package mdriver

import (
	"context"
	"encoding/json"
	"errors"
	"reflect"
	"testing"
)

// The sync wrappers exist for m lib (m-cli): pre-image capture reads routine
// source off the engine via `sync pull` (never $TEXT — FATAL-2), and
// uninstall/heal remove a routine via `sync rm`. Argv must follow the contract
// §5.2 shapes exactly so both drivers parse them.

func TestClient_SyncPull_ArgvAndParse(t *testing.T) {
	r := PullResult{Mirror: "/tmp/mir", Pulled: 3, Unchanged: 1, Bytes: 512}
	f := &fakeCmd{stdout: clientEnvBytes(t, "sync pull", true, 0, r, nil)}
	c := NewClient("m-ydb", "ydb", "docker", []string{"--container", "eng"}, f.run)

	got, err := c.SyncPull(context.Background(), "/tmp/mir", "STD*", true)
	if err != nil {
		t.Fatalf("SyncPull: %v", err)
	}
	if got.Pulled != 3 || got.Bytes != 512 {
		t.Errorf("result = %+v, want pulled=3 bytes=512", got)
	}
	want := []string{"sync", "pull", "--mirror", "/tmp/mir", "--filter", "STD*", "--full",
		"--transport", "docker", "--container", "eng", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

func TestClient_SyncPull_NoFilterNoFull(t *testing.T) {
	f := &fakeCmd{stdout: clientEnvBytes(t, "sync pull", true, 0, PullResult{}, nil)}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)

	if _, err := c.SyncPull(context.Background(), "/tmp/mir", "", false); err != nil {
		t.Fatalf("SyncPull: %v", err)
	}
	want := []string{"sync", "pull", "--mirror", "/tmp/mir", "--transport", "local", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

func TestClient_SyncRm_ArgvAndParse(t *testing.T) {
	r := RmResult{Removed: []string{"MLIBPRB2.m"}}
	f := &fakeCmd{stdout: clientEnvBytes(t, "sync rm <name>", true, 0, r, nil)}
	c := NewClient("m-ydb", "ydb", "docker", []string{"--container", "eng"}, f.run)

	got, err := c.SyncRm(context.Background(), "MLIBPRB2")
	if err != nil {
		t.Fatalf("SyncRm: %v", err)
	}
	if len(got.Removed) != 1 || got.Removed[0] != "MLIBPRB2.m" {
		t.Errorf("removed = %v", got.Removed)
	}
	want := []string{"sync", "rm", "MLIBPRB2",
		"--transport", "docker", "--container", "eng", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

// A driver Fail-path envelope on a sync verb must surface as *DriverError, the
// same F5 discipline as every other wrapper.
func TestClient_SyncRm_FailEnvelopeIsDriverError(t *testing.T) {
	env := envelope{SchemaVersion: "1.0", Command: "sync rm <name>", OK: false, Exit: 3,
		Error: &envError{Code: "RUNTIME", Exit: 3, Message: "rm failed"}}
	b, merr := json.Marshal(env)
	if merr != nil {
		t.Fatalf("marshal: %v", merr)
	}
	f := &fakeCmd{stdout: b}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)

	_, err := c.SyncRm(context.Background(), "GONE")
	var de *DriverError
	if !errors.As(err, &de) {
		t.Fatalf("err = %v (%T), want *DriverError", err, err)
	}
	if de.Code != "RUNTIME" {
		t.Errorf("code = %q", de.Code)
	}
}
