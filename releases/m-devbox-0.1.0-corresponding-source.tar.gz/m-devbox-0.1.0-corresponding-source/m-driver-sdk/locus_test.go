package mdriver

import (
	"context"
	"errors"
	"strings"
	"testing"
)

// R-9: the key names the PLACE, not the ROUTE. A selector aliases — across
// transports (iris.docker.foia-t12 vs iris.remote.127.0.0.1_52773 — the live
// healthcheck config) and within one (an --docker <id> vs its name; localhost vs
// 127.0.0.1 vs a tunnel). A key built from a selector spelling can never be
// collision-free against itself. These tests pin the canonical-locus ladder.

// fakeDocker models what the REAL docker CLI does — which is the whole of S2:
// `docker inspect` exits non-zero for BOTH "no such container" (a clean no-match,
// which must key self-canonically so `lifecycle provision` can run) AND "cannot
// connect to the daemon" (which must REFUSE). The exit code alone cannot tell them
// apart, and getting it wrong is a SILENT SPLIT LOCK.
type fakeDocker struct {
	inspect     map[string]string // selector -> canonical name
	ps          string            // `docker ps -a` output: ID\tNAME\tHOSTNAME per line
	daemonDown  bool              // every docker call fails the way a dead daemon fails
	noDockerCLI bool              // docker is not installed at all
}

func (f fakeDocker) runner() DockerRunner {
	return func(_ context.Context, args ...string) ([]byte, error) {
		if f.noDockerCLI {
			return nil, ErrNoDocker
		}
		if f.daemonDown {
			// A dead daemon fails EVERY call — including the liveness probe. That is
			// what makes it distinguishable from a missing container.
			return nil, &DockerError{Args: args, Exit: 1,
				Stderr: "Cannot connect to the Docker daemon at unix:///var/run/docker.sock."}
		}
		switch args[0] {
		case "version": // the liveness probe: the daemon is up
			return []byte("27.0.3\n"), nil
		case "inspect":
			if name, ok := f.inspect[args[len(args)-1]]; ok {
				return []byte("/" + name + "\n"), nil
			}
			return nil, &DockerError{Args: args, Exit: 1,
				Stderr: "Error: No such object: " + args[len(args)-1]}
		case "ps":
			return []byte(f.ps), nil
		}
		return nil, errors.New("unscripted: " + strings.Join(args, " "))
	}
}

func lab() fakeDocker {
	return fakeDocker{
		inspect: map[string]string{
			"foia-t12":     "foia-t12",
			"3cf3d3cf2ff9": "foia-t12", // the ID spelling of the same container
			"vehu":         "vehu",
		},
		// ID \t NAME \t HOSTNAME  (a container's default hostname IS its short ID)
		ps: "3cf3d3cf2ff9\tfoia-t12\t3cf3d3cf2ff9\n" +
			"aa11bb22cc33\tvehu\taa11bb22cc33\n",
	}
}

func TestLocus_Key(t *testing.T) {
	l := Locus{Class: LocusDocker, ID: "foia-t12"}
	if got := l.Key("iris"); got != "iris.docker.foia-t12" {
		t.Errorf("Key = %q, want iris.docker.foia-t12", got)
	}
	// A key is a lock-file basename: no separators may survive.
	dirty := Locus{Class: LocusRemote, ID: "iris.va.gov:52773/VISTA"}
	if k := dirty.Key("iris"); strings.ContainsAny(k, "/: ") {
		t.Errorf("key %q is not safe as a basename", k)
	}
}

// Defeat (i), within one transport: `--docker <id>` and `--docker <name>` are the
// SAME container. A selector-spelled key would give them two lock files.
func TestDockerLocus_CanonicalizesIDToName(t *testing.T) {
	d := &DockerLocator{Run: lab().runner()}
	byName, err := d.Canonicalize(context.Background(), "foia-t12")
	if err != nil {
		t.Fatalf("by name: %v", err)
	}
	byID, err := d.Canonicalize(context.Background(), "3cf3d3cf2ff9")
	if err != nil {
		t.Fatalf("by id: %v", err)
	}
	if byName != byID {
		t.Errorf("id and name derive different loci: %+v vs %+v", byID, byName)
	}
	if byName.Class != LocusDocker || byName.ID != "foia-t12" {
		t.Errorf("locus = %+v, want the canonical NAME", byName)
	}
}

// S2 — THE SILENT SPLIT LOCK. This is the regression test for the defect the m-ydb
// spike found in v0.8.0: `docker inspect` exits non-zero for a missing container AND
// for a dead daemon, and the SDK mapped BOTH to the clean-no-match sentinel. A dead
// daemon therefore yielded locus{docker, <raw selector>} with err == nil — so
// `--container vehu` keyed `ydb.docker.vehu` while `--container <its id>` keyed
// `ydb.docker.<id>`: TWO LOCK FILES, ONE ENGINE, NO ERROR.
//
// That is defeat (i) reintroduced exactly when the box is degraded — i.e. defeat (n),
// the very case RUN_LOCK_UNRESOLVED exists to close — reintroduced inside the code
// that fixes R-9.
//
// v0.8.0's test for this passed while the bug was live, because its fake returned a
// plain errors.New rather than an exit failure, so it never walked the real path. A
// test that cannot fail is not a test.
func TestDockerLocus_DaemonDownRefuses_NotACleanNoMatch(t *testing.T) {
	d := &DockerLocator{Run: fakeDocker{daemonDown: true}.runner()}

	l, err := d.Canonicalize(context.Background(), "3cf3d3cf2ff9")
	if err == nil {
		t.Fatalf("a DEAD DAEMON produced a key (%+v) instead of refusing — this is the silent split lock: "+
			"the id and the name of one container would take two different lock files", l)
	}
	if l.Valid() {
		t.Errorf("a refused derivation must yield NO locus, got %+v", l)
	}
}

// …and the other side of the same coin: with the daemon ALIVE, a container that does
// not exist is a CLEAN no-match and must still key self-canonically — otherwise
// `lifecycle provision --docker foo` could never take a bracket.
func TestDockerLocus_NoSuchContainer_LiveDaemon_IsSelfCanonical(t *testing.T) {
	d := &DockerLocator{Run: lab().runner()} // daemon up, container absent
	l, err := d.Canonicalize(context.Background(), "not-created-yet")
	if err != nil {
		t.Fatalf("daemon alive + container absent must be a clean no-match: %v", err)
	}
	if l != (Locus{Class: LocusDocker, ID: "not-created-yet"}) {
		t.Errorf("locus = %+v, want the requested name (you are about to CREATE it)", l)
	}
}

// A custom DockerRunner must be able to EXPRESS a clean no-match — in v0.8.0 the
// sentinel was unexported and minted only inside the real closure, so an injected
// runner could produce nothing but a daemon error, and the self-canonical rung (the
// one that dissolves the bootstrap problem) was untestable by any consumer.
func TestDockerLocus_CustomRunnerCanExpressACleanNoMatch(t *testing.T) {
	d := &DockerLocator{Run: func(_ context.Context, _ ...string) ([]byte, error) {
		return nil, ErrNoSuchContainer
	}}
	l, err := d.Canonicalize(context.Background(), "brand-new")
	if err != nil {
		t.Fatalf("an explicit ErrNoSuchContainer must be honored as a clean no-match: %v", err)
	}
	if l.ID != "brand-new" {
		t.Errorf("locus = %+v, want the self-canonical name", l)
	}
}

// A box with NO docker at all runs no containers — for a NETWORK route that is a real
// answer (clean no-match ⇒ classify foreign), not an infrastructure failure.
func TestMatchNode_NoDockerCLIIsACleanNoMatch(t *testing.T) {
	d := &DockerLocator{Run: fakeDocker{noDockerCLI: true}.runner()}
	l, found, err := d.MatchNode(context.Background(), "iris-prod-07.va.gov")
	if err != nil {
		t.Fatalf("no docker CLI is not an enumeration failure: %v", err)
	}
	if found || l.Valid() {
		t.Errorf("got %+v found=%v, want a clean no-match", l, found)
	}
}

// THE R-9 UNIFICATION. A network route asks the live engine its node fingerprint;
// if that node is a local container, the key is THAT CONTAINER'S DOCKER KEY. This
// is the single line that makes `m test --docker foia-t12` and
// `v pkg install --transport remote` (the live healthcheck lane) serialize.
func TestMatchNode_NetworkRouteUnifiesWithTheDockerRoute(t *testing.T) {
	d := &DockerLocator{Run: lab().runner()}
	// foia-t12's node fingerprint, as reported by the engine over Atelier: its
	// container ID (a container's default hostname IS its short ID — measured).
	l, found, err := d.MatchNode(context.Background(), "3cf3d3cf2ff9")
	if err != nil {
		t.Fatalf("MatchNode: %v", err)
	}
	if !found {
		t.Fatal("the engine's node is a local container but was not matched")
	}
	dockerRoute, _ := d.Canonicalize(context.Background(), "foia-t12")
	if l != dockerRoute {
		t.Fatalf("the two routes to ONE instance derive different loci: remote=%+v docker=%+v", l, dockerRoute)
	}
	if l.Key("iris") != "iris.docker.foia-t12" {
		t.Errorf("key = %q, want the container's docker key", l.Key("iris"))
	}
}

// The engine may report a SHORT id, a long id, or the name. All must unify.
func TestMatchNode_AcceptsIDPrefixAndName(t *testing.T) {
	d := &DockerLocator{Run: lab().runner()}
	want := Locus{Class: LocusDocker, ID: "foia-t12"}
	for _, node := range []string{"3cf3d3cf2ff9", "3cf3d3cf", "foia-t12"} {
		l, found, err := d.MatchNode(context.Background(), node)
		if err != nil || !found {
			t.Fatalf("node %q: found=%v err=%v", node, found, err)
		}
		if l != want {
			t.Errorf("node %q → %+v, want %+v", node, l, want)
		}
	}
}

// A genuinely foreign engine: a CLEAN no-match. Not an error — the caller keys it
// from the engine-reported fingerprint (never the dialed spelling), which is what
// unifies tunnels and DNS aliases.
func TestMatchNode_ForeignEngineIsACleanNoMatch(t *testing.T) {
	d := &DockerLocator{Run: lab().runner()}
	l, found, err := d.MatchNode(context.Background(), "iris-prod-07.va.gov")
	if err != nil {
		t.Fatalf("a foreign engine is not an error: %v", err)
	}
	if found {
		t.Fatalf("a foreign node matched a local container: %+v", l)
	}
}

// Defeat (n) again, on the match path: an enumeration ERROR is NOT a no-match. The
// distinction is contract (C-RL-8) — error ⇒ refuse; clean no-match ⇒ foreign.
func TestMatchNode_EnumerationErrorIsNotANoMatch(t *testing.T) {
	d := &DockerLocator{Run: fakeDocker{daemonDown: true}.runner()}
	_, found, err := d.MatchNode(context.Background(), "anything")
	if err == nil {
		t.Fatal("an enumeration error must surface as an error, never as a clean no-match")
	}
	if found {
		t.Fatal("found must be false on error")
	}
}

// Defeat (l): two containers with the same explicit --hostname. Ambiguous ⇒
// fail-closed, naming both candidates. Never a guess.
func TestMatchNode_AmbiguousHostnameRefuses(t *testing.T) {
	f := lab()
	f.ps = "aaaa\tone\tshared-host\nbbbb\ttwo\tshared-host\n"
	d := &DockerLocator{Run: f.runner()}
	_, found, err := d.MatchNode(context.Background(), "shared-host")
	if err == nil {
		t.Fatal("an ambiguous node match must refuse, not guess")
	}
	if found {
		t.Fatal("found must be false when ambiguous")
	}
	if !strings.Contains(err.Error(), "one") || !strings.Contains(err.Error(), "two") {
		t.Errorf("the refusal must name both candidates: %v", err)
	}
}

// The fail-closed refusal itself (R-9.3): a route that cannot be resolved does NOT
// get a key — a bracket-requiring verb on it is refused.
func TestUnresolvedRunLock(t *testing.T) {
	err := UnresolvedRunLock("iris", errors.New("docker daemon down"))
	var rl *RunLockError
	if !errors.As(err, &rl) {
		t.Fatalf("err %T is not a *RunLockError", err)
	}
	if rl.Code != CodeRunLockUnresolved {
		t.Errorf("code = %q, want %q", rl.Code, CodeRunLockUnresolved)
	}
	if rl.Exit != ExitRunLockRefused {
		t.Errorf("exit = %d, want %d", rl.Exit, ExitRunLockRefused)
	}
	if !strings.Contains(rl.Error(), "daemon down") {
		t.Errorf("the refusal must carry WHY it could not resolve: %v", rl)
	}
}

// AMENDMENT C — the loud break. RunLockKey(engine, transport, selector) is GONE:
// its replacement takes a Locus, so a stale caller passing a raw transport+selector
// fails to COMPILE rather than silently deriving a legacy (route-spelled) key. That
// is only free because zero drivers implemented runlock-path — this test exists so
// the reason is recorded where it cannot rot.
func TestLocus_ReplacesTheRouteSpelledKey(t *testing.T) {
	// The engine-instance-path ADR's "derive, never declare" still holds: the local
	// locus is a DERIVED interior, hashed so it never appears in a lock-file name.
	l := Locus{Class: LocusLocal, ID: HashSelector("/var/db/vehu/vehu.gld")}
	k := l.Key("ydb")
	if !strings.HasPrefix(k, "ydb.local.") || strings.Contains(k, "/") {
		t.Errorf("key = %q, want ydb.local.<hash> with no interior in it", k)
	}
	if len(l.ID) != 12 {
		t.Errorf("local locus id = %q, want a 12-char digest", l.ID)
	}
}
