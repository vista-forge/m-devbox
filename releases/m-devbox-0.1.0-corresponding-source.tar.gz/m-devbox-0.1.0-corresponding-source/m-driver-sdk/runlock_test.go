package mdriver

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// lockClient returns a Client whose `meta runlock-path` resolves to a lock file
// under dir — the driver is the derivation authority (R-3), so the SDK always
// asks for the key/path instead of composing one itself.
func lockClient(t *testing.T, dir, key string) *Client {
	t.Helper()
	return NewClient("m-ydb", "ydb", TransportDocker, nil,
		func(_ context.Context, _ string, args []string) ([]byte, []byte, int, error) {
			joined := strings.Join(args, " ")
			if !strings.HasPrefix(joined, "meta runlock-path") {
				return nil, nil, 7, nil
			}
			// Honor the --run-lock-dir override the SDK passes for a fixture dir.
			d := dir
			for i, a := range args {
				if a == "--run-lock-dir" && i+1 < len(args) {
					d = args[i+1]
				}
			}
			ref := RunLockRef{Key: key, Path: filepath.Join(d, key+".lock")}
			data, _ := json.Marshal(ref)
			env := fmt.Sprintf(`{"schemaVersion":"1.0","command":"meta runlock-path","ok":true,"exit":0,"data":%s}`, data)
			return []byte(env), nil, 0, nil
		})
}

func mustAcquire(t *testing.T, o RunLockOptions) *RunLock {
	t.Helper()
	l, err := AcquireRunLock(context.Background(), o)
	if err != nil {
		t.Fatalf("AcquireRunLock: %v", err)
	}
	t.Cleanup(func() { _ = l.Release() })
	return l
}

func readRecordFile(t *testing.T, path string) RunLockRecord {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read record: %v", err)
	}
	var r RunLockRecord
	if err := json.Unmarshal(b, &r); err != nil {
		t.Fatalf("decode record %q: %v", b, err)
	}
	return r
}

func TestAcquireRunLock_WritesRecordAndFencesTheToken(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")

	l := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "m test"})

	if l.Key != "ydb.docker.vehu" {
		t.Errorf("Key = %q, want the driver-derived key", l.Key)
	}
	if l.Path != filepath.Join(dir, "ydb.docker.vehu.lock") {
		t.Errorf("Path = %q, want the driver-derived path", l.Path)
	}
	if l.Token == "" {
		t.Fatal("no run token generated")
	}
	if !l.Owned() {
		t.Error("an acquired bracket must be owned")
	}

	rec := readRecordFile(t, l.Path)
	// §6b: the record stores the token's SHA-256, NEVER the token — a joiner gets
	// it by process inheritance, so a "helpful" script cannot scrape ownership.
	sum := sha256.Sum256([]byte(l.Token))
	if rec.TokenSHA256 != hex.EncodeToString(sum[:]) {
		t.Errorf("record tokenSHA256 = %q, want sha256(token)", rec.TokenSHA256)
	}
	if strings.Contains(string(mustJSON(t, rec)), l.Token) {
		t.Error("the raw token leaked into the holder record")
	}
	if rec.PID != os.Getpid() || rec.Consumer != "m test" || rec.Key != l.Key || rec.V != 1 {
		t.Errorf("record narrative is wrong: %+v", rec)
	}
	if rec.StartedAt.IsZero() {
		t.Error("record has no startedAt")
	}
}

func mustJSON(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	return b
}

func TestAcquireRunLock_DirIs0700(t *testing.T) {
	root := t.TempDir()
	dir := filepath.Join(root, "run-lock")
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})

	fi, err := os.Stat(dir)
	if err != nil {
		t.Fatalf("stat lock dir: %v", err)
	}
	if perm := fi.Mode().Perm(); perm != 0o700 {
		t.Errorf("lock dir mode = %o, want 0700", perm)
	}
}

func TestAcquireRunLock_TryModeOnHeldLockIsBusyNotAnError(t *testing.T) {
	// R-6 / C-RL-6: Wait == 0 is a single LOCK_EX|LOCK_NB attempt. On failure the
	// caller proceeds in report-only mode — a distinct machine-readable outcome
	// naming the holder, NEVER a bare green and never a red.
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	held := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "v pkg install VSL.kids"})
	before := readRecordFile(t, held.Path)

	l, err := AcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir, Wait: 0})
	if l != nil {
		t.Fatal("try-mode acquired a lock that was already held")
	}
	if !IsEngineBusy(err) {
		t.Fatalf("err = %v, want an engine-busy outcome", err)
	}
	var rl *RunLockError
	if !errors.As(err, &rl) {
		t.Fatalf("err %T is not a *RunLockError", err)
	}
	if rl.Code != CodeEngineBusy {
		t.Errorf("code = %q, want %q", rl.Code, CodeEngineBusy)
	}
	// It must name the measured holder, so the STAMP can say WHO, not just "busy".
	if rl.Status == nil || rl.Status.Record == nil || rl.Status.Record.Consumer != "v pkg install VSL.kids" {
		t.Errorf("busy outcome does not name the holder: %+v", rl.Status)
	}
	// "no side effects": the holder's record is untouched.
	if after := readRecordFile(t, held.Path); after.TokenSHA256 != before.TokenSHA256 {
		t.Error("a failed try-mode acquire overwrote the holder's record")
	}
}

func TestAcquireRunLock_BoundedWaitTimesOutLoudly(t *testing.T) {
	// §2 rule 2: liveness is bounded and never silent. §7.4: every wait is
	// bounded and the waiter holds nothing.
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "healthcheck"})

	var waited []RunLockStatus
	start := time.Now()
	l, err := AcquireRunLock(context.Background(), RunLockOptions{
		Client: cl, Dir: dir, Wait: 150 * time.Millisecond,
		poll:   10 * time.Millisecond,
		OnWait: func(s RunLockStatus) { waited = append(waited, s) },
	})
	elapsed := time.Since(start)

	if l != nil {
		t.Fatal("acquired a held lock")
	}
	var rl *RunLockError
	if !errors.As(err, &rl) || rl.Code != CodeRunLockTimeout {
		t.Fatalf("err = %v, want %s", err, CodeRunLockTimeout)
	}
	if elapsed < 150*time.Millisecond {
		t.Errorf("returned after %v, before the %v deadline", elapsed, 150*time.Millisecond)
	}
	if len(waited) == 0 {
		t.Error("OnWait never fired — a wait must be loud immediately, not silent")
	}
	if !strings.Contains(rl.Error(), "healthcheck") {
		t.Errorf("the timeout does not name the holder: %v", rl)
	}
}

func TestAcquireRunLock_WaitSucceedsOnceTheHolderReleases(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	held := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "first"})

	go func() {
		time.Sleep(40 * time.Millisecond)
		_ = held.Release()
	}()

	l, err := AcquireRunLock(context.Background(), RunLockOptions{
		Client: cl, Dir: dir, Wait: 2 * time.Second, poll: 10 * time.Millisecond, Consumer: "second",
	})
	if err != nil {
		t.Fatalf("waiter never acquired: %v", err)
	}
	defer func() { _ = l.Release() }()
	// The new lane overwrites the record with its own tokenSHA — this is what
	// fences a dead bracket's orphan children (§6b).
	rec := readRecordFile(t, l.Path)
	sum := sha256.Sum256([]byte(l.Token))
	if rec.TokenSHA256 != hex.EncodeToString(sum[:]) || rec.Consumer != "second" {
		t.Errorf("the new holder did not overwrite the record: %+v", rec)
	}
}

func TestAcquireRunLock_ContextCancelStopsTheWait(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})

	ctx, cancel := context.WithCancel(context.Background())
	go func() { time.Sleep(30 * time.Millisecond); cancel() }()

	_, err := AcquireRunLock(ctx, RunLockOptions{Client: cl, Dir: dir, Wait: time.Minute, poll: 10 * time.Millisecond})
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("err = %v, want context.Canceled (Ctrl-C while waiting holds nothing — exit cleanly)", err)
	}
}

func TestRelease_IsIdempotentAndFreesTheLock(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	l := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})

	if err := l.Release(); err != nil {
		t.Fatalf("Release: %v", err)
	}
	if err := l.Release(); err != nil {
		t.Fatalf("second Release must be a no-op, got %v", err)
	}
	rec := readRecordFile(t, l.Path)
	if rec.ReleasedAt == nil {
		t.Error("release did not stamp releasedAt on the record")
	}
	// The lock is free: a try-mode acquire now succeeds.
	l2, err := AcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	if err != nil {
		t.Fatalf("lock not released: %v", err)
	}
	_ = l2.Release()
}

func TestJoinRunLock_IsOwnerReentrantAndItsReleaseIsANoOp(t *testing.T) {
	// §R-2 reentrancy rule + defeat (d): the nested case (m test → v pkg install
	// → driver call). The inner layer VERIFIES, it does not lock; only the
	// acquiring process releases. A joined Release that actually released would
	// hand the engine to another lane mid-run — the whole nested case turns on
	// this being a no-op.
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	held := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "m test"})

	t.Setenv(EnvRunLockToken, held.Token)
	t.Setenv(EnvRunLockKey, held.Key)

	joined, err := JoinRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir, Consumer: "v pkg install"})
	if err != nil {
		t.Fatalf("JoinRunLock: %v", err)
	}
	if joined.Owned() {
		t.Error("a joined handle must not be owned")
	}
	if joined.Token != held.Token || joined.Key != held.Key {
		t.Error("the joined handle does not carry the ambient bracket's identity")
	}
	if err := joined.Release(); err != nil {
		t.Fatalf("joined Release: %v", err)
	}
	// The bracket is STILL held after the joined release.
	if err := VerifyRunLock(RunLockRef{Key: held.Key, Path: held.Path}, held.Token); err != nil {
		t.Fatalf("a joined Release released the owner's bracket: %v", err)
	}
	rec := readRecordFile(t, held.Path)
	if rec.ReleasedAt != nil {
		t.Error("a joined Release stamped releasedAt — it must not touch the record")
	}
}

func TestJoinRunLock_NoAmbientTokenIsRefused(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})
	t.Setenv(EnvRunLockToken, "")

	_, err := JoinRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	var rl *RunLockError
	if !errors.As(err, &rl) || rl.Code != CodeRunLockRequired {
		t.Fatalf("err = %v, want %s", err, CodeRunLockRequired)
	}
}

func TestJoinRunLock_ForeignTokenIsRefused(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})
	t.Setenv(EnvRunLockToken, "not-the-holders-token")

	_, err := JoinRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	var rl *RunLockError
	if !errors.As(err, &rl) || rl.Code != CodeRunLockMismatch {
		t.Fatalf("err = %v, want %s", err, CodeRunLockMismatch)
	}
}

func TestJoinRunLock_AmbientBracketForAnotherEngineIsNotAJoin(t *testing.T) {
	// A nested tool under a vehu bracket that targets foia must NOT believe it is
	// protected: the ambient key is a different serialization domain.
	dir := t.TempDir()
	vehu := lockClient(t, dir, "ydb.docker.vehu")
	foia := lockClient(t, dir, "iris.docker.foia-t12")
	held := mustAcquire(t, RunLockOptions{Client: vehu, Dir: dir})

	t.Setenv(EnvRunLockToken, held.Token)
	t.Setenv(EnvRunLockKey, held.Key)

	_, err := JoinRunLock(context.Background(), RunLockOptions{Client: foia, Dir: dir})
	var rl *RunLockError
	if !errors.As(err, &rl) || rl.Code != CodeRunLockNotHeld {
		t.Fatalf("err = %v, want %s (the ambient bracket is for another key)", err, CodeRunLockNotHeld)
	}
	if !strings.Contains(rl.Error(), "ydb.docker.vehu") {
		t.Errorf("the refusal does not name the ambient key: %v", rl)
	}
}

func TestJoinOrAcquireRunLock(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")

	// No ambient bracket → acquire.
	t.Setenv(EnvRunLockToken, "")
	l, err := JoinOrAcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	if err != nil {
		t.Fatalf("acquire path: %v", err)
	}
	if !l.Owned() {
		t.Error("with no ambient bracket, JoinOrAcquire must ACQUIRE (owned)")
	}

	// Ambient bracket for this key → join, no second acquire (no self-wait).
	t.Setenv(EnvRunLockToken, l.Token)
	t.Setenv(EnvRunLockKey, l.Key)
	j, err := JoinOrAcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	if err != nil {
		t.Fatalf("join path: %v", err)
	}
	if j.Owned() {
		t.Error("with an ambient bracket, JoinOrAcquire must JOIN (not owned)")
	}
	_ = l.Release()
}

// --- the driver-side dispatch primitive (§R-2's verification) ----------------

func TestVerifyRunLock_NeverAcquiresTheLock(t *testing.T) {
	// The heart of the deadlock argument (§7.3): verification is a NON-BLOCKING
	// probe + record compare, never an acquisition. If the probe kept the lock it
	// took, the first in-bracket driver call would lock the engine against its own
	// bracket-holder — and every subsequent call in the run would refuse.
	dir := t.TempDir()
	ref := RunLockRef{Key: "ydb.docker.vehu", Path: filepath.Join(dir, "ydb.docker.vehu.lock")}

	// Probing a FREE lock must refuse AND leave it free.
	for i := 0; i < 3; i++ {
		err := VerifyRunLock(ref, "")
		var rl *RunLockError
		if !errors.As(err, &rl) || rl.Code != CodeRunLockRequired {
			t.Fatalf("probe %d: err = %v, want %s", i, err, CodeRunLockRequired)
		}
	}
	// Still free — an acquire succeeds immediately.
	cl := lockClient(t, dir, "ydb.docker.vehu")
	l, err := AcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	if err != nil {
		t.Fatalf("the probe kept the lock it took: %v", err)
	}
	defer func() { _ = l.Release() }()

	// And an in-bracket call verifies repeatedly without ever blocking or failing.
	for i := 0; i < 3; i++ {
		if err := VerifyRunLock(ref, l.Token); err != nil {
			t.Fatalf("in-bracket verify %d failed: %v", i, err)
		}
	}
}

func TestVerifyRunLock_Refusals(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	ref := RunLockRef{Key: "ydb.docker.vehu", Path: filepath.Join(dir, "ydb.docker.vehu.lock")}

	// C-RL-1: no bracket, no token → REQUIRED.
	assertRefusal(t, VerifyRunLock(ref, ""), CodeRunLockRequired)
	// C-RL-3: no bracket, token presented → NOT_HELD (the bracket died under its
	// own children).
	assertRefusal(t, VerifyRunLock(ref, "stale-token"), CodeRunLockNotHeld)

	l := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "v pkg install"})

	// C-RL-2: valid token + held lock → proceeds.
	if err := VerifyRunLock(ref, l.Token); err != nil {
		t.Fatalf("the owner was refused its own bracket: %v", err)
	}
	// C-RL-1 (held): no token while another lane holds → REQUIRED, naming the holder.
	err := VerifyRunLock(ref, "")
	assertRefusal(t, err, CodeRunLockRequired)
	if !strings.Contains(err.Error(), "v pkg install") {
		t.Errorf("the refusal does not name the measured holder: %v", err)
	}
	// C-RL-4 (fencing): a surviving orphan of a dead bracket presents the OLD
	// token while a new lane holds → the record compare fails. This is the
	// kernel-anchored fencing guarantee, so it gets a test, not a comment.
	assertRefusal(t, VerifyRunLock(ref, "the-dead-brackets-token"), CodeRunLockMismatch)
}

func TestVerifyRunLock_HeldWithAnUnreadableRecordFailsClosed(t *testing.T) {
	// The bracket is held but its record is absent/garbage (the microsecond window
	// between flock and the record write, or a corrupted file). Exclusivity is
	// fail-CLOSED: we cannot prove ownership, so we refuse.
	dir := t.TempDir()
	path := filepath.Join(dir, "ydb.docker.vehu.lock")
	ref := RunLockRef{Key: "ydb.docker.vehu", Path: path}

	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = f.Close() }()
	if ok, err := flockTry(f); err != nil || !ok {
		t.Fatalf("could not hold the fixture lock: ok=%v err=%v", ok, err)
	}
	if _, err := f.WriteString("not json"); err != nil {
		t.Fatal(err)
	}

	assertRefusal(t, VerifyRunLock(ref, "any-token"), CodeRunLockMismatch)
}

func assertRefusal(t *testing.T, err error, wantCode string) {
	t.Helper()
	var rl *RunLockError
	if !errors.As(err, &rl) {
		t.Fatalf("err = %v (%T), want a *RunLockError with code %s", err, err, wantCode)
	}
	if rl.Code != wantCode {
		t.Fatalf("code = %q, want %q", rl.Code, wantCode)
	}
	if rl.Exit != ExitRunLockRefused {
		t.Errorf("exit = %d, want %d (the contract's refusal rung)", rl.Exit, ExitRunLockRefused)
	}
}

func TestRequireRunLock_EnforcesOnlyTheClassesThatNeedIt(t *testing.T) {
	dir := t.TempDir()
	ref := RunLockRef{Key: "ydb.docker.vehu", Path: filepath.Join(dir, "ydb.docker.vehu.lock")}

	// status/control run with NO token and NO bracket — C-RL-5. If they did not,
	// a stuck run could never be observed or unwedged (§R-7), and AcquireRunLock
	// could never call runlock-path to bootstrap (§7.3).
	for _, c := range []VerbClass{ClassStatus, ClassControl} {
		if err := RequireRunLock(c, ref, ""); err != nil {
			t.Errorf("%s was refused: %v", c, err)
		}
	}
	// mutating/read without a bracket are refused — C-RL-1.
	for _, c := range []VerbClass{ClassMutating, ClassRead} {
		assertRefusal(t, RequireRunLock(c, ref, ""), CodeRunLockRequired)
	}
}

// --- status measurement ------------------------------------------------------

func TestProbeRunLock_UnheldThenHeld(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	ref := RunLockRef{Key: "ydb.docker.vehu", Path: filepath.Join(dir, "ydb.docker.vehu.lock")}

	st, err := ProbeRunLock(ref)
	if err != nil {
		t.Fatalf("ProbeRunLock: %v", err)
	}
	if st.State != HolderUnheld || st.Held() {
		t.Errorf("state = %q, want %q", st.State, HolderUnheld)
	}

	l := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "m test"})
	st, err = ProbeRunLock(ref)
	if err != nil {
		t.Fatalf("ProbeRunLock: %v", err)
	}
	if !st.Held() || st.State != HolderRunning {
		t.Errorf("state = %q, want %q", st.State, HolderRunning)
	}
	if st.Record == nil || st.Record.PID != os.Getpid() {
		t.Errorf("status carries no holder record: %+v", st.Record)
	}
	// /proc/locks is the measurement of WHO — the kernel's answer, not a
	// self-report (R-5 layer 2).
	if len(st.Holders) == 0 {
		t.Error("no kernel-measured holder: /proc/locks was not consulted")
	}
	var found bool
	for _, h := range st.Holders {
		if h.PID == os.Getpid() {
			found = true
		}
	}
	if !found {
		t.Errorf("this process holds the lock but is not among the measured holders: %+v", st.Holders)
	}
	if !strings.Contains(st.Describe(), "m test") {
		t.Errorf("Describe() = %q, want it to name the holder", st.Describe())
	}
	_ = l
}

func TestRunLockStatus_StoppedHolderTriageIsMechanized(t *testing.T) {
	// R-5: the 6 h suspended-writer incident becomes a first-wait diagnostic. The
	// playbook is retired from memory INTO the tool, so the steps must actually be
	// in the output — with the real pgid substituted.
	st := RunLockStatus{
		Key:   "iris.docker.foia-t12",
		State: HolderStopped,
		Record: &RunLockRecord{
			PID: 12345, PGID: 12300, Consumer: "v pkg install VSL.kids", StartedAt: time.Now(),
		},
		Holders: []RunLockHolder{{PID: 12345, State: "T", Cmd: "v"}},
	}
	tri := st.StoppedHolderTriage()
	for _, want := range []string{
		"attest verify",     // step 1: diagnose with the B0 ledger first
		"kill -9 -- -12300", // step 2: SIGKILL the process group WHILE STOPPED
		"never SIGCONT",     // the hard-won rule: a resumed writer runs a stale plan forward
		"docker top",        // step 3: a host-killed docker exec does not kill the container-side process
	} {
		if !strings.Contains(tri, want) {
			t.Errorf("triage is missing %q:\n%s", want, tri)
		}
	}
}

func TestAcquireRunLock_StoppedHolderStopsTheWaitEarly(t *testing.T) {
	// R-5: if the holder is state T, stop waiting early and fail with the
	// mechanized triage — do not burn the full timeout, and NEVER auto-break.
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	mustAcquire(t, RunLockOptions{Client: cl, Dir: dir, Consumer: "frozen writer"})

	// Force the liveness sampler to report a stopped holder without actually
	// SIGSTOPping the test process.
	restore := holderStateFn
	holderStateFn = func(int) (string, string, bool) { return "T", "v", true }
	t.Cleanup(func() { holderStateFn = restore })

	start := time.Now()
	_, err := AcquireRunLock(context.Background(), RunLockOptions{
		Client: cl, Dir: dir, Wait: 10 * time.Second, poll: 10 * time.Millisecond,
	})
	elapsed := time.Since(start)

	var rl *RunLockError
	if !errors.As(err, &rl) || rl.Code != CodeRunLockHolderStopped {
		t.Fatalf("err = %v, want %s", err, CodeRunLockHolderStopped)
	}
	if elapsed > 3*time.Second {
		t.Errorf("waited %v — a stopped holder must stop the wait EARLY, not burn the timeout", elapsed)
	}
	if !strings.Contains(rl.Hint, "never SIGCONT") {
		t.Errorf("the refusal does not carry the mechanized triage:\n%s", rl.Hint)
	}
	// And no auto-break, ever: the lock is still held.
	st, _ := ProbeRunLock(RunLockRef{Key: "ydb.docker.vehu", Path: filepath.Join(dir, "ydb.docker.vehu.lock")})
	if !st.Held() {
		t.Error("the waiter BROKE a lock it believed dead — breaking is human-only (R-5)")
	}
}

// --- key derivation ----------------------------------------------------------
//
// The route-spelled RunLockKey(engine, transport, selector) is GONE as of v0.8.0 —
// it keyed on the ROUTE, and routes alias (§R-9). Derivation now goes through
// Locus.Key; see locus_test.go. These two properties still hold and are asserted
// there: same instance → same key (serialize); different instances → different keys
// (do not block each other).

func TestLocus_SameInstanceOneKey_DifferentInstancesTwo(t *testing.T) {
	a := Locus{Class: LocusDocker, ID: "vehu"}
	b := Locus{Class: LocusDocker, ID: "vehu"}
	c := Locus{Class: LocusDocker, ID: "vehu-2"}
	if a.Key("ydb") != b.Key("ydb") {
		t.Error("the same instance must derive the same key")
	}
	if a.Key("ydb") == c.Key("ydb") {
		t.Error("different instances must derive different keys")
	}
}

func TestDeriveRunLockRef_DefaultHome(t *testing.T) {
	ref, err := DeriveRunLockRef("", "ydb.docker.vehu")
	if err != nil {
		t.Fatalf("DeriveRunLockRef: %v", err)
	}
	// R-4: the home is ~/data/vista-forge/run-lock — a directory nothing reaps.
	// NOT /tmp: a tmp-cleaner can unlink a HELD lock file, after which the next
	// acquirer creates a new inode at the same path and locks it successfully —
	// two lanes each holding "the" lock on different inodes.
	if !strings.HasSuffix(filepath.Dir(ref.Path), filepath.Join("data", "vista-forge", "run-lock")) {
		t.Errorf("default lock home = %q, want ~/data/vista-forge/run-lock", filepath.Dir(ref.Path))
	}
	if filepath.Base(ref.Path) != "ydb.docker.vehu.lock" {
		t.Errorf("lock file = %q, want <key>.lock", filepath.Base(ref.Path))
	}
	if strings.HasPrefix(ref.Path, os.TempDir()) {
		t.Error("the lock home must not be under /tmp — a tmp-cleaner silently breaks mutual exclusion")
	}
}

func TestRunLock_EnvAndBind(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	l := mustAcquire(t, RunLockOptions{Client: cl, Dir: dir})

	env := l.Env()
	if !contains(env, EnvRunLockToken+"="+l.Token) || !contains(env, EnvRunLockKey+"="+l.Key) {
		t.Errorf("Env() = %v, want the token + key for the process subtree", env)
	}

	// Bind wires the bracket into a Client so every driver invocation carries it —
	// one call, so a consumer cannot half-wire itself into a refusal.
	target := NewClient("m-ydb", "ydb", TransportDocker, nil, nil)
	l.Bind(target)
	if target.RunLockToken != l.Token {
		t.Errorf("Bind did not set the token")
	}
	if target.RunLockDir != dir {
		t.Errorf("RunLockDir = %q, want the fixture dir %q", target.RunLockDir, dir)
	}
}

func contains(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}
