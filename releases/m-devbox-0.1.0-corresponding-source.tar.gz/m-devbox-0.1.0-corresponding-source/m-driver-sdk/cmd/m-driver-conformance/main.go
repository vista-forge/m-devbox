// Command m-driver-conformance is the executable contract gate (driver-contract.md
// §9): it drives a driver binary over the subprocess + JSON-envelope seam and
// reports whether the driver conforms. It is engine-agnostic — it exercises only
// what the driver advertises in `meta caps`.
//
//	m-driver-conformance --driver ./dist/m-iris --transport remote
//	m-driver-conformance --driver ./dist/m-ydb  --transport local --json
//
// Connection details are read by the driver from its M_<ENGINE>_* environment,
// inherited here — so set those before running. Exit 0 = conformant, 1 = a check
// failed, 2 = usage.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"strings"

	"github.com/vista-forge/m-driver-sdk/conformance"
)

func main() {
	driver := flag.String("driver", "", "path to the m-<engine> driver binary")
	transport := flag.String("transport", "", "transport to test: local | docker | remote")
	asJSON := flag.Bool("json", false, "emit the report as JSON")
	// S3 — without these, C-RL-7 (the R-9 red-proof) and C-RL-8 could only ever SKIP
	// from the gate that actually runs. A gate that cannot run is not a gate.
	peer := flag.String("peer-transport", "",
		"a SECOND route to the SAME engine instance — enables C-RL-7, the R-9 red-proof "+
			"(e.g. --transport docker --peer-transport remote against foia-t12, which Atelier also publishes on 127.0.0.1:52773). "+
			"Both routes MUST derive a byte-equal runlock-path, or the lock does not serialize the engine against itself.")
	peerArgs := multiFlag{}
	flag.Var(&peerArgs, "peer-arg", "extra connection flag for the peer route (repeatable, e.g. --peer-arg=--container --peer-arg=foia-t12)")
	unresolvable := multiFlag{}
	flag.Var(&unresolvable, "unresolvable-arg",
		"connection flag(s) making the route unresolvable — enables C-RL-8 (e.g. --unresolvable-arg=--base-url --unresolvable-arg=http://127.0.0.1:1/)")
	plant := flag.String("plant-wrong-limit", "",
		"NEGATIVE CONTROL (a gate is proven by firing): rewrite the driver's declared caps.limits.<field> to declared+1 "+
			"HARNESS-SIDE before the suite trusts it, so the C-CAPS-2 live at-limit probe must be OBSERVED RED against the real engine. "+
			"The driver itself never learns to lie. Fields: maxString | evalEnvelope | maxNodeValue | loadBodyBytes. "+
			"Expect exit 1 with exactly that probe FAILed; exit 0 under a plant means the gate is broken.")
	flag.Parse()

	if *driver == "" || *transport == "" {
		fmt.Fprintln(os.Stderr, "usage: m-driver-conformance --driver <path> --transport <local|docker|remote> [--json]\n"+
			"                         [--peer-transport <t> [--peer-arg <flag>]...]   # C-RL-7, the R-9 red-proof\n"+
			"                         [--unresolvable-arg <flag>]...                 # C-RL-8")
		os.Exit(2)
	}

	// The run-lock cases open a REAL bracket in the REAL passwd-derived domain —
	// deliberately (L0.B2). The pre-L0 temp-dir isolation was a self-report: it
	// proved enforcement over a sandbox home nobody serializes on, and since
	// L0.B1 every dir override is refused in a production binary anyway
	// (RUN_LOCK_DIR_FORBIDDEN). The suite brackets the engine under test exactly
	// like a real lane, so a concurrently-held bracket on that engine surfaces as
	// contention (acquire waits up to 30s) — point it at a test engine.
	run := conformance.ExecRunner(*driver, *transport)
	if *plant != "" {
		field := *plant
		if !validPlantField[field] {
			fmt.Fprintf(os.Stderr, "unknown --plant-wrong-limit field %q (want maxString | evalEnvelope | maxNodeValue | loadBodyBytes)\n", field)
			os.Exit(2)
		}
		fmt.Printf("NEGATIVE CONTROL: caps.limits.%s planted at declared+1 — C-CAPS-2 [%s at-limit] must come back RED\n\n", field, field)
		run = plantWrongLimit(run, field)
	}
	rep := conformance.RunWith(context.Background(), run, *transport,
		conformance.Options{
			Driver:           *driver,
			EnvRunner:        conformance.ExecEnvRunner(*driver, *transport),
			PeerTransport:    *peer,
			PeerArgs:         peerArgs,
			UnresolvableArgs: unresolvable,
		})

	if *asJSON {
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		_ = enc.Encode(rep)
	} else {
		printText(rep)
	}
	if rep.Fail > 0 {
		os.Exit(1)
	}
}

var validPlantField = map[string]bool{
	"maxString": true, "evalEnvelope": true, "maxNodeValue": true, "loadBodyBytes": true,
}

// plantWrongLimit wraps a Runner so the driver's `meta caps` answer reaches the
// suite with limits.<field> bumped to declared+1 — the harness-side plant that
// proves the live spot-measurement gate fires against a real engine. Only the
// declaration the suite READS is doctored; every probe still runs against the
// real engine, which is what makes the resulting RED a live proof rather than
// a fixture story.
func plantWrongLimit(run conformance.Runner, field string) conformance.Runner {
	return func(ctx context.Context, args ...string) (conformance.RawResult, error) {
		raw, err := run(ctx, args...)
		if err != nil || len(args) < 2 || args[0] != "meta" || args[1] != "caps" {
			return raw, err
		}
		var envl map[string]json.RawMessage
		if json.Unmarshal(raw.Stdout, &envl) != nil {
			return raw, nil
		}
		var data map[string]json.RawMessage
		if json.Unmarshal(envl["data"], &data) != nil {
			return raw, nil
		}
		var limits map[string]json.RawMessage
		if data["limits"] == nil || json.Unmarshal(data["limits"], &limits) != nil {
			fmt.Fprintln(os.Stderr, "plant-wrong-limit: this connection advertises no caps.limits block — nothing to plant into")
			os.Exit(2)
		}
		var n int
		if json.Unmarshal(limits[field], &n) != nil {
			return raw, nil
		}
		limits[field] = json.RawMessage(fmt.Sprintf("%d", n+1))
		data["limits"], _ = json.Marshal(limits)
		envl["data"], _ = json.Marshal(data)
		raw.Stdout, _ = json.Marshal(envl)
		return raw, nil
	}
}

// multiFlag is a repeatable string flag.
type multiFlag []string

func (m *multiFlag) String() string     { return strings.Join(*m, " ") }
func (m *multiFlag) Set(v string) error { *m = append(*m, v); return nil }

func printText(rep conformance.Report) {
	title := "m-driver-conformance"
	if rep.Engine != "" {
		title += " — " + rep.Engine
	}
	fmt.Printf("%s (transport %s)\n", title, rep.Transport)
	for _, r := range rep.Results {
		// SKIP is rendered as its own mark, never folded into PASS: a case the
		// driver put out of scope was not asserted, and a reader must be able to see
		// exactly how much of the contract this driver actually stood for.
		mark := "PASS"
		switch {
		case r.Skip:
			mark = "SKIP"
		case !r.Pass:
			mark = "FAIL"
		}
		line := fmt.Sprintf("  [%s] %s", mark, r.Name)
		if !r.Pass && r.Detail != "" {
			line += " — " + r.Detail
		}
		fmt.Println(line)
	}
	fmt.Printf("\n%d passed, %d failed, %d skipped\n", rep.Pass, rep.Fail, rep.Skip)
}
