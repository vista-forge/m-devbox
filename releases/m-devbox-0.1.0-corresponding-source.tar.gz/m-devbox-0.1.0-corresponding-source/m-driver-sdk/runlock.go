package mdriver

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/user"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"
)

// The per-engine run-lock (design: m-driver-sdk/docs/design/run-lock.md;
// contract: driver-contract.md §5.8).
//
// No host-side artifact used to say "a run owns this engine right now", so every
// multi-call engine run (N staging chunks + a finalize; census-before → install →
// census-after) raced every other lane, cron, and CI job on the two shared
// engines. This file is the seam that fixes it:
//
//	orchestrator ── AcquireRunLock(key) ─► flock(LOCK_EX) on <dir>/<key>.lock
//	             ── writes the holder record {tokenSHA256, pid, pgid, …}
//	             ── exports M_RUN_LOCK_TOKEN to its process subtree
//	   ├─ driver call 1 (--run-lock <t>) ─► driver: lock HELD ∧ sha256(t)==record → mutate
//	   ├─ nested tool ── JoinRunLock(env) ─► same verification; its Release is a NO-OP
//	   └─ Release()  ── cleanup first, THEN unlock
//
// Three stances, because three different questions are being asked (§2):
//
//	Exclusivity is FAIL-CLOSED.  Liveness is BOUNDED and LOUD.  Breaking is HUMAN.
//
// flock(2) is the only truth of held-ness — the kernel releases it when the
// holder dies, so there is no stale-lock class to reclaim and a crashed holder
// can never deadlock the toolchain. /proc/locks is the measurement of WHO. The
// holder record is narrative only, never evidence of held-ness.
//
// Verification NEVER acquires: the driver's check is a non-blocking probe plus a
// record compare, so an in-bracket call cannot wait on the bracket its own run
// holds. That is the structural reason this design needs no fail-open escape,
// which in turn is what licenses making exclusivity fail-closed (§7).

// Env var names for the bracket. Scope: ephemeral, process-subtree, never
// committed. The token rides argv (--run-lock, the loud channel) or env (the
// fallback that carries a bash-wrapped chain); the explicit flag wins.
const (
	EnvRunLockToken = "M_RUN_LOCK_TOKEN"
	EnvRunLockKey   = "M_RUN_LOCK_KEY"
)

// Refusal codes (§6e). They enter the declared error vocabulary
// (undeclared-seams D-1); a consumer branches on the CODE, never on prose.
const (
	// CodeRunLockRequired — a bracket-requiring verb was called with no token.
	CodeRunLockRequired = "RUN_LOCK_REQUIRED"
	// CodeRunLockMismatch — a token was presented but does not match the live
	// holder's record. This is the fencing refusal: a dead bracket's orphan child
	// still presenting the old token after a new lane has acquired.
	CodeRunLockMismatch = "RUN_LOCK_MISMATCH"
	// CodeRunLockNotHeld — a token was presented but NO bracket is held: the
	// bracket died under its own children.
	CodeRunLockNotHeld = "RUN_LOCK_NOT_HELD"
	// CodeRunLockTimeout — a bounded acquire wait expired (acquire side).
	CodeRunLockTimeout = "RUN_LOCK_TIMEOUT"
	// CodeRunLockHolderStopped — the holder is SIGSTOPped (state T). The wait
	// stops EARLY and returns the mechanized triage instead of burning the
	// timeout. Never an auto-break: the 6 h suspended-writer incident is precisely
	// a lock that LOOKED dead for hours and was not (R-5).
	CodeRunLockHolderStopped = "RUN_LOCK_HOLDER_STOPPED"
	// CodeEngineBusy — the try-mode (Wait == 0) outcome on a held lock. NOT an
	// error condition: the caller proceeds in report-only mode and emits this as a
	// distinct machine-readable outcome naming the holder — never a bare green
	// (R-6; an unobserved gate is not a gate).
	CodeEngineBusy = "SKIPPED_ENGINE_BUSY"
	// CodeRunLockDirForbidden — a lock-home override (driver argv --run-lock-dir,
	// RunLockOptions.Dir, or Client.RunLockDir) was set in a NON-TEST binary. The
	// override decouples the bracket from the real serialization domain — a real
	// run that honors it locks a file no other lane looks at (DS-19) — so outside
	// a `go test` binary it is refused, never honored (hardening L0.B1, Dev-11).
	CodeRunLockDirForbidden = "RUN_LOCK_DIR_FORBIDDEN"
)

// ExitRunLockRefused is the contract exit code every run-lock refusal carries:
// the §2 ladder's EXISTING refusal rung (4 — clikit's ExitRefused, whose own
// definition already reads "conflict / refusal (lock held, …)"). Distinctness
// lives in the CODE, which is the machine-branching key; minting a new integer
// would fall off the contract's exit ladder, force a change in every vendored
// clikit copy, and be missed by m-cli's existing exit-4 handling.
const ExitRunLockRefused = 4

// Holder states reported by runlock-status (§6d).
const (
	HolderUnheld  = "UNHELD"
	HolderRunning = "RUNNING"
	HolderStopped = "STOPPED"
	// HolderOrphanFD — flock says held, but the recorded holder is dead. An
	// inherited FD in a surviving child (e.g. an orphaned `docker exec` client)
	// keeps the lock held after the acquirer died. Named so this is visible rather
	// than mysterious; it is still NOT auto-broken.
	HolderOrphanFD = "HELD_BY_ORPHAN_FD"
)

// DefaultRunLockDirName is the run-lock home under the user's home directory
// (R-4): ~/data/vista-forge/run-lock.
//
// Deliberately NOT /tmp. The sharp reason is not reboots: a tmp-cleaner
// (systemd-tmpfiles) can unlink a lock file WHILE IT IS HELD. flock survives the
// unlink (the FD holds the inode), but the next acquirer open(O_CREATE)s a NEW
// inode at the same path and locks it successfully — two lanes each holding "the"
// lock on different inodes, mutual exclusion silently broken by the filesystem.
// The lock home must be a directory nothing reaps.
var DefaultRunLockDirName = filepath.Join("data", "vista-forge", "run-lock")

// RunLockRef is the `meta runlock-path` payload: the derived key and lock-file
// path for a connection. The DRIVER is the single derivation authority (R-3), so
// bash, m-cli, v-pkg and both drivers cannot disagree about the key for the same
// target — two lanes "locking" different keys for one container is a silent
// failure of mutual exclusion.
type RunLockRef struct {
	Key  string `json:"key"`
	Path string `json:"path"`
}

// RunLockRecord is the holder record written into the lock file (§6b). It is
// NARRATIVE: used for messages and for token verification, never as evidence of
// held-ness (flock is that).
type RunLockRecord struct {
	V   int    `json:"v"`
	Key string `json:"key"`
	// TokenSHA256 is the hex SHA-256 of the run token — the token itself is NEVER
	// written. A joiner gets the token by process inheritance (env), never by
	// reading this file, so a "helpful" script cannot scrape ownership. This is
	// anti-footgun, not authentication (§9: malice is out of the threat model).
	TokenSHA256 string     `json:"tokenSHA256"`
	PID         int        `json:"pid"`
	PGID        int        `json:"pgid"`
	Host        string     `json:"host"`
	User        string     `json:"user,omitempty"`
	Consumer    string     `json:"consumer,omitempty"`
	StartedAt   time.Time  `json:"startedAt"`
	ReleasedAt  *time.Time `json:"releasedAt,omitempty"`
}

// RunLockHolder is one kernel-measured holder of the lock file (from
// /proc/locks) — the answer to "who", taken from the kernel rather than from a
// self-report.
type RunLockHolder struct {
	PID   int    `json:"pid"`
	State string `json:"state,omitempty"` // /proc state letter: R, S, D, T (stopped), Z
	Cmd   string `json:"cmd,omitempty"`
}

// RunLockStatus is the `meta runlock-status` payload: the three trust layers, in
// order — flock (truth of held-ness), /proc/locks (measurement of who), the
// record (narrative).
type RunLockStatus struct {
	Key     string          `json:"key"`
	Path    string          `json:"path"`
	State   string          `json:"state"`
	Holders []RunLockHolder `json:"holders,omitempty"`
	Record  *RunLockRecord  `json:"record,omitempty"`
}

// Held reports whether a bracket is live on this engine.
func (s RunLockStatus) Held() bool { return s.State != HolderUnheld && s.State != "" }

// Describe renders the one-line holder narrative a waiter prints IMMEDIATELY on
// block (R-5) — a wait is never silent.
func (s RunLockStatus) Describe() string {
	if !s.Held() {
		return fmt.Sprintf("run-lock %s: not held", s.Key)
	}
	var b strings.Builder
	fmt.Fprintf(&b, "run-lock %s: held", s.Key)
	if s.Record != nil {
		fmt.Fprintf(&b, " by pid %d", s.Record.PID)
		var bits []string
		if s.Record.Consumer != "" {
			bits = append(bits, s.Record.Consumer)
		}
		if !s.Record.StartedAt.IsZero() {
			bits = append(bits, "since "+s.Record.StartedAt.Format("15:04:05"))
		}
		if st := s.holderState(); st != "" {
			bits = append(bits, "state "+st)
		}
		if len(bits) > 0 {
			fmt.Fprintf(&b, " (%s)", strings.Join(bits, ", "))
		}
	}
	if s.State == HolderOrphanFD {
		b.WriteString(" — the recorded holder is DEAD; an inherited FD in a surviving child still holds the lock")
	}
	return b.String()
}

func (s RunLockStatus) holderState() string {
	for _, h := range s.Holders {
		if h.State != "" {
			return h.State
		}
	}
	return ""
}

// StoppedHolderTriage renders the mechanized triage for a STOPPED holder. This
// is the suspended-engine-writer playbook retired OUT of memory and INTO the
// tool: a 6 h manual incident becomes a first-wait diagnostic. The tool
// diagnoses; the human kills. There is no auto-break, no TTL expiry and no lease
// steal, in v1 or ever — breaking a lock you wrongly believe dead admits a second
// writer, which is strictly worse than waiting (R-5).
func (s RunLockStatus) StoppedHolderTriage() string {
	pgid, pid := 0, 0
	if s.Record != nil {
		pgid, pid = s.Record.PGID, s.Record.PID
	}
	return strings.Join([]string{
		fmt.Sprintf("the run-lock holder (pid %d) is STOPPED — it is not dead, and it will NOT be broken automatically.", pid),
		"Diagnose, then kill by hand:",
		"  1. `v pkg attest verify <ledger>` — zero dangling intents ⇒ it froze pre-mutation and the kill is provably clean;",
		"     a dangling intent ⇒ it froze MID-mutation, and killing leaves a reconcilable crash state (`v pkg adopt` / `v pkg purge`).",
		fmt.Sprintf("  2. `kill -9 -- -%d` — kill the process group WHILE IT IS STOPPED; never SIGCONT/resume it first", pgid),
		"     (a resumed writer runs a stale plan forward against a moved engine).",
		"  3. `docker top <container>` — a host-killed `docker exec` does not kill the container-side process; check for one",
		"     started at the freeze time.",
	}, "\n")
}

// RunLockError is every run-lock refusal and acquire failure. Callers branch on
// Code; drivers map it onto the envelope's error object with Exit.
type RunLockError struct {
	Code   string
	Exit   int
	Key    string
	Path   string
	Msg    string
	Hint   string
	Status *RunLockStatus // the measured holder, when there is one
}

func (e *RunLockError) Error() string {
	msg := e.Code
	if e.Msg != "" {
		msg += ": " + e.Msg
	}
	if e.Status != nil && e.Status.Held() {
		msg += " — " + e.Status.Describe()
	}
	return msg
}

// IsEngineBusy reports the try-mode outcome: the engine is held by another lane,
// so a non-waiting caller (G-LEAK-SCAN's cron) must record SKIPPED_ENGINE_BUSY
// naming the holder — never a bare green, and never a red.
func IsEngineBusy(err error) bool {
	var rl *RunLockError
	return errors.As(err, &rl) && rl.Code == CodeEngineBusy
}

// RunLockOptions selects the engine instance and the acquire behavior (§6a).
type RunLockOptions struct {
	// Client is the driver to derive key/path through (its runlock-path verb is
	// the single derivation authority). Required.
	Client *Client
	// Wait bounds the acquire. 0 = a single non-blocking try (R-6 report-only
	// mode). The SHAPE is contract — always bounded, always loud, always
	// overridable. The NUMBERS (30 s interactive / 10 min batch / cron try-only)
	// are consumer defaults and belong to m-cli and v-pkg, not here (decision #3).
	Wait time.Duration
	// Consumer is narrative for the holder record: "m test",
	// "v pkg install VSL.kids", …
	Consumer string
	// Dir overrides the lock home. TESTS AND FIXTURES ONLY: it decouples the
	// bracket from the real serialization domain, so a real run that sets it is
	// locking a file no other lane looks at.
	Dir string
	// OnWait fires with the measured holder as soon as the acquire blocks, and on
	// each subsequent sample. The SDK is a library and does not print; this is how
	// a wait is made loud immediately rather than silent (R-5).
	OnWait func(RunLockStatus)

	// poll is the liveness-sampling interval while waiting (test hook).
	poll time.Duration
}

const defaultRunLockPoll = 250 * time.Millisecond

// RunLock is a held (or joined) per-engine run bracket.
type RunLock struct {
	Key   string
	Path  string
	Token string

	owned    bool
	released bool
	dir      string   // the requested override ("" = the default home)
	f        *os.File // nil for a joined handle: a joiner holds no FD and no lock
}

// Owned reports whether this handle ACQUIRED the bracket. Only the acquiring
// process releases; a joined handle's Release is a no-op (§R-2's reentrancy
// rule).
func (l *RunLock) Owned() bool { return l != nil && l.owned }

// Env returns the bracket's environment for child processes — the token rides the
// process subtree, so a nested sanctioned tool can JoinRunLock instead of
// deadlocking on a second acquire (defeat (d)).
func (l *RunLock) Env() []string {
	return []string{EnvRunLockToken + "=" + l.Token, EnvRunLockKey + "=" + l.Key}
}

// Bind wires this bracket into a Client, so every subsequent driver invocation
// carries --run-lock (and --run-lock-dir when overridden) and the driver's
// dispatch check sees the same bracket this handle holds. One call, so a consumer
// cannot half-wire itself into a refusal.
func (l *RunLock) Bind(c *Client) {
	c.RunLockToken = l.Token
	c.RunLockDir = l.dir
}

// Release ends the bracket. It is idempotent, and a NO-OP on a joined handle —
// only the acquirer releases. A joined Release that actually released would hand
// the engine to another lane in the middle of the outer run.
//
// Callers must run cleanup (unstage, close sessions) BEFORE Release: state is
// restored before exclusivity is surrendered (§R-7). Note that release does NOT
// imply clean state — the lock asserts exclusivity, the census asserts state;
// keep the two claims separate.
func (l *RunLock) Release() error {
	if l == nil || !l.owned || l.released {
		return nil
	}
	l.released = true
	defer func() {
		_ = l.f.Close()
		l.f = nil
	}()

	// The releasedAt stamp is best-effort narrative; a failure to write it must
	// never keep the lock held.
	if rec, err := readRunLockRecord(l.Path); err == nil && rec != nil {
		now := time.Now()
		rec.ReleasedAt = &now
		_ = writeRunLockRecord(l.f, rec)
	}
	return flockUnlock(l.f)
}

// AcquireRunLock opens a run bracket on the engine the Client points at.
//
// It is the ONLY blocking wait in the design, and it holds nothing while it waits
// (acquire is the first act of a bracket) — which is why a maximal timeout parks
// one lane without transitively blocking anything (§7.4).
func AcquireRunLock(ctx context.Context, o RunLockOptions) (*RunLock, error) {
	ref, err := resolveRef(ctx, o)
	if err != nil {
		return nil, err
	}

	f, err := openLockFile(ref.Path)
	if err != nil {
		return nil, err
	}
	ok, err := flockTry(f)
	if err != nil {
		_ = f.Close()
		// Exclusivity is fail-closed: the lock infrastructure is mkdir + open +
		// flock on a local disk. If THAT fails the box is broken, and mutating a
		// shared engine blind is the worst available action.
		return nil, fmt.Errorf("run-lock %s: cannot lock %s: %w", ref.Key, ref.Path, err)
	}
	if !ok {
		if o.Wait <= 0 {
			// Try-mode (R-6): report the measured holder and let the caller proceed
			// in report-only mode.
			st := probeHeld(ref)
			_ = f.Close()
			return nil, &RunLockError{
				Code: CodeEngineBusy, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
				Msg:    "engine is held by another run — skipped, not scanned",
				Status: &st,
			}
		}
		if err := waitForLock(ctx, f, ref, o); err != nil {
			_ = f.Close()
			return nil, err
		}
	}

	l := &RunLock{Key: ref.Key, Path: ref.Path, Token: newRunToken(), owned: true, dir: o.Dir, f: f}
	if err := writeRunLockRecord(f, newRecord(ref.Key, l.Token, o.Consumer)); err != nil {
		_ = flockUnlock(f)
		_ = f.Close()
		return nil, fmt.Errorf("run-lock %s: write holder record: %w", ref.Key, err)
	}
	return l, nil
}

// waitForLock polls for the lock, bounded by o.Wait and by ctx, sampling the
// holder's liveness as it goes. Polling (rather than a blocking flock) is what
// makes the wait interruptible, bounded, and able to bail out EARLY on a stopped
// holder instead of burning the whole timeout.
func waitForLock(ctx context.Context, f *os.File, ref RunLockRef, o RunLockOptions) error {
	poll := o.poll
	if poll <= 0 {
		poll = defaultRunLockPoll
	}
	deadline := time.Now().Add(o.Wait)

	st := probeHeld(ref)
	if o.OnWait != nil {
		o.OnWait(st) // loud immediately, on the first block
	}
	if err := stoppedHolder(ref, st); err != nil {
		return err
	}

	t := time.NewTicker(poll)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
		}

		ok, err := flockTry(f)
		if err != nil {
			return fmt.Errorf("run-lock %s: cannot lock %s: %w", ref.Key, ref.Path, err)
		}
		if ok {
			return nil
		}

		st = probeHeld(ref)
		if o.OnWait != nil {
			o.OnWait(st)
		}
		if err := stoppedHolder(ref, st); err != nil {
			return err
		}
		if time.Now().After(deadline) {
			return &RunLockError{
				Code: CodeRunLockTimeout, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
				Msg:    fmt.Sprintf("timed out after %s waiting for the run-lock", o.Wait),
				Hint:   "the holder is running but slow; raise --lock-wait, or diagnose it with `m runlock status`",
				Status: &st,
			}
		}
	}
}

// stoppedHolder turns a SIGSTOPped holder into an early, mechanized failure
// rather than a silent multi-hour wait.
func stoppedHolder(ref RunLockRef, st RunLockStatus) error {
	if st.State != HolderStopped {
		return nil
	}
	return &RunLockError{
		Code: CodeRunLockHolderStopped, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
		Msg:    "the run-lock holder is STOPPED (state T) — waiting for it is pointless, and it will not be broken automatically",
		Hint:   st.StoppedHolderTriage(),
		Status: &st,
	}
}

// JoinRunLock verifies the AMBIENT bracket (M_RUN_LOCK_TOKEN, inherited from the
// process subtree) against the live record and returns a NON-OWNING handle.
//
// This is the nested case (m test → v pkg install → driver call, defeat (d)): the
// inner layer verifies, it does not lock. No second acquire means no self-wait.
func JoinRunLock(ctx context.Context, o RunLockOptions) (*RunLock, error) {
	ref, err := resolveRef(ctx, o)
	if err != nil {
		return nil, err
	}
	token := os.Getenv(EnvRunLockToken)
	if token == "" {
		return nil, &RunLockError{
			Code: CodeRunLockRequired, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:  "no ambient run-lock bracket (" + EnvRunLockToken + " is unset)",
			Hint: "wrap the run in `m runlock hold` or call AcquireRunLock",
		}
	}
	// An ambient bracket for a DIFFERENT engine is not a join. Without this, a
	// nested tool targeting foia under a vehu bracket would fail the SHA compare
	// and report a confusing MISMATCH, when the truth is that its target engine is
	// unbracketed — and it must acquire, not join.
	if ambient := os.Getenv(EnvRunLockKey); ambient != "" && ambient != ref.Key {
		return nil, &RunLockError{
			Code: CodeRunLockNotHeld, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:  fmt.Sprintf("the ambient bracket is for key %q, but this target is %q — a different engine instance", ambient, ref.Key),
			Hint: "acquire a separate bracket for this engine (brackets are per-instance; hold one engine at a time)",
		}
	}
	if err := VerifyRunLock(ref, token); err != nil {
		return nil, err
	}
	return &RunLock{Key: ref.Key, Path: ref.Path, Token: token, owned: false, dir: o.Dir}, nil
}

// JoinOrAcquireRunLock is the sanctioned consumer's auto-bracket: join the
// ambient bracket when there is a valid one for this target, else acquire one for
// the span of the command. It lives here, not in each consumer, so m-cli and v-pkg
// cannot drift on the reentrancy rule — the one rule that keeps the nested case
// from self-deadlocking.
func JoinOrAcquireRunLock(ctx context.Context, o RunLockOptions) (*RunLock, error) {
	if os.Getenv(EnvRunLockToken) != "" {
		l, err := JoinRunLock(ctx, o)
		if err == nil {
			return l, nil
		}
		// A token for ANOTHER engine's bracket is not an error — this target is
		// simply unbracketed, so acquire. Any other refusal (a forged or stale
		// token for THIS key) is a real failure and must stay loud.
		var rl *RunLockError
		if !errors.As(err, &rl) || rl.Code != CodeRunLockNotHeld {
			return nil, err
		}
	}
	return AcquireRunLock(ctx, o)
}

// --- the driver-side dispatch primitives -------------------------------------

// RequireRunLock is the enforcement decision, and it lives here so that both
// drivers make it identically: a class that needs a bracket must prove one; a
// status or control verb runs unconditionally.
//
// A driver's dispatch middleware is exactly: look the verb up in the registry
// (ClassOf), call this, and render a refusal onto the envelope. The middleware is
// the choke point — a hurried developer can evade a convention, but not the
// dispatch path they call through.
func RequireRunLock(class VerbClass, ref RunLockRef, token string) error {
	if !class.RequiresRunLock() {
		return nil
	}
	return VerifyRunLock(ref, token)
}

// VerifyRunLock is the ownership check a driver runs at call entry (§R-2). It is
// one non-blocking syscall plus one small read — negligible against a docker exec
// or Atelier round trip — and it NEVER blocks: the driver never waits on the
// lock, so a driver call cannot deadlock on it. Waiting happens only in the
// orchestrator's acquire.
func VerifyRunLock(ref RunLockRef, token string) error {
	st, err := ProbeRunLock(ref)
	if err != nil {
		// Fail-closed: if we cannot even probe, we do not mutate a shared engine.
		return &RunLockError{
			Code: CodeRunLockRequired, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg: "cannot probe the run-lock: " + err.Error(),
		}
	}

	if !st.Held() {
		// Nobody holds a bracket. No token ⇒ the caller simply forgot one. A token
		// ⇒ its bracket died under it (the holder was killed while this child was
		// in flight).
		if token == "" {
			return &RunLockError{
				Code: CodeRunLockRequired, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
				Msg:    "this verb mutates or reads engine state and no run-lock bracket is held",
				Hint:   "wrap the run: `m runlock hold --engine <e> [--docker <c>] -- <cmd>`",
				Status: &st,
			}
		}
		return &RunLockError{
			Code: CodeRunLockNotHeld, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:    "a run-lock token was presented but no bracket is held — the bracket died under its own children",
			Status: &st,
		}
	}

	if token == "" {
		return &RunLockError{
			Code: CodeRunLockRequired, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:    "this verb mutates or reads engine state and no run-lock token was presented, but another run holds the engine",
			Status: &st,
		}
	}

	// The bracket is held but its record is unreadable — the microsecond window
	// between flock and the record write, or a corrupted file. We cannot PROVE
	// ownership, so we refuse: exclusivity is fail-closed.
	if st.Record == nil {
		return &RunLockError{
			Code: CodeRunLockMismatch, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:    "the run-lock is held but its holder record is unreadable — ownership cannot be proven",
			Status: &st,
		}
	}
	if st.Record.TokenSHA256 != hashToken(token) {
		// FENCING (§6b): the holder died, a new lane acquired and overwrote the
		// record with its own tokenSHA — so a surviving orphan child of the dead
		// bracket, still presenting the old token, now fails this compare. That is
		// kernel-anchored fencing of zombie writers, and it is why this is a
		// contract guarantee with a test rather than a comment.
		return &RunLockError{
			Code: CodeRunLockMismatch, Exit: ExitRunLockRefused, Key: ref.Key, Path: ref.Path,
			Msg:    "the presented run-lock token does not match the live bracket — it belongs to a bracket that no longer holds this engine",
			Status: &st,
		}
	}
	return nil // owner-reentrant: proceed.
}

// ProbeRunLock measures the lock WITHOUT acquiring it: a single LOCK_EX|LOCK_NB
// attempt (released immediately if it succeeds), then /proc/locks for who, then
// the record for narrative. The probe never keeps what it takes — if it did, the
// first in-bracket driver call would lock the engine against its own holder.
func ProbeRunLock(ref RunLockRef) (RunLockStatus, error) {
	f, err := os.OpenFile(ref.Path, os.O_RDONLY, 0o600)
	if errors.Is(err, os.ErrNotExist) {
		// No lock file at all: nobody has ever bracketed this engine.
		return RunLockStatus{Key: ref.Key, Path: ref.Path, State: HolderUnheld}, nil
	}
	if err != nil {
		return RunLockStatus{}, err
	}
	defer func() { _ = f.Close() }()

	ok, err := flockTry(f)
	if err != nil {
		return RunLockStatus{}, err
	}
	if ok {
		// We took it, so nobody held it. Give it straight back — this is a probe.
		if err := flockUnlock(f); err != nil {
			return RunLockStatus{}, err
		}
		return RunLockStatus{Key: ref.Key, Path: ref.Path, State: HolderUnheld}, nil
	}
	return probeHeld(ref), nil
}

// probeHeld builds the status of a lock already known to be held.
func probeHeld(ref RunLockRef) RunLockStatus {
	st := RunLockStatus{Key: ref.Key, Path: ref.Path, State: HolderRunning}
	if rec, err := readRunLockRecord(ref.Path); err == nil {
		st.Record = rec
	}
	st.Holders = lockHolders(ref.Path)

	// Layer 2 (the kernel's answer) outranks layer 3 (the record's self-report).
	for _, h := range st.Holders {
		if h.State == "T" {
			st.State = HolderStopped
			return st
		}
	}
	// Held, but the process that WROTE the record is gone: an inherited FD in a
	// surviving child is keeping the lock alive. Name it, so it is visible rather
	// than mysterious.
	if st.Record != nil && st.Record.PID > 0 && !pidAlive(st.Record.PID) {
		st.State = HolderOrphanFD
	}
	return st
}

// --- key/path derivation ------------------------------------------------------

// runLockKeyClean keeps a key safe as a lock-file basename (the same rule as the
// m-iris sesslock's lockKeyClean).
var runLockKeyClean = regexp.MustCompile(`[^A-Za-z0-9_.-]+`)

// RunLockKey(engine, transport, selector) is GONE as of v0.8.0 — see Locus.Key in
// locus.go (design §R-9).
//
// It keyed on the connection SELECTOR, which names a ROUTE — and routes alias, both
// across transports and within one, so a selector-spelled key can never be
// collision-free against itself. `Locus.Key` replaces it: the key names the PLACE.
//
// The replacement deliberately takes a DIFFERENT SHAPE (a Locus, not a
// transport+selector pair) so that a stale caller fails to COMPILE rather than
// silently deriving a legacy, route-spelled key. That loud break is free exactly once
// — now — because no driver has implemented `runlock-path` yet. After the spikes land
// it would have been a silent semantic break at the version seam, which is R-9's own
// defect, self-inflicted (§R-9.9).
//
// Granularity is unchanged: the whole INSTANCE, never the namespace. IRIS namespaces
// share the license pool, %SYS, and mapped component globals, so a USER-staged run and
// a VISTA install are not independent. Coarse costs a wait; fine risks a lie.

// HashSelector is the selector for a target identified by a filesystem interior
// (m-ydb local: the realpath of the derived global directory) — a short digest,
// so the interior never appears in a lock-file name.
func HashSelector(s string) string {
	sum := sha256.Sum256([]byte(s))
	return hex.EncodeToString(sum[:])[:12]
}

// currentUser is DefaultRunLockDir's passwd lookup. A var only so the
// fail-closed branch is testable; production code never touches it.
var currentUser = user.Current

// DefaultRunLockDir is the run-lock home (R-4). See DefaultRunLockDirName for why
// it is not /tmp.
//
// It derives from passwd (user.Current().HomeDir), NEVER the $HOME env: $HOME is
// an unmeasured ambient input, and two processes with divergent $HOMEs would
// derive two lock files for one engine — two lanes each "holding" the bracket
// while mutating the same instance (the measured D9/EXP-1 defeat). passwd is
// byte-identical however the environment is dressed (DS-1). On a passwd-lookup
// failure it fails CLOSED: no fallback, because falling back to $HOME would
// reopen D9 on exactly the hosts where passwd is broken.
func DefaultRunLockDir() (string, error) {
	u, err := currentUser()
	if err != nil {
		return "", fmt.Errorf("run-lock: passwd lookup for the lock home failed (no $HOME fallback — a divergent env would split the serialization domain): %w", err)
	}
	if u.HomeDir == "" {
		return "", errors.New("run-lock: the passwd entry has no home directory — refusing to derive a lock home (no $HOME fallback)")
	}
	return filepath.Join(u.HomeDir, DefaultRunLockDirName), nil
}

// inTestBinary reports whether this process is a `go test` binary — the real
// test-vs-production signal the dir-override gate keys on (Dev-11). A var only
// so the gate's own tests can simulate a production binary.
var inTestBinary = testing.Testing

// refuseDirOverride is the production gate on the lock-home override (DS-19,
// Dev-11). The override exists for tests and fixtures ONLY — it decouples the
// bracket from the real serialization domain, so a non-test binary that sets it
// is locking a file no other lane looks at. All three entry points (driver argv
// --run-lock-dir via DeriveRunLockRef, RunLockOptions.Dir via resolveRef,
// Client.RunLockDir via call) funnel through this check.
func refuseDirOverride(entry, dir string) error {
	if dir == "" || inTestBinary() {
		return nil
	}
	return &RunLockError{
		Code: CodeRunLockDirForbidden,
		Exit: ExitRunLockRefused,
		Msg:  entry + " overrides the run-lock home in a non-test binary",
		Hint: "the override is for tests/fixtures only — production always uses the passwd-derived home; unset it",
	}
}

// DeriveRunLockRef composes the lock ref for a key. dir is the tests-only
// override; empty means the default home. This is the ONE implementation of
// key→path, which each driver calls to answer `meta runlock-path` — so no two
// lanes can compose different paths for the same engine. It is also where the
// driver argv --run-lock-dir lands, so the production gate fires here inside
// the driver process itself.
func DeriveRunLockRef(dir, key string) (RunLockRef, error) {
	if err := refuseDirOverride("--run-lock-dir", dir); err != nil {
		return RunLockRef{}, err
	}
	if dir == "" {
		d, err := DefaultRunLockDir()
		if err != nil {
			return RunLockRef{}, err
		}
		dir = d
	}
	return RunLockRef{Key: key, Path: filepath.Join(dir, key+".lock")}, nil
}

// resolveRef asks the DRIVER for the key and path — it is the single derivation
// authority (R-3), and `meta runlock-path` is a control-class verb precisely so
// this call can be made before any bracket exists (§7.3).
func resolveRef(ctx context.Context, o RunLockOptions) (RunLockRef, error) {
	if err := refuseDirOverride("RunLockOptions.Dir", o.Dir); err != nil {
		return RunLockRef{}, err
	}
	if o.Client == nil {
		return RunLockRef{}, errors.New("run-lock: no Client — the driver is the key/path derivation authority")
	}
	ref, err := o.Client.RunLockPath(ctx, o.Dir)
	if err != nil {
		return RunLockRef{}, err
	}
	if ref.Key == "" || ref.Path == "" {
		return RunLockRef{}, fmt.Errorf("run-lock: driver %s returned an empty runlock-path (%+v)", o.Client.Engine, ref)
	}
	return ref, nil
}

// --- lock file + record I/O ---------------------------------------------------

func openLockFile(path string) (*os.File, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, fmt.Errorf("run-lock: create lock home: %w", err)
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return nil, fmt.Errorf("run-lock: open %s: %w", path, err)
	}
	return f, nil
}

// newRunToken mints the run-scoped fencing token. It is random, never derived
// from anything guessable: a fabricated token fails the SHA compare, and the
// token is not scrapable from the record.
func newRunToken() string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		// crypto/rand on Linux does not fail; if it somehow did, a predictable
		// token would silently weaken fencing, so refuse to mint one.
		panic("run-lock: crypto/rand failed: " + err.Error())
	}
	return hex.EncodeToString(b)
}

func hashToken(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}

func newRecord(key, token, consumer string) *RunLockRecord {
	host, _ := os.Hostname()
	rec := &RunLockRecord{
		V: 1, Key: key, TokenSHA256: hashToken(token),
		PID: os.Getpid(), PGID: processGroup(), Host: host,
		Consumer: consumer, StartedAt: time.Now(),
	}
	if u, err := user.Current(); err == nil {
		rec.User = u.Username
	}
	return rec
}

// readRunLockRecord reads the holder record. An absent, empty or malformed record
// yields (nil, nil): the record is narrative, so its absence is not an error —
// but it IS a refusal, because ownership then cannot be proven (see
// VerifyRunLock's fail-closed branch).
func readRunLockRecord(path string) (*RunLockRecord, error) {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if len(strings.TrimSpace(string(b))) == 0 {
		return nil, nil
	}
	var rec RunLockRecord
	if err := json.Unmarshal(b, &rec); err != nil {
		return nil, nil
	}
	return &rec, nil
}

// writeRunLockRecord truncates and rewrites the record through the FD that HOLDS
// the lock — the record is only ever written by the holder, and only after flock
// has been won.
func writeRunLockRecord(f *os.File, rec *RunLockRecord) error {
	b, err := json.Marshal(rec)
	if err != nil {
		return err
	}
	if err := f.Truncate(0); err != nil {
		return err
	}
	if _, err := f.Seek(0, io.SeekStart); err != nil {
		return err
	}
	if _, err := f.Write(append(b, '\n')); err != nil {
		return err
	}
	return f.Sync()
}
