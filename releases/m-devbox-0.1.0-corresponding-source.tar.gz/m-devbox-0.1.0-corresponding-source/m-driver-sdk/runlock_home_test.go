package mdriver

import (
	"context"
	"errors"
	"os"
	"os/user"
	"path/filepath"
	"testing"
)

// L0.B1 (runlock-stack-hardening): the lock home IS the serialization domain.
// EXP-1/D9 measured the defeat: two $HOMEs → two lock files → two lanes
// concurrently mutating one engine. These tests pin the fix: the home derives
// from passwd, is byte-identical under any $HOME, and fails CLOSED when passwd
// cannot answer.

// TestDefaultRunLockDir_HomeImmune is the standing immunity control (DS-1):
// the derived lock home must be byte-identical for HOME ∈ {real, hostile,
// unset}, and equal to the passwd-derived home. Reverting DefaultRunLockDir to
// os.UserHomeDir() reds this test (the hostile case diverges, the unset case
// errors).
func TestDefaultRunLockDir_HomeImmune(t *testing.T) {
	u, err := user.Current()
	if err != nil {
		t.Fatalf("user.Current: %v", err)
	}
	want := filepath.Join(u.HomeDir, DefaultRunLockDirName)

	cases := []struct {
		name  string
		home  string
		unset bool
	}{
		{name: "real", home: os.Getenv("HOME")},
		{name: "hostile", home: "/tmp/hostile-home"},
		{name: "unset", unset: true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			t.Setenv("HOME", c.home) // registers the restore even for unset
			if c.unset {
				os.Unsetenv("HOME")
			}
			got, err := DefaultRunLockDir()
			if err != nil {
				t.Fatalf("DefaultRunLockDir with HOME=%q: %v", c.home, err)
			}
			if got != want {
				t.Errorf("DefaultRunLockDir with HOME=%q = %q, want passwd-derived %q — a $HOME-swayed lock home splits the serialization domain (D9)",
					c.home, got, want)
			}
		})
	}
}

// TestDefaultRunLockDir_FailsClosedOnPasswdFailure: when passwd cannot answer,
// the derivation ERRORS — it never falls back to $HOME (that fallback would be
// D9 reborn on exactly the machines where passwd is broken).
func TestDefaultRunLockDir_FailsClosedOnPasswdFailure(t *testing.T) {
	t.Setenv("HOME", "/tmp/hostile-home")
	orig := currentUser
	t.Cleanup(func() { currentUser = orig })

	currentUser = func() (*user.User, error) { return nil, errors.New("passwd unavailable") }
	if dir, err := DefaultRunLockDir(); err == nil {
		t.Errorf("DefaultRunLockDir = %q on passwd failure, want an error — never a $HOME fallback", dir)
	}

	currentUser = func() (*user.User, error) { return &user.User{Username: "ghost"}, nil }
	if dir, err := DefaultRunLockDir(); err == nil {
		t.Errorf("DefaultRunLockDir = %q on an empty passwd HomeDir, want an error — never a $HOME fallback", dir)
	}
}

// --- the dir-override production gate (DS-19, Dev-11) --------------------------
//
// The lock-home override has three silently-honored entry points: driver argv
// --run-lock-dir (which lands in DeriveRunLockRef), RunLockOptions.Dir, and
// Client.RunLockDir. Each decouples the bracket from the real serialization
// domain, so in a NON-TEST binary all three are refused. The gate keys on
// testing.Testing() via the inTestBinary seam; these tests flip the seam to
// exercise the production branch from inside a test binary.

// asProductionBinary makes the gate see a non-test binary for this test.
func asProductionBinary(t *testing.T) {
	t.Helper()
	orig := inTestBinary
	inTestBinary = func() bool { return false }
	t.Cleanup(func() { inTestBinary = orig })
}

func assertDirForbidden(t *testing.T, err error) {
	t.Helper()
	if err == nil {
		t.Fatal("the dir override was honored in a (simulated) production binary, want a refusal — an honored override locks a file no other lane looks at (DS-19)")
	}
	var rl *RunLockError
	if !errors.As(err, &rl) {
		t.Fatalf("refusal error = %T (%v), want *RunLockError", err, err)
	}
	if rl.Code != CodeRunLockDirForbidden {
		t.Errorf("refusal code = %q, want %q", rl.Code, CodeRunLockDirForbidden)
	}
	if rl.Exit != ExitRunLockRefused {
		t.Errorf("refusal exit = %d, want %d", rl.Exit, ExitRunLockRefused)
	}
}

// Entry point 1 — driver argv --run-lock-dir funnels into DeriveRunLockRef
// (m-ydb runlock.go: DeriveRunLockRef(conn.RunLockDir, …)), so the SDK-side
// gate here is what refuses the flag inside a production driver binary.
func TestDeriveRunLockRef_DirOverrideRefusedInProduction(t *testing.T) {
	asProductionBinary(t)
	_, err := DeriveRunLockRef("/tmp/fixture-lock-home", "ydb.docker.vehu")
	assertDirForbidden(t, err)
}

// Entry point 2 — RunLockOptions.Dir, on every bracket path (acquire and join).
func TestAcquireRunLock_OptionsDirRefusedInProduction(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	asProductionBinary(t)
	_, err := AcquireRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	assertDirForbidden(t, err)
}

func TestJoinRunLock_OptionsDirRefusedInProduction(t *testing.T) {
	dir := t.TempDir()
	cl := lockClient(t, dir, "ydb.docker.vehu")
	asProductionBinary(t)
	_, err := JoinRunLock(context.Background(), RunLockOptions{Client: cl, Dir: dir})
	assertDirForbidden(t, err)
}

// Entry point 3 — Client.RunLockDir, which otherwise rides EVERY invocation
// (client.go appends --run-lock-dir to each call). The refusal must fire
// before the driver is invoked: the flag never reaches argv.
func TestClient_RunLockDirRefusedInProduction(t *testing.T) {
	invoked := false
	c := NewClient("m-ydb", "ydb", TransportDocker, nil,
		func(_ context.Context, _ string, _ []string) ([]byte, []byte, int, error) {
			invoked = true
			return []byte(`{"schemaVersion":"1.0","command":"lifecycle status","ok":true,"exit":0}`), nil, 0, nil
		})
	c.RunLockDir = "/tmp/fixture-lock-home"
	asProductionBinary(t)
	_, err := c.Status(context.Background())
	assertDirForbidden(t, err)
	if invoked {
		t.Error("the driver was invoked despite the refused override — the flag must never reach argv")
	}
}

// The positive half of the gate: a real test binary (this one, seam untouched)
// still gets the override — every suite fixture in the SDK and the drivers
// depends on it.
func TestDeriveRunLockRef_DirOverrideHonoredInTestBinary(t *testing.T) {
	ref, err := DeriveRunLockRef("/tmp/fixture-lock-home", "ydb.docker.vehu")
	if err != nil {
		t.Fatalf("DeriveRunLockRef in a test binary: %v", err)
	}
	if ref.Path != filepath.Join("/tmp/fixture-lock-home", "ydb.docker.vehu.lock") {
		t.Errorf("ref.Path = %q, want the fixture-dir path", ref.Path)
	}
}
