package conformance

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// The run-lock conformance cases (contract §5.8, run-lock design §6e) — the
// red-proofs that a driver actually REFUSES an unbracketed mutation instead of
// silently performing it.
//
// They are CAPABILITY-GATED on features.runLock, and that gating is the whole
// trick. These cases assert behavior no driver implements until P0.3; wired
// unconditionally they would red-gate the SDK and both drivers from the moment
// they landed until every driver caught up — a self-inflicted broken gate sitting
// on the org's critical path. Gated, the suite is green today and turns hard the
// instant a driver claims the capability: the bit becomes the driver's own
// promise, and conformance holds it to it.
//
// Two rules keep that from becoming an excuse:
//
//   - a skip is VISIBLY a skip, never a pass (P-B: an unobserved gate is not a
//     gate) — the suite counts and prints them separately;
//   - a skip must be a decision the DRIVER made. If the bit is advertised and the
//     suite has no way to bracket, that is a broken gate and it is RED.

const (
	cRL1 = "C-RL-1 mutate with no token → RUN_LOCK_REQUIRED"
	cRL2 = "C-RL-2 mutate with a valid token + held lock → proceeds"
	cRL3 = "C-RL-3 token presented, lock free → RUN_LOCK_NOT_HELD"
	cRL4 = "C-RL-4 token presented, lock held by another record → RUN_LOCK_MISMATCH (fencing)"
	cRL5 = "C-RL-5 status/control verbs run with no token"
	cRL6 = "C-RL-6 try-mode on a held lock → busy outcome, no side effects"
	cRL7 = "C-RL-7 two routes to one instance → BYTE-EQUAL runlock-path (the R-9 red-proof)"
	cRL8 = "C-RL-8 unresolvable route → RUN_LOCK_UNRESOLVED, never a selector-spelled key"
	cRL9 = "C-RL-9 hostile $HOME → SAME lock ref, refusal fences on the REAL record (the D9 red-proof)"
)

var runLockCases = []string{cRL1, cRL2, cRL3, cRL4, cRL5, cRL6, cRL7, cRL8, cRL9}

func (s *suite) checkRunLock(ctx context.Context, o Options) {
	if !s.caps.Features.RunLock {
		for _, name := range runLockCases {
			s.skip(name, "driver does not advertise features.runLock — it does not enforce the run-lock, so there is nothing to hold it to")
		}
		return
	}

	// The bit is advertised. From here every path is pass-or-fail: a driver that
	// promises enforcement gets held to all six, and a suite that cannot check is
	// itself the finding.
	client := o.newClient
	if client == nil {
		if o.Driver == "" {
			s.fail("run-lock: suite wiring",
				"the driver advertises features.runLock but the suite was given no --driver path, so it cannot open a bracket to test against — the run-lock cases did not run")
			return
		}
		client = func(engine string) *mdriver.Client {
			return mdriver.NewClient(o.Driver, engine, s.transport, nil, nil)
		}
	}
	cl := client(s.caps.Engine)
	cl.RunLockDir = o.LockDir

	// The mutating verb the refusals are proven against. `exec eval` of a local SET
	// is the least harmful mutation in the contract: if the driver wrongly PROCEEDS
	// (the very bug being hunted) it has assigned a local variable and nothing else.
	if !has(s.caps.Axes.Exec, "eval") {
		s.fail("run-lock: suite wiring",
			"the driver advertises features.runLock but no `exec eval` to exercise the refusal against")
		return
	}
	mutate := func(token string) []string {
		args := []string{"exec", "eval", "set x=1"}
		if o.LockDir != "" {
			args = append(args, "--run-lock-dir", o.LockDir)
		}
		if token != "" {
			args = append(args, "--run-lock", token)
		}
		return args
	}

	// --- with NO bracket held ---------------------------------------------------

	// C-RL-1: the design's core trade — the corruption class becomes an
	// error-message class. A lane that forgot the bracket is REFUSED, not served.
	s.refusal(ctx, cRL1, mdriver.CodeRunLockRequired, mutate("")...)

	// C-RL-3: a token, but no bracket — the holder died under its own children.
	s.refusal(ctx, cRL3, mdriver.CodeRunLockNotHeld, mutate("a-token-from-a-dead-bracket")...)

	// --- open a real bracket ----------------------------------------------------

	lock, err := mdriver.AcquireRunLock(ctx, mdriver.RunLockOptions{
		Client: cl, Dir: o.LockDir, Wait: 30 * time.Second,
		Consumer: "m-driver-conformance",
	})
	if err != nil {
		s.fail("run-lock: acquire", fmt.Sprintf("the suite could not open a bracket through the driver's runlock-path: %v", err))
		return
	}
	defer func() { _ = lock.Release() }()

	// C-RL-2: the owner is reentrant — every call inside its own bracket proceeds,
	// with no wait. If this failed, the lock would deadlock every real run.
	if env := s.call(ctx, cRL2, mutate(lock.Token)...); env != nil {
		s.report0(cRL2, env.OK,
			fmt.Sprintf("the bracket holder was refused its own bracket (exit %d, code %s)", env.Exit, code(env)))
	}

	// C-RL-4: FENCING. A surviving orphan of a dead bracket presents its old token
	// while a new lane holds the engine — the record compare fails, so the zombie
	// writer is refused. Kernel-anchored, and a contract guarantee, so it is tested
	// rather than asserted in a comment.
	s.refusal(ctx, cRL4, mdriver.CodeRunLockMismatch, mutate("the-dead-brackets-token")...)

	// C-RL-9: THE D9 RED-PROOF (L0.B2). The lock home must derive from passwd,
	// never from $HOME — two processes with divergent $HOMEs deriving two lock
	// files for one engine is the measured EXP-1 defeat. Proven live, not read
	// from code: the same driver call, dressed in a hostile $HOME, must
	//   (a) re-derive the BYTE-EQUAL ref the suite's bracket holds, and
	//   (b) fence a wrong token with RUN_LOCK_MISMATCH — proof the refusal
	//       compared against the REAL held record. A pre-L0 driver answers a
	//       different path for (a) and RUN_LOCK_NOT_HELD for (b): its hostile-env
	//       lane is holding a lock file nobody else looks at.
	s.checkHostileHome(ctx, lock)

	// C-RL-5: the declared escape hatch. Even WITH a bracket held by someone else
	// and no token in hand, status and control verbs must run — otherwise a stuck
	// run could never be observed or unwedged, and AcquireRunLock could never have
	// called runlock-path to get here in the first place.
	control := [][]string{{"meta", "caps"}}
	if has(s.caps.Axes.Meta, "runlock-status") {
		status := []string{"meta", "runlock-status"}
		if o.LockDir != "" {
			status = append(status, "--run-lock-dir", o.LockDir)
		}
		control = append(control, status)
	}
	exempt := true
	var why string
	for _, args := range control {
		env := s.call(ctx, cRL5+" ["+args[0]+" "+args[1]+"]", args...)
		if env == nil || !env.OK {
			exempt = false
			why = fmt.Sprintf("`%s %s` was refused while a bracket was held (code %s)", args[0], args[1], code(env))
		}
	}
	s.report0(cRL5, exempt, why)

	// C-RL-6: try-mode. A cron (G-LEAK-SCAN) never waits: it reports the holder and
	// skips. The outcome must be BUSY — never a bare green, never a red — and it
	// must leave the holder's record untouched.
	before, _ := mdriver.ProbeRunLock(mdriver.RunLockRef{Key: lock.Key, Path: lock.Path})
	_, tryErr := mdriver.AcquireRunLock(ctx, mdriver.RunLockOptions{Client: cl, Dir: o.LockDir, Wait: 0})
	after, _ := mdriver.ProbeRunLock(mdriver.RunLockRef{Key: lock.Key, Path: lock.Path})
	switch {
	case !mdriver.IsEngineBusy(tryErr):
		s.fail(cRL6, fmt.Sprintf("try-mode on a held lock returned %v, want a SKIPPED_ENGINE_BUSY outcome naming the holder", tryErr))
	case after.Record == nil || before.Record == nil || after.Record.TokenSHA256 != before.Record.TokenSHA256:
		s.fail(cRL6, "try-mode had a side effect: it overwrote the holder's record")
	default:
		s.pass(cRL6)
	}

	s.checkLocus(ctx, o)

	// The C-CAPS-2 live at-limit probes are mutating verbs (exec eval / load),
	// so an enforcing driver's probes run HERE, inside the bracket this suite
	// already holds — exactly like a real lane would run them.
	if s.caps.Limits != nil && s.limitsShapeOK {
		s.checkCapsLimitsLive(ctx, lock.Token, o)
	}
}

// checkHostileHome is C-RL-9 — the D9/EXP-1 red-proof, run INSIDE the suite's
// bracket so both assertions compare against a lock that is genuinely held.
func (s *suite) checkHostileHome(ctx context.Context, lock *mdriver.RunLock) {
	if s.runEnv == nil {
		s.fail(cRL9,
			"the driver advertises features.runLock but the suite was given no EnvRunner, so it cannot dress a call in a hostile $HOME — the D9 red-proof did not run")
		return
	}
	hostile := []string{"HOME=/nonexistent/m-driver-conformance-hostile-home"}

	// (a) derivation immunity: the ref must not move with the environment.
	env := s.callEnv(ctx, cRL9+" [runlock-path]", hostile, "meta", "runlock-path")
	if env == nil {
		return
	}
	if !env.OK {
		s.fail(cRL9, fmt.Sprintf("runlock-path under a hostile $HOME was refused (code %s) — it must answer, byte-equal", code(env)))
		return
	}
	var ref mdriver.RunLockRef
	if err := json.Unmarshal(env.Data, &ref); err != nil {
		s.fail(cRL9, "runlock-path data is not a {key, path}: "+err.Error())
		return
	}
	if ref.Key != lock.Key || ref.Path != lock.Path {
		s.fail(cRL9, fmt.Sprintf(
			"a hostile $HOME re-derived a DIFFERENT lock ref — the serialization domain splits on the environment (D9):\n"+
				"      real env    → key=%q path=%q\n      hostile env → key=%q path=%q\n"+
				"    the lock home must derive from passwd, never $HOME",
			lock.Key, lock.Path, ref.Key, ref.Path))
		return
	}

	// (b) fencing immunity: a wrong token under the hostile env must be compared
	// against the REAL held record — MISMATCH, never NOT_HELD (the signature of a
	// guard probing an env-derived path nobody holds).
	env = s.callEnv(ctx, cRL9+" [fencing]", hostile,
		"exec", "eval", "set x=1", "--run-lock", "the-dead-brackets-token")
	switch {
	case env == nil:
	case env.OK:
		s.fail(cRL9, "under a hostile $HOME the driver PROCEEDED (ok=true) instead of refusing — an unbracketed run reached the engine")
	case env.Error != nil && env.Error.Code == mdriver.CodeRunLockNotHeld:
		s.fail(cRL9,
			"under a hostile $HOME the wrong token came back RUN_LOCK_NOT_HELD — the guard probed an env-derived path nobody holds instead of fencing on the REAL record (want RUN_LOCK_MISMATCH)")
	case env.Error == nil || env.Error.Code != mdriver.CodeRunLockMismatch:
		s.fail(cRL9, fmt.Sprintf("error.code = %q, want %q", code(env), mdriver.CodeRunLockMismatch))
	case env.Exit != mdriver.ExitRunLockRefused:
		s.fail(cRL9, fmt.Sprintf("exit = %d, want %d (the contract's refusal rung)", env.Exit, mdriver.ExitRunLockRefused))
	default:
		s.pass(cRL9)
	}
}

// checkLocus is the R-9 pair: does the key name the PLACE, or the ROUTE?
func (s *suite) checkLocus(ctx context.Context, o Options) {
	// --- C-RL-7: THE R-9 RED-PROOF ---------------------------------------------
	//
	// Two routes to ONE instance must derive a byte-equal key. This is the case that
	// would have caught R-9 in the first place: on this box, foia-t12 is reachable as
	// `--transport docker --container foia-t12` AND as `--transport remote` (Atelier
	// on 127.0.0.1:52773) — which is the LIVE healthcheck configuration
	// (lifecycle-healthcheck.sh drives `m test --docker` and
	// `v pkg install --transport remote` against it in the same lane). Under
	// route-spelled keying those two derive DIFFERENT lock files, so the healthcheck
	// would not serialize against itself.
	if o.PeerTransport == "" {
		s.skip(cRL7, "no dual route configured (Options.PeerTransport) — this driver/lab has no second route to the same instance to cross-check")
	} else {
		mine := s.runLockRef(ctx, cRL7, nil, o)
		peer := s.runLockRef(ctx, cRL7, append([]string{"--transport", o.PeerTransport}, o.PeerArgs...), o)
		switch {
		case mine == nil || peer == nil:
			// the failure is already recorded by runLockRef
		case mine.Key != peer.Key || mine.Path != peer.Path:
			s.fail(cRL7, fmt.Sprintf(
				"two routes to ONE engine derive DIFFERENT locks — they will not serialize:\n"+
					"      %s → key=%q\n      %s → key=%q\n"+
					"    the key must name the instance (its canonical locus), not the route",
				s.transport, mine.Key, o.PeerTransport, peer.Key))
		default:
			s.pass(cRL7)
		}
	}

	// --- C-RL-8: fail-closed, never a selector fallback -------------------------
	//
	// A route whose canonical locus cannot be determined gets NO key. Falling back to
	// the selector spelling would reintroduce the R-9 split precisely when the box is
	// degraded (defeat (n)) — the worst possible moment.
	if len(o.UnresolvableArgs) == 0 {
		s.skip(cRL8, "no unresolvable-route fixture configured (Options.UnresolvableArgs)")
		return
	}
	args := append([]string{"meta", "runlock-path"}, o.UnresolvableArgs...)
	if o.LockDir != "" {
		args = append(args, "--run-lock-dir", o.LockDir)
	}
	env := s.call(ctx, cRL8, args...)
	switch {
	case env == nil:
	case env.OK:
		s.fail(cRL8, "an unresolvable route still produced a key — the driver guessed instead of refusing")
	case env.Error == nil || env.Error.Code != mdriver.CodeRunLockUnresolved:
		s.fail(cRL8, fmt.Sprintf("error.code = %q, want %q", code(env), mdriver.CodeRunLockUnresolved))
	case env.Exit != mdriver.ExitRunLockRefused:
		s.fail(cRL8, fmt.Sprintf("exit = %d, want %d", env.Exit, mdriver.ExitRunLockRefused))
	default:
		s.pass(cRL8)
	}
}

// runLockRef fetches `meta runlock-path` over an explicit route. connArgs nil = the
// suite's own transport (the Runner already appends it).
func (s *suite) runLockRef(ctx context.Context, label string, connArgs []string, o Options) *mdriver.RunLockRef {
	args := append([]string{"meta", "runlock-path"}, connArgs...)
	if o.LockDir != "" {
		args = append(args, "--run-lock-dir", o.LockDir)
	}
	env := s.call(ctx, label, args...)
	if env == nil {
		return nil
	}
	if !env.OK {
		s.fail(label, fmt.Sprintf("runlock-path failed over %v: %s", connArgs, code(env)))
		return nil
	}
	var ref mdriver.RunLockRef
	if err := json.Unmarshal(env.Data, &ref); err != nil {
		s.fail(label, "runlock-path data is not a {key, path}: "+err.Error())
		return nil
	}
	return &ref
}

// checkCapsConnection is C-CAPS-1 (decision #7): the capability document describes
// the CONNECTION, not the binary.
//
// m-iris advertised `exec script` on all three transports while the remote transport
// refused it at runtime — so a remote caller negotiated "supported", then failed. The
// same shape would make Features.RunLock lie, and owner decision #4 (an old driver is
// a HARD ERROR, never a silent unlocked run) is built on trusting that bit.
//
// It is gated on Features.RunLock — not because caps-honesty depends on the run-lock,
// but because connection-resolved caps and the run-lock land in the SAME driver slice
// (P0.2b). Wiring it unconditionally would red-gate both drivers from the moment it
// landed until they caught up — the self-inflicted-broken-gate trap this suite already
// avoided once. So: a driver that has not taken its slice SKIPS (visibly); a driver
// that advertises runLock and still ships binary-union caps is RED, because it is
// lying about the very bit decision #4 trusts.
func (s *suite) checkCapsConnection() {
	const name = "C-CAPS-1 caps are connection-resolved"
	if !s.caps.Features.RunLock {
		s.skip(name, "driver has not taken its P0.2b slice (features.runLock is false); connection-resolved caps land with it — decision #7")
		return
	}
	if s.caps.Transport == "" {
		s.fail(name,
			"the driver advertises features.runLock but caps carries no `transport` field — the "+
				"document still describes the BINARY's union, so every capability in it (including "+
				"features.runLock itself) is a claim about a connection the caller may not have")
		return
	}
	s.report0(name, s.caps.Transport == s.transport,
		fmt.Sprintf("caps.transport = %q but the connection under test is %q — the document does not describe this connection",
			s.caps.Transport, s.transport))
}

// checkCapsLimits is C-CAPS-2 (contract 1.1 §4a): a driver that advertises a
// limits block must advertise an HONEST one. Graduated like C-CAPS-1: a driver
// that has not taken its limits slice SKIPS visibly (nil block — consumers keep
// their gated constants); a PRESENT block with an impossible shape is RED,
// because every consumer that asks instead of hardcoding is trusting it.
//
// Shape rules (each measured on both engines, 2026-07-16): every byte bound is
// positive except LoadBodyBytes (0 = "no cliff found at package scale" — a
// measured verdict, not an unknown); a node cannot out-carry a string
// (MaxNodeValue ≤ MaxString on any M engine — YDB record ≤ string, IRIS equal);
// MaxNodeValueKind must say whether the node cap is physics or site config;
// the four contract fault keys must map to non-empty mnemonics. It returns
// whether the shape is clean: only a shape-clean block is handed to the live
// at-limit spot-measurement (checkCapsLimitsLive, capslive.go), which
// re-measures the declared values over this very connection — a declared cap
// is a self-report until re-measured.
func (s *suite) checkCapsLimits() bool {
	const name = "C-CAPS-2 caps.limits is honest"
	l := s.caps.Limits
	if l == nil {
		s.skip(name, "driver has not taken its limits slice (caps.limits absent) — consumers keep their gated constants; contract 1.1 §4a")
		return false
	}
	var faults []string
	if l.MaxString <= 0 {
		faults = append(faults, fmt.Sprintf("maxString = %d (must be > 0)", l.MaxString))
	}
	if l.MaxNodeValue <= 0 {
		faults = append(faults, fmt.Sprintf("maxNodeValue = %d (must be > 0)", l.MaxNodeValue))
	}
	if l.MaxNodeValue > l.MaxString {
		faults = append(faults, fmt.Sprintf("maxNodeValue %d > maxString %d — a node cannot out-carry a string", l.MaxNodeValue, l.MaxString))
	}
	if l.MaxNodeValueKind != "engine" && l.MaxNodeValueKind != "region-config" {
		faults = append(faults, fmt.Sprintf("maxNodeValueKind = %q (must be \"engine\" or \"region-config\" — consumers need to know physics vs site config)", l.MaxNodeValueKind))
	}
	if l.MaxKeyBytes <= 0 {
		faults = append(faults, fmt.Sprintf("maxKeyBytes = %d (must be > 0)", l.MaxKeyBytes))
	}
	if l.MaxSubscripts <= 0 {
		faults = append(faults, fmt.Sprintf("maxSubscripts = %d (must be > 0)", l.MaxSubscripts))
	}
	if l.EvalEnvelope <= 0 {
		faults = append(faults, fmt.Sprintf("evalEnvelope = %d (must be > 0 — a lane that carries nothing is not a lane)", l.EvalEnvelope))
	}
	if l.LoadBodyBytes < 0 {
		faults = append(faults, fmt.Sprintf("loadBodyBytes = %d (must be ≥ 0; 0 means no-cliff-found, a measured verdict)", l.LoadBodyBytes))
	}
	for _, k := range []string{"oversize-string", "oversize-node", "oversize-key", "too-many-subscripts"} {
		if l.FaultMnemonics[k] == "" {
			faults = append(faults, fmt.Sprintf("faultMnemonics[%q] missing/empty — a consumer translating this fault falls back to an engine-shaped regex, the exact gap the map closes", k))
		}
	}
	s.report0(name, len(faults) == 0, "caps.limits is malformed: "+strings.Join(faults, "; "))
	return len(faults) == 0
}

// refusal asserts that a verb is refused with a specific structured code on the
// contract's refusal rung — a driver that PROCEEDS here is the corruption bug.
func (s *suite) refusal(ctx context.Context, name, wantCode string, args ...string) {
	env := s.call(ctx, name, args...)
	if env == nil {
		return
	}
	switch {
	case env.OK:
		s.fail(name, "the driver PROCEEDED (ok=true) instead of refusing — an unbracketed run reached the engine")
	case env.Error == nil:
		s.fail(name, "the driver refused, but with no structured error object to branch on")
	case env.Error.Code != wantCode:
		s.fail(name, fmt.Sprintf("error.code = %q, want %q", env.Error.Code, wantCode))
	case env.Exit != mdriver.ExitRunLockRefused:
		s.fail(name, fmt.Sprintf("exit = %d, want %d (the contract's refusal rung)", env.Exit, mdriver.ExitRunLockRefused))
	default:
		s.pass(name)
	}
}

func code(env *Envelope) string {
	if env == nil || env.Error == nil {
		return "-"
	}
	return env.Error.Code
}
