package conformance

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// The C-CAPS-2 live spot-measurement probes (contract 1.1 §4a; caps-limits
// adoption W1): for a connection advertising `limits`, conformance re-measures
// every probeable declared value AT-LIMIT over that very connection. A declared
// cap is a self-report until re-measured — the shape gate (checkCapsLimits)
// keeps a malformed block out; these probes keep a FALSE one out.
//
// Probe idioms are the engcap campaign's (v-stdlib/scripts/engcap-l1.sh):
// oversized payloads are built ENGINE-SIDE with $justify (the eval lane is
// usually narrower than maxString, so the payload can never ride the command),
// and every probe writes a verdict token + observed $length so silent
// truncation is distinguishable from a clean pass. Padding that must survive
// the lane rides INSIDE a string literal, never in a comment — a truncated
// comment still executes, a truncated literal cannot.
//
// Deliberately NOT probed (documented, not faked):
//   - one-past probes (declared+1 must fault) are DEFERRED until each driver's
//     fault-envelope shape is pinned in conformance; the at-limit half already
//     catches the dangerous direction — declaring more than the engine carries;
//   - maxKeyBytes / maxSubscripts stay shape-only: re-deriving them needs the
//     engine's key-encoding overhead (the engcap $qlength technique), a
//     follow-on, not a W1 wire-up.

// maxStringProbe builds the declared-length local string engine-side and
// writes the verdict token with the observed length.
func maxStringProbe(n int) string {
	return fmt.Sprintf(`new x set x=$justify("",%d) write "CAPS2STR=",$select($length(x)=%d:1,1:0),";L=",$length(x),!`, n, n)
}

// maxNodeValueProbe SETs a scratch global node at the declared size in the
// ephemeral-prefix namespace (^zztcapslim), reads it back, and kills it in the
// same command — a fault on the SET writes nothing, so the engine stays
// greenfield either way. Running it at-limit on the connection under test is
// what re-derives kind "region-config" values per instance: a site whose
// region carries less than the declared reference faults here, by design.
func maxNodeValueProbe(n int) string {
	return fmt.Sprintf(`new x set x=$justify("",%d) set ^zztcapslim=x kill x write "CAPS2NODE=",$select($length($get(^zztcapslim))=%d:1,1:0),";L=",$length($get(^zztcapslim)),! kill ^zztcapslim`, n, n)
}

// evalEnvelopeProbe returns a command literal of EXACTLY n bytes whose verdict
// is the padding length: the pad rides inside the string literal, so a lane
// that truncates the command breaks the literal (a fault), and a lane that
// rewrites it changes the verdict. ok=false when n is too small to carry the
// probe at all.
const (
	evalProbePrefix = `write "CAPS2ENV=",$length("`
	evalProbeSuffix = `"),!`
)

func evalEnvelopeProbe(n int) (cmd, want string, ok bool) {
	pad := n - len(evalProbePrefix) - len(evalProbeSuffix)
	if pad < 1 {
		return "", "", false
	}
	return evalProbePrefix + strings.Repeat("A", pad) + evalProbeSuffix,
		fmt.Sprintf("CAPS2ENV=%d", pad), true
}

// loadBodyProbe returns a valid M routine body of EXACTLY n bytes for routine
// zztcapslim. The verdict tag rides the END of the body — a truncated stage
// loses it, so `exec run capsv^zztcapslim` writing the token proves the whole
// body arrived intact. Padding is comment lines (they only pad the FILE, whose
// byte count is the declared fact; the load lane carries the file wholesale,
// so unlike the eval probe there is no truncation mode a comment could mask).
func loadBodyProbe(n int) (string, bool) {
	const header = "zztcapslim ; C-CAPS-2 loadBodyBytes at-limit probe (conformance; staged+unstaged)\n quit\n"
	const verdict = "capsv ; verdict tag at the END of the body\n write \"CAPS2LOAD=1\",!\n quit\n"
	rem := n - len(header) - len(verdict)
	if rem < 0 || (rem > 0 && rem < 3) {
		return "", false // cannot pad to that exact size with valid comment lines
	}
	var b strings.Builder
	b.WriteString(header)
	for rem > 0 {
		// One comment line " ;<A…>\n" is line+3 bytes for `line` A's; keep lines
		// short (the probe measures the BODY size, not source-line limits).
		take := rem
		if take > 1003 {
			take = 1003
		}
		if left := rem - take; left > 0 && left < 3 {
			take = rem - 3
		}
		b.WriteString(" ;")
		b.WriteString(strings.Repeat("A", take-3))
		b.WriteString("\n")
		rem -= take
	}
	b.WriteString(verdict)
	return b.String(), true
}

const (
	cCapsMaxString = "C-CAPS-2 [maxString at-limit]"
	cCapsEvalEnv   = "C-CAPS-2 [evalEnvelope at-limit]"
	cCapsMaxNode   = "C-CAPS-2 [maxNodeValue at-limit]"
	cCapsLoadBody  = "C-CAPS-2 [loadBodyBytes at-limit]"
)

// checkCapsLimitsLive re-measures the declared limits at-limit over the
// connection under test. Called only when the block is present and
// shape-clean; token is the held run-lock bracket ("" when the driver does
// not enforce the run-lock). Probes are mutating verbs, so an enforcing
// driver's probes run inside the suite's own bracket — exactly like a real
// lane.
func (s *suite) checkCapsLimitsLive(ctx context.Context, token string, o Options) {
	l := s.caps.Limits
	conn := func(args ...string) []string {
		if o.LockDir != "" {
			args = append(args, "--run-lock-dir", o.LockDir)
		}
		if token != "" {
			args = append(args, "--run-lock", token)
		}
		return args
	}

	if !has(s.caps.Axes.Exec, "eval") {
		s.fail("C-CAPS-2 [live at-limit]",
			"caps.limits is present but the connection advertises no `exec eval` to re-measure over — a declared limit nothing can probe stays a self-report")
		return
	}

	// maxString: build the declared length engine-side, verdict = observed $length.
	s.evalProbe(ctx, cCapsMaxString,
		conn("exec", "eval", maxStringProbe(l.MaxString)),
		fmt.Sprintf("CAPS2STR=1;L=%d", l.MaxString),
		fmt.Sprintf("declared maxString=%d", l.MaxString))

	// evalEnvelope: a command literal of EXACTLY the declared size must survive
	// this lane intact.
	if cmd, want, ok := evalEnvelopeProbe(l.EvalEnvelope); !ok {
		s.fail(cCapsEvalEnv, fmt.Sprintf("declared evalEnvelope=%d is too small to carry the probe — not a plausible lane", l.EvalEnvelope))
	} else {
		s.evalProbe(ctx, cCapsEvalEnv, conn("exec", "eval", cmd), want,
			fmt.Sprintf("declared evalEnvelope=%d", l.EvalEnvelope))
	}

	// maxNodeValue: at-limit scratch SET re-derives the cap on THIS instance —
	// kind "region-config" sites whose region carries less are caught here.
	s.evalProbe(ctx, cCapsMaxNode,
		conn("exec", "eval", maxNodeValueProbe(l.MaxNodeValue)),
		fmt.Sprintf("CAPS2NODE=1;L=%d", l.MaxNodeValue),
		fmt.Sprintf("declared maxNodeValue=%d (%s)", l.MaxNodeValue, l.MaxNodeValueKind))

	// loadBodyBytes: one exec load at the declared size, proven intact by
	// running the verdict tag that rides the END of the body.
	switch {
	case l.LoadBodyBytes == 0:
		s.skip(cCapsLoadBody, "loadBodyBytes=0 — the measured no-cliff-found verdict for this lane; there is no at-limit to probe")
	case !has(s.caps.Axes.Exec, "load") || !has(s.caps.Axes.Exec, "run"):
		s.fail(cCapsLoadBody, fmt.Sprintf(
			"declares loadBodyBytes=%d but this connection does not advertise exec load+run — the declaration describes a lane the connection does not have", l.LoadBodyBytes))
	default:
		s.loadProbe(ctx, token, o)
	}
}

// evalProbe runs one at-limit eval probe and grades the verdict: a fault means
// the declaration overstates the lane; a wrong verdict token means the lane
// rewrote or silently truncated the payload.
func (s *suite) evalProbe(ctx context.Context, name string, args []string, want, declared string) {
	env := s.call(ctx, name, args...)
	if env == nil {
		return
	}
	if !env.OK {
		s.fail(name, fmt.Sprintf(
			"%s: the at-limit probe FAULTED (%s) — the declaration overstates what this connection actually carries; correct the driver's caps or re-measure (engcap)",
			declared, faultOf(env)))
		return
	}
	var r struct {
		Stdout string `json:"stdout"`
	}
	if err := json.Unmarshal(env.Data, &r); err != nil {
		s.fail(name, "exec eval data is not a {stdout, status}: "+err.Error())
		return
	}
	if !strings.Contains(r.Stdout, want) {
		s.fail(name, fmt.Sprintf(
			"%s: the probe ran but the verdict is wrong — want %q in stdout, got %q (silent truncation, or the lane rewrote the payload)",
			declared, want, strings.TrimSpace(r.Stdout)))
		return
	}
	s.pass(name)
}

// loadProbe stages a routine body of EXACTLY the declared loadBodyBytes, runs
// its end-of-body verdict tag, and unstages — the engine is left greenfield.
func (s *suite) loadProbe(ctx context.Context, token string, o Options) {
	l := s.caps.Limits
	body, ok := loadBodyProbe(l.LoadBodyBytes)
	if !ok {
		s.fail(cCapsLoadBody, fmt.Sprintf("declared loadBodyBytes=%d is too small to carry a valid probe routine — not a plausible lane", l.LoadBodyBytes))
		return
	}
	dir, err := os.MkdirTemp("", "m-driver-conformance-caps-")
	if err != nil {
		s.fail(cCapsLoadBody, "cannot create the probe workspace: "+err.Error())
		return
	}
	defer os.RemoveAll(dir)
	path := filepath.Join(dir, "zztcapslim.m")
	if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
		s.fail(cCapsLoadBody, "cannot write the probe routine: "+err.Error())
		return
	}

	conn := func(args ...string) []string {
		if s.caps.Features.ManagedStaging {
			args = append(args, "--stage-dir", "mtest-capslim")
		}
		if o.LockDir != "" {
			args = append(args, "--run-lock-dir", o.LockDir)
		}
		if token != "" {
			args = append(args, "--run-lock", token)
		}
		return args
	}

	loadEnv := s.call(ctx, cCapsLoadBody+" [load]", conn("exec", "load", path)...)
	// Unconditional exit cleanup once a load was attempted: a leaked stage is
	// not greenfield, so a failed unstage is itself a finding.
	defer func() {
		if !has(s.caps.Axes.Exec, "unstage") {
			return
		}
		env := s.call(ctx, cCapsLoadBody+" [unstage]", conn("exec", "unstage")...)
		if env == nil || !env.OK {
			s.fail(cCapsLoadBody+" [cleanup]", "the probe stage could not be unstaged — the engine is NOT greenfield (code "+code(env)+")")
		}
	}()
	if loadEnv == nil {
		return
	}
	if !loadEnv.OK {
		s.fail(cCapsLoadBody, fmt.Sprintf(
			"declared loadBodyBytes=%d: the at-limit stage was REFUSED (%s) — the declaration overstates what this lane carries",
			l.LoadBodyBytes, faultOf(loadEnv)))
		return
	}

	runEnv := s.call(ctx, cCapsLoadBody+" [run]", conn("exec", "run", "capsv^zztcapslim")...)
	if runEnv == nil {
		return
	}
	if !runEnv.OK {
		s.fail(cCapsLoadBody, fmt.Sprintf(
			"declared loadBodyBytes=%d: the staged probe would not run (%s) — the body did not arrive intact", l.LoadBodyBytes, faultOf(runEnv)))
		return
	}
	var r struct {
		Stdout string `json:"stdout"`
	}
	if err := json.Unmarshal(runEnv.Data, &r); err != nil {
		s.fail(cCapsLoadBody, "exec run data is not a {stdout, status}: "+err.Error())
		return
	}
	if !strings.Contains(r.Stdout, "CAPS2LOAD=1") {
		s.fail(cCapsLoadBody, fmt.Sprintf(
			"declared loadBodyBytes=%d: the end-of-body verdict tag did not answer (got %q) — the body was truncated in staging", l.LoadBodyBytes, strings.TrimSpace(r.Stdout)))
		return
	}
	s.pass(cCapsLoadBody)
}

// faultOf renders the most specific cause an envelope carries: the engine
// fault mnemonic when present, else the structured error code.
func faultOf(env *Envelope) string {
	if env.EngineError != nil && env.EngineError.Mnemonic != "" {
		return env.EngineError.Mnemonic
	}
	return "code " + code(env)
}
