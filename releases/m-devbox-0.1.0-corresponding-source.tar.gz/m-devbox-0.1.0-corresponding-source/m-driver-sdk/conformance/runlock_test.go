package conformance

import (
	"context"
	"encoding/json"
	"errors"
	"path/filepath"
	"strings"
	"testing"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// runLockDriver is a fake driver that ENFORCES the run-lock through the SDK's own
// dispatch primitives (ClassOf → RequireRunLock) — i.e. exactly the middleware
// each real driver will wire in P0.3. So these tests drive the conformance cases
// end-to-end against a real lock file, not against canned envelopes.
type runLockDriver struct {
	dir       string // the run-lock home this fake derives into
	key       string
	advertise bool   // does it advertise features.runLock?
	limits    string // raw caps.limits JSON ("" = absent — the not-taken slice)
	broken    bool   // …but does not actually enforce (the dishonest-caps case)
	extraVerb string

	// The C-CAPS-2 live-probe seam (capslive_test.go): execVerbs widens the
	// advertised exec axis beyond ["eval"], managedStaging flips the feature
	// bit, and sim — when set — emulates an M engine with its own REAL limits
	// for the probe idioms, so a fake can declare one thing and carry another
	// (the planted-wrong-declaration negative control).
	execVerbs      []string
	managedStaging bool
	sim            *engineSim

	// The two C-RL-9 defect shapes (L0.B2). homeSensitive is the pre-L0 driver:
	// BOTH the runlock-path derivation and the guard read $HOME, so a hostile env
	// splits the serialization domain (the measured D9/EXP-1 defeat).
	// guardHomeSensitive is the subtler split: derivation fixed (passwd) but the
	// GUARD still probes an env-derived path — runlock-path answers byte-equal
	// while refusals fence on a lock file nobody holds.
	homeSensitive      bool
	guardHomeSensitive bool
}

func (d runLockDriver) caps() string {
	exec := `"eval"`
	for _, v := range d.execVerbs {
		if v != "eval" {
			exec += `,"` + v + `"`
		}
	}
	axes := `"lifecycle":["status"],"exec":[` + exec + `],"meta":["caps","version","doctor","runlock-path","runlock-status"]`
	if d.extraVerb != "" {
		axes = `"lifecycle":["status"],"exec":["eval","` + d.extraVerb + `"],"meta":["caps","version","doctor"]`
	}
	// Connection-resolved: a driver that claims runLock must describe the CONNECTION,
	// not the binary's union (decision #7 / C-CAPS-1).
	transport := ``
	if d.advertise {
		transport = `"transport":"docker",`
	}
	limits := ``
	if d.limits != "" {
		limits = `,"limits":` + d.limits
	}
	return `{"engine":"ydb","contract":"1.0",` + transport + `"transports":["local","docker","remote"],` +
		`"axes":{` + axes + `},` +
		`"features":{"remote":true,"prune":false,"ephemeralPrefix":false,"snapshot":false,` +
		`"managedStaging":` + boolStr(d.managedStaging) + `,"runLock":` + boolStr(d.advertise) + `}` + limits + `}`
}

func boolStr(b bool) string {
	if b {
		return "true"
	}
	return "false"
}

func (d runLockDriver) runner() Runner {
	return func(ctx context.Context, args ...string) (RawResult, error) {
		return d.run(ctx, "", args...)
	}
}

// envRunner is the fake's EnvRunner: it reads an injected HOME the way a real
// driver subprocess would see its environment dressed.
func (d runLockDriver) envRunner() EnvRunner {
	return func(ctx context.Context, extraEnv []string, args ...string) (RawResult, error) {
		home := ""
		for _, kv := range extraEnv {
			if v, ok := strings.CutPrefix(kv, "HOME="); ok {
				home = v
			}
		}
		return d.run(ctx, home, args...)
	}
}

func (d runLockDriver) run(_ context.Context, injectedHome string, args ...string) (RawResult, error) {
	var axis, verb, token, dir string
	var dirFlagged bool
	var positional []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--run-lock":
			if i+1 < len(args) {
				token = args[i+1]
				i++
			}
		case "--run-lock-dir":
			if i+1 < len(args) {
				dir = args[i+1]
				dirFlagged = true
				i++
			}
		case "--transport", "--output", "--stage-dir":
			i++
		default:
			positional = append(positional, args[i])
		}
	}
	if len(positional) < 2 {
		return env(false, 2, `{}`, strings.Join(positional, " ")), nil
	}
	axis, verb = positional[0], positional[1]
	cmd := axis + " " + verb
	if dir == "" {
		dir = d.dir
	}
	// C-RL-9 defect shapes: a hostile injected HOME moves the derivation and/or
	// the guard when the fake models a $HOME-reading driver. An explicit
	// --run-lock-dir always wins (the fixture override), like the real drivers'.
	pathDir, guardDir := dir, dir
	if injectedHome != "" && !dirFlagged {
		envDir := filepath.Join(injectedHome, "data", "vista-forge", "run-lock")
		if d.homeSensitive {
			pathDir, guardDir = envDir, envDir
		} else if d.guardHomeSensitive {
			guardDir = envDir
		}
	}
	ref := mdriver.RunLockRef{Key: d.key, Path: filepath.Join(pathDir, d.key+".lock")}
	guardRef := mdriver.RunLockRef{Key: d.key, Path: filepath.Join(guardDir, d.key+".lock")}

	switch cmd {
	case "meta caps":
		return env(true, 0, d.caps(), cmd), nil
	case "meta version":
		return env(true, 0, `{"driver":"fake","engine":"ydb","contract":"1.0","build":"t"}`, cmd), nil
	case "meta doctor":
		return env(true, 0, `{"transport":"docker","ok":true,"checks":[{"name":"x","ok":true}]}`, cmd), nil
	case "lifecycle status":
		return env(true, 0, `{"transport":"docker","running":true,"healthy":true,"latencyMs":1}`, cmd), nil
	case "meta runlock-path":
		b, _ := json.Marshal(ref)
		return env(true, 0, string(b), cmd), nil
	case "meta runlock-status":
		st, err := mdriver.ProbeRunLock(ref)
		if err != nil {
			return env(false, 5, `{}`, cmd), nil
		}
		b, _ := json.Marshal(st)
		return env(true, 0, string(b), cmd), nil
	}

	// The dispatch middleware: class lookup → RequireRunLock → refusal envelope.
	class, ok := mdriver.ClassOf(axis, verb)
	if !ok {
		return env(false, 7, `{}`, cmd), nil
	}
	if !d.broken {
		if err := mdriver.RequireRunLock(class, guardRef, token); err != nil {
			var rl *mdriver.RunLockError
			if ok := asRunLockError(err, &rl); ok {
				return failEnv(rl.Code, rl.Exit, cmd), nil
			}
			return env(false, 5, `{}`, cmd), nil
		}
	}
	// The engine simulator (capslive_test.go): a fake with a sim carries REAL
	// limits of its own, so the C-CAPS-2 live probes measure something.
	if d.sim != nil && axis == "exec" {
		if raw, handled := d.sim.handle(verb, positional[2:], cmd); handled {
			return raw, nil
		}
	}
	return env(true, 0, `{"stdout":"","status":0}`, cmd), nil
}

func asRunLockError(err error, out **mdriver.RunLockError) bool {
	return errors.As(err, out)
}

// failEnv is a Fail-path envelope carrying a structured refusal code.
func failEnv(code string, exit int, cmd string) RawResult {
	e := Envelope{
		SchemaVersion: "1.0", Command: cmd, OK: false, Exit: exit,
		Data:  json.RawMessage(`null`),
		Error: &EnvError{Code: code, Exit: exit, Message: code},
	}
	b, _ := json.Marshal(e)
	return RawResult{Stdout: b, Exit: exit}
}

func runFake(t *testing.T, d runLockDriver, o Options) Report {
	t.Helper()
	if o.EnvRunner == nil {
		o.EnvRunner = d.envRunner()
	}
	o.newClient = func(engine string) *mdriver.Client {
		return mdriver.NewClient("fake", engine, "docker", nil,
			func(ctx context.Context, _ string, args []string) ([]byte, []byte, int, error) {
				raw, err := d.runner()(ctx, args...)
				if err != nil {
					return nil, nil, 0, err
				}
				return raw.Stdout, nil, raw.Exit, nil
			})
	}
	return RunWith(context.Background(), d.runner(), "docker", o)
}

func named(rep Report, prefix string) []Result {
	var out []Result
	for _, r := range rep.Results {
		if strings.HasPrefix(r.Name, prefix) {
			out = append(out, r)
		}
	}
	return out
}

// A driver that advertises features.runLock and actually enforces it passes all
// six cases — the capability bit is the driver's own promise, and conformance
// holds it to it.
func TestRunLock_EnforcingDriverPassesAllSixCases(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	if rep.Fail > 0 {
		for _, r := range rep.Results {
			if !r.Pass && !r.Skip {
				t.Errorf("FAIL %s — %s", r.Name, r.Detail)
			}
		}
	}
	for _, c := range []string{"C-RL-1", "C-RL-2", "C-RL-3", "C-RL-4", "C-RL-5", "C-RL-6", "C-CAPS-1"} {
		got := named(rep, c)
		if len(got) == 0 {
			t.Errorf("%s did not run at all", c)
			continue
		}
		for _, r := range got {
			if !r.Pass {
				t.Errorf("%s: pass=%v skip=%v — %s", r.Name, r.Pass, r.Skip, r.Detail)
			}
		}
	}
	// C-RL-7 (dual route) and C-RL-8 (unresolvable fixture) need lab wiring the fake
	// has no way to provide, and C-CAPS-2 needs a limits block this fake does not
	// declare — they SKIP, visibly, and that is the honest outcome. The live driver
	// spikes DO provide all three.
	if rep.Skip != 3 {
		t.Errorf("Skip = %d, want exactly C-RL-7 + C-RL-8 + C-CAPS-2 skipped", rep.Skip)
	}
}

// The trap the kickoff names: C-RL-1…6 assert behavior no driver implements yet.
// Wired naively they would red-gate the SDK and BOTH drivers from the moment they
// land until P0.3 completes — a self-inflicted broken gate on the critical path.
// So they are capability-gated: no bit ⇒ skipped, and the suite is green today.
func TestRunLock_DriverWithoutTheBitSkipsAndStaysGreen(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: false}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	if rep.Fail != 0 {
		t.Errorf("a driver that does not advertise runLock must stay GREEN, got %d failures", rep.Fail)
	}
	// 9 run-lock cases (C-RL-1..9) + C-CAPS-1 + C-CAPS-2 — all skipped, none passed.
	if rep.Skip != 11 {
		t.Errorf("Skip = %d, want the 9 run-lock cases + C-CAPS-1 + C-CAPS-2 skipped", rep.Skip)
	}
	for _, r := range named(rep, "C-RL-") {
		// P-B: an unobserved gate is not a gate. A skip must be VISIBLY a skip and
		// must never be counted as a pass — otherwise the suite would report six
		// green assertions it never actually made.
		if !r.Skip {
			t.Errorf("%s is not marked skipped", r.Name)
		}
		if r.Pass {
			t.Errorf("%s is counted as a PASS — a skip must never read as a pass", r.Name)
		}
		if !strings.Contains(r.Detail, "runLock") {
			t.Errorf("%s does not say WHY it skipped: %q", r.Name, r.Detail)
		}
	}
}

// …and it turns hard the instant a driver claims the capability.
func TestRunLock_DishonestCapsIsRed(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true, broken: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	if rep.Fail == 0 {
		t.Fatal("a driver that advertises features.runLock but does not enforce it must be RED")
	}
	var sawRefusalFailure bool
	for _, r := range named(rep, "C-RL-1") {
		if !r.Pass && !r.Skip {
			sawRefusalFailure = true
		}
	}
	if !sawRefusalFailure {
		t.Error("C-RL-1 (mutate with no token → RUN_LOCK_REQUIRED) did not fail against a non-enforcing driver")
	}
}

// A skip must be a DECISION the driver made, never an accident of how the suite
// was invoked. If the bit is advertised but the suite has no driver path to
// bracket with, that is a broken gate — and a broken gate is RED, not skipped.
func TestRunLock_AdvertisedButUnwireableSuiteIsRedNotSkipped(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true}
	rep := RunWith(context.Background(), d.runner(), "docker", Options{}) // no Driver, no client

	for _, r := range named(rep, "C-RL-") {
		if r.Skip {
			t.Errorf("an unwireable suite must not SKIP %s — that is a gate silently not running", r.Name)
		}
	}
	if rep.Fail == 0 {
		t.Fatal("features.runLock advertised with no way to bracket must be RED")
	}
}

// The coverage red-gate (§6c): a verb a driver advertises that the registry does
// not classify is a verb its own dispatch middleware cannot enforce. Adding one
// therefore FORCES the taxonomy question at add-time.
func TestVerbClassCoverage_UnclassifiedAdvertisedVerbIsRed(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: false, extraVerb: "teleport"}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	var found bool
	for _, r := range named(rep, "verb classes") {
		if !r.Pass && strings.Contains(r.Detail, "exec teleport") {
			found = true
		}
	}
	if !found {
		t.Errorf("an unclassified advertised verb did not red-gate the suite: %+v", rep.Results)
	}
}

func TestVerbClassCoverage_GreenOnAClassifiedDriver(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: false}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	for _, r := range named(rep, "verb classes") {
		if !r.Pass {
			t.Errorf("coverage check failed on a fully-classified driver: %s", r.Detail)
		}
	}
}

// The legacy entry point keeps working (both drivers' `meta selftest` calls it),
// and it must not silently drop the run-lock cases into nothing.
func TestRun_BackCompatEntryPointStillReports(t *testing.T) {
	rep := Run(context.Background(), goodDriver().runner(), "local")
	if rep.Pass == 0 {
		t.Fatal("the legacy Run() reported nothing")
	}
	if rep.Fail != 0 {
		t.Errorf("the legacy Run() went red on a conformant driver: %d failures", rep.Fail)
	}
}

// --- C-RL-7: the R-9 red-proof must actually FIRE ------------------------------
//
// A gate that cannot go red is not a gate. These two tests are the ones that would
// have caught R-9 in the first place.

// dualRouteDriver derives its key from the ROUTE (the R-3 defect) — so the docker
// route and the remote route to ONE engine produce two different lock files.
type dualRouteDriver struct{ dir string }

func (d dualRouteDriver) runner() Runner {
	return func(_ context.Context, args ...string) (RawResult, error) {
		joined := strings.Join(args, " ")
		transport := "docker"
		for i, a := range args {
			if a == "--transport" && i+1 < len(args) {
				transport = args[i+1]
			}
		}
		switch {
		case strings.HasPrefix(joined, "meta caps"):
			return env(true, 0, `{"engine":"iris","contract":"1.0","transport":"`+transport+`",`+
				`"transports":["docker","remote"],"axes":{"exec":["eval"],"meta":["caps","runlock-path"]},`+
				`"features":{"runLock":true}}`, "meta caps"), nil
		case strings.HasPrefix(joined, "meta runlock-path"):
			// THE DEFECT: the key is spelled from the route, not the instance.
			key := "iris.docker.foia-t12"
			if transport == "remote" {
				key = "iris.remote.127.0.0.1_52773"
			}
			b, _ := json.Marshal(mdriver.RunLockRef{Key: key, Path: filepath.Join(d.dir, key+".lock")})
			return env(true, 0, string(b), "meta runlock-path"), nil
		}
		return env(false, 7, `{}`, joined), nil
	}
}

// This is R-9 itself, reproduced: foia-t12 over docker and over Atelier are ONE
// engine, and a route-spelled key gives them two locks — so the live healthcheck
// lane (`m test --docker` + `v pkg install --transport remote`) would not serialize
// against itself. C-RL-7 must catch it.
func TestCRL7_RouteSpelledKeyIsRED(t *testing.T) {
	dir := t.TempDir()
	d := dualRouteDriver{dir: dir}
	rep := RunWith(context.Background(), d.runner(), "docker", Options{
		Driver: "fake", LockDir: dir,
		PeerTransport: "remote", // the SAME foia-t12, reached the other way
		newClient: func(engine string) *mdriver.Client {
			return mdriver.NewClient("fake", engine, "docker", nil,
				func(ctx context.Context, _ string, args []string) ([]byte, []byte, int, error) {
					raw, _ := d.runner()(ctx, args...)
					return raw.Stdout, nil, raw.Exit, nil
				})
		},
	})

	var fired bool
	for _, r := range named(rep, "C-RL-7") {
		if !r.Pass && !r.Skip {
			fired = true
			if !strings.Contains(r.Detail, "iris.docker.foia-t12") ||
				!strings.Contains(r.Detail, "iris.remote.127.0.0.1_52773") {
				t.Errorf("C-RL-7 fired but does not NAME the two colliding keys: %s", r.Detail)
			}
		}
	}
	if !fired {
		t.Fatal("C-RL-7 did NOT fire on a route-spelled key — the R-9 red-proof cannot go red, so it is not a gate")
	}
}

// …and it must be a visible SKIP, never a silent pass, where no dual route exists.
func TestCRL7_NoDualRouteIsAVisibleSkip(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir}) // no PeerTransport

	got := named(rep, "C-RL-7")
	if len(got) != 1 {
		t.Fatalf("C-RL-7 did not report at all: %+v", rep.Results)
	}
	if !got[0].Skip || got[0].Pass {
		t.Errorf("C-RL-7 = pass:%v skip:%v — with no dual route it must SKIP, never pass", got[0].Pass, got[0].Skip)
	}
	if !strings.Contains(got[0].Detail, "dual route") {
		t.Errorf("the skip does not say why: %q", got[0].Detail)
	}
}

// --- S1: the harness must SEE a refusal ---------------------------------------
//
// clikit renders a Fail-path envelope to STDERR. v0.8.0's harness parsed stdout only,
// so C-RL-1/3/4 — the three REFUSAL cases, the entire point of a lock that refuses —
// reported FAIL against drivers that refuse perfectly. Both driver spikes hit it
// independently and had to prove those cases with their own integration tests.
//
// A harness that cannot see a refusal cannot gate a lock whose purpose is to refuse.
func TestSuiteCall_ReadsTheFailEnvelopeFromStderr(t *testing.T) {
	// A driver that behaves exactly like the real ones: refusal envelope on stderr,
	// stdout empty, process exit 4.
	stderrRefuser := func(_ context.Context, args ...string) (RawResult, error) {
		joined := strings.Join(args, " ")
		if strings.HasPrefix(joined, "meta caps") {
			return env(true, 0, `{"engine":"ydb","contract":"1.0","transport":"docker",`+
				`"transports":["docker"],"axes":{"exec":["eval"],"meta":["caps"]},`+
				`"features":{"runLock":false}}`, "meta caps"), nil
		}
		fail := failEnv(mdriver.CodeRunLockRequired, mdriver.ExitRunLockRefused, joined)
		return RawResult{Stdout: nil, Stderr: fail.Stdout, Exit: fail.Exit}, nil // ← on STDERR
	}

	s := &suite{run: stderrRefuser, transport: "docker"}
	envp := s.call(context.Background(), "refusal", "exec", "eval", "set x=1")

	if envp == nil {
		t.Fatal("the harness could not read a refusal envelope from stderr — C-RL-1/3/4 are blind")
	}
	if envp.Error == nil || envp.Error.Code != mdriver.CodeRunLockRequired {
		t.Fatalf("refusal not decoded: %+v", envp)
	}
	if envp.Exit != mdriver.ExitRunLockRefused {
		t.Errorf("exit = %d, want %d", envp.Exit, mdriver.ExitRunLockRefused)
	}
	for _, r := range s.results {
		if !r.Pass && !r.Skip {
			t.Errorf("envelope discipline failed on a well-formed stderr refusal: %s — %s", r.Name, r.Detail)
		}
	}
}

// --- C-RL-9 (L0.B2): the D9/EXP-1 red-proof — $HOME-immunity of the lock domain ---

// A conformant (passwd-derived) driver is indifferent to a hostile $HOME: the
// re-derived ref is byte-equal and the wrong-token refusal fences on the REAL
// record (RUN_LOCK_MISMATCH — proof the hostile call resolved to the same lock).
func TestCRL9_EnforcingDriverIsImmuneToHostileHome(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	got := named(rep, "C-RL-9")
	if len(got) == 0 {
		t.Fatal("C-RL-9 did not run at all")
	}
	for _, r := range got {
		if !r.Pass || r.Skip {
			t.Errorf("%s: pass=%v skip=%v — %s", r.Name, r.Pass, r.Skip, r.Detail)
		}
	}
}

// The pre-L0 driver: lock home read from $HOME. A hostile env re-derives a
// DIFFERENT ref — the serialization domain splits (the measured D9 defeat) and
// C-RL-9 must be RED. This is the standing planted-defect fixture for L0.V.
func TestCRL9_HomeDerivedLockHomeIsRED(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true, homeSensitive: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	got := named(rep, "C-RL-9")
	if len(got) == 0 {
		t.Fatal("C-RL-9 did not run at all")
	}
	failed := false
	for _, r := range got {
		if !r.Pass && !r.Skip {
			failed = true
			if !strings.Contains(r.Detail, "DIFFERENT") {
				t.Errorf("C-RL-9 failed but the detail does not name the domain split: %s", r.Detail)
			}
		}
	}
	if !failed {
		t.Error("C-RL-9 stayed green against a $HOME-derived driver — the D9 red-proof does not red")
	}
}

// The subtler split: derivation fixed (runlock-path is byte-equal) but the GUARD
// still probes an env-derived path — the wrong-token call comes back
// RUN_LOCK_NOT_HELD (a lock file nobody holds) instead of fencing MISMATCH on
// the real record. C-RL-9 must be RED on the code, not just the path compare.
func TestCRL9_GuardSplitIsRED(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true, guardHomeSensitive: true}
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	got := named(rep, "C-RL-9")
	if len(got) == 0 {
		t.Fatal("C-RL-9 did not run at all")
	}
	failed := false
	for _, r := range got {
		if !r.Pass && !r.Skip {
			failed = true
		}
	}
	if !failed {
		t.Error("C-RL-9 stayed green against a guard that probes an env-derived path")
	}
}

// A driver that advertises features.runLock while the suite has no EnvRunner is
// a broken gate, and a broken gate is RED — never a skip (an unobserved gate is
// not a gate).
func TestCRL9_MissingEnvRunnerIsRedNotSkipped(t *testing.T) {
	dir := t.TempDir()
	d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true}
	o := Options{Driver: "fake", LockDir: dir}
	o.newClient = func(engine string) *mdriver.Client {
		return mdriver.NewClient("fake", engine, "docker", nil,
			func(ctx context.Context, _ string, args []string) ([]byte, []byte, int, error) {
				raw, err := d.runner()(ctx, args...)
				if err != nil {
					return nil, nil, 0, err
				}
				return raw.Stdout, nil, raw.Exit, nil
			})
	}
	rep := RunWith(context.Background(), d.runner(), "docker", o) // no EnvRunner

	got := named(rep, "C-RL-9")
	if len(got) == 0 {
		t.Fatal("C-RL-9 did not run (or report) at all — the missing wiring was silently skipped")
	}
	for _, r := range got {
		if r.Skip {
			t.Errorf("%s reported as SKIP — a wiring hole must be a FAILURE", r.Name)
		}
		if r.Pass {
			t.Errorf("%s reported as PASS with no EnvRunner to check with", r.Name)
		}
	}
}

// C-CAPS-2 is graduated like C-CAPS-1: absent block = visible SKIP (consumers
// keep their gated constants); a PRESENT block is held to the contract's shape —
// a malformed one is RED because every consumer that asks instead of hardcoding
// trusts it. Well-formed values here are the 2026-07-16 measured YDB numbers;
// the well-formed fake carries a truth-matching engine sim because a
// shape-clean block now flows on into the live at-limit probes
// (capslive_test.go owns those cases — this test grades the SHAPE result only,
// by its exact name).
func TestCapsLimits_ShapeGate(t *testing.T) {
	// node out-carries string + bogus kind + missing mnemonics
	const bad = `{"maxString":1024,"maxNodeValue":16368,"maxNodeValueKind":"vibes",` +
		`"maxKeyBytes":1019,"maxSubscripts":31,"evalEnvelope":32635,"loadBodyBytes":97275}`
	cases := []struct {
		name, limits, want string
	}{
		{"absent skips", "", "skip"},
		{"well-formed passes", "good", "pass"},
		{"malformed is red", bad, "fail"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			d := runLockDriver{dir: dir, key: "ydb.docker.vehu", advertise: true, limits: tc.limits}
			if tc.limits == "good" {
				d = capsLiveFake(t, dir, ydbMeasured(), ydbMeasured())
			}
			rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})
			r := one(t, rep, "C-CAPS-2 caps.limits is honest")
			state := "fail"
			if r.Skip {
				state = "skip"
			} else if r.Pass {
				state = "pass"
			}
			if state != tc.want {
				t.Errorf("C-CAPS-2 = %s, want %s — %s", state, tc.want, r.Detail)
			}
		})
	}
}
