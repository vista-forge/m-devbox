package conformance

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"testing"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// engineSim emulates an M engine behind the fake driver for the C-CAPS-2 live
// probe idioms — with its own REAL limits, independent of what the fake's caps
// DECLARE. That split is the whole point: a fake that declares more than its
// sim carries is the planted-wrong-declaration negative control, and the gate
// is proven by watching it fire.
type engineSim struct {
	real   mdriver.Limits
	staged map[string]string // routine name → staged body
	// observability for the tests
	unstaged bool
}

var justifyN = regexp.MustCompile(`\$justify\("",(\d+)\)`)
var evalEnvShape = regexp.MustCompile(`^write "CAPS2ENV=",\$length\("(A*)"\),!$`)

// handle emulates one exec-axis call. Returns handled=false for commands the
// run-lock cases own (e.g. `set x=1`).
func (e *engineSim) handle(verb string, rest []string, cmd string) (RawResult, bool) {
	switch verb {
	case "eval":
		if len(rest) == 0 {
			return RawResult{}, false
		}
		return e.eval(rest[0], cmd)
	case "load":
		if len(rest) == 0 {
			return RawResult{}, false
		}
		body, err := os.ReadFile(rest[0])
		if err != nil {
			return failEnv("NO_SOURCE", 2, cmd), true
		}
		if len(body) > e.real.LoadBodyBytes {
			// The measured docker-lane failure mode: the spawn refuses LOUDLY.
			return simFault("E2BIG: argument list too long", cmd), true
		}
		if e.staged == nil {
			e.staged = map[string]string{}
		}
		name := strings.TrimSuffix(filepath.Base(rest[0]), ".m")
		e.staged[name] = string(body)
		return env(true, 0, fmt.Sprintf(`{"loaded":[%q],"compiled":true}`, name), cmd), true
	case "run":
		if len(rest) == 0 {
			return RawResult{}, false
		}
		tag, routine, ok := strings.Cut(rest[0], "^")
		if !ok {
			return RawResult{}, false
		}
		body, staged := e.staged[routine]
		if !staged || !strings.Contains(body, tag) {
			return simFault("NOROUTINE", cmd), true
		}
		if strings.Contains(body, `write "CAPS2LOAD=1",!`) {
			return env(true, 0, `{"stdout":"CAPS2LOAD=1\n","status":0}`, cmd), true
		}
		return env(true, 0, `{"stdout":"","status":0}`, cmd), true
	case "unstage":
		e.unstaged = true
		e.staged = nil
		return env(true, 0, `{"removed":true}`, cmd), true
	}
	return RawResult{}, false
}

func (e *engineSim) eval(m, cmd string) (RawResult, bool) {
	// The eval-envelope probe: the whole command literal must survive the lane.
	if g := evalEnvShape.FindStringSubmatch(m); g != nil {
		if len(m) > e.real.EvalEnvelope {
			// A truncated command breaks the string literal — a fault, never silence.
			return simFault("SYNTAX: unterminated string (lane truncated the command)", cmd), true
		}
		return env(true, 0, fmt.Sprintf(`{"stdout":"CAPS2ENV=%d\n","status":0}`, len(g[1])), cmd), true
	}
	g := justifyN.FindStringSubmatch(m)
	if g == nil {
		return RawResult{}, false
	}
	n, err := strconv.Atoi(g[1])
	if err != nil {
		return RawResult{}, false
	}
	switch m {
	case maxStringProbe(n):
		if n > e.real.MaxString {
			return simFault(e.real.FaultMnemonics["oversize-string"], cmd), true
		}
		return env(true, 0, fmt.Sprintf(`{"stdout":"CAPS2STR=1;L=%d\n","status":0}`, n), cmd), true
	case maxNodeValueProbe(n):
		if n > e.real.MaxString {
			return simFault(e.real.FaultMnemonics["oversize-string"], cmd), true
		}
		if n > e.real.MaxNodeValue {
			return simFault(e.real.FaultMnemonics["oversize-node"], cmd), true
		}
		return env(true, 0, fmt.Sprintf(`{"stdout":"CAPS2NODE=1;L=%d\n","status":0}`, n), cmd), true
	}
	return RawResult{}, false
}

// simFault is an engine-fault envelope: ok=false on the engine-fault rung with
// a structured engineError carrying the mnemonic, the way both drivers render
// a runtime fault (contract §7).
func simFault(mnemonic, cmd string) RawResult {
	e := Envelope{
		SchemaVersion: "1.0", Command: cmd, OK: false, Exit: 5,
		Data:        json.RawMessage(`null`),
		Error:       &EnvError{Code: "ENGINE_FAULT", Exit: 5, Message: mnemonic},
		EngineError: &mdriver.EngineError{Mnemonic: mnemonic, Text: mnemonic},
	}
	b, _ := json.Marshal(e)
	return RawResult{Stdout: b, Exit: 5}
}

// ydbMeasured is the 2026-07-16 measured YDB docker-lane block (the reference
// true declaration for these tests).
func ydbMeasured() mdriver.Limits {
	return mdriver.Limits{
		MaxString:        1048576,
		MaxNodeValue:     16368,
		MaxNodeValueKind: "region-config",
		MaxKeyBytes:      1019,
		MaxSubscripts:    31,
		EvalEnvelope:     32635,
		LoadBodyBytes:    97275,
		FaultMnemonics: map[string]string{
			"oversize-string":     "MAXSTRLEN",
			"oversize-node":       "REC2BIG",
			"oversize-key":        "GVSUBOFLOW",
			"too-many-subscripts": "MAXNRSUBSCRIPTS",
		},
	}
}

func limitsJSON(t *testing.T, l mdriver.Limits) string {
	t.Helper()
	b, err := json.Marshal(l)
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}

// capsLiveFake is a run-lock-enforcing fake whose sim carries the engine's
// measured limits and whose caps declare `declared`.
func capsLiveFake(t *testing.T, dir string, declared, measured mdriver.Limits) runLockDriver {
	t.Helper()
	return runLockDriver{
		dir: dir, key: "ydb.docker.vehu", advertise: true,
		limits:         limitsJSON(t, declared),
		execVerbs:      []string{"eval", "load", "run", "unstage"},
		managedStaging: true,
		sim:            &engineSim{real: measured},
	}
}

var liveProbeNames = []string{
	"C-CAPS-2 [maxString at-limit]",
	"C-CAPS-2 [evalEnvelope at-limit]",
	"C-CAPS-2 [maxNodeValue at-limit]",
	"C-CAPS-2 [loadBodyBytes at-limit]",
}

// one returns the single result whose name is exactly `name` (not the
// per-call envelope entries, which carry suffixed labels).
func one(t *testing.T, rep Report, name string) Result {
	t.Helper()
	var out []Result
	for _, r := range rep.Results {
		if r.Name == name {
			out = append(out, r)
		}
	}
	if len(out) != 1 {
		t.Fatalf("%s: ran %d times, want exactly 1", name, len(out))
	}
	return out[0]
}

// A true declaration passes: every probeable limit is re-measured at-limit
// over the connection and comes back clean, and the load probe leaves the
// engine unstaged (greenfield).
func TestCapsLive_TrueDeclarationPasses(t *testing.T) {
	dir := t.TempDir()
	d := capsLiveFake(t, dir, ydbMeasured(), ydbMeasured())
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	for _, r := range rep.Results {
		if !r.Pass && !r.Skip {
			t.Errorf("FAIL %s — %s", r.Name, r.Detail)
		}
	}
	for _, name := range liveProbeNames {
		if r := one(t, rep, name); !r.Pass {
			t.Errorf("%s: pass=%v skip=%v — %s", name, r.Pass, r.Skip, r.Detail)
		}
	}
	if !d.sim.unstaged {
		t.Error("the load probe did not unstage — a leaked mtest- stage is not greenfield")
	}
}

// THE NEGATIVE CONTROL (a gate is proven by firing): a declaration one byte
// past what the engine actually carries must be OBSERVED RED on exactly the
// probe that covers it. This is the dangerous direction — a consumer trusting
// the declared number would build a payload the engine faults on.
func TestCapsLive_PlantedWrongDeclarationIsRed(t *testing.T) {
	cases := []struct {
		field string
		bump  func(*mdriver.Limits)
		probe string
	}{
		{"maxString", func(l *mdriver.Limits) { l.MaxString++ }, "C-CAPS-2 [maxString at-limit]"},
		{"evalEnvelope", func(l *mdriver.Limits) { l.EvalEnvelope++ }, "C-CAPS-2 [evalEnvelope at-limit]"},
		{"maxNodeValue", func(l *mdriver.Limits) { l.MaxNodeValue++ }, "C-CAPS-2 [maxNodeValue at-limit]"},
		{"loadBodyBytes", func(l *mdriver.Limits) { l.LoadBodyBytes++ }, "C-CAPS-2 [loadBodyBytes at-limit]"},
	}
	for _, tc := range cases {
		t.Run(tc.field, func(t *testing.T) {
			dir := t.TempDir()
			declared := ydbMeasured()
			tc.bump(&declared)
			d := capsLiveFake(t, dir, declared, ydbMeasured())
			rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

			r := one(t, rep, tc.probe)
			if r.Pass || r.Skip {
				t.Fatalf("%s declared past the engine's real cap was NOT red (pass=%v skip=%v) — the gate did not fire", tc.field, r.Pass, r.Skip)
			}
			if r.Detail == "" {
				t.Error("a red probe must explain itself")
			}
			// The other probes stay green: the finding is precise, not a cascade.
			for _, name := range liveProbeNames {
				if name == tc.probe {
					continue
				}
				if other := one(t, rep, name); !other.Pass {
					t.Errorf("%s went red alongside the planted %s — want a precise finding, got a cascade: %s", name, tc.field, other.Detail)
				}
			}
		})
	}
}

// loadBodyBytes=0 is a measured verdict (no cliff found at package scale),
// not an unknown — there is nothing to probe at-limit, and that is a VISIBLE
// skip, never a silent pass.
func TestCapsLive_NoCliffLaneSkipsLoadProbe(t *testing.T) {
	dir := t.TempDir()
	l := ydbMeasured()
	l.LoadBodyBytes = 0
	d := capsLiveFake(t, dir, l, l)
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	r := one(t, rep, "C-CAPS-2 [loadBodyBytes at-limit]")
	if !r.Skip {
		t.Fatalf("loadBodyBytes=0 must be a visible SKIP, got pass=%v — %s", r.Pass, r.Detail)
	}
	if !strings.Contains(r.Detail, "no-cliff") {
		t.Errorf("the skip must say the 0 is a measured verdict: %q", r.Detail)
	}
	if rep.Fail != 0 {
		t.Errorf("a no-cliff lane must stay green, got %d failures", rep.Fail)
	}
}

// A driver declaring loadBodyBytes>0 on a connection that does not advertise
// exec load+run is describing a lane the connection does not have — RED, not
// a skip: the declaration itself is the defect.
func TestCapsLive_LoadDeclaredWithoutLoadVerbIsRed(t *testing.T) {
	dir := t.TempDir()
	d := capsLiveFake(t, dir, ydbMeasured(), ydbMeasured())
	d.execVerbs = []string{"eval"} // no load/run/unstage on this connection
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	r := one(t, rep, "C-CAPS-2 [loadBodyBytes at-limit]")
	if r.Pass || r.Skip {
		t.Fatalf("loadBodyBytes>0 with no exec load advertised must be RED, got pass=%v skip=%v", r.Pass, r.Skip)
	}
}

// A malformed block is the SHAPE gate's finding; the live probes must not
// pile assertions on top of nonsense values.
func TestCapsLive_MalformedShapeSuppressesLiveProbes(t *testing.T) {
	dir := t.TempDir()
	bad := ydbMeasured()
	bad.MaxNodeValueKind = "vibes"
	d := capsLiveFake(t, dir, bad, ydbMeasured())
	rep := runFake(t, d, Options{Driver: "fake", LockDir: dir})

	if r := one(t, rep, "C-CAPS-2 caps.limits is honest"); r.Pass || r.Skip {
		t.Fatal("the malformed block did not red the shape gate")
	}
	for _, name := range liveProbeNames {
		if got := named(rep, name); len(got) != 0 {
			t.Errorf("%s ran over a malformed block", name)
		}
	}
}

// The probe builders hold their byte-exactness contracts: the eval-envelope
// command and the load body are EXACTLY the declared size (the whole point of
// an at-limit probe), and the load body ends with the verdict tag.
func TestCapsLive_ProbeBuildersAreByteExact(t *testing.T) {
	for _, n := range []int{64, 4096, 32635, 65535, 97275} {
		cmd, want, ok := evalEnvelopeProbe(n)
		if !ok {
			t.Fatalf("evalEnvelopeProbe(%d) refused", n)
		}
		if len(cmd) != n {
			t.Errorf("evalEnvelopeProbe(%d) built %d bytes", n, len(cmd))
		}
		if want == "" {
			t.Errorf("evalEnvelopeProbe(%d): empty verdict", n)
		}
		body, ok := loadBodyProbe(n)
		if n >= 200 { // below the skeleton size the builder refuses, honestly
			if !ok {
				t.Fatalf("loadBodyProbe(%d) refused", n)
			}
			if len(body) != n {
				t.Errorf("loadBodyProbe(%d) built %d bytes", n, len(body))
			}
			if !strings.HasSuffix(body, "capsv ; verdict tag at the END of the body\n write \"CAPS2LOAD=1\",!\n quit\n") {
				t.Errorf("loadBodyProbe(%d): verdict tag is not the END of the body", n)
			}
		}
	}
	if _, _, ok := evalEnvelopeProbe(8); ok {
		t.Error("evalEnvelopeProbe must refuse a size too small to carry the probe")
	}
}
