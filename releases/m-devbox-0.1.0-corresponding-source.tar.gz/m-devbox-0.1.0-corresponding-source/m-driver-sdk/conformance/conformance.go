// Package conformance is the executable definition of the m engine-driver
// contract (driver-contract.md §9). It drives a driver *binary* over the same
// subprocess + JSON-envelope seam m-cli uses — `m-<engine> <axis> <verb>
// --output json` — and asserts the driver speaks the contract: well-formed
// envelopes, the exit-code ladder, an honest capability document, and reachable
// meta/lifecycle verbs. A driver is contract-complete only when it passes, which
// is what lets m-cli trust any engine sight unseen (contract §9, coherence C6).
//
// The suite is caps-driven: it reads `meta caps` and exercises only the verbs a
// driver advertises, so it is engine-agnostic and honest by construction. It is
// stdlib-only (the SDK stays dependency-free); the Runner seam lets unit tests
// drive it with canned envelopes and production drive a real binary via
// ExecRunner.
package conformance

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"strings"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// RawResult is one driver invocation's captured output and process exit code.
//
// Stderr is captured because clikit renders a FAIL-PATH envelope to STDERR, not
// stdout (a known deviation from contract §2's "one JSON envelope to stdout"). The
// SDK's production Client.call already falls back to stderr for exactly this reason —
// and v0.8.0's conformance harness did not, so the first cases to exercise a REFUSAL
// (C-RL-1/3/4) reported FAIL against drivers that refuse perfectly. Measured on the
// wire by the m-ydb spike:
//
//	$ m-ydb exec eval "set x=1" --output json      # no bracket held
//	  stdout: (empty)                    exit: 4
//	  stderr: {"ok":false,"exit":4,"error":{"code":"RUN_LOCK_REQUIRED",…}}
//
// A harness that cannot see a refusal cannot gate a lock whose whole purpose is to
// refuse.
type RawResult struct {
	Stdout []byte
	Stderr []byte
	Exit   int
}

// envelopeBytes returns the stream carrying the JSON envelope: stdout normally, else
// stderr (the Fail path). Mirrors Client.call.
func (r RawResult) envelopeBytes() []byte {
	if len(bytes.TrimSpace(r.Stdout)) > 0 {
		return r.Stdout
	}
	return r.Stderr
}

// Runner invokes the driver with the given contract args (e.g. "meta","caps")
// and returns its stdout + process exit. A non-zero engine exit is a result, not
// a Go error; an error means the driver could not be launched at all.
type Runner func(ctx context.Context, args ...string) (RawResult, error)

// EnvRunner invokes the driver like Runner but with extraEnv entries appended to
// the driver process environment, overriding inherited values (os/exec keeps the
// LAST duplicate key). It is the seam C-RL-9 dresses a hostile $HOME with, per
// call, without touching the suite's own environment (RK-3).
type EnvRunner func(ctx context.Context, extraEnv []string, args ...string) (RawResult, error)

// Envelope is the clikit JSON envelope every driver writes (contract §2). data is
// decoded per-verb into the SDK shapes.
type Envelope struct {
	SchemaVersion string               `json:"schemaVersion"`
	Command       string               `json:"command"`
	OK            bool                 `json:"ok"`
	Exit          int                  `json:"exit"`
	Data          json.RawMessage      `json:"data"`
	Error         *EnvError            `json:"error,omitempty"`
	EngineError   *mdriver.EngineError `json:"engineError,omitempty"`
}

// EnvError is the envelope's error object (contract §2, ok=false).
type EnvError struct {
	Code    string `json:"code"`
	Exit    int    `json:"exit"`
	Message string `json:"message"`
	Hint    string `json:"hint"`
}

// Result is one conformance assertion outcome.
//
// Skip is a THIRD outcome, not a flavor of pass: a case the driver's advertised
// capabilities put out of scope was never asserted, and a suite that reported it
// as green would be claiming a check it did not make (undeclared-seams P-B — an
// unobserved gate is not a gate). Skip and Pass are therefore mutually exclusive,
// and Detail always says why.
type Result struct {
	Name   string `json:"name"`
	Pass   bool   `json:"pass"`
	Skip   bool   `json:"skip,omitempty"`
	Detail string `json:"detail,omitempty"`
}

// Report is the suite outcome for one driver+transport. Skip is reported
// separately from Pass so a reader (and the meta-gate) can see how much of the
// contract this driver actually stood for.
type Report struct {
	Transport string   `json:"transport"`
	Engine    string   `json:"engine,omitempty"`
	Results   []Result `json:"results"`
	Pass      int      `json:"pass"`
	Fail      int      `json:"fail"`
	Skip      int      `json:"skip"`
}

// Options configures the parts of the suite that need to reach the driver as a
// CLIENT rather than as a bare verb runner — today, the run-lock cases, which
// must open a real bracket before they can prove the driver honors it.
type Options struct {
	// Driver is the path to the driver binary. REQUIRED when the driver advertises
	// features.runLock: without it the suite cannot acquire a bracket, and that is
	// reported as a FAILURE, never as a skip — a gate that silently does not run is
	// the defect, not the excuse.
	Driver string
	// LockDir points the run-lock cases at a fixture lock home instead of the real
	// one. TEST-BINARY FIXTURES ONLY: since L0.B1 every dir override is refused in
	// a production binary (RUN_LOCK_DIR_FORBIDDEN), so a live suite always brackets
	// the REAL passwd-derived domain — which is the point: a conformance proof
	// against a sandbox home is a self-report about a domain nobody serializes on.
	LockDir string

	// EnvRunner invokes the driver with per-call environment overrides — REQUIRED
	// (like Driver) when the driver advertises features.runLock: C-RL-9 proves the
	// lock domain's $HOME-immunity by re-deriving the ref under a hostile $HOME,
	// which the plain Runner cannot express. nil while runLock is advertised is a
	// suite-wiring FAILURE, never a skip.
	EnvRunner EnvRunner

	// PeerTransport is a SECOND route to the SAME engine instance — the whole point
	// of C-RL-7, the R-9 red-proof. On this box the iris lab pair is exactly that:
	// foia-t12 is reachable as `--transport docker --container foia-t12` AND as
	// `--transport remote` (Atelier on 127.0.0.1:52773). Both must derive a
	// BYTE-EQUAL runlock-path, or the run-lock does not serialize the very
	// healthcheck lane it exists to protect.
	//
	// Empty ⇒ C-RL-7 is a VISIBLE SKIP ("no dual route configured"), never a pass.
	PeerTransport string
	// PeerArgs are extra connection flags the peer route needs (e.g. --container).
	PeerArgs []string

	// UnresolvableArgs make the route unresolvable (e.g. an Atelier base-URL pointing
	// at a dead port). C-RL-8 asserts the driver then REFUSES with
	// RUN_LOCK_UNRESOLVED rather than falling through to a selector-spelled key —
	// which is what would reintroduce the R-9 split exactly when the box is degraded.
	//
	// Empty ⇒ C-RL-8 is a VISIBLE SKIP.
	UnresolvableArgs []string

	// newClient builds the driver client the run-lock cases bracket with. nil = the
	// production subprocess client over Driver; the SDK's own tests inject a fake.
	newClient func(engine string) *mdriver.Client
}

// validExit is the contract's exit-code ladder (contract §2).
var validExit = map[int]bool{0: true, 2: true, 3: true, 4: true, 5: true, 6: true, 7: true}

type suite struct {
	run       Runner
	runEnv    EnvRunner // per-call env override seam (C-RL-9); may be nil
	transport string
	results   []Result
	caps      *mdriver.Caps
	// limitsShapeOK records checkCapsLimits' verdict: the live at-limit probes
	// (checkCapsLimitsLive) run only over a shape-clean block — probing a
	// malformed declaration would assert nonsense on top of an already-red gate.
	limitsShapeOK bool
}

// Run executes the conformance suite against a driver via run, for transport. It
// is the back-compatible entry point (both drivers' `meta selftest` call it); the
// run-lock cases need a driver path, so use RunWith to exercise them.
func Run(ctx context.Context, run Runner, transport string) Report {
	return RunWith(ctx, run, transport, Options{})
}

// RunWith executes the conformance suite with the extra wiring the run-lock cases
// need.
func RunWith(ctx context.Context, run Runner, transport string, o Options) Report {
	s := &suite{run: run, runEnv: o.EnvRunner, transport: transport}
	s.checkCaps(ctx)
	// The remaining checks are caps-driven: only advertised verbs are exercised.
	if s.caps != nil {
		if has(s.caps.Axes.Meta, "version") {
			s.checkVersion(ctx)
		}
		if has(s.caps.Axes.Meta, "doctor") {
			s.checkDoctor(ctx)
		}
		if has(s.caps.Axes.Lifecycle, "status") {
			s.checkLifecycleStatus(ctx)
		}
		s.checkVerbClasses()
		s.checkCapsConnection()
		s.limitsShapeOK = s.checkCapsLimits()
		s.checkRunLock(ctx, o)
		// A limits-advertising driver that does NOT enforce the run-lock is
		// probed tokenless here; an enforcing driver is probed inside the
		// bracket checkRunLock opens (its probes are mutating verbs).
		if s.caps.Limits != nil && s.limitsShapeOK && !s.caps.Features.RunLock {
			s.checkCapsLimitsLive(ctx, "", o)
		}
	}
	return s.report()
}

// checkVerbClasses is the classification coverage red-gate (contract §5.8): every
// verb a driver ADVERTISES must carry a class in the SDK registry, because the
// class is what its dispatch middleware keys the run-lock check off. An
// unclassified verb is a verb that cannot be enforced — so adding one goes red,
// and the taxonomy question gets asked at add-time instead of leaving a hole for
// the next hurried helper to walk through.
//
// This check is NOT capability-gated: it is about whether the contract can express
// the driver's surface at all, which is true whether or not the driver enforces
// the lock yet.
func (s *suite) checkVerbClasses() {
	missing := mdriver.UnclassifiedVerbs(*s.caps)
	s.report0("verb classes: every advertised verb is classified", len(missing) == 0,
		"advertised but unclassified (add them to mdriver's registry and decide their run-lock class): "+strings.Join(missing, ", "))
}

// call invokes a verb, decodes + validates the universal envelope discipline
// (contract §2), records a pass/fail for that discipline, and returns the parsed
// envelope (nil if the call could not be made or the envelope was unusable).
func (s *suite) call(ctx context.Context, label string, args ...string) *Envelope {
	raw, err := s.run(ctx, args...)
	return s.decode(label, raw, err)
}

// callEnv is call with per-call environment overrides through the EnvRunner
// seam (C-RL-9). Callers guard s.runEnv != nil.
func (s *suite) callEnv(ctx context.Context, label string, extraEnv []string, args ...string) *Envelope {
	raw, err := s.runEnv(ctx, extraEnv, args...)
	return s.decode(label, raw, err)
}

// decode validates the universal envelope discipline (contract §2) on a raw
// driver result and records the envelope-level verdict under label.
func (s *suite) decode(label string, raw RawResult, err error) *Envelope {
	if err != nil {
		s.fail(label+": launch", fmt.Sprintf("driver could not be launched: %v", err))
		return nil
	}
	var env Envelope
	if jerr := json.Unmarshal(raw.envelopeBytes(), &env); jerr != nil {
		s.fail(label+": envelope", fmt.Sprintf("no JSON envelope on stdout or stderr: %v", jerr))
		return nil
	}
	// Universal envelope discipline (contract §2).
	var problems []string
	if env.SchemaVersion == "" {
		problems = append(problems, "missing schemaVersion")
	}
	if env.Command == "" {
		problems = append(problems, "missing command")
	}
	if !validExit[env.Exit] {
		problems = append(problems, fmt.Sprintf("exit %d not on the ladder", env.Exit))
	}
	if env.Exit != raw.Exit {
		problems = append(problems, fmt.Sprintf("envelope.exit %d != process exit %d", env.Exit, raw.Exit))
	}
	if env.OK != (env.Exit == 0) {
		problems = append(problems, fmt.Sprintf("ok=%v inconsistent with exit=%d", env.OK, env.Exit))
	}
	// A non-ok envelope must explain itself — via an error object (the Fail path)
	// OR a data payload (the doctor/lint "data + non-zero exit" report). Bare
	// ok=false with neither is unexplained. A JSON `null` data field (how a nil
	// RawMessage round-trips, since the envelope's data has no omitempty) counts
	// as no data.
	if !env.OK && env.Error == nil && isBlankJSON(env.Data) {
		problems = append(problems, "ok=false but neither error nor data")
	}
	if len(problems) > 0 {
		s.fail(label+": envelope", strings.Join(problems, "; "))
	} else {
		s.pass(label + ": envelope")
	}
	return &env
}

// isBlankJSON reports whether a RawMessage carries no payload: empty, all
// whitespace, or a literal `null` (a nil json.RawMessage marshals to `null`).
func isBlankJSON(r json.RawMessage) bool {
	t := bytes.TrimSpace(r)
	return len(t) == 0 || string(t) == "null"
}

func (s *suite) checkCaps(ctx context.Context) {
	env := s.call(ctx, "caps", "meta", "caps")
	if env == nil {
		return
	}
	if !env.OK {
		s.fail("caps: ok", "meta caps returned ok=false")
		return
	}
	var c mdriver.Caps
	if err := json.Unmarshal(env.Data, &c); err != nil {
		s.fail("caps: parse", fmt.Sprintf("caps data not a capability document: %v", err))
		return
	}
	s.caps = &c
	s.report0("caps: engine", c.Engine != "", "engine name is empty")
	s.report0("caps: contract major",
		major(c.Contract) == major(mdriver.ContractVersion),
		fmt.Sprintf("contract %q major != SDK %q", c.Contract, mdriver.ContractVersion))
	s.report0("caps: transports non-empty", len(c.Transports) > 0, "transports list is empty")
	s.report0("caps: advertises tested transport",
		has(c.Transports, s.transport),
		fmt.Sprintf("transport %q not in advertised %v", s.transport, c.Transports))
	s.report0("caps: features.remote honest",
		c.Features.Remote == has(c.Transports, mdriver.TransportRemote),
		fmt.Sprintf("features.remote=%v but transports remote=%v", c.Features.Remote, has(c.Transports, mdriver.TransportRemote)))
	s.report0("caps: meta self-listing",
		has(c.Axes.Meta, "caps") && has(c.Axes.Meta, "version"),
		"meta axis must list at least caps and version")
	// Honest axes: no axis may be present-but-empty. A JSON `[]` unmarshals to a
	// non-nil empty slice (absent → nil), so non-nil && len 0 = dishonest. (Can't
	// use Axes.Wired(), which filters len>0 and would hide exactly this.)
	emptyAxis := ""
	for _, av := range []struct {
		name string
		v    []string
	}{
		{"lifecycle", c.Axes.Lifecycle}, {"sync", c.Axes.Sync}, {"exec", c.Axes.Exec},
		{"data", c.Axes.Data}, {"cover", c.Axes.Cover}, {"admin", c.Axes.Admin}, {"meta", c.Axes.Meta},
	} {
		if av.v != nil && len(av.v) == 0 {
			emptyAxis = av.name
		}
	}
	s.report0("caps: no empty axes", emptyAxis == "", "axis advertised but empty: "+emptyAxis)
}

func (s *suite) checkVersion(ctx context.Context) {
	env := s.call(ctx, "version", "meta", "version")
	if env == nil || !env.OK {
		s.fail("version: ok", "meta version did not return ok")
		return
	}
	// Only engine + contract are cross-checked against caps (the m-cli-relevant
	// invariant); driver/build shape is left free.
	var v struct {
		Engine   string `json:"engine"`
		Contract string `json:"contract"`
	}
	if err := json.Unmarshal(env.Data, &v); err != nil {
		s.fail("version: parse", err.Error())
		return
	}
	s.report0("version: engine matches caps",
		s.caps == nil || v.Engine == s.caps.Engine,
		fmt.Sprintf("version.engine %q != caps.engine", v.Engine))
	s.report0("version: contract matches caps",
		s.caps == nil || v.Contract == s.caps.Contract,
		fmt.Sprintf("version.contract %q != caps.contract", v.Contract))
}

func (s *suite) checkDoctor(ctx context.Context) {
	env := s.call(ctx, "doctor", "meta", "doctor")
	if env == nil {
		return
	}
	// doctor may legitimately be ok=false (a failed check / unreachable): exit
	// 0/5/6 only. The envelope discipline already checked the ladder + ok⟺exit.
	s.report0("doctor: exit", env.Exit == 0 || env.Exit == 5 || env.Exit == 6,
		fmt.Sprintf("doctor exit %d, want 0/5/6", env.Exit))
	var d mdriver.DoctorResult
	if err := json.Unmarshal(env.Data, &d); err != nil {
		s.fail("doctor: parse", err.Error())
		return
	}
	s.report0("doctor: has checks", len(d.Checks) > 0, "doctor returned no checks")
}

func (s *suite) checkLifecycleStatus(ctx context.Context) {
	env := s.call(ctx, "status", "lifecycle", "status")
	if env == nil {
		return
	}
	var st mdriver.Status
	if err := json.Unmarshal(env.Data, &st); err != nil {
		s.fail("status: parse", err.Error())
		return
	}
	// Healthy must imply running — a driver cannot be healthy-but-down.
	s.report0("status: healthy implies running", !st.Healthy || st.Running,
		"status reports healthy=true but running=false")
}

// --- result bookkeeping ------------------------------------------------------

func (s *suite) pass(name string) { s.results = append(s.results, Result{Name: name, Pass: true}) }
func (s *suite) fail(name, detail string) {
	s.results = append(s.results, Result{Name: name, Pass: false, Detail: detail})
}

// skip records a case the driver's advertised capabilities put out of scope. It
// is NEVER a pass: reason is mandatory, and the report counts it apart.
func (s *suite) skip(name, reason string) {
	s.results = append(s.results, Result{Name: name, Pass: false, Skip: true, Detail: reason})
}

func (s *suite) report0(name string, ok bool, failDetail string) {
	if ok {
		s.pass(name)
	} else {
		s.fail(name, failDetail)
	}
}

func (s *suite) report() Report {
	r := Report{Transport: s.transport, Results: s.results}
	if s.caps != nil {
		r.Engine = s.caps.Engine
	}
	for _, res := range s.results {
		switch {
		case res.Skip:
			r.Skip++
		case res.Pass:
			r.Pass++
		default:
			r.Fail++
		}
	}
	return r
}

func has(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

func major(version string) string {
	if i := strings.IndexByte(version, '.'); i >= 0 {
		return version[:i]
	}
	return version
}

// ExecRunner returns a Runner that invokes a real driver binary at path, passing
// `<args…> --transport <transport> --output json` and inheriting the process
// environment (the driver reads its M_<ENGINE>_* connection from there). Stdout
// is captured; stderr is discarded (diagnostics, contract §2).
func ExecRunner(path, transport string) Runner {
	run := ExecEnvRunner(path, transport)
	return func(ctx context.Context, args ...string) (RawResult, error) {
		return run(ctx, nil, args...)
	}
}

// ExecEnvRunner is ExecRunner with the per-call env-override seam (RK-3): the
// driver subprocess inherits this process's environment PLUS extraEnv, whose
// entries win over inherited duplicates (os/exec keeps the last value per key).
// C-RL-9 uses it to dress a single call in a hostile $HOME.
func ExecEnvRunner(path, transport string) EnvRunner {
	return func(ctx context.Context, extraEnv []string, args ...string) (RawResult, error) {
		full := append([]string{}, args...)
		full = append(full, "--transport", transport, "--output", "json")
		cmd := exec.CommandContext(ctx, path, full...)
		if len(extraEnv) > 0 {
			cmd.Env = append(os.Environ(), extraEnv...)
		}
		var out, errb bytes.Buffer
		cmd.Stdout, cmd.Stderr = &out, &errb
		err := cmd.Run()
		if err != nil {
			var ee *exec.ExitError
			if errors.As(err, &ee) {
				return RawResult{Stdout: out.Bytes(), Stderr: errb.Bytes(), Exit: ee.ExitCode()}, nil
			}
			return RawResult{}, err
		}
		return RawResult{Stdout: out.Bytes(), Stderr: errb.Bytes(), Exit: 0}, nil
	}
}
