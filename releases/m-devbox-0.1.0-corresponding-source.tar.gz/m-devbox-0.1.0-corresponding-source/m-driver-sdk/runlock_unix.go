//go:build unix

package mdriver

import (
	"bufio"
	"errors"
	"os"
	"strconv"
	"strings"
	"syscall"
)

// The kernel half of the run-lock: flock(2) is the only truth of held-ness, and
// /proc/locks is the measurement of WHO holds it — the kernel's answer, not a
// self-report (R-5's trust order). Everything here is a measurement; nothing here
// makes a decision.

// flockTry takes an EXCLUSIVE, NON-BLOCKING lock. ok=false means another open
// file description holds it. It never blocks — which is what lets the driver's
// dispatch check verify ownership without ever waiting on the lock (§7.3).
//
// flock is per open-file-description, not per process: a fresh open() of a file
// this same process already holds via another FD is correctly denied. That is why
// an in-process probe sees "held", and why closing a probe's FD cannot release
// the holder's lock.
func flockTry(f *os.File) (bool, error) {
	for {
		err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB)
		switch {
		case err == nil:
			return true, nil
		case errors.Is(err, syscall.EWOULDBLOCK): // == EAGAIN: held by someone else
			return false, nil
		case errors.Is(err, syscall.EINTR):
			continue
		default:
			return false, err
		}
	}
}

func flockUnlock(f *os.File) error {
	for {
		err := syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
		if errors.Is(err, syscall.EINTR) {
			continue
		}
		return err
	}
}

// processGroup is the holder's pgid — recorded so the mechanized triage can print
// a `kill -9 -- -<pgid>` that reaps the whole frozen run, not just its leader (a
// host-killed leader leaves its `docker exec` children behind).
func processGroup() int {
	pgid, err := syscall.Getpgid(os.Getpid())
	if err != nil {
		return 0
	}
	return pgid
}

// holderStateFn reads a process's state letter and command from /proc. It is a
// var so a test can simulate a STOPPED holder without SIGSTOPping itself.
var holderStateFn = procState

// lockHolders resolves the lock file's dev:inode in /proc/locks to the PIDs the
// KERNEL says hold it. This is what makes "held by a dead process" visible rather
// than mysterious: an inherited FD in a surviving child shows up here as the real
// holder, even though the acquirer is gone.
//
// A best-effort measurement: on a kernel without /proc it returns nothing, and
// the caller falls back to the record's (self-reported) PID. It never fabricates
// a holder.
func lockHolders(path string) []RunLockHolder {
	var st syscall.Stat_t
	if err := syscall.Stat(path, &st); err != nil {
		return nil
	}
	f, err := os.Open("/proc/locks")
	if err != nil {
		return nil
	}
	defer func() { _ = f.Close() }()

	//nolint:unconvert // st.Dev is not uint64 on every unix (int32 on darwin) — the conversion is load-bearing off linux.
	wantMaj, wantMin, wantIno := devMajor(uint64(st.Dev)), devMinor(uint64(st.Dev)), uint64(st.Ino)

	var out []RunLockHolder
	seen := map[int]bool{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 6 {
			continue
		}
		// "1: FLOCK  ADVISORY  WRITE 12345 08:02:1234567 0 EOF"
		// A blocked WAITER is rendered with a "->" marker after the id; it does not
		// hold the lock, so it must never be reported as a holder.
		if fields[1] == "->" {
			continue
		}
		pid, err := strconv.Atoi(fields[4])
		if err != nil || seen[pid] {
			continue
		}
		maj, mnr, ino, ok := parseLockID(fields[5])
		if !ok || maj != wantMaj || mnr != wantMin || ino != wantIno {
			continue
		}
		seen[pid] = true
		state, cmd, _ := holderStateFn(pid)
		out = append(out, RunLockHolder{PID: pid, State: state, Cmd: cmd})
	}
	return out
}

// parseLockID parses /proc/locks' "MAJ:MIN:INO" field (major and minor in hex,
// inode in decimal).
func parseLockID(s string) (maj, mnr, ino uint64, ok bool) {
	parts := strings.Split(s, ":")
	if len(parts) != 3 {
		return 0, 0, 0, false
	}
	maj, err := strconv.ParseUint(parts[0], 16, 64)
	if err != nil {
		return 0, 0, 0, false
	}
	mnr, err = strconv.ParseUint(parts[1], 16, 64)
	if err != nil {
		return 0, 0, 0, false
	}
	ino, err = strconv.ParseUint(parts[2], 10, 64)
	if err != nil {
		return 0, 0, 0, false
	}
	return maj, mnr, ino, true
}

// devMajor/devMinor decode a Linux dev_t the way /proc/locks encodes it.
func devMajor(dev uint64) uint64 { return (dev>>8)&0xfff | ((dev >> 32) &^ 0xfff) }
func devMinor(dev uint64) uint64 { return dev&0xff | ((dev >> 12) &^ 0xff) }

// procState reads /proc/<pid>/stat. found=false means the process is gone (or
// /proc is unavailable — the caller must not read that as "dead", which is why
// pidAlive is a separate, explicit question).
//
// The comm field is parenthesized and may itself contain spaces and parens, so
// the state letter is found after the LAST ')', never by splitting on whitespace.
func procState(pid int) (state, cmd string, found bool) {
	b, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/stat")
	if err != nil {
		return "", "", false
	}
	s := string(b)
	closeIdx := strings.LastIndexByte(s, ')')
	openIdx := strings.IndexByte(s, '(')
	if closeIdx < 0 || openIdx < 0 || closeIdx < openIdx {
		return "", "", false
	}
	cmd = s[openIdx+1 : closeIdx]
	rest := strings.Fields(s[closeIdx+1:])
	if len(rest) == 0 {
		return "", cmd, true
	}
	return rest[0], cmd, true
}

// pidAlive asks whether a recorded holder still exists. Used ONLY to name the
// HELD_BY_ORPHAN_FD case — never to license breaking a lock, which is human-only.
func pidAlive(pid int) bool {
	if _, err := os.Stat("/proc/self/stat"); err != nil {
		return true // no /proc: we cannot measure, so we must not claim it is dead
	}
	_, _, found := holderStateFn(pid)
	return found
}
