package mdriver

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"reflect"
	"testing"
)

// fakeCmd records the last invocation and returns canned streams.
type fakeCmd struct {
	name   string
	args   []string
	stdout []byte
	stderr []byte
	exit   int
	err    error
}

func (f *fakeCmd) run(_ context.Context, name string, args []string) (stdout, stderr []byte, exit int, err error) {
	f.name, f.args = name, args
	return f.stdout, f.stderr, f.exit, f.err
}

// A Fail-path envelope (ok:false, an error, NO engineError) must surface as a
// typed *DriverError — not the zero-value-result + nil-error hole (F5) that let
// a failed stage/exec report a silent 0/0 suite with no diagnostic.
func TestClient_Call_FailEnvelopeSurfacesDriverError(t *testing.T) {
	failEnv := []byte(`{"schemaVersion":"1.0","command":"exec load <paths>","ok":false,"exit":5,` +
		`"error":{"code":"RUNTIME","exit":5,"message":"session: could not parse iris session output","hint":"h"}}`)
	f := &fakeCmd{stdout: failEnv}
	c := NewClient("m-iris", "iris", "docker", nil, f.run)

	_, err := c.Load(context.Background(), []string{"/x/STDJSON.m"})
	if err == nil {
		t.Fatal("Load returned nil error on an ok:false Fail envelope (silent 0/0 hole)")
	}
	var de *DriverError
	if !errors.As(err, &de) {
		t.Fatalf("error is not *DriverError: %T (%v)", err, err)
	}
	if de.Code != "RUNTIME" || de.Exit != 5 || de.Engine != "iris" {
		t.Errorf("DriverError = %+v, want code=RUNTIME exit=5 engine=iris", de)
	}
	if de.Command == "" || de.Message == "" {
		t.Errorf("DriverError missing command/message: %+v", de)
	}
}

// A §7 engine fault (ok:false WITH engineError) stays DATA — no Go error — so the
// wrapper surfaces it in ExecResult.EngineError (the contract: a fault is data).
func TestClient_Call_EngineFaultStaysData(t *testing.T) {
	eng := &EngineError{Mnemonic: "<UNDEF>", Text: "<UNDEF>foo"}
	f := &fakeCmd{stdout: clientEnvBytes(t, "exec eval <command>", false, 5, ExecResult{}, eng)}
	c := NewClient("m-iris", "iris", "docker", nil, f.run)

	r, err := c.ExecEval(context.Background(), "w 1")
	if err != nil {
		t.Fatalf("ExecEval returned a Go error for a §7 fault (should be data): %v", err)
	}
	if r.EngineError == nil || r.EngineError.Mnemonic != "<UNDEF>" {
		t.Errorf("engine fault not surfaced as data: %+v", r.EngineError)
	}
}

// A valid-false result (ok:false, DATA present, NO error field — e.g. doctor
// unhealthy / status down via ResultExit) is NOT a failure: it returns as data,
// no Go error, so callers can read the state.
func TestClient_Call_ValidFalseWithDataIsNotError(t *testing.T) {
	env := []byte(`{"schemaVersion":"1.0","command":"lifecycle status","ok":false,"exit":0,` +
		`"data":{"running":false,"healthy":false}}`)
	f := &fakeCmd{stdout: env}
	c := NewClient("m-iris", "iris", "docker", nil, f.run)

	s, err := c.Status(context.Background())
	if err != nil {
		t.Fatalf("Status returned an error for a valid-false (no error field) envelope: %v", err)
	}
	if s.Running {
		t.Errorf("status data not decoded: %+v", s)
	}
}

// clientEnvBytes builds a clikit-style JSON envelope (the wire shape the client parses).
func clientEnvBytes(t *testing.T, command string, ok bool, exit int, data any, eng *EngineError) []byte {
	t.Helper()
	raw, err := json.Marshal(data)
	if err != nil {
		t.Fatalf("marshal data: %v", err)
	}
	env := map[string]any{
		"schemaVersion": "1.0", "command": command, "ok": ok, "exit": exit,
		"data": json.RawMessage(raw),
	}
	if eng != nil {
		env["engineError"] = eng
	}
	b, err := json.Marshal(env)
	if err != nil {
		t.Fatalf("marshal env: %v", err)
	}
	return b
}

func TestClient_Status_ArgvAndParse(t *testing.T) {
	st := Status{Transport: "remote", Running: true, Healthy: true, Version: "IRIS for UNIX 2026.1"}
	f := &fakeCmd{stdout: clientEnvBytes(t, "lifecycle status", true, 0, st, nil)}
	c := NewClient("/bin/m-iris", "iris", "remote", []string{"--base-url", "X"}, f.run)

	got, err := c.Status(context.Background())
	if err != nil {
		t.Fatalf("Status: %v", err)
	}
	if !got.Healthy || got.Version != st.Version {
		t.Errorf("status = %+v, want healthy + version", got)
	}
	if f.name != "/bin/m-iris" {
		t.Errorf("bin = %q", f.name)
	}
	want := []string{"lifecycle", "status", "--transport", "remote", "--base-url", "X", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

// An EMPTY Client.Transport means "the caller expressed no preference" and MUST
// NOT reach argv: the driver then resolves the transport below the seam from its
// own M_<ENGINE>_TRANSPORT env and its own default (ydb local, iris remote).
// Before this, `call` appended --transport unconditionally, so a driver flag
// always beat the driver's own env — which is why M_YDB_TRANSPORT measured as
// ignored, and why `m vista status --engine ydb` refused in the m-devbox image
// while `m test` ran local. Transport-resolution ADR D1/D2.
func TestClient_Call_EmptyTransportIsOmittedFromArgv(t *testing.T) {
	st := Status{Transport: "local", Running: true, Healthy: true, Version: "r2.06"}
	f := &fakeCmd{stdout: clientEnvBytes(t, "lifecycle status", true, 0, st, nil)}
	c := NewClient("m-ydb", "ydb", "", nil, f.run)

	if _, err := c.Status(context.Background()); err != nil {
		t.Fatalf("Status: %v", err)
	}
	want := []string{"lifecycle", "status", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v (no --transport: delegation to the driver)", f.args, want)
	}
	for _, a := range f.args {
		if a == "--transport" {
			t.Fatal("an empty Transport still reached argv — the driver's own env/default can never win")
		}
	}
}

// The delegation in the test above must not weaken the explicit path: a non-empty
// Transport is still forwarded verbatim, and still wins over the driver's env.
func TestClient_Call_ExplicitTransportStillForwarded(t *testing.T) {
	st := Status{Transport: "remote", Running: true, Healthy: true}
	f := &fakeCmd{stdout: clientEnvBytes(t, "lifecycle status", true, 0, st, nil)}
	c := NewClient("m-ydb", "ydb", "remote", []string{"--host", "h"}, f.run)

	if _, err := c.Status(context.Background()); err != nil {
		t.Fatalf("Status: %v", err)
	}
	want := []string{"lifecycle", "status", "--transport", "remote", "--host", "h", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

func TestClient_ExecEval_StdoutSuccess(t *testing.T) {
	r := ExecResult{Stdout: "HI", Status: 0}
	f := &fakeCmd{stdout: clientEnvBytes(t, "exec eval", true, 0, r, nil)}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)

	got, err := c.ExecEval(context.Background(), `w "HI"`)
	if err != nil {
		t.Fatalf("ExecEval: %v", err)
	}
	if got.Stdout != "HI" {
		t.Errorf("stdout = %q", got.Stdout)
	}
	if got.EngineError != nil {
		t.Errorf("unexpected engineError: %+v", got.EngineError)
	}
	want := []string{"exec", "eval", `w "HI"`, "--transport", "local", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

// On an engine fault the driver emits the envelope (with engineError) to STDERR
// and exits non-zero; the client must read stderr and surface engineError as
// DATA (not a Go error) so callers can render a RED-with-cause result.
func TestClient_ExecEval_EngineErrorFromStderr(t *testing.T) {
	eng := &EngineError{Mnemonic: "<NOROUTINE>", Text: "no such routine", Line: 12, Routine: "ZZZ"}
	f := &fakeCmd{
		stderr: clientEnvBytes(t, "exec eval", false, 5, ExecResult{Status: 5}, eng),
		exit:   5,
	}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)

	got, err := c.ExecEval(context.Background(), "do ^ZZZ")
	if err != nil {
		t.Fatalf("engine fault must be data, not a Go error: %v", err)
	}
	if got.EngineError == nil || got.EngineError.Mnemonic != "<NOROUTINE>" {
		t.Fatalf("engineError = %+v, want <NOROUTINE>", got.EngineError)
	}
}

func TestClient_LaunchError(t *testing.T) {
	f := &fakeCmd{err: errors.New("exec: \"m-ydb\": executable file not found")}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)
	if _, err := c.Status(context.Background()); err == nil {
		t.Error("a launch failure must be a Go error")
	}
}

func TestClient_BadEnvelope(t *testing.T) {
	f := &fakeCmd{stdout: []byte("not json"), exit: 0}
	c := NewClient("m-ydb", "ydb", "local", nil, f.run)
	if _, err := c.Status(context.Background()); err == nil {
		t.Error("non-JSON output must be a Go error")
	}
}

func TestClient_ExecScript_Base64ArgAndStdout(t *testing.T) {
	r := ExecResult{Stdout: "^ycov(\"STDSTR\",\"len\",1)=\"3:\"", Status: 0}
	f := &fakeCmd{stdout: clientEnvBytes(t, "exec script", true, 0, r, nil)}
	c := NewClient("m-ydb", "ydb", "docker", []string{"--container", "vehu"}, f.run)

	script := "kill ^ycov\nview \"TRACE\":1:\"^ycov\":\"\"\nhalt\n"
	got, err := c.ExecScript(context.Background(), script)
	if err != nil {
		t.Fatalf("ExecScript: %v", err)
	}
	if got.Stdout != r.Stdout {
		t.Errorf("stdout = %q, want %q", got.Stdout, r.Stdout)
	}
	b64 := base64.StdEncoding.EncodeToString([]byte(script))
	want := []string{"exec", "script", "--script-b64", b64, "--transport", "docker", "--container", "vehu", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

// StageSweep asks the driver to remove stale run-staging directories
// (mtest-*) older than the TTL under the engine's primary source dir, and
// returns what was swept so the caller can report it (no silent cleanup).
func TestClient_StageSweep_ArgvAndParse(t *testing.T) {
	r := SweepResult{Swept: []string{"mtest-old1", "mtest-old2"}}
	f := &fakeCmd{stdout: clientEnvBytes(t, "exec sweep", true, 0, r, nil)}
	c := NewClient("m-ydb", "ydb", "docker", []string{"--container", "vehu"}, f.run)

	got, err := c.StageSweep(context.Background(), 24)
	if err != nil {
		t.Fatalf("StageSweep: %v", err)
	}
	if !reflect.DeepEqual(got.Swept, r.Swept) {
		t.Errorf("swept = %v, want %v", got.Swept, r.Swept)
	}
	want := []string{"exec", "sweep", "--ttl-hours", "24", "--transport", "docker", "--container", "vehu", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}

// Unstage removes the run's own staging directory (the --stage-dir the
// connection was built with) — the unconditional exit-path cleanup.
func TestClient_Unstage_Argv(t *testing.T) {
	f := &fakeCmd{stdout: clientEnvBytes(t, "exec unstage", true, 0, UnstageResult{Removed: "mtest-abc"}, nil)}
	c := NewClient("m-ydb", "ydb", "docker", []string{"--container", "vehu", "--stage-dir", "mtest-abc"}, f.run)

	got, err := c.Unstage(context.Background())
	if err != nil {
		t.Fatalf("Unstage: %v", err)
	}
	if got.Removed != "mtest-abc" {
		t.Errorf("removed = %q, want mtest-abc", got.Removed)
	}
	want := []string{"exec", "unstage", "--transport", "docker", "--container", "vehu", "--stage-dir", "mtest-abc", "--output", "json"}
	if !reflect.DeepEqual(f.args, want) {
		t.Errorf("argv = %v\nwant %v", f.args, want)
	}
}
