package mdriver

import "sort"

// This file is the verb mutation-classification registry (run-lock design §6c,
// driver-contract.md §5.8) — the single place that answers "may this verb run
// outside a run-lock bracket?".
//
// It exists so that enforcement is keyed off a CLASS rather than a per-verb hand
// list in prose. Each driver's dispatch middleware looks the verb up here and
// calls RequireRunLock; a new verb therefore inherits the check automatically,
// and a verb a driver advertises but nobody classified is red-gated by
// conformance (UnclassifiedVerbs). That is what forces the taxonomy question at
// add-time instead of leaving an unenforced hole for the next hurried change
// (undeclared-seams §3, defeats (a)/(b)).

// VerbClass is a contract verb's engine-state class.
type VerbClass string

const (
	// ClassMutating — the verb can change engine state (routines, globals,
	// namespace) or the instance's existence. A bracket token is required.
	ClassMutating VerbClass = "mutating"

	// ClassRead — the verb reads engine state whose torn view poisons a consumer.
	// A token is required, the same as mutating: owner decision #2 is STRICT,
	// because a snapshot racing a writer is exactly the torn pre-image that the
	// v-pkg F2 incident then restored as truth (audit V2). Reading a busy engine
	// waits; diagnosis is unaffected, since the control class stays exempt.
	ClassRead VerbClass = "read"

	// ClassStatus — instance metadata only: no engine state is read or written.
	// No token.
	ClassStatus VerbClass = "status"

	// ClassControl — the DECLARED escape hatch (§R-7), not a silent bypass: verbs
	// whose purpose is to unwedge or observe a run. No token, by design, for two
	// load-bearing reasons:
	//
	//   - the remedy for a stuck run must never queue behind the stuck run (the
	//     historical reason m-iris's per-call lock had to be bypassed by Abort);
	//   - AcquireRunLock bootstraps by calling the driver's runlock-path to learn
	//     the key/path, so a token-gated runlock-* could never be reached before a
	//     bracket exists — the bracket could never be taken at all (§7.3).
	ClassControl VerbClass = "control"
)

// RequiresRunLock reports whether a verb of this class may run only inside a
// proven run-lock bracket.
func (c VerbClass) RequiresRunLock() bool { return c == ClassMutating || c == ClassRead }

// verbClasses maps "<axis> <verb>" to its class. The key is AXIS-QUALIFIED
// because `lifecycle status` (instance metadata) and `sync status` (a content
// comparison against the instance, which a concurrent writer tears) share a verb
// name and must not share a class.
//
// Every verb named in the contract's §5 axis tables is classified here, whether
// or not a driver wires it yet — the taxonomy question belongs at
// contract-authoring time. Conformance red-gates the converse: a verb a driver
// ADVERTISES that is absent here.
var verbClasses = map[string]VerbClass{
	// lifecycle — up/down/restart/provision/destroy change the instance itself; a
	// `down` or `destroy` under another lane's bracket is the worst available
	// action, so they are writes, not status.
	"lifecycle up":        ClassMutating,
	"lifecycle down":      ClassMutating,
	"lifecycle restart":   ClassMutating,
	"lifecycle provision": ClassMutating,
	"lifecycle destroy":   ClassMutating,
	"lifecycle status":    ClassStatus,
	"lifecycle logs":      ClassStatus,
	"lifecycle wait":      ClassStatus,

	// sync — the read half compares instance routine source against a host mirror;
	// a concurrent push/install tears that comparison into a false answer, so they
	// are `read`, not `status`. pull writes only the host mirror.
	"sync list":   ClassRead,
	"sync pull":   ClassRead,
	"sync status": ClassRead,
	"sync verify": ClassRead,
	"sync diff":   ClassRead,
	"sync push":   ClassMutating,
	"sync deploy": ClassMutating,
	"sync rm":     ClassMutating,

	// exec — eval/run/script are arbitrary M writes (§6c). unstage and sweep
	// REMOVE engine-visible staging state, so they are writes too; they run inside
	// the bracket by construction (the signal handler cleans up, THEN releases —
	// §R-7, order matters). abort is the control-class escape hatch.
	"exec load":    ClassMutating,
	"exec run":     ClassMutating,
	"exec eval":    ClassMutating,
	"exec script":  ClassMutating,
	"exec unstage": ClassMutating,
	"exec sweep":   ClassMutating,
	"exec abort":   ClassControl,

	// data — get/query/export are the torn-snapshot surface decision #2 closes.
	"data get":    ClassRead,
	"data query":  ClassRead,
	"data export": ClassRead,
	"data set":    ClassMutating,
	"data kill":   ClassMutating,
	"data import": ClassMutating,

	// cover — trace RUNS an entryref under the engine's line tracer: arbitrary M.
	"cover trace": ClassMutating,

	// admin — backup and check read the whole database; a backup torn by a
	// concurrent writer is the same defect class as a torn pre-image.
	"admin backup":  ClassRead,
	"admin check":   ClassRead,
	"admin restore": ClassMutating,
	"admin journal": ClassMutating,

	// meta — introspection is exempt. native/shell hand RAW engine argv to the
	// engine and selftest drives the full suite against it: their content cannot
	// be classified, so the only safe class is the strictest one.
	"meta caps":     ClassStatus,
	"meta version":  ClassStatus,
	"meta info":     ClassStatus,
	"meta schema":   ClassStatus,
	"meta doctor":   ClassStatus,
	"meta ping":     ClassStatus,
	"meta selftest": ClassMutating,
	"meta native":   ClassMutating,
	"meta shell":    ClassMutating,

	// The run-lock's own verbs are control: see ClassControl's second reason.
	"meta runlock-path":   ClassControl,
	"meta runlock-status": ClassControl,
}

// ClassOf returns the class of an axis+verb. ok is false when the verb is not in
// the registry — callers MUST treat that as a red (conformance does), never as a
// permissive default: an unclassified verb is an unenforced hole.
func ClassOf(axis, verb string) (VerbClass, bool) {
	c, ok := verbClasses[axis+" "+verb]
	return c, ok
}

// ClassifiedVerbs returns the registry as a copy, for rendering the contract's
// class table and for iteration. It is a copy on purpose: an exported mutable map
// would let a consumer reclassify `exec eval` as `status` at runtime and exempt
// itself from the very enforcement it is calling through (defeat (d)).
func ClassifiedVerbs() map[string]VerbClass {
	out := make(map[string]VerbClass, len(verbClasses))
	for k, v := range verbClasses {
		out[k] = v
	}
	return out
}

// UnclassifiedVerbs returns the "<axis> <verb>" entries a driver advertises in
// caps that carry no class — sorted, so the conformance failure is stable. A
// non-empty result is a RED: the driver has a verb its own dispatch middleware
// cannot enforce, which is how an unenforced verb would otherwise be added.
func UnclassifiedVerbs(c Caps) []string {
	var missing []string
	for _, av := range c.Axes.Wired() {
		for _, verb := range av.Verbs {
			if _, ok := ClassOf(av.Name, verb); !ok {
				missing = append(missing, av.Name+" "+verb)
			}
		}
	}
	sort.Strings(missing)
	return missing
}
