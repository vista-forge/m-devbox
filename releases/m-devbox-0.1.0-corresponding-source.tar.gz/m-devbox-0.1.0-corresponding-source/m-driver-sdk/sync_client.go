package mdriver

import "context"

// PullResult reports what `sync pull` materialized into the host-side mirror
// (contract §5.2: { pulled, bytes }; the counters beyond those two are additive
// driver detail and may be zero on a driver that does not report them).
type PullResult struct {
	Mirror    string `json:"mirror,omitempty"`
	Pulled    int    `json:"pulled"`
	Unchanged int    `json:"unchanged,omitempty"`
	Deleted   int    `json:"deleted,omitempty"`
	Bytes     int    `json:"bytes"`
}

// RmResult reports what `sync rm` removed from the instance (contract §5.2:
// { removed }).
type RmResult struct {
	Removed []string `json:"removed"`
}

// SyncPull materializes routine source from the instance into the host-side
// mirror directory (sync pull). filter narrows by bare routine name (contract
// §5.2 `--filter`, glob semantics); full forces a re-copy ignoring the mirror
// manifest.
//
// This is the sanctioned way to read routine SOURCE off an engine — the m lib
// pre-image capture reads the .m bytes this way, never via $TEXT read-back,
// because $TEXT over an object-only routine fails *plausibly* (measured
// 2026-07-22: embedded-source .so → convincing source; bare .o → 0 lines while
// still executable). See m-lib-install §5b.
func (c *Client) SyncPull(ctx context.Context, mirror, filter string, full bool) (PullResult, error) {
	args := []string{"sync", "pull", "--mirror", mirror}
	if filter != "" {
		args = append(args, "--filter", filter)
	}
	if full {
		args = append(args, "--full")
	}
	var r PullResult
	_, err := c.call(ctx, &r, args...)
	return r, err
}

// SyncRm removes a routine from the instance (sync rm) — the deletion half of
// m lib uninstall/heal for a greenfield install.
func (c *Client) SyncRm(ctx context.Context, name string) (RmResult, error) {
	var r RmResult
	_, err := c.call(ctx, &r, "sync", "rm", name)
	return r, err
}
