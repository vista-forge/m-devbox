package mdriver

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
)

// argvSpy captures the argv the client hands the driver binary.
func argvSpy(t *testing.T, data string) (*Client, *[]string) {
	t.Helper()
	var seen []string
	c := NewClient("m-ydb", "ydb", TransportDocker, nil,
		func(_ context.Context, _ string, args []string) ([]byte, []byte, int, error) {
			seen = args
			env := `{"schemaVersion":"1.0","command":"x","ok":true,"exit":0,"data":` + data + `}`
			return []byte(env), nil, 0, nil
		})
	return c, &seen
}

func TestClient_RunLockToken_RidesEveryInvocation(t *testing.T) {
	// §6a: when set, every driver invocation appends --run-lock <token>. The
	// explicit flag is the loud channel and wins over the M_RUN_LOCK_TOKEN env
	// fallback the driver reads for the bash-wrapped chain.
	c, seen := argvSpy(t, `{"stdout":"","status":0}`)
	c.RunLockToken = "tok-123"

	if _, err := c.ExecEval(context.Background(), "set x=1"); err != nil {
		t.Fatalf("ExecEval: %v", err)
	}
	argv := strings.Join(*seen, " ")
	if !strings.Contains(argv, "--run-lock tok-123") {
		t.Errorf("argv = %q, want --run-lock tok-123", argv)
	}
}

func TestClient_NoRunLockToken_NoFlag(t *testing.T) {
	// Unset ⇒ no flag ⇒ the driver falls back to M_RUN_LOCK_TOKEN. An empty
	// --run-lock "" would be a presented-but-blank token, which reads as MISMATCH
	// rather than the intended env fallback.
	c, seen := argvSpy(t, `{"stdout":"","status":0}`)
	if _, err := c.ExecEval(context.Background(), "set x=1"); err != nil {
		t.Fatalf("ExecEval: %v", err)
	}
	if strings.Contains(strings.Join(*seen, " "), "--run-lock") {
		t.Errorf("argv = %v, want no --run-lock flag when no token is set", *seen)
	}
}

func TestClient_RunLockDir_RidesEveryInvocation(t *testing.T) {
	// The dispatch check must look at the SAME lock file the bracket holds, so a
	// fixture-dir override has to reach the driver on every call, not just on the
	// derivation verb.
	c, seen := argvSpy(t, `{"stdout":"","status":0}`)
	c.RunLockDir = "/tmp/fixture"
	if _, err := c.ExecEval(context.Background(), "set x=1"); err != nil {
		t.Fatalf("ExecEval: %v", err)
	}
	if !strings.Contains(strings.Join(*seen, " "), "--run-lock-dir /tmp/fixture") {
		t.Errorf("argv = %v, want --run-lock-dir", *seen)
	}
}

func TestClient_RunLockPath_CallsTheDerivationVerb(t *testing.T) {
	c, seen := argvSpy(t, `{"key":"ydb.docker.vehu","path":"/d/ydb.docker.vehu.lock"}`)
	ref, err := c.RunLockPath(context.Background(), "/d")
	if err != nil {
		t.Fatalf("RunLockPath: %v", err)
	}
	argv := strings.Join(*seen, " ")
	if !strings.HasPrefix(argv, "meta runlock-path") {
		t.Errorf("argv = %q, want the meta runlock-path verb", argv)
	}
	if !strings.Contains(argv, "--run-lock-dir /d") {
		t.Errorf("argv = %q, want the dir override passed through", argv)
	}
	if ref.Key != "ydb.docker.vehu" || ref.Path != "/d/ydb.docker.vehu.lock" {
		t.Errorf("ref = %+v, want the driver's derivation verbatim", ref)
	}
}

func TestClient_SupportsRunLock(t *testing.T) {
	// Decision #4: a caller must never believe it is protected while it is not.
	// The capability bit is how it asks — the hard error itself is m-cli's (P0.4).
	for _, tc := range []struct {
		name string
		caps string
		want bool
	}{
		{"advertised", `{"engine":"ydb","contract":"1.0","features":{"runLock":true}}`, true},
		{"not advertised", `{"engine":"ydb","contract":"1.0","features":{"runLock":false}}`, false},
		{"old driver (field absent)", `{"engine":"ydb","contract":"1.0","features":{}}`, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			c, _ := argvSpy(t, tc.caps)
			got, err := c.SupportsRunLock(context.Background())
			if err != nil {
				t.Fatalf("SupportsRunLock: %v", err)
			}
			if got != tc.want {
				t.Errorf("SupportsRunLock = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestFeatures_RunLockAlwaysRenders(t *testing.T) {
	// A false flag is meaningful information, not absence — an honest
	// "runLock":false is exactly what lets m-cli hard-error instead of running
	// unlocked while believing itself protected.
	b, err := json.Marshal(Caps{Engine: "ydb", Features: Features{}})
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if !strings.Contains(string(b), `"runLock":false`) {
		t.Errorf("caps JSON = %s, want an explicit runLock:false", b)
	}
}
