package mdriver

import (
	"sort"
	"strings"
	"testing"
)

// The registry's whole purpose is that enforcement is keyed off a class, not a
// hand list in prose — so these tests pin the classes the run-lock design's §6c
// table asserts, and the coverage property that makes adding a verb force the
// taxonomy question.

func TestClassOf_ExecIsMutating(t *testing.T) {
	// §6c: "exec eval/run/script are mutating (arbitrary M writes)".
	for _, verb := range []string{"eval", "run", "script", "load", "unstage", "sweep"} {
		c, ok := ClassOf("exec", verb)
		if !ok {
			t.Fatalf("exec %s unclassified", verb)
		}
		if c != ClassMutating {
			t.Errorf("exec %s = %q, want %q", verb, c, ClassMutating)
		}
	}
}

func TestClassOf_ReadVerbsRequireTheBracket(t *testing.T) {
	// Owner decision #2 (STRICT): read-class verbs require the token, same as
	// mutating — it is what closes audit V2's torn snapshot.
	for _, av := range [][2]string{{"data", "get"}, {"data", "query"}, {"sync", "verify"}, {"admin", "backup"}} {
		c, ok := ClassOf(av[0], av[1])
		if !ok {
			t.Fatalf("%s %s unclassified", av[0], av[1])
		}
		if c != ClassRead {
			t.Errorf("%s %s = %q, want %q", av[0], av[1], c, ClassRead)
		}
		if !c.RequiresRunLock() {
			t.Errorf("%s %s (%s) must require the bracket — decision #2 is STRICT", av[0], av[1], c)
		}
	}
}

func TestClassOf_ControlClassIsExempt(t *testing.T) {
	// §R-7: the declared escape hatch. abort must never queue behind the run it
	// exists to unwedge, and runlock-path/runlock-status must be callable BEFORE
	// a bracket exists — AcquireRunLock bootstraps through runlock-path, so if it
	// required a token the bracket could never be taken at all (§7.3).
	for _, av := range [][2]string{{"exec", "abort"}, {"meta", "runlock-path"}, {"meta", "runlock-status"}} {
		c, ok := ClassOf(av[0], av[1])
		if !ok {
			t.Fatalf("%s %s unclassified", av[0], av[1])
		}
		if c != ClassControl {
			t.Errorf("%s %s = %q, want %q", av[0], av[1], c, ClassControl)
		}
		if c.RequiresRunLock() {
			t.Errorf("%s %s must be exempt: a token-gated %s deadlocks its own acquire", av[0], av[1], av[1])
		}
	}
}

func TestClassOf_StatusIsExempt(t *testing.T) {
	for _, verb := range []string{"caps", "version", "info", "schema", "doctor"} {
		c, ok := ClassOf("meta", verb)
		if !ok {
			t.Fatalf("meta %s unclassified", verb)
		}
		if c != ClassStatus || c.RequiresRunLock() {
			t.Errorf("meta %s = %q (requires=%v), want %q exempt", verb, c, c.RequiresRunLock(), ClassStatus)
		}
	}
}

func TestClassOf_LifecycleWritesAreMutating(t *testing.T) {
	// `lifecycle down`/`destroy` under another lane's bracket is the worst
	// available action; they are engine-state writes, not status.
	for _, verb := range []string{"up", "down", "restart", "provision", "destroy"} {
		if c, _ := ClassOf("lifecycle", verb); c != ClassMutating {
			t.Errorf("lifecycle %s = %q, want %q", verb, c, ClassMutating)
		}
	}
	for _, verb := range []string{"status", "logs", "wait"} {
		if c, _ := ClassOf("lifecycle", verb); c != ClassStatus {
			t.Errorf("lifecycle %s = %q, want %q", verb, c, ClassStatus)
		}
	}
}

func TestClassOf_AxisQualified(t *testing.T) {
	// `sync status` (a content comparison against the instance — torn view lies)
	// and `lifecycle status` (instance metadata) share a verb name and MUST NOT
	// share a class. This is why the registry key is axis-qualified.
	sync, _ := ClassOf("sync", "status")
	life, _ := ClassOf("lifecycle", "status")
	if sync != ClassRead {
		t.Errorf("sync status = %q, want %q", sync, ClassRead)
	}
	if life != ClassStatus {
		t.Errorf("lifecycle status = %q, want %q", life, ClassStatus)
	}
}

func TestClassOf_PassthroughIsMutating(t *testing.T) {
	// native/shell hand raw engine argv to the engine — unclassifiable content,
	// so the only safe class is the strictest one.
	for _, verb := range []string{"native", "shell", "selftest"} {
		if c, _ := ClassOf("meta", verb); c != ClassMutating {
			t.Errorf("meta %s = %q, want %q (passthrough cannot be trusted to be read-only)", verb, c, ClassMutating)
		}
	}
}

func TestClassOf_UnknownVerb(t *testing.T) {
	if _, ok := ClassOf("exec", "teleport"); ok {
		t.Error("an unknown verb must report unclassified, not a default class")
	}
}

// UnclassifiedVerbs is the coverage red-gate: a driver that advertises a verb
// the registry does not classify is RED, so adding a verb forces the taxonomy
// question at add-time (§6c, undeclared-seams defeat (a)).
func TestUnclassifiedVerbs_RedGatesANewVerb(t *testing.T) {
	c := Caps{Axes: Axes{Exec: []string{"eval", "teleport"}, Meta: []string{"caps"}}}
	got := UnclassifiedVerbs(c)
	if len(got) != 1 || got[0] != "exec teleport" {
		t.Errorf("UnclassifiedVerbs = %v, want [exec teleport]", got)
	}
}

// The gate must be green against what the real drivers advertise TODAY, or it
// red-gates both of them the moment this lands — the self-inflicted-broken-gate
// trap. These are m-ydb's and m-iris's live caps (internal/driver/caps.go).
func TestUnclassifiedVerbs_RealDriverCapsAreFullyClassified(t *testing.T) {
	ydb := Caps{Axes: Axes{
		Meta:      []string{"caps", "info", "version", "schema", "doctor"},
		Lifecycle: []string{"up", "down", "restart", "status", "wait", "provision", "destroy"},
		Sync:      []string{"list", "pull", "status", "verify", "diff", "push", "deploy", "rm"},
		Exec:      []string{"load", "run", "eval", "script", "abort", "unstage", "sweep"},
	}}
	iris := Caps{Axes: Axes{
		Meta:      []string{"caps", "version", "info", "schema", "doctor"},
		Sync:      []string{"list", "pull", "status", "verify", "push", "deploy", "diff", "rm"},
		Lifecycle: []string{"up", "down", "restart", "status", "wait", "provision", "destroy"},
		Exec:      []string{"load", "run", "eval", "script", "abort", "unstage", "sweep"},
		Data:      []string{"get", "set", "kill", "query"},
	}}
	for name, c := range map[string]Caps{"m-ydb": ydb, "m-iris": iris} {
		if missing := UnclassifiedVerbs(c); len(missing) > 0 {
			t.Errorf("%s advertises unclassified verbs %v — the coverage gate would red-gate it on landing", name, missing)
		}
	}
}

// Every verb the contract's §5 axis tables name is classified, so a driver that
// wires one later inherits a class rather than going red for a verb the contract
// already blessed.
func TestClassifiedVerbs_CoversTheContractAxes(t *testing.T) {
	all := ClassifiedVerbs()
	for _, want := range []string{
		"lifecycle logs", "sync list", "data export", "data import",
		"cover trace", "admin backup", "admin restore", "admin check", "admin journal",
	} {
		if _, ok := all[want]; !ok {
			t.Errorf("contract verb %q is not in the registry", want)
		}
	}
}

// The exported view is a copy: a consumer cannot reclassify a verb at runtime
// and quietly exempt itself from enforcement (undeclared-seams defeat (d)).
func TestClassifiedVerbs_IsACopy(t *testing.T) {
	ClassifiedVerbs()["exec eval"] = ClassStatus
	if c, _ := ClassOf("exec", "eval"); c != ClassMutating {
		t.Fatalf("the registry was mutated through the exported view: exec eval = %q", c)
	}
}

func TestVerbClass_RequiresRunLock(t *testing.T) {
	for c, want := range map[VerbClass]bool{
		ClassMutating: true, ClassRead: true, ClassStatus: false, ClassControl: false,
	} {
		if got := c.RequiresRunLock(); got != want {
			t.Errorf("%s.RequiresRunLock() = %v, want %v", c, got, want)
		}
	}
}

// A rendering aid for the contract table: the projection must be stable.
func TestClassifiedVerbs_Sorted(t *testing.T) {
	keys := make([]string, 0, len(ClassifiedVerbs()))
	for k := range ClassifiedVerbs() {
		keys = append(keys, k)
	}
	if !sort.StringsAreSorted(keys) {
		sort.Strings(keys)
	}
	for _, k := range keys {
		if !strings.Contains(k, " ") {
			t.Errorf("registry key %q is not axis-qualified", k)
		}
	}
}
