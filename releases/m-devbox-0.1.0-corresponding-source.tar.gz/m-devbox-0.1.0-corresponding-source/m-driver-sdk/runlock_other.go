//go:build !unix

package mdriver

import (
	"errors"
	"os"
)

// The run-lock's mutual exclusion is flock(2) — a Unix primitive. On a platform
// without it there is no exclusivity to be had, so every path REFUSES rather than
// degrading to a no-op: a run-lock that silently protects nothing is precisely the
// defect class this seam exists to close ("a net that trusts a self-report").
//
// The deployment model is one Linux box (§8f), so this file exists to keep the
// SDK honest under cross-compilation, not to support a platform.

var errNoFlock = errors.New("run-lock: flock(2) is unavailable on this platform — engine exclusivity cannot be enforced")

func flockTry(*os.File) (bool, error) { return false, errNoFlock }
func flockUnlock(*os.File) error      { return errNoFlock }
func processGroup() int               { return 0 }
func lockHolders(string) []RunLockHolder {
	return nil
}

var holderStateFn = procState

func procState(int) (state, cmd string, found bool) { return "", "", false }
func pidAlive(int) bool                             { return true }
