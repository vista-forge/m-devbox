package mdriver

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"os/exec"
	"strings"
)

// The canonical LOCUS of an engine instance (run-lock design §R-9).
//
// R-3 keyed the run-lock on the connection SELECTOR, and that was the defect: a
// selector names a ROUTE, and routes alias. They alias across transports — foia-t12
// is `iris.docker.foia-t12` over docker and `iris.remote.127.0.0.1_52773` over
// Atelier, which is the LIVE healthcheck configuration, so a transport-keyed lock
// would not serialize that gate against itself — and they alias within one transport
// (`--docker <id>` vs its name; localhost vs 127.0.0.1 vs a tunnel). A key built from
// a selector spelling can never be collision-free against itself.
//
//	The key names the PLACE, not the ROUTE.
//
// The resolution ladder (§R-9.3):
//
//	docker  → the selector, canonicalized host-side (ID → name). NO engine call.
//	local   → the interior the driver already derives, hashed. NO engine call.
//	network → ask the LIVE engine its node fingerprint, then classify:
//	            node is a local container → THAT CONTAINER'S DOCKER LOCUS  ← the unification
//	            node is this host         → the local locus
//	            neither                   → foreign, keyed from the engine's ANSWER,
//	                                        never the dialed spelling
//	unresolvable → NO KEY. Refuse (RUN_LOCK_UNRESOLVED). Never a selector fallback.
//
// Why the lifecycle bootstrap problem dissolves rather than needing a patch: the
// verbs that cannot ask a stopped engine who it is (`lifecycle up/provision/destroy`)
// are exactly the verbs that ride docker/local routes — whose selector already IS the
// canonical locus. There is no verb that must both run against an unreachable engine
// and ride a network route, so the fallback that would have re-split the key domain is
// never needed.
//
// The engine-ask itself is per-driver (Atelier vs SSH vs session — vendor logic, below
// this SDK). What lives here is the docker legwork both drivers would otherwise
// implement twice, and drift on.

// LocusClass is the class of an instance's canonical locus. It is NOT the dialed
// transport: a remote/Atelier route to a local container has class `docker`, because
// that is where the instance IS.
type LocusClass string

const (
	// LocusDocker — the instance is a container on this host. ID is its canonical name.
	LocusDocker LocusClass = "docker"
	// LocusLocal — the instance is a native install on this host. ID is the derived,
	// hashed interior (engine-instance-path ADR: derive, never declare).
	LocusLocal LocusClass = "local"
	// LocusRemote — the instance is FOREIGN: not a container here, not this host. ID is
	// built from the engine's OWN reported fingerprint, never the dialed spelling — which
	// is what unifies tunnels, DNS aliases and differing URL spellings onto one key.
	//
	// A foreign key carries the design's scope boundary in its own class name: flock is
	// per-kernel, so a foreign instance is serialized only among lanes on THIS driving
	// host. Lanes on other hosts are not covered (§8f, §R-9.8).
	LocusRemote LocusClass = "remote"
)

// Locus is where an engine instance IS.
type Locus struct {
	Class LocusClass
	ID    string
}

// Key renders the run-lock key. Grammar is unchanged from R-3
// (`<engine>.<class>.<id>`, same normalization) — what changed is what the parts MEAN.
func (l Locus) Key(engine string) string {
	clean := func(s string) string {
		return strings.Trim(runLockKeyClean.ReplaceAllString(s, "_"), "_")
	}
	return clean(engine) + "." + clean(string(l.Class)) + "." + clean(l.ID)
}

// Valid reports whether the locus is resolved. The zero Locus is deliberately invalid:
// an unresolved route must refuse, never key.
func (l Locus) Valid() bool { return l.Class != "" && l.ID != "" }

// CodeRunLockUnresolved — the route's canonical locus could not be determined, so no
// key exists and a bracket-requiring verb on it is REFUSED (fail-closed, §R-9.3).
//
// This must NEVER degrade into a selector-spelled key: that would reintroduce the
// two-routes-one-instance split precisely when the box is degraded (defeat (n)).
const CodeRunLockUnresolved = "RUN_LOCK_UNRESOLVED"

// UnresolvedRunLock builds the fail-closed refusal, carrying WHY resolution failed.
func UnresolvedRunLock(engine string, cause error) error {
	return &RunLockError{
		Code: CodeRunLockUnresolved, Exit: ExitRunLockRefused,
		Msg: fmt.Sprintf("cannot determine which engine instance this connection reaches (%s): %v", engine, cause),
		Hint: "the run-lock keys on the instance, not the route — it will not guess. " +
			"Check the engine is reachable and the docker daemon is up, then retry.",
	}
}

// --- the docker legwork (shared, so the two drivers cannot drift on it) ----------

// DockerRunner runs the docker CLI and returns its stdout. Injected so the locus
// helpers are unit-testable without a daemon.
//
// A custom runner signals the two failure classes the SDK must tell apart:
//
//	ErrNoSuchContainer — a CLEAN no-match (the container does not exist)
//	ErrNoDocker        — docker is not installed on this box
//	anything else      — an infrastructure failure: REFUSE
type DockerRunner func(ctx context.Context, args ...string) ([]byte, error)

// ErrNoSuchContainer is the clean-no-match sentinel. **Exported** (v0.8.1) so a custom
// DockerRunner can express it: in v0.8.0 it was unexported and minted only inside the
// real closure, so an injected runner could produce nothing but an infrastructure
// error — and the self-canonical rung, the one that dissolves the bootstrap problem,
// was untestable by any consumer.
var ErrNoSuchContainer = errors.New("no such container")

// ErrNoDocker — docker is not installed. For a NETWORK route this is a real answer,
// not a failure: a box with no docker runs no containers, so the engine is foreign.
var ErrNoDocker = errors.New("docker CLI not found")

// DockerError is a non-zero docker exit. Its Stderr is kept because the exit code
// ALONE cannot say whether the container is missing or the daemon is dead — see
// Canonicalize.
type DockerError struct {
	Args   []string
	Exit   int
	Stderr string
}

func (e *DockerError) Error() string {
	return fmt.Sprintf("docker %s: exit %d: %s", strings.Join(e.Args, " "), e.Exit, strings.TrimSpace(e.Stderr))
}

// DockerLocator resolves docker loci. A nil Run uses the real `docker` binary.
type DockerLocator struct{ Run DockerRunner }

// NewDockerLocator binds to the real docker CLI.
func NewDockerLocator() *DockerLocator { return &DockerLocator{Run: dockerCLI} }

func dockerCLI(ctx context.Context, args ...string) ([]byte, error) {
	out, err := exec.CommandContext(ctx, "docker", args...).Output()
	if err == nil {
		return out, nil
	}
	if errors.Is(err, exec.ErrNotFound) {
		return nil, ErrNoDocker
	}
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		// NOTE: do NOT classify here. `docker inspect` exits non-zero for a missing
		// container AND for a dead daemon, and mistaking the second for the first is a
		// SILENT SPLIT LOCK (S2). Classification needs a liveness probe — see
		// Canonicalize.
		return nil, &DockerError{Args: args, Exit: ee.ExitCode(), Stderr: string(ee.Stderr)}
	}
	return nil, err
}

func (d *DockerLocator) run(ctx context.Context, args ...string) ([]byte, error) {
	if d.Run == nil {
		d.Run = dockerCLI
	}
	return d.Run(ctx, args...)
}

// daemonAlive probes the daemon. It is the ONLY reliable way to tell a missing
// container from a dead daemon — the exit code is 1 for both, and parsing stderr
// prose is fragile across docker versions and locales. It runs only on the error
// path, so it costs nothing in the common case.
func (d *DockerLocator) daemonAlive(ctx context.Context) bool {
	_, err := d.run(ctx, "version", "--format", "{{.Server.Version}}")
	return err == nil
}

// Canonicalize turns a docker selector — a name OR an id, a running OR a stopped
// container — into the container's canonical NAME. This is what collapses the
// `--docker <id>` / `--docker <name>` alias onto one key (defeat (i)).
//
// A container that does NOT exist is not an error: `lifecycle provision --docker foo`
// is about to CREATE it, and `foo` is exactly its canonical locus. That is what makes
// docker routes self-canonical and lets the most destructive verbs key without an
// engine call.
//
// A DAEMON failure IS an error, and the caller must refuse (RUN_LOCK_UNRESOLVED) —
// never fall through to the selector spelling.
func (d *DockerLocator) Canonicalize(ctx context.Context, selector string) (Locus, error) {
	out, err := d.run(ctx, "inspect", "--format", "{{.Name}}", selector)
	if err != nil {
		// S2 — THE DECISION THAT MUST NOT BE GOT WRONG. `docker inspect` exits 1 for
		// BOTH "no such container" and "cannot connect to the daemon". v0.8.0 mapped
		// both to a clean no-match, so a dead daemon silently returned
		// locus{docker, <raw selector>} — and `--container vehu` and
		// `--container <its id>` then took TWO LOCK FILES FOR ONE ENGINE. That is
		// defeat (n): the split lock, reintroduced exactly when the box is degraded,
		// inside the code that fixes R-9.
		switch {
		case errors.Is(err, ErrNoSuchContainer):
			// A custom runner said so explicitly. Trust it.
		case errors.Is(err, ErrNoDocker):
			// A docker route on a box with no docker is a genuine misconfiguration.
			return Locus{}, fmt.Errorf("docker route to %q but %w", selector, err)
		case d.daemonAlive(ctx):
			// The daemon is UP and still could not find it ⇒ a real no-match: the
			// container does not exist yet. Self-canonical — this is what lets
			// `lifecycle provision --docker foo` take a bracket before foo exists.
		default:
			// The daemon is down (or unreachable). We CANNOT know what this selector
			// names, so we do not guess: refuse.
			return Locus{}, fmt.Errorf("cannot canonicalize docker selector %q: %w", selector, err)
		}
		return Locus{Class: LocusDocker, ID: selector}, nil
	}
	// `{{.Name}}` renders with a leading slash.
	name := strings.TrimPrefix(strings.TrimSpace(string(out)), "/")
	if name == "" {
		return Locus{}, fmt.Errorf("docker inspect %s: empty name", selector)
	}
	return Locus{Class: LocusDocker, ID: name}, nil
}

// MatchNode maps an engine-reported node fingerprint (its hostname, which for a
// container defaults to its short ID) onto a local container.
//
// This is the line that closes R-9: a remote/Atelier route whose engine turns out to
// be a container on this host derives THAT CONTAINER'S docker locus — so
// `m test --docker foia-t12` and `v pkg install --transport remote` land on one lock.
//
// The three outcomes are contract (C-RL-8):
//
//	(locus, true,  nil) — the engine IS this local container
//	(zero,  false, nil) — a CLEAN no-match: the engine is genuinely foreign
//	(zero,  false, err) — an ENUMERATION ERROR, or an ambiguous match: REFUSE
//
// The error-vs-no-match distinction is the whole point: collapsing them would either
// key a foreign engine as local (wrong) or refuse every foreign engine (useless).
func (d *DockerLocator) MatchNode(ctx context.Context, node string) (Locus, bool, error) {
	if node == "" {
		return Locus{}, false, errors.New("the engine reported no node fingerprint")
	}
	out, err := d.run(ctx, "ps", "-a", "--no-trunc", "--format", "{{.ID}}\t{{.Names}}\t{{.Label \"hostname\"}}")
	if err != nil {
		if errors.Is(err, ErrNoDocker) {
			// No docker on this box ⇒ no local containers ⇒ the engine is genuinely
			// foreign. That is a real ANSWER, not an infrastructure failure.
			return Locus{}, false, nil
		}
		// An enumeration failure IS an error, never a no-match. Refusing here is what
		// stops a degraded box from silently splitting the key domain (defeat (n)).
		return Locus{}, false, fmt.Errorf("docker ps: %w", err)
	}

	var hits []Locus
	sc := bufio.NewScanner(strings.NewReader(string(out)))
	for sc.Scan() {
		f := strings.Split(strings.TrimSpace(sc.Text()), "\t")
		if len(f) < 2 || f[0] == "" || f[1] == "" {
			continue
		}
		id, name := f[0], f[1]
		hostname := ""
		if len(f) > 2 {
			hostname = f[2]
		}
		// A container's default hostname IS its short ID, so an ID-prefix match is the
		// common case; an explicit --hostname and the name are also accepted.
		if idMatches(id, node) || name == node || (hostname != "" && hostname == node) {
			hits = append(hits, Locus{Class: LocusDocker, ID: name})
		}
	}

	switch len(hits) {
	case 0:
		return Locus{}, false, nil // genuinely foreign
	case 1:
		return hits[0], true, nil
	default:
		// Defeat (l): two containers can share an explicit --hostname. Fail closed,
		// naming both — never guess which engine we are actually talking to.
		names := make([]string, len(hits))
		for i, h := range hits {
			names[i] = h.ID
		}
		return Locus{}, false, fmt.Errorf(
			"node %q matches %d local containers (%s) — cannot tell which instance this is",
			node, len(hits), strings.Join(names, ", "))
	}
}

// idMatches reports whether node is a prefix of the container's full ID (the engine
// may report a short id, a long id, or something else entirely).
func idMatches(fullID, node string) bool {
	const minPrefix = 8 // a shorter "prefix" is not an identification
	return len(node) >= minPrefix && strings.HasPrefix(fullID, node)
}
