package mdriver

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
)

// CmdRunner runs the driver binary and returns its stdout, stderr, and process
// exit. Only a launch failure (binary missing, etc.) is a Go error; a non-zero
// engine/driver exit is a result. Injected so the client is testable without a
// real driver binary.
type CmdRunner func(ctx context.Context, name string, args []string) (stdout, stderr []byte, exit int, err error)

// Client is the SDK's reference engine client: the single, shared way any tool
// reaches a live engine over the driver contract. It invokes an m-<engine>
// driver binary over the contract's subprocess + JSON-envelope seam
// (driver-contract.md §2) —
// `m-<engine> <axis> <verb> [args] --transport <t> [conn] --output json` — and
// parses the one JSON envelope it writes. A caller speaks only the neutral
// contract (§1, §11: "zero changes to add an engine"); all vendor detail lives
// behind the binary, which the drivers reach themselves (m-ydb via
// local/docker/SSH, m-iris via Atelier REST), so this client never knows the
// wire, only the contract.
//
// It is the seam's transport monopoly: m-cli and every `v` tool import this
// Client rather than hand-rolling transport or vendoring a copy
// (~/vista-forge/CLAUDE.md, waterline rule 3). One Client drives one
// m-<engine> binary over one transport+connection.
type Client struct {
	Bin    string // path to the m-<engine> binary
	Engine string // "ydb" | "iris" (for error messages)
	// Transport is local | docker | remote — or EMPTY, meaning the caller expressed
	// no preference and the DRIVER resolves it below the seam (its
	// M_<ENGINE>_TRANSPORT env, then its own default: ydb local, iris remote).
	// Empty is not a transport and never reaches argv; see call(). Pass a value
	// only when the operator actually chose one, or when the caller's own behavior
	// depends on the answer (m-cli's staged verbs branch their staging lifecycle on
	// it, so they must pin). Transport-resolution ADR D1/D2/D3.
	Transport string
	ConnArgs  []string // extra connection flags (e.g. --container, --base-url); usually empty (driver reads M_<ENGINE>_* env)

	// RunLockToken proves this client's calls belong to a live run bracket. When
	// set, every driver invocation carries `--run-lock <token>` — the LOUD channel,
	// which wins over the M_RUN_LOCK_TOKEN env fallback the driver reads for a
	// bash-wrapped chain. Set it with RunLock.Bind, never by hand.
	//
	// Unset means "no bracket proven by this client": a mutating or read verb will
	// be REFUSED by the driver's dispatch unless the ambient env carries a valid
	// token. That refusal is the point — the corruption class becomes an
	// error-message class (run-lock design §8a).
	RunLockToken string
	// RunLockDir overrides the run-lock home on every invocation, so the driver's
	// dispatch check reads the SAME lock file the bracket holds. Tests and fixtures
	// only.
	RunLockDir string

	run CmdRunner
}

// NewClient builds a driver client. A nil run uses the real subprocess runner.
func NewClient(bin, engine, transport string, connArgs []string, run CmdRunner) *Client {
	if run == nil {
		run = ExecRunner
	}
	return &Client{Bin: bin, Engine: engine, Transport: transport, ConnArgs: connArgs, run: run}
}

// envelope is the wire shape the driver writes (driver-contract.md §2). engineError
// is a sibling of data, set on a §7 fault.
type envelope struct {
	SchemaVersion string          `json:"schemaVersion"`
	Command       string          `json:"command"`
	OK            bool            `json:"ok"`
	Exit          int             `json:"exit"`
	Data          json.RawMessage `json:"data"`
	Error         *envError       `json:"error,omitempty"`
	EngineError   *EngineError    `json:"engineError,omitempty"`
}

type envError struct {
	Code    string `json:"code"`
	Exit    int    `json:"exit"`
	Message string `json:"message"`
	Hint    string `json:"hint"`
}

// DriverError is a driver- or transport-level failure surfaced from a Fail-path
// envelope (ok:false with an `error`, and NO engineError). Before this, `call`
// ignored `ok`, so such a failure yielded a zero-value result and a NIL Go error
// — the silent-0/0 hole (F5) where a failed stage/exec reported an empty "0/0,
// ok:false" suite with no diagnostic. Callers can branch on Code / Exit, or just
// propagate it. A §7 ENGINE fault (ok:false WITH engineError) is NOT a
// DriverError — it stays data in the result's EngineError, per the contract.
type DriverError struct {
	Engine  string // "ydb" | "iris"
	Command string // the envelope's command (e.g. "exec load <paths>")
	Code    string // error.code (e.g. RUNTIME, NO_NAMESPACE)
	Exit    int    // error.exit / envelope exit
	Message string // human-readable message
	Hint    string // optional remediation hint
}

func (e *DriverError) Error() string {
	msg := fmt.Sprintf("driver %s: %s failed", e.Engine, e.Command)
	if e.Code != "" {
		msg += " [" + e.Code + "]"
	}
	if e.Message != "" {
		msg += ": " + e.Message
	}
	if e.Hint != "" {
		msg += " (" + e.Hint + ")"
	}
	return msg
}

// call invokes a verb and returns the parsed envelope, decoding data into out
// (when non-nil). It reads the envelope from stdout, falling back to stderr —
// the drivers' success envelopes go to stdout (cc.Result), but a Fail-path
// envelope currently lands on stderr (a clikit deviation from §2's "one JSON
// envelope to stdout"; tolerated here, flagged for a clikit/conformance-v2 fix).
func (c *Client) call(ctx context.Context, out any, args ...string) (*envelope, error) {
	// The lock-home override is tests/fixtures only: in a non-test binary it is
	// refused BEFORE the driver is invoked, so the flag never reaches argv
	// (DS-19, Dev-11 — an honored override locks a file no other lane looks at).
	if err := refuseDirOverride("Client.RunLockDir", c.RunLockDir); err != nil {
		return nil, err
	}
	full := append([]string{}, args...)
	// An EMPTY Transport is the caller saying "I have no preference" — it is NOT a
	// transport, and must not reach argv. Omitting the flag lets the driver resolve
	// its own transport below the seam (its M_<ENGINE>_TRANSPORT env, then its own
	// default: ydb local, iris remote). Emitting it unconditionally meant a driver
	// flag always beat the driver's own env, so M_YDB_TRANSPORT could never take
	// effect and m-cli's Kong `default:` — a value indistinguishable from an
	// explicit choice — silently overrode a correct answer one layer down.
	// Transport-resolution ADR D2 (docs/background/transport-resolution-on-invoke-adr.md).
	if c.Transport != "" {
		full = append(full, "--transport", c.Transport)
	}
	full = append(full, c.ConnArgs...)
	// The run bracket rides EVERY invocation, not just the mutating ones: the
	// driver decides what needs a token from the verb-classification registry, and
	// the client has no business second-guessing that classification.
	if c.RunLockToken != "" {
		full = append(full, "--run-lock", c.RunLockToken)
	}
	if c.RunLockDir != "" {
		full = append(full, "--run-lock-dir", c.RunLockDir)
	}
	full = append(full, "--output", "json")

	stdout, stderr, _, err := c.run(ctx, c.Bin, full)
	if err != nil {
		return nil, fmt.Errorf("driver %s: launch %s: %w", c.Engine, c.Bin, err)
	}

	env, perr := parseEnvelope(stdout)
	if perr != nil {
		// Fall back to stderr (Fail-path envelope) before giving up.
		if env2, perr2 := parseEnvelope(stderr); perr2 == nil {
			env = env2
		} else {
			return nil, fmt.Errorf("driver %s: no JSON envelope on stdout or stderr: %w", c.Engine, perr)
		}
	}
	if out != nil && len(env.Data) > 0 {
		if jerr := json.Unmarshal(env.Data, out); jerr != nil {
			return nil, fmt.Errorf("driver %s: decode %s data: %w", c.Engine, env.Command, jerr)
		}
	}
	// A Fail-path envelope (ok:false with an `error`, no §7 engineError) is a
	// driver/transport failure — surface it as a typed error instead of the
	// silent zero-result + nil-error hole (F5). A §7 engine fault (engineError
	// set) is deliberately NOT surfaced here: it is data the wrapper reads into
	// the result's EngineError. A "valid-false" result (ok:false with data and no
	// `error` — e.g. doctor unhealthy / status down via ResultExit) is likewise
	// left as data.
	if !env.OK && env.EngineError == nil && env.Error != nil {
		return env, &DriverError{
			Engine:  c.Engine,
			Command: env.Command,
			Code:    env.Error.Code,
			Exit:    env.Error.Exit,
			Message: env.Error.Message,
			Hint:    env.Error.Hint,
		}
	}
	return env, nil
}

func parseEnvelope(b []byte) (*envelope, error) {
	if len(bytes.TrimSpace(b)) == 0 {
		return nil, errors.New("empty output")
	}
	var env envelope
	if err := json.Unmarshal(b, &env); err != nil {
		return nil, err
	}
	if env.SchemaVersion == "" {
		return nil, errors.New("not a clikit envelope (no schemaVersion)")
	}
	return &env, nil
}

// Status runs `lifecycle status` — the reachability + identity probe (running,
// healthy, version). This is the engine-neutral way to prove a VistA is live and
// learn its version banner (the portable replacement for `W $ZV`, which only
// captures device output on YottaDB).
func (c *Client) Status(ctx context.Context) (Status, error) {
	var s Status
	_, err := c.call(ctx, &s, "lifecycle", "status")
	return s, err
}

// Caps fetches the driver's capability document.
func (c *Client) Caps(ctx context.Context) (Caps, error) {
	var caps Caps
	_, err := c.call(ctx, &caps, "meta", "caps")
	return caps, err
}

// RunLockPath runs `meta runlock-path` — the driver's single key/path derivation
// authority (run-lock design R-3). dir is the tests-only home override.
//
// It is a CONTROL-class verb, so it takes no token: that is what lets
// AcquireRunLock learn where the lock lives BEFORE a bracket exists. A
// token-gated derivation verb could never be reached, and the bracket could never
// be taken at all (§7.3).
func (c *Client) RunLockPath(ctx context.Context, dir string) (RunLockRef, error) {
	args := []string{"meta", "runlock-path"}
	if dir != "" {
		args = append(args, "--run-lock-dir", dir)
	}
	var ref RunLockRef
	_, err := c.call(ctx, &ref, args...)
	return ref, err
}

// RunLockStatus runs `meta runlock-status` — the driver's measurement of the
// bracket: the holder record, the /proc/locks holder PIDs, and the holder's
// process state (UNHELD | RUNNING | STOPPED | HELD_BY_ORPHAN_FD). Also control
// class: a stuck run must always be observable.
func (c *Client) RunLockStatus(ctx context.Context) (RunLockStatus, error) {
	var st RunLockStatus
	_, err := c.call(ctx, &st, "meta", "runlock-status")
	return st, err
}

// SupportsRunLock reports whether the driver advertises Features.RunLock — i.e.
// whether it actually enforces the bracket in its dispatch.
//
// This is how a consumer asks the question owner decision #4 turns on: a caller
// must NEVER run unlocked while believing it is protected. An old driver (which
// omits the field, so it reads false) is a hard error with an upgrade hint in
// m-cli, not a silent unlocked run — otherwise "a net that trusts a self-report"
// simply re-enters at the version seam.
func (c *Client) SupportsRunLock(ctx context.Context) (bool, error) {
	caps, err := c.Caps(ctx)
	if err != nil {
		return false, err
	}
	return caps.Features.RunLock, nil
}

// ExecEval evaluates a single M command. A §7 engine fault is returned in
// ExecResult.EngineError (data), not as a Go error — only a transport/launch
// failure is a Go error.
func (c *Client) ExecEval(ctx context.Context, command string) (ExecResult, error) {
	return c.exec(ctx, "eval", []string{command})
}

// ExecRun runs an entryref (args become $ZCMDLINE / the formallist).
func (c *Client) ExecRun(ctx context.Context, entryref string, args []string) (ExecResult, error) {
	return c.exec(ctx, "run", append([]string{entryref}, args...))
}

// ExecScript runs a multi-line M/ObjectScript script (ExecRequest.Script) and
// returns its raw captured device output — the transport feeds it to the
// engine's direct mode (YDB `-direct`) or a raw `iris session` pipe, appending
// the terminating halt. Unlike ExecEval/ExecRun there is no $ETRAP/TRY-CATCH
// wrapper: a script is a self-contained compound operation (e.g. the coverage
// TRACE / LineByLine passes) whose caller parses the raw dump itself, so faults
// surface only as absent/garbled output, never as a structured engineError. The
// script is base64-passed on argv so newlines and quotes cross the subprocess
// seam unmangled without widening the CmdRunner signature with a stdin channel.
func (c *Client) ExecScript(ctx context.Context, script string) (ExecResult, error) {
	b64 := base64.StdEncoding.EncodeToString([]byte(script))
	var r ExecResult
	env, err := c.call(ctx, &r, "exec", "script", "--script-b64", b64)
	if err != nil {
		return ExecResult{}, err
	}
	if env.EngineError != nil {
		r.EngineError = env.EngineError
	}
	return r, nil
}

func (c *Client) exec(ctx context.Context, verb string, rest []string) (ExecResult, error) {
	var r ExecResult
	env, err := c.call(ctx, &r, append([]string{"exec", verb}, rest...)...)
	if err != nil {
		return ExecResult{}, err
	}
	if env.EngineError != nil {
		r.EngineError = env.EngineError
	}
	return r, nil
}

// Load stages + compiles routine source (exec load).
func (c *Client) Load(ctx context.Context, paths []string) (LoadResult, error) {
	return c.load(ctx, paths, false)
}

// LoadNoCompile stages routine source WITHOUT the eager ZLINK/OBJ.Load compile
// (exec load --no-compile). This is the lazy-staging model a test/coverage run
// needs: drop every candidate routine on the engine's source path and let it
// auto-compile only what a suite actually references — so an optional module
// that fails to compile on this engine (e.g. a YDB-only deviceparam in STDNET)
// does not fail the whole stage when no running suite references it.
func (c *Client) LoadNoCompile(ctx context.Context, paths []string) (LoadResult, error) {
	return c.load(ctx, paths, true)
}

func (c *Client) load(ctx context.Context, paths []string, noCompile bool) (LoadResult, error) {
	args := append([]string{"exec", "load"}, paths...)
	if noCompile {
		args = append(args, "--no-compile")
	}
	var r LoadResult
	env, err := c.call(ctx, &r, args...)
	if err != nil {
		return LoadResult{}, err
	}
	if env.EngineError != nil {
		r.EngineError = env.EngineError
	}
	return r, nil
}

// StageSweep removes stale run-staging directories (`mtest-*`, older than
// ttlHours) under the engine's primary routine source dir (exec sweep) and
// returns their names. It is the self-healing half of the managed staging
// namespace (Features.ManagedStaging): a run that leaked its staging dir —
// crash, kill, lost host — is retired by the next run's sweep instead of
// shadowing installed routines forever. Only directories matching the staging
// prefix are touched, never flat files (a flat .m in the patch dir may be a
// genuine local patch).
func (c *Client) StageSweep(ctx context.Context, ttlHours int) (SweepResult, error) {
	var r SweepResult
	_, err := c.call(ctx, &r, "exec", "sweep", "--ttl-hours", fmt.Sprint(ttlHours))
	return r, err
}

// Unstage removes the run's own staging directory — the --stage-dir the
// connection was built with (exec unstage). Callers defer it unconditionally
// (abort paths included) so a completed run leaves no staging debris.
func (c *Client) Unstage(ctx context.Context) (UnstageResult, error) {
	var r UnstageResult
	_, err := c.call(ctx, &r, "exec", "unstage")
	return r, err
}

// ExecRunner is the production CmdRunner: it runs the driver binary, capturing
// stdout and stderr separately. A non-zero exit is a result; only a launch
// failure is an error.
func ExecRunner(ctx context.Context, name string, args []string) (stdout, stderr []byte, exit int, err error) {
	cmd := exec.CommandContext(ctx, name, args...)
	var out, errb bytes.Buffer
	cmd.Stdout, cmd.Stderr = &out, &errb
	runErr := cmd.Run()
	var ee *exec.ExitError
	if errors.As(runErr, &ee) {
		return out.Bytes(), errb.Bytes(), ee.ExitCode(), nil
	}
	if runErr != nil {
		return out.Bytes(), errb.Bytes(), 0, runErr
	}
	return out.Bytes(), errb.Bytes(), 0, nil
}
