# The per-engine run-lock — design (engine-state-hygiene-2 §4.0 / P0; v-pkg audit V2)

**Status: ACCEPTED — 2026-07-12 (Rafael, all five §11 questions answered).**
R-1…R-8 are accepted as recommended; the five open questions are decided in §11.
**Build may now proceed in the R-8 landing order.** This is a cross-repo seam change
to `m-driver-sdk` that every consumer pins — land it SDK-first, per the coordination
model.

> **⚠️ AMENDMENT PENDING — R-9 (2026-07-12, decision-seeking).** The R-3 key
> derivation has a measured defect: it keys per **transport**, and one IRIS
> instance reachable by two transports derives two keys — two lanes that do not
> serialize. §R-9 below is the design answer (canonical-locus keying), **PROPOSED,
> not yet accepted** — owner decisions #6–#8 in §R-9.10. **Both P0.2b driver
> spikes are blocked on it** (they would build `meta runlock-path` against a key
> about to be replaced). Everything else in this document stands unamended.

Design pass: 2026-07-12, Fable 5, coordinator lane (per
`docs/m-engine-drivers/coordination-model.md` — the SDK is the sync point).
Kickoff: `docs/proposals/engine-state-hygiene-2/prompts/p0-run-lock-kickoff.md`.
Companion requirements: engine-state-hygiene-2 §4.0/§4.1;
`v-pkg/docs/design/v-pkg-command-surface-audit.md` V2;
`docs/memory/suspended-engine-writer-triage.md` (read as a requirements doc);
`docs/background/engine-instance-path-resolution-adr.md`;
`docs/background/undeclared-seams-adr.md` §3.

---

## 1. Problem — one sentence, then the evidence

**No host-side artifact says "a run owns this engine right now,"** so every
multi-call engine run (N staging chunks + a finalize; census-before → install →
census-after) races every other lane, cron, and CI job on the two shared
engines.

Measured, not hypothetical (all 2026-07-12 or earlier):

- Two `lifecycle-healthcheck.sh` runs found driving vehu and foia **concurrently**
  while the v-pkg audit was being written (audit V2, "live right now").
- Two healthcheck runs found **SIGSTOPped for ~6 h** mid `v pkg install`
  ([[suspended-engine-writer-triage]]) — triaged and killed *by hand*, with a
  playbook this design must mechanize.
- **489 leaked `ZVINS*` scratch routines** counted on foia
  (`v-pkg/pkgcli/lifecycle.go:185-190` class).
- The F2 incident: leaked residue captured as a pre-image sidecar, then
  *restored* by uninstall.

What exists today (verified against source this pass):

| Mechanism | Scope | Stance | Why it is not a run-lock |
|---|---|---|---|
| `m-iris` sesslock (`internal/session/sesslock_unix.go`) | **per driver call**, per container | blocking flock, **fail-open** (any open/lock failure → no-op release), file in `os.TempDir()` (`sesslock.go:57`) | exists for the IRIS device-capture race (F1), not engine state; prefixed/long runs and `Abort` run **unlocked** (`session.go:202,546`) |
| `m-ydb` | — | — | **no host-side lock at all** (verified: zero flock/lock code) |
| Engine-side `L +^XTMP("VPKGLOCK",name):5` (`v-pkg/installspec/script.go:114`) | same install *name*, `INST^XPDIL1` window only, 5 s | fail-refuse | wrong scope on every axis; and an engine-side `LOCK` is held by an engine *process*, which dies with each subprocess driver call — it structurally cannot span a multi-call run |
| v-pkg `WithLedgerLock` (`internal/attest/lock_unix.go`) | the ledger file | fail-closed | protects the audit trail, **not the engine mutation it records** (audit V2) |

---

## 2. The trap, resolved — fail-open vs deadlock

The two failure modes are both already in the code being replaced:

- The sesslock is **deliberately fail-open** ("a lock-infra hiccup never fails a
  dispatch") — defensible for a capture-race lock, but for *engine state* it is
  the org's signature defect: a net that trusts a self-report, a run-lock that
  silently protects nothing.
- The abort path **deliberately bypasses** the lock, because a lock that abort
  must wait on cannot be the tool that unwedges a stuck run.

**Resolution — three different questions get three different stances:**

> **Exclusivity is fail-closed. Liveness is bounded and loud. Breaking is human.**

1. **Exclusivity (may I mutate?) — fail-closed.** A mutating driver verb that
   cannot *prove* a run-bracket is held **refuses** (structured error, distinct
   exit). Lock-infra failure on the acquire path fails the run. Rationale: the
   lock infrastructure is `mkdir` + `open` + `flock(2)` on a local disk — if
   that fails, the box is broken and mutating a shared engine blind is the worst
   available action. The asset here is engine state: corruption is silent and
   permanent; a refused dispatch is loud and retryable.
2. **Liveness (how long may I wait?) — bounded, never silent.** Every wait
   prints who it is waiting on immediately, samples the holder's liveness while
   waiting, and times out with a mechanized triage (§R-5). No infinite silent
   block anywhere. Deadlock is prevented structurally (§7), not by fail-open.
3. **Breaking (may I steal a held lock?) — never automatic.** Breaking a lock
   you wrongly believe dead admits a second writer — strictly worse than
   waiting. The tool diagnoses (kernel-measured, not self-reported); the human
   kills. §R-5.

The per-call sesslock **stays, unchanged, fail-open** — it protects device
output tidiness, not engine state; different asset, different stance. The
run-lock sits strictly *above* it (§7 ordering). The old abort bypass is
replaced by a **declared control-plane exemption** (§R-7): the escape hatch is
in the contract, not a silent bypass — per undeclared-seams D-4, escape hatches
are a declared, classified class.

---

## 3. The design at a glance

```
orchestrator (m test / v pkg install / healthcheck / CI lane)
  │  AcquireRunLock(key)            ← flock(LOCK_EX) on ~/data/vista-forge/run-lock/<key>.lock
  │  writes holder record           ← {tokenSHA256, pid, pgid, host, consumer, startedAt}
  │  exports M_RUN_LOCK_TOKEN=<t>   ← the bracket's process subtree inherits it
  │
  ├── driver call 1 (--run-lock <t>) ──► driver verifies: lock HELD ∧ sha256(t)==record → mutate
  ├── driver call 2 (--run-lock <t>) ──► …
  ├── nested tool (v pkg …) ─ JoinRunLock(env) ─► same verification, Release()=no-op
  │
  │  Release()                      ← cleanup first (unstage), then LOCK_UN
  └─ (SIGKILL/crash: kernel releases flock; token is now fenced — see §6b)
```

One lock file per engine instance; `flock(2)` is the mutual-exclusion truth;
`/proc/locks` is the measurement of who holds it; the holder record is
narrative. A run-scoped **token** proves ownership across the separate driver
subprocesses, so calls *inside* the bracket are reentrant and calls *outside*
any bracket are **refused, not corrupted**.

---

## R-1 — Where the lock lives

**RECOMMENDED:** split by role, along the org's existing seams:

- **The primitive is a file + `flock`** — takeable from Go (`flock(2)`) and
  from a shell (`flock(1)` semantics via the wrapper verb below). No daemon, no
  Go-only API.
- **The contract lives in `m-driver-sdk`** (driver-contract.md addendum, §6 of
  this doc): key derivation, path, holder-record schema, token semantics,
  refusal codes, and the verb mutation-classification registry. The SDK also
  ships the Go bracket API (`mdriver.AcquireRunLock` / `JoinRunLock`) and the
  conformance cases. The SDK is the seam both drivers pin and the only place a
  shape shared by m-cli, v-pkg, and both drivers can live without drifting
  (coordination model).
- **Enforcement lives in each driver** (m-ydb, m-iris): the refusal check runs
  in the driver's dispatch path. Rationale = the engine-instance-path ADR's D1
  argument verbatim: the driver stack is the org's transport monopoly
  (waterline rule 3) — a rule enforced there binds every present and *future*
  consumer, including ones that don't exist yet. Enforcement anywhere higher
  (m-cli) leaves a hole under it.
- **The shell surface**: each driver gains `meta` verbs `runlock-path` /
  `runlock-status` (derivation + measurement); **m-cli** gains the consumer
  wrapper `m runlock hold|try|status|path` (§6d) — the single bash API the
  healthcheck, cron, and CI use. A bash consumer never computes the path or
  writes the record itself.

**Rejected:**

- *m-cli-only host lock.* Leaves the driver seam unenforced: any `v` tool or
  raw driver invocation bypasses it. The choke point is the driver dispatch.
- *Per-driver independent designs.* Key/path/record derivation must be
  byte-identical across engines and consumers or mutual exclusion silently
  fails (two lanes "locking" different keys for the same container). Shared
  shape ⇒ SDK, per the coordination model.
- *Engine-side lock (`LOCK +^…`).* An M `LOCK` is owned by an engine process;
  every driver call is a fresh subprocess/session, so nothing engine-side can
  span a multi-call run. Also invisible to bash without a driver call, and dies
  with a container restart. (This is why the existing `VPKGLOCK` cannot be
  generalized — audit V2.)
- *A lock daemon / lease service.* Solo org, one box, cooperating tools. A
  daemon adds an availability dependency and a failure mode (daemon down =
  toolchain down) to buy properties flock already gives free (kernel-owned
  state, auto-release on death).

## R-2 — Run-scoped bracket + driver refusal + cross-process ownership

**RECOMMENDED:** the lock is **run-scoped** (bracket-open → N driver calls →
bracket-close), and **the driver refuses to mutate unless a run-lock is held
and proven** — forgetting the bracket becomes a *refusal*, not a corruption.
Ownership across processes is proven by a **run token** (fencing token):

- `AcquireRunLock` generates a random token, writes `sha256(token)` into the
  holder record, returns the token, and the holder exports it
  (`M_RUN_LOCK_TOKEN`) to its process subtree and passes it explicitly
  (`--run-lock <token>`) on every driver invocation it makes.
- A **mutating** driver verb (per the §6c classification) verifies:
  1. derive the lock path (same derivation as `runlock-path`);
  2. probe `flock(LOCK_EX|LOCK_NB)`:
     - **acquired** → nobody holds a bracket → release probe, **refuse**
       (`RUN_LOCK_REQUIRED` if no token was presented; `RUN_LOCK_NOT_HELD` if
       one was — the bracket died under its own children, see §6b);
     - **EWOULDBLOCK** → a bracket is live: read the record; `sha256(presented
       token) == record.tokenSHA256` → **proceed** (owner-reentrant); mismatch
       or no token → **refuse** (`RUN_LOCK_MISMATCH` / `RUN_LOCK_REQUIRED`),
       naming the measured holder.
  The check is one non-blocking syscall + one small read per driver call —
  negligible against a `docker exec`/Atelier round trip. It **never blocks**:
  the driver never waits on the lock, so a driver call cannot deadlock on it
  (§7). Waiting happens only in the orchestrator's acquire.
- **Sanctioned consumers auto-bracket** (m-cli, v-pkg — §R-8): each top-level
  engine-touching command *joins* the ambient bracket when `M_RUN_LOCK_TOKEN`
  is present and valid for the target key, else *acquires* one for the span of
  the command. The human running `m vista exec …` never sees the machinery;
  only a consumer that hand-rolls driver calls without a bracket meets the
  refusal — and that consumer used to meet corruption.
- **Reentrancy rule:** a process holding or joined to a bracket **never
  re-acquires** — `JoinRunLock` verifies and returns a non-owning handle whose
  `Release` is a no-op. Only the acquiring process releases. This resolves the
  nested case (defeat d: `m test` → `v pkg install` → driver call) with no
  self-wait: inner layers verify, they do not lock.

**Deadlock note for this rule (the heart of the kickoff's R-2 question):** the
driver's refusal check is achievable without deadlocking in-bracket calls
precisely because verification is a *non-blocking probe + record compare*, not
an acquisition. The only blocking wait in the whole design is the
orchestrator's initial acquire, which holds nothing else (§7).

**Rejected:**

- *Per-call locking only (no bracket).* Serializes single calls but lets two
  N-call runs interleave between calls — exactly the torn-state class (census
  vs concurrent install; snapshot vs install — audit V2's scenario). The run is
  the unit of meaning; the lock must match it.
- *FD inheritance as ownership proof* (`flock` is per open-file-description;
  children sharing the FD share the lock). Correct in theory, fragile in this
  org's real call chains: Go's `exec.Command` closes non-std FDs unless
  `ExtraFiles` is threaded through every layer (mdriver.Client → driver →
  `docker exec`), and bash consumers would need disciplined `exec 9>`
  plumbing. One missed hop silently downgrades to "no proof". The token rides
  argv/env, which every layer already passes.
- *Process-ancestry check* (walk `/proc/<pid>/stat` ppid chain to the holder).
  Orphan reparenting breaks the chain mid-run (an intermediate exits → child
  reparents to init and instantly "leaves" the bracket); `setsid`/`docker exec`
  break it too. Racy and wrong in exactly the crash cases that matter.
- *Convention only (bracket API, no driver refusal).* The YAGNI-honest
  alternative, and the biggest complexity saving (no token, no middleware). But
  the three 2026-07-12 incidents were all **sanctioned tools that took no lock
  because none existed** — a conventional lock would still not have been taken
  by the next forgotten consumer. The choke-point refusal is the part that
  converts the *fourth* incident into a refusal
  ([[nets-at-the-choke-point]], undeclared-seams §3 defeat (a)/(b): a hurried
  developer adding a helper evades any convention; he cannot evade the dispatch
  path he calls through). If the owner rejects enforcement, the fallback
  posture is bracket-by-convention + census detection — protection degrades
  from *prevent* to *detect-after*.

## R-3 — The key

**RECOMMENDED:** one lock per **engine instance**, key derived at runtime by
the driver from the connection *selector* (never from a host-declared
interior — engine-instance-path ADR):

| Transport | Key | Serialization domain |
|---|---|---|
| docker | `<engine>.docker.<container>` | the container (e.g. `ydb.docker.vehu`, `iris.docker.foia-t12`) |
| local | `ydb.local.<sha256[:12] of realpath(derived gbldir)>` / `iris.local.<instance>` | the host instance (interior derived by the driver, per the ADR — it never appears in host config, only inside the key derivation) |
| remote (Atelier) | `iris.remote.<host>_<port>` | the whole remote instance |

Key characters normalized by the existing `lockKeyClean` rule
(`m-iris/internal/session/sesslock.go:39`). Properties required by the kickoff:

- Two lanes, same image, **different containers** → different container names →
  different keys → **do not block each other**. ✓
- Two lanes, **same container** → same key → **serialize**. ✓
- Container **restart** does not change the name → the same lock still governs
  the same instance across restarts (defeat e). ✓ (A container *recreated under
  a different name* is a different instance — correctly a different key.)

**Granularity is the whole instance, not the namespace.** Rejected finer key
(`…<container>.<namespace>`): IRIS namespaces share the license pool, `%SYS`,
and mapped/shared component globals (`^XTV`, `^XWB`, `^DIC` classes — the
KIDS/component surfaces audit V2 names); a USER-staged run and a VISTA install
are not actually independent. Coarse costs a wait; fine risks a lie. On this
box the contention cost is minutes, the corruption cost is the F2 class.

**Derivation authority is the driver** (single implementation, printed by
`runlock-path`), so bash, m-cli, v-pkg, and both drivers cannot disagree about
the key for the same target. The SDK's `AcquireRunLock` obtains key+path by
calling the driver's `runlock-path` verb through the normal envelope — one
extra subprocess per bracket-open, negligible.

## R-4 — Durability + location

**RECOMMENDED:** `~/data/vista-forge/run-lock/<key>.lock` (dir `0700`, created
on first acquire). Overridable only by an explicit flag (`--run-lock-dir`,
tests/fixtures only) — no new env knob (the env-var-registry proposal is
pending; an ambient path override is exactly the class it wants classified
first).

Why not `/tmp` — the sharp reason is not reboots: **a tmp-cleaner
(`systemd-tmpfiles`) can unlink a lock file while it is held.** flock survives
the unlink (the FD holds the inode), but the next acquirer `open(O_CREATE)`s a
*new inode at the same path* and locks it successfully → **two lanes each hold
"the" lock on different inodes → mutual exclusion silently broken**. That is a
fail-open defect installed by the filesystem. The lock home must be a directory
nothing reaps. (The same argument, plus H-5's reboot-orphaning of *journals*,
moves the m-iris `StateRoot` and sesslock path off `/tmp` in the same landing —
`~/data/vista-forge/m-iris-staging/`, `…/m-iris-sess/`.)

Properties: survives reboot (the *record* survives for post-reboot narrative;
flock state is process-scoped so a reboot holds nothing — correct, since no
process survived either); shared across all processes of the operating user
(this box's model: rafael + the self-hosted runner as rafael); discoverable by
bash via `m runlock path`. House precedent for the root: `auth.env`, the
proposed attest home, and the durable StateRoot all live under
`~/data/vista-forge/` — one machine-data root, uncommitted, outside every repo
(`FORGE_ROOT` is derived-never-written and refers to the *repo* tree; per-machine
mutable state does not belong under it).

**Rejected:** `XDG_STATE_HOME` (`~/.local/state/…`) — equally correct, but a
second machine-data root for no gain; `~/data` is the org's established one.
Rejected: per-repo paths (a lock spanning repos cannot live in one), and any
path derived from `FORGE_ROOT` (worktrees/second checkouts would silently
split the lock domain).

## R-5 — Liveness, staleness, the frozen writer

**Ground truth model (three layers, trust in this order):**

1. **`flock` is the only truth of held-ness.** Auto-released on process death —
   there is *no stale-lock class to reclaim*. Not released on `SIGSTOP` — a
   suspended writer holds it indefinitely, **by design correct** (it may be
   resumed; its intent is live).
2. **`/proc/locks` is the measurement of who.** `runlock-status` resolves the
   lock file's `dev:inode` in `/proc/locks` to the actual holder PID(s) — the
   kernel's answer, not a self-report (SNR discipline). This also exposes the
   one way "held by a dead process" can appear: an **inherited FD in a
   surviving child** (e.g. an orphaned `docker exec` client) keeps the lock
   held after the acquirer dies — the status verb names the real PIDs, so this
   is visible, not mysterious.
3. **The holder record is narrative** (pid, pgid, host, consumer, startedAt,
   tokenSHA256) — used for messages and token verification, never as evidence
   of held-ness.

**What a waiter may do about a lock it believes dead: nothing, automatically.**
The rule is absolute in v1: **no auto-break, no TTL expiry, no lease steal.**
Evidence: the suspended-writer incident is precisely a lock that *looked* dead
for 6 h and was not — SIGCONT would have resumed a stale plan against a moved
engine. Breaking wrongly admits a second writer, recreating the defect class
this lock exists to close; waiting is loud and recoverable. Instead, the waiter
**diagnoses mechanically** — this is where the manual playbook
([[suspended-engine-writer-triage]]) is retired into the tool:

- On block: immediately print
  `waiting for run-lock ydb.docker.vehu: held by pid 12345 (v pkg install VSL.kids, since 09:14, state S)`.
- While waiting: sample holder liveness (`/proc/<pid>/stat` state). If the
  holder is **`T` (stopped)**, stop waiting early and fail with the mechanized
  triage — the playbook's steps as output text:
  1. diagnose with the B0 ledger first: `v pkg attest verify <ledger>` — zero
     dangling intents ⇒ frozen pre-mutation, kill is provably clean; a dangling
     intent ⇒ frozen mid-mutation, killing leaves the reconcilable crash state
     (`v pkg adopt` / `v pkg purge`);
  2. `kill -9 -- -<pgid>` **while stopped — never SIGCONT/resume** (a resumed
     writer runs a stale plan forward on old inodes);
  3. check `docker top <container>` for a container-side process started at the
     freeze time (a host-killed `docker exec` does not kill it).
- On timeout (holder running but slow): fail `RUN_LOCK_TIMEOUT` with the same
  holder narrative + measured state. The operator decides.

**Journal liveness (sibling C-1 item, contract-required here):** the staging
journal gains `pid` + `host` fields, and the write-only `StagedHash` guard
(`m-iris/internal/staging/staging.go:47-53` — verified this pass: written at
`m-iris/staging.go:56`, **read nowhere**) gains its read-side in `unstage`.
Sweeps skip any journal whose PID is alive on its recorded host *or* whose
engine's run-lock is currently held. The run-lock makes the census/sweep sound;
the journal liveness makes `--ttl 0` possible. Both land in the same driver
increment (R-8) but the sweep logic itself is the drivers' existing surface,
not new SDK shape.

**Rejected:** *TTL/lease auto-expiry* — every TTL is a bet that "slow" and
"dead" are distinguishable by a clock; the 6 h suspended writer proves they are
not. *Heartbeat threads* (touch mtime every N s) — a stopped process stops
heartbeating but remains resumable, so heartbeat absence still cannot license a
break; machinery without a decision improvement. *SIGCONT-and-observe* —
explicitly forbidden by the incident's hard-won rule.

## R-6 — Non-blocking mode (G-LEAK-SCAN)

**RECOMMENDED:** `AcquireRunLock(…, NonBlocking)` / `m runlock try` — a single
`LOCK_EX|LOCK_NB` attempt. On failure it reports the measured holder and the
caller proceeds in **report-only** mode: G-LEAK-SCAN scans nothing, sweeps
nothing, and emits a distinct machine-readable outcome
(`SKIPPED_ENGINE_BUSY`, naming the holder) — never a bare green. Per
undeclared-seams P-B ("an unobserved gate is not a gate"), the cron's STAMP
must distinguish *scanned-clean* from *skipped-busy*, and the meta-gate section
should red if every recent run skipped (a permanently-busy engine is itself a
finding — likely a frozen holder, see R-5).

## R-7 — Timeout & abort semantics

**RECOMMENDED:**

- **Acquire waits are bounded and configurable:** `--lock-wait <dur>` on every
  auto-bracketing command; defaults — interactive single-shot (`m vista exec`)
  ≈ 30 s; batch runs (`m test`, `v pkg`, healthcheck lanes) ≈ 10 min; cron
  try-only (R-6). Numbers are recommendations, not contract; the *shape*
  (always bounded, always loud, always overridable) is contract.
- **Ctrl-C while waiting:** nothing is held; exit cleanly.
- **Ctrl-C while holding:** the bracket holder's signal handler (the P0 sibling
  "signal-safe unstage" — SIGINT+SIGTERM) runs cleanup **first** (unstage /
  close sessions), **then** `Release()`. Order matters: state is restored
  before exclusivity is surrendered.
- **SIGKILL / OOM / crash while holding:** the kernel releases the flock
  immediately — **an aborted holder can never deadlock the toolchain**; that is
  the structural reason this design does not need the old fail-open escape.
  What remains is *residue*, not *blockage*: the journal (PID-dead ⇒ sweepable)
  and the census/G-CLEAN handle it. **Lock release does NOT imply clean
  state** — the lock asserts exclusivity, the census asserts state; keep the
  two claims separate.
- **Control-plane exemption (declared, not a bypass):** verbs whose purpose is
  to *unwedge or observe* a run — `exec abort`, the future `reap-sessions`,
  `status`/`caps`/`doctor`/`ping`, `runlock-*` themselves — are classified
  `control` (§6c) and take **no** run-lock and **no** token. This is the
  historical abort lesson (the m-iris per-call lock had to be bypassed by
  `Abort`, `session.go:546`, because the remedy for a stuck run cannot queue
  behind the stuck run) promoted from a silent bypass to a contract-declared
  class, per undeclared-seams D-4. Precise history, corrected from the kickoff's
  shorthand: prefixed/long runs run *unlocked* (`serialize=false`,
  `session.go:202`) and `Abort` bypasses so it can reach a *busy container* —
  the deadlock the bypass prevents is queueing the unwedger behind the wedge.
  The run-lock preserves exactly that property by exempting the control class.
- **The sesslock is untouched.** It remains per-call, blocking, fail-open — the
  capture-race lock. Ordering: the run-lock is always acquired *before* any
  driver call, hence before any sesslock; no path acquires a run-lock while
  holding a sesslock (§7).

## R-8 — Cross-repo landing order (the coordination model's answer)

SDK first; drivers parallel; consumers after; CI last. Per repo, per the
Increment Protocol; pin ceremony dormant under `go.work` (tags release-only —
cut an SDK tag when the drivers' CI needs the real pin).

| # | Repo | Change |
|---|---|---|
| 1 | **m-driver-sdk** (coordinator) | Contract addendum (§6 of this doc) in `docs/m-engine-drivers/driver-contract.md`; `mdriver` bracket API (`AcquireRunLock`/`JoinRunLock`/`RunLock`); `Client.RunLockToken` → `--run-lock` on every invocation; the verb mutation-classification registry (exported map + contract table); conformance cases C-RL-1…6 (§6e); `Features.RunLock` capability bit. Tag (e.g. v0.6.0). |
| 2a | **m-ydb** (parallel spike) | `meta runlock-path`/`runlock-status`; dispatch middleware enforcing the classification (refusals); journal pid/host + liveness-aware sweep skip; conformance green. |
| 2b | **m-iris** (parallel spike) | Same as 2a, **plus H-5**: `StateRoot` default → `~/data/vista-forge/m-iris-staging` and sesslock path off `/tmp` (`config.go:131-136`, `sesslock.go:57`); `StagedHash` read-side in unstage; sesslock itself unchanged. |
| 3 | **m-cli** | `m runlock hold\|try\|status\|path` (the bash surface — `hold` runs a child command with the token exported); auto-bracket in `test`/`coverage`/`vista exec` (join-else-acquire); wire the P0 signal handler to release-after-cleanup; feature-negotiate via caps (old driver ⇒ clear error, not silent unlocked run). |
| 4 | **v-pkg** | Auto-bracket every mutating verb **and** `snapshot`/`restore` (a capture racing a writer is audit V2's torn-read); join via env token so a healthcheck-wrapped `v pkg` reenters; refusal surfaced in the report envelope. G-LEAK-SCAN's future sweep verbs use try-mode. |
| 5 | **v-stdlib + CI (.github)** | `lifecycle-healthcheck.sh` wraps each engine lane in `m runlock hold … --` (per-lane brackets, never both engines at once — §7); `redproof-*` scripts likewise; m-ci/G-IRIS-INSTALL lanes bracket the same way; G-LEAK-SCAN cron = try-mode + `SKIPPED_ENGINE_BUSY` STAMP semantics. This unblocks **Phase C** of the v-pkg emergency repair (its live acceptance runs need a held bracket to be safe) and the `engine-state-hygiene-2` census/G-CLEAN. |

What each consumer must *change* is exactly one of: take the wrapper (bash),
call the bracket API (Go orchestrators), or nothing (anything that only calls
through m-cli/v-pkg inherits their auto-brackets).

---

## R-9 — the key names the PLACE, not the ROUTE (PROPOSED 2026-07-12 — decision-seeking)

**Status: PROPOSED, awaiting owner (§R-9.10). Blocks both P0.2b driver spikes.**
Found while writing the P0.2b kickoffs; design pass 2026-07-12, Fable 5,
coordinator lane. This section is a **peer of R-3** — it amends R-3's key
derivation and nothing else; every other R-section, the §7 deadlock argument, and
the five §11 decisions stand exactly as accepted. Kickoff:
`docs/proposals/engine-state-hygiene-2/prompts/r9-instance-key-design-kickoff.md`.

### R-9.1 The defect (measured, live, not hypothetical)

R-3 derives the key from the connection **selector** — the *route*. But a route is
not an instance, and one instance can have many routes. Measured on this box,
2026-07-12: `foia-t12` publishes Atelier on `0.0.0.0:52773`, and the ambient env
carries `M_IRIS_CONTAINER=foia-t12` **and**
`M_IRIS_BASE_URL=http://127.0.0.1:52773/…` side by side. Under R-3:

| Path | Key |
|---|---|
| `m test --engine iris --docker foia-t12` | `iris.docker.foia-t12` |
| `v pkg install --engine iris --transport remote` | `iris.remote.127.0.0.1_52773` |

**Same instance, two lock files, no mutual exclusion** — and this is the *current
live configuration of the very gate the lock exists to protect*:
`v-stdlib/scripts/lifecycle-healthcheck.sh` drives foia-t12 over docker (suites,
line 451) **and** over remote (`vpkg_transport="remote"`, line 475) in one lane.
A transport-keyed run-lock would not serialize the healthcheck against itself; the
concurrent-healthcheck-during-install incident that motivated the design stays
open on IRIS while both consumers *believe* they are protected. That is the org's
signature defect ("a net that trusts a self-report") re-entering through the key.

**And the aliasing is not even cross-transport only.** Within a single transport:
`--docker 3cf3d3cf2ff9` (the container ID — `docker exec` accepts it) and
`--docker foia-t12` derive different keys for one container; `localhost:52773`,
`127.0.0.1:52773`, and `minty:52773` derive three keys for one Atelier endpoint.
The defect class is **selector aliasing**, and a selector string can never be
collision-free against itself. The key must name the **place** (the instance's
canonical locus), never the **route** (how this process happened to dial it) —
routes are many; the place is one.

### R-9.2 Does ACCEPTED Option C (IRIS → remote-only) make this moot? **No.**

Answered explicitly, per the kickoff:

1. **The migration period is now**, and the collision configuration is the live
   healthcheck above. `m test`/`m coverage` stay on docker until m-cli's
   routine-wrap work lands (`iris-transport-standardization` §12 row 2 — the only
   real work left, and unscheduled).
2. **Docker does not go away under Option C** — it stays wired as the lab path and
   as the proposed §9 dual-read parity net (D-3, open). If D-3 is accepted, the
   dual-transport configuration becomes a *permanent scheduled gate*, not a
   transition artifact.
3. **Single-transport aliasing survives any transport consolidation** (R-9.1:
   ID-vs-name, URL spellings). Option C narrows the door; it does not close it.
4. **m-ydb has three transports of its own** (local / docker / remote-SSH), and
   `local` + `remote(localhost)` alias one instance by construction.

So R-9 is structural, not transitional. (Conversely, per the transport proposal
§8: R-9's answer is correct under every Option-C outcome — neither blocks the
other.)

### R-9.3 The decision — canonical-locus keying, with live resolution for network routes

> **The key is derived from the instance's canonical locus. Container and
> filesystem routes are self-canonical — their selector, canonicalized
> host-side, *is* the locus. Network routes are resolved by asking the live
> engine who it is — a status-grade, control-exempt round trip — and mapping the
> answer onto the locus. A route that cannot be resolved does not get a key: a
> bracket-requiring verb on it is refused, fail-closed.**

The derivation ladder (the driver remains the sole derivation authority, R-3):

| Route class | Resolution | Key | Engine call? |
|---|---|---|---|
| **docker** | `docker inspect` canonicalizes the selector (ID → **name**); works on a stopped container | `<engine>.docker.<name>` (e.g. `iris.docker.foia-t12`) | **no** |
| **local** | the interior the driver already derives (ADR D1) | `ydb.local.<sha256[:12] of realpath(gbldir)>` / `iris.local.<instance>` | **no** |
| **network** (iris remote/Atelier, ydb remote/SSH) | ask the live engine its **node fingerprint** (hostname; + instance name on IRIS, + realpath(gbldir) on YDB), then classify: | | **yes** (status-grade) |
| → node matches a local container (hostname or ID-prefix) | | that container's **docker key** — the unification that closes R-9.1 | |
| → node is this host | | the **local key**, from the engine-reported locus | |
| → neither (**foreign**) | | `<engine>.remote.<node>_<locus>` — from the *engine-reported* fingerprint, never the dialed spelling | |
| → engine unreachable, or docker enumeration **error** (≠ clean no-match) | | **no key: refuse** (`RUN_LOCK_UNRESOLVED`, exit 4). Control/status verbs unaffected. | |

Key grammar is unchanged (`<engine>.<class>.<locus>`, same three class words,
same `runLockKeyClean` normalization); what changes is that `docker` loci are
inspect-canonical names, and `remote` loci are engine-reported fingerprints.

**Why the lifecycle bootstrap problem dissolves rather than needing a patch.**
The kickoff's hard problem was: `lifecycle up` cannot ask a stopped engine who it
is, so the most destructive verbs cannot use an engine-reported key — and a
container-name fallback for them would re-split the key ("the same defect,
moved"). The ladder answers it structurally: **the verbs that cannot ask are
exactly the verbs whose selector already is the canonical locus.** Verified
against both drivers this pass:

- m-ydb `lifecycle up/down/restart/provision/destroy` are docker/local only
  (container start/stop; gde/mupip on host files) — self-canonical rows, no
  engine call needed, works on a stopped/nonexistent instance.
- m-iris `lifecycle provision/destroy` are exit-7 on remote
  (`lifecycle.go:296-302`), and remote `up`/`down`/`restart` are *probes/no-ops*
  ("the server is not ours to stop" — `lifecycle.go:22-31`); docker/local
  lifecycle is not wired at all yet (`remoteOnly`, `lifecycle.go:41-52`). When it
  lands, it lands on self-canonical rows.

So there is **no verb that both (a) must run against an unreachable engine and
(b) rides a network route** — the fallback that would have moved the defect is
never needed. A network-route verb against a dead engine was going to fail
anyway; refusing it at key derivation (`RUN_LOCK_UNRESOLVED`) is honest, not a
loss. The healthcheck window case also closes: a bracket that `lifecycle down`s
its engine mid-run holds `iris.docker.foia-t12`; a rogue `lifecycle up
--docker foia-t12` during the down-window derives the *same* self-canonical key
and queues. Under pure engine-identity keying that window was open.

**Recreate semantics (kickoff: "does it survive a container recreated under a
new name?").** Unchanged from R-3, now stated for both mechanisms: restart keeps
the name and the hostname (both measured: container hostname = container ID,
persisted in config) → same key across restarts ✓. Recreate under a *new* name is
a new instance → new key, correct ✓. Recreate under the *same* name: docker-route
key unchanged (conservative, serializes — same as R-3); a network route resolving
mid-recreate maps the new hostname to the same name → same key ✓. The residual —
holder's engine recreated *under* its live bracket — is §6b/§8(e)'s existing
bounded residual, unchanged.

**Who asks, and when — and why the driver never trusts a claimed key.** The
resolution runs in exactly the two places that derive today: `meta runlock-path`
(bracket-open; control-exempt, so the §7.3 bootstrap argument is untouched) and
the dispatch check of every bracket-requiring verb. The dispatch check **must
re-derive per call** rather than trust `M_RUN_LOCK_KEY` from the environment:
the ambient key is a **self-report**, and trusting it would let a lane holding a
vehu bracket aim a driver call at foia and pass verification (the token matches —
at the *claimed* key). v0.7.0's `RequireRunLock` already takes the driver-derived
ref; this design keeps that guarantee. Cost of keeping it, measured against the
probe numbers: docker/local routes pay one `docker inspect` (~10–30 ms against a
~100–160 ms `docker exec` dispatch — noise); network routes pay one status-grade
round trip (~24 ms on Atelier, from the probe's 1.11 s / 46 stages), roughly
doubling per-verb transport overhead — ≈ +1–2 s across a full `m test` run.
Accepted, and named.

**Cacheability (kickoff question): yes, but not in v1.** A binding cache
(`<lockdir>/bindings/<engine>.<class>.<selectorhash>` → key) would eliminate the
per-call round trip. The invalidation rule is pre-written so the future
optimization cannot weaken the net: *bracket-open always resolves live and
rewrites the binding; a dispatch check may serve from the cache, but must
re-resolve live before issuing any refusal.* Under that rule a stale binding can
cause a redundant round trip or a spurious wait, never a false pass. Deferred per
§10's YAGNI test: the tax is ~1 s per suite and the cache is a second mechanism
with its own staleness semantics — no consumer hurts enough yet. (The
engine-instance-path ADR's D4 anti-registry argument does not forbid it: D4's own
test — "a fact needed without its ground truth present" — is met here by
latency, and the live-revalidate rule removes the drift hazard. But it earns its
keep only when the tax bites.)

### R-9.4 Alternatives argued (not merely listed)

1. **Pure engine-reported identity, all verbs** (the kickoff's candidate). Right
   instinct — the engine is the ground truth of its own identity — wrong
   totality: the lifecycle verbs *must* fall back to something host-side, and any
   fallback keyed differently re-splits the domain ("the same defect, moved", the
   kickoff's own analysis). Patching that with a persistent selector→identity
   binding store builds a *second* mechanism with a cold-start hole (first-ever
   `lifecycle up` on a fresh box has no binding and no engine to ask). The ladder
   adopts engine-ask for exactly the route class where liveness is structural,
   and never needs the fallback. **Rejected as the general rule; adopted
   route-scoped.**
2. **Host-side canonicalization without an engine call** (resolve a loopback
   Atelier port to the container publishing it). Cheap, and it works when the
   engine is down — but it is wrong in the one case that will actually happen: an
   SSH tunnel (`ssh -L 52773:va-host:52773`) makes a *foreign* instance dial as
   loopback; port-resolution would find no publishing container (or, worse, an
   unrelated one) and misclassify. The engine-ask answers correctly through any
   tunnel, proxy, or spelling, because it asks the thing itself. Port-matching is
   also ambiguous under multiple published ports (52773→foia-t12, 52774→
   m-test-iris today — 1:1 now, nothing keeps it so). **Rejected as the
   network-route rule; `docker inspect` name-canonicalization survives as the
   docker-route piece** (it is host-authority over a host fact — which container
   owns this name — not a guess about the far side).
3. **A declared instance id** (host config: "this base URL is foia-t12"). The
   kickoff asks: is an *identity* the same as an *interior*? No — a wrong
   declared id cannot corrupt a run the way a wrong gbldir did. But the ADR D1
   argument was never about what the fact *does*; it was about how declaration
   *fails*: two separable host settings (selector, declaration) drift incoherent
   silently, and the blast here — a split lock — is precisely R-9.1's silent
   mutual-exclusion loss. The incident shape would be the 2026-07-11 env.sh
   incident verbatim: new selector, stale declaration, invisible exactly where
   the config was written. So D1 is **honoured by generalizing it**: *any*
   host-declared fact about the far side of the seam whose incoherence is silent
   is forbidden — identity included. **Rejected.**
4. **Accept the split; forbid cross-transport lanes by policy.** Not even
   available: the live healthcheck legitimately mixes transports in one lane
   today (R-9.1), so the policy would start out violated by the org's own
   canonical gate. And a convention is not a gate (undeclared-seams P-B) — this
   org has three measured incidents of sanctioned tools defeating conventions.
   **Rejected, explicitly rather than implicitly.**
5. **Token-scan verification** (skip key derivation in the dispatch check: scan
   all lock files for a record matching the presented token's hash). Eliminates
   the per-call round trip — but it proves the caller belongs to *some* live
   bracket, not to *this engine's* bracket, which is the claimed-key hole in
   different clothes (a vehu bracket's child would pass against foia). A
   verification that trusts a self-report is the defect class this lock exists to
   close. **Rejected.**

### R-9.5 The §7 deadlock argument, re-checked

Unbroken, clause by clause. The engine-ask is **transport traffic, not lock
acquisition** — it adds no edge to the lock graph, so §7.1's strict order
(`run-lock ≺ sesslock ≺ ledger-lock`) gains no back-edge. It runs inside
`runlock-path` (control-exempt — §7.3's bootstrap path is unchanged) and inside
the dispatch check *before* any lock probe, holding nothing. `RequireRunLock`
still never blocks (probe + compare); waiting still happens only in the
orchestrator's acquire. The one new failure mode — resolution fails — is a
**refusal**, not a wait, so §7.4's bounded-wait claim holds. No change to §7 is
required.

### R-9.6 Defeating the new key — the next doors (§8 style)

(a)–(g) stand as accepted. The new enumeration — (h)/(i) are the two R-3 let
through; (k) is my candidate for the one that gets through *this* design:

| # | Attack | Outcome |
|---|---|---|
| (h) | **Two transports, one instance** (the R-9.1 defect) | Both resolve to the container's canonical locus → one key → serialize. Red-proven by conformance C-RL-7 on foia-t12 (docker + remote must derive byte-equal keys). |
| (i) | **Two spellings of one route** (`--docker <id>` vs name; `localhost` vs `127.0.0.1` vs hostname; an SSH tunnel) | Docker: inspect canonicalizes to the name. Network: the key is built from the engine's answer, never the dialed spelling — all spellings and tunnels to one instance unify. |
| (j) | **Foreign instance, two local lanes** (one driving host → a genuinely remote engine, two different URLs) | Both resolve to `<engine>.remote.<node>_<locus>` (engine-reported) → serialize *on this driving host*. Lanes on **other** hosts remain uncovered — that is §8(f)/R-9.8, now visible in the key class itself. |
| (k) | **A host-network engine container** (`--net=host`) | Its hostname is the *host's* hostname → a network route resolving to it classifies **local**, while its docker route keys on the container name → **split**. Declared unsupported: zero exist in the org (measured — vehu/foia-t12/m-test-* all bridge-netted), and `meta doctor` should red on one. This is the honest answer's honest residual: named, gated, not papered. |
| (l) | **Two containers with the same explicit hostname** (docker allows it across networks) | Ambiguous node-match → `RUN_LOCK_UNRESOLVED` naming both candidates — fail-closed, never a guess. (Default hostnames are container IDs — unique; only explicit `--hostname` can collide.) |
| (m) | **Resolution flips mid-bracket** (container recreated under the holder) | The holder's calls verify at the key its record holds; a post-recreate lane derives the same name-key (docker) or the new fingerprint (network). Bounded by §6b's existing mid-call residual; the census remains the backstop. No new window. |
| (n) | **Resolver infrastructure fails** (docker daemon down during derivation; engine answers garbage) | Enumeration **error** ⇒ refuse (`RUN_LOCK_UNRESOLVED`) — never a silent fall-through to a selector-spelled key, which would reintroduce (h) exactly when the box is degraded. A clean no-match ⇒ genuinely foreign, keyed as such. The distinction is contract (C-RL-8). |

Plus the §3 undeclared-seams checklist re-run: the classification registry and
dispatch middleware are unchanged (a)/(b); no goldens carry derivation (c) — but
note the caps golden *does* change under R-9.7, deliberately; a fabricated
`M_RUN_LOCK_KEY` is now *provably* inert since the driver never reads a claimed
key for verification (d); refusals stay foreground + C-RL-7/8 run scheduled (e).

### R-9.7 Q2 — caps are connection-resolved (same disease, same cure)

The disease in both questions is one sentence: **the seam's declared shape does
not match the engine's reality.** Q1: the key declared a route to be an instance.
Q2: the capability document declares the *binary's* union while conformance and
callers live on a *connection* — `m-iris/internal/driver/caps.go:38` advertises
`exec script` on all three transports while remote refuses it at runtime
(`remote.go:124`, an unstructured `fmt.Errorf`, not even exit 7); the CapsDoc
comment admits provision/destroy are "advertised but report unsupported (exit 7)
on the remote transport". `Features.RunLock` — one per-driver bit, conformance
per-transport — inherits the flaw, and owner decision #4 (old driver ⇒ hard
error) *trusts that bit*.

**Decision: the capability document describes the CONNECTION, not the binary.**

- `Caps` gains `Transport string` (additive) — the resolved transport this
  document describes. `CapsDoc()` becomes `CapsDoc(conn)`: axes/verbs list what
  *this connection* actually dispatches (remote drops `exec script` and
  `lifecycle provision/destroy`); `Features`, including `RunLock`, are the
  connection's promises. `meta caps` already runs against a resolved connection —
  this makes its output honest rather than adding a new query surface (the
  kickoff's "cheaper honest answer", confirmed: no per-transport `Features` matrix
  type is needed, because the *document* is already per-connection).
- Decision #4's check is honest by construction: m-cli reads the bit over the
  same connection it is about to drive.
- The **verb class registry stays contract-global** (per-verb, not
  per-transport): m-iris remote realizes `lifecycle down` as a no-op, but it
  stays `mutating` — a class describes the verb's contract semantics; a transport
  that under-realizes a verb still enforces the stricter class. Coarse costs a
  wait; fine risks a lie.
- Conformance addition **C-CAPS-1** (per transport): every advertised verb must
  dispatch to something other than "unsupported", and calling an *unadvertised*
  verb yields structured exit 7 (which also forces `remote.go:124` onto the
  ladder). Runs beside C-RL-* in the nightly.

### R-9.8 Q3 — the production boundary, headlined (not footnoted)

`flock(2)` is per-kernel. In the deployment Option C optimizes for — a remote
IRIS dev server, developers reaching it over Atelier from their own workstations
— **each workstation serializes only itself**. §8(f)/§9 already declare this,
but as a footnote; the Option-C framing makes it the headline:

> **The run-lock is a single-driving-host lab/CI safety net.** It closes the
> three measured incidents on minty — two concurrent healthchecks, two 6 h
> suspended writers, 489 leaked scratch routines — which is real and worth
> building. It is **not** a production concurrency control, and the transport
> that matters in production (Atelier) is precisely where it covers least.

Made structural, not just textual: foreign-class keys
(`<engine>.remote.<node>_<locus>`) *are* the boundary — `m runlock status` on
one must say "serializes lanes on this host only", and this sentence joins §9's
named non-coverage list. A genuine multi-developer deployment needs an
**engine-side** answer — a lease or lock *inside* the instance, generalizing the
`^XTMP("VPKGLOCK")` KIDS already takes. That is a **named deferred item, not a
scheduled one, and not this design stretched**: an engine-side multi-host lease
needs expiry-and-fencing semantics that this design's no-TTL doctrine (R-5)
deliberately refuses for host-side flock — importing that doctrine blindly, or
abandoning it silently, are both wrong, which is why it is its own future design
pass with its own kickoff. Until then, nothing in the docs may imply the
run-lock generalizes.

### R-9.9 The contract delta — and the version verdict

**§5.8 delta** (applied on acceptance): the derivation table is replaced by the
R-9.3 ladder; `RUN_LOCK_UNRESOLVED` (exit 4) joins the refusal-code table; the
foreign-class coverage sentence joins the non-coverage list; the caps section
gains the connection-resolved rule + `transport` field. §5.8's key grammar,
lock home, record schema, token semantics, flags, class table, middleware
sketch, and C-RL-1…6 are untouched.

**SDK delta** (m-driver-sdk, coordinator):

- `RunLockKey(engine, class, locus)` — same signature, redefined params: class ∈
  `docker|local|remote` is the **locus class**, not the dialed transport; locus
  is the **canonical locus**. Docstring + contract change only.
- New shared helpers for the docker legwork both drivers need identically:
  canonicalize name/ID → name (stopped containers included), and match an
  engine-reported node against local containers (hostname / ID-prefix), with the
  error-vs-no-match distinction surfaced. The engine-ask itself stays per-driver
  (Atelier vs SSH vs session — vendor logic, below the SDK).
- New code `CodeRunLockUnresolved = "RUN_LOCK_UNRESOLVED"`, exit 4.
- Conformance: **C-RL-7** (two routes, one instance ⇒ byte-equal
  `runlock-path` — the R-9 red-proof; required where a dual route exists, which
  the iris lab lane has; visible-skip otherwise), **C-RL-8** (unresolvable ⇒
  refusal, never a selector-spelled fallback key), **C-CAPS-1** (R-9.7).
- `Caps.Transport string`, additive.

**Verdict: ADDITIVE — minor — tag `v0.8.0`; both spikes pin v0.8.0 instead of
v0.7.0.** Argument: no v0.7.0 public symbol is removed or re-signatured; the
bracket API, record schema, refusal codes, and C-RL-1…6 survive verbatim; the
additions are fields, codes, helpers, and cases. The one *semantic* change —
what `RunLockKey`'s parameters mean — lands with **zero implementers**: no
driver has built `runlock-path`, none advertises `features.runLock` (P0.2b is
blocked on exactly this), and conformance capability-gates on that bit, so there
is no deployed derivation to break. This is the last moment the change is
additive; after the spikes land it would be a breaking (major) migration with a
transition window in which old and new drivers derive different keys for one
instance — R-9.1 again, self-inflicted at the version seam. That is the
sequencing argument for deciding R-9 **now**, before any spike starts.

### R-9.11 Amendments A–C (accepted with #6–#8, 2026-07-13)

Three amendments were attached at acceptance. They do not change the answer; they
harden it.

**A — the `+24 ms` per-call tax is INFERRED, not measured. Do not ship it as a fact.**
§R-9.3 derives it from "the probe's 1.11 s / 46 stages" — but that is the cost of an
Atelier **PutDoc + compile**, which is a different operation that merely lands in a
similar magnitude. What *was* measured (5 runs each, foia-t12, 2026-07-13): a **full
driver verb invocation costs ~115 ms over docker and ~111 ms over remote** — the two
are indistinguishable, both dominated by driver subprocess spawn. But the R-9 tax is
a **marginal in-driver** round trip (one extra call inside an already-spawned driver
process), and that **cannot be isolated from outside the driver**. Neither number
measures it.

**Obligation on the m-iris spike:** produce the real in-driver figure as part of
C-RL-7 (a five-line benchmark) and record it here. **If it exceeds ~30 ms it is no
longer noise against a ~111 ms verb, and the §R-9.3 binding cache stops being
deferrable** — its pre-written invalidation rule must then be built, not parked. That
fork currently rests on an inferred number, which is exactly what this org's
"measure, don't infer" rule exists to prevent.

**B — the resolution recursion hazard gets a red-proof, not a sentence.** The dispatch
check re-derives per call; on a network route that derivation **makes an engine call**.
If that call re-enters the dispatch middleware, it recurses without bound. §R-9.3 names
the mitigation ("status-grade, driver-internal") — but *driver-internal* is a
discipline, not a gate, and this is the single most likely implementation bug in either
spike. **Each driver must carry a test: a bracket-requiring verb on a network route
completes without re-entering the middleware.**

**C — the loud break. `RunLockKey` is REMOVED, not redefined.** §R-9.9 argued the
change was additive because "no v0.7.0 public symbol is removed or re-signatured" —
`RunLockKey(engine, transport, selector)` would keep its signature and only change what
its parameters *mean*. **That is the most dangerous shape of change there is: the
compiler cannot catch a stale caller.** So the amendment inverts it deliberately:
`RunLockKey` is **gone**, replaced by `Locus.Key` — a **different shape** — so a stale
caller fails to **compile** rather than silently deriving a legacy, route-spelled key.

The version verdict is unchanged (**v0.8.0**; v0.x permits it), but the *argument* is
amended: this is a **deliberate re-signature**, not an additive one. It is free exactly
once — now — because zero drivers have implemented `runlock-path`. That is the whole
sequencing case for deciding R-9 before the spikes, and it is now enforced by the
compiler rather than by memory.

### R-9.10 Owner decisions — #6, #7, #8 — **ALL THREE ACCEPTED 2026-07-13 (Rafael)**

**Accepted as recommended, with amendments A–C above (§R-9.11).** Built and tagged
**v0.8.0**. Both P0.2b spikes are released to run in parallel against it.

| # | Question | RECOMMENDED | Consequence if accepted |
|---|---|---|---|
| 6 | **R-9 key derivation** | **Canonical-locus keying with the R-9.3 ladder**: self-canonical docker/local; engine-ask on network routes; fail-closed `RUN_LOCK_UNRESOLVED`; per-call driver-side resolution (no claimed-key trust); binding cache deferred with the invalidation rule pre-written | SDK v0.8.0 slice (coordinator, small) lands first; both spikes pin v0.8.0 and build `runlock-path` on the ladder; C-RL-7/8 join the suite |
| 7 | **Caps shape (Q2)** | **Connection-resolved caps** + additive `Caps.Transport`; verb classes stay contract-global; C-CAPS-1 per transport | `CapsDoc(conn)` in both drivers (m-iris drops `exec script`/`provision`/`destroy` from remote caps; `remote.go:124` → structured exit 7); caps goldens become per-transport |
| 8 | **Production boundary (Q3)** | **Headline the single-driving-host scope** (§R-9.8 box into §9); foreign-key status output carries it; engine-side lease = **named deferred item**, its own future design pass, not scheduled, not implied | Doc + `runlock-status` wording; no code beyond the foreign-key labeling; the lease item gets a one-line stub in the tracker's "later phases" so it cannot silently vanish |

**Nothing in R-1…R-8 or §11 #1–#5 is reopened by any of these.** If #6 is
vetoed, the fallback ladder-less options are all argued and rejected in R-9.4 —
the honest alternative to #6 is accepting a known silent mutual-exclusion hole
and saying so in §9, which the author does not recommend.

---

## 6. The m-driver-sdk contract change — SPEC (not built)

### 6a. Go surface (`package mdriver`)

```go
// RunLockOptions selects the engine instance and the acquire behavior.
type RunLockOptions struct {
    Client      *Client       // the driver to derive key/path through (runlock-path)
    Wait        time.Duration // 0 = non-blocking try; bounded wait otherwise
    Consumer    string        // narrative: "m test", "v pkg install VSL.kids", …
    Dir         string        // override for tests only; default ~/data/vista-forge/run-lock
}

// RunLock is a held (or joined) per-engine run bracket.
type RunLock struct {
    Key, Path, Token string
    // owned: only the acquiring process's Release releases; a joined
    // handle's Release is a no-op.
}

func AcquireRunLock(ctx context.Context, o RunLockOptions) (*RunLock, error)
func JoinRunLock(ctx context.Context, o RunLockOptions) (*RunLock, error) // token from env; verifies against the live record
func (l *RunLock) Release() error
func (l *RunLock) Env() []string // M_RUN_LOCK_TOKEN=…, M_RUN_LOCK_KEY=… for child processes
```

`Client` gains `RunLockToken string`; when set, every driver invocation
appends `--run-lock <token>`. Env fallback in the driver
(`M_RUN_LOCK_TOKEN`) covers the bash-wrapped chain; the explicit flag is the
loud channel and wins. *(Both env names go to the env-var-registry for
classification when that proposal lands: scope = ephemeral, process-subtree,
never committed.)*

### 6b. Lock file + holder record + fencing

- Path: `<dir>/<key>.lock`. Acquire = `open(O_CREATE|O_RDWR)` +
  `flock(LOCK_EX[|LOCK_NB])`; then truncate-and-write the record; release =
  best-effort append `releasedAt`, `LOCK_UN`, close.
- Record (JSON, one object): `{v:1, key, tokenSHA256, pid, pgid, host, user,
  consumer, startedAt}`. The record stores the token's **SHA-256, never the
  token** — a joiner gets the token by process inheritance (env), never by
  reading the file, so a "helpful" script cannot scrape ownership (cheap
  hardening; this is anti-footgun, not security — §9).
- **Fencing property:** if the holder dies, the kernel frees the flock; a new
  lane acquires and **overwrites the record** with its own tokenSHA. Any
  surviving orphan child of the dead bracket still presenting the old token now
  fails the record compare → refused. Kernel-anchored fencing of zombie writers
  — stated as a contract guarantee and conformance-tested (C-RL-4).
- Residual (named honestly): the driver's ownership check is at call *entry*;
  if the holder is SIGKILLed mid-driver-call and a new lane acquires within
  that same call's execution window, the tail of the in-flight call overlaps
  the new bracket. Bounded by one call; not closable with advisory locks; the
  census remains the backstop.

### 6c. Verb mutation-classification registry (undeclared-seams P-C)

Every contract verb carries a class; the class — not a per-verb hand list in
prose — drives enforcement:

| Class | Meaning | Run-lock requirement |
|---|---|---|
| `mutating` | can change engine state (routines, globals, namespace) | token required — refuse otherwise |
| `read` | reads engine state whose torn view poisons a consumer (`data get/walk`, capture) | token required (same rule; a snapshot racing a writer is V2's torn pre-image) |
| `status` | instance metadata only (`status`, `caps`, `doctor`, `ping`, version) | none |
| `control` | unwedge/observe a run (`exec abort`, `reap-sessions`, `runlock-*`) | none — the declared escape hatch (R-7) |

`exec eval/run/script` are `mutating` (arbitrary M writes). The registry is an
exported SDK map (`mdriver.VerbClass`); the contract doc table is its rendered
projection; **conformance red-gates coverage**: every verb a driver advertises
in `caps` must be classified — an unclassified verb is red, so adding a verb
*forces* the taxonomy question at add-time. Enforcement sits once, in each
driver's dispatch middleware keyed off the registry — a new verb inherits the
check; a hurried developer cannot add an unenforced verb without going red
(defeat-checklist (a)/(b)).

### 6d. Driver + m-cli verbs

- Driver `meta` axis: `runlock-path` (prints key + path for the connection —
  the single derivation authority), `runlock-status` (record + `/proc/locks`
  measurement + holder `/proc` state classification:
  `UNHELD | RUNNING | STOPPED | HELD_BY_ORPHAN_FD`).
- m-cli: `m runlock hold --engine <e> [--docker <c>] [--lock-wait <d>] -- cmd
  args…` (acquire → export env → run child → cleanup → release; the bash
  bracket); `try` (R-6); `status`; `path`.

### 6e. Refusal codes + conformance

Envelope-level structured errors (driver `error`, not `engineError`):
`RUN_LOCK_REQUIRED`, `RUN_LOCK_MISMATCH`, `RUN_LOCK_NOT_HELD`,
`RUN_LOCK_TIMEOUT` (m-cli/acquire side), `SKIPPED_ENGINE_BUSY` (try-mode
outcome, not an error). Distinct exit code (value assigned at build within the
clikit taxonomy; per undeclared-seams D-1 the codes enter the declared error
vocabulary).

Conformance additions (D5 suite, both drivers, nightly + meta-gate §7):
- **C-RL-1** mutate without token → `RUN_LOCK_REQUIRED`.
- **C-RL-2** mutate with valid token + held lock → proceeds.
- **C-RL-3** token presented, lock free → `RUN_LOCK_NOT_HELD`.
- **C-RL-4** token presented, lock held by *another* record → `RUN_LOCK_MISMATCH` (fencing).
- **C-RL-5** `status`/`control` verbs run with no token.
- **C-RL-6** try-mode on a held lock → busy outcome, no side effects.
These are the red-proofs — the gate's own liveness is asserted (KAT
principle), and they run *scheduled*, feeding the meta-gate's staleness
discipline (P-B: an unobserved gate is not a gate).

---

## 7. The deadlock argument (stated, not asserted)

A deadlock needs a cycle of processes each *holding* one resource and
*waiting* for another. Enumerate the lock universe and the waits:

Locks: per-engine run-locks (this design), the m-iris per-call sesslock, the
v-pkg ledger flock. Waits: the orchestrator's bounded acquire; the sesslock's
per-dispatch wait; the ledger lock's short critical section.

1. **A strict acquisition order exists and no edge reverses it:**
   `run-lock ≺ sesslock ≺ (leaf) ledger-lock`. The run-lock is taken at
   bracket-open, before any driver call, so no path acquires a run-lock while
   holding a sesslock; the sesslock is taken inside a single dispatch; the
   ledger lock wraps only a read-tip→seal→append on a local file
   (`attest.go`/`lock_unix.go` — verified: no engine call inside `fn`). A
   cycle needs a back-edge; none exists.
2. **Hold-at-most-one run-lock.** Consumers bracket one engine at a time
   (dual-engine scripts bracket per lane, sequentially — R-8 row 5). Two
   run-locks are therefore never held by one process, so the classic AB-BA
   between vehu and foia lanes cannot form. (If a future consumer genuinely
   must hold both, the fallback discipline is fixed lexicographic key order —
   documented now so the exception has a rule waiting.)
3. **In-bracket calls never wait on the bracket.** The driver's ownership
   check is `LOCK_NB` + compare — a probe, never an acquisition — so the
   historical self-deadlock class (abort waiting on the lock its own run
   holds; a child re-acquiring what its parent holds) is structurally absent:
   owners *verify*, only outsiders *wait*, and only at bracket-open.
4. **Every wait is bounded** (`--lock-wait`, default finite) **and the blocker
   is always external and killable**: the wait's owner holds nothing (acquire
   is the first act of a bracket), so even a maximal timeout parks one lane
   without transitively blocking anything it holds.
5. **A dead holder cannot block anyone**: flock dies with the process
   (kernel), so crash/SIGKILL/OOM of any holder frees the next waiter without
   operator action. The one unbounded-*hold* case is a **stopped** (or truly
   hung) holder — that is a liveness loss in the holder, not a deadlock cycle,
   it cannot propagate (waiters time out, diagnose, and exit), and R-5
   mechanizes its resolution.

Therefore: no cycle (1–3), no unbounded wait (4), no permanent hold except the
human-diagnosable stopped-writer case (5). The design needs **no fail-open
escape to stay live** — which is what licenses making exclusivity fail-closed.

---

## 8. Defeating my own lock — the seven scenarios

| # | Attack | Outcome under this design |
|---|---|---|
| (a) | A lane forgets the bracket | Sanctioned tools cannot (auto-bracket). A hand-rolled driver call hits the dispatch middleware → **refusal** (`RUN_LOCK_REQUIRED`), not corruption. This is the design's core trade: the corruption class becomes an error-message class. |
| (b) | Takes it and dies | Kernel frees the flock instantly — no stale lock, no operator action. Residue (staged routines, dangling intent) is the *census/sweep/adopt* jurisdiction, deliberately not the lock's (§R-7: release ≠ clean). Orphan children of the dead bracket are token-fenced (§6b) the moment a new lane acquires. |
| (c) | Takes it and is SIGSTOPped | Lock held indefinitely — **correct** (the writer may resume). Waiters detect state `T`, exit early with the mechanized triage (B0-ledger diagnosis; SIGKILL-while-stopped, never SIGCONT; pgid kill; `docker top` check). The 6 h manual incident becomes a first-wait diagnostic. No auto-break, ever. |
| (d) | Nested acquisition (`m test` → `v pkg install` → driver call) | The inner tool finds `M_RUN_LOCK_TOKEN`, `JoinRunLock` verifies against the live record, proceeds reentrantly; its `Release` is a no-op. No second acquire → no self-wait. A nested tool spawned with a *scrubbed* env can't prove ownership and times out with a message naming its own parent as holder — a loud misconfiguration, not a deadlock (bounded wait). |
| (e) | Container restarted under the holder | Key = container *name* → the same lock still governs; no second lane can slip in during the restart. The holder's subsequent calls fail on engine state (its staging is gone) and its bracket closes normally; journal + census reconcile the residue. The lock's correctness is unaffected — it serializes *access*, it does not promise the engine survived. |
| (f) | Two lanes on two hosts | **Out of scope, declared.** flock is per-kernel; the deployment model is one box (minty) — both engines are local containers, and CI is the self-hosted runner on the same host. The m-iris *remote* transport from a second machine would bypass the lock entirely: named as a limitation; if a second driving host ever appears, the lock must move engine-adjacent (or a shared-FS/lease design — NFS flock semantics are their own hazard). Do not pretend coverage that isn't there. |
| (g) | The bash consumer that forgets `flock(1)` | Its `v pkg`/`m` calls each auto-bracket individually — every *op* is still serialized and no state is corrupted; what degrades is *run atomicity*: another lane can interleave between its ops (e.g. census-before / install / census-after straddling a foreign install → **false diagnosis, not corruption**). R-8 wraps the known bash consumers in `m runlock hold`; the residual for future unwrapped scripts is a false-red class the census will surface loudly. Hand-rolled `flock(1)` without the wrapper is documented as unsupported (its children would be refused — a loud dead-end, not a silent hole). |

Plus the undeclared-seams §3 defeat checklist: **(a) new flag/verb** — the
classification registry red-gates unclassified verbs at add-time (§6c);
**(b) second helper** — enforcement is in the driver dispatch, beneath any
helper; hand-rolled transport is already red-gated by the m-ci engine-access
scan + the PreToolUse hook; **(c) golden regen** — no goldens carry the
enforcement (it's middleware + conformance, not a snapshot); **(d) dynamic
construction** — a fabricated token fails the SHA compare; the token isn't
scrapable from the record (§6b); a *cooperating-but-wrong* tool can only end at
a refusal; **(e) who observes a red** — refusals are foreground CLI failures in
the invoking lane; the scheduled conformance red-proofs and G-LEAK-SCAN's
busy/clean STAMP feed the meta-gate (P-B).

---

## 9. What this lock does NOT protect (named, per the obligations)

- **A human (or agent) running `docker exec … mumps` / `iris session` by
  hand.** That is the `engine-stack-guard` hook's jurisdiction + the m-ci
  engine-access scan — the lock only governs traffic through the driver seam.
- **Malice.** This is advisory locking among cooperating tools. A tool that
  deliberately forges ownership, edits the record, or unlinks the lock file is
  out of the threat model (solo box; the SHA-256 record is anti-footgun, not
  auth).
- **Engine-internal background mutation.** TaskMan jobs, engine-side crons, or
  a KIDS install queued *inside* the engine mutate state no host bracket can
  see. The census measures outcomes; the lock cannot serialize what never
  crosses the seam.
- **A second driving host** (defeat f) — declared out of scope.
- **Clean state.** Release ≠ clean (§R-7). The lock is the *exclusivity* half
  of §4.1's contract; G-CLEAN/census is the *state* half. Neither substitutes
  for the other.
- **The IRIS device capture race** — still the sesslock's job (retained,
  fail-open, per-call).
- **Mid-call fencing** — the bounded §6b residual (holder killed mid-driver-call
  overlapping a new bracket for the tail of that one call).

## 10. YAGNI — why a run-lock at all, honestly

*"Solo org, one box — just don't run two things at once."* The org's real
operating model already **is** concurrent by design: parallel session lanes
(coordination model), scheduled gates (nightly conformance, the planned
G-LEAK-SCAN), CI on push, plus an operator — and the discipline failed three
measured times in one week (two concurrent healthchecks; two 6 h suspended
writers; 489 leaked scratch routines as the accumulated residue of unserialized
runs). "Don't run two things" is a convention, and §R-2's rejected-alternatives
analysis applies to it directly: every incident above was a sanctioned tool
with no lock to take. The minimal counter-proposal (a bare `flock(1)` wrapper
file, by convention, no enforcement) would have prevented **none** of them.
What actually pays is the refusal at the choke point; the bracket/token
machinery is the minimum that makes refusal compatible with multi-call runs.
Conversely, this design deliberately does **not** buy: reader/writer shared
modes (LOCK_SH is a compatible later extension of the same file), lease/renewal
protocols, multi-host coverage, or a lock service — each is machinery for a
consumer that does not exist (engine-instance-path ADR D4's test: no consumer,
no artifact).

## 11. Owner decisions — ALL FIVE DECIDED (2026-07-12, Rafael)

Every question was accepted **as recommended**. The design is therefore adopted
whole; there are no amendments to reconcile.

| # | Question | **Decision** | Consequence for the build |
|---|---|---|---|
| 1 | R-2 enforcement | **Driver refusal + token** (not bracket-by-convention) | The lock **prevents**, it does not merely detect. The token machinery is in: SDK ships `AcquireRunLock`/`JoinRunLock` + `Client.RunLockToken`; **both drivers enforce in dispatch middleware**. A hand-rolled consumer that skips the bracket meets `RUN_LOCK_REQUIRED`, not corruption. |
| 2 | `read`-class verbs | **STRICT — reads require the bracket too** | Closes audit V2's torn snapshot (the read the F2 incident then restored as truth). Cost accepted: reading a busy engine waits. **Diagnosis is unaffected** — the `control` class (`status`/`caps`/`doctor`/`ping`/`abort`/`runlock-*`) is exempt by §R-7, so a stuck run can always be observed and unwedged. |
| 3 | Timeout defaults | **30 s interactive / 10 min batch / cron try-only** | `m vista exec` ≈30 s; `m test`, `m coverage`, `v pkg`, healthcheck lanes ≈10 min; G-LEAK-SCAN never waits (`SKIPPED_ENGINE_BUSY`). The *shape* was already contract (always bounded, always loud, always `--lock-wait`-overridable); these are the numbers. |
| 4 | `Features.RunLock` transition | **Hard error + upgrade hint** | No silent unlocked run, ever — a caller must never believe it is protected while it is not (the "net that trusts a self-report" defect, which would otherwise re-enter at the *version* seam). A stale driver binary in `dist/` is a loud, brief, self-correcting failure. Consequence: **the R-8 landing order is now load-bearing** — m-cli/v-pkg must not ship their auto-brackets before both drivers advertise the capability. |
| 5 | Naming | **Top-level `m runlock hold\|try\|status\|path`** | Reads well at the call sites that matter (the bash wrappers): `m runlock hold ydb.docker.vehu -- ./lifecycle-healthcheck.sh`. One new top-level noun in `m`, distinct from `m engine` (container lifecycle). |

**Nothing was vetoed and nothing was amended**, so no part of §§1–10 is
superseded: the fail-closed exclusivity stance (§2), the deadlock argument (§7),
the seven defeat scenarios (§8) and the named non-coverage (§9) all stand exactly
as written.

**Decisions #6–#8 (the R-9 key amendment) are OPEN — see §R-9.10.**
