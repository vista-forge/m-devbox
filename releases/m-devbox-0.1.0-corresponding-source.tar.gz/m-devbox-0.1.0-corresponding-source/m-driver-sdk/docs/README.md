# m-driver-sdk docs

`m-driver-sdk` is the coordination sync point (D0) for the m-engine-drivers
effort — it owns the neutral contract types and is the orchestrator that keeps
`m-ydb` and `m-iris` parallel and consistent. This folder holds the live
cross-repo status; the normative contract itself lives in the central `docs`
repo (see below).

## Layout

- [`implementation-tracker.md`](implementation-tracker.md) — **live** Tier-D
  tracker: the single source of truth for per-repo, per-milestone status across
  `m-driver-sdk` / `m-ydb` / `m-iris`. Reconcile it on every cross-repo change.
- [`design/run-lock.md`](design/run-lock.md) — **DRAFT, decision-seeking**: the
  per-engine run-lock seam design (engine-state-hygiene-2 §4.0 / v-pkg audit V2)
  — bracket API, token fencing, driver refusal, R-1…R-8. Build starts only on
  owner acceptance; execution tracked in the `docs` repo's
  `engine-state-hygiene-2-tracker.md`.
- `archive/` — retired docs from this repo (kept, never deleted):
  - [`archive/continue-implementation.md`](archive/continue-implementation.md) —
    archived fresh-session kickoff prompt to resume the implementation.

## Normative spec (read-only, central `docs` repo)

`~/vista-forge/docs/m-engine-drivers/` — `driver-contract.md` (v1.0),
`driver-implementation-plan.md` (§4 m-ydb, §5 m-iris), `engine-command-survey.md`,
`coordination-model.md`, `phase-0-reconciliation.md`.

Shared coordination memory is **not** kept here — it lives in the central `docs`
repo's `docs/memory/` (recalled by the coordinator session).
