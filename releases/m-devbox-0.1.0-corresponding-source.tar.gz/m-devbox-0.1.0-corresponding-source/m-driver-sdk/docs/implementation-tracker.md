---
status: accepted
---

# m-engine-drivers — implementation tracker

**`m-driver-sdk` is the OWNER and ORCHESTRATOR of the m-engine-drivers implementation.**
This document is the single source of truth for cross-repo status. Every change in any of the
three repos must reconcile here: when you land work, update the tables below in the SAME change
(or immediately after) so the three implementations stay parallel and consistent.

> Three repos, one system. m-cli speaks only the neutral contract; the two drivers must look
> identical to it. The SDK + this tracker are the coordination point — shared shapes change here
> first, both drivers pin the same SDK version, and every stage is validated against BOTH real
> engines.

Last reconciled: **2026-06-12** (the reference engine **`Client`** + driver-binary
**`Locate`** lifted from m-cli's `internal/driver` into the SDK — fulfills waterline
rule 3 "the engine Client lives in m-driver-sdk; m-cli and every `v` tool import it";
staged for v0.3.0 on `coordination`. Also fixed a pre-existing conformance bug:
`null` data (a nil `json.RawMessage` round-trips to `null`) was not counted as empty,
so the `ok=false` "neither error nor data" check never fired). Prior: 2026-06-11 (m-ydb
**remote (SSH) transport** + `ydbdriver` facade; NO SDK change). Prior: 2026-06-06 (SDK
M5 `CoverResult` defined on `coordination`, untagged — staged for v0.3.0).

Legend: ☑ done · ◐ in progress / partial · ☐ not started · — n/a · 🔒 gated (needs a resource)

---

## 1. Repo snapshot

| Repo | Role | GitHub (public, vista-forge) | Branch | SDK pin | Head | Real-engine tier |
|---|---|---|---|---|---|---|
| **m-driver-sdk** | contract + Transport, **orchestrator** | `m-driver-sdk` | `main` (tags v0.1.0, v0.2.0, **v0.3.0**) | — | `63a7ffa` | — |
| **m-ydb** | D2 — YottaDB driver | `m-ydb` | `m-ydb-driver` | **v0.2.0** | _M3 exec done; +remote(SSH) transport_ | `m-test-engine` (YottaDB r2.07) ☑ · remote(SSH) live ⬚ pending |
| **m-iris** | D1 — IRIS driver (was irissync) | `m-iris` | `m-iris-driver` (PR #1 → main, OPEN) | **v0.2.0** | `a502071` | `m-test-iris` (IRIS CE 2026.1) ☑ |

Local paths: `~/vista-forge/{m-driver-sdk,m-ydb,m-iris}`. Both drivers depend on the SDK by
tagged version through the public Go proxy (no `replace`).

---

## 2. Milestone × repo status (the master rollup)

Milestone ladder from `docs/m-engine-drivers/driver-implementation-plan.md` §2. The SDK column is
the shared shape/seam each milestone needs (defined once, consumed by both drivers).

| M | Axis / concern | m-driver-sdk (shared shape) | m-ydb | m-iris |
|---|---|---|---|---|
| **M0** | scaffold + `meta` (caps/version/info/schema) + transport seam | ☑ `Transport`, `Caps/Axes/Features`, `EngineError`, `FakeTransport`, `ContractVersion` | ☑ | ☑ |
| **M1** | `lifecycle` + health probes + `doctor` | ☑ `Status`, `StateResult`, `Check`, `DoctorResult`, `Axes.Wired()` (**v0.2.0**) | ☑ (real YDB) | ☑ (real IRIS) |
| **M2** | `sync` (source axis) | — (filesystem / Atelier; no shared payload) | ☑ full axis (list/pull/status/verify/diff/push/deploy/rm + bare-name `--filter`, filesystem-native over `$ydb_routines`; push conflict-checked, deploy `--prune` common-prefix guard) | ◐ verbs exist (list/pull/status/verify/push/deploy); add diff/rm + bare-name `--filter` |
| **M3** | `exec` (load/run/eval/abort) + `engineError` | ☑ `ExecRequest`/`ExecResult`, `EngineError`, `LoadRequest`/`LoadResult` | ☑ load/run/eval/abort + engineError (runtime via $ETRAP→$ZSTATUS over `%XCMD`; compile via ZLINK stderr listing; ephemeral `--prefix`; real r2.07) | ◐ remote substrate spike ☑ (real IRIS); wire exec/eval/abort commands |
| **M4** | `data` (get/set/kill/query/export/import) | ☑ `GlobalRef`/`GlobalNode`, `SetGlobal` (export/import shape TBD) | ☐ | ☐ |
| **M5** | `cover` (trace → LCOV) | ◐ `CoverResult` (lcov/coveredLines/totalLines/linePercent) defined on `coordination`, untagged | ☐ | ☐ |
| **M6** | `admin` (backup/restore/check/journal) | ☐ neutral result shape TBD | ☐ | ☐ |
| **M7** | `native` passthrough (full backend surface) | — (per-engine; not in contract) | ☐ | ☐ |
| **M8** | conformance green on all transports + CI matrix | ◐ `conformance` pkg + `cmd/m-driver-conformance` (D5) built, unit-green | ☑ **16/16 local** (doctor finding fixed via clikit `ResultExit`) | ☑ **16/16 live vs m-test-iris** (remote) |

Per-driver critical path: **M0 → M1 → M2(staging) → M3 → M5 → M8**; M4/M6 after M3; M7 any time
after M0. (m-ydb: no `remote`. m-iris: `remote` attach-mode — provision/destroy unsupported there.)

---

## 3. SDK API surface (package `mdriver`) — what exists vs pending

`ContractVersion = "1.0"`. Current tag: **v0.3.0** (tagged 2026-06-12 on `main`; `coordination` = `main`).

| Symbol | Since | Notes |
|---|---|---|
| `Transport` (Health/Load/Exec/ReadGlobal/SetGlobal) | v0.1.0 | the frozen verb-level seam |
| `ExecRequest`/`ExecResult`, `LoadRequest`/`LoadResult` | v0.1.0 | field-dispatched exec (Script>EntryRef>Command) |
| `GlobalRef`/`GlobalNode`, `Health` | v0.1.0 | |
| `EngineError` | v0.1.0 | §7 fault; clikit keeps its own copy for the envelope (drivers convert at the boundary) |
| `Caps`/`Axes`/`Features`, transport consts, `FakeTransport` | v0.1.0 | `Axes` is struct+omitempty (honest caps) |
| `Axes.Wired()`, `Check`, `DoctorResult`, `Status`, `StateResult` | **v0.2.0** | M1 doctor + lifecycle payloads |
| `CoverResult` (lcov/coveredLines/totalLines/linePercent) | **v0.3.0** | M5 cover payload (contract §5.5). No new Transport verb — driver composes `Exec`+`ReadGlobal` |
| `Client`/`NewClient`, `CmdRunner`/`ExecRunner` | **v0.3.0** | the reference engine client (subprocess + JSON-envelope seam): `<axis> <verb> --transport <t> [conn] --output json`. `Status`/`Caps`/`ExecEval`/`ExecRun`/`Load`. Lifted from m-cli's `internal/driver` (waterline rule 3 — the seam's transport monopoly) |
| `Locate`/`LocateDeps`/`DefaultLocateDeps` | **v0.3.0** | driver-binary resolution (contract §4 order: `$M_<ENGINE>_BIN` → next to exe → sibling `dist/` → PATH). Lifted with `Client` |
| admin result shape | — | **pending (M6)** |

**Versioning / repin protocol:** add types/fields → minor bump; change/remove → major (contract §8).
To bump: edit SDK → commit → `git tag vX.Y.Z` + push tag → in BOTH drivers
`go get github.com/vista-forge/m-driver-sdk@vX.Y.Z` (default proxy, so go.sum is sumdb-verified
for CI) → `go mod tidy` → test → commit `deps: pin … vX.Y.Z`. Both drivers always pin the SAME version.

---

## 4. Per-repo next actions

**m-ydb (D2)** — **M2 `sync` COMPLETE** (plan §4 tasks 6+7): full axis
`list/pull/status/verify/diff/push/deploy/rm` + bare-name `--filter`, filesystem-native over
`$ydb_routines`. `internal/{manifest,mirror,source,udiff}`; `source.Store` (List/Read/Write/Remove) =
host-fs `FileStore` (local) | container `ShellStore` (docker, over `transport.Session.Sh`; write via
base64→`base64 -d`). push is conflict-checked vs the manifest (`manifest.CheckConflict`, exit 4 unless
`--force`) and lands content in both mirror + instance; deploy installs a library with a common-prefix
prune guard (refuses prune with no common prefix); diff = LCS unified (`internal/udiff`); rm clears
instance+mirror+manifest. caps advertises all 8 verbs; golden regenerated. Validated vs real YottaDB
r2.07 via `make test-it` (ShellStore list/read + write/read/remove round-trip, arbitrary bytes).
**M3 exec ☑ COMPLETE** (plan §4 tasks 8,9,10): `load`/`run`/`eval`/`abort` + `engineError`.
`ExecTrapped` xecutes the work under a `$ETRAP` via `%XCMD` (clean non-direct context; `-direct` prints
`YDB>` prompts and bypasses the trap), capturing sentinel-delimited `$ZSTATUS` → §7 EngineError (mnemonic
by `%FAC-S-NAME` regex so a `%`-routine location isn't mis-read). The configured routine path is layered
onto `$ZROUTINES` at runtime (not the env) so staged routines resolve while `%XCMD` stays linked.
`Compile` (ZLINK) surfaces **compile** faults from the stderr listing (`parseCompileError`; ZLINK writes
the listing to stderr with exit 0, no trap). `exec load` stages (store.Write) + compiles; `run`/`eval`
→ {stdout,status}; `abort --prefix` greps the `;<prefix>` marker filtered to yottadb procs via
`/proc/<pid>/comm` → `mupip stop`. Validated vs real r2.07 (run staged→"HI42", `%YDB-E-LVUNDEF`,
`%YDB-E-INVCMD` compile, abort no-op). caps `exec:[load,run,eval,abort]`. **+remote(SSH) transport (2026-06-11, VSL effort):**
3rd transport beside local/docker — wraps the yottadb argv in `ssh`, sources EnvFile on the far
side; Health/Exec/Version over SSH; lifecycle attach-only; sync-over-remote not wired; caps advertises
`remote`+`features.remote=true`; public `ydbdriver` facade (`New→mdriver.Transport`) for m-cli/VistaEngine;
reverses YDB-no-remote (contract §3 amended). Unit-green; **live SSH `make test-it` PENDING** (sandbox
blocks ssh/docker). NEXT: **M5 cover** (`view "TRACE":1:"^ycov"`→LCOV; port m-cli/internal/mcov) and/or
**M4 data**. Deferred: `lifecycle logs` (parity with m-iris). Granular tasks: plan §4.

**m-iris (D1)** — M0+M1 done & real-IRIS-validated; next **finish M2 `sync`** (add diff/rm +
bare-name `--filter`; regroup is done) and **M3 exec** (wire run/eval/abort onto the proven remote
runner substrate; also build local/docker `iris session` transports). Granular tasks: plan §5.
Open: PR #1 (m-iris-driver → main) — merge when ready.

**m-driver-conformance (D5 / M8) — STARTED 2026-06-11 (VSL effort).** The executable
contract gate (`conformance` pkg + `cmd/m-driver-conformance`) drives a driver *binary*
over the subprocess+JSON seam (`m-<engine> <axis> <verb> --output json`) and asserts:
envelope discipline (schemaVersion/command/exit-ladder/`ok⟺exit==0`/envelope.exit==process
exit/error-on-fail), caps honesty (contract major, transports incl. tested one,
`features.remote`⟺transports, meta self-lists caps+version, no present-but-empty axis),
version↔caps engine/contract cross-check, doctor (exit 0/5/6 + checks), lifecycle status
(healthy⇒running). Caps-driven (only advertised verbs), stdlib-only (SDK stays dep-free),
Runner seam (unit tests use canned envelopes). **Unit-green; live-proven — it caught two
real drifts on first run, both now FIXED:** (1) m-iris `meta version` lacked
engine/contract → driver-specific `versionCmd` (16/16 live vs m-test-iris); (2) m-ydb (&
m-iris latent) `meta doctor` (unreachable) emitted a stdout envelope `exit:0` while the
process exited 6 — a shared **clikit** limitation (`cc.Result` always wrote
`{ok:true,exit:0}`; `Fail` wrote the error envelope to *stderr*). **Fixed** with
`clikit.Context.ResultExit(data, exit, text)` (+ `Run` returns `cc.ExitCode()`), applied
byte-identically across m-ydb/m-iris; doctor now uses it. Conformance rule relaxed to
"ok=false needs error **or** data" (doctor carries `checks[]`). **Both drivers 16/16**
(m-ydb local, m-iris remote-live). **Fix 2026-06-12:** the "ok=false needs error or data"
rule treated a `null` data field as present (a nil `json.RawMessage` marshals to `null`, 4
bytes), so a bare `ok=false` envelope wrongly passed — `TestRun_OkFalseWithNothingFails` was
RED on `coordination`. Now `isBlankJSON` counts `null`/blank as empty; suite green. NEXT: apply
the same clikit copy to m-cli at D3; wire conformance into both drivers' `make`/`meta selftest`;
add live-engine verb exercise (exec/data round-trips) as v2.
**X.2 (2026-07-14) — conformance got its blocking CI home:** this repo's new
`.github/workflows/conformance.yml` runs the org `driver-conformance-hosted.yml` on every
Go-touching PR/push, ×2 lanes (clone m-ydb / m-iris @main, `go mod edit -replace` the SDK
dep to the checkout, spin the public engine image on `ubuntu-latest`, `make conformance`
BLOCKING). **Lanes were BORN-RED by design** (hardening master Dev-13): the post-L0.B1
harness's own `RunLockOptions.Dir` override is refused in a non-test binary
(`RUN_LOCK_DIR_FORBIDDEN` ×3, 20 passed — verified live, run 29323932663).
**L0.B2 (`fc7e784`, same day) turned them GREEN** (run 29327719531, both engines):
C-RL-9 (hostile-`$HOME` byte-equal ref + MISMATCH fencing) rides the new
`EnvRunner`/`ExecEnvRunner` per-call env-inject; the harness dropped its temp-dir
isolation and now brackets the REAL passwd-derived domain (`--run-lock-dir` flag
removed; `Options.LockDir` stays test-binary-only). Pre-L0 negative control
observed RED. **L0 CLOSED (2026-07-14, master v1.13.0):** v0.9.0 tagged; both drivers repinned
(their lanes now run the C-RL-9 harness — CI green ×4); L0.V's planted UserHomeDir
revert observed redding runlock_home_test.go; P.B provenance binding live (the
nightly REPORT records sdkPin + binarySha256; org probe + meta-gate §7/§7b red a
deployed-but-unproven rebuild). NEXT for this repo = L1 (guard layer, p04).
Status/registers: the hardening master (sole source of truth), rows L0.* / P.B.

**m-driver-sdk (orchestrator)** — M5 (LCOV) shared shape **DONE and shipped in `v0.3.0`**:
`CoverResult{lcov,coveredLines,totalLines,linePercent}` in `cover.go` (contract §5.5), gates green
(`go test -race`, vet, gofmt). No new Transport verb — `cover trace` composes the existing
`Exec`+`ReadGlobal` (YDB `view "TRACE"`→`zwrite ^ycov`; IRIS monitor→runner). **Reference `Client`
lifted in (2026-06-12):** `client.go` + `locate.go` (+ tests) moved from
m-cli's `internal/driver` so the engine client homes in the SDK per waterline rule 3 — m-cli and every
`v` tool now import `mdriver.Client`/`mdriver.Locate` instead of vendoring transport. Pure lift (logic
unchanged); gates green. Also fixed a pre-existing conformance `null`-data bug (see D5 below).
**Release ceremony DONE (2026-06-12):** `coordination` fast-forwarded to `main`; `v0.3.0` annotated tag
cut on `63a7ffa` and pushed. REMAINING: (a) repin BOTH drivers (`go get …@v0.3.0` → tidy → test) —
unblocks **M5 cover** on m-ydb and m-iris — and (b) migrate m-cli off `internal/driver` onto
`mdriver.Client` (repin to v0.3.0, delete the copy + tests, update `vista_cmd.go` /
`internal/engine/vista.go` / `vista_test.go`) — this is what makes the lift a true *move* (no duplicate;
waterline G3). Still pending: define the M6 (admin) shape when that milestone starts; keep this tracker +
the contract reconciled; own `m-driver-conformance` (D5).

**✅ FIXED 2026-07-06 (A1, this repo) — `Client.call` now surfaces Fail-path
envelopes as a typed `*DriverError`.** `call` returns `&DriverError{Engine,
Command, Code, Exit, Message, Hint}` when `!env.OK && env.EngineError == nil &&
env.Error != nil` — i.e. a genuine driver/transport Fail (`clikit.Fail`), NOT a
§7 engine fault (which stays data in the result's `EngineError`) and NOT a
valid-false result (`ok:false` + data, no `error` — e.g. `doctor` unhealthy /
`status` down via `ResultExit`, left as data). Three tests lock all three arms
(`TestClient_Call_FailEnvelopeSurfacesDriverError` / `_EngineFaultStaysData` /
`_ValidFalseWithDataIsNotError`). Ships in **v0.6.0**. Consumers (m-cli
`VistaEngine.Stage`, v-pkg) get honest failures once they bump the pin; the
conformance managed-staging + Fail-envelope case is still TODO (own session).
Original filing ↓

**⚠ FILED 2026-07-06 (m-iris staging-drift analysis, F5) — `Client.call` swallows
driver error envelopes.** `client.go` `call()` (`~74-100`) parses the envelope and
returns it **without ever inspecting `env.OK`/`env.Error`** — a driver-level failure
(`{ok:false, exit:5, error:{code:RUNTIME}}`, no `engineError`, no `data`) yields
zero-value results (`Load`→empty `Loaded`, `Exec`→empty `Stdout`, status 0) and a
**nil Go error**. Live-proven with a logging `M_IRIS_BIN` wrapper during a bare-lane
`m test`: BOTH `exec load` and `exec run` failed (`session: could not parse iris
session output`), yet `mtest` reported staging success and a silent **0/0** suite with
no diagnostic — the exact "0/0 has no diagnostic" pathology. This is the missing
backstop for the whole toolchain (m-cli `VistaEngine.Stage` has no guard of its own;
v-pkg hand-rolls one at `lifecycle.go:171-175`). **Fix (proposal A1):** `call`
surfaces `ok:false` as a typed Go error carrying `error.code`/`error.message`/`exit`;
add a conformance case (canned `ok:false` envelope ⇒ client returns error). Prereq for
honest failures across m-cli/v-pkg and for closing v-stdlib P-3(b). Full write-up:
m-iris `docs/design/iris-staging-drift-analysis.md` (F5, F6) +
`docs/proposals/iris-managed-staging.md` (§3 A1).

---

## 5. Hard rules (every session honors these)

1. **TDD always** — failing table-driven test (fake Transport / golden / argv) → red → implement →
   green → `go test -race`. No implementation before a failing test.
2. **Dual-engine real validation each stage** — after a milestone slice, run that driver's gated
   real-engine tier (`make test-it`) against BOTH real engines and add gated tests for new verbs.
   See [`docs/archive/continue-implementation.md`](archive/continue-implementation.md) for the
   container setup. Unit tests use fakes; reality is the gate.
3. **Shared shapes live in the SDK** — any JSON/result shape m-cli reads from BOTH drivers is
   defined once in `mdriver`, then consumed (drivers may alias). Never hand-duplicate divergently.
4. **clikit stays byte-identical** across m-ydb and m-iris (except the version.go ldflags comment).
5. **caps stays honest** — advertise only wired verbs; grow per milestone; regenerate goldens.
6. **Reconcile here** — update §1/§2/§3 of this tracker on every cross-repo change, and the
   normative `driver-contract.md` / `driver-implementation-plan.md` when a contract/plan item moves.

---

## 6. Source-of-truth references

- Normative spec (read-only): `~/vista-forge/docs/m-engine-drivers/` — `driver-contract.md`
  (v1.0), `driver-implementation-plan.md` (§4 m-ydb, §5 m-iris tracking), `engine-command-survey.md`,
  `driver-plan-risk-assessment.md`, `phase-0-reconciliation.md`.
- This SDK repo: `README.md` (SDK overview), `docs/implementation-tracker.md` (this file),
  `docs/archive/continue-implementation.md` (archived fresh-session kickoff).
- Session memory (auto-loaded): `m-engine-drivers-consistency-protocol`,
  `m-engine-drivers-real-engine-testing`, `m-driver-sdk-phase0`, `m-ydb-driver-m0`,
  `m-iris-driver-m0-spike`.
