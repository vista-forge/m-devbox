// Package mdriver is the shared engine-driver SDK for the m toolchain: the
// vendor-neutral contract types (driver-contract.md v1.0) and the verb-level
// Transport seam that every m-<engine> driver implements and that m-cli depends
// on. It is the single coupling point between m-cli, m-ydb, and m-iris — m-cli
// speaks only the contract; all proprietary detail lives behind the Transport
// in each driver.
//
// Extracted at the Phase-0 reconciliation checkpoint by freezing the two driver
// Transport sketches (m-ydb's session-pipe and m-iris's Atelier-SQL) against one
// interface. Adding verbs/fields is a back-compatible minor bump; changing or
// removing one is a major bump (driver-contract.md §8).
//
// The package holds ONLY vendor-neutral types — no YottaDB or IRIS specifics.
// clikit (the toolchain envelope/styling layer) is intentionally NOT imported:
// clikit is vendored into every toolchain repo, including non-driver ones, so a
// clikit→SDK dependency would couple the whole toolchain to the driver SDK.
// EngineError is therefore defined here for Transport results; clikit keeps its
// own copy for the JSON envelope and drivers convert at the boundary.
package mdriver

// ContractVersion is the driver-contract major.minor this SDK encodes. A driver
// advertises it in caps.contract; m-cli refuses a driver whose major it does not
// understand, with an upgrade hint (driver-contract.md §8).
// 1.1 (2026-07-16): additive — Caps gains the optional `limits` block (§4a),
// the measured per-connection engine/lane limits from the engine-capability
// fact-check (docs repo proposals/engine-capability-registry/, owner-accepted §4).
const ContractVersion = "1.1"

// Transport selectors (driver-contract.md §3). A driver advertises which it
// supports via caps.transports; YottaDB supports local+docker, IRIS adds remote.
const (
	TransportLocal  = "local"
	TransportDocker = "docker"
	TransportRemote = "remote"
)

// Caps is the capability document emitted by `meta caps` (driver-contract.md §4).
// m-cli probes it before optional verbs and adapts to exactly what is advertised;
// calling an unadvertised verb yields exit 7. Caps MUST be honest — advertise
// only axes/verbs actually wired in the build — and conformance enforces it.
// Caps DESCRIBES THE CONNECTION, not the binary (design §R-9.7, owner decision #7).
// A driver builds it from the resolved connection — `CapsDoc(conn)` — because the
// binary's union of capabilities is a lie to every caller on a specific transport:
// m-iris advertised `exec script` on all three transports while the remote transport
// refused it at runtime, so a remote caller negotiated "supported" and then failed.
//
// This matters most for Features.RunLock: owner decision #4 (an old driver is a HARD
// ERROR, never a silent unlocked run) is built on trusting that bit, and a per-binary
// bit would lie exactly the same way a per-binary `script` did.
type Caps struct {
	Engine   string `json:"engine"`
	Contract string `json:"contract"`
	// Transport is the connection this document describes — the resolved transport,
	// not a list. Additive in v0.8.0; conformance (C-CAPS-1) asserts it matches the
	// transport under test, which is what makes every other field in the document
	// honest about the connection the caller actually has.
	Transport  string   `json:"transport,omitempty"`
	Transports []string `json:"transports"`
	Axes       Axes     `json:"axes"`
	Features   Features `json:"features"`
	// Limits is the measured capability block (driver-contract.md §4a, contract
	// 1.1): what THIS engine over THIS connection actually carries, so consumers
	// ask instead of hardcoding one engine's number into both (the STDCOMPRESS
	// defect shape). nil = the driver has not taken its limits slice — consumers
	// keep their gated constants; a PRESENT block must be honest and conformance
	// (C-CAPS-2) checks its shape and will grow live spot-measurement.
	Limits *Limits `json:"limits,omitempty"`
}

// Limits carries the measured engine/lane limits for the resolved connection
// (driver-contract.md §4a). Values are FACTS with provenance, not tunables:
// each driver's numbers come from the engine-capability measured report
// (docs repo proposals/engine-capability-registry/engine-capability-registry-measured-report.md,
// 2026-07-16) or are derived live from the engine. Byte counts throughout.
//
// The three bindings from the campaign:
//   - a declared cap is a self-report — conformance re-measures (C-CAPS-2);
//   - EvalEnvelope/LoadBodyBytes are per-TRANSPORT-LANE facts (the lane, not
//     the engine, owns them — measured P3a/P3b);
//   - the failure-mode map matters as much as the numbers (explainStageFault's
//     single-engine regex was exactly the gap FaultMnemonics closes).
type Limits struct {
	// MaxString is the engine's maximum local string length.
	MaxString int `json:"maxString"`
	// MaxNodeValue is the largest value one global node carries on this
	// instance. MaxNodeValueKind says whether that is physics or site config:
	//   "engine"        — the engine's own ceiling (IRIS long strings)
	//   "region-config" — a per-region/site setting (YDB max_rec_size): a
	//                     different site may carry more or less; re-derive there.
	MaxNodeValue     int    `json:"maxNodeValue"`
	MaxNodeValueKind string `json:"maxNodeValueKind"`
	// MaxKeyBytes bounds the total key (global name + subscripts, engine
	// counting); MaxSubscripts bounds subscripts per reference.
	MaxKeyBytes   int `json:"maxKeyBytes"`
	MaxSubscripts int `json:"maxSubscripts"`
	// EvalEnvelope is the largest command literal exec eval carries intact on
	// THIS lane; LoadBodyBytes the largest routine body exec load stages intact
	// (0 = no cliff found at package scale — measured, not unknown).
	EvalEnvelope  int `json:"evalEnvelope"`
	LoadBodyBytes int `json:"loadBodyBytes"`
	// FaultMnemonics maps the contract's oversize conditions to this engine's
	// fault mnemonic, so a consumer can translate a fault without an
	// engine-shaped regex. Keys (contract §4a): "oversize-string",
	// "oversize-node", "oversize-key", "too-many-subscripts".
	FaultMnemonics map[string]string `json:"faultMnemonics,omitempty"`
}

// Axes lists the advertised verbs per contract axis (driver-contract.md §5). It
// is a struct (not a map) so the JSON field order is the contract's logical
// order; each axis is omitempty so a driver advertising only its wired axes
// leaves the rest nil → absent (the honest-incremental model both drivers use).
type Axes struct {
	Lifecycle []string `json:"lifecycle,omitempty"`
	Sync      []string `json:"sync,omitempty"`
	Exec      []string `json:"exec,omitempty"`
	Data      []string `json:"data,omitempty"`
	Cover     []string `json:"cover,omitempty"`
	Admin     []string `json:"admin,omitempty"`
	Meta      []string `json:"meta,omitempty"`
}

// AxisVerbs pairs an axis name with its advertised verbs (for iteration).
type AxisVerbs struct {
	Name  string
	Verbs []string
}

// Wired returns the non-empty axes in the contract's logical order, so callers
// (caps text rendering, conformance) can iterate advertised axes without
// re-listing field names. Empty (unwired) axes are skipped.
func (a Axes) Wired() []AxisVerbs {
	var out []AxisVerbs
	for _, av := range []AxisVerbs{
		{"lifecycle", a.Lifecycle}, {"sync", a.Sync}, {"exec", a.Exec},
		{"data", a.Data}, {"cover", a.Cover}, {"admin", a.Admin}, {"meta", a.Meta},
	} {
		if len(av.Verbs) > 0 {
			out = append(out, av)
		}
	}
	return out
}

// Features advertises optional capabilities m-cli negotiates for graceful
// degradation (driver-contract.md §4, §10). All fields are always rendered
// (no omitempty): a false flag is meaningful information, not absence.
type Features struct {
	Remote          bool `json:"remote"`
	Prune           bool `json:"prune"`
	EphemeralPrefix bool `json:"ephemeralPrefix"`
	Snapshot        bool `json:"snapshot"`
	// ManagedStaging: exec load stages into a run-scoped subdirectory of the
	// primary source dir (--stage-dir), with exec unstage (exit cleanup) and
	// exec sweep (TTL retirement of leaked mtest-* dirs) — the self-healing
	// staging namespace. File-based engines (YDB) advertise it; an engine that
	// stages into a namespace (IRIS) has nothing to sweep and leaves it false.
	ManagedStaging bool `json:"managedStaging"`
	// RunLock: the driver ENFORCES the per-engine run-lock in its dispatch — it
	// derives the lock key (meta runlock-path), measures the holder (meta
	// runlock-status), and REFUSES any mutating/read verb that cannot prove a live
	// bracket (driver-contract.md §5.8).
	//
	// This bit is the driver's own promise, and conformance holds it to it: a
	// driver that leaves it false SKIPS the run-lock cases (visibly — a skip is
	// never a pass); a driver that advertises it must pass all six. An old driver
	// omits the field entirely, which unmarshals to false — so consumers can tell
	// "does not enforce" from "enforces", and hard-error rather than run unlocked
	// while believing themselves protected (owner decision #4).
	RunLock bool `json:"runLock"`
}

// EngineError is the structured engine fault (driver-contract.md §7). On any
// compile/runtime fault, exec/cover verbs set ok=false AND populate this so a
// RED suite shows the real cause (e.g. a <NOROUTINE> at a line) instead of
// passed:0, failed:0. Mnemonic carries the engine code: %YDB-E-…/%GTM-E… for
// YottaDB (from $ZSTATUS), or the IRIS <…> code (from $ZERROR).
//
// A driver builds this from the transport result and maps it onto the clikit
// envelope's own EngineError field when rendering a failure.
type EngineError struct {
	Routine  string `json:"routine,omitempty"`
	Line     int    `json:"line,omitempty"`
	Mnemonic string `json:"mnemonic,omitempty"`
	Text     string `json:"text,omitempty"`
}
