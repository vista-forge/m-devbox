//go:build guardoff

package main

// The guard-off variant exists for exactly one consumer: the L1.B1 wrapper
// (guardoff_test.go), which builds `-tags guardoff` and asserts the refusal
// suite goes RED against it — the measured proof that the dispatch guard is
// load-bearing. X.2's E3 validation planted the same variant on a PR and
// observed the live C-RL conformance gate block the merge.
//
// It skips ONLY the middleware's run-lock enforcement; it does not fork any
// SDK logic (the master's L1 constraint). Nothing ships it: no Makefile, CI
// invocation, or dist build passes `-tags guardoff` (DS-15) — and a binary
// built with it by hand still cannot survive the nightly conformance run,
// which reds C-RL-1/3/4 against exactly this behavior.
const runLockGuardEnabled = false
