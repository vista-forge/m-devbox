//go:build !guardoff

package main

import (
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"path/filepath"
	"sort"
	"strings"
	"testing"
)

// L1.E — THE PACKAGE-API STRUCTURAL GATE (runlock-stack-hardening master,
// DS-13 / RK-13).
//
// The Kong-surface gate (TestGuardCoverage_*) proves every CLI verb passes the
// dispatch guard — but the CLI is not the only surface of this module. An
// importable package that reaches internal/ hands an external consumer the
// engine WITHOUT the guard, which is exactly how DS-13 found ydbdriver.New.
//
// Disposition (RK-13, recorded in the master): ydbdriver stays exported as the
// DECLARED, G6-KEYED entry point — an in-process consumer carries the bracket
// duty itself (L2), and L3's G6 v2 keys on this import path so an importer
// with no resolving bracket marker reds `m arch check`. The facade cannot
// self-guard without becoming a second derivation authority (R-3: the driver
// CLI is the single derivation authority) or forking the dispatch logic.
//
// What this test therefore pins, forever, is the INVENTORY: the classified
// facade is the ONLY importable surface that reaches the module internals, and
// its export list is exactly the declared constructor set. A new unguarded
// path cannot appear without editing the registry below in the same diff —
// which is the RK-13-class decision made visible.

const modulePath = "github.com/vista-forge/m-ydb"

// g6KeyedFacades — the classified unguarded entry points (RK-13 disposition).
// Adding an entry here is a G6-keying decision: L3's G6 v2 must key on the new
// import path, and the master's RK-13 row must record it.
var g6KeyedFacades = map[string]bool{
	"ydbdriver": true,
}

// facadeExports — the declared constructor surface of each facade. A new
// export is a new unguarded engine path and must be classified deliberately.
var facadeExports = map[string][]string{
	"ydbdriver": {"Config", "New"},
}

// TestAPISurface_InternalsReachableOnlyFromTheClassifiedFacade fails when any
// importable (non-internal, non-main) package imports the module's internals —
// unless it is a declared, G6-keyed facade.
func TestAPISurface_InternalsReachableOnlyFromTheClassifiedFacade(t *testing.T) {
	fset := token.NewFileSet()
	scanned := 0
	err := filepath.WalkDir(".", func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			switch d.Name() {
			case ".git", "dist", "docs", "testdata":
				return fs.SkipDir
			}
			return nil
		}
		if !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
			return nil
		}
		dir := filepath.ToSlash(filepath.Dir(path))
		if dir == "." {
			return nil // package main — behind the dispatch guard (TestGuardCoverage_*)
		}
		top := strings.Split(dir, "/")[0]
		if top == "internal" {
			return nil // not importable outside the module
		}
		if g6KeyedFacades[top] {
			return nil // the declared entry point — bracket duty is the importer's (G6 v2)
		}
		f, perr := parser.ParseFile(fset, path, nil, parser.ImportsOnly)
		if perr != nil {
			return perr
		}
		scanned++
		for _, imp := range f.Imports {
			p := strings.Trim(imp.Path.Value, `"`)
			if strings.HasPrefix(p, modulePath+"/internal/") {
				t.Errorf("%s imports %s — an importable package outside the declared facades reaches "+
					"the module internals, so the engine is reachable without the dispatch guard. "+
					"Either route it through the guarded CLI, or classify it in g6KeyedFacades as a "+
					"deliberate RK-13-class decision (and key G6 v2 on it)", path, p)
			}
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if scanned == 0 {
		t.Fatal("the scan visited no importable packages — the walk is broken, so this gate proves nothing")
	}
}

// TestAPISurface_FacadeExportsExactlyTheDeclaredConstructors pins each facade's
// export list, so a new unguarded constructor (DS-13's shape) cannot land
// silently even inside an already-classified package.
func TestAPISurface_FacadeExportsExactlyTheDeclaredConstructors(t *testing.T) {
	for facade, want := range facadeExports {
		got := exportedDecls(t, facade)
		wantSorted := append([]string(nil), want...)
		sort.Strings(wantSorted)
		if strings.Join(got, " ") != strings.Join(wantSorted, " ") {
			t.Errorf("%s exports %v, want exactly %v — a new export is a new unguarded engine "+
				"path (DS-13); declare it here and in the master's RK-13 row, or unexport it",
				facade, got, wantSorted)
		}
	}
}

// exportedDecls parses a package directory's non-test files and returns its
// sorted exported top-level identifiers.
func exportedDecls(t *testing.T, dir string) []string {
	t.Helper()
	fset := token.NewFileSet()
	pkgs, err := parser.ParseDir(fset, dir, func(fi fs.FileInfo) bool {
		return !strings.HasSuffix(fi.Name(), "_test.go")
	}, 0)
	if err != nil {
		t.Fatal(err)
	}
	var names []string
	for _, pkg := range pkgs {
		for _, f := range pkg.Files {
			for _, decl := range f.Decls {
				switch d := decl.(type) {
				case *ast.FuncDecl:
					if d.Recv == nil && d.Name.IsExported() {
						names = append(names, d.Name.Name)
					}
				case *ast.GenDecl:
					for _, spec := range d.Specs {
						switch s := spec.(type) {
						case *ast.TypeSpec:
							if s.Name.IsExported() {
								names = append(names, s.Name.Name)
							}
						case *ast.ValueSpec:
							for _, n := range s.Names {
								if n.IsExported() {
									names = append(names, n.Name)
								}
							}
						}
					}
				}
			}
		}
	}
	sort.Strings(names)
	return names
}
