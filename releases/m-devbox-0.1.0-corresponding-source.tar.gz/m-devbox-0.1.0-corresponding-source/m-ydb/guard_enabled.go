//go:build !guardoff

package main

// runLockGuardEnabled — every real build enforces §5.8. The constant exists
// only so the `guardoff` build tag can compile the load-bearing-proof variant
// (see guard_disabled.go); it is not a runtime switch, and no flag or env var
// can flip it.
const runLockGuardEnabled = true
