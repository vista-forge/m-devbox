// Command m-ydb is the YottaDB engine driver for the m toolchain: a vendor
// adapter exposing the neutral engine-driver contract (driver-contract.md v1.0)
// over YottaDB, plus the complete native YottaDB surface for power users. m-cli
// speaks only the contract; all YottaDB specifics (mupip/dse/gde/lke, the
// files-plus-rundown lifecycle, $ZSTATUS error parsing) live here, behind it.
//
// The contract surface is grouped into axes — m-cli speaks only these:
//
//	m-ydb meta caps        capability document (axes/transports/features)
//	m-ydb meta info        driver identity + resolved engine target
//	m-ydb meta version     driver/engine/contract + build info
//	m-ydb meta schema      machine-readable command tree (agent discovery)
//	m-ydb meta doctor      typed preflight diagnostics (exit 0/5/6)
//	m-ydb lifecycle status report running/healthy/version; --probe for CI gating
//	m-ydb lifecycle wait   block until healthy or --timeout (exit 6)
//	m-ydb sync list        inventory routine source ($ydb_routines)
//	m-ydb sync pull        source → mirror, incremental via the manifest
//	m-ydb sync status      source vs. local manifest drift (exit 3 on drift)
//	m-ydb sync verify      re-hash mirror files against the manifest (exit 3)
//	m-ydb sync diff        unified diff of one routine (instance vs. mirror)
//	m-ydb sync push        write routines back to the instance (conflict-checked; exit 4)
//	m-ydb sync deploy      install a routine-source library; --prune true-syncs
//	m-ydb sync rm          remove a routine from the instance
//	m-ydb exec load        stage .m into the routine path + compile (ZLINK)
//	m-ydb exec run         run an entryref (args→$ZCMDLINE); faults → engineError
//	m-ydb exec eval        evaluate one M command; faults → engineError
//	m-ydb exec abort       stop jobs tagged with an ephemeral --prefix
//
// Later milestones add the data, cover, admin, and native axes; caps grows to
// advertise each as it lands (caps is honest — advertised == implemented).
//
// Connection config comes from flags or M_YDB_* env (flags win), with unset
// paths falling back to the standard ydb_*/gtm_* env; see internal/config.
// Transports: local | docker (YottaDB has no network API, so no remote).
package main

import (
	"os"

	"github.com/alecthomas/kong"
	"github.com/willabides/kongplete"

	"github.com/vista-forge/m-ydb/clikit"
	"github.com/vista-forge/m-ydb/internal/config"
)

// CLI is the root command grammar — one typed struct Kong parses and `schema`
// reflects. clikit.Globals and config.Conn are embedded so both contribute
// global flags; config.Conn is bound so commands receive a *config.Conn. The
// contract verbs are grouped into axis subcommands (meta, lifecycle, …).
type CLI struct {
	clikit.Globals
	config.Conn

	Meta      metaCmd      `cmd:"" help:"Introspection + power tools: caps / info / version / schema / doctor."`
	Lifecycle lifecycleCmd `cmd:"" help:"Manage the engine instance: status / wait (up/down/restart/provision/destroy land in M1b)."`
	Sync      syncCmd      `cmd:"" help:"Source axis: routine source ↔ instance (list / pull / status / verify / diff / push / deploy / rm)."`
	Exec      execCmd      `cmd:"" help:"Execution axis: load (stage+compile) / run / eval / abort; faults surface as engineError."`

	InstallCompletions kongplete.InstallCompletions `cmd:"" help:"Install shell tab-completions."`
}

// ProvideConn hands each command its connection — and it is the driver's DISPATCH
// MIDDLEWARE (driver-contract §5.8 §6c): the run-lock guard runs here, once, for
// every verb that can reach the engine.
//
// Why here, and not a Kong hook or conn.NewSession():
//
//   - conn.NewSession() is called from TEN sites (doctor/lifecycle/exec). A guard
//     copy-pasted ten times is the hand-rolled-bracket antipattern the v-pkg audit
//     found; the eleventh verb would be written without it.
//   - A Kong parse-time hook (BeforeApply/AfterApply) fires INSIDE parser.Parse,
//     and clikit.Run flattens every parse error into `USAGE` / exit 2 — measured, not
//     assumed: Conn.Validate()'s "docker transport needs a container" surfaces as
//     code USAGE with no `command` field. A refusal must carry RUN_LOCK_REQUIRED on
//     exit 4, so a parse-time hook cannot express one without a clikit change, and
//     clikit is the contract-bearing fork kept byte-identical with m-iris.
//   - A Kong PROVIDER runs inside kctx.Run, so its error travels the normal ladder
//     (clikit.RenderError + exitOf → the structured code, exit 4) with `command` set.
//     A verb cannot touch the engine without a *config.Conn, so this IS the funnel —
//     and TestGuardCoverage_EveryBracketVerbTakesTheConn red-gates the one way out
//     (a bracket-requiring verb whose Run does not take the Conn).
//
// A new verb therefore inherits the check with zero extra code — the actual §6c
// requirement. The mechanism differs from m-iris's; the BEHAVIOR is pinned by
// conformance, and a mechanism difference is tolerable where an enforcement
// difference is not.
func (c *CLI) ProvideConn(kctx *kong.Context) (*config.Conn, error) {
	if err := guardRunLock(kctx, &c.Conn); err != nil {
		return nil, err
	}
	return &c.Conn, nil
}

func main() {
	cli := &CLI{}
	os.Exit(clikit.Run(
		"m-ydb",
		"YottaDB engine driver for the m toolchain — neutral contract verbs (meta, lifecycle, …) over YottaDB, plus the native YottaDB surface.",
		cli, &cli.Globals,
		// NOTE: no kong.Bind(&cli.Conn) — the Conn is PROVIDED (above), so every
		// command that takes one passes the run-lock guard. A plain binding would hand
		// the connection over unguarded.
	))
}
