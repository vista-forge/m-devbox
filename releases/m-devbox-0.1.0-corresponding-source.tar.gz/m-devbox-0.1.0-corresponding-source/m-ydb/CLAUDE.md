# m-ydb — YottaDB engine driver (D2). Repo rules.

Adds to the org rules (`~/vista-forge/CLAUDE.md`) and the user global
(`~/.claude/CLAUDE.md`). Where this file says **EXCEPTION**, it *overrides* those
for this repo (the user authorized driver-effort carve-outs, 2026-06-06).

This is a **driver spike** session — one of the three coordinated repos
(`m-driver-sdk` ⟷ `m-iris` ⟷ `m-ydb`). Read [[coordination-model]]
(`docs/m-engine-drivers/coordination-model.md` in the `docs` repo) once per fresh
session that touches the driver effort.

## Lane — what this session owns
- **Owns / may push: `m-ydb` only**, trunk-based on **`main`** (the org
  Increment Protocol). The old `m-ydb-driver` branch lane is **retired** —
  the go-work ADR (`docs/background/go-work-dev-loop-adr.md` in the `docs`
  repo) made the parallel-lane ceremony dormant while solo. Re-arm a branch
  lane only if parallel driver sessions run again.
- **Never edit `m-driver-sdk`** here, and never push `m-driver-sdk` / `m-iris` /
  `docs`. Those belong to their own sessions (one session ↔ one repo; m-cli
  likewise).

## The SDK seam — shared shapes change in the SDK, not here
- **Pin ceremony DORMANT while solo** (same go-work ADR): the root `go.work`
  resolves `m-driver-sdk` to the local working tree for the dev loop, and
  **tags/pins are release-only**. CI builds with `GOWORK=off` against the real
  `go.mod` pin, so keep `go.mod` on a real tagged version — still **no
  `replace` directives**, no pseudo-versions.
- A new shared shape (a type m-cli reads, or that m-iris must match) is **SDK
  work**: land it in `m-driver-sdk` from its own session, tag on release, then
  update the pin here. Don't fork the shape locally.
- `caps` stays **honest** (advertise only wired verbs). The neutral contract +
  envelope shapes are the m-cli surface; they change only via the SDK/contract,
  which you don't edit here — so you cannot drift the surface.

## Increment Protocol — EXCEPTIONS for this repo
Run the org Increment Protocol (persist memory → update tracker → commit+push) at
every verified increment, automatically, **but**:
- **EXCEPTION (memory):** m-ydb memory lives in **`./docs/memory/`** (this repo),
  committed here with the code. Do **NOT** write `~/claude/memory` and do **NOT**
  write the `docs` repo's `docs/memory/` (shared coordination memory, coordinator-
  owned). The harness recall path for an m-ydb session is symlinked to `./docs/memory/`.
- **EXCEPTION (tracker):** update **`./docs/m-ydb-tracker.md`** (this repo), not the
  shared `docs/archive/m-engine-drivers/driver-implementation-plan.md` §4 — the coordinator
  rolls the shared plan up at milestone boundaries. This keeps parallel iris/ydb
  spikes from clashing on the `docs` repo.
- **Commit+push:** `m-ydb`, trunk-based on `main`. Gates first:
  `go test -race ./...`, `go vet`, `gofmt`, and `make test-it` against the live
  YottaDB (`m-test-engine`, r2.07) for any engine-touching change.

## Real-engine validation
Validate every milestone slice against real YottaDB (`make test-it`, `m-test-engine`,
r2.07) — the fake transport tier alone misses engine-shape bugs.
