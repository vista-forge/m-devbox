---
name: m-ydb-sdk-docker-locator-defect
description: SDK v0.8.0 gotcha — NewDockerLocator maps ANY non-zero docker exit to a clean no-match, so a dead daemon silently yields a selector-spelled run-lock key (defeat (n)).
metadata:
  type: project
---

**`mdriver.NewDockerLocator()` (m-driver-sdk v0.8.0) cannot tell a missing container
from a dead daemon, and the failure mode is a SILENT split lock.** Found and measured
during m-ydb's P0.2b slice, 2026-07-13.

Its runner maps **every** `*exec.ExitError` to the unexported no-match sentinel:

```go
if errors.As(err, &ee) { return nil, fmt.Errorf("%w: %s", errNoSuchContainer, …) }
```

But `docker inspect` exits non-zero for **both** "no such container" (a clean
no-match, which must key self-canonically so `lifecycle provision` can run) **and**
"Cannot connect to the Docker daemon" (which must **refuse**). Measured against a stub
docker with the daemon down:

    Canonicalize(<a container ID>) → locus{docker, <the raw ID>}, err = nil

So with a hiccuping daemon, `--container vehu` keys `ydb.docker.vehu` while
`--container <its id>` keys `ydb.docker.<id>` — **two lock files for one engine, no
error**. That is defeat (i) reintroduced exactly when the box is degraded, which is
defeat (n) — the case `RUN_LOCK_UNRESOLVED` exists to close.

**m-ydb's fix (in-repo, no SDK edit): `runlock.LocalDocker()`** wraps the SDK's runner
rather than reimplementing the docker legwork. On any docker error it asks
`docker version` whether the daemon is alive; if not, it returns a plain error
(`%v`, **never `%w`** — the wrap must *break* the SDK's sentinel chain, or a dead
daemon still reads as "no such container"). It also returns **nil** when there is no
docker CLI at all, which is a real answer — a box with no docker runs no containers, so
a network route still classifies cleanly instead of refusing.

**m-iris will inherit the hole unless it wraps too.** The real fix belongs in the SDK
(export the no-match sentinel, or distinguish daemon-down inside `NewDockerLocator`) —
filed as `needs SDK` in `docs/m-ydb-tracker.md`.

> ✅ **RESOLVED UPSTREAM — SDK v0.8.1 (S2, `84d47d7`); m-ydb repinned and the
> wrapper is RETIRED (T2, 2026-07-13).** The SDK's `Canonicalize` now classifies on
> the error path with its own daemon-liveness probe (dead daemon → REFUSE) and
> exports `ErrNoSuchContainer` / `ErrNoDocker` / `DockerError` so a custom runner can
> express each class. Production wires `mdriver.NewDockerLocator()` directly; the
> PATH-stub tests (dead-daemon refusal, absent-CLI = docker route refuses / remote
> classifies foreign) stay in `internal/runlock/locus_test.go` — they now hold the
> **SDK** to the behavior the wrapper used to provide. Keep this file: the lesson —
> *an exit code cannot carry the missing-vs-dead distinction; a test whose fake
> returns a hand-made error tests the fake* — outlives the defect.

Related: [[run-lock-enforcement]].
