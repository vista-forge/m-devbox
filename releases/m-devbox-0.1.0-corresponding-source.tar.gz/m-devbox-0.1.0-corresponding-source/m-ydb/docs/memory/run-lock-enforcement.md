---
name: run-lock-enforcement
description: m-ydb enforces the per-engine run-lock in dispatch (P0.2b) — the guard lives in a Kong PROVIDER, not a hook; enforcement breaks unbracketed consumers by design.
metadata:
  type: project
---

m-ydb's slice of the per-engine run-lock (P0.2b) landed 2026-07-13: the driver
derives the lock key (`meta runlock-path`), measures the holder
(`meta runlock-status`), and **refuses** any mutating/read verb that cannot prove a
live bracket. `features.runLock = true`. Design: `m-driver-sdk/docs/design/run-lock.md`
(R-9.3 ladder is normative); contract §5.8.

## The durable lessons (not the event)

**1. The guard MUST be a Kong provider, not a Kong hook.** Both `BeforeApply` and
`AfterApply` fire *inside* `parser.Parse`, and `clikit.Run` flattens **every** parse
error into `code: USAGE, exit: 2` with **no `command` field**. Measured, not assumed:
`Conn.Validate()`'s "docker transport needs a container" already surfaces that way.
A run-lock refusal must carry `RUN_LOCK_REQUIRED` on **exit 4**, so a parse-time hook
**cannot express one** without changing clikit — and clikit is the contract-bearing
fork kept byte-identical with m-iris. A Kong **provider** (`CLI.ProvideConn`) runs
inside `kctx.Run`, so its error travels the normal ladder (structured code, exit 4,
`command` set). Kong returns a provider's error **unwrapped**, so `errors.As` finds
the `*clikit.Error`.

Also ruled out: an axis-level `Run()` method. Kong's `RunNode` calls Run methods
**leaf-first, parents after** — an axis guard would run *after* the verb it was meant
to guard.

**2. The provider's one hole is gated, not documented.** The guard fires when a
command asks for `*config.Conn`; a bracket-requiring verb whose `Run` didn't take one
would slip past. `TestGuardCoverage_EveryBracketVerbTakesTheConn` walks the Kong model
and reds on exactly that. A convention would not have held.

**3. Enforcement breaks unbracketed consumers — by design, and it already has.**
`~/.local/bin/m-ydb` is a **symlink into `m-ydb/dist/m-ydb`**, so rebuilding the driver
puts enforcement live on this box immediately. Measured right after the build:

    m test --engine ydb --docker m-test-engine
    → STAGE_FAILED: exec sweep failed [RUN_LOCK_REQUIRED]

That is the feature arriving before its consumer. **The M test path stays down until
m-cli's P0.4 lands** (`m runlock hold` + the consumer auto-bracket) — there is no
user-facing way to open a bracket before then. To temporarily restore the old driver:
build a pre-P0.2b commit into `dist/` (the symlink follows).

**4. Caps are per-connection now (decision #7).** `driver.CapsFor(transport)` +
`driver.Supports(transport, axis, verb)` read **one table**, so `meta caps` and the
dispatch check cannot drift; an unadvertised verb is refused with **exit 7** instead of
being attempted and failing at runtime. On `remote` (SSH, attach-only, no source
store) m-ydb drops `sync` entirely, plus `lifecycle provision|destroy` and `exec load`.
Goldens are per-transport (`testdata/caps-<transport>.json`).

**5. The remote route costs 2 engine round trips per bracket-requiring verb** (ask the
engine `$ZGBLDIR`, then ask its host `uname -n` + `readlink -f`). Docker and local
routes are self-canonical and pay **zero**. The engine-ask is a plain call on
`transport.Session` — never a re-entry into the CLI — which is what makes amendment B's
recursion structurally impossible; red-proven by
`TestGuard_NetworkRouteDoesNotReenterTheMiddleware`.

**6. The guard is proven LOAD-BEARING by a wrapper, never a bare build tag (L1.B1,
2026-07-14).** `guardoff_test.go` is a plain-suite test that itself builds
`-tags guardoff` (compiling `runLockGuardEnabled=false`, guard_disabled.go) and
asserts the refusal cases go RED against the variant. The pattern's two gotchas:
a bare build-tagged suite is dead code (nothing here passes `-tags` — master
DS-15), and the wrapper must assert on `--- FAIL: <case>` lines, **not** on
refusal-message text — under guard-off the cases fail as
`code = "RUNTIME", want "RUN_LOCK_*"` (the body proceeds and dies without an
engine), so a message-substring assertion would false-miss. The wrapper file
carries `//go:build !guardoff` so the inner run cannot recurse into it.

**7. The package-API surface is gated, not just the Kong surface (L1.E,
2026-07-14).** `apisurface_test.go` pins (a) internals importable ONLY from the
declared facade registry (`g6KeyedFacades`) and (b) the facade's exact export
list. **RK-13 disposition: `ydbdriver.New` is a G6-keyed entry point** — kept
exported and unguarded because the facade cannot verify a bracket without
becoming a second derivation authority (R-3); the importer carries bracket duty
and L3's G6 v2 keys on the import path. Adding any unguarded surface now
requires editing that registry in the same diff. (Same increment: the coverage
gate previously SKIPPED advertised-but-unclassified verbs where m-iris reds
them — fixed; parity plants observed RED on both branches.)

See [[m-ydb-sdk-docker-locator-defect]] for the SDK bug this slice found and worked
around, and the tracker's `needs SDK` block for what the coordinator owes.
