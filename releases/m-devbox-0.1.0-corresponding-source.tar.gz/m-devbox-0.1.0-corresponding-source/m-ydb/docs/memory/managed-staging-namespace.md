---
name: managed-staging-namespace
description: The mtest-* managed staging namespace (H1a) — why staging goes into a SUBDIR of the primary source dir, why that subdir must be explicitly prepended to the routine path, and why docker chset must ride as `docker exec -e` (not an argv env prefix).
metadata:
  type: project
---

# Managed staging namespace (mtest-*) + chset env derivation (2026-07-05)

Two transport invariants behind the H1a fix (docs repo
`proposals/completed/engine-state-hygiene-hardening/engine-state-hygiene-hardening.md`);
the design itself is in code (`--stage-dir` on Conn, `exec unstage`/`exec
sweep`, `source.SweepStageDirs*`) — these are the *why* facts that keep it
correct:

- **`dir*` in $ZROUTINES is flat-dir + AUTO-RELINK, not subdir search.** A
  `.m`/`.o` in a subdir of the patch dir resolves under NO env — which makes a
  `<primary>/mtest-<token>/` staging subdir shadow-proof BY CONSTRUCTION, and
  conversely means the run's own subdir MUST be explicitly prepended to the
  routine path or staged routines resolve nowhere. One mechanism does both:
  `Conn.EnsureStageRoutines` prepends the stage path to `c.Routines`, and both
  consumers follow — the source store's write target (dirs[0]) and the
  session's runtime `$ZROUTINES` layering. (Proven live on vehu: staged
  ZZTSTAGEPROOF resolved only under the stage-dir conn, FILENOTFND without.)
- **EVERY engine-executing verb must make BOTH halves of that mechanism run —
  the `exec script` gap (found 2026-07-06, the `m coverage` 0.0% regression).**
  At MSN, `exec script` neither called `EnsureStageRoutines` nor had a
  `$ZROUTINES` injection on its UNTRAPPED path (`Session.Exec` builds raw
  `mumps -direct` stdin; docker/remote `env()` carries nothing), so a
  direct-mode script silently saw only the login profile's routine path:
  `m coverage`'s TRACE pass ran `do ^SUITE` against nothing, YDB direct mode
  printed no error, and every staged line reported 0 hits — a plausible-looking
  1.3%/0.0% "coverage". Fix: `execScriptCmd` stage-preps the conn like
  load/run/eval, and `buildExec`'s Script case prepends
  `set $zroutines=<routines_ >_$zroutines` as the FIRST stdin line (the
  untrapped mirror of `buildTrapped`'s layering). Checklist for any NEW
  engine-executing verb: (1) `EnsureStageRoutines` before `NewSession()`;
  (2) confirm the request shape actually carries `cfg.Routines` to the engine
  (trapped = buildTrapped's SET; untrapped script = the stdin prepend; local =
  env()). A silent no-op resolution is invisible in green output — probe
  `write $zroutines` under the conn when in doubt.
- **Sweep scope is directories-only, mtest-\* only, TTL-gated, own-dir
  excluded.** Flat `.m`/`.o` files in the primary dir are NEVER swept — flat p
  is the engine's real patch dir and a pattern sweep could eat a genuine local
  patch (vehu carries XWB*/ZVPKG*/zz* there). `ValidStageName` confines every
  `rm -rf` to the namespace; `exec unstage` refuses names outside it, so the
  primary dir itself can never be a removal target.
- **Docker chset must be `docker exec -e ydb_chset=<v>`, NOT an argv
  `env ydb_chset=<v>` prefix inside `bash -lc`.** The container login profile
  (ydb_env_set) derives the chset-DEPENDENT env from $ydb_chset — under UTF-8
  that is `o/utf8*` object dirs + `utf8/libyottadbutil.so` (%XCMD lives
  there). An argv-level override flips the chset AFTER those UTF-8 paths are
  derived, and the M-mode process dies at startup on the UTF-8 objects: the
  P-3(a) bare-YDB `--chset m` 0/0 abort (exit 253, no diagnostic). `-e` puts
  the var in the environment BEFORE the profile runs, so ydb_env_set derives
  M-mode paths. GT.M-profile images (vehu) ignore ydb_chset either way, so
  `-e` is safe across images; local/remote keep the argv prefix (no
  login-shell derivation there).
