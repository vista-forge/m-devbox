---
name: percent-routine-file-grammar
description: YDB %-routines live on disk as `_X.m` (%DT ↔ _DT.m) — the source layer must accept what List enumerates; fixed 2026-07-22 (PR-21) after it broke `m lib verify` on every FileMan-bearing engine. IRIS has NO file form — the m lib IRIS lane must map %-names differently.
metadata:
  type: project
---

**YottaDB resolves a `%`-routine from an underscore-prefixed file**: `%DT` ↔
`_DT.m` (and its object is `_DT.o`). There is no `%DT.m` on disk — a file
literally named `%X.m` is inert to the engine.

**The defect this cost (2026-07-22, m-devbox P2 bake / PR-21):**
`internal/source` `nameRe` accepted `%X.m` and rejected `_X.m` — exactly
backwards relative to the on-disk grammar — while `List` (extension-only
check) happily enumerated `_X.m` files. An enumerate-then-refuse store broke
every consumer that walks a FileMan-bearing engine: `sync pull` (and through
it m-cli's `m lib verify` → `PullTo`) died on `read _DT.m: invalid routine
name`, and `exec load` could not stage `%`-routine source (vista-fileman's
CLAUDE.md rule 4 documents the workaround it forced: in-engine `19,"ZS"`
`$TEXT`-copies via FMPOCREN — still works, now unnecessary).

**The rule:** the store deals in *filenames*, so its grammar is the *on-disk*
grammar — first char `%`, `_` or letter. Whatever `List` can return,
`Read`/`Write`/`Remove` must accept ([[schema-unrepresentable-truth-vanishes]]
adjacent: an asymmetric surface makes real files unrepresentable). Pinned by
`TestRoutineNameGrammar` + `TestFileStore_PercentRoutineRoundTrip`.

**Bare-name propagation is already consistent:** `Compile` takes `_DT` (YDB
`zlink "_DT"` is the correct spelling), `sync rm` removes `_DT.o` via
`RemoveObjectLocal(dir,"_DT")`. Display surfaces show the underscore form —
cosmetic, deliberate.

**IRIS-parity caveat (for m-lib P3):** IRIS routines have no file form at all
— `%`-routines live in the namespace DB with real `%` names and cross-namespace
mapping semantics. The `%X ↔ _X.m` mapping is a **YDB-lane fact**; an IRIS
store must handle `%`-names natively, not by filename encoding.
