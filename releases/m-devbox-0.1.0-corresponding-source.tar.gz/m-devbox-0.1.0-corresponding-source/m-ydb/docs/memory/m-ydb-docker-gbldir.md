---
name: m-ydb-docker-gbldir
description: Fixed (2026-06-12) — the docker transport established no $ydb_gbldir, so all global-accessing M faulted %YDB-E-ZGBLDIRUNDEF; buildTrapped now SET $ZGBLDIR at runtime. Live-proven on vehu (v pkg --engine ydb full lifecycle). Corrects the M0a "YDB driver-path" record (was raw-M).
metadata:
  type: project
---

# m-ydb docker transport: missing global directory (FIXED 2026-06-12)

## The bug
The **docker** transport ran user M with **no global directory established**, so
any global access faulted **`%YDB-E-ZGBLDIRUNDEF`** — while routine load/run
worked fine. Root cause, two cooperating facts in `internal/transport`:
- `exec.go execEnv()` returns **`nil` for docker** ("the container's own env
  applies") — no `ydb_gbldir`.
- `buildTrapped()` layered only `$ZROUTINES` at runtime, never the gbldir.
- A FOIA container (`worldvista/vehu`) sets its VistA env **solely via
  `/home/vehu/etc/env`**, which `docker exec` does **not** source, so the
  container's default exec env has no `ydb_gbldir`/`gtmgbldir`.

Net: the entire KIDS lifecycle (which touches `^XTMP`/`^XPD`/FileMan globals)
failed. `v pkg install/verify/uninstall --engine ydb --transport docker` against
vehu all died at `run EN^ZVPKGINS`; ZZSKEL failed identically (so **not** a v-pkg
bug). **This means the earlier-recorded "M0a YDB driver-path proven on vehu"
(v-pkg/m-stdlib trackers) was actually the raw-M-over-`docker exec` path
(sourcing the env file), NOT `v pkg … --engine ydb`.** Surfaced by m-stdlib VSL
T0b.2 (the MSL KIDS base needs the real driver path).

## The fix
`buildTrapped` now emits **`SET $ZGBLDIR=<cfg.GblDir>`** (when `GblDir` is
configured), right before the existing `SET $ZROUTINES=…_$ZROUTINES`. This
**mirrors the routine-path layering**: establish the resource at runtime inside
the `%XCMD` command rather than via process env — so it works over `docker exec`
with no `-e` plumbing, and is a harmless re-assert on local (env already sets
`ydb_gbldir`) / remote (EnvFile sources it). Only ~8 lines in `exec.go`.

Why runtime-SET (not `docker exec -e`): same philosophy as `execEnv()`
deliberately omitting `ydb_routines` — keep the engine's default search path
intact so `%XCMD` (a system percent-routine) still links; layer the configured
paths on at runtime. `$ZGBLDIR` is the read-write ISV for the global directory.

## Validation
- Unit: `TestExecTrapped_DockerSetsZGblDir` (TDD red→green); `go test -race
  ./...`, `go vet`, `gofmt`, `make test-it` (m-test-engine r2.07) all green.
  (The integration tests don't set `GblDir`, so the bare-engine path is
  unchanged — no SET added there.)
- **Live on vehu (docker):** `m-ydb exec eval 'W $D(^XPD(9.7,0))' --transport
  docker` → global data (was ZGBLDIRUNDEF); `v pkg install/verify/uninstall
  /tmp/ZZSKEL.kids --engine ydb --transport docker` → install #9.7 **status 3**,
  verify installed:true, uninstall reversible (post-verify installed:false).
  Env: `M_YDB_CONTAINER=vehu M_YDB_DIST=/home/vehu/lib/gtm
  M_YDB_GBLDIR=/home/vehu/g/vehu.gld M_YDB_ROUTINES=<sourced gtmroutines>`.

## Consequence
The YDB driver path (`v pkg … --engine ydb --transport docker`) is now genuinely
real, not just raw-M. **Unblocks m-stdlib VSL T0b.2** (branch
`t0b2-msl-kids-base`): rebuild done; resume `scripts/kids-test-in-place.sh ydb`
there. See [[m-ydb-driver-m0]] (the M3 exec axis this corrects).

## Follow-on: docker now login-shell sourced — zero gbldir/routines config (2026-06-17)
The 2026-06-12 fix worked only when the caller **passed** the paths explicitly
(the live proof used `M_YDB_GBLDIR=/home/vehu/g/vehu.gld
M_YDB_ROUTINES=<sourced gtmroutines>`). `m vista exec --engine ydb --transport
docker` (m-cli) passes **neither** — `config.Resolve` fills `GblDir`/`Routines`
from the *host* `gtmgbldir`/`gtmroutines`, which are empty when targeting a
container — so `SET $ZGBLDIR` was skipped and exec faulted `ZGBLDIRUNDEF` again
(returned `ok:true, stdout:""` up the stack, looking like a silent no-op).

**Fix:** `Session.wrap()` now wraps the docker argv in **`docker exec -i <c> bash
-lc <shJoin(argv)>`** — a *login shell* that sources the container's own
`gtmgbldir`/`gtmroutines`/`gtm_dist`, so the engine env is established with **no
explicit flags**. This mirrors m-cli's `DockerRunner` (which already drives these
same containers via `bash -lc` — see m-cli's docker-routines fallback), unifying
the two docker paths. The runtime `SET $ZGBLDIR`/`$ZROUTINES` injection stays as
an *override* layer for an explicit `--gbldir`/`--routines` (or a staged routine
dir) on top of what the login shell resolves. Requires `bash` in the container
(present in vehu + m-test-engine).

**Validation (2026-06-17):** unit `TestDocker_WrapsArgv`/`TestDocker_Util_Argv`
updated to the `bash -lc` form (TDD); `go test -race ./...` + `golangci-lint`
green; `make test-it` (m-test-engine) green. **Live on vehu (zero path flags):**
`m-ydb exec eval 'W $ZV' --transport docker` → `GT.M V7.0-005 …`;
`'W $P($G(^DIC(200,0)),"^",1)'` → `NEW PERSON`; `lifecycle status` →
running/healthy/r2.02. Unblocks `m vista exec`/`status` in m-cli (and the vdocs
SKL S2.2 live-DD seam). See [[engine-access-through-driver-stack]].

## Follow-on: source-store (load/sync) path now container-aware too (2026-06-30)
The 2026-06-17 login-shell fix made the **exec** path resolve the container's env
with zero flags — but the **source axis** (`exec load`, all of `sync`) takes a
SEPARATE path: `config.SourceStore` reads the routine *write* dirs from
`ParseRoutinesDirs($ydb_routines)` resolved off the **host** env, never the
container. Against a real VistA image (`vehu`) the host has no `ydb_routines`, so
`SourceStore` returned **`no routine source directory: set --routines or
$ydb_routines`** and `exec load` staged nothing — which is exactly how
**`v pkg install` surfaced as `stage ZVPKGRD: driver loaded no routine`** (its
`runMScript` refuses up front when `cl.Load` reports zero loaded — lifecycle.go
explicitly anticipates "no routine source directory configured → loads nothing").
This was the **OPEN ZVPKGRD install snag** the v-rpc-tap reaper-live-proof memory
flagged as a P4 blocker — NOT a v-pkg bug, NOT a regression of T0a.3 (that proof
passed `M_YDB_ROUTINES=<sourced gtmroutines>` explicitly; nothing sets it now).

**Fix:** new `Session.ContainerRoutines(ctx)` reads the engine's own
`$ZROUTINES` (docker-only; with no `--routines` set, `Exec` layers no override so
it returns the login-shell value, whose `object*(src …)` form `ParseRoutinesDirs`
already parses). `config.SourceStore` calls it as a **fallback only when host
`Routines` is empty + docker + a container is set** — so explicit `--routines`
and the bare m-test-engine path are untouched (no regression; auto-discovery is
strictly additive, filling a case that previously errored). vehu's
`$ZROUTINES` → source dirs `/home/vehu/p` (primary write target) `/home/vehu/s`
`/home/vehu/r`.

**Validation (2026-06-30):** unit `TestContainerRoutines_DockerReadsZRoutines` /
`_NonDockerIsNoop` (TDD red→green, fake runner); `gofmt`/`go vet`/`golangci-lint`/
`go test ./...` green; `make test-it` (m-test-engine) green. **Live, zero path
flags:** `m-ydb exec load ZVPROBE.m --transport docker` → `loaded:[ZVPROBE.m]
compiled:true` on **both** vehu and m-test-engine (was BAD_CONFIG). **Full
`v pkg` lifecycle proven byte-clean on vehu (2026-06-30):** `install
vslrtap.kids --engine ydb --transport docker --auto-snapshot` → **status 3,
installed:true** (3 greenfield routines); `verify` → installed:true, all 3
present; `uninstall` → byte-clean (source + `.o` objects + #9.7 `B` entry +
`^XTMP("VPKGI")` staging global all gone). So the **OPEN ZVPKGRD P4 install
blocker is fully CLOSED** — install path is healthy end-to-end.

## Follow-on: docker now IGNORES host M_YDB_* entirely (FIXED 2026-07-11, `ae4d3a5`)
The 2026-06-30 fix made `ContainerRoutines` a fallback **only when host `Routines`
is empty** — it explicitly assumed nothing sets `M_YDB_ROUTINES` when targeting a
container. The **unified-path-strategy** later broke that assumption: the org env
anchor `workspace/env.sh` now exports `M_YDB_ROUTINES=/home/vehu/p/* /home/vehu/r`,
`M_YDB_GBLDIR=/home/vehu/g/vehu.gld`, `M_YDB_DIST=/home/vehu/lib/gtm` as GLOBAL YDB
defaults (correct for `--docker vehu`). Kong bound them onto `Conn.Routines/GblDir/
Dist` for EVERY transport, so `--docker m-test-engine` overrode the container but
kept **vehu's** paths: `exec load` staged into `/home/vehu/p/mtest-*` (host
`Routines`[0], no longer empty → ContainerRoutines fallback skipped) while the
run's `$zroutines` layered vehu's paths onto m-test-engine's own `/data/r2.07_x86_64/r`
— so `do start^STDASSERT` resolved nothing (`$text(+0^STDASSERT)`="") and the
orchestrated script emitted zero `##TEST` markers → **every suite 0/0**, IRIS+vehu
green. This is a **LOCAL/dev-loop** break (env.sh is machine-local). NOTE: the
separate m-stdlib `ci / m-ci` "Engine-bound gates" standing red is a DIFFERENT
cause — `m-ci.yml` never builds the m-ydb/m-iris driver, so `m test --docker` dies
`STAGE_FAILED: launch …/m-ydb: no such file` (exit 2); CI has no `M_YDB_*` leak
(doesn't source env.sh). Do not conflate — this fix does not touch that CI gap.

**Fix:** removed the `env:"M_YDB_*"` tags from the `Dist`/`GblDir`/`Routines` struct
fields and read those env defaults in `Resolve` instead, **transport-gated**: for
docker, `Resolve` reads NONE of `M_YDB_*`/`ydb_*`/`gtm_*` (the container's `bash -lc`
login profile is authoritative — the same philosophy as `execEnv()` returning nil
for docker); an explicit `--ydb-dist`/`--gbldir`/`--routines` flag still wins on
every transport; non-docker keeps `M_YDB_* > ydb_* > gtm_*` precedence. This is
strictly stronger than the 2026-06-30 "empty check" — docker no longer *depends* on
the host leaving `M_YDB_ROUTINES` unset. **Why not fix workspace/env.sh:** those
vars are the single source consumed by 5+ vehu gate/vet scripts; the driver, not
the anchor, is the right place to scope them.

**Validation (with the vehu `M_YDB_*` env STILL set):** m-test-engine STDHEXTST
`0/0 → 49/49`; vehu 49/49 + IRIS 49/49 (no regression); m-stdlib `make test`
2533/0 across 33 suites; the safety-net **P3.1 capability doctor now 5/5 on real
YDB** m-test-engine. Unit tests `TestResolve_DockerIgnoresHostEnv` /
`_DockerHonorsExplicitFlag` / `_MYDBEnvWinsOverYDB` lock the contract;
`TestEnsureStageRoutines_NeedsAResolvableSourceDir` hardened to clear the routine
env (it hits the REAL `os.Getenv` via `PrimarySourceDir`→`ResolveEnv`, so the dev
shell's `M_YDB_ROUTINES` had leaked in). `make lint`+`make test` green.

GOTCHAS: (1) a transient `stage-incomplete: staged 794 of 345 nodes` on the FIRST
attempt was **stale `^XTMP("VPKGI")` residue** from a prior failed install, NOT a
bug — `dist/kids/vslrtap.kids` parses to exactly 345 pairs (`b.Pairs()` =
`EnginePairs` = 345 distinct subs, 0 dups); from a clean `VPKGI=0` it staged
345/345 and installed. The finalize's count check correctly refused the polluted
stage. (2) `v pkg uninstall` (`^%ZOSF("DEL")`, Kernel-native) removes BOTH `.m`
and `.o`; `m-ydb sync rm` removes only the `.m` **source** — a scratch routine
still links from its leftover object after `sync rm`. To delete a stray routine
on a **VistA** engine, use `^%ZOSF("DEL")` via `m vista exec` (engine-native, not
a shell `rm` — `rm` is deny-gated even through an M PIPE device). A **bare** YDB
engine (m-test-engine) has no `^%ZOSF`, so a `sync rm`'d routine's `.o` can't be
cleaned that way — recreate the disposable engine instead. See [[m-ydb-driver-m0]],
[[engine-access-through-driver-stack]].
