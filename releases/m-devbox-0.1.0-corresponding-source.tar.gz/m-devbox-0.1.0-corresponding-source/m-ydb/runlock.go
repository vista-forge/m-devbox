package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/alecthomas/kong"

	mdriver "github.com/vista-forge/m-driver-sdk"

	"github.com/vista-forge/m-ydb/clikit"
	"github.com/vista-forge/m-ydb/internal/config"
	"github.com/vista-forge/m-ydb/internal/driver"
	"github.com/vista-forge/m-ydb/internal/runlock"
)

// The per-engine run-lock, driver side (driver-contract.md §5.8; design
// m-driver-sdk/docs/design/run-lock.md).
//
// Three pieces live here, and only here:
//
//	guardRunLock   the dispatch middleware — the ONE choke point that refuses an
//	               unbracketed mutation. Keyed off the SDK's verb-class registry, so
//	               a new verb inherits the check with no extra code.
//	runLockRef     the key/path derivation — the driver is the SINGLE derivation
//	               authority (R-3), so no two lanes can lock different files for one
//	               engine.
//	meta runlock-* the two verbs that expose those to consumers.
//
// The one rule not to "improve": VERIFICATION NEVER ACQUIRES. The check is a
// non-blocking probe plus a record compare. A driver that helpfully WAITED for the
// lock would make the first in-bracket call block on its own run's bracket, and
// every later call in that run would refuse. Owners verify; only outsiders wait,
// and only at bracket-open, in the orchestrator (§7).

// runLockDeps builds the resolution seams for a connection. It is a var so tests
// can inject a fake engine probe — the production wiring is the real docker CLI,
// the real hostname, and a real SSH round trip.
var runLockDeps = func(conn *config.Conn) runlock.Deps {
	return runlock.Deps{
		// The SDK locator classifies its own failures since v0.8.1 (S2): a dead
		// daemon REFUSES, a missing docker CLI is a clean answer (ErrNoDocker —
		// the docker route refuses, a network route classifies foreign). m-ydb's
		// interim LocalDocker hardening wrapper is retired — the upstream fix it
		// filed for ("needs SDK", tracker) shipped.
		Docker:   mdriver.NewDockerLocator(),
		Probe:    nodeProbe(conn),
		Hostname: os.Hostname,
		RealPath: filepath.EvalSymlinks,
	}
}

// runLockRef derives this connection's lock key + path through the R-9.3 ladder.
//
// It re-derives on EVERY call rather than trusting M_RUN_LOCK_KEY from the
// environment: an ambient key is a self-report, and trusting it would let a lane
// holding a vehu bracket aim a call at another engine and pass verification — the
// token matches, at the *claimed* key (§R-9.4 alternative 5). The driver asks the
// world where this engine is; it never accepts an answer from the caller.
func runLockRef(ctx context.Context, conn *config.Conn) (mdriver.RunLockRef, error) {
	conn.ResolveEnv()
	loc, err := runlock.Resolve(ctx, runlock.Target{
		Engine:    engineName,
		Transport: conn.Transport,
		Container: conn.Container,
		GblDir:    conn.GblDir,
	}, runLockDeps(conn))
	if err != nil {
		return mdriver.RunLockRef{}, err
	}
	return mdriver.DeriveRunLockRef(conn.RunLockDir, loc.Key(engineName))
}

const engineName = "ydb"

// guardRunLock is the dispatch middleware — m-ydb's enforcement of §5.8.
//
// It runs at the ONE point every engine-reaching verb passes through: the
// connection's provider (CLI.ProvideConn). Not at conn.NewSession() — that is
// called from ten sites across doctor/lifecycle/exec, and a ten-site guard is the
// hand-rolled-bracket antipattern (the v-pkg audit found an attest bracket
// copy-pasted ×9, and the next verb added without it). A verb cannot reach the
// engine without a *config.Conn, so it cannot reach the engine without passing
// here — and TestGuardCoverage_EveryBracketVerbTakesTheConn red-gates the converse.
func guardRunLock(kctx *kong.Context, conn *config.Conn) error {
	axis, verb := axisVerb(kctx)
	if axis == "" || verb == "" {
		return nil // not a contract verb (e.g. install-completions)
	}

	// Honesty first (C-CAPS-1): a verb this CONNECTION does not dispatch is refused
	// on the contract's "unsupported" rung, not attempted and failed at runtime.
	if !driver.Supports(conn.Transport, axis, verb) {
		return clikit.Fail(clikit.ExitUnsupported, "UNSUPPORTED",
			fmt.Sprintf("`%s %s` is not available over the %s transport", axis, verb, conn.Transport),
			"run `meta caps` — the capability document describes THIS connection, not the binary")
	}

	if !runLockGuardEnabled {
		// Only the `guardoff` build tag compiles this true (guard_disabled.go) —
		// the L1.B1 wrapper's variant. Everything from here down is what that
		// variant proves the refusal suite depends on.
		return nil
	}

	class, ok := mdriver.ClassOf(axis, verb)
	if !ok {
		// An unclassified verb is one this middleware cannot enforce — an unenforced
		// hole. Refusing it forces the taxonomy question at add-time instead of leaving
		// the hole open for the next hurried change. Conformance red-gates it too.
		return clikit.Fail(clikit.ExitUnsupported, "UNCLASSIFIED_VERB",
			fmt.Sprintf("`%s %s` carries no run-lock class, so the driver cannot enforce the bracket on it", axis, verb),
			"classify it in the SDK's verb registry (mdriver.ClassifiedVerbs) before wiring it")
	}
	if !class.RequiresRunLock() {
		// Status and control verbs run unconditionally — the DECLARED escape hatch
		// (§R-7), not a silent bypass. It is load-bearing twice: the remedy for a stuck
		// run must not queue behind the stuck run, and AcquireRunLock bootstraps by
		// calling runlock-path, so a token-gated derivation could never be reached.
		// Note this returns BEFORE resolving the locus: a status verb pays no engine
		// call for a lock it does not need.
		return nil
	}

	ref, err := runLockRef(context.Background(), conn)
	if err != nil {
		return runLockFail(err)
	}
	return runLockFail(mdriver.RequireRunLock(class, ref, conn.RunLockToken))
}

// axisVerb reads the dispatched contract verb from the parsed command path — the
// registry's key. Reading the NODE names (rather than splitting kctx.Command(),
// which renders placeholders like "exec eval <m-command>") keeps the lookup exact.
func axisVerb(kctx *kong.Context) (axis, verb string) {
	node := kctx.Selected()
	if node == nil || node.Parent == nil || node.Parent.Type != kong.CommandNode {
		return "", ""
	}
	return node.Parent.Name, node.Name
}

// runLockFail renders a run-lock refusal onto the contract's error ladder: the
// CODE is what a consumer branches on, and exit 4 is the ladder's existing refusal
// rung (clikit.ExitRefused — "conflict / refusal (lock held, …)").
func runLockFail(err error) error {
	if err == nil {
		return nil
	}
	var rl *mdriver.RunLockError
	if errors.As(err, &rl) {
		return clikit.Fail(rl.Exit, rl.Code, rl.Error(), rl.Hint)
	}
	return clikit.Fail(clikit.ExitRuntime, "RUNLOCK_FAILED", err.Error(), "")
}

// nodeProbe asks a LIVE engine over the remote (SSH) route who it is — the
// engine-ask the R-9.3 ladder needs for network routes, where the selector names a
// route and not a place.
//
// It is DRIVER-INTERNAL: a plain call on the transport session, never a re-entry
// into the CLI. That is what keeps the per-call re-derivation from recursing
// through the dispatch check that invoked it (design amendment B), and it is
// red-proven by TestGuard_NetworkRouteDoesNotReenterTheMiddleware.
func nodeProbe(conn *config.Conn) runlock.Probe {
	return func(ctx context.Context) (runlock.Node, error) {
		s := conn.NewSession()

		// Ask the ENGINE for its own global directory. Authoritative, and — unlike
		// reading $ydb_gbldir in a far-side shell — it does not depend on whether the
		// remote env file EXPORTS the variable into a child process.
		res, err := s.Exec(ctx, mdriver.ExecRequest{Command: "write $ZGBLDIR"})
		if err != nil {
			return runlock.Node{}, fmt.Errorf("the engine could not be asked for its $ZGBLDIR: %w", err)
		}
		gbldir := strings.TrimSpace(res.Stdout)
		if gbldir == "" {
			return runlock.Node{}, errors.New("the engine reported an empty $ZGBLDIR")
		}

		// Then ask the engine's HOST who it is, and canonicalize that gbldir where it
		// actually lives — the interior is measured on the far side, never mapped from
		// a host-side declaration (engine-instance-path ADR).
		out, code, err := s.Sh(ctx, "uname -n && readlink -f "+shQuote(gbldir))
		if err != nil {
			return runlock.Node{}, fmt.Errorf("the engine host could not be reached: %w", err)
		}
		if code != 0 {
			return runlock.Node{}, fmt.Errorf("the engine host refused the identity probe (exit %d)", code)
		}
		var lines []string
		for _, ln := range strings.Split(out, "\n") {
			if ln = strings.TrimSpace(ln); ln != "" {
				lines = append(lines, ln)
			}
		}
		if len(lines) < 2 {
			return runlock.Node{}, fmt.Errorf("the engine host's identity probe returned %q", strings.TrimSpace(out))
		}
		return runlock.Node{Name: lines[0], GblDir: lines[1]}, nil
	}
}

// shQuote single-quotes a token for the far-side shell (a path may contain spaces).
func shQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'" }

// --- meta runlock-path --------------------------------------------------------

// runlockPathCmd answers "where is this engine's lock?" — and it is the SINGLE
// derivation authority for that answer (R-3). bash, m-cli, v-pkg and both drivers
// ask this verb rather than composing a path themselves, because two lanes
// "locking" different keys for one container is a silent failure of mutual
// exclusion — the exact defect the lock exists to prevent.
//
// CONTROL class: it takes no token. AcquireRunLock bootstraps through it (§7.3).
type runlockPathCmd struct{}

func (runlockPathCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	ref, err := runLockRef(context.Background(), conn)
	if err != nil {
		return runLockFail(err)
	}
	return cc.Result(ref, func() {
		cc.KV([2]string{"key", cc.Accent(ref.Key)}, [2]string{"path", ref.Path})
	})
}

// --- meta runlock-status ------------------------------------------------------

// runlockStatusCmd measures the holder. The measurement itself is
// mdriver.ProbeRunLock, VERBATIM — the three trust layers (flock = the truth of
// held-ness, /proc/locks = the kernel's answer to *who*, the record = narrative)
// live in the SDK precisely so a second implementation cannot drift from m-iris's.
//
// CONTROL class: no token. The remedy for a stuck run must never queue behind the
// stuck run.
type runlockStatusCmd struct{}

func (runlockStatusCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	ref, err := runLockRef(context.Background(), conn)
	if err != nil {
		return runLockFail(err)
	}
	st, err := mdriver.ProbeRunLock(ref)
	if err != nil {
		return clikit.Fail(clikit.ExitRuntime, "RUNLOCK_PROBE_FAILED",
			fmt.Sprintf("cannot measure the run-lock at %s: %v", ref.Path, err), "")
	}
	return cc.Result(st, func() {
		cc.Title("run-lock — " + st.Key)
		fmt.Fprintln(cc.Stdout, st.Describe())
		if st.State == mdriver.HolderStopped {
			fmt.Fprintln(cc.Stdout, st.StoppedHolderTriage())
		}
		// The production boundary, said out loud where it applies (decision #8): flock
		// is per-kernel, so a FOREIGN instance is serialized among lanes on this driving
		// host only. This is a lab/CI safety net, not a production concurrency control.
		if strings.HasPrefix(st.Key, engineName+"."+string(mdriver.LocusRemote)+".") {
			fmt.Fprintln(cc.Stdout, "note: this engine is remote — the run-lock serializes lanes on THIS host only.")
		}
	})
}
