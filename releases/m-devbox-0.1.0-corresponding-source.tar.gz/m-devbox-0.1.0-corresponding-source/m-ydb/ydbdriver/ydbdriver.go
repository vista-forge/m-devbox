// Package ydbdriver is m-ydb's public, importable surface: it constructs a
// YottaDB mdriver.Transport for in-process consumers (notably m-cli's
// VistaEngine) that speak only the neutral engine-driver contract. All vendor
// logic stays in internal/ — this package is the thin seam that lets another
// module hold a YottaDB Transport without reaching into m-ydb's internals.
//
// The same Transport covers all three reaches behind one contract: local
// (native install), docker (a container we manage), and remote (SSH to a host
// running YottaDB). Pick one via Config.Transport.
//
// RUN-LOCK (RK-13 disposition — G6-keyed entry point): this constructor is
// deliberately NOT behind the CLI dispatch guard, because an in-process
// consumer bypasses the driver process entirely and the facade cannot verify a
// bracket without becoming a second derivation authority (R-3: the driver CLI
// is the single derivation authority). The BRACKET DUTY IS THE IMPORTER'S: hold
// a run-lock bracket (mdriver.AcquireRunLock) around any mutating/read use of
// this Transport. `m arch check`'s G6 keys on this import path — an importer
// with no resolving bracket marker is red-gated. The structural test
// (apisurface_test.go) pins this package as the module's only such surface.
package ydbdriver

import (
	mdriver "github.com/vista-forge/m-driver-sdk"
	"github.com/vista-forge/m-ydb/internal/transport"
)

// Config is the YottaDB connection. It re-exports the internal transport config
// so external callers configure the engine without importing internal/.
//
//	local:  Dist / GblDir / Routines locate the install + database.
//	docker: Container is the container to exec into.
//	remote: Host (+ Port/User/Identity) is the SSH target; EnvFile is sourced
//	        on the far side for the YottaDB environment.
type Config = transport.Config

// New builds a YottaDB Transport over the given connection, using the real OS
// runner. Callers hold the result as an mdriver.Transport and never see vendor
// detail; the T0.1 readiness gate is Health (W $ZV via Exec).
func New(cfg Config) mdriver.Transport {
	return transport.NewSession(cfg, nil)
}
