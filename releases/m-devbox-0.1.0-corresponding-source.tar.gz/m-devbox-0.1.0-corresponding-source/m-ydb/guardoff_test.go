//go:build !guardoff

package main

import (
	"context"
	"os"
	"os/exec"
	"strings"
	"testing"
	"time"
)

// L1.B1 — THE LOAD-BEARING PROOF (runlock-stack-hardening master, Dev-8).
//
// The refusal suite passing proves the guard refuses; it does not prove the
// suite would NOTICE if the guard were deleted. So this wrapper builds the
// guard-off variant (`-tags guardoff` compiles runLockGuardEnabled=false) and
// runs the refusal cases against it, asserting they go RED — the tests fail
// exactly when the guard stops guarding, so a pass here is measured evidence
// that the suite is load-bearing, not passing by luck.
//
// It is a WRAPPER in the normal suite, deliberately: no Makefile or CI
// invocation passes `-tags` (DS-15), so a bare build-tagged suite would be
// dead code, and an added `-tags` CI line can be dropped silently. A plain
// `go test` member cannot stop running without deleting a visible test.
//
// This file itself carries `!guardoff` so the inner run cannot recurse into it.

// guardRefusalCases are the refusal tests that MUST fail under the variant:
// no-token, dead-bracket token, and zombie-token fencing.
var guardRefusalCases = []string{
	"TestGuard_MutatingVerbWithNoTokenIsRefused",
	"TestGuard_TokenButNoBracketIsRefused",
	"TestGuard_ForeignTokenAgainstALiveBracketIsRefusedAsMismatch",
}

func TestGuardOff_RefusalCasesGoRed(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	cmd := exec.CommandContext(ctx, "go", "test", "-count=1",
		"-tags", "guardoff", "-run", strings.Join(guardRefusalCases, "|"), ".")
	cmd.Env = os.Environ()
	out, err := cmd.CombinedOutput()
	s := string(out)

	if err == nil {
		t.Fatalf("the refusal cases PASSED against the guard-off variant — the guard is not "+
			"load-bearing: either the variant did not disable it, or the refusals never depended "+
			"on it\n%s", s)
	}
	// It must have failed because the CASES ran and redded — not because the
	// variant failed to compile or the -run expression matched nothing (both of
	// which leave no "--- FAIL: <case>" lines).
	for _, name := range guardRefusalCases {
		if !strings.Contains(s, "--- FAIL: "+name) {
			t.Errorf("refusal case %s did not run and fail under the guard-off variant\n%s", name, s)
		}
	}
}
