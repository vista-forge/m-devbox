# m-ydb — driver-contract conformance (nightly)

generated: 2026-07-27T07:15:03Z
verdict: CONFORMANT
sdkPin: v0.11.0
binarySha256: 6cb490991356bb5826d4541194ecc463234f965c39911d75fa461413e992c95b
buildMode: go.work (dev-loop working trees — NOT the committed pin; audit F-13). Release-time pinned proof: make conformance-pinned.

```
go build -trimpath -ldflags "-s -w -X github.com/vista-forge/m-ydb/clikit.Version=5a2fd33 -X github.com/vista-forge/m-ydb/clikit.Commit=5a2fd33 -X github.com/vista-forge/m-ydb/clikit.Date=2026-07-27" -o dist/m-ydb .
M_YDB_CONTAINER=m-test-engine \
	go run github.com/vista-forge/m-driver-sdk/cmd/m-driver-conformance \
		--driver ./dist/m-ydb --transport docker
m-driver-conformance — ydb (transport docker)
  [PASS] caps: envelope
  [PASS] caps: engine
  [PASS] caps: contract major
  [PASS] caps: transports non-empty
  [PASS] caps: advertises tested transport
  [PASS] caps: features.remote honest
  [PASS] caps: meta self-listing
  [PASS] caps: no empty axes
  [PASS] version: envelope
  [PASS] version: engine matches caps
  [PASS] version: contract matches caps
  [PASS] doctor: envelope
  [PASS] doctor: exit
  [PASS] doctor: has checks
  [PASS] status: envelope
  [PASS] status: healthy implies running
  [PASS] verb classes: every advertised verb is classified
  [PASS] C-CAPS-1 caps are connection-resolved
  [PASS] C-CAPS-2 caps.limits is honest
  [PASS] C-RL-1 mutate with no token → RUN_LOCK_REQUIRED: envelope
  [PASS] C-RL-1 mutate with no token → RUN_LOCK_REQUIRED
  [PASS] C-RL-3 token presented, lock free → RUN_LOCK_NOT_HELD: envelope
  [PASS] C-RL-3 token presented, lock free → RUN_LOCK_NOT_HELD
  [PASS] C-RL-2 mutate with a valid token + held lock → proceeds: envelope
  [PASS] C-RL-2 mutate with a valid token + held lock → proceeds
  [PASS] C-RL-4 token presented, lock held by another record → RUN_LOCK_MISMATCH (fencing): envelope
  [PASS] C-RL-4 token presented, lock held by another record → RUN_LOCK_MISMATCH (fencing)
  [PASS] C-RL-9 hostile $HOME → SAME lock ref, refusal fences on the REAL record (the D9 red-proof) [runlock-path]: envelope
  [PASS] C-RL-9 hostile $HOME → SAME lock ref, refusal fences on the REAL record (the D9 red-proof) [fencing]: envelope
  [PASS] C-RL-9 hostile $HOME → SAME lock ref, refusal fences on the REAL record (the D9 red-proof)
  [PASS] C-RL-5 status/control verbs run with no token [meta caps]: envelope
  [PASS] C-RL-5 status/control verbs run with no token [meta runlock-status]: envelope
  [PASS] C-RL-5 status/control verbs run with no token
  [PASS] C-RL-6 try-mode on a held lock → busy outcome, no side effects
  [SKIP] C-RL-7 two routes to one instance → BYTE-EQUAL runlock-path (the R-9 red-proof) — no dual route configured (Options.PeerTransport) — this driver/lab has no second route to the same instance to cross-check
  [SKIP] C-RL-8 unresolvable route → RUN_LOCK_UNRESOLVED, never a selector-spelled key — no unresolvable-route fixture configured (Options.UnresolvableArgs)
  [PASS] C-CAPS-2 [maxString at-limit]: envelope
  [PASS] C-CAPS-2 [maxString at-limit]
  [PASS] C-CAPS-2 [evalEnvelope at-limit]: envelope
  [PASS] C-CAPS-2 [evalEnvelope at-limit]
  [PASS] C-CAPS-2 [maxNodeValue at-limit]: envelope
  [PASS] C-CAPS-2 [maxNodeValue at-limit]
  [PASS] C-CAPS-2 [loadBodyBytes at-limit] [load]: envelope
  [PASS] C-CAPS-2 [loadBodyBytes at-limit] [run]: envelope
  [PASS] C-CAPS-2 [loadBodyBytes at-limit]
  [PASS] C-CAPS-2 [loadBodyBytes at-limit] [unstage]: envelope

44 passed, 0 failed, 2 skipped
```
