package main

import (
	"bytes"
	"context"
	"encoding/base64"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	mdriver "github.com/vista-forge/m-driver-sdk"
	"github.com/vista-forge/m-ydb/clikit"
	"github.com/vista-forge/m-ydb/internal/config"
	"github.com/vista-forge/m-ydb/internal/transport"
)

func newLocalConn(routines string) *config.Conn {
	return &config.Conn{Transport: "local", Routines: routines}
}

func writeTmp(dir, name, body string) error {
	return os.WriteFile(filepath.Join(dir, name), []byte(body), 0o644)
}

func fileExists(dir, name string) bool {
	_, err := os.Stat(filepath.Join(dir, name))
	return err == nil
}

// fakeSession builds a local-transport Session whose OS runner is replaced by
// the given canned output, so the exec command glue is testable without an
// engine.
func fakeSession(out transport.CmdOutput) *transport.Session {
	return transport.NewSession(
		transport.Config{Transport: "local"},
		func(_ context.Context, _, _ []string, _ string) (transport.CmdOutput, error) {
			return out, nil
		},
	)
}

func TestExecDo_Success(t *testing.T) {
	var buf bytes.Buffer
	sess := fakeSession(transport.CmdOutput{Stdout: "hello\n", Code: 0})
	if err := execDo(jsonCtx(&buf, "exec eval"), sess, mdriver.ExecRequest{Command: "w \"hello\",!"}); err != nil {
		t.Fatalf("execDo: %v", err)
	}
	env := decodeEnvelope(t, buf.Bytes())
	if !env.OK || env.Exit != clikit.ExitOK {
		t.Fatalf("ok=%v exit=%d, want ok=true exit=0", env.OK, env.Exit)
	}
	d, _ := env.Data.(map[string]any)
	if d["stdout"] != "hello\n" {
		t.Errorf("data.stdout = %v, want hello", d["stdout"])
	}
}

func TestExecLoad_StagesFromDir(t *testing.T) {
	stageDir := t.TempDir() // instance source dir (dirs[0])
	from := t.TempDir()
	for _, n := range []string{"FOO.m", "BAR.m"} {
		if err := writeTmp(from, n, n+" ;x\n q\n"); err != nil {
			t.Fatal(err)
		}
	}
	conn := newLocalConn(stageDir)
	var buf bytes.Buffer
	c := &execLoadCmd{From: from, NoCompile: true}
	if err := c.Run(jsonCtx(&buf, "exec load"), conn); err != nil {
		t.Fatalf("load: %v", err)
	}
	d, _ := decodeEnvelope(t, buf.Bytes()).Data.(map[string]any)
	if loaded, _ := d["loaded"].([]any); len(loaded) != 2 {
		t.Errorf("loaded = %v, want 2", d["loaded"])
	}
	for _, n := range []string{"FOO.m", "BAR.m"} {
		if !fileExists(stageDir, n) {
			t.Errorf("%s not staged into the instance dir", n)
		}
	}
}

func TestExecLoad_CompileErrorSurfaced(t *testing.T) {
	// A YottaDB compile fault is a stderr listing (exit 0), parsed by Compile.
	out := transport.CmdOutput{
		Stderr: " bad zzznotacommand\n     ^-----\nAt column 5, line 2, source module /r/FOO.m\n%YDB-E-INVCMD, Invalid command keyword encountered\n",
		Code:   0,
	}
	sess := fakeSession(out)
	ee, err := sess.Compile(context.Background(), []string{"FOO"})
	if err != nil {
		t.Fatalf("Compile: %v", err)
	}
	if ee == nil || ee.Mnemonic != "%YDB-E-INVCMD" || ee.Routine != "FOO" || ee.Line != 2 {
		t.Errorf("compile engineError = %+v, want INVCMD at FOO line 2", ee)
	}
}

func TestExecDo_EngineErrorSurfaced(t *testing.T) {
	var buf bytes.Buffer
	out := transport.CmdOutput{
		Stdout: "\x01150373850,xeq+1^FOO,%YDB-E-UNDEF,Undefined local variable: x\x01",
		Code:   1,
	}
	sess := fakeSession(out)
	err := execDo(jsonCtx(&buf, "exec eval"), sess, mdriver.ExecRequest{Command: "w x"})
	if err == nil {
		t.Fatal("expected an error for a faulting exec")
	}
	var ce *clikit.Error
	if !errors.As(err, &ce) {
		t.Fatalf("want *clikit.Error, got %T", err)
	}
	if ce.Exit != clikit.ExitRuntime {
		t.Errorf("exit = %d, want %d", ce.Exit, clikit.ExitRuntime)
	}
	if ce.Engine == nil || ce.Engine.Mnemonic != "%YDB-E-UNDEF" || ce.Engine.Routine != "FOO" {
		t.Errorf("engineError = %+v", ce.Engine)
	}
}

// --- managed staging namespace (exec load --stage-dir / unstage / sweep) ----

func TestExecLoad_StagesIntoStageDir(t *testing.T) {
	primary := t.TempDir()
	from := t.TempDir()
	if err := writeTmp(from, "FOO.m", "foo ;x\n q\n"); err != nil {
		t.Fatal(err)
	}
	conn := newLocalConn(primary)
	conn.StageDir = "mtest-run1"
	var buf bytes.Buffer
	c := &execLoadCmd{From: from, NoCompile: true}
	if err := c.Run(jsonCtx(&buf, "exec load"), conn); err != nil {
		t.Fatalf("load: %v", err)
	}
	if !fileExists(filepath.Join(primary, "mtest-run1"), "FOO.m") {
		t.Error("FOO.m not staged into the mtest-run1 subdir")
	}
	if fileExists(primary, "FOO.m") {
		t.Error("FOO.m leaked into the flat primary dir")
	}
}

func TestExecScript_PrepsManagedStaging(t *testing.T) {
	// exec script must stage-prep the conn exactly like load/run/eval: without
	// EnsureStageRoutines the direct-mode script resolves only the ambient
	// routine path and every staged routine silently does not exist — the
	// `m coverage` 0.0% regression (2026-07-06).
	primary := t.TempDir()
	conn := newLocalConn(primary)
	conn.StageDir = "mtest-run1"
	var buf bytes.Buffer
	c := &execScriptCmd{ScriptB64: base64.StdEncoding.EncodeToString([]byte("halt\n"))}
	_ = c.Run(jsonCtx(&buf, "exec script"), conn) // engine may be absent; the conn prep is the contract
	want := filepath.Join(primary, "mtest-run1")
	if !strings.HasPrefix(conn.Routines, want+" ") {
		t.Errorf("conn.Routines = %q, want the managed staging dir %q first", conn.Routines, want)
	}
}

func TestExecUnstage_RemovesTheRunStageDir(t *testing.T) {
	primary := t.TempDir()
	stage := filepath.Join(primary, "mtest-run1")
	if err := os.MkdirAll(stage, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := writeTmp(stage, "FOO.m", "foo ;\n q\n"); err != nil {
		t.Fatal(err)
	}
	conn := newLocalConn(primary)
	conn.StageDir = "mtest-run1"
	var buf bytes.Buffer
	c := &execUnstageCmd{}
	if err := c.Run(jsonCtx(&buf, "exec unstage"), conn); err != nil {
		t.Fatalf("unstage: %v", err)
	}
	if _, err := os.Stat(stage); !os.IsNotExist(err) {
		t.Error("stage dir still present after unstage")
	}
	d, _ := decodeEnvelope(t, buf.Bytes()).Data.(map[string]any)
	if d["removed"] != "mtest-run1" {
		t.Errorf("data.removed = %v, want mtest-run1", d["removed"])
	}
}

func TestExecUnstage_NeedsStageDir(t *testing.T) {
	conn := newLocalConn(t.TempDir())
	var buf bytes.Buffer
	c := &execUnstageCmd{}
	if err := c.Run(jsonCtx(&buf, "exec unstage"), conn); err == nil {
		t.Error("unstage without --stage-dir must be a usage error")
	}
}

func TestExecSweep_RetiresOnlyStaleStageDirs(t *testing.T) {
	primary := t.TempDir()
	old := time.Now().Add(-25 * time.Hour)
	for name, ts := range map[string]time.Time{"mtest-old": old, "mtest-fresh": time.Now()} {
		d := filepath.Join(primary, name)
		if err := os.MkdirAll(d, 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(d, ts, ts); err != nil {
			t.Fatal(err)
		}
	}
	conn := newLocalConn(primary)
	var buf bytes.Buffer
	c := &execSweepCmd{TTLHours: 24}
	if err := c.Run(jsonCtx(&buf, "exec sweep"), conn); err != nil {
		t.Fatalf("sweep: %v", err)
	}
	if _, err := os.Stat(filepath.Join(primary, "mtest-old")); !os.IsNotExist(err) {
		t.Error("mtest-old survived the sweep")
	}
	if _, err := os.Stat(filepath.Join(primary, "mtest-fresh")); err != nil {
		t.Error("mtest-fresh should have survived the sweep")
	}
	d, _ := decodeEnvelope(t, buf.Bytes()).Data.(map[string]any)
	if swept, _ := d["swept"].([]any); len(swept) != 1 || swept[0] != "mtest-old" {
		t.Errorf("data.swept = %v, want [mtest-old]", d["swept"])
	}
}
