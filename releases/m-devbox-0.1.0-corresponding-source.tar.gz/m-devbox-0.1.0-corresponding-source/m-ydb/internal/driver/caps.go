// Package driver holds the m-ydb vendor logic: the YottaDB-specific realization
// of the neutral engine-driver contract. It depends on the shared SDK
// (github.com/vista-forge/m-driver-sdk) for the contract shapes and the
// verb-level Transport, and knows nothing of m-cli.
package driver

import mdriver "github.com/vista-forge/m-driver-sdk"

// CapsFor returns the m-ydb capability document for ONE CONNECTION
// (driver-contract.md §4; run-lock design decision #7).
//
// The document describes the **connection, not the binary**. That distinction is
// the whole of decision #7: a caps document that advertises the binary's union
// tells a remote caller "supported", and the call then fails at runtime — and the
// same shape would make `features.runLock` a lie, which owner decision #4 (an old
// driver is a HARD ERROR, never a silent unlocked run) trusts absolutely. So the
// axes here are filtered to what THIS transport actually dispatches, and
// `transport` names the connection the document is about.
//
// It stays HONEST by construction: Supports() below reads this same table, and the
// dispatch middleware refuses (exit 7) anything it does not advertise. Caps and
// enforcement therefore cannot drift — there is one table, with two readers.
//
// YottaDB is daemonless and file-based. There is no network *engine* API, but the
// engine is reachable three ways: local (native install), docker (a container we
// manage), and remote — an SSH host-shell transport that runs the same yottadb
// invocation on another host (e.g. a FOIA `vehu` server).
func CapsFor(transport string) mdriver.Caps {
	c := mdriver.Caps{
		Engine:     "ydb",
		Contract:   mdriver.ContractVersion,
		Transport:  transport,
		Transports: []string{mdriver.TransportLocal, mdriver.TransportDocker, mdriver.TransportRemote},
		Axes: mdriver.Axes{
			// meta: introspection + the run-lock derivation pair. runlock-path and
			// runlock-status are CONTROL class — they take no token, which is what lets
			// AcquireRunLock bootstrap (§7.3: a token-gated derivation verb could never
			// be reached, so the bracket could never be taken at all).
			Meta:      []string{"caps", "info", "version", "schema", "doctor", "runlock-path", "runlock-status"},
			Lifecycle: []string{"up", "down", "restart", "status", "wait", "provision", "destroy"},
			Sync:      []string{"list", "pull", "status", "verify", "diff", "push", "deploy", "rm"},
			Exec:      []string{"load", "run", "eval", "script", "abort", "unstage", "sweep"},
		},
		Features: mdriver.Features{
			Remote:          true,  // SSH host-shell transport (not a network engine API)
			Prune:           true,  // sync deploy --prune true-sync (M2)
			EphemeralPrefix: true,  // exec --prefix zzt<runid> staging (M3)
			Snapshot:        false, // lifecycle snapshot/rollback — roadmap §10, not yet
			ManagedStaging:  true,  // exec load --stage-dir / unstage / sweep (mtest-* namespace)
			// RunLock: this driver's own promise that its dispatch REFUSES any
			// mutating/read verb that cannot prove a live bracket. Conformance holds it
			// to that promise the instant it is true (C-RL-1…8).
			RunLock: true,
		},
	}

	// Limits (contract 1.1 §4a) ship ONLY on the measured lane. The docker-lane
	// values are the engine-capability fact-check's, measured on YottaDB r2.02 /
	// vehu 2026-07-16 (docs repo proposals/engine-capability-registry/
	// engine-capability-registry-measured-report.md; probes engcap-l1/l3/p3b):
	//   - maxString: engine ceiling, clean MAXSTRLEN one past.
	//   - maxNodeValue 16368 is kind "region-config" — the REFERENCE instance's
	//     max_rec_size (identical TEMP/DEFAULT there); a site's region may carry
	//     more or less, which is exactly what the kind field tells consumers.
	//   - evalEnvelope: the 32766 indirection cap minus this driver's exec
	//     wrapper; loadBodyBytes: the Linux MAX_ARG_STRLEN argv cap through
	//     docker exec (fails LOUD: "argument list too long").
	// local/remote lanes are UNMEASURED and ship NO block (contract §4a: a
	// guessed block is worse than none — consumers keep their gated constants).
	if transport == mdriver.TransportDocker {
		c.Limits = &mdriver.Limits{
			MaxString:        1048576,
			MaxNodeValue:     16368,
			MaxNodeValueKind: "region-config",
			MaxKeyBytes:      1019,
			MaxSubscripts:    31,
			EvalEnvelope:     32635,
			LoadBodyBytes:    97275,
			FaultMnemonics: map[string]string{
				"oversize-string":     "MAXSTRLEN",
				"oversize-node":       "REC2BIG",
				"oversize-key":        "GVSUBOFLOW",
				"too-many-subscripts": "MAXNRSUBSCRIPTS",
			},
		}
	}

	if transport == mdriver.TransportRemote {
		// Over SSH the instance is provisioned and torn down on the host, out of band —
		// the driver only attaches to it (transport.errRemoteAttachOnly).
		c.Axes.Lifecycle = without(c.Axes.Lifecycle, "provision", "destroy")
		// The sync axis needs a routine SOURCE STORE, which is not wired over SSH
		// (config.Conn.SourceStore). An axis with no realizable verb is not advertised
		// at all rather than advertised and refused.
		c.Axes.Sync = nil
		// exec load stages through that same source store; run/eval/script/abort and the
		// staging lifecycle (unstage/sweep, which drive the far-side shell) do dispatch.
		c.Axes.Exec = without(c.Axes.Exec, "load")
	}
	return c
}

// Supports reports whether a connection on this transport actually dispatches a
// verb. It is the dispatch middleware's honesty check and the exact converse of
// what CapsFor advertises — an unadvertised verb is refused with exit 7 (the
// contract's "unsupported" rung), never attempted and failed at runtime (C-CAPS-1).
func Supports(transport, axis, verb string) bool {
	for _, av := range CapsFor(transport).Axes.Wired() {
		if av.Name == axis {
			for _, v := range av.Verbs {
				if v == verb {
					return true
				}
			}
			return false
		}
	}
	return false
}

// without returns the verbs minus the named ones, preserving order.
func without(verbs []string, drop ...string) []string {
	cut := make(map[string]bool, len(drop))
	for _, d := range drop {
		cut[d] = true
	}
	out := make([]string, 0, len(verbs))
	for _, v := range verbs {
		if !cut[v] {
			out = append(out, v)
		}
	}
	return out
}
