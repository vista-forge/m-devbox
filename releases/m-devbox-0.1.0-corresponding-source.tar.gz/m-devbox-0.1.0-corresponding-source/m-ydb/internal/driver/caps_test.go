package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

var transports = []string{
	mdriver.TransportLocal, mdriver.TransportDocker, mdriver.TransportRemote,
}

// TestCaps_GoldenJSON pins the m-ydb capability document (driver-contract.md §4)
// PER TRANSPORT — the golden files are the byte-for-byte contract m-cli reads via
// `meta caps`. They are per-transport because the document describes the
// CONNECTION, not the binary (decision #7): one golden could only pin the union,
// which is the very dishonesty that decision closes.
func TestCaps_GoldenJSON(t *testing.T) {
	for _, tr := range transports {
		t.Run(tr, func(t *testing.T) {
			got, err := json.MarshalIndent(CapsFor(tr), "", "  ")
			if err != nil {
				t.Fatalf("marshal caps: %v", err)
			}
			got = append(got, '\n')

			golden := filepath.Join("testdata", "caps-"+tr+".json")
			if os.Getenv("UPDATE_GOLDEN") == "1" {
				if err := os.WriteFile(golden, got, 0o644); err != nil {
					t.Fatalf("update golden: %v", err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatalf("read golden: %v", err)
			}
			if string(got) != string(want) {
				t.Errorf("caps JSON mismatch:\n--- got ---\n%s\n--- want ---\n%s", got, want)
			}
		})
	}
}

// TestCaps_Invariants asserts contract-level invariants independently of the
// golden bytes, so a wrong golden can't mask a real regression.
func TestCaps_Invariants(t *testing.T) {
	for _, tr := range transports {
		c := CapsFor(tr)
		if c.Engine != "ydb" {
			t.Errorf("[%s] engine = %q, want ydb", tr, c.Engine)
		}
		if c.Contract != mdriver.ContractVersion {
			t.Errorf("[%s] contract = %q, want %q", tr, c.Contract, mdriver.ContractVersion)
		}
		// C-CAPS-1: the document must name the connection it describes, or every
		// capability in it (including features.runLock, which decision #4 trusts) is a
		// claim about a connection the caller may not have.
		if c.Transport != tr {
			t.Errorf("[%s] caps.transport = %q — the document does not name its own connection", tr, c.Transport)
		}
		if want := []string{"local", "docker", "remote"}; !equal(c.Transports, want) {
			t.Errorf("[%s] transports = %v, want %v", tr, c.Transports, want)
		}
		if !c.Features.Remote {
			t.Errorf("[%s] features.remote must be true (SSH host-shell transport)", tr)
		}
		// Honest caps: every advertised (non-nil) axis must be non-empty.
		for name, verbs := range map[string][]string{
			"lifecycle": c.Axes.Lifecycle, "sync": c.Axes.Sync, "exec": c.Axes.Exec,
			"data": c.Axes.Data, "cover": c.Axes.Cover, "admin": c.Axes.Admin, "meta": c.Axes.Meta,
		} {
			if verbs != nil && len(verbs) == 0 {
				t.Errorf("[%s] axis %q is advertised but empty", tr, name)
			}
		}
		if !contains(c.Axes.Meta, "caps") || !contains(c.Axes.Meta, "version") {
			t.Errorf("[%s] meta axis = %v, must include caps and version", tr, c.Axes.Meta)
		}
	}
}

// The run-lock's own derivation verbs must be advertised on EVERY transport: a
// consumer that cannot reach `runlock-path` cannot open a bracket at all, so the
// engine would be unusable rather than protected (§7.3).
func TestCaps_RunLockVerbsOnEveryTransport(t *testing.T) {
	for _, tr := range transports {
		c := CapsFor(tr)
		for _, verb := range []string{"runlock-path", "runlock-status"} {
			if !contains(c.Axes.Meta, verb) {
				t.Errorf("[%s] meta axis does not advertise %q — no consumer could open a bracket", tr, verb)
			}
		}
		if !c.Features.RunLock {
			t.Errorf("[%s] features.runLock must be true — this driver enforces the bracket in dispatch", tr)
		}
	}
}

// EVERY advertised verb must be classified in the SDK's registry, or the dispatch
// middleware cannot enforce the run-lock on it — an unclassified verb is an
// unenforced hole, which is precisely how one gets added by a hurried change.
// Conformance red-gates this too; failing here first makes it a local red.
func TestCaps_EveryAdvertisedVerbIsClassified(t *testing.T) {
	for _, tr := range transports {
		if missing := mdriver.UnclassifiedVerbs(CapsFor(tr)); len(missing) > 0 {
			t.Errorf("[%s] advertised but unclassified (the middleware cannot enforce these): %v", tr, missing)
		}
	}
}

// Caps and dispatch read ONE table: whatever is advertised is supported, and
// whatever is not advertised is refused with exit 7. If these two could disagree,
// caps would be back to describing the binary.
func TestSupports_AgreesWithCaps(t *testing.T) {
	for _, tr := range transports {
		for _, av := range CapsFor(tr).Axes.Wired() {
			for _, verb := range av.Verbs {
				if !Supports(tr, av.Name, verb) {
					t.Errorf("[%s] caps advertises %s %s but Supports() says no", tr, av.Name, verb)
				}
			}
		}
	}
	// The remote transport is attach-only and has no source store: these are the
	// verbs it must NOT advertise, and must refuse.
	for _, unsupported := range [][2]string{
		{"lifecycle", "provision"}, {"lifecycle", "destroy"},
		{"sync", "list"}, {"sync", "push"}, {"exec", "load"},
	} {
		if Supports(mdriver.TransportRemote, unsupported[0], unsupported[1]) {
			t.Errorf("[remote] %s %s is not realizable over SSH — it must not be advertised",
				unsupported[0], unsupported[1])
		}
		if !Supports(mdriver.TransportDocker, unsupported[0], unsupported[1]) {
			t.Errorf("[docker] %s %s must still be supported", unsupported[0], unsupported[1])
		}
	}
}

func equal(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func contains(s []string, v string) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

// Contract 1.1 §4a: the limits block ships ONLY on the lane whose values were
// measured (docker/vehu, engine-capability report 2026-07-16) — an unmeasured
// lane advertises NO block rather than guessed numbers, and consumers keep
// their gated constants there.
func TestCapsFor_LimitsOnlyOnTheMeasuredLane(t *testing.T) {
	l := CapsFor(mdriver.TransportDocker).Limits
	if l == nil {
		t.Fatal("docker lane: limits absent — the measured lane must advertise its block")
	}
	if l.MaxString != 1048576 || l.MaxNodeValue != 16368 || l.MaxNodeValueKind != "region-config" {
		t.Errorf("docker limits core: got %+v", *l)
	}
	if l.MaxKeyBytes != 1019 || l.MaxSubscripts != 31 || l.EvalEnvelope != 32635 || l.LoadBodyBytes != 97275 {
		t.Errorf("docker limits lane values: got %+v", *l)
	}
	for k, want := range map[string]string{
		"oversize-string": "MAXSTRLEN", "oversize-node": "REC2BIG",
		"oversize-key": "GVSUBOFLOW", "too-many-subscripts": "MAXNRSUBSCRIPTS",
	} {
		if l.FaultMnemonics[k] != want {
			t.Errorf("faultMnemonics[%q] = %q, want %q", k, l.FaultMnemonics[k], want)
		}
	}
	for _, tr := range []string{mdriver.TransportLocal, mdriver.TransportRemote} {
		if CapsFor(tr).Limits != nil {
			t.Errorf("%s lane: limits present but UNMEASURED — a guessed block is worse than none", tr)
		}
	}
}
