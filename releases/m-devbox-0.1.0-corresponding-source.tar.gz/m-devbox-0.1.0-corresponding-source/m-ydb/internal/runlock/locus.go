// Package runlock derives the canonical LOCUS of the YottaDB instance a
// connection reaches — where the engine IS, never how it was dialed (run-lock
// design §R-9.3, normative; driver-contract §5.8).
//
// The driver is the single derivation authority (R-3): bash, m-cli, v-pkg and
// both drivers ask `meta runlock-path` rather than composing a key themselves, so
// no two lanes can "lock" different keys for one engine — which would be a SILENT
// failure of mutual exclusion.
//
// The ladder, for m-ydb's three routes:
//
//	docker  → `docker inspect` canonicalizes the selector (ID → NAME). NO engine call.
//	local   → the driver-derived $ydb_gbldir, realpath'd + hashed. NO engine call.
//	remote  → ask the LIVE engine its node fingerprint (SSH), then classify:
//	            the node is a local container → THAT CONTAINER'S DOCKER LOCUS
//	            the node is this host         → the LOCAL locus
//	            neither                       → foreign, keyed from the engine's ANSWER
//	unresolvable → NO KEY: refuse (RUN_LOCK_UNRESOLVED). Never a selector fallback.
//
// Why the lifecycle bootstrap problem does not arise: the verbs that cannot ask a
// stopped engine who it is (up/provision/destroy) are exactly the verbs that ride
// docker/local — whose selector already IS the canonical locus.
package runlock

import (
	"context"
	"fmt"
	"strings"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// The container resolver for THIS box is the SDK's own locator
// (mdriver.NewDockerLocator, wired in the main package's runLockDeps). Since SDK
// v0.8.1 (S2) it classifies its failures itself: a missing container is a clean
// no-match (self-canonical — `lifecycle provision` can key before the container
// exists), a DEAD DAEMON REFUSES (never a selector-spelled key — the silent split
// lock, defeat (n)), and a missing docker CLI is ErrNoDocker (the docker route
// refuses; MatchNode reads it as "no local containers", so a network route
// classifies cleanly foreign). m-ydb's interim LocalDocker hardening wrapper —
// which closed the dead-daemon hole host-side while the fix was upstream —
// retired with the v0.8.1 repin.

// Node is a live engine's answer to "who are you?" — taken from the engine and
// its host, never from the host-side config that dialed it. That is what unifies
// tunnels, DNS aliases, and differing spellings of one route onto one key.
type Node struct {
	// Name is the far-side node fingerprint (`uname -n`). For a container this
	// defaults to its short ID, which is what lets MatchNode map it back.
	Name string
	// GblDir is the engine's OWN global directory ($ZGBLDIR), realpath'd on the far
	// side — the interior, measured where it lives (engine-instance-path ADR: the
	// interior is DERIVED by the driver, never declared host-side).
	GblDir string
}

// Probe asks a live engine over the network route who it is. Only `remote` needs
// one; docker and local are self-canonical.
//
// It is a DRIVER-INTERNAL call — a plain method call on the transport session, not
// a re-entry into the CLI — so the dispatch check that re-derives per call cannot
// recurse through it (run-lock design amendment B; red-proven in the main package
// by TestGuard_NetworkRouteDoesNotReenterTheMiddleware).
type Probe func(ctx context.Context) (Node, error)

// Target is the connection whose locus we want: the resolved m-ydb transport plus
// the selector it carries.
type Target struct {
	Engine    string // "ydb"
	Transport string // local | docker | remote
	Container string // docker: the container selector (a name OR an id)
	GblDir    string // local: the $ydb_gbldir the driver already derives
}

// Deps are the resolution seams, injected so the ladder is unit-testable without
// a docker daemon, an engine, or a network.
type Deps struct {
	// Docker enumerates + canonicalizes local containers. A NIL Docker means "this
	// box runs no containers" — a KNOWN answer (the docker CLI is not installed),
	// which is a clean no-match, not a degraded resolver. A docker that IS present
	// but fails is an ERROR and must refuse (defeat (n)).
	Docker *mdriver.DockerLocator
	// Probe is the remote engine-ask. Required for the remote transport.
	Probe Probe
	// Hostname reports this host's node name, for the is-this-host classification
	// that closes the local + ssh-to-localhost alias.
	Hostname func() (string, error)
	// RealPath canonicalizes a host path (local route only; the remote route's
	// realpath is taken on the far side, by the Probe).
	RealPath func(string) (string, error)
}

// Resolve walks the R-9.3 ladder and returns the instance's canonical locus, or a
// *mdriver.RunLockError with code RUN_LOCK_UNRESOLVED.
//
// It NEVER falls back to the selector spelling. A selector names a route, and
// routes alias — a key built from one can never be collision-free against itself,
// which is the whole defect R-9 closes.
func Resolve(ctx context.Context, t Target, d Deps) (mdriver.Locus, error) {
	switch t.Transport {
	case mdriver.TransportDocker:
		return resolveDocker(ctx, t, d)
	case mdriver.TransportRemote:
		return resolveRemote(ctx, t, d)
	default:
		return resolveLocal(t, d)
	}
}

// resolveDocker: self-canonical. `docker inspect` maps an ID or a name onto the
// container's canonical NAME, and works on a stopped — or not-yet-created —
// container, so even `lifecycle provision` can key without an engine call.
func resolveDocker(ctx context.Context, t Target, d Deps) (mdriver.Locus, error) {
	if t.Container == "" {
		return mdriver.Locus{}, unresolved(t, fmt.Errorf("the docker transport names no container"))
	}
	if d.Docker == nil {
		// The docker route was selected on a box with no docker: we cannot name the
		// instance at all. (A missing docker means "no containers" only when we are
		// classifying a NETWORK route — here it means the route itself is broken.)
		return mdriver.Locus{}, unresolved(t, fmt.Errorf("the docker CLI is not available on this host"))
	}
	loc, err := d.Docker.Canonicalize(ctx, t.Container)
	if err != nil {
		return mdriver.Locus{}, unresolved(t, err)
	}
	return loc, nil
}

// resolveLocal: the interior the driver already derives ($ydb_gbldir), realpath'd
// so two spellings of one database are one key, and hashed so the interior never
// appears in a lock-file name.
func resolveLocal(t Target, d Deps) (mdriver.Locus, error) {
	if t.GblDir == "" {
		return mdriver.Locus{}, unresolved(t, fmt.Errorf(
			"no global directory: $ydb_gbldir is unset, so this connection does not name a database"))
	}
	resolved := t.GblDir
	if d.RealPath != nil {
		// A path that does not resolve (a database not created yet) is not fatal: the
		// spelling we were given still names the instance provision is about to make.
		if p, err := d.RealPath(t.GblDir); err == nil && p != "" {
			resolved = p
		}
	}
	return mdriver.Locus{Class: mdriver.LocusLocal, ID: mdriver.HashSelector(resolved)}, nil
}

// resolveRemote: the engine-ask. The key is built from what the ENGINE said, never
// from the host, port, tunnel or user we dialed — so every spelling of one
// instance unifies.
func resolveRemote(ctx context.Context, t Target, d Deps) (mdriver.Locus, error) {
	if d.Probe == nil {
		return mdriver.Locus{}, unresolved(t, fmt.Errorf("no engine probe wired for the remote transport"))
	}
	node, err := d.Probe(ctx)
	if err != nil {
		return mdriver.Locus{}, unresolved(t, err)
	}
	node.Name, node.GblDir = strings.TrimSpace(node.Name), strings.TrimSpace(node.GblDir)
	if node.Name == "" || node.GblDir == "" {
		// It answered, but not with an identity. A blank fingerprint identifies
		// nothing, and half a fingerprint would collide across instances on one host.
		return mdriver.Locus{}, unresolved(t, fmt.Errorf(
			"the engine reported an incomplete fingerprint (node %q, gbldir %q)", node.Name, node.GblDir))
	}

	// Is this engine a container on THIS box? Then it has a docker locus, and the
	// docker route to it must derive the SAME key (the R-9 unification). A nil
	// Docker means there are no containers here — a clean no-match.
	if d.Docker != nil {
		loc, ok, err := d.Docker.MatchNode(ctx, node.Name)
		if err != nil {
			// An enumeration failure is NOT a no-match: it means we cannot tell where
			// this engine is. Refusing here is what stops a degraded box from silently
			// splitting the key domain.
			return mdriver.Locus{}, unresolved(t, err)
		}
		if ok {
			return loc, nil
		}
	}

	// Is it this host? Then it is the same instance the local route reaches, and it
	// must derive the local key — this is the alias (`local` + `ssh localhost`) that
	// m-ydb's own transports create by construction.
	if d.Hostname != nil {
		if host, err := d.Hostname(); err == nil && host != "" && host == node.Name {
			return mdriver.Locus{Class: mdriver.LocusLocal, ID: mdriver.HashSelector(node.GblDir)}, nil
		}
	}

	// Genuinely foreign. The class name carries the design's scope boundary: flock is
	// per-kernel, so a foreign instance is serialized among lanes on THIS driving host
	// only (§R-9.8) — it is a lab/CI safety net, not a production concurrency control.
	return mdriver.Locus{
		Class: mdriver.LocusRemote,
		ID:    node.Name + "_" + mdriver.HashSelector(node.GblDir),
	}, nil
}

// unresolved renders the fail-closed refusal. It is the ONLY exit from a failed
// derivation: there is deliberately no path from here to a selector-spelled key.
func unresolved(t Target, cause error) error {
	engine := t.Engine
	if engine == "" {
		engine = "ydb"
	}
	return mdriver.UnresolvedRunLock(engine, cause)
}
