package runlock

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	mdriver "github.com/vista-forge/m-driver-sdk"
)

// The docker cases drive a STUB `docker` binary on PATH rather than a fake
// DockerRunner, because the distinction under test — a missing container (a clean
// no-match) vs. a dead daemon (an error) — is carried by the *exec.ExitError the
// real runner unwraps. A hand-made fake error cannot express it, so a fake would
// test the fake. This drives the true seam.
const dockerStub = `#!/bin/sh
if [ "$STUB_DOCKER_DAEMON" = "down" ]; then
  echo "Cannot connect to the Docker daemon at unix:///var/run/docker.sock." >&2
  exit 1
fi
cmd=$1; shift
case "$cmd" in
  version|info) echo "28.0.1" ;;
  inspect)
    for a in "$@"; do sel=$a; done
    case "$sel" in
      vehu|9c1f2a3b4d5e6f7012345678) echo "/vehu" ;;
      *) echo "Error: No such object: $sel" >&2; exit 1 ;;
    esac ;;
  ps) printf '9c1f2a3b4d5e6f7012345678\tvehu\t\n' ;;
  *) exit 2 ;;
esac
`

// stubDocker puts the stub on PATH and returns the locator m-ydb actually ships
// (the SDK's, since the v0.8.1 repin retired the LocalDocker hardening wrapper),
// so the tests exercise the production wiring.
func stubDocker(t *testing.T, daemon string) *mdriver.DockerLocator {
	t.Helper()
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "docker"), []byte(dockerStub), 0o755); err != nil {
		t.Fatalf("write docker stub: %v", err)
	}
	t.Setenv("PATH", dir+string(os.PathListSeparator)+os.Getenv("PATH"))
	t.Setenv("STUB_DOCKER_DAEMON", daemon)
	return mdriver.NewDockerLocator()
}

func hostname(n string) func() (string, error) {
	return func() (string, error) { return n, nil }
}

// realpath fakes symlink resolution: /link/m.gld is the same file as /real/m.gld.
func realpath(p string) (string, error) {
	return strings.Replace(p, "/link/", "/real/", 1), nil
}

func probing(n Node, err error) (Probe, *int) {
	calls := 0
	return func(context.Context) (Node, error) {
		calls++
		return n, err
	}, &calls
}

// The docker route is SELF-CANONICAL: no engine call, and an ID and a name for
// one container collapse onto ONE key (defeat (i)).
func TestResolve_Docker_CanonicalizesIDToName(t *testing.T) {
	d := stubDocker(t, "up")
	deps := Deps{Docker: d, Hostname: hostname("minty"), RealPath: realpath}

	byName, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "vehu"}, deps)
	if err != nil {
		t.Fatalf("resolve by name: %v", err)
	}
	byID, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "9c1f2a3b4d5e6f7012345678"}, deps)
	if err != nil {
		t.Fatalf("resolve by id: %v", err)
	}

	if byName.Key("ydb") != "ydb.docker.vehu" {
		t.Errorf("key = %q, want ydb.docker.vehu", byName.Key("ydb"))
	}
	if byName.Key("ydb") != byID.Key("ydb") {
		t.Errorf("an ID and a name for ONE container derived different keys: %q vs %q — they will not serialize",
			byName.Key("ydb"), byID.Key("ydb"))
	}
}

// A container that does not exist yet is still self-canonical: `lifecycle
// provision --container foo` is about to CREATE foo, and must be able to key.
func TestResolve_Docker_UncreatedContainerKeysOnItsName(t *testing.T) {
	loc, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "not-yet"},
		Deps{Docker: stubDocker(t, "up"), Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("an uncreated container must key (provision needs it): %v", err)
	}
	if loc.Key("ydb") != "ydb.docker.not-yet" {
		t.Errorf("key = %q, want ydb.docker.not-yet", loc.Key("ydb"))
	}
}

// A DEAD DAEMON is not a clean no-match. `docker inspect` exits non-zero either
// way, so a resolver that reads only the exit status would key a dead-daemon box
// on the RAW SELECTOR — and an `--container <id>` lane would then derive a
// different key from the `--container <name>` lane it is supposed to serialize
// against. That is defeat (i) reintroduced exactly when the box is degraded, which
// is defeat (n). It must REFUSE.
func TestResolve_Docker_DeadDaemonRefusesInsteadOfKeyingTheSelector(t *testing.T) {
	_, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "vehu"},
		Deps{Docker: stubDocker(t, "down"), Hostname: hostname("minty"), RealPath: realpath})
	assertUnresolved(t, err)
}

// The local route hashes the REALPATH of the derived gbldir, so two spellings of
// one database are one key, and the interior never appears in a lock-file name.
func TestResolve_Local_HashesRealpathOfGblDir(t *testing.T) {
	deps := Deps{Hostname: hostname("minty"), RealPath: realpath}

	direct, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "local", GblDir: "/real/m.gld"}, deps)
	if err != nil {
		t.Fatalf("resolve direct: %v", err)
	}
	viaLink, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "local", GblDir: "/link/m.gld"}, deps)
	if err != nil {
		t.Fatalf("resolve via symlink: %v", err)
	}

	want := "ydb.local." + mdriver.HashSelector("/real/m.gld")
	if direct.Key("ydb") != want {
		t.Errorf("key = %q, want %q", direct.Key("ydb"), want)
	}
	if direct.Key("ydb") != viaLink.Key("ydb") {
		t.Errorf("two spellings of ONE database derived different keys: %q vs %q",
			direct.Key("ydb"), viaLink.Key("ydb"))
	}
	if strings.Contains(direct.Key("ydb"), "m.gld") {
		t.Errorf("key %q leaks the interior — it must be hashed", direct.Key("ydb"))
	}
}

// No gbldir means the instance cannot be identified. Fail closed: guessing a key
// here is how two lanes end up "locking" different files for one engine.
func TestResolve_Local_NoGblDirRefuses(t *testing.T) {
	_, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "local"},
		Deps{Hostname: hostname("minty"), RealPath: realpath})
	assertUnresolved(t, err)
}

// THE ALIAS THE LADDER EXISTS TO CLOSE: `--transport local` and an SSH route to
// this same host are ONE instance, so they must derive ONE key — and the remote
// key is built from the ENGINE's answer, never the dialed spelling.
func TestResolve_Remote_SSHToThisHostDerivesTheLocalKey(t *testing.T) {
	probe, calls := probing(Node{Name: "minty", GblDir: "/real/m.gld"}, nil)

	remote, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: stubDocker(t, "up"), Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("resolve remote: %v", err)
	}
	local, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "local", GblDir: "/real/m.gld"},
		Deps{Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("resolve local: %v", err)
	}

	if remote.Key("ydb") != local.Key("ydb") {
		t.Errorf("ssh-to-localhost and local derive DIFFERENT keys (%q vs %q) — one instance, two locks",
			remote.Key("ydb"), local.Key("ydb"))
	}
	if *calls != 1 {
		t.Errorf("node probe called %d times, want exactly 1", *calls)
	}
}

// A network route whose engine turns out to be a LOCAL CONTAINER derives that
// container's docker locus — so `--container vehu` and an SSH route into vehu land
// on one lock (the R-9 unification, defeat (h)). m-ydb's remote transport exists
// precisely for "a FOIA vehu container reachable on :22 but not exec-able locally"
// (internal/transport.Config), so this alias is real, not hypothetical.
func TestResolve_Remote_EngineIsALocalContainer(t *testing.T) {
	d := stubDocker(t, "up")
	probe, _ := probing(Node{Name: "9c1f2a3b4d5e", GblDir: "/real/m.gld"}, nil) // a container's hostname IS its short id

	viaSSH, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: d, Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("resolve remote: %v", err)
	}
	viaDocker, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "vehu"},
		Deps{Docker: d, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("resolve docker: %v", err)
	}

	if viaSSH.Key("ydb") != viaDocker.Key("ydb") {
		t.Errorf("two routes to ONE container derive different keys: ssh=%q docker=%q",
			viaSSH.Key("ydb"), viaDocker.Key("ydb"))
	}
	if viaSSH.Key("ydb") != "ydb.docker.vehu" {
		t.Errorf("key = %q, want ydb.docker.vehu (the container's canonical locus)", viaSSH.Key("ydb"))
	}
}

// A genuinely foreign engine is keyed from its OWN reported fingerprint — so a
// tunnel, an IP and a DNS name for one host all unify.
func TestResolve_Remote_ForeignEngineKeysOnItsOwnFingerprint(t *testing.T) {
	probe, _ := probing(Node{Name: "va-vista-01", GblDir: "/home/vehu/g/mumps.gld"}, nil)
	loc, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: stubDocker(t, "up"), Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("resolve: %v", err)
	}

	want := "ydb.remote.va-vista-01_" + mdriver.HashSelector("/home/vehu/g/mumps.gld")
	if loc.Key("ydb") != want {
		t.Errorf("key = %q, want %q", loc.Key("ydb"), want)
	}
	if loc.Class != mdriver.LocusRemote {
		t.Errorf("class = %q, want remote — the foreign class IS the coverage boundary (§R-9.8)", loc.Class)
	}
}

// An unreachable engine cannot say who it is, so there is no key. Refuse — never
// fall back to the dialed spelling.
func TestResolve_Remote_UnreachableEngineRefuses(t *testing.T) {
	probe, _ := probing(Node{}, errors.New("ssh: connect to host dead-host port 22: no route to host"))
	_, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: stubDocker(t, "up"), Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	assertUnresolved(t, err)
}

// An engine that answers but names no node is just as unresolvable as one that
// does not answer: a blank (or half) fingerprint cannot identify an instance.
func TestResolve_Remote_BlankFingerprintRefuses(t *testing.T) {
	for _, tc := range []struct {
		name string
		node Node
	}{
		{"no node name", Node{GblDir: "/real/m.gld"}},
		{"no gbldir", Node{Name: "va-vista-01"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			probe, _ := probing(tc.node, nil)
			_, err := Resolve(context.Background(),
				Target{Engine: "ydb", Transport: "remote"},
				Deps{Docker: stubDocker(t, "up"), Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
			assertUnresolved(t, err)
		})
	}
}

// A container-enumeration ERROR while classifying a network route is not a
// no-match — it means we cannot tell WHERE this engine is. Refuse (defeat (n)).
func TestResolve_Remote_DockerEnumerationErrorRefuses(t *testing.T) {
	probe, _ := probing(Node{Name: "somewhere", GblDir: "/real/m.gld"}, nil)
	_, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: stubDocker(t, "down"), Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	assertUnresolved(t, err)
}

// A box with NO docker installed runs no containers — that is a KNOWN answer (a
// clean no-match), not a degraded resolver, so an SSH route to a foreign host
// still resolves. Deps.Docker == nil is how the wiring says "no containers here".
func TestResolve_Remote_NoDockerOnThisBoxIsACleanNoMatch(t *testing.T) {
	probe, _ := probing(Node{Name: "va-vista-01", GblDir: "/g/mumps.gld"}, nil)
	loc, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("a docker-less box must still resolve a foreign SSH route: %v", err)
	}
	if loc.Class != mdriver.LocusRemote {
		t.Errorf("class = %q, want remote", loc.Class)
	}
}

// A box with NO docker CLI at all (SDK ErrNoDocker, since v0.8.1): the docker
// route refuses — there is no instance for it to name — while a network route to
// a foreign host still classifies cleanly instead of refusing. This is the
// behavior m-ydb's retired LocalDocker nil-wrapper used to provide; the pin here
// keeps the SDK honest about carrying it.
func TestResolve_AbsentDockerCLI_DockerRouteRefuses_RemoteClassifiesForeign(t *testing.T) {
	t.Setenv("PATH", t.TempDir()) // no docker binary anywhere
	d := mdriver.NewDockerLocator()

	_, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "docker", Container: "vehu"},
		Deps{Docker: d, Hostname: hostname("minty"), RealPath: realpath})
	assertUnresolved(t, err)

	probe, _ := probing(Node{Name: "va-vista-01", GblDir: "/g/mumps.gld"}, nil)
	loc, err := Resolve(context.Background(),
		Target{Engine: "ydb", Transport: "remote"},
		Deps{Docker: d, Probe: probe, Hostname: hostname("minty"), RealPath: realpath})
	if err != nil {
		t.Fatalf("a docker-less box must still resolve a foreign SSH route: %v", err)
	}
	if loc.Class != mdriver.LocusRemote {
		t.Errorf("class = %q, want remote", loc.Class)
	}
}

func assertUnresolved(t *testing.T, err error) {
	t.Helper()
	if err == nil {
		t.Fatal("want a refusal, got a key — the resolver GUESSED instead of refusing")
	}
	var rl *mdriver.RunLockError
	if !errors.As(err, &rl) {
		t.Fatalf("error %v is not a *mdriver.RunLockError — a consumer cannot branch on it", err)
	}
	if rl.Code != mdriver.CodeRunLockUnresolved {
		t.Errorf("code = %q, want %q", rl.Code, mdriver.CodeRunLockUnresolved)
	}
	if rl.Exit != mdriver.ExitRunLockRefused {
		t.Errorf("exit = %d, want %d", rl.Exit, mdriver.ExitRunLockRefused)
	}
}
