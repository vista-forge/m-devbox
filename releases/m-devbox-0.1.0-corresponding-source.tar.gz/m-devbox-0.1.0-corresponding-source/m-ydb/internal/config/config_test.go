package config

import (
	"context"
	"testing"
)

func TestResolve_FillsFromYDBEnv(t *testing.T) {
	env := map[string]string{
		"ydb_dist":     "/opt/yottadb",
		"ydb_gbldir":   "/data/m.gld",
		"ydb_routines": "/data/r /opt/yottadb",
	}
	c := &Conn{Transport: "local"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Dist != "/opt/yottadb" || c.GblDir != "/data/m.gld" || c.Routines != "/data/r /opt/yottadb" {
		t.Errorf("resolve = %+v, want filled from ydb_* env", c)
	}
}

func TestResolve_DoesNotOverrideExplicit(t *testing.T) {
	env := map[string]string{"ydb_dist": "/from/env", "ydb_gbldir": "/from/env.gld"}
	c := &Conn{Transport: "local", Dist: "/explicit"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Dist != "/explicit" {
		t.Errorf("Dist = %q, explicit flag must win over env", c.Dist)
	}
	if c.GblDir != "/from/env.gld" {
		t.Errorf("GblDir = %q, want filled from env when unset", c.GblDir)
	}
}

func TestResolve_GTMFallback(t *testing.T) {
	// GT.M users (and older YottaDB) export gtm_* — accept them when ydb_* are absent.
	env := map[string]string{"gtm_dist": "/usr/lib/fis-gtm", "gtmgbldir": "/data/g.gld"}
	c := &Conn{Transport: "local"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Dist != "/usr/lib/fis-gtm" || c.GblDir != "/data/g.gld" {
		t.Errorf("resolve = %+v, want gtm_* fallback", c)
	}
}

func TestResolve_MYDBEnvWinsOverYDB(t *testing.T) {
	// Non-docker: M_YDB_* is the first-precedence env default, above ydb_*/gtm_*.
	env := map[string]string{
		"M_YDB_ROUTINES": "/mydb/r",
		"ydb_routines":   "/ydb/r",
	}
	c := &Conn{Transport: "local"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Routines != "/mydb/r" {
		t.Errorf("Routines = %q, want M_YDB_ROUTINES to win over ydb_routines", c.Routines)
	}
}

func TestResolve_DockerIgnoresHostEnv(t *testing.T) {
	// Docker transport is authoritative-from-the-container: NO host env default
	// (M_YDB_*/ydb_*/gtm_*) is applied, so a vehu-pinned M_YDB_ROUTINES can't leak
	// onto another container and abort its suites 0/0 (the m-test-engine regression).
	env := map[string]string{
		"M_YDB_DIST":     "/home/vehu/lib/gtm",
		"M_YDB_GBLDIR":   "/home/vehu/g/vehu.gld",
		"M_YDB_ROUTINES": "/home/vehu/p/* /home/vehu/r",
		"ydb_routines":   "/ydb/r",
	}
	c := &Conn{Transport: "docker", Container: "m-test-engine"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Dist != "" || c.GblDir != "" || c.Routines != "" {
		t.Errorf("docker resolve = %+v, want dist/gbldir/routines EMPTY (container profile is authoritative)", c)
	}
}

func TestResolve_DockerHonorsExplicitFlag(t *testing.T) {
	// An explicit --routines still wins on docker (it's set on the field before
	// Resolve); only the host ENV defaults are suppressed.
	env := map[string]string{"M_YDB_ROUTINES": "/home/vehu/p/*"}
	c := &Conn{Transport: "docker", Container: "c", Routines: "/explicit/in/container"}
	c.Resolve(func(k string) string { return env[k] })

	if c.Routines != "/explicit/in/container" {
		t.Errorf("Routines = %q, explicit flag must survive on docker", c.Routines)
	}
}

func TestValidate_DockerNeedsContainer(t *testing.T) {
	if err := (&Conn{Transport: "docker"}).Validate(); err == nil {
		t.Error("docker transport without a container must be a validation error")
	}
	if err := (&Conn{Transport: "docker", Container: "m-test-engine"}).Validate(); err != nil {
		t.Errorf("docker with container should validate: %v", err)
	}
	if err := (&Conn{Transport: "local"}).Validate(); err != nil {
		t.Errorf("local should validate without a container: %v", err)
	}
}

func TestValidate_RemoteNeedsHost(t *testing.T) {
	if err := (&Conn{Transport: "remote"}).Validate(); err == nil {
		t.Error("remote transport without a host must be a validation error")
	}
	if err := (&Conn{Transport: "remote", Host: "vehu.local"}).Validate(); err != nil {
		t.Errorf("remote with a host should validate: %v", err)
	}
}

func TestTransportConfig_Maps(t *testing.T) {
	c := &Conn{Transport: "docker", Container: "m-test-engine", Dist: "/opt/yottadb"}
	tc := c.TransportConfig()
	if tc.Transport != "docker" || tc.Container != "m-test-engine" || tc.Dist != "/opt/yottadb" {
		t.Errorf("TransportConfig = %+v", tc)
	}
}

func TestTransportConfig_MapsRemote(t *testing.T) {
	c := &Conn{Transport: "remote", Host: "h", Port: 2222, User: "u", Identity: "/k", EnvFile: "/env"}
	tc := c.TransportConfig()
	if tc.Transport != "remote" || tc.Host != "h" || tc.Port != 2222 ||
		tc.User != "u" || tc.Identity != "/k" || tc.EnvFile != "/env" {
		t.Errorf("TransportConfig = %+v", tc)
	}
}

// --- managed staging (--stage-dir) -----------------------------------------

func TestStagePath_JoinsPrimarySourceDir(t *testing.T) {
	c := &Conn{Transport: "local", Routines: "/data/p* /data/r", StageDir: "mtest-abc"}
	got, err := c.StagePath(context.Background())
	if err != nil {
		t.Fatalf("StagePath: %v", err)
	}
	if got != "/data/p/mtest-abc" {
		t.Errorf("stage path = %q, want /data/p/mtest-abc", got)
	}
}

func TestStagePath_RefusesBadNames(t *testing.T) {
	for _, bad := range []string{"", "zzt1", "mtest-a/b", "mtest-.."} {
		c := &Conn{Transport: "local", Routines: "/data/p", StageDir: bad}
		if _, err := c.StagePath(context.Background()); err == nil {
			t.Errorf("StagePath(%q) should refuse", bad)
		}
	}
}

func TestEnsureStageRoutines_PrependsOnceAndIsIdempotent(t *testing.T) {
	c := &Conn{Transport: "local", Routines: "/data/p* /data/r", StageDir: "mtest-abc"}
	for i := 0; i < 2; i++ {
		if err := c.EnsureStageRoutines(context.Background()); err != nil {
			t.Fatalf("EnsureStageRoutines #%d: %v", i+1, err)
		}
	}
	want := "/data/p/mtest-abc /data/p* /data/r"
	if c.Routines != want {
		t.Errorf("routines = %q, want %q", c.Routines, want)
	}
	// The prepended stage path is what the source store writes into (dirs[0])
	// and what the session layers first onto $ZROUTINES.
	if dirs := c.SourceDirs(); len(dirs) == 0 || dirs[0] != "/data/p/mtest-abc" {
		t.Errorf("SourceDirs()[0] = %v, want the stage path first", dirs)
	}
}

func TestEnsureStageRoutines_NoStageDirIsNoop(t *testing.T) {
	c := &Conn{Transport: "local", Routines: "/data/p"}
	if err := c.EnsureStageRoutines(context.Background()); err != nil {
		t.Fatalf("EnsureStageRoutines: %v", err)
	}
	if c.Routines != "/data/p" {
		t.Errorf("routines mutated to %q on a no-stage conn", c.Routines)
	}
}

func TestEnsureStageRoutines_NeedsAResolvableSourceDir(t *testing.T) {
	// PrimarySourceDir → SourceDirs → ResolveEnv reads the REAL process env, so
	// clear every routine-source var it consults (the dev/CI shell may export
	// M_YDB_ROUTINES=/home/vehu/p) to make "no resolvable source dir" deterministic.
	for _, k := range []string{"M_YDB_ROUTINES", "ydb_routines", "gtmroutines"} {
		t.Setenv(k, "")
	}
	c := &Conn{Transport: "local", Routines: "", StageDir: "mtest-abc"}
	if err := c.EnsureStageRoutines(context.Background()); err == nil {
		t.Error("want an error when no source dir is resolvable for --stage-dir")
	}
}
