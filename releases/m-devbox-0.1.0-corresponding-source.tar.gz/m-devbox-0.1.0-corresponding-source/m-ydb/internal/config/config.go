// Package config resolves the m-ydb connection (transport + YottaDB paths or a
// container) from flags and environment. m-cli passes the active [instance]
// profile as M_YDB_* env + non-secret flags (driver-contract §3); the blob is
// opaque to m-cli — only this driver interprets the YottaDB fields. As a
// convenience for humans, an unset path falls back to the standard ydb_*/gtm_*
// environment a YottaDB shell already exports.
package config

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/vista-forge/m-ydb/internal/mirror"
	"github.com/vista-forge/m-ydb/internal/source"
	"github.com/vista-forge/m-ydb/internal/transport"
)

// Conn is the connection + behavior flag set, embedded in the root CLI and bound
// so every command receives a *config.Conn. Flags win over M_YDB_* env, which in
// turn wins over the standard ydb_*/gtm_* env — the path fields resolve that
// chain in Resolve (not via Kong env tags) so it can be transport-gated: docker
// takes dist/gbldir/routines from the container's own profile, never a host env.
type Conn struct {
	Transport string `env:"M_YDB_TRANSPORT" enum:"local,docker,remote" default:"local" help:"Engine transport: local (native install) | docker (a container we manage) | remote (SSH to a host running YottaDB)."`
	// Dist/GblDir/Routines: the M_YDB_* env defaults are read in Resolve (NOT via
	// a Kong env tag) so they can be transport-gated — for docker transport the
	// container's own login profile is authoritative and a host M_YDB_* (which
	// describes a DIFFERENT engine, e.g. vehu's /home/vehu paths) must not leak
	// onto another container. An explicit --ydb-dist/--gbldir/--routines flag
	// still wins on every transport.
	Dist      string `name:"ydb-dist" help:"$ydb_dist — directory holding the yottadb/mupip/gde binaries (local + remote; docker uses the container profile). M_YDB_DIST env applies to non-docker only." placeholder:"DIR"`
	GblDir    string `name:"gbldir" help:"$ydb_gbldir — the .gld global directory (docker uses the container profile). M_YDB_GBLDIR env applies to non-docker only." placeholder:"PATH"`
	Routines  string `name:"routines" help:"$ydb_routines — routine source/object search path (docker uses the container profile). M_YDB_ROUTINES env applies to non-docker only." placeholder:"PATH"`
	Container string `env:"M_YDB_CONTAINER" help:"docker transport: the container name to exec into." placeholder:"NAME"`
	StageDir  string `name:"stage-dir" env:"M_YDB_STAGE_DIR" help:"Run-scoped managed staging subdir (mtest-<token>) under the primary routine source dir: exec load stages there (created on write) and the runtime routine path prepends it, so a leaked stage can never shadow the flat patch dir; exec unstage removes it, exec sweep retires stale ones." placeholder:"MTEST-DIR"`
	Chset     string `env:"M_YDB_CHSET" enum:"m,M,utf-8,UTF-8,utf8,UTF8," default:"" help:"Engine charset: m (byte mode — one char == one byte, exports ydb_chset=M) or utf-8. Empty inherits the ambient $ydb_chset." placeholder:"CHSET"`

	// remote (SSH) transport — reach a filesystem YottaDB on another host (e.g. a
	// FOIA `vehu` server). The same yottadb invocation is wrapped in `ssh`; the
	// engine env is sourced from EnvFile on the far side. SSH is a host-shell
	// transport, not a YottaDB network engine API.
	Host     string `env:"M_YDB_HOST" help:"remote (SSH) transport: target host." placeholder:"HOST"`
	Port     int    `env:"M_YDB_PORT" help:"remote (SSH) transport: ssh port (default 22)." placeholder:"PORT"`
	User     string `env:"M_YDB_USER" help:"remote (SSH) transport: ssh user." placeholder:"USER"`
	Identity string `name:"identity" env:"M_YDB_IDENTITY" help:"remote (SSH) transport: ssh identity file (-i)." placeholder:"FILE"`
	EnvFile  string `name:"env-file" env:"M_YDB_ENVFILE" help:"remote (SSH) transport: remote file to source for the YottaDB env (e.g. /home/vehu/etc/env)." placeholder:"PATH"`

	// The per-engine run bracket (driver-contract §5.8). Both flags are honored by
	// the derivation verbs (meta runlock-path/runlock-status) AND by the dispatch
	// check — if they were not, the bracket and the check would read different lock
	// files and every in-bracket call would refuse.
	//
	// RunLockToken has an env fallback (M_RUN_LOCK_TOKEN) because a bracket exports
	// it to its whole process subtree, which is what carries a bash-wrapped chain
	// (`m runlock hold … -- ./script.sh`). The explicit flag is the LOUD channel and
	// wins — Kong resolves a set flag over an env default.
	RunLockToken string `name:"run-lock" env:"M_RUN_LOCK_TOKEN" help:"Prove this call belongs to a live run bracket (driver-contract §5.8). Mutating and read verbs are REFUSED without it." placeholder:"TOKEN"`
	RunLockDir   string `name:"run-lock-dir" help:"Override the run-lock home (default ~/data/vista-forge/run-lock). TESTS AND FIXTURES ONLY: a real run that sets it locks a file no other lane looks at." placeholder:"DIR"`

	// sync axis (M2) behavior flags.
	Mirror string `env:"M_YDB_MIRROR" default:".m-cache" help:"Mirror root directory for the sync axis (routine source ↔ instance)."`
	Filter string `help:"Glob over the bare routine name (extension-insensitive), e.g. 'DG*'." placeholder:"GLOB"`
	DryRun bool   `name:"dry-run" help:"Plan only; never write to the mirror or the instance."`

	// stagePath caches the resolved <primary>/<StageDir> once computed (a
	// docker resolution may cost a container probe). Not a flag.
	stagePath string `kong:"-"`
}

// ydbChset maps the user-facing charset token to YottaDB's $ydb_chset value.
// Unknown/empty tokens yield "" (leave the engine's ambient default untouched).
func ydbChset(tok string) string {
	switch tok {
	case "m", "M":
		return "M"
	case "utf-8", "UTF-8", "utf8", "UTF8":
		return "UTF-8"
	default:
		return ""
	}
}

// Resolve fills unset path fields from the M_YDB_* env, then the standard
// YottaDB (ydb_*) environment, falling back to the GT.M (gtm_*) names. An
// explicit flag (already set on the field before Resolve) always wins.
//
// DOCKER transport is authoritative-from-the-container: session env() returns
// nil for docker and wrap() runs a `bash -lc` login shell that sources the
// container's own engine profile (ydb_chset-derived $ydb_routines, its $ydb_gbldir,
// its dist). A host M_YDB_*/ydb_*/gtm_* value describes a DIFFERENT engine (the
// workspace default is vehu's /home/vehu/* paths) and, injected onto another
// container (e.g. m-test-engine), makes staged routines resolve to the wrong dir
// and every suite abort 0/0. So for docker we read NONE of these env defaults —
// only an explicit --ydb-dist/--gbldir/--routines flag survives. getenv is
// injected for testability (pass os.Getenv in production).
func (c *Conn) Resolve(getenv func(string) string) {
	if c.Transport == transportDocker {
		return
	}
	fill := func(dst *string, keys ...string) {
		if *dst != "" {
			return
		}
		for _, k := range keys {
			if v := getenv(k); v != "" {
				*dst = v
				return
			}
		}
	}
	fill(&c.Dist, "M_YDB_DIST", "ydb_dist", "gtm_dist")
	fill(&c.GblDir, "M_YDB_GBLDIR", "ydb_gbldir", "gtmgbldir")
	fill(&c.Routines, "M_YDB_ROUTINES", "ydb_routines", "gtmroutines")
}

// ResolveEnv fills unset paths from the real process environment. Commands that
// touch the engine call it before reading paths or building a session.
func (c *Conn) ResolveEnv() { c.Resolve(os.Getenv) }

// Validate checks the connection is usable for engine-bound work.
func (c *Conn) Validate() error {
	if c.Transport == "docker" && c.Container == "" {
		return fmt.Errorf("docker transport needs a container: pass --container or M_YDB_CONTAINER")
	}
	if c.Transport == transportRemote && c.Host == "" {
		return fmt.Errorf("remote transport needs a host: pass --host or M_YDB_HOST")
	}
	return nil
}

// TransportConfig maps the connection onto the transport layer's config.
func (c *Conn) TransportConfig() transport.Config {
	return transport.Config{
		Transport: c.Transport,
		Dist:      c.Dist,
		GblDir:    c.GblDir,
		Routines:  c.Routines,
		Container: c.Container,
		Chset:     ydbChset(c.Chset),
		Host:      c.Host,
		Port:      c.Port,
		User:      c.User,
		Identity:  c.Identity,
		EnvFile:   c.EnvFile,
	}
}

// NewSession builds the YottaDB session transport for this connection,
// resolving paths from the environment first.
func (c *Conn) NewSession() *transport.Session {
	c.ResolveEnv()
	return transport.NewSession(c.TransportConfig(), nil)
}

// Layout is the mirror layout for the sync axis (the --mirror root).
func (c *Conn) Layout() mirror.Layout {
	return mirror.Layout{Root: c.Mirror}
}

// SourceDirs resolves the routine source directories from $ydb_routines (after
// filling unset paths from the environment).
func (c *Conn) SourceDirs() []string {
	c.ResolveEnv()
	return source.ParseRoutinesDirs(c.Routines)
}

// PrimarySourceDir resolves the engine's primary routine source dir (the flat
// patch dir writes normally target): the first $ydb_routines source dir, or —
// docker with no host-pinned path — the first dir of the container's own
// $ZROUTINES. It is the parent the managed staging namespace (mtest-*) lives
// under.
func (c *Conn) PrimarySourceDir(ctx context.Context) (string, error) {
	dirs := c.SourceDirs()
	if len(dirs) == 0 && c.Transport == transportDocker && c.Container != "" {
		if cr, err := c.NewSession().ContainerRoutines(ctx); err == nil {
			c.Routines = strings.TrimSpace(cr)
			dirs = source.ParseRoutinesDirs(c.Routines)
		}
	}
	if len(dirs) == 0 {
		return "", fmt.Errorf("no routine source directory: set --routines or $ydb_routines")
	}
	return dirs[0], nil
}

// StagePath resolves the absolute managed staging directory for this
// connection: <primary source dir>/<StageDir>. It refuses a StageDir outside
// the mtest-* namespace (source.ValidStageName) so every later rm -rf is
// confined by construction.
func (c *Conn) StagePath(ctx context.Context) (string, error) {
	if !source.ValidStageName(c.StageDir) {
		return "", fmt.Errorf("invalid --stage-dir %q: want %s<token> (single path component)", c.StageDir, source.StagePrefix)
	}
	if c.stagePath != "" {
		return c.stagePath, nil
	}
	primary, err := c.PrimarySourceDir(ctx)
	if err != nil {
		return "", fmt.Errorf("--stage-dir needs a resolvable source dir: %w", err)
	}
	c.stagePath = primary + "/" + c.StageDir
	return c.stagePath, nil
}

// EnsureStageRoutines makes the managed staging dir the run's FIRST routine
// location: it prepends <primary>/<StageDir> to c.Routines, which every
// downstream consumer follows — the source store's write target (dirs[0], so
// exec load stages into the subdir) and the session's runtime $ZROUTINES
// layering (so staged routines resolve ahead of the flat patch dir). A conn
// with no StageDir is untouched; the prepend is idempotent. Engine-executing
// commands (exec load/run/eval/script) call it before building a session.
func (c *Conn) EnsureStageRoutines(ctx context.Context) error {
	if c.StageDir == "" {
		return nil
	}
	sp, err := c.StagePath(ctx)
	if err != nil {
		return err
	}
	if c.Routines == sp || strings.HasPrefix(c.Routines, sp+" ") {
		return nil // already prepended
	}
	c.Routines = sp + " " + c.Routines
	return nil
}

// SourceStore builds the engine-side routine source store for the sync axis:
// a host-filesystem store for local, or a container store (over the session) for
// docker. It fails (usable for an exit-2) when no source directory is resolvable
// or the docker container is missing.
func (c *Conn) SourceStore() (source.Store, error) {
	if c.Transport == transportRemote {
		return nil, fmt.Errorf("sync over the remote (SSH) transport is not yet supported")
	}
	dirs := c.SourceDirs()
	if len(dirs) == 0 && c.Transport == transportDocker && c.Container != "" {
		// The host pinned no routine source path; a real VistA image keeps it in
		// the container's own engine profile (vehu), so ask the engine for its
		// $ZROUTINES rather than failing. Best-effort: a probe error leaves dirs
		// empty and falls through to the clear "set --routines" message below.
		if cr, err := c.NewSession().ContainerRoutines(context.Background()); err == nil {
			dirs = source.ParseRoutinesDirs(cr)
		}
	}
	if len(dirs) == 0 {
		return nil, fmt.Errorf("no routine source directory: set --routines or $ydb_routines")
	}
	if c.Transport == transportDocker {
		if c.Container == "" {
			return nil, fmt.Errorf("docker transport needs a container: pass --container or M_YDB_CONTAINER")
		}
		return source.NewShellStore(c.NewSession(), dirs), nil
	}
	return source.NewFileStore(dirs), nil
}

const (
	transportDocker = "docker"
	transportRemote = "remote"
)
