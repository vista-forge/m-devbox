package source

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func writeFile(t *testing.T, dir, name, body string) {
	t.Helper()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, name), []byte(body), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestFileStore_ListAndRead(t *testing.T) {
	d1 := filepath.Join(t.TempDir(), "src1")
	d2 := filepath.Join(t.TempDir(), "src2")
	writeFile(t, d1, "FOO.m", "FOO ;one\n quit\n")
	writeFile(t, d1, "BAR.m", "BAR\n")
	writeFile(t, d1, "notes.txt", "ignored\n") // non-.m ignored
	writeFile(t, d2, "BAZ.m", "BAZ\n")
	writeFile(t, d2, "FOO.m", "FOO ;shadowed\n") // earlier dir wins

	st := NewFileStore([]string{d1, d2})
	rts, err := st.List(context.Background())
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	names := map[string]bool{}
	for _, r := range rts {
		names[r.Name] = true
		if r.TS == "" {
			t.Errorf("%s has empty TS", r.Name)
		}
	}
	for _, want := range []string{"FOO.m", "BAR.m", "BAZ.m"} {
		if !names[want] {
			t.Errorf("missing %s in %v", want, names)
		}
	}
	if names["notes.txt"] {
		t.Error("non-.m file listed")
	}
	if len(rts) != 3 {
		t.Errorf("count = %d, want 3 (first-dir-wins on FOO.m)", len(rts))
	}

	// Read resolves through the search path, earlier dir winning.
	b, err := st.Read(context.Background(), "FOO.m")
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(b) != "FOO ;one\n quit\n" {
		t.Errorf("read FOO.m = %q, want the src1 copy", b)
	}
	if _, err := st.Read(context.Background(), "NOPE.m"); !os.IsNotExist(err) {
		t.Errorf("read missing: err = %v, want IsNotExist", err)
	}
}

func TestFileStore_WriteAndRemove(t *testing.T) {
	d0 := filepath.Join(t.TempDir(), "primary")
	d1 := filepath.Join(t.TempDir(), "secondary")
	writeFile(t, d1, "OLD.m", "OLD\n")
	st := NewFileStore([]string{d0, d1})
	ctx := context.Background()

	// Write lands in the primary (first) dir and returns a non-empty TS.
	rt, err := st.Write(ctx, "NEW.m", []byte("NEW ;body\n quit\n"))
	if err != nil {
		t.Fatalf("write: %v", err)
	}
	if rt.Name != "NEW.m" || rt.TS == "" {
		t.Errorf("write result = %+v", rt)
	}
	got, err := os.ReadFile(filepath.Join(d0, "NEW.m"))
	if err != nil || string(got) != "NEW ;body\n quit\n" {
		t.Fatalf("primary write = %q err=%v", got, err)
	}

	// Read resolves the freshly written routine.
	if b, err := st.Read(ctx, "NEW.m"); err != nil || string(b) != "NEW ;body\n quit\n" {
		t.Fatalf("read back = %q err=%v", b, err)
	}

	// Remove deletes from the primary dir.
	writeFile(t, d0, "GONE.m", "GONE\n")
	if err := st.Remove(ctx, "GONE.m"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if _, err := os.Stat(filepath.Join(d0, "GONE.m")); !os.IsNotExist(err) {
		t.Error("GONE.m still present after remove")
	}
	// Removing a name absent from the primary dir is a no-op (not an error).
	if err := st.Remove(ctx, "OLD.m"); err != nil {
		t.Errorf("remove of non-primary routine = %v, want nil (no-op)", err)
	}
}

// TestRoutineNameGrammar pins the filename grammar the stores accept, through
// the public Read surface: a rejected name gets the "invalid routine name"
// error; an accepted (but absent) name gets fs.ErrNotExist. The `_X.m` rows
// are the PR-21 regression: `_DT.m` IS the on-disk form of the %-routine %DT
// (YottaDB resolves %-routines from underscore-prefixed files), and List
// already returns such files — a store that enumerates a file it then refuses
// to read broke `m lib verify` on every FileMan-bearing engine (measured
// 2026-07-22: `read _DT.m: source: invalid routine name "_DT.m"`).
func TestRoutineNameGrammar(t *testing.T) {
	st := NewFileStore([]string{t.TempDir()})
	ctx := context.Background()
	cases := []struct {
		name  string
		valid bool
	}{
		{"FOO.m", true},
		{"foo9.m", true},
		{"%DT.m", true},   // literal %-name (List would return it if present)
		{"_DT.m", true},   // the on-disk %-routine form — PR-21
		{"_zosv.m", true}, // lower-case %-routine form
		{"_.m", false},    // bare marker with no name
		{"9FOO.m", false}, // digit first
		{"F_OO.m", false}, // underscore only leads
		{"FOO.o", false},  // not source
		{"FOO", false},    // no extension
		{"../X.m", false}, // path escape
		{"", false},
	}
	for _, c := range cases {
		_, err := st.Read(ctx, c.name)
		accepted := os.IsNotExist(err) // an accepted-but-absent name misses; a rejected one errors differently
		if c.valid && !accepted {
			t.Errorf("Read(%q) = %v, want fs.ErrNotExist (name should be accepted)", c.name, err)
		}
		if !c.valid && accepted {
			t.Errorf("Read(%q) = %v, want an invalid-name rejection", c.name, err)
		}
	}
}

// TestFileStore_PercentRoutineRoundTrip is the PR-21 end-to-end pin on the
// local store: a %-routine file (`_DT.m`) writes, lists, reads and removes
// exactly like any other routine.
func TestFileStore_PercentRoutineRoundTrip(t *testing.T) {
	d := filepath.Join(t.TempDir(), "r")
	st := NewFileStore([]string{d})
	ctx := context.Background()

	if _, err := st.Write(ctx, "_DT.m", []byte("%DT ;fileman date\n quit\n")); err != nil {
		t.Fatalf("write _DT.m: %v", err)
	}
	rts, err := st.List(ctx)
	if err != nil || len(rts) != 1 || rts[0].Name != "_DT.m" {
		t.Fatalf("list = %+v err=%v, want the one _DT.m row", rts, err)
	}
	if b, err := st.Read(ctx, "_DT.m"); err != nil || string(b) != "%DT ;fileman date\n quit\n" {
		t.Fatalf("read back = %q err=%v", b, err)
	}
	if err := st.Remove(ctx, "_DT.m"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if _, err := os.Stat(filepath.Join(d, "_DT.m")); !os.IsNotExist(err) {
		t.Error("_DT.m still present after remove")
	}
}

// fakeSh records the scripts it runs and replays canned stdout keyed by a
// substring match, so ShellStore can be unit-tested without a container.
type fakeSh struct {
	responses []struct{ contains, stdout string }
	capture   *string // if set, records the last script run
}

func (f *fakeSh) Sh(_ context.Context, script string) (string, int, error) {
	if f.capture != nil {
		*f.capture = script
	}
	for _, r := range f.responses {
		if contains(script, r.contains) {
			return r.stdout, 0, nil
		}
	}
	return "", 0, nil
}

func contains(s, sub string) bool {
	return len(sub) == 0 || (len(s) >= len(sub) && indexOf(s, sub) >= 0)
}
func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}

func TestShellStore_ListParsesTabbedOutput(t *testing.T) {
	sh := &fakeSh{responses: []struct{ contains, stdout string }{
		{"stat", "FOO.m\t1700000000\nBAR.m\t1700000005\nFOO.m\t1699999999\n"},
	}}
	st := NewShellStore(sh, []string{"/data/r"})
	rts, err := st.List(context.Background())
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if len(rts) != 2 {
		t.Fatalf("count = %d, want 2 (first FOO.m wins)", len(rts))
	}
	byName := map[string]string{}
	for _, r := range rts {
		byName[r.Name] = r.TS
	}
	if byName["FOO.m"] != "1700000000" {
		t.Errorf("FOO.m TS = %q, want first occurrence 1700000000", byName["FOO.m"])
	}
	if byName["BAR.m"] != "1700000005" {
		t.Errorf("BAR.m TS = %q", byName["BAR.m"])
	}
}

func TestShellStore_Read(t *testing.T) {
	sh := &fakeSh{responses: []struct{ contains, stdout string }{
		{"cat", "FOO ;body\n quit\n"},
	}}
	st := NewShellStore(sh, []string{"/data/r"})
	b, err := st.Read(context.Background(), "FOO.m")
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(b) != "FOO ;body\n quit\n" {
		t.Errorf("read = %q", b)
	}
}

func TestShellStore_WriteEncodesAndReturnsTS(t *testing.T) {
	var gotScript string
	sh := &fakeSh{responses: []struct{ contains, stdout string }{
		{"base64 -d", "1700000123\n"}, // write script ends by stat-ing the new file
	}}
	sh.capture = &gotScript
	st := NewShellStore(sh, []string{"/data/r"})
	rt, err := st.Write(context.Background(), "FOO.m", []byte("FOO\n quit\n"))
	if err != nil {
		t.Fatalf("write: %v", err)
	}
	if rt.Name != "FOO.m" || rt.TS != "1700000123" {
		t.Errorf("write result = %+v, want {FOO.m 1700000123}", rt)
	}
	// Content must be base64-encoded into the script (no raw newlines / quoting hazards).
	if !contains(gotScript, "base64 -d") || contains(gotScript, "FOO\n quit") {
		t.Errorf("script did not base64-encode content: %q", gotScript)
	}
}

func TestShellStore_Remove(t *testing.T) {
	var gotScript string
	sh := &fakeSh{}
	sh.capture = &gotScript
	st := NewShellStore(sh, []string{"/data/r"})
	if err := st.Remove(context.Background(), "FOO.m"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if !contains(gotScript, "rm -f") || !contains(gotScript, "/data/r/FOO.m") {
		t.Errorf("remove script = %q", gotScript)
	}
}

func TestParseRoutinesDirs(t *testing.T) {
	tests := []struct {
		in   string
		want []string
	}{
		{"/data/r", []string{"/data/r"}},
		{"/data/r /more/src", []string{"/data/r", "/more/src"}},
		// object(source-list): only the source dirs in parens count.
		{"/obj(/src1 /src2)", []string{"/src1", "/src2"}},
		// autorelink star and shared objects are stripped/skipped.
		{"/data/r* /opt/ydb/libyottadbutil.so", []string{"/data/r"}},
		{"", nil},
	}
	for _, tt := range tests {
		got := ParseRoutinesDirs(tt.in)
		if fmt.Sprint(got) != fmt.Sprint(tt.want) {
			t.Errorf("ParseRoutinesDirs(%q) = %v, want %v", tt.in, got, tt.want)
		}
	}
}

func TestMatch_BareNameExtensionInsensitive(t *testing.T) {
	tests := []struct {
		name, glob string
		want       bool
	}{
		{"DGREG.m", "", true},      // empty glob matches all
		{"DGREG.m", "DG*", true},   // prefix glob on bare name
		{"DGREG.m", "DGREG", true}, // exact bare name
		{"XUSER.m", "DG*", false},
		{"DGREG.m", "*.m", false}, // glob is bare-name, so ".m" never matches
	}
	for _, tt := range tests {
		got, err := Match(tt.name, tt.glob)
		if err != nil {
			t.Fatalf("Match(%q,%q): %v", tt.name, tt.glob, err)
		}
		if got != tt.want {
			t.Errorf("Match(%q,%q) = %v, want %v", tt.name, tt.glob, got, tt.want)
		}
	}
}

// --- managed staging namespace (mtest-*) ---------------------------------

func TestValidStageName(t *testing.T) {
	for name, want := range map[string]bool{
		"mtest-abc123":   true,
		"mtest-1a.b_c-d": true,
		"mtest-":         false, // no token
		"":               false,
		"zzt1":           false, // outside the managed namespace
		"mtest-a/b":      false, // path separator
		"mtest-..":       false,
		"mtest-a b":      false,
	} {
		if got := ValidStageName(name); got != want {
			t.Errorf("ValidStageName(%q) = %v, want %v", name, got, want)
		}
	}
}

func TestSweepStageDirsLocal(t *testing.T) {
	primary := t.TempDir()
	old := time.Now().Add(-25 * time.Hour)
	mkdir := func(name string, ts time.Time) {
		d := filepath.Join(primary, name)
		if err := os.MkdirAll(d, 0o755); err != nil {
			t.Fatal(err)
		}
		writeFile(t, d, "X.m", "x ;\n q\n")
		if err := os.Chtimes(d, ts, ts); err != nil {
			t.Fatal(err)
		}
	}
	mkdir("mtest-old", old)
	mkdir("mtest-fresh", time.Now())
	mkdir("mtest-keep", old)                          // the running conn's own dir — must survive
	mkdir("notstaging", old)                          // non-namespace dir — must survive
	writeFile(t, primary, "LOCAL.m", "local ;\n q\n") // flat FILE — must survive
	oldFile := filepath.Join(primary, "LOCAL.m")
	if err := os.Chtimes(oldFile, old, old); err != nil {
		t.Fatal(err)
	}

	swept, err := SweepStageDirsLocal(primary, 24*time.Hour, time.Now(), "mtest-keep")
	if err != nil {
		t.Fatalf("sweep: %v", err)
	}
	if len(swept) != 1 || swept[0] != "mtest-old" {
		t.Fatalf("swept = %v, want [mtest-old]", swept)
	}
	for _, want := range []string{"mtest-fresh", "mtest-keep", "notstaging", "LOCAL.m"} {
		if _, err := os.Stat(filepath.Join(primary, want)); err != nil {
			t.Errorf("%s should have survived the sweep: %v", want, err)
		}
	}
	if _, err := os.Stat(filepath.Join(primary, "mtest-old")); !os.IsNotExist(err) {
		t.Error("mtest-old still present after sweep")
	}
}

func TestSweepStageDirsShell_ScriptAndParse(t *testing.T) {
	var script string
	sh := &fakeSh{
		capture: &script,
		responses: []struct{ contains, stdout string }{
			{"mtest-", "mtest-a\nmtest-b\n"},
		},
	}
	swept, err := SweepStageDirsShell(context.Background(), sh, "/data/p", 24*time.Hour, time.Unix(1700000000, 0), "mtest-mine")
	if err != nil {
		t.Fatalf("sweep: %v", err)
	}
	if len(swept) != 2 || swept[0] != "mtest-a" || swept[1] != "mtest-b" {
		t.Errorf("swept = %v, want [mtest-a mtest-b]", swept)
	}
	for _, frag := range []string{"'/data/p'/mtest-*", "[ -d ", "rm -rf", "86400", "1700000000", "mtest-mine"} {
		if !contains(script, frag) {
			t.Errorf("sweep script missing %q:\n%s", frag, script)
		}
	}
}

func TestRemoveStageDirLocal(t *testing.T) {
	primary := t.TempDir()
	d := filepath.Join(primary, "mtest-x")
	writeFile(t, d, "FOO.m", "foo ;\n q\n")
	if err := RemoveStageDirLocal(primary, "mtest-x"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if _, err := os.Stat(d); !os.IsNotExist(err) {
		t.Error("stage dir still present")
	}
	// Absent dir is a no-op; a name outside the namespace is refused.
	if err := RemoveStageDirLocal(primary, "mtest-x"); err != nil {
		t.Errorf("second remove = %v, want nil (no-op)", err)
	}
	if err := RemoveStageDirLocal(primary, "r"); err == nil {
		t.Error("removing a non-mtest name must be refused")
	}
}

func TestRemoveStageDirShell(t *testing.T) {
	var script string
	sh := &fakeSh{capture: &script}
	if err := RemoveStageDirShell(context.Background(), sh, "/data/p", "mtest-abc"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if !contains(script, `rm -rf '/data/p/mtest-abc'`) {
		t.Errorf("remove script = %q, want rm -rf '/data/p/mtest-abc'", script)
	}
	if err := RemoveStageDirShell(context.Background(), sh, "/data/p", "r"); err == nil {
		t.Error("removing a non-mtest name must be refused")
	}
}
