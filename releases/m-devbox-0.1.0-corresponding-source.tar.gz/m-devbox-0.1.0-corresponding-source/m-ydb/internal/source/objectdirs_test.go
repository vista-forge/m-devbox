package source

import (
	"reflect"
	"testing"
)

// ObjectDirsFor maps a routine SOURCE dir to the object dir(s) its compiled .o
// can land in, per $ydb_routines token semantics. This exists because sync rm
// removing only the .m leaves the routine fully executable from the leftover
// object (measured 2026-07-22, PR-9 shape B) — removal must cover the object.
func TestObjectDirsFor(t *testing.T) {
	cases := []struct {
		name     string
		routines string
		src      string
		want     []string
	}{
		{
			name:     "group token with autorelink (the m-test-engine shape)",
			routines: "/data/r2.07_x86_64/o/utf8*(/data/r2.07_x86_64/r /data/r) /opt/yottadb/current/utf8/libyottadbutil.so",
			src:      "/data/r2.07_x86_64/r",
			want:     []string{"/data/r2.07_x86_64/o/utf8"},
		},
		{
			name:     "group token, second source dir maps to the same object dir",
			routines: "/inst/o(/inst/r /data/r)",
			src:      "/data/r",
			want:     []string{"/inst/o"},
		},
		{
			name:     "bare dir: source and object co-located",
			routines: "/work /other",
			src:      "/work",
			want:     []string{"/work"},
		},
		{
			name:     "bare dir with autorelink marker",
			routines: "/work*",
			src:      "/work",
			want:     []string{"/work"},
		},
		{
			name:     "src not on the path",
			routines: "/a /b",
			src:      "/nope",
			want:     nil,
		},
		{
			name:     "shared objects are never object dirs",
			routines: "/x/libyottadbutil.so /work",
			src:      "/work",
			want:     []string{"/work"},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := ObjectDirsFor(tc.routines, tc.src)
			if !reflect.DeepEqual(got, tc.want) {
				t.Errorf("ObjectDirsFor(%q, %q) = %v, want %v", tc.routines, tc.src, got, tc.want)
			}
		})
	}
}
