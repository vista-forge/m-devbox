// Package source is m-ydb's view of the engine-side routine source: the .m
// files in a YottaDB instance's $ydb_routines source directories. For YottaDB
// the source IS the file on disk, so a Store lists/reads those files directly —
// over the host filesystem for the local transport (FileStore), or inside the
// managed container for the docker transport (ShellStore).
//
// The change signal for sync is the source file's modification time (epoch
// seconds, so it is identical whether read by stat locally or in the container);
// content integrity is the SHA-256 the mirror records. Routine names are the
// bare filenames (e.g. "FOO.m"); --filter matches the extension-stripped bare
// name (driver-contract §5.2).
package source

import (
	"context"
	"encoding/base64"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// errNoDirs is returned by a write/remove when no source directory is
// configured (so there is no primary dir to target).
var errNoDirs = fmt.Errorf("source: no routine source directory configured")

// Routine is one routine in the engine's source.
type Routine struct {
	Name string // filename, e.g. "FOO.m"
	TS   string // change signal: source mod-time, epoch seconds
}

// Store lists and reads .m source files from the engine's routine source
// directories, in search-path order (the first directory holding a given name
// wins, matching YottaDB's own resolution). Writes/removes target the primary
// (first) source directory — the one the driver owns and pushes into.
type Store interface {
	List(ctx context.Context) ([]Routine, error)
	Read(ctx context.Context, name string) ([]byte, error)
	// Write persists content as the routine in the primary source dir and
	// returns the resulting Routine (name + new source TS).
	Write(ctx context.Context, name string, content []byte) (Routine, error)
	// Remove deletes the routine from the primary source dir. A routine absent
	// from the primary dir is a no-op (nil error).
	Remove(ctx context.Context, name string) error
}

// nameRe restricts routine filenames to YottaDB's grammar, which also makes
// them safe to interpolate into the ShellStore scripts.
var nameRe = mustName()

func mustName() func(string) bool {
	// First char %, _ or letter; then letters/digits; then ".m". A leading `_`
	// is the ON-DISK form of a %-routine (YottaDB resolves %DT from _DT.m), so
	// a FileMan-bearing engine's source dirs are full of `_X.m` files — List
	// already returns them, and Read/Write/Remove must accept what List
	// enumerates (PR-21: rejecting them broke `m lib verify` and kept
	// `exec load` from staging %-routine source). `_` alone, or anywhere past
	// position 0, stays invalid.
	return func(s string) bool {
		if !strings.HasSuffix(s, ".m") {
			return false
		}
		base := strings.TrimSuffix(s, ".m")
		if base == "" || base == "_" {
			return false
		}
		for i, r := range base {
			switch {
			case r >= 'A' && r <= 'Z', r >= 'a' && r <= 'z':
			case (r == '%' || r == '_') && i == 0:
			case r >= '0' && r <= '9' && i > 0:
			default:
				return false
			}
		}
		return true
	}
}

// --- FileStore (local transport) ---------------------------------------------

// FileStore reads routine source from host-filesystem directories.
type FileStore struct {
	dirs []string
}

// NewFileStore builds a local-filesystem store over the given source dirs (in
// search-path order).
func NewFileStore(dirs []string) *FileStore { return &FileStore{dirs: dirs} }

func (s *FileStore) List(context.Context) ([]Routine, error) {
	seen := map[string]bool{}
	var out []Routine
	for _, dir := range s.dirs {
		entries, err := os.ReadDir(dir)
		if os.IsNotExist(err) {
			continue // a configured source dir that does not exist is just empty
		}
		if err != nil {
			return nil, err
		}
		for _, e := range entries {
			name := e.Name()
			if e.IsDir() || filepath.Ext(name) != ".m" || seen[name] {
				continue
			}
			info, err := e.Info()
			if err != nil {
				return nil, err
			}
			seen[name] = true
			out = append(out, Routine{Name: name, TS: strconv.FormatInt(info.ModTime().Unix(), 10)})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out, nil
}

func (s *FileStore) Read(_ context.Context, name string) ([]byte, error) {
	if !nameRe(name) {
		return nil, fmt.Errorf("source: invalid routine name %q", name)
	}
	for _, dir := range s.dirs {
		b, err := os.ReadFile(filepath.Join(dir, name))
		if err == nil {
			return b, nil
		}
		if !os.IsNotExist(err) {
			return nil, err
		}
	}
	return nil, fs.ErrNotExist
}

func (s *FileStore) Write(_ context.Context, name string, content []byte) (Routine, error) {
	if !nameRe(name) {
		return Routine{}, fmt.Errorf("source: invalid routine name %q", name)
	}
	if len(s.dirs) == 0 {
		return Routine{}, errNoDirs
	}
	dir := s.dirs[0]
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return Routine{}, err
	}
	path := filepath.Join(dir, name)
	if err := os.WriteFile(path, content, 0o644); err != nil {
		return Routine{}, err
	}
	info, err := os.Stat(path)
	if err != nil {
		return Routine{}, err
	}
	return Routine{Name: name, TS: strconv.FormatInt(info.ModTime().Unix(), 10)}, nil
}

func (s *FileStore) Remove(_ context.Context, name string) error {
	if !nameRe(name) {
		return fmt.Errorf("source: invalid routine name %q", name)
	}
	if len(s.dirs) == 0 {
		return errNoDirs
	}
	err := os.Remove(filepath.Join(s.dirs[0], name))
	if os.IsNotExist(err) {
		return nil // no-op: nothing to remove in the primary dir
	}
	return err
}

// --- ShellStore (docker transport) -------------------------------------------

// Sheller runs a /bin/sh -c script in the engine's filesystem context (inside
// the managed container for the docker transport) and returns its stdout and
// exit code. transport.Session implements it.
type Sheller interface {
	Sh(ctx context.Context, script string) (stdout string, code int, err error)
}

// ShellStore reads routine source from directories inside the engine container
// by running small shell scripts through a Sheller.
type ShellStore struct {
	sh   Sheller
	dirs []string
}

// NewShellStore builds a container store over the given source dirs.
func NewShellStore(sh Sheller, dirs []string) *ShellStore {
	return &ShellStore{sh: sh, dirs: dirs}
}

func (s *ShellStore) List(ctx context.Context) ([]Routine, error) {
	var b strings.Builder
	for _, dir := range s.dirs {
		// For each *.m in dir, print "<basename>\t<mtime-epoch>". Skip the glob
		// when nothing matches (the [ -e ] guard). stat -c is GNU coreutils.
		fmt.Fprintf(&b, `for f in '%s'/*.m; do [ -e "$f" ] || continue; printf '%%s\t%%s\n' "${f##*/}" "$(stat -c %%Y "$f" 2>/dev/null)"; done;`, dir)
	}
	out, _, err := s.sh.Sh(ctx, b.String())
	if err != nil {
		return nil, err
	}
	seen := map[string]bool{}
	var rts []Routine
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		name, ts, ok := strings.Cut(line, "\t")
		if !ok || filepath.Ext(name) != ".m" || seen[name] {
			continue
		}
		seen[name] = true
		rts = append(rts, Routine{Name: name, TS: ts})
	}
	sort.Slice(rts, func(i, j int) bool { return rts[i].Name < rts[j].Name })
	return rts, nil
}

func (s *ShellStore) Read(ctx context.Context, name string) ([]byte, error) {
	if !nameRe(name) {
		return nil, fmt.Errorf("source: invalid routine name %q", name)
	}
	var b strings.Builder
	for _, dir := range s.dirs {
		fmt.Fprintf(&b, `if [ -f '%s/%s' ]; then cat '%s/%s'; exit 0; fi;`, dir, name, dir, name)
	}
	b.WriteString("exit 1")
	out, code, err := s.sh.Sh(ctx, b.String())
	if err != nil {
		return nil, err
	}
	if code != 0 {
		return nil, fs.ErrNotExist
	}
	return []byte(out), nil
}

func (s *ShellStore) Write(ctx context.Context, name string, content []byte) (Routine, error) {
	if !nameRe(name) {
		return Routine{}, fmt.Errorf("source: invalid routine name %q", name)
	}
	if len(s.dirs) == 0 {
		return Routine{}, errNoDirs
	}
	dir := s.dirs[0]
	// base64 the content so arbitrary bytes survive the shell with no quoting
	// hazard, decode it in the container, then print the new file's mtime.
	enc := base64.StdEncoding.EncodeToString(content)
	script := fmt.Sprintf(`mkdir -p '%s'; printf '%%s' '%s' | base64 -d > '%s/%s'; stat -c %%Y '%s/%s'`,
		dir, enc, dir, name, dir, name)
	out, code, err := s.sh.Sh(ctx, script)
	if err != nil {
		return Routine{}, err
	}
	if code != 0 {
		return Routine{}, fmt.Errorf("source: write %s failed (exit %d)", name, code)
	}
	return Routine{Name: name, TS: strings.TrimSpace(out)}, nil
}

func (s *ShellStore) Remove(ctx context.Context, name string) error {
	if !nameRe(name) {
		return fmt.Errorf("source: invalid routine name %q", name)
	}
	if len(s.dirs) == 0 {
		return errNoDirs
	}
	dir := s.dirs[0]
	_, code, err := s.sh.Sh(ctx, fmt.Sprintf(`rm -f '%s/%s'`, dir, name))
	if err != nil {
		return err
	}
	if code != 0 {
		return fmt.Errorf("source: remove %s failed (exit %d)", name, code)
	}
	return nil
}

// --- managed staging namespace (mtest-*) --------------------------------------
//
// `m test`-style runs stage routine source into a run-scoped SUBDIRECTORY of
// the primary source dir (`<primary>/mtest-<token>`) instead of the flat dir
// itself, so a leaked stage can never shadow an installed routine (in
// $ZROUTINES, `dir*` is flat dir + auto-relink — the `*` is NOT subdir search,
// so a file in a subdir resolves only when that subdir is explicitly on the
// path). The lifecycle is: sweep stale mtest-* dirs on run start (TTL), stage,
// remove the run's own dir on exit. Only DIRECTORIES in the mtest-* namespace
// are ever swept/removed — a flat .m/.o in the primary dir may be a genuine
// local patch and is never touched.

// StagePrefix is the managed staging namespace: every run-scoped staging
// directory is named StagePrefix+<token>, and only such directories are
// eligible for sweep/removal.
const StagePrefix = "mtest-"

var stageNameRe = regexp.MustCompile(`^mtest-[A-Za-z0-9][A-Za-z0-9._-]*$`)

// ValidStageName reports whether name is a safe, in-namespace staging
// directory name: the mtest- prefix plus a token of [A-Za-z0-9._-] starting
// alphanumeric — a single path component with no separators, so it is safe to
// join under the primary dir and to interpolate into shell scripts.
func ValidStageName(name string) bool { return stageNameRe.MatchString(name) }

// SweepStageDirsLocal removes subdirectories of primary in the mtest-*
// namespace whose mtime is older than ttl (relative to now), skipping keep
// (the calling run's own stage dir). It returns the removed names, sorted —
// callers report them (no silent cleanup). Flat files and directories outside
// the namespace are never touched.
func SweepStageDirsLocal(primary string, ttl time.Duration, now time.Time, keep string) ([]string, error) {
	entries, err := os.ReadDir(primary)
	if os.IsNotExist(err) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var swept []string
	for _, e := range entries {
		name := e.Name()
		if !e.IsDir() || !ValidStageName(name) || name == keep {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue // raced away — nothing to sweep
		}
		if now.Sub(info.ModTime()) < ttl {
			continue
		}
		if err := os.RemoveAll(filepath.Join(primary, name)); err != nil {
			return swept, err
		}
		swept = append(swept, name)
	}
	sort.Strings(swept)
	return swept, nil
}

// SweepStageDirsShell is SweepStageDirsLocal over a Sheller (the docker
// transport): one shell pass that removes stale mtest-* DIRECTORIES under
// primary and prints each removed name. now is passed in from the host so the
// age check does not depend on container clock parsing.
func SweepStageDirsShell(ctx context.Context, sh Sheller, primary string, ttl time.Duration, now time.Time, keep string) ([]string, error) {
	script := fmt.Sprintf(
		`for d in '%s'/mtest-*; do [ -d "$d" ] || continue; b="${d##*/}"; [ "$b" = '%s' ] && continue; ts=$(stat -c %%Y "$d" 2>/dev/null) || continue; [ $((%d-ts)) -ge %d ] || continue; rm -rf "$d" && printf '%%s\n' "$b"; done`,
		primary, keep, now.Unix(), int64(ttl.Seconds()))
	out, _, err := sh.Sh(ctx, script)
	if err != nil {
		return nil, err
	}
	var swept []string
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if line != "" && ValidStageName(line) {
			swept = append(swept, line)
		}
	}
	sort.Strings(swept)
	return swept, nil
}

// RemoveStageDirLocal removes the staging directory name under primary (the
// run's unconditional exit cleanup). A name outside the mtest-* namespace is
// refused — this function can never remove the primary dir itself or an
// arbitrary subdirectory. An absent dir is a no-op.
func RemoveStageDirLocal(primary, name string) error {
	if !ValidStageName(name) {
		return fmt.Errorf("source: not a managed staging dir name: %q (want %s<token>)", name, StagePrefix)
	}
	return os.RemoveAll(filepath.Join(primary, name))
}

// RemoveStageDirShell is RemoveStageDirLocal over a Sheller (docker transport).
func RemoveStageDirShell(ctx context.Context, sh Sheller, primary, name string) error {
	if !ValidStageName(name) {
		return fmt.Errorf("source: not a managed staging dir name: %q (want %s<token>)", name, StagePrefix)
	}
	_, code, err := sh.Sh(ctx, fmt.Sprintf(`rm -rf '%s/%s'`, primary, name))
	if err != nil {
		return err
	}
	if code != 0 {
		return fmt.Errorf("source: remove stage dir %s failed (exit %d)", name, code)
	}
	return nil
}

// RemoveObjectLocal removes dir/<bare>.o if present, reporting whether it
// existed. Part of sync rm's object-removal half (a leftover .o keeps the
// routine executable).
func RemoveObjectLocal(dir, bare string) (bool, error) {
	p := filepath.Join(dir, bare+".o")
	if _, err := os.Stat(p); err != nil {
		if os.IsNotExist(err) {
			return false, nil
		}
		return false, err
	}
	if err := os.Remove(p); err != nil {
		return false, err
	}
	return true, nil
}

// RemoveObjectShell is RemoveObjectLocal over the container shell.
func RemoveObjectShell(ctx context.Context, sh Sheller, dir, bare string) (bool, error) {
	script := fmt.Sprintf(`if [ -f '%s/%s.o' ]; then rm -f '%s/%s.o' && echo GONE; fi`, dir, bare, dir, bare)
	out, code, err := sh.Sh(ctx, script)
	if err != nil {
		return false, err
	}
	if code != 0 {
		return false, fmt.Errorf("source: remove object %s.o failed (exit %d)", bare, code)
	}
	return strings.Contains(out, "GONE"), nil
}

// --- helpers -----------------------------------------------------------------

// ParseRoutinesDirs extracts the source directories from a $ydb_routines value
// (best-effort). It keeps bare directories and the source dirs inside an
// `object(src1 src2)` group, strips a trailing `*` autorelink marker, and skips
// shared-object entries (.so/.o).
func ParseRoutinesDirs(ydbRoutines string) []string {
	var out []string
	add := func(tok string) {
		tok = strings.TrimSpace(tok)
		tok = strings.TrimSuffix(tok, ")") // stray close-paren from a group
		tok = strings.TrimSuffix(tok, "*") // autorelink marker
		if tok == "" || strings.HasSuffix(tok, ".so") || strings.HasSuffix(tok, ".o") {
			return
		}
		out = append(out, tok)
	}
	for _, tok := range strings.Fields(ydbRoutines) {
		if i := strings.IndexByte(tok, '('); i >= 0 {
			inner := tok[i+1:]
			inner = strings.TrimSuffix(inner, ")")
			for _, src := range strings.Fields(inner) {
				add(src)
			}
			continue
		}
		add(tok)
	}
	return out
}

// ObjectDirsFor maps a routine SOURCE directory to the object directory(ies)
// its compiled .o can land in, per $ydb_routines token semantics: for an
// `obj(src…)` / `obj*(src…)` group the object dir is the part before the `(`;
// for a bare `dir` / `dir*` token source and object co-locate in the dir
// itself. Shared-object entries (.so/.o) are never object dirs.
//
// This exists because removing only a routine's .m leaves it fully executable
// from the leftover object (measured 2026-07-22: $TEXT reads back 0 lines
// while the routine still runs) — a removal that does not cover the object
// has not removed the routine.
func ObjectDirsFor(ydbRoutines, srcDir string) []string {
	clean := func(tok string) string {
		tok = strings.TrimSpace(tok)
		tok = strings.TrimSuffix(tok, ")")
		tok = strings.TrimSuffix(tok, "*")
		return tok
	}
	var out []string
	fields := strings.Fields(ydbRoutines)
	for i := 0; i < len(fields); i++ {
		tok := fields[i]
		if j := strings.IndexByte(tok, '('); j >= 0 {
			obj := clean(tok[:j])
			// Collect the group's source dirs: the rest of this token plus
			// following fields up to (and including) the one closing the group.
			srcs := []string{clean(tok[j+1:])}
			for !strings.HasSuffix(fields[i], ")") && i+1 < len(fields) {
				i++
				srcs = append(srcs, clean(fields[i]))
			}
			for _, s := range srcs {
				if s == srcDir && obj != "" && !strings.HasSuffix(obj, ".so") && !strings.HasSuffix(obj, ".o") {
					out = append(out, obj)
				}
			}
			continue
		}
		d := clean(tok)
		if d == srcDir && !strings.HasSuffix(d, ".so") && !strings.HasSuffix(d, ".o") {
			out = append(out, d)
		}
	}
	return out
}

// BareName strips a routine's extension: "FOO.m" → "FOO".
func BareName(name string) string {
	return strings.TrimSuffix(name, filepath.Ext(name))
}

// Match reports whether a routine name passes a bare-name glob (the extension
// is stripped before matching, per driver-contract §5.2). An empty glob matches
// everything.
func Match(name, glob string) (bool, error) {
	if glob == "" {
		return true, nil
	}
	ok, err := filepath.Match(glob, BareName(name))
	if err != nil {
		return false, fmt.Errorf("invalid --filter %q: %w", glob, err)
	}
	return ok, nil
}
