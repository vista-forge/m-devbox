package main

import (
	"context"
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	mdriver "github.com/vista-forge/m-driver-sdk"
	"github.com/vista-forge/m-ydb/clikit"
	"github.com/vista-forge/m-ydb/internal/config"
	"github.com/vista-forge/m-ydb/internal/mirror"
	"github.com/vista-forge/m-ydb/internal/source"
	"github.com/vista-forge/m-ydb/internal/transport"
)

// execCmd is the exec axis (driver-contract §5.3) — run M code against the
// instance. load stages .m source into the routine path and compiles it (ZLINK,
// surfacing compile faults from the listing); run/eval execute an entryref / a
// single command under a $ETRAP that surfaces a structured engineError
// ($ZSTATUS, §7) on a runtime fault; abort stops jobs tagged with an ephemeral
// --prefix. The configured routine path is layered onto $ZROUTINES at runtime so
// staged routines resolve while %XCMD stays linked.
type execCmd struct {
	Load    execLoadCmd    `cmd:"" name:"load" help:"Stage .m source into the instance routine path and compile it (ZLINK); compile faults surface as engineError."`
	Run     execRunCmd     `cmd:"" name:"run" help:"Run an entryref (LABEL^ROUTINE); args → $ZCMDLINE. Faults surface as engineError."`
	Eval    execEvalCmd    `cmd:"" name:"eval" help:"Evaluate a single M command. Faults surface as engineError."`
	Script  execScriptCmd  `cmd:"" name:"script" help:"Run a multi-line direct-mode M script (base64 --script-b64); returns raw device output. No $ETRAP wrapper — for compound passes like coverage TRACE."`
	Abort   execAbortCmd   `cmd:"" name:"abort" help:"Stop running jobs tagged with an ephemeral --prefix (pgrep + mupip stop)."`
	Unstage execUnstageCmd `cmd:"" name:"unstage" help:"Remove this run's managed staging dir (--stage-dir) from the primary source dir — the unconditional exit cleanup."`
	Sweep   execSweepCmd   `cmd:"" name:"sweep" help:"Retire stale managed staging dirs (mtest-*, older than --ttl-hours) under the primary source dir; reports what was swept. Never touches flat files."`
}

type execResult struct {
	Stdout string `json:"stdout"`
	Status int    `json:"status"`
}

// --- load --------------------------------------------------------------------

type execLoadCmd struct {
	Paths     []string `arg:"" optional:"" help:".m source files to stage."`
	From      string   `help:"Stage every .m routine in this directory." placeholder:"DIR"`
	NoCompile bool     `name:"no-compile" help:"Stage only; skip the ZLINK compile check."`
}

type execLoadResult struct {
	Loaded   []string `json:"loaded"`
	Compiled bool     `json:"compiled"`
}

func (c *execLoadCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	if len(c.Paths) == 0 && c.From == "" {
		return clikit.Fail(clikit.ExitUsage, "NO_SOURCE", "exec load needs <paths…> or --from <dir>", "")
	}
	// A managed staging conn writes into <primary>/<stage-dir> (dirs[0] after
	// the prepend) and compiles/runs with that dir first on $ZROUTINES.
	if err := conn.EnsureStageRoutines(context.Background()); err != nil {
		return usageErr(err)
	}
	store, err := conn.SourceStore()
	if err != nil {
		return usageErr(err)
	}
	srcs, err := c.gather(conn.Filter)
	if err != nil {
		return err
	}
	ctx := context.Background()
	loaded := make([]string, 0, len(srcs))
	for _, sc := range srcs {
		if _, err := store.Write(ctx, sc.name, mirror.Normalize(sc.content)); err != nil {
			return runtimeErr(err)
		}
		loaded = append(loaded, sc.name)
	}
	sort.Strings(loaded)

	if c.NoCompile {
		return cc.Result(execLoadResult{Loaded: loaded, Compiled: false}, func() {
			cc.Title("load complete (staged, not compiled)")
			cc.KV([2]string{"loaded", fmt.Sprint(len(loaded))})
		})
	}

	ee, err := conn.NewSession().Compile(ctx, bareNames(loaded))
	if err != nil {
		return runtimeErr(err)
	}
	if ee != nil {
		msg := strings.TrimSpace(ee.Mnemonic + " " + ee.Text)
		return clikit.FailEngine(clikit.ExitRuntime, "COMPILE_ERROR", "compile failed: "+msg, "", toClikitEngineError(ee))
	}
	return cc.Result(execLoadResult{Loaded: loaded, Compiled: true}, func() {
		cc.Title("load complete")
		cc.KV([2]string{"loaded", fmt.Sprint(len(loaded))}, [2]string{"compiled", "yes"})
		fmt.Fprintln(cc.Stdout, cc.Success("routines staged + compiled"))
	})
}

type routineSrc struct {
	name    string
	content []byte
}

// gather reads the routine sources named by the explicit paths and/or the
// --from directory (the latter filtered by the bare-name --filter).
func (c *execLoadCmd) gather(glob string) ([]routineSrc, error) {
	var out []routineSrc
	for _, p := range c.Paths {
		if filepath.Ext(p) != ".m" {
			return nil, usageErr(fmt.Errorf("not a .m routine: %s", p))
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return nil, runtimeErr(err)
		}
		out = append(out, routineSrc{name: filepath.Base(p), content: b})
	}
	if c.From != "" {
		names, err := dirRoutines(c.From, glob)
		if err != nil {
			return nil, err
		}
		for _, n := range names {
			b, err := os.ReadFile(filepath.Join(c.From, n))
			if err != nil {
				return nil, runtimeErr(err)
			}
			out = append(out, routineSrc{name: n, content: b})
		}
	}
	return out, nil
}

// --- run ---------------------------------------------------------------------

type execRunCmd struct {
	EntryRef string   `arg:"" help:"Entryref to run (LABEL^ROUTINE or ^ROUTINE)."`
	Args     []string `arg:"" optional:"" help:"Arguments, joined into $ZCMDLINE."`
	Prefix   string   `help:"Ephemeral-run prefix; marks the process so 'exec abort --prefix' can stop it." placeholder:"PREFIX"`
}

func (c *execRunCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	return runExec(cc, conn, mdriver.ExecRequest{EntryRef: c.EntryRef, Args: c.Args, Prefix: c.Prefix})
}

// --- abort -------------------------------------------------------------------

type execAbortCmd struct {
	Prefix string `help:"Ephemeral-run prefix to abort (the marker passed to 'exec run --prefix')." placeholder:"PREFIX"`
}

type execAbortResult struct {
	Killed []string `json:"killed"`
}

func (c *execAbortCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	if c.Prefix == "" {
		return clikit.Fail(clikit.ExitUsage, "NO_PREFIX", "exec abort needs --prefix", "")
	}
	if err := conn.Validate(); err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_CONN", err.Error(), "")
	}
	killed, err := conn.NewSession().Abort(context.Background(), c.Prefix)
	if err != nil {
		return runtimeErr(err)
	}
	return cc.Result(execAbortResult{Killed: nonNil(killed)}, func() {
		if len(killed) == 0 {
			fmt.Fprintln(cc.Stdout, cc.Faint("no jobs matched --prefix "+c.Prefix))
			return
		}
		fmt.Fprintln(cc.Stdout, cc.Success(fmt.Sprintf("stopped %d job(s): %s", len(killed), strings.Join(killed, ", "))))
	})
}

// --- eval --------------------------------------------------------------------

type execEvalCmd struct {
	Command []string `arg:"" help:"M command to evaluate (joined with spaces; quote it as one shell arg)."`
}

func (c *execEvalCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	return runExec(cc, conn, mdriver.ExecRequest{Command: strings.Join(c.Command, " ")})
}

// --- script ------------------------------------------------------------------

type execScriptCmd struct {
	ScriptB64 string `name:"script-b64" help:"Base64-encoded multi-line M script to run in direct mode." placeholder:"B64"`
}

// Run decodes the base64 script and runs it in YottaDB direct mode via the plain
// Session.Exec (no $ETRAP wrapper — a script is a self-contained compound pass,
// e.g. the coverage `view \"TRACE\"` → `zwrite ^ycov` sequence, whose caller
// parses the raw dump). Returns the raw captured device output verbatim.
func (c *execScriptCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	if c.ScriptB64 == "" {
		return clikit.Fail(clikit.ExitUsage, "NO_SCRIPT", "exec script needs --script-b64", "")
	}
	raw, err := base64.StdEncoding.DecodeString(c.ScriptB64)
	if err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_SCRIPT_B64", "invalid base64 in --script-b64: "+err.Error(), "")
	}
	if err := conn.Validate(); err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_CONN", err.Error(), "")
	}
	// A managed staging conn resolves routines from <primary>/<stage-dir>
	// first — same prep as load/run/eval (config.EnsureStageRoutines's
	// contract). Skipping it here made every staged routine invisible to a
	// direct-mode script: the coverage TRACE pass ran against the ambient
	// path and reported 0.0% (found 2026-07-06).
	if err := conn.EnsureStageRoutines(context.Background()); err != nil {
		return usageErr(err)
	}
	res, err := conn.NewSession().Exec(context.Background(), mdriver.ExecRequest{Script: string(raw)})
	if err != nil {
		return runtimeErr(err)
	}
	return cc.Result(execResult{Stdout: res.Stdout, Status: res.Status}, func() {
		if res.Stdout != "" {
			fmt.Fprint(cc.Stdout, res.Stdout)
			if !strings.HasSuffix(res.Stdout, "\n") {
				fmt.Fprintln(cc.Stdout)
			}
		}
	})
}

// --- shared ------------------------------------------------------------------

// runExec validates the connection and dispatches to execDo with a real session.
func runExec(cc *clikit.Context, conn *config.Conn, req mdriver.ExecRequest) error {
	if err := conn.Validate(); err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_CONN", err.Error(), "")
	}
	if err := conn.EnsureStageRoutines(context.Background()); err != nil {
		return usageErr(err)
	}
	return execDo(cc, conn.NewSession(), req)
}

// --- unstage -------------------------------------------------------------------

type execUnstageCmd struct{}

type execUnstageResult struct {
	Removed string `json:"removed"`
}

// Run removes the connection's managed staging dir (<primary>/<stage-dir>).
// It is the run's unconditional exit cleanup: callers invoke it on every exit
// path, and an already-absent dir is a clean no-op. The mtest-* namespace
// validation in StagePath/RemoveStageDir* confines the removal by construction
// — the flat primary dir itself can never be the target.
func (c *execUnstageCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	if conn.StageDir == "" {
		return clikit.Fail(clikit.ExitUsage, "NO_STAGE_DIR", "exec unstage needs --stage-dir (or M_YDB_STAGE_DIR)", "")
	}
	if err := conn.Validate(); err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_CONN", err.Error(), "")
	}
	ctx := context.Background()
	primary, err := conn.PrimarySourceDir(ctx)
	if err != nil {
		return usageErr(err)
	}
	if conn.Transport == "docker" {
		err = source.RemoveStageDirShell(ctx, conn.NewSession(), primary, conn.StageDir)
	} else {
		err = source.RemoveStageDirLocal(primary, conn.StageDir)
	}
	if err != nil {
		return runtimeErr(err)
	}
	return cc.Result(execUnstageResult{Removed: conn.StageDir}, func() {
		fmt.Fprintln(cc.Stdout, cc.Success("removed staging dir "+conn.StageDir))
	})
}

// --- sweep ---------------------------------------------------------------------

type execSweepCmd struct {
	TTLHours int `name:"ttl-hours" default:"24" help:"Retire mtest-* staging dirs older than this many hours."`
}

type execSweepResult struct {
	Swept []string `json:"swept"`
}

// Run retires stale managed staging dirs under the primary source dir — the
// self-healing half of the staging lifecycle: a dir leaked by a crashed/killed
// run is removed by the next run's sweep instead of persisting forever. Only
// mtest-* DIRECTORIES older than the TTL are removed (the conn's own
// --stage-dir is skipped); flat .m/.o files are never touched — a flat file in
// the patch dir may be a genuine local patch, not staging debris.
func (c *execSweepCmd) Run(cc *clikit.Context, conn *config.Conn) error {
	if err := conn.Validate(); err != nil {
		return clikit.Fail(clikit.ExitUsage, "BAD_CONN", err.Error(), "")
	}
	ctx := context.Background()
	primary, err := conn.PrimarySourceDir(ctx)
	if err != nil {
		return usageErr(err)
	}
	ttl := time.Duration(c.TTLHours) * time.Hour
	var swept []string
	if conn.Transport == "docker" {
		swept, err = source.SweepStageDirsShell(ctx, conn.NewSession(), primary, ttl, time.Now(), conn.StageDir)
	} else {
		swept, err = source.SweepStageDirsLocal(primary, ttl, time.Now(), conn.StageDir)
	}
	if err != nil {
		return runtimeErr(err)
	}
	return cc.Result(execSweepResult{Swept: nonNil(swept)}, func() {
		if len(swept) == 0 {
			fmt.Fprintln(cc.Stdout, cc.Faint("no stale staging dirs"))
			return
		}
		fmt.Fprintln(cc.Stdout, cc.Success(fmt.Sprintf("swept %d stale staging dir(s): %s", len(swept), strings.Join(swept, ", "))))
	})
}

// execDo runs req under the engineError-capturing trap and renders the result:
// a §7 fault becomes an ok=false envelope with engineError (exit 5); otherwise
// {stdout, status}.
func execDo(cc *clikit.Context, sess *transport.Session, req mdriver.ExecRequest) error {
	res, err := sess.ExecTrapped(context.Background(), req)
	if err != nil {
		return runtimeErr(err)
	}
	if res.EngineError != nil {
		msg := res.EngineError.Mnemonic
		if res.EngineError.Text != "" {
			msg = strings.TrimSpace(msg + " " + res.EngineError.Text)
		}
		return clikit.FailEngine(clikit.ExitRuntime, "ENGINE_ERROR", msg, "", toClikitEngineError(res.EngineError))
	}
	return cc.Result(execResult{Stdout: res.Stdout, Status: res.Status}, func() {
		if res.Stdout != "" {
			fmt.Fprint(cc.Stdout, res.Stdout)
			if !strings.HasSuffix(res.Stdout, "\n") {
				fmt.Fprintln(cc.Stdout)
			}
		}
		fmt.Fprintln(cc.Stdout, cc.Faint(fmt.Sprintf("status %d", res.Status)))
	})
}

// toClikitEngineError converts the SDK §7 fault to clikit's own copy (drivers
// convert at the envelope boundary — consistency-protocol).
func toClikitEngineError(e *mdriver.EngineError) *clikit.EngineError {
	if e == nil {
		return nil
	}
	return &clikit.EngineError{
		Routine:  e.Routine,
		Line:     e.Line,
		Mnemonic: e.Mnemonic,
		Text:     e.Text,
	}
}
