package main

import (
	"context"
	"errors"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/alecthomas/kong"

	mdriver "github.com/vista-forge/m-driver-sdk"

	"github.com/vista-forge/m-ydb/clikit"
	"github.com/vista-forge/m-ydb/internal/config"
	"github.com/vista-forge/m-ydb/internal/runlock"
)

// The guard is exercised THROUGH KONG — a real argv, parsed against the real CLI
// grammar and dispatched — because what is under test is not the guard function,
// it is whether the guard is actually ON the dispatch path. A test that called
// guardRunLock() directly would still pass if nothing invoked it.
//
// No engine is needed: the locus resolution is faked through runLockDeps (the same
// seam production wires to the real docker CLI / SSH), and every refusal happens
// before the verb body runs.

// dispatch parses argv against the real CLI and runs the selected command. err is
// the command's error (a refusal, or the body's own error); reached reports whether
// the verb body produced output — i.e. whether an unbracketed call would have hit
// the engine.
func dispatch(t *testing.T, argv ...string) (reached bool, err error) {
	t.Helper()
	cli := &CLI{}
	parser, perr := kong.New(cli,
		kong.Name("m-ydb"),
		kong.Exit(func(int) { t.Fatal("kong tried to exit the test process") }),
	)
	if perr != nil {
		t.Fatalf("kong.New: %v", perr)
	}
	kctx, perr := parser.Parse(argv)
	if perr != nil {
		t.Fatalf("parse %v: %v", argv, perr)
	}
	var buf strings.Builder
	cc := &clikit.Context{Stdout: &buf, Stderr: &buf, Format: clikit.FormatJSON, Command: kctx.Command()}
	err = kctx.Run(cc, parser)
	return buf.Len() > 0, err
}

// localFixture points the resolver at a fixed local database — no docker, no
// engine, no network — and returns the lock key the guard will derive for it. The
// test's bracket and the guard's check must land on the SAME file, which is the
// whole point of the driver being the single derivation authority.
func localFixture(t *testing.T) (dir, gbldir, key string) {
	t.Helper()
	dir = t.TempDir()
	gbldir = filepath.Join(dir, "m.gld")

	orig := runLockDeps
	t.Cleanup(func() { runLockDeps = orig })
	runLockDeps = func(*config.Conn) runlock.Deps {
		return runlock.Deps{
			Hostname: func() (string, error) { return "test-host", nil },
			RealPath: func(p string) (string, error) { return p, nil },
		}
	}
	return dir, gbldir, "ydb.local." + mdriver.HashSelector(gbldir)
}

// conn is the argv for the local fixture's connection.
func connArgs(dir, gbldir string) []string {
	return []string{"--transport", "local", "--gbldir", gbldir, "--run-lock-dir", dir}
}

// The core trade the whole design makes: a lane that forgot the bracket is
// REFUSED, not served. The corruption class becomes an error-message class.
func TestGuard_MutatingVerbWithNoTokenIsRefused(t *testing.T) {
	dir, gbldir, _ := localFixture(t)

	argv := append([]string{"exec", "eval", "set x=1"}, connArgs(dir, gbldir)...)
	reached, err := dispatch(t, argv...)

	assertRefusal(t, err, mdriver.CodeRunLockRequired)
	if reached {
		t.Error("the verb body RAN — an unbracketed mutation reached the engine")
	}
}

// A token, but no live bracket: the bracket died under its own children. It gets
// its own code, because the operator's next move is different.
func TestGuard_TokenButNoBracketIsRefused(t *testing.T) {
	dir, gbldir, _ := localFixture(t)

	argv := append([]string{"exec", "eval", "set x=1"}, connArgs(dir, gbldir)...)
	argv = append(argv, "--run-lock", "a-token-from-a-dead-bracket")
	_, err := dispatch(t, argv...)

	assertRefusal(t, err, mdriver.CodeRunLockNotHeld)
}

// FENCING: a surviving orphan of a dead bracket presents its old token while a NEW
// lane holds the engine. The record compare fails, so the zombie writer is refused.
// Kernel-anchored, and a contract guarantee — hence a test, not a comment.
func TestGuard_ForeignTokenAgainstALiveBracketIsRefusedAsMismatch(t *testing.T) {
	dir, gbldir, key := localFixture(t)
	holdBracket(t, dir, key)

	argv := append([]string{"exec", "eval", "set x=1"}, connArgs(dir, gbldir)...)
	argv = append(argv, "--run-lock", "the-dead-brackets-token")
	_, err := dispatch(t, argv...)

	assertRefusal(t, err, mdriver.CodeRunLockMismatch)
}

// The owner is REENTRANT: a call inside its own bracket proceeds, with no wait. If
// this failed, the lock would deadlock every real run — which is exactly why
// verification is a probe + a record compare and NEVER an acquire.
func TestGuard_BracketHolderProceedsInItsOwnBracket(t *testing.T) {
	dir, gbldir, key := localFixture(t)
	lock := holdBracket(t, dir, key)

	argv := append([]string{"exec", "eval", "set x=1"}, connArgs(dir, gbldir)...)
	argv = append(argv, "--run-lock", lock.Token)
	_, err := dispatch(t, argv...)

	// The body may still fail (there is no real engine behind this fixture) — what
	// must NOT happen is a run-lock refusal of the bracket's own holder.
	if code := clikitCode(err); strings.HasPrefix(code, "RUN_LOCK") {
		t.Fatalf("the bracket holder was REFUSED its own bracket: %s (%v)", code, err)
	}
}

// Status and control verbs run with NO token, even while another lane holds the
// engine. This is the declared escape hatch (§R-7), and it is load-bearing twice:
// the remedy for a stuck run must not queue behind the stuck run, and AcquireRunLock
// bootstraps through `meta runlock-path` — a token-gated derivation verb could never
// be reached, so the bracket could never be taken at all (§7.3).
func TestGuard_ControlAndStatusVerbsRunUnbracketed(t *testing.T) {
	dir, gbldir, key := localFixture(t)
	holdBracket(t, dir, key) // another lane owns the engine

	for _, verb := range [][]string{
		{"meta", "caps"},
		{"meta", "runlock-path"},
		{"meta", "runlock-status"},
	} {
		t.Run(strings.Join(verb, " "), func(t *testing.T) {
			reached, err := dispatch(t, append(append([]string{}, verb...), connArgs(dir, gbldir)...)...)
			if err != nil {
				t.Errorf("`%s` was refused while another lane held the engine: %v", strings.Join(verb, " "), err)
			}
			if !reached {
				t.Errorf("`%s` produced no output", strings.Join(verb, " "))
			}
		})
	}
}

// `meta runlock-path` is the SINGLE derivation authority (R-3): the key it answers
// with must be the key the dispatch check enforces against. If these two could
// disagree, two lanes could "lock" different files for one engine — a silent
// failure of mutual exclusion, which is the defect the lock exists to prevent.
func TestRunlockPath_IsTheKeyTheGuardEnforces(t *testing.T) {
	dir, gbldir, key := localFixture(t)

	ref, err := runLockRef(context.Background(), &config.Conn{
		Transport: "local", GblDir: gbldir, RunLockDir: dir,
	})
	if err != nil {
		t.Fatalf("derive: %v", err)
	}
	if ref.Key != key {
		t.Errorf("key = %q, want %q", ref.Key, key)
	}
	if want := filepath.Join(dir, key+".lock"); ref.Path != want {
		t.Errorf("path = %q, want %q", ref.Path, want)
	}
	// The interior never appears in the lock-file name.
	if strings.Contains(ref.Key, "m.gld") {
		t.Errorf("the key %q leaks the database interior", ref.Key)
	}
}

// AMENDMENT B — THE RED-PROOF.
//
// The dispatch check re-derives the key on EVERY call, and on a network route that
// derivation makes an ENGINE CALL. If that call re-entered the dispatch middleware,
// it would recurse without bound. "Status-grade, driver-internal" is a discipline,
// not a gate — so this is the gate: a bracket-requiring verb on a network route
// resolves its locus exactly once and refuses cleanly, with no re-entry.
func TestGuard_NetworkRouteDoesNotReenterTheMiddleware(t *testing.T) {
	dir := t.TempDir()
	resolutions, probes := 0, 0

	orig := runLockDeps
	t.Cleanup(func() { runLockDeps = orig })
	runLockDeps = func(*config.Conn) runlock.Deps {
		// Built once per derivation: re-entering the middleware would re-derive, so this
		// counter IS the re-entry counter.
		resolutions++
		if resolutions > 4 {
			t.Fatal("UNBOUNDED RECURSION: the locus derivation re-entered the dispatch middleware")
		}
		return runlock.Deps{
			// The engine-ask. In production this is a plain call on the transport session
			// — never a re-entry into the CLI — which is what makes the recursion
			// structurally impossible rather than merely unlikely.
			Probe: func(context.Context) (runlock.Node, error) {
				probes++
				return runlock.Node{Name: "remote-node", GblDir: "/g/m.gld"}, nil
			},
			Hostname: func() (string, error) { return "not-this-host", nil },
			RealPath: func(p string) (string, error) { return p, nil },
		}
	}

	_, err := dispatch(t, "exec", "eval", "set x=1",
		"--transport", "remote", "--host", "h", "--run-lock-dir", dir)

	// It must still REFUSE — a recursion that was "fixed" by breaking the refusal
	// would be worse than the recursion.
	assertRefusal(t, err, mdriver.CodeRunLockRequired)
	if resolutions != 1 {
		t.Errorf("the locus was derived %d times for one verb, want exactly 1 (the middleware re-entered itself)", resolutions)
	}
	if probes != 1 {
		t.Errorf("the engine was probed %d times for one verb, want exactly 1", probes)
	}
}

// A verb this CONNECTION cannot dispatch is refused on the contract's "unsupported"
// rung — never attempted and then failed at runtime. Caps and the dispatch check
// read ONE table, so the document cannot promise what the connection will not do
// (C-CAPS-1).
func TestGuard_UnadvertisedVerbOnThisTransportIsExit7(t *testing.T) {
	dir := t.TempDir()

	reached, err := dispatch(t, "sync", "list", "--transport", "remote", "--host", "h", "--run-lock-dir", dir)

	var ce *clikit.Error
	if !errors.As(err, &ce) {
		t.Fatalf("want a structured refusal, got %v", err)
	}
	if ce.Exit != clikit.ExitUnsupported {
		t.Errorf("exit = %d, want %d (unsupported)", ce.Exit, clikit.ExitUnsupported)
	}
	if reached {
		t.Error("the verb body ran on a transport that cannot realize it")
	}
}

// An unresolvable route gets NO key, so a bracket-requiring verb on it REFUSES.
// A fall-back to the selector spelling would reintroduce the two-routes-one-instance
// split exactly when the box is degraded (defeat (n)) — the worst possible moment.
// This is C-RL-8's behavior, proven here because the conformance CLI exposes no
// fixture flag for it (see `needs SDK` in the tracker).
func TestGuard_UnresolvableRouteRefusesRatherThanGuessing(t *testing.T) {
	dir := t.TempDir()
	orig := runLockDeps
	t.Cleanup(func() { runLockDeps = orig })
	runLockDeps = func(*config.Conn) runlock.Deps {
		return runlock.Deps{
			Probe: func(context.Context) (runlock.Node, error) {
				return runlock.Node{}, errors.New("ssh: connect to host dead port 22: no route to host")
			},
			Hostname: func() (string, error) { return "minty", nil },
			RealPath: func(p string) (string, error) { return p, nil },
		}
	}

	_, err := dispatch(t, "exec", "eval", "set x=1",
		"--transport", "remote", "--host", "dead", "--run-lock-dir", dir)
	assertRefusal(t, err, mdriver.CodeRunLockUnresolved)

	// And the derivation verb itself must refuse rather than answer with a key it does
	// not have.
	_, perr := dispatch(t, "meta", "runlock-path",
		"--transport", "remote", "--host", "dead", "--run-lock-dir", dir)
	assertRefusal(t, perr, mdriver.CodeRunLockUnresolved)
}

// THE FUNNEL GATE. The guard runs when a command asks for its connection, so a
// bracket-requiring verb whose Run does NOT take a *config.Conn would slip past it.
// That is the one hole in the mechanism, and this closes it as a RED GATE rather
// than a convention: the next verb cannot quietly opt out of enforcement.
// contractAxes are the axes under contract classification (install-completions
// is a kongplete builtin, not a contract verb).
var contractAxes = map[string]bool{
	"meta": true, "lifecycle": true, "sync": true, "exec": true,
}

func TestGuardCoverage_EveryBracketVerbTakesTheConn(t *testing.T) {
	parser, err := kong.New(&CLI{}, kong.Name("m-ydb"))
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	connType := reflect.TypeOf(&config.Conn{})
	checked := 0
	var walk func(n *kong.Node)
	walk = func(n *kong.Node) {
		for _, child := range n.Children {
			walk(child)
		}
		if n.Type != kong.CommandNode || n.Parent == nil || n.Parent.Type != kong.CommandNode {
			return
		}
		class, ok := mdriver.ClassOf(n.Parent.Name, n.Name)
		if !ok {
			// The guard refuses an unclassified verb at runtime (UNCLASSIFIED_VERB),
			// but a verb this CLI advertises with no class is still an unenforced
			// hole waiting for a permissive refactor — red it at add-time, the same
			// gate m-iris's guard_test.go stands (L1.E).
			if contractAxes[n.Parent.Name] {
				t.Errorf("%s %s is advertised by the CLI but carries NO class in the SDK registry — "+
					"the dispatch guard cannot enforce it; classify it in mdriver's verbclass.go",
					n.Parent.Name, n.Name)
			}
			return
		}
		if !class.RequiresRunLock() {
			return
		}
		checked++
		run := n.Target.Addr().MethodByName("Run")
		if !run.IsValid() {
			t.Errorf("%s %s has no Run method", n.Parent.Name, n.Name)
			return
		}
		for i := 0; i < run.Type().NumIn(); i++ {
			if run.Type().In(i) == connType {
				return // it takes the Conn, so it goes through the provider — and the guard
			}
		}
		t.Errorf("%s %s is %s-class (it needs a bracket) but its Run does not take a *config.Conn — "+
			"it never passes the dispatch guard, so it could mutate the engine unbracketed",
			n.Parent.Name, n.Name, class)
	}
	walk(parser.Model.Node)

	if checked == 0 {
		t.Fatal("the coverage gate checked NO verbs — it is not gating anything")
	}
}

// holdBracket opens a real bracket on the fixture's key, as another lane would.
func holdBracket(t *testing.T, dir, key string) *mdriver.RunLock {
	t.Helper()
	ref, err := mdriver.DeriveRunLockRef(dir, key)
	if err != nil {
		t.Fatalf("derive ref: %v", err)
	}
	lock, err := mdriver.AcquireRunLock(context.Background(), mdriver.RunLockOptions{
		Client: fakeRefClient(ref), Dir: dir, Consumer: "m-ydb test",
	})
	if err != nil {
		t.Fatalf("acquire bracket: %v", err)
	}
	t.Cleanup(func() { _ = lock.Release() })
	return lock
}

func assertRefusal(t *testing.T, err error, wantCode string) {
	t.Helper()
	if err == nil {
		t.Fatalf("the driver PROCEEDED instead of refusing with %s", wantCode)
	}
	var ce *clikit.Error
	if !errors.As(err, &ce) {
		t.Fatalf("error %v is not a structured clikit.Error — a consumer cannot branch on it", err)
	}
	if ce.Code != wantCode {
		t.Errorf("code = %q, want %q", ce.Code, wantCode)
	}
	if ce.Exit != mdriver.ExitRunLockRefused {
		t.Errorf("exit = %d, want %d (the contract's refusal rung)", ce.Exit, mdriver.ExitRunLockRefused)
	}
}

func clikitCode(err error) string {
	var ce *clikit.Error
	if errors.As(err, &ce) {
		return ce.Code
	}
	return ""
}

// fakeRefClient is an SDK Client whose `meta runlock-path` answers from a fixed ref.
// AcquireRunLock asks the DRIVER for the key (R-3) and there is no driver subprocess
// in-process, so the test stands in for one.
func fakeRefClient(ref mdriver.RunLockRef) *mdriver.Client {
	return mdriver.NewClient("unused", "ydb", "local", nil,
		func(context.Context, string, []string) (stdout, stderr []byte, exit int, err error) {
			env := `{"schemaVersion":"1.0","command":"meta runlock-path","ok":true,"exit":0,` +
				`"data":{"key":"` + ref.Key + `","path":"` + ref.Path + `"}}`
			return []byte(env), nil, 0, nil
		})
}
