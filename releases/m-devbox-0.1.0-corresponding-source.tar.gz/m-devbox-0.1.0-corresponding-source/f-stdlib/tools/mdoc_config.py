"""mdoc_config.py — f-stdlib's RepoConfig for the shared mdoc core.

f-stdlib is the FOURTH consumer of the canonical parser core (m-stdlib
`tools/mdoc/`, stdlib-doc-accuracy Ph7) after m-stdlib, v-stdlib and v-web.
The f band adds NO vocabulary: FSL doc blocks use only the shared tag
registry (no VistA tags, no envelope hooks) — this file is deliberately
minimal and exists so f-specific knowledge, if any ever appears, has
exactly one home. NEVER fork the core: a parser fix lands in m-stdlib and
all consumers pick it up via the sibling path.
"""

from __future__ import annotations

from pathlib import Path

# The shared core package is resolved by the SHELL (gen-manifest.py) before
# this module is imported — mdoc is importable here by that point.
from mdoc import RepoConfig

REPO_ROOT = Path(__file__).resolve().parent.parent

CONFIG = RepoConfig(
    lib_name="fsl",
    repo_root=REPO_ROOT,
    src_glob="FSL*.m",
    manifest_filename="fsl-manifest.json",
    changelog_paths=("CHANGELOG.md",),
    strict=True,
)
