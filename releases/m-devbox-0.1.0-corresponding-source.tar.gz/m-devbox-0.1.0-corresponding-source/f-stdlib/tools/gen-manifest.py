#!/usr/bin/env python3
"""Parse src/FSL*.m into dist/fsl-manifest.json (4th mdoc consumer).

Thin SHELL over the canonical shared parser core — m-stdlib's `tools/mdoc/`
package, resolved from the SIBLING checkout (`MSTDLIB` env override,
org-layout default; a missing sibling is a HARD red, never a silent skip).
f-stdlib-specific knowledge lives in `tools/mdoc_config.py`. The parser is
STRICT; a core fix in m-stdlib's mdoc/ is picked up here with no hand-port
(editing mdoc/ itself is a CROSS-REPO seam change — regenerate + gate all
consumers).

Usage:
    python3 tools/gen-manifest.py --self-test   # shared mdoc corpus + f wiring checks
    python3 tools/gen-manifest.py               # strict parse; writes dist/
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
MSTDLIB = Path(os.environ.get("MSTDLIB", str(TOOLS_DIR.parents[1] / "m-stdlib")))
_core_marker = MSTDLIB / "tools" / "mdoc" / "core.py"
if not _core_marker.is_file():
    sys.exit(
        f"gen-manifest: canonical mdoc core not found at {_core_marker} — "
        f"clone m-stdlib beside this repo (workspace/repos.txt / bootstrap.sh) "
        f"or point MSTDLIB at a checkout."
    )
sys.path.insert(0, str(MSTDLIB / "tools"))
sys.path.insert(0, str(TOOLS_DIR))  # own dir FIRST so our mdoc_config wins
from mdoc import core, selftest  # noqa: E402
from mdoc_config import CONFIG  # noqa: E402

core.configure(CONFIG)

build_manifest = core.build_manifest  # for file-path importers (gen-docs.py)


def self_test() -> int:
    """The shared mdoc corpus, then f-stdlib config-wiring assertions."""
    rc = selftest.run(restore=CONFIG)
    if rc != 0:
        return rc

    failures: list[str] = []

    def expect(cond, msg):
        if not cond:
            failures.append(msg)

    expect(core.CONFIG is CONFIG and CONFIG.strict,
           "f-stdlib runs the STRICT parser")
    expect(CONFIG.src_glob == "FSL*.m", f"glob wrong: {CONFIG.src_glob}")
    expect(core.FOREIGN_TAGS == frozenset(),
           f"the f band adds no foreign tags: {core.FOREIGN_TAGS}")

    # The live corpus stays fully accounted under strict.
    core.PROBLEMS.clear()
    manifest, _errs = core.build_manifest()
    expect(core.PROBLEMS == [],
           f"strict parse of src/FSL*.m should be clean, got {core.PROBLEMS}")
    expect(core.UNACCOUNTED == [],
           f"every FSL col-1 label should be accounted, got {core.UNACCOUNTED}")
    expect(len(manifest["modules"]) == 7,
           f"Tier 0 is 7 modules, got {len(manifest['modules'])}")

    if failures:
        for f in failures:
            print(f"FAIL: {f}", file=sys.stderr)
        return 1
    print("self-test OK (shared mdoc corpus + f-stdlib config wiring; strict corpus clean)")
    return 0


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(description="Strict-parse src/FSL*.m into dist/fsl-manifest.json.")
    p.add_argument("--self-test", action="store_true",
                   help="Run the shared mdoc corpus + f-stdlib config-wiring checks and exit.")
    args = p.parse_args(argv)
    if args.self_test:
        return self_test()
    return core.run_generate()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
