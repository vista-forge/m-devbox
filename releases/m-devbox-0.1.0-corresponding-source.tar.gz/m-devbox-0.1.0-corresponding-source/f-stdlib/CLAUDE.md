# f-stdlib — repo rules (thin; adds to, never overrides, the org rules)

Org rules bind: `~/vista-forge/CLAUDE.md` (Increment Protocol, driver-stack
engine access, offline gates, TDD hard rule). This file adds only the
f-band specifics.

## What this repo is

**FSL — the FileMan Standard Library**, the `f` band of the m/f/v waterline:
`FSL*` routines that wrap FileMan's **documented DBS API** in JSON-shaped,
web-era calls. Placement test: *needs FileMan, needs nothing above it* —
runs on standalone FileMan (the `vista-fileman` seed), no Kernel, no VistA.

- Proposal (authoritative roster/charter): `docs` repo
  `proposals/fileman-stdlib/fileman-stdlib.md` (§4 roster, §5 tiers,
  §9 gates, §10 NOT-list).
- Tracker (single FSL-side ledger — update it at every code increment,
  coordinator-style): `docs` repo
  `proposals/fileman-stdlib/fileman-stdlib-tracker.md`.
- Per-repo memory: `docs/memory/` here, committed with the code.

## Layer = f — the waterline, both directions

- FSL **may call**: `STD*` (m-stdlib) and FileMan's documented API
  (`DI*` entry points, `^DD(`/`^DIC(` reads, `%DT`/`%DTC`).
- FSL **must never touch** Kernel/VistA: no `XU*`, `ZTM*`, `XM*`, `XPD*`
  routine calls; no `^XUSEC(`, `^VA(`, `^XTV(`, `^XMB(`, `^%ZTSK(` globals.
  `make arch` (`m arch check .`, in `make check`) enforces this: the band-aware
  f-band gate permits FileMan core (`^DIC`/`^DD`/`^DI*`/`%DT`) and forbids
  Kernel/KIDS/`^VSL`/VistA-app symbols. It superseded the interim
  `make waterline-grep` (f-band-arch-gate Phase C).
- Dependency is one-way downward (`v → f → m`): nothing in m-stdlib may
  call FSL; v-layer code consumes FSL, never the reverse.
- FileMan sits **beside** the band: FSL never modifies a `DI*` routine or
  a FileMan-owned file/DD system node (fixture DDs in the 999300+ probe
  block are test-only state, reset by `FSLFIX`).

## Engine floor

Suites run against a scratch standalone-FileMan YottaDB engine provisioned
by the sibling `vista-fileman` repo (`make floor` → container
`f-stdlib-test`). Engine access is **only** through the driver stack
(`m test/coverage --engine ydb --docker f-stdlib-test`, `m-ydb exec` under
`m runlock hold`). Never vehu/foia; never raw `docker exec`/`mumps`.

## Conventions

- Modern style (`mumps-modern-style`, pythonic-lower); the FileMan names FSL
  *calls* stay as documented (`UPDATE^DIE`, `$$GET1^DIQ`, …).
- TDD hard rule: `tests/<MODULE>TST.m` red first; stubs return safe defaults
  (`quit 0` / `""`), never `$ECODE`.
- Gates before commit: `make check` (fmt + lint zero errors + waterline
  grep + suites + per-module coverage ≥85 + docs gate), bare-run, rc
  captured.
- Every FSL call that can surface a FileMan error returns the one FSLERR
  envelope; nothing above FSL reads `^TMP("DIERR")` or `DIERR`.
- FSLIEN is **deferred** (P0 R-6(b) verdict) — do not scaffold it. Tier 1+
  modules (FSLTX/FSLREF), Tier 2 (FSLSCH/FSLMIG) and Tier 3 wait for their
  pulling milestones; the roster is closed (proposal §10).
