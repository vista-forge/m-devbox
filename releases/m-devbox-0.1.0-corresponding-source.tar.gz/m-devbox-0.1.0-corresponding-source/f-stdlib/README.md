# f-stdlib — FSL, the FileMan Standard Library

**FSL (`FSL*`)** is the `f` band of the vista-forge waterline: engine-resident
M routines that wrap VA FileMan's **documented DBS API** — once, well — in
JSON-shaped, web-era calls. It needs **standalone FileMan and nothing above
it**: no Kernel, no VistA packages. FileMan itself is never modified.

```
band  prefix  placement test                       stdlib
 m    STD*    runs on a bare M engine              m-stdlib (MSL)
 f    FSL*    + standalone FileMan, nothing above  f-stdlib (FSL)  ← this repo
 v    VSL*    + Kernel / VistA                     v-stdlib (VSL)
```

Dependency is one-way downward (`v → f → m`): FSL may call `STD*` and
FileMan's documented API (`DI*` entry points, `^DD`/`^DIC` reads); no `STD*`
routine touches FileMan and no `FSL*` routine touches Kernel/VistA.

Authoritative charter: the accepted **fileman-stdlib proposal** (`docs` repo,
`proposals/fileman-stdlib/fileman-stdlib.md`) — module roster §4, compat/strict
tiers §5, gates §9. First consumer: **fileman-freight**.

## Tier 0 modules (this repo, milestone M1/P1)

| Module | Provides |
|---|---|
| `FSLENV` | standalone environment seeding (`DUZ`, `DUZ(0)="@"`, `DT`, `U`, IO) — guarded: refuses where the environment is already owned (Kernel), never clobbers |
| `FSLERR` | the one error envelope `{"ok":true,"data":…}` / `{"ok":false,"errors":[{code,text,field}…]}`; translates **and clears** FileMan error state — nothing above FSL reads `^TMP("DIERR")` |
| `FSLDATE` | ISO 8601 ⇄ FileMan internal, both directions; explicit site-TZ offset; second granularity and imprecise dates stated, never fudged |
| `FSLDD` | DD introspection as JSON (files, fields, indexes, keys) — the codegen source; output shape frozen by golden tests |
| `FSLDB` | CRUD verbs over `UPDATE^DIE`/`GETS^DIQ`/`FILE^DIE`/`VALS^DIE`/`^DIK`; multiples as nested JSON, WP as string arrays; **delete checks inbound references first** (refuse \| cascade, explicit) |
| `FSLQ` | declarative reads on the FMQL model: `list` with `$ORDER` index-cursor pagination + compiled conjunction filters + an unindexed-scan guard rail (refuse, don't scan); `find` → `FIND^DIC` |
| `FSLFIX` | scratch-engine test fixtures (load/reset known files + records), honoring the managed-staging invariant |

`FSLDB` is the **compat tier**: bug-for-bug faithful to FileMan's documented
semantics (partial filing, advisory locks). The strict tier (`FSLTX`,
Tier 1) arrives at its pulling milestone with real transactions.

## What FSL is NOT (the anti-kitchen-sink charter, proposal §10)

FSL is **data plane only**. Permanently out of scope, with their owners:

| Not in FSL | Owner |
|---|---|
| Report/print formatting, captioned output | Go (render from FSLQ/FSLDB data) |
| Forms/UI engines (ScreenMan replacement) | Go/web, generated from FSLDD |
| Word-processing *editors* | any 2026 editor; FSL stores/serves the text |
| Import/export *formats* (CSV/JSON shaping) | Go, streaming over FSL reads/writes |
| Filegrams / record transport | the org's API surfaces |
| Archiving/purging, backup, retention | engine + OS/cloud |
| Audit *retention/immutability* | ops plane (journal-extract pipeline) |
| Identity/authn, sessions, TLS | host tier (Go/OIDC) — never M |
| SQL | engine lane (Octo via generated DD→DDL), consumer-pulled |
| Scheduling/background jobs | host (systemd/cron) or v-layer TaskMan |
| Vector/LLM/analytics anything | out of charter |

The roster is **closed**: adding a module requires amending the proposal.

## Developing

```bash
make floor        # provision the scratch standalone-FileMan engine (f-stdlib-test)
make test         # run suites through the driver stack (m test)
make coverage     # aggregate + per-module line coverage, floor 85%
make check        # the full offline gate (fmt + lint + waterline + suites + coverage + docs)
make floor-down   # tear the scratch engine down
```

Engine access is **only** via the driver stack (`m`/`m-ydb`); suites never
touch vehu/foia. See `CLAUDE.md` for the repo rules and the org `CLAUDE.md`
for the waterline + Increment Protocol.

## License

AGPL-3.0-or-later, dual-licensed with a commercial option (see `LICENSE`).
No VistA-M source enters this repo.
