# Changelog — f-stdlib (FSL)

## [0.1.0] — 2026-07-19

Initial Tier 0 (fileman-stdlib P1 / freight M1): FSLENV, FSLERR, FSLDATE,
FSLFIX, FSLDD, FSLDB, FSLQ — red→green on the scratch standalone-FileMan
floor; FSLDD JSON contract frozen by golden tests; FSLDB delete checks the
inbound-pointer registry first and carries the C-2 reindex repair; FSLQ
refuses unindexed scans and pages under the measured seam ceilings.
