FSLDATE ; f-stdlib — ISO 8601 <-> FileMan internal date/time.
 ; m-lint: disable-file=M-MOD-024 — definite-assignment false positives: paren multi-set, pattern-branch else-chains, and by-name FileMan output arrays (GETS/UPDATE fill locals the linter cannot see)
 ; doc: @tier core
 ;
 ; FM internal is YYYMMDD(.HHMMSS): YYY = year-1700, imprecise dates carry
 ; MM=00 and/or DD=00, time is SECOND granularity with trailing zeros
 ; trimmed, and carries NO timezone (gap G-8 — honestly bounded, never
 ; fudged). The mapping rules, stated:
 ;   - An ISO input with no offset is SITE-LOCAL wall time: converted
 ;     directly, no shifting.
 ;   - An ISO input carrying Z/+hh:mm REQUIRES the site-TZ argument
 ;     (minutes east of UTC) and is shifted to site wall time.
 ;   - fromFm() never shifts: the optional site-TZ argument only LABELS
 ;     the wall time with its offset suffix.
 ;   - Non-zero sub-second fractions are REJECTED (lossy), ".000" accepted.
 ;   - ISO midnight T00:00:00 maps to FileMan's previous-day .24
 ;     convention, and .24 maps back — round-trip clean.
 ; Invalid input returns "" — never a guess.
 ;
 quit
 ;
toFm(iso,tz) ; ISO 8601 -> FM internal; "" if invalid.
 ; doc: @param iso string ISO 8601: YYYY \| YYYY-MM \| YYYY-MM-DD [T HH:MM[:SS[.000]] [Z\|+hh:mm\|-hh:mm]]
 ; doc: @param tz number site offset, minutes east of UTC; REQUIRED iff iso carries an offset
 ; doc: @returns string FM internal YYYMMDD(.HHMMSS), imprecise forms preserved; "" invalid
 ; doc: @example write $$toFm^FSLDATE("2026-01-15T14:30:45")  ; "3260115.143045"
 ; doc: @example write $$toFm^FSLDATE("2026-01-15T23:30:00Z",-300)  ; "3260115.183"
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$fromFm^FSLDATE
 new date,time,off,y,mo,d,hh,mi,ss,frac,fmd,hms
 set iso=$get(iso)
 set date=$piece(iso,"T")
 set time=$piece(iso,"T",2)
 if iso["T",time="" quit ""
 ; date part: YYYY | YYYY-MM | YYYY-MM-DD
 if date?4N set y=+date,mo=0,d=0
 else  if date?4N1"-"2N set y=+$extract(date,1,4),mo=+$extract(date,6,7),d=0
 else  if date?4N1"-"2N1"-"2N set y=+$extract(date,1,4),mo=+$extract(date,6,7),d=+$extract(date,9,10)
 else  quit ""
 if y<1701!(y>9999) quit ""
 if mo>12 quit ""
 if mo=0,d>0 quit ""
 if d>0,'$$validDate^STDDATE(y,mo,d) quit ""
 if time="",(mo=0)!(d=0) quit (y-1700)*10000+(mo*100)+d
 if (mo=0)!(d=0) quit ""
 if time="" quit (y-1700)*10000+(mo*100)+d
 ; offset suffix: Z | +hh:mm | -hh:mm  (else site-local, no shift)
 set off=""
 if $extract(time,$length(time))="Z" do
 . set off=0
 . set time=$extract(time,1,$length(time)-1)
 else  if $length(time)>5,$extract(time,$length(time)-5)?1(1"+",1"-") do
 . new tail
 . set tail=$extract(time,$length(time)-5,$length(time))
 . if $extract(tail,2,6)?2N1":"2N do
 . . set off=($extract(tail,2,3)*60+$extract(tail,5,6))*$select($extract(tail)="-":-1,1:1)
 . . set time=$extract(time,1,$length(time)-6)
 if off'="",$get(tz)="" quit ""
 ; time part: HH:MM[:SS[.frac]] — frac must be all zeros (second granularity)
 set frac=$piece(time,".",2)
 if time["." do  quit:time="" ""
 . if frac'?1.N set time="" quit
 . if +frac'=0 set time="" quit
 . set time=$piece(time,".")
 if time?2N1":"2N set hh=+$extract(time,1,2),mi=+$extract(time,4,5),ss=0
 else  if time?2N1":"2N1":"2N set hh=+$extract(time,1,2),mi=+$extract(time,4,5),ss=+$extract(time,7,8)
 else  quit ""
 if hh>23!(mi>59)!(ss>59) quit ""
 ; shift to site wall time when the input carried an offset
 if off'="",off'=+$get(tz) do
 . new days,tot,sec
 . set days=$$civilToDays^STDDATE(y,mo,d)
 . set tot=days*86400+(hh*3600)+(mi*60)+ss+((+$get(tz)-off)*60)
 . set sec=tot#86400
 . set days=(tot-sec)/86400
 . do civilFromDays^STDDATE(days,.y,.mo,.d)
 . set hh=sec\3600
 . set mi=sec#3600\60
 . set ss=sec#60
 if y<1701!(y>9999) quit ""
 ; ISO midnight -> FileMan previous-day .24 convention
 if hh=0,mi=0,ss=0 do  quit fmd_".24"
 . new days
 . set days=$$civilToDays^STDDATE(y,mo,d)-1
 . do civilFromDays^STDDATE(days,.y,.mo,.d)
 . set fmd=(y-1700)*10000+(mo*100)+d
 set hms=$$pad2(hh)_$$pad2(mi)_$$pad2(ss)
 quit +(((y-1700)*10000+(mo*100)+d)_"."_hms)
 ;
fromFm(fm,tz) ; FM internal -> ISO 8601; "" if invalid.
 ; doc: @param fm string FM internal YYYMMDD(.HHMMSS); imprecise MM=00/DD=00 accepted
 ; doc: @param tz number optional site offset (minutes east of UTC) — LABELS the wall time with a suffix; no shifting
 ; doc: @returns string ISO 8601 (YYYY \| YYYY-MM \| YYYY-MM-DD \| ...THH:MM:SS[offset]); "" invalid
 ; doc: @example write $$fromFm^FSLDATE(3260115.143)  ; "2026-01-15T14:30:00"
 ; doc: @example write $$fromFm^FSLDATE(3260115.183,-300)  ; "2026-01-15T18:30:00-05:00"
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$toFm^FSLDATE
 new date,frac,y,mo,d,hh,mi,ss,out
 set fm=$get(fm)
 if fm="" quit ""
 if fm'?7N,fm'?7N1"."1.N quit ""
 set date=$piece(fm,".")
 set frac=$piece(fm,".",2)
 set y=$extract(date,1,3)+1700
 set mo=+$extract(date,4,5)
 set d=+$extract(date,6,7)
 if mo=0!(d=0) do  quit out
 . set out=""
 . if frac'="" quit
 . if mo=0,d'=0 quit
 . if mo>12 quit
 . set out=$$pad4(y)
 . if mo'=0 set out=out_"-"_$$pad2(mo)
 if '$$validDate^STDDATE(y,mo,d) quit ""
 if frac="" quit $$pad4(y)_"-"_$$pad2(mo)_"-"_$$pad2(d)
 set frac=$extract(frac_"000000",1,6)
 set hh=+$extract(frac,1,2)
 set mi=+$extract(frac,3,4)
 set ss=+$extract(frac,5,6)
 ; FileMan .24 = 24:00 = next-day ISO midnight
 if hh=24 do
 . new days
 . quit:mi'=0!(ss'=0)
 . set days=$$civilToDays^STDDATE(y,mo,d)+1
 . do civilFromDays^STDDATE(days,.y,.mo,.d)
 . set hh=0
 if hh>23!(mi>59)!(ss>59) quit ""
 set out=$$pad4(y)_"-"_$$pad2(mo)_"-"_$$pad2(d)_"T"_$$pad2(hh)_":"_$$pad2(mi)_":"_$$pad2(ss)
 if $get(tz)'="" set out=out_$$fmtOff(+tz)
 quit out
 ;
fmtOff(min) ; Format a minutes-east offset as Z / +HH:MM / -HH:MM.
 ; doc: @internal
 new a
 if min=0 quit "Z"
 set a=$select(min<0:-min,1:min)
 quit $select(min<0:"-",1:"+")_$$pad2(a\60)_":"_$$pad2(a#60)
 ;
pad2(n) ; Two-digit zero-pad.
 ; doc: @internal
 quit $select(n<10:"0"_+n,1:+n)
 ;
pad4(n) ; Four-digit zero-pad.
 ; doc: @internal
 new s
 set s=+n
 for  quit:$length(s)'<4  set s="0"_s
 quit s
