FSLDD ; f-stdlib — DD introspection as JSON (the codegen source).
 ; doc: @tier core
 ;
 ; Reads the data dictionary (^DD/^DIC — sanctioned f-band reads) and
 ; renders files, fields, indexes and keys as STDJSON trees / JSON text.
 ; The $$json() output shape is a CONTRACT — frozen by golden tests in
 ; FSLDDTST — because generated Go types and web forms derive from it.
 ;
 ; Field object (keys always in M collation order):
 ;   multiple  subfile number          (multiple/wp fields only)
 ;   name      field label
 ;   node      storage node (before ";")
 ;   number    field number
 ;   piece     storage piece (0 for multiple/wp)
 ;   pointer   target file number      (pointer fields only)
 ;   required  true/false ("R" flag)
 ;   set       [{code,label},...]      (set-of-codes fields only)
 ;   type      free-text|numeric|set|date|pointer|variable-pointer|
 ;             wp|multiple|computed|mumps|unknown
 ; Index object: {field,live,name,type} — `live` mirrors the
 ; ^DD(file,"IX",field) marker (a defined-but-unmarked x-ref is NOT
 ; filer-maintained: the P0b C-2 finding, surfaced honestly here).
 ; Key depth (fields per key) lands when a consumer pulls it.
 ;
 quit
 ;
json(file) ; File DD as JSON text (the frozen codegen contract).
 ; doc: @param file number FileMan file or subfile number
 ; doc: @returns string JSON object {fields,global,indexes,keys,name,number}; "" if no such file
 ; doc: @example write $$json^FSLDD(999301)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do file^FSLDD, do files^FSLDD
 new out
 do file(file,.out)
 if '$data(out) quit ""
 quit $$encode^STDJSON(.out)
 ;
file(file,out) ; File DD as an STDJSON tree.
 ; doc: @param file number FileMan file or subfile number
 ; doc: @param out array destination tree (by ref; killed first; left undefined if no such file)
 ; doc: @example new t do file^FSLDD(999300,.t)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$json^FSLDD, do field^FSLDD
 new fld,i,sub
 kill out
 if '$$exists(file) quit
 set out="o"
 set out("number")="n:"_+file
 set out("name")="s:"_$$name(file)
 set out("global")="s:"_$$root(file)
 set out("fields")="a"
 set i=0
 set fld=0
 for  set fld=$order(^DD(file,fld)) quit:fld=""!(+fld'=fld)  do
 . quit:'($data(^DD(file,fld,0))#10)
 . set i=i+1
 . kill sub
 . do field(file,fld,.sub)
 . merge out("fields",i)=sub
 do indexes(file,.sub)
 merge out("indexes")=sub
 do keys(file,.sub)
 merge out("keys")=sub
 quit
 ;
field(file,fld,out) ; One field's DD as an STDJSON tree.
 ; doc: @param file number FileMan file or subfile number
 ; doc: @param fld number field number
 ; doc: @param out array destination tree (by ref; killed first; undefined if no such field)
 ; doc: @example new t do field^FSLDD(999300,3,.t) write $get(t("type"))  ; "s:set"
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do file^FSLDD, $$fldnum^FSLDD
 new zero,flags,np,typ,i,pair
 kill out
 set zero=$get(^DD(file,fld,0))
 if zero="" quit
 set flags=$piece(zero,"^",2)
 set np=$piece(zero,"^",4)
 set out="o"
 set out("name")="s:"_$piece(zero,"^")
 set out("node")="s:"_$piece(np,";")
 set out("number")="n:"_+fld
 set out("piece")="n:"_+$piece(np,";",2)
 set out("required")=$select(flags["R":"t",1:"f")
 set typ=$$type(flags)
 set out("type")="s:"_typ
 if typ="wp"!(typ="multiple") set out("multiple")="n:"_+flags
 if typ="pointer" set out("pointer")="n:"_+$piece(flags,"P",2)
 if typ="set" do
 . new list,k,n
 . set list=$piece(zero,"^",3)
 . set out("set")="a"
 . set n=0
 . for k=1:1:$length(list,";") do
 . . quit:$piece(list,";",k)=""
 . . set n=n+1
 . . set out("set",n)="o"
 . . set out("set",n,"code")="s:"_$piece($piece(list,";",k),":")
 . . set out("set",n,"label")="s:"_$piece($piece(list,";",k),":",2)
 quit
 ;
files(out) ; All files on this engine as an STDJSON array of {global,name,number}.
 ; doc: @param out array destination tree (by ref; killed first)
 ; doc: @example new t do files^FSLDD(.t)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do file^FSLDD
 new f,i
 kill out
 set out="a"
 set i=0
 set f=0
 for  set f=$order(^DIC(f)) quit:f=""!(+f'=f)  do
 . quit:'($data(^DIC(f,0))#10)
 . quit:$data(^DD(f))<10
 . set i=i+1
 . set out(i)="o"
 . set out(i,"global")="s:"_$$root(f)
 . set out(i,"name")="s:"_$piece($get(^DIC(f,0)),"^")
 . set out(i,"number")="n:"_+f
 quit
 ;
fldnum(file,name) ; Resolve a field name or number to the field number.
 ; doc: @param file number FileMan file or subfile number
 ; doc: @param name string field name (as in the DD "B" index) or a field number
 ; doc: @returns number field number; "" when no such field
 ; doc: @example write $$fldnum^FSLDD(999300,"STATUS")  ; 3
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do field^FSLDD
 new fld
 set fld=""
 if name?.N!(name?.N1".".N)!(name?1".".N) do  quit fld
 . set fld=""
 . if $data(^DD(file,+name,0))#10 set fld=+name
 set fld=$order(^DD(file,"B",name,""))
 if fld'="" quit +fld
 quit ""
 ;
indexes(file,out) ; Index registry as an STDJSON array of {field,live,name,type}.
 ; doc: @param file number FileMan file or subfile number
 ; doc: @param out array destination tree (by ref; killed first)
 ; doc: @example new t do indexes^FSLDD(999300,.t)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do file^FSLDD
 ; doc: Traditional x-refs come from each field's ^DD(file,fld,1,n,0)
 ; doc: definitions; `live` is the ^DD(file,"IX",fld) marker (false =
 ; doc: defined but NOT filer-maintained — the C-2 hazard). New-style
 ; doc: indexes from ^DD(file,0,"IX",...) carry type "new".
 new i,fld,n,def,nm,f2
 kill out
 set out="a"
 set i=0
 set fld=0
 for  set fld=$order(^DD(file,fld)) quit:fld=""!(+fld'=fld)  do
 . set n=0
 . for  set n=$order(^DD(file,fld,1,n)) quit:n=""!(+n'=n)  do
 . . set def=$get(^DD(file,fld,1,n,0))
 . . quit:$piece(def,"^",2)=""
 . . set i=i+1
 . . set out(i)="o"
 . . set out(i,"field")="n:"_+fld
 . . set out(i,"live")=$select($data(^DD(file,"IX",fld))#10:"t",1:"f")
 . . set out(i,"name")="s:"_$piece(def,"^",2)
 . . set out(i,"type")="s:traditional"
 set nm=""
 for  set nm=$order(^DD(file,0,"IX",nm)) quit:nm=""  do
 . set f2=""
 . for  set f2=$order(^DD(file,0,"IX",nm,f2)) quit:f2=""  do
 . . set fld=""
 . . for  set fld=$order(^DD(file,0,"IX",nm,f2,fld)) quit:fld=""  do
 . . . set i=i+1
 . . . set out(i)="o"
 . . . set out(i,"field")="n:"_+fld
 . . . set out(i,"live")="t"
 . . . set out(i,"name")="s:"_nm
 . . . set out(i,"type")="s:new"
 quit
 ;
keys(file,out) ; Key registry (KEY file "F" index) as an STDJSON array.
 ; doc: @param file number FileMan file number
 ; doc: @param out array destination tree (by ref; killed first)
 ; doc: @example new t do keys^FSLDD(999300,.t)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do file^FSLDD
 ; doc: Walks ^DD("KEY","F",file,ien); emits {name,number} per key.
 ; doc: Key FIELD membership lands when a consumer pulls it.
 new i,ien
 kill out
 set out="a"
 set i=0
 set ien=""
 for  set ien=$order(^DD("KEY","F",file,ien)) quit:ien=""  do
 . set i=i+1
 . set out(i)="o"
 . set out(i,"name")="s:"_$piece($get(^DD("KEY",ien,0)),"^")
 . set out(i,"number")="n:"_+ien
 quit
 ;
exists(file) ; 1 iff the file/subfile has a DD.
 ; doc: @internal
 quit $data(^DD(+$get(file)))>1
 ;
name(file) ; File/subfile name (top level from ^DIC; subfile from its DD zero node).
 ; doc: @internal
 new nm
 set nm=$piece($get(^DIC(file,0)),"^")
 if nm="" set nm=$piece($get(^DD(file,0)),"^")
 quit nm
 ;
root(file) ; Data-global root ("" for subfiles — reached through the parent).
 ; doc: @internal
 quit $get(^DIC(file,0,"GL"))
 ;
type(flags) ; Decode the DD type-flag string to the FSL type taxonomy.
 ; doc: @internal
 new sub01
 set sub01=""
 if +flags>0 do  quit sub01
 . set sub01=$select($piece($get(^DD(+flags,.01,0)),"^",2)["W":"wp",1:"multiple")
 if flags["K" quit "mumps"
 if flags["V" quit "variable-pointer"
 if flags["P" quit "pointer"
 if flags["C" quit "computed"
 if flags["S" quit "set"
 if flags["D" quit "date"
 if flags["N" quit "numeric"
 if flags["F" quit "free-text"
 quit "unknown"
