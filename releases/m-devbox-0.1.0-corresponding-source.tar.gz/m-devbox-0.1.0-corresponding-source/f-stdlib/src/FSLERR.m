FSLERR ; f-stdlib — the one error envelope (translates + clears FM error state).
 ; doc: @tier core
 ;
 ; Every FSL surface returns exactly one JSON envelope shape:
 ;   success  {"data":<any>,"ok":true}
 ;   failure  {"errors":[{"code":C,"field":F,"text":T},...],"ok":false}
 ; built with STDJSON trees. The error object shape is FIXED (code/field/
 ; text always present; field "" when not field-level).
 ;
 ; FileMan's DBS error plumbing — the DIERR variable, the caller MSG_ROOT
 ; array (root("DIERR",...)), and ^TMP("DIERR",$J) when no MSG_ROOT was
 ; passed — is translated here and CLEARED here (CLEAN^DILF). Nothing
 ; above FSL ever reads ^TMP("DIERR") or DIERR again.
 ;
 ; Measured shape this translates (floor probe, FileMan 22.2):
 ;   root("DIERR")="n^m"        root("DIERR",i)=code
 ;   root("DIERR",i,"PARAM","FIELD")=field    root("DIERR",i,"TEXT",j)=line
 ;
 quit
 ;
ok(data) ; Success envelope around a caller-built STDJSON tree.
 ; doc: @param data array STDJSON tree (by ref); undefined -> data:null
 ; doc: @returns string JSON text {"data":...,"ok":true}
 ; doc: @example new d set d="s:hi" write $$ok^FSLERR(.d)  ; {"data":"hi","ok":true}
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$fail^FSLERR, $$wrap^FSLERR
 ; doc: The data key is always present — an undefined tree serialises as
 ; doc: null, so consumers get one stable shape.
 new env
 set env="o"
 set env("ok")="t"
 if $data(data) merge env("data")=data
 else  set env("data")="z"
 quit $$encode^STDJSON(.env)
 ;
fail(errs) ; Failure envelope around an error-list tree.
 ; doc: @param errs array STDJSON array tree of error objects (by ref; see add)
 ; doc: @returns string JSON text {"errors":[...],"ok":false}
 ; doc: @example new e do add^FSLERR(.e,401,"no such file","") write $$fail^FSLERR(.e)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do add^FSLERR, $$ok^FSLERR
 new env
 set env="o"
 set env("ok")="f"
 if $data(errs) merge env("errors")=errs
 else  set env("errors")="a"
 quit $$encode^STDJSON(.env)
 ;
add(errs,code,text,field) ; Append one error object to an error-list tree.
 ; doc: @param errs array STDJSON array tree (by ref; initialised on first add)
 ; doc: @param code string error code (FileMan DIERR number or FSL-* code)
 ; doc: @param text string human-readable message
 ; doc: @param field string field number when field-level; "" otherwise
 ; doc: @example new e do add^FSLERR(.e,701,"value is invalid",".01")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$fail^FSLERR, $$collect^FSLERR
 new i
 set errs="a"
 set i=$order(errs(""),-1)+1
 set errs(i)="o"
 set errs(i,"code")="s:"_code
 set errs(i,"field")="s:"_$get(field)
 set errs(i,"text")="s:"_text
 quit
 ;
collect(fmerr,errs) ; Translate FM error state into an error list; CLEAR it all.
 ; doc: @param fmerr array the MSG_ROOT array passed to the DBS call (by ref)
 ; doc: @param errs array STDJSON array tree the errors are appended to (by ref)
 ; doc: @returns number count of errors collected (0 = no error state)
 ; doc: @example new n,e set n=$$collect^FSLERR(.FMERR,.e) if n write $$fail^FSLERR(.e)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$wrap^FSLERR, $$pending^FSLERR, do clear^FSLERR
 ; doc: Reads fmerr("DIERR",...) (and, when the DBS call was made without a
 ; doc: MSG_ROOT, ^TMP("DIERR",$J)), appends one error object per entry,
 ; doc: then clears fmerr("DIERR") + DIERR + ^TMP("DIERR",$J) via CLEAN^DILF.
 ; doc: After collect() no FileMan error state survives anywhere.
 new n
 set n=$$fromRoot(.fmerr,.errs)
 if $data(^TMP("DIERR",$job)) do
 . new tmp
 . merge tmp=^TMP("DIERR",$job)
 . set n=n+$$fromNode(.tmp,.errs)
 kill fmerr("DIERR")
 do clear
 quit n
 ;
wrap(fmerr,data) ; One-shot envelope: failure if FM error state exists, else success.
 ; doc: @param fmerr array the MSG_ROOT array from the just-made DBS call (by ref)
 ; doc: @param data array STDJSON tree for the success case (by ref)
 ; doc: @returns string JSON envelope text; FM error state is cleared either way
 ; doc: @example do UPDATE^DIE("","FDA","IEN","FMERR") write $$wrap^FSLERR(.FMERR,.data)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$collect^FSLERR, $$ok^FSLERR, $$fail^FSLERR
 new errs,n
 set n=$$collect^FSLERR(.fmerr,.errs)
 if n quit $$fail(.errs)
 quit $$ok(.data)
 ;
pending() ; Predicate — does un-collected FileMan error state exist?
 ; doc: @returns bool 1 iff DIERR is set or ^TMP("DIERR",$J) has entries
 ; doc: @example if $$pending^FSLERR() do clear^FSLERR
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see do clear^FSLERR
 quit ($get(DIERR)'="")!($data(^TMP("DIERR",$job))>0)
 ;
clear ; Clear all FileMan error/dialog state (CLEAN^DILF).
 ; doc: @example do clear^FSLERR
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$pending^FSLERR
 ; doc: Kills DIERR, DIHELP, DIMSG and ^TMP("DIERR",$J) via FileMan's own
 ; doc: documented cleanup entry point.
 do CLEAN^DILF
 quit
 ;
fromRoot(fmerr,errs) ; Append errors from a MSG_ROOT array; return count.
 ; doc: @internal
 new sub
 if '$data(fmerr("DIERR")) quit 0
 kill sub
 merge sub=fmerr("DIERR")
 quit $$emit(.sub,.errs)
 ;
fromNode(tmp,errs) ; Append errors from a merged ^TMP("DIERR",$J) copy; return count.
 ; doc: @internal
 quit $$emit(.tmp,.errs)
 ;
emit(dierr,errs) ; Walk a DIERR-shaped subtree; append error objects; return count.
 ; doc: @internal
 ; doc: dierr(i)=code, dierr(i,"PARAM","FIELD")=field, dierr(i,"TEXT",j)=line.
 new i,n,code,field,text,j
 set n=0
 set i=0
 for  set i=$order(dierr(i)) quit:+i'=i!(i="")  do
 . set code=$get(dierr(i))
 . set field=$get(dierr(i,"PARAM","FIELD"))
 . set text=""
 . set j=0
 . for  set j=$order(dierr(i,"TEXT",j)) quit:+j'=j!(j="")  do
 . . set text=text_$select(text="":"",1:" ")_$get(dierr(i,"TEXT",j))
 . do add(.errs,code,text,field)
 . set n=n+1
 quit n
