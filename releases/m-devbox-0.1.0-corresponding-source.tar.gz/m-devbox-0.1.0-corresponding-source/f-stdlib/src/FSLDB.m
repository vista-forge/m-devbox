FSLDB ; f-stdlib — CRUD verbs over the FileMan DBS API (compat tier).
 ; m-lint: disable-file=M-MOD-024 — definite-assignment false positives: paren multi-set, pattern-branch else-chains, and by-name FileMan output arrays (GETS/UPDATE fill locals the linter cannot see)
 ; doc: @tier core
 ;
 ; The COMPAT tier: thin, bug-for-bug faithful to FileMan's documented
 ; filing semantics — PARTIAL FILING is possible on multi-part writes
 ; (scalars file, then WP, then multiples; an error midway leaves the
 ; earlier parts filed — exactly FileMan's own documented behavior, stated
 ; here, never papered over). Atomic units arrive with the strict tier
 ; (FSLTX, Tier 1). No locking is performed (advisory-lock discipline is
 ; the caller's, per the DG); use validate() for pre-flight checks.
 ;
 ; Value contract (typed, codegen-friendly — pairs with FSLDD):
 ;   in  (create/update): FileMan INTERNAL values (set codes, pointer
 ;       IENs, bare numbers) EXCEPT dates, which are ISO 8601 and are
 ;       converted via FSLDATE; WP fields = JSON string arrays; multiples
 ;       (create only) = JSON arrays of objects.
 ;   out (read, default): internal values, dates as ISO, numbers bare,
 ;       WP as string arrays, multiples as nested arrays (each entry
 ;       carries its "ien"); empty-valued fields are OMITTED.
 ;   out (read, flag "E"): FileMan external/display values throughout.
 ; MEASURED compat-tier truth: FileMan does NOT run input transforms on
 ; INTERNAL values (UPDATE^DIE/FILE^DIE file them as given) — that is the
 ; documented DBS contract, not an FSL bug. Pre-flight user input with
 ; validate() (VALS^DIE, external->internal) before filing.
 ; Every verb returns the FSLERR envelope; all FileMan error state is
 ; translated and cleared here.
 ;
 quit
 ;
create(file,json) ; File a new record (UPDATE^DIE + WP^DIE + subfile UPDATE^DIE).
 ; doc: @param file number FileMan file number
 ; doc: @param json string JSON object of field name/number -> typed value (see module doc)
 ; doc: @returns string envelope; ok data = {"ien":n}
 ; doc: @example write $$create^FSLDB(999301,"{""NAME"":""GEARS""}")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$update^FSLDB, $$read^FSLDB, $$delete^FSLDB
 ; doc: Compat tier: scalars file first, then WP, then multiple entries —
 ; doc: an error midway is reported but earlier parts remain filed.
 new tree,errs,data,FSLFDA,FSLWP,FSLSUB,FSLIEN,FSLI2,FSLFE,ien,fld
 if $data(^DD(+$get(file)))<10 do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 if '$$jparse(json,.tree,.errs) quit $$fail^FSLERR(.errs)
 do plan(+file,.tree,1,.FSLFDA,.FSLWP,.FSLSUB,.errs)
 if $data(errs) quit $$fail^FSLERR(.errs)
 do UPDATE^DIE("","FSLFDA","FSLIEN","FSLFE")
 if $data(FSLFE("DIERR")) quit $$wrap^FSLERR(.FSLFE,.data)
 set ien=+$get(FSLIEN(1))
 set fld=""
 for  set fld=$order(FSLWP(fld)) quit:fld=""  do  quit:$data(errs)
 . new FSLWPA
 . merge FSLWPA=FSLWP(fld)
 . do WP^DIE(+file,ien_",",fld,"K","FSLWPA","FSLFE")
 . if $data(FSLFE("DIERR")) do collectAdd(.FSLFE,.errs)
 if $data(errs) quit $$fail^FSLERR(.errs)
 if $data(FSLSUB) do  if $data(FSLFE("DIERR")) quit $$wrap^FSLERR(.FSLFE,.data)
 . new sub,seq,sf,FSLFDA2
 . set sub=""
 . for  set sub=$order(FSLSUB(sub)) quit:sub=""  do
 . . set seq=""
 . . for  set seq=$order(FSLSUB(sub,seq)) quit:seq=""  do
 . . . set sf=""
 . . . for  set sf=$order(FSLSUB(sub,seq,sf)) quit:sf=""  do
 . . . . set FSLFDA2(sub,"+"_seq_","_ien_",",sf)=FSLSUB(sub,seq,sf)
 . do UPDATE^DIE("","FSLFDA2","FSLI2","FSLFE")
 set data="o"
 set data("ien")="n:"_ien
 quit $$ok^FSLERR(.data)
 ;
read(file,ien,fields,flags) ; Read a record as typed JSON (GETS^DIQ).
 ; doc: @param file number FileMan file number
 ; doc: @param ien number record internal entry number
 ; doc: @param fields string GETS^DIQ field spec; "" = "**" (all, incl WP + multiples)
 ; doc: @param flags string "" = internal-typed values (dates ISO); "E" = FileMan external
 ; doc: @returns string envelope; ok data = the record object (+"ien")
 ; doc: @example write $$read^FSLDB(999300,1,"","")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$create^FSLDB, $$update^FSLDB
 ; doc: Multiples nest as arrays of objects (each with its "ien"); WP
 ; doc: fields are string arrays; empty-valued fields are omitted.
 new FSLGOT,FSLFE,data,iens,fspec,mode,fld,sub,none
 if $data(^DD(+$get(file)))<10 do  quit $$fail^FSLERR(.none)
 . do add^FSLERR(.none,"FSL-NOFILE","no such file: "_$get(file),"")
 set iens=+$get(ien)_","
 set fspec=$select($get(fields)="":"**",1:fields)
 set mode=$select($get(flags)["E":"E",1:"I")
 do GETS^DIQ(+file,iens,fspec,"IE","FSLGOT","FSLFE")
 if $data(FSLFE("DIERR")) quit $$wrap^FSLERR(.FSLFE,.none)
 set data="o"
 set fld=""
 for  set fld=$order(FSLGOT(+file,iens,fld)) quit:fld=""  do
 . new typ,name,v,i,j
 . set typ=$$ftype(+file,fld)
 . set name=$piece($get(^DD(+file,fld,0)),"^")
 . if typ="wp" do  quit
 . . set (i,j)=0
 . . for  set i=$order(FSLGOT(+file,iens,fld,i)) quit:i=""!(+i'=i)  do
 . . . set j=j+1
 . . . set data(name,j)="s:"_$get(FSLGOT(+file,iens,fld,i))
 . . set:j>0 data(name)="a"
 . set v=$get(FSLGOT(+file,iens,fld,mode))
 . if typ="date",mode="I" set v=$$fromFm^FSLDATE(v)
 . quit:v=""
 . set data(name)=$$jval(v)
 set sub=""
 for  set sub=$order(FSLGOT(sub)) quit:sub=""  do
 . quit:+sub=+file
 . new pf,name,si,j
 . set pf=$order(^DD(+file,"SB",sub,""))
 . quit:pf=""
 . set name=$piece($get(^DD(+file,pf,0)),"^")
 . set data(name)="a"
 . set j=0
 . set si=""
 . for  set si=$order(FSLGOT(sub,si)) quit:si=""  do
 . . new sf,v2,typ2,name2
 . . set j=j+1
 . . set data(name,j)="o"
 . . set data(name,j,"ien")="n:"_+si
 . . set sf=""
 . . for  set sf=$order(FSLGOT(sub,si,sf)) quit:sf=""  do
 . . . set typ2=$$ftype(sub,sf)
 . . . set name2=$piece($get(^DD(sub,sf,0)),"^")
 . . . set v2=$get(FSLGOT(sub,si,sf,mode))
 . . . if typ2="date",mode="I" set v2=$$fromFm^FSLDATE(v2)
 . . . quit:v2=""
 . . . set data(name,j,name2)=$$jval(v2)
 set data("ien")="n:"_+$get(ien)
 quit $$ok^FSLERR(.data)
 ;
update(file,ien,json) ; Edit scalar/WP fields of an existing record (FILE^DIE).
 ; doc: @param file number FileMan file number
 ; doc: @param ien number record internal entry number
 ; doc: @param json string JSON object of field -> typed value (internal; dates ISO; WP arrays)
 ; doc: @returns string envelope; ok data = {"updated":n}
 ; doc: @example write $$update^FSLDB(999300,2,"{""QTY"":6}")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$create^FSLDB, $$validate^FSLDB
 ; doc: Multiples are REFUSED (FSL-NOSUB) in the compat tier — subentry
 ; doc: editing is a planned strict-tier surface. WP content is replaced
 ; doc: wholesale (WP^DIE "K").
 new tree,errs,data,FSLFDA,FSLWP,FSLSUB,FSLFE,fld,cnt
 if $data(^DD(+$get(file)))<10 do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 if '$$jparse(json,.tree,.errs) quit $$fail^FSLERR(.errs)
 do plan(+file,.tree,0,.FSLFDA,.FSLWP,.FSLSUB,.errs)
 if '$data(errs),$data(FSLSUB) do add^FSLERR(.errs,"FSL-NOSUB","multiples are not editable via update() in the compat tier","")
 if $data(errs) quit $$fail^FSLERR(.errs)
 set cnt=0
 if $data(FSLFDA) do  if $data(FSLFE("DIERR")) quit $$wrap^FSLERR(.FSLFE,.data)
 . new FSLUPD,f2
 . set f2=""
 . for  set f2=$order(FSLFDA(+file,"+1,",f2)) quit:f2=""  do
 . . set FSLUPD(+file,+$get(ien)_",",f2)=FSLFDA(+file,"+1,",f2)
 . . set cnt=cnt+1
 . do FILE^DIE("","FSLUPD","FSLFE")
 set fld=""
 for  set fld=$order(FSLWP(fld)) quit:fld=""  do  quit:$data(errs)
 . new FSLWPA
 . merge FSLWPA=FSLWP(fld)
 . do WP^DIE(+file,+$get(ien)_",",fld,"K","FSLWPA","FSLFE")
 . if $data(FSLFE("DIERR")) do collectAdd(.FSLFE,.errs)
 . else  set cnt=cnt+1
 if $data(errs) quit $$fail^FSLERR(.errs)
 set data="o"
 set data("updated")="n:"_cnt
 quit $$ok^FSLERR(.data)
 ;
validate(file,ien,json) ; Validate EXTERNAL values without filing (VALS^DIE).
 ; doc: @param file number FileMan file number
 ; doc: @param ien number record context for the validation (screens etc.)
 ; doc: @param json string JSON object of field -> EXTERNAL (as-typed) value
 ; doc: @returns string envelope; ok data = {"internal":{field-name:internal,...}}
 ; doc: @example write $$validate^FSLDB(999300,2,"{""STATUS"":""INACTIVE""}")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$update^FSLDB
 new tree,errs,data,FSLEXT,FSLINT,FSLFE,k,fld,iens
 if $data(^DD(+$get(file)))<10 do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 if '$$jparse(json,.tree,.errs) quit $$fail^FSLERR(.errs)
 set iens=+$get(ien)_","
 set k=""
 for  set k=$order(tree(k)) quit:k=""  do
 . set fld=$$fldnum^FSLDD(+file,k)
 . if fld="" do add^FSLERR(.errs,"FSL-NOFIELD","no such field: "_k,k) quit
 . set FSLEXT(+file,iens,fld)=$$leaf(.tree,k)
 if $data(errs) quit $$fail^FSLERR(.errs)
 do VALS^DIE("","FSLEXT","FSLINT","FSLFE")
 if $data(FSLFE("DIERR")) quit $$wrap^FSLERR(.FSLFE,.data)
 set data="o"
 set data("internal")="o"
 set fld=""
 for  set fld=$order(FSLINT(+file,iens,fld)) quit:fld=""  do
 . set data("internal",$piece($get(^DD(+file,fld,0)),"^"))=$$jval($get(FSLINT(+file,iens,fld)))
 quit $$ok^FSLERR(.data)
 ;
delete(file,ien,policy) ; Reference-checked delete (^DIK last, never first).
 ; doc: @param file number FileMan file number
 ; doc: @param ien number record internal entry number
 ; doc: @param policy string "" \| "refuse" (default) \| "cascade"
 ; doc: @returns string envelope; ok data = {"deleted":[{file,ien},...]} in deletion order
 ; doc: @example write $$delete^FSLDB(999300,5,"")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$read^FSLDB, $$reindex^FSLDB
 ; doc: Walks the DD inbound-pointer registry ^DD(file,0,"PT") FIRST (the
 ; doc: G-5 closure: bare ^DIK never sweeps inbound pointers). refuse =
 ; doc: structured FSL-REFS failure naming a referencing record; cascade =
 ; doc: depth-first delete of referencers (depth cap 5), then the target.
 new root,errs,data,deleted,n,err
 set root=$$root^FSLDD(+$get(file))
 if root="" do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 if '$$recAt(root,+$get(ien)) do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOREC","no record "_+$get(ien)_" in file "_+file,"")
 set (n,err)=0
 do delRec(+file,+ien,$get(policy)="cascade",0,.deleted,.n,.err,.errs)
 if err quit $$fail^FSLERR(.errs)
 set data="o"
 merge data("deleted")=deleted
 quit $$ok^FSLERR(.data)
 ;
reindex(file) ; C-2 repair: reconstruct IX markers + IXALL^DIK + live-lookup verify.
 ; doc: @param file number FileMan file number
 ; doc: @returns string envelope; ok data = {"markers":n,"reindexed":true,"verified":0\|1}
 ; doc: @example write $$reindex^FSLDB(999300)
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$delete^FSLDB
 ; doc: The P0b C-2 finding: an applied DD can carry x-ref DEFINITIONS
 ; doc: without the ^DD(file,"IX",field) markers, leaving indexes dead to
 ; doc: the filer. This reconstructs the markers from the definitions,
 ; doc: re-cross-references the file (IXALL^DIK), then PROVES lookups are
 ; doc: live ($$FIND1^DIC on the first record) — verify, never assume.
 new root,errs,data,fld,m,DIK,DA,first,v,ien2,FSLFE,junk
 set root=$$root^FSLDD(+$get(file))
 if root="" do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 set m=0
 set fld=0
 for  set fld=$order(^DD(+file,fld)) quit:fld=""!(+fld'=fld)  do
 . quit:$order(^DD(+file,fld,1,0))=""
 . quit:$data(^DD(+file,"IX",fld))#10
 . set ^DD(+file,"IX",fld)=""
 . set m=m+1
 set DIK=root
 do IXALL^DIK
 set first=0
 ; m-lint: disable-next-line=M-MOD-036 — root is DD-derived (^DIC "GL"), the sanctioned FileMan indirection class
 for  set first=$order(@(root_first_")")) quit:first=""!(+first=first)
 set data="o"
 set data("markers")="n:"_m
 set data("reindexed")="t"
 if first="" set data("verified")="n:0" quit $$ok^FSLERR(.data)
 ; m-lint: disable-next-line=M-MOD-036 — DD-derived root
 set v=$piece($get(@(root_first_",0)")),"^")
 set ien2=$$FIND1^DIC(+file,"","QX",v,"","","FSLFE")
 do collectAdd(.FSLFE,.junk)
 if +ien2'>0 do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-VERIFY","reindex complete but $$FIND1^DIC cannot find """_v_""" — lookups are NOT live","")
 set data("verified")="n:1"
 quit $$ok^FSLERR(.data)
 ;
plan(file,tree,allowsub,fda,wp,subs,errs) ; JSON tree -> FDA/WP/subfile plans.
 ; doc: @internal
 ; doc: Scalars land in fda(file,"+1,",fld) (dates ISO->FM via FSLDATE);
 ; doc: WP arrays in wp(fld,line,0); multiples in subs(subfile,seq,subfld).
 new k,fld,typ,v
 set k=""
 for  set k=$order(tree(k)) quit:k=""  do
 . set fld=$$fldnum^FSLDD(file,k)
 . if fld="" do add^FSLERR(.errs,"FSL-NOFIELD","no such field: "_k,k) quit
 . set typ=$$ftype(file,fld)
 . if typ="wp" do  quit
 . . new i
 . . set i=""
 . . for  set i=$order(tree(k,i)) quit:i=""  set wp(fld,+i,0)=$$leaf2(.tree,k,i)
 . if typ="multiple" do  quit
 . . new sub,i,sk,sfld,sv
 . . set sub=+$piece($get(^DD(file,fld,0)),"^",2)
 . . set i=""
 . . for  set i=$order(tree(k,i)) quit:i=""  do
 . . . set sk=""
 . . . for  set sk=$order(tree(k,i,sk)) quit:sk=""  do
 . . . . set sfld=$$fldnum^FSLDD(sub,sk)
 . . . . if sfld="" do add^FSLERR(.errs,"FSL-NOFIELD","no such subfield: "_sk,k_"."_sk) quit
 . . . . set sv=$$leaf2(.tree,k,i,sk)
 . . . . if $$ftype(sub,sfld)="date" do  quit:sv=""
 . . . . . set sv=$$toFm^FSLDATE(sv)
 . . . . . if sv="" do add^FSLERR(.errs,"FSL-BADDATE","not a valid ISO 8601 date",k_"."_sk)
 . . . . set:sv'="" subs(sub,+i,sfld)=sv
 . set v=$$leaf(.tree,k)
 . if typ="date" do  quit:v=""
 . . set v=$$toFm^FSLDATE(v)
 . . if v="" do add^FSLERR(.errs,"FSL-BADDATE","not a valid ISO 8601 date",k)
 . set:v'="" fda(file,"+1,",fld)=v
 quit
 ;
delRec(file,ien,cascade,depth,deleted,n,err,errs) ; Recursive ref-checked delete.
 ; doc: @internal
 new f2,fld2,root2,np,nd,pc,rien,cnt,DIK,DA
 if depth>5 do add^FSLERR(.errs,"FSL-DEEP","cascade depth exceeds 5","") set err=1 quit
 set f2=""
 for  set f2=$order(^DD(file,0,"PT",f2)) quit:f2=""!err  do
 . set fld2=""
 . for  set fld2=$order(^DD(file,0,"PT",f2,fld2)) quit:fld2=""!err  do
 . . set root2=$$root^FSLDD(f2)
 . . if root2="" do add^FSLERR(.errs,"FSL-REFS","unscannable pointer registry entry (subfile #"_f2_")","") set err=1 quit
 . . set np=$piece($get(^DD(f2,fld2,0)),"^",4)
 . . set nd=$piece(np,";")
 . . set pc=+$piece(np,";",2)
 . . set (rien,cnt)=0
 . . for  set rien=$order(@(root2_rien_")")) quit:rien=""!(+rien'=rien)!err  do
 . . . set cnt=cnt+1
 . . . if cnt>10000 do add^FSLERR(.errs,"FSL-SCAN","inbound-reference scan cap exceeded on file "_f2,"") set err=1 quit
 . . . new val
 . . . set val=$piece($get(@(root2_rien_","_nd_")")),"^",pc)
 . . . quit:val=""!(+val'=+ien)
 . . . if 'cascade do  quit
 . . . . do add^FSLERR(.errs,"FSL-REFS","inbound reference(s) exist; policy=refuse — file "_f2_" field "_fld2_" ien "_rien,"")
 . . . . set err=1
 . . . do delRec(f2,rien,1,depth+1,.deleted,.n,.err,.errs)
 quit:err
 set DIK=$$root^FSLDD(file)
 set DA=ien
 do ^DIK
 set n=n+1
 set deleted="a"
 set deleted(n)="o"
 set deleted(n,"file")="n:"_file
 set deleted(n,"ien")="n:"_ien
 quit
 ;
jparse(json,tree,errs) ; Parse a JSON object argument; error on failure.
 ; doc: @internal
 new jok
 set jok=$$parse^STDJSON($get(json),.tree)
 if 'jok do add^FSLERR(.errs,"FSL-BADJSON","invalid JSON: "_$$lastError^STDJSON(),"") quit 0
 if $get(tree)'="o" do add^FSLERR(.errs,"FSL-BADJSON","expected a JSON object","") quit 0
 quit 1
 ;
leaf(tree,k) ; Scalar payload of tree(k) ("" for containers/literals).
 ; doc: @internal
 new tmp
 merge tmp=tree(k)
 quit $$valueOf^STDJSON(.tmp)
 ;
leaf2(tree,k,i,sk) ; Scalar payload of tree(k,i[,sk]).
 ; doc: @internal
 new tmp
 if $data(sk) merge tmp=tree(k,i,sk)
 else  merge tmp=tree(k,i)
 quit $$valueOf^STDJSON(.tmp)
 ;
ftype(file,fld) ; FSL type of a field (FSLDD taxonomy).
 ; doc: @internal
 quit $$type^FSLDD($piece($get(^DD(file,fld,0)),"^",2))
 ;
jval(v) ; STDJSON leaf for a value: canonical numbers bare, else string.
 ; doc: @internal
 quit $select(v=""!(v'=+v):"s:"_v,1:"n:"_v)
 ;
recAt(root,ien) ; 1 iff a record node exists at root(ien).
 ; doc: @internal
 ; m-lint: disable-next-line=M-MOD-036 — DD-derived root
 quit $data(@(root_+ien_")"))>0
 ;
collectAdd(fmerr,errs) ; Fold FM error state into errs (always clears).
 ; doc: @internal
 new junk
 set junk=$$collect^FSLERR(.fmerr,.errs)
 quit
