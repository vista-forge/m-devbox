FSLENV ; f-stdlib — standalone environment seeding (Kernel-absence made explicit).
 ; doc: @tier core
 ;
 ; Standalone FileMan reads a handful of environment variables that Kernel
 ; would normally own: DUZ (user), DUZ(0) (FileMan access code), DT (today,
 ; FM internal), U ("^"), and the IO device set. On a standalone engine
 ; nobody seeds them — init() does, once, in one documented place.
 ;
 ; The guard (proposal fileman-stdlib §7 promise 3): if the environment is
 ; already OWNED — DUZ or DT defined, i.e. Kernel (or any managing layer)
 ; has signed on — init() REFUSES and touches nothing. FSL never clobbers a
 ; managed environment; on a VistA system FSLENV is a no-op by construction.
 ;
 quit
 ;
init() ; Seed the standalone-FileMan environment; refuse if already owned.
 ; doc: @returns bool 1 = seeded; 0 = refused (DUZ or DT already defined — environment is owned)
 ; doc: @example if '$$init^FSLENV() write "environment already owned",!
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$seeded^FSLENV
 ; doc: Seeds, in the CALLER's scope (deliberately not NEWed): DUZ=1,
 ; doc: DUZ(0)="@" (the service identity, programmer access), U="^",
 ; doc: DT=today (FM internal, via DT^DICRW), and minimal IO defaults
 ; doc: (IO/IO(0)=$PRINCIPAL, IOM=80, IOSL=24). Refusal changes NOTHING.
 if $data(DUZ)!$data(DT) quit 0
 set DUZ=1
 set DUZ(0)="@"
 do DT^DICRW
 set IO=$principal
 set IO(0)=$principal
 set IOM=80
 set IOSL=24
 quit 1
 ;
seeded() ; Predicate — is the standalone environment fully seeded?
 ; doc: @returns bool 1 iff DUZ, DUZ(0), U and DT are all defined
 ; doc: @example if $$seeded^FSLENV() do  ; safe to call FileMan DBS APIs
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$init^FSLENV
 quit $data(DUZ)#10&($data(DUZ(0))#10)&($data(U)#10)&($data(DT)#10)
