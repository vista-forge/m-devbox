FSLQ ; f-stdlib — declarative reads on the FMQL model (list/find).
 ; m-lint: disable-file=M-MOD-024 — definite-assignment false positives: paren multi-set, pattern-branch else-chains, and by-name FileMan output arrays (GETS/UPDATE fill locals the linter cannot see)
 ; doc: @tier core
 ;
 ; Reads are declarative and index-driven (the FMQL model; the analysis's
 ; CQRS split): list() walks a NAMED, LIVE cross-reference with $ORDER
 ; cursor pagination and a compiled conjunction filter; find() wraps
 ; FIND^DIC. The guard rail is absolute: an unindexed walk is REFUSED
 ; (FSL-NOIDX), never attempted.
 ;
 ; Pagination respects the measured seam ceilings (P0 bench: request line
 ; INDRMAXLEN=32766; ~18KB JSON response budget): page size caps at 200
 ; items and ~16KB of payload, whichever comes first; the cursor is an
 ; OPAQUE token (base64 of index-value + ien) — callers must not parse it.
 ; Filters are `field op value` clauses conjoined with `&&`; ops
 ; = != > < >= <= ~ (contains), compiled against the DD (dates take ISO
 ; literals; numeric/pointer/date fields compare numerically). Filtering
 ; happens per index candidate — a filter never widens the scan, and a
 ; page call inspects at most 1000 candidates before returning a partial
 ; page with a cursor.
 ;
 quit
 ;
list(file,index,from,limit,dir,fields,filter) ; Cursor-paginated index walk.
 ; doc: @param file number FileMan file number
 ; doc: @param index string x-ref name; "" = "B"; must be a LIVE index (else FSL-NOIDX)
 ; doc: @param from string opaque cursor from a previous page ("" = start)
 ; doc: @param limit number max items (default 20, cap 200; byte cap ~16KB applies too)
 ; doc: @param dir string "+" ascending (default) \| "-" descending
 ; doc: @param fields string comma list of scalar fields to hydrate per item (GETS^DIQ)
 ; doc: @param filter string `field op value [&& ...]` conjunction compiled against the DD
 ; doc: @returns string envelope; ok data = {"cursor":c,"items":[{ien,value,...}],"more":0\|1}
 ; doc: @example write $$list^FSLQ(999300,"ST","",10,"","QTY","STATUS = A")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$find^FSLQ
 new errs,data,root,fld,pref,dr,lim,v0,i0,v,i,resume,done,more,cnt,scans,bytes
 new lastv,lasti,cf,ncf,fh,nfh,fspec,items,ni
 set root=$$root^FSLDD(+$get(file))
 if root="" do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"") quit $$fail^FSLERR(.errs)
 set index=$select($get(index)="":"B",1:index)
 set fld=$$ixfld(+file,index)
 if fld="" do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOIDX","no live index """_index_""" on file "_+file_" — unindexed scans are refused","")
 do cfilter(+file,$get(filter),.cf,.ncf,.errs)
 do cfields(+file,$get(fields),.fh,.nfh,.fspec,.errs)
 if $data(errs) quit $$fail^FSLERR(.errs)
 set dr=$select($get(dir)="-":-1,1:1)
 set lim=+$get(limit)
 if lim<1 set lim=20
 if lim>200 set lim=200
 set (v0,i0)=""
 if $get(from)'="" do
 . new raw
 . set raw=$$decode^STDB64(from)
 . set v0=$piece(raw,$char(9))
 . set i0=$piece(raw,$char(9),2)
 set pref=root_$$q(index)
 set resume=(v0'="")
 set (done,more,cnt,scans,bytes)=0
 set (lastv,lasti)=""
 set ni=0
 if resume set v=v0
 ; m-lint: disable-next-line=M-MOD-036 — pref is DD-derived (^DIC "GL" + index name), the sanctioned FileMan indirection class
 else  set v=$order(@(pref_","_$$q("")_")"),dr)
 set i=$select(resume:i0,1:"")
 for  quit:v=""!done  do
 . for  set i=$order(@(pref_","_$$q(v)_","_$$q(i)_")"),dr) quit:i=""!done  do
 . . set scans=scans+1
 . . if scans>1000 set done=1,more=1 quit
 . . set lastv=v
 . . set lasti=i
 . . quit:'$$feval(root,i,.cf,ncf)
 . . do emit(+file,i,v,.items,.ni,.fh,nfh,fspec,.bytes)
 . . set cnt=cnt+1
 . . if cnt'<lim!(bytes>16000) set done=1,more=1
 . quit:done
 . set v=$order(@(pref_","_$$q(v)_")"),dr)
 . set i=""
 set data="o"
 set data("cursor")="s:"_$select(more:$$encode^STDB64(lastv_$char(9)_lasti),1:"")
 set data("items")="a"
 merge data("items")=items
 set data("more")="n:"_more
 quit $$ok^FSLERR(.data)
 ;
find(file,value,index,limit) ; Lookup via FIND^DIC.
 ; doc: @param file number FileMan file number
 ; doc: @param value string lookup value (FIND^DIC "QX" semantics — exact)
 ; doc: @param index string index(es) to search; "" = FileMan default
 ; doc: @param limit number max records ("" = all)
 ; doc: @returns string envelope; ok data = {"count":n,"items":[{ien,value}],"more":0\|1}
 ; doc: @example write $$find^FSLQ(999300,"HAMMER","","")
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$list^FSLQ
 new errs,data,FSLQL,FSLQE,n,cnt,morefl,lim
 if $data(^DD(+$get(file)))<10 do  quit $$fail^FSLERR(.errs)
 . do add^FSLERR(.errs,"FSL-NOFILE","no such file: "_$get(file),"")
 set lim=$select(+$get(limit)>0:+limit,1:"*")
 do FIND^DIC(+file,"","@;.01","QX",$get(value),lim,$get(index),"","","FSLQL","FSLQE")
 if $data(FSLQE("DIERR")) quit $$wrap^FSLERR(.FSLQE,.data)
 set cnt=+$piece($get(FSLQL("DILIST",0)),"^")
 set morefl=+$piece($get(FSLQL("DILIST",0)),"^",3)
 set data="o"
 set data("count")="n:"_cnt
 set data("items")="a"
 set n=0
 for  set n=$order(FSLQL("DILIST",2,n)) quit:n=""  do
 . set data("items",n)="o"
 . set data("items",n,"ien")="n:"_+$get(FSLQL("DILIST",2,n))
 . set data("items",n,"value")=$$jv($get(FSLQL("DILIST","ID",n,.01)))
 set data("more")="n:"_morefl
 quit $$ok^FSLERR(.data)
 ;
ixfld(file,index) ; Field carrying a LIVE traditional x-ref named `index`; "" if none.
 ; doc: @internal
 ; doc: Live = definition present AND the ^DD(file,"IX",fld) marker set
 ; doc: (the C-2 lesson: definition without marker is a dead index).
 new fld,n,hit
 set hit=""
 set fld=0
 for  set fld=$order(^DD(file,fld)) quit:fld=""!(+fld'=fld)!(hit'="")  do
 . quit:'($data(^DD(file,"IX",fld))#10)
 . set n=0
 . for  set n=$order(^DD(file,fld,1,n)) quit:n=""!(+n'=n)!(hit'="")  do
 . . if $piece($get(^DD(file,fld,1,n,0)),"^",2)=index set hit=fld
 quit hit
 ;
cfilter(file,filter,cf,ncf,errs) ; Compile the &&-conjunction against the DD.
 ; doc: @internal
 new j,c,fname,op,val,fld,typ,np
 set ncf=0
 quit:$get(filter)=""
 for j=1:1:$length(filter,"&&") do
 . set c=$$trim($piece(filter,"&&",j))
 . quit:c=""
 . set fname=$piece(c," ")
 . set op=$piece(c," ",2)
 . set val=$$trim($piece(c," ",3,99))
 . set fld=$$fldnum^FSLDD(file,fname)
 . if fld="" do add^FSLERR(.errs,"FSL-NOFIELD","no such filter field: "_fname,fname) quit
 . if "~=~!=~>~<~>=~<=~~~"'[("~"_op_"~") do add^FSLERR(.errs,"FSL-BADOP","unknown filter operator: "_op,fname) quit
 . set typ=$$type^FSLDD($piece($get(^DD(file,fld,0)),"^",2))
 . if typ="date" do  quit:$data(errs)
 . . set val=$$toFm^FSLDATE(val)
 . . if val="" do add^FSLERR(.errs,"FSL-BADDATE","filter date literal is not ISO 8601",fname)
 . set np=$piece($get(^DD(file,fld,0)),"^",4)
 . set ncf=ncf+1
 . set cf(ncf,"ndx")=$select($piece(np,";")=+$piece(np,";"):$piece(np,";"),1:$$q($piece(np,";")))
 . set cf(ncf,"pc")=+$piece(np,";",2)
 . set cf(ncf,"op")=op
 . set cf(ncf,"val")=val
 . set cf(ncf,"num")=(typ="numeric")!(typ="pointer")!(typ="date")
 quit
 ;
cfields(file,fields,fh,nfh,fspec,errs) ; Compile the hydration field list.
 ; doc: @internal
 new j,fname,fld,typ
 set nfh=0
 set fspec=""
 quit:$get(fields)=""
 for j=1:1:$length(fields,",") do
 . set fname=$$trim($piece(fields,",",j))
 . quit:fname=""
 . set fld=$$fldnum^FSLDD(file,fname)
 . if fld="" do add^FSLERR(.errs,"FSL-NOFIELD","no such field: "_fname,fname) quit
 . set typ=$$type^FSLDD($piece($get(^DD(file,fld,0)),"^",2))
 . if typ="wp"!(typ="multiple") do add^FSLERR(.errs,"FSL-NOSUB","list() hydrates scalar fields only: "_fname,fname) quit
 . set nfh=nfh+1
 . set fh(nfh,"fld")=fld
 . set fh(nfh,"name")=$piece($get(^DD(file,fld,0)),"^")
 . set fh(nfh,"typ")=typ
 . set fspec=fspec_$select(fspec="":"",1:";")_fld
 quit
 ;
feval(root,ien,cf,ncf) ; 1 iff record `ien` passes every compiled clause.
 ; doc: @internal
 new j,raw,op,val,pass
 set pass=1
 for j=1:1:ncf quit:'pass  do
 . ; m-lint: disable-next-line=M-MOD-036 — root is DD-derived (^DIC "GL")
 . set raw=$piece($get(@(root_ien_","_cf(j,"ndx")_")")),"^",cf(j,"pc"))
 . set op=cf(j,"op")
 . set val=cf(j,"val")
 . if cf(j,"num") do  quit
 . . if op="=" set pass=(+raw=+val)&(raw'="") quit
 . . if op="!=" set pass='((+raw=+val)&(raw'="")) quit
 . . if op=">" set pass=(raw'="")&(+raw>+val) quit
 . . if op="<" set pass=(raw'="")&(+raw<+val) quit
 . . if op=">=" set pass=(raw'="")&(+raw'<+val) quit
 . . if op="<=" set pass=(raw'="")&(+raw'>+val) quit
 . . if op="~" set pass=(raw[val) quit
 . . set pass=0
 . if op="=" set pass=(raw=val) quit
 . if op="!=" set pass=(raw'=val) quit
 . if op="~" set pass=(raw[val) quit
 . if op=">" set pass=(raw]]val) quit
 . if op="<" set pass=(val]]raw) quit
 . if op=">=" set pass='(val]]raw) quit
 . if op="<=" set pass='(raw]]val) quit
 . set pass=0
 quit pass
 ;
emit(file,ien,v,items,ni,fh,nfh,fspec,bytes) ; Append one item (+hydration).
 ; doc: @internal
 new FSLQG,FSLQE,j,hv,junk
 set ni=ni+1
 set items(ni)="o"
 set items(ni,"ien")="n:"_+ien
 set items(ni,"value")=$$jv(v)
 set bytes=bytes+$length(v)+24
 quit:nfh<1
 do GETS^DIQ(file,ien_",",fspec,"IE","FSLQG","FSLQE")
 if $data(FSLQE("DIERR")) do  quit
 . new e2
 . set junk=$$collect^FSLERR(.FSLQE,.e2)
 for j=1:1:nfh do
 . set hv=$get(FSLQG(file,ien_",",fh(j,"fld"),"I"))
 . if fh(j,"typ")="date" set hv=$$fromFm^FSLDATE(hv)
 . quit:hv=""
 . set items(ni,fh(j,"name"))=$$jv(hv)
 . set bytes=bytes+$length(hv)+$length(fh(j,"name"))+6
 quit
 ;
q(s) ; Quote a string as an M subscript literal (doubling embedded quotes).
 ; doc: @internal
 new out,j,c
 set out=""""
 for j=1:1:$length(s) do
 . set c=$extract(s,j)
 . set out=out_$select(c="""":"""""",1:c)
 quit out_""""
 ;
trim(s) ; Strip leading/trailing spaces.
 ; doc: @internal
 new a,b
 set a=1
 set b=$length(s)
 for  quit:a>b!($extract(s,a)'=" ")  set a=a+1
 for  quit:b<a!($extract(s,b)'=" ")  set b=b-1
 quit $extract(s,a,b)
 ;
jv(v) ; STDJSON leaf: canonical numbers bare, else string.
 ; doc: @internal
 quit $select(v=""!(v'=+v):"s:"_v,1:"n:"_v)
