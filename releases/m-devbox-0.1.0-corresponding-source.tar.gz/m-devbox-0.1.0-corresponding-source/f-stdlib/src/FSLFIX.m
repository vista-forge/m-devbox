FSLFIX ; f-stdlib — scratch-engine test fixtures (the FileMan STDFIX analog).
 ; doc: @tier core
 ;
 ; Builds the FSL test fixture on a SCRATCH standalone-FileMan engine:
 ;   #999300 ZFSL WIDGET   ^ZFSL(999300,  .01 NAME (RF, B x-ref) · 1 CODE (F)
 ;                         · 2 QTY (NJ) · 3 STATUS (set, ST x-ref) · 4 WHEN (D)
 ;                         · 5 CAT (P -> #999301) · 6 NOTES (WP) · 7 ITEMS
 ;                         (multiple #999300.07: .01 ITEM + 1 SUBQTY)
 ;   #999301 ZFSL CATEGORY ^ZFSL(999301,  .01 NAME (RF, B x-ref)
 ; with the inbound-pointer registry node ^DD(999301,0,"PT",999300,5) the
 ; FSLDB delete check walks. Records seed deterministically (widgets 1..5,
 ; categories 1..2) through the documented DBS API only — x-refs stay live.
 ;
 ; Managed-staging invariant: everything this module writes lives under
 ; ^ZFSL, ^DD(9993*)/^DIC(9993*) and the fixture ^DIC("B") names; remove()
 ; deletes exactly that set. Core FileMan is never touched.
 ;
 quit
 ;
install() ; Ensure fixture DDs exist, then seed records; 1 = ready.
 ; doc: @returns bool 1 = fixture DDs present + seed records loaded; 0 = filing error
 ; doc: @example if '$$install^FSLFIX() write "fixture install failed",!
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$reset^FSLFIX, $$installed^FSLFIX, do remove^FSLFIX
 ; doc: Idempotent: DDs are (re)built only when absent; records are always
 ; doc: reset to the deterministic seed state.
 if '$$installed() do buildDd
 quit $$reset()
 ;
installed() ; Predicate — are the fixture DDs present?
 ; doc: @returns bool 1 iff both fixture file DDs exist
 ; doc: @example if $$installed^FSLFIX() do  ; fixture-dependent suite may run
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$install^FSLFIX
 new have
 set have=($data(^DD(999300,.01,0))>0)&($data(^DD(999301,.01,0))>0)
 quit have&($get(^ZFSLFIX("ddv"))=$$ddv())
 ;
reset() ; Reset fixture DATA to the deterministic seed state; 1 = ok.
 ; doc: @returns bool 1 = seed state restored; 0 = a seed filing errored
 ; doc: @example if '$$reset^FSLFIX() write "fixture reset failed",!
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$install^FSLFIX
 ; doc: Kills the fixture data globals (DDs kept), re-creates the file
 ; doc: headers, and re-files categories 1..2 + widgets 1..5 (widget 1
 ; doc: carries WP NOTES + two ITEMS entries) via UPDATE^DIE / WP^DIE.
 new ok
 kill ^ZFSL
 set ^ZFSL(999300,0)="ZFSL WIDGET^999300^0^0"
 set ^ZFSL(999301,0)="ZFSL CATEGORY^999301^0^0"
 set ok=1
 if '$$cat("TOOLS") set ok=0
 if ok,'$$cat("PARTS") set ok=0
 if ok,'$$widget("HAMMER","AAA",10,"A",3260110,1) set ok=0
 if ok,'$$widget("WRENCH","BBB",5,"A",3260111.09,1) set ok=0
 if ok,'$$widget("GADGET","CCC",0,"I","",2) set ok=0
 if ok,'$$widget("ANVIL","DDD",25,"A",3260112,2) set ok=0
 if ok,'$$widget("PLIERS","EEE",7,"I",3260113,1) set ok=0
 if ok,'$$notes() set ok=0
 if ok,'$$items() set ok=0
 quit ok
 ;
remove ; Delete the fixture entirely (DDs + data + name-index entries).
 ; doc: @example do remove^FSLFIX
 ; doc: @since v0.1.0
 ; doc: @stable stable
 ; doc: @see $$install^FSLFIX
 kill ^ZFSL
 kill ^DD(999300),^DD(999300.06),^DD(999300.07),^DD(999301)
 kill ^DIC(999300),^DIC(999301)
 kill ^DIC("B","ZFSL WIDGET"),^DIC("B","ZFSL CATEGORY")
 kill ^ZFSLFIX
 quit
 ;
ddv() ; Fixture DD shape version — bump on any buildDd change.
 ; doc: @internal
 quit 3
 ;
buildDd ; Emit the fixture DDs (FMPRB-style test-only emit; core FM untouched).
 ; doc: @internal
 kill ^DD(999300),^DD(999300.06),^DD(999300.07),^DD(999301)
 kill ^DIC(999300),^DIC(999301)
 set ^ZFSLFIX("ddv")=$$ddv()
 ; --- #999301 ZFSL CATEGORY ---------------------------------------
 set ^DIC(999301,0)="ZFSL CATEGORY^999301"
 set ^DIC(999301,0,"GL")="^ZFSL(999301,"
 set ^DIC("B","ZFSL CATEGORY",999301)=""
 set ^DD(999301,0)="ZFSL CATEGORY^L^.01^1"
 set ^DD(999301,.01,0)="NAME^RF^^0;1^K:$L(X)>30!($L(X)<1) X"
 set ^DD(999301,.01,1,0)="^.1"
 set ^DD(999301,.01,1,1,0)="999301^B"
 set ^DD(999301,.01,1,1,1)="S ^ZFSL(999301,""B"",$E(X,1,30),DA)="""""
 set ^DD(999301,.01,1,1,2)="K ^ZFSL(999301,""B"",$E(X,1,30),DA)"
 set ^DD(999301,"B","NAME",.01)=""
 set ^DD(999301,"IX",.01)=""
 set ^DD(999301,"RQ",.01)=""
 set ^DD(999301,"GL",0,1,.01)=""
 ; inbound-pointer registry: WIDGET field 5 points here (FSLDB delete walk)
 set ^DD(999301,0,"PT",999300,5)=""
 ; --- #999300 ZFSL WIDGET -----------------------------------------
 set ^DIC(999300,0)="ZFSL WIDGET^999300"
 set ^DIC(999300,0,"GL")="^ZFSL(999300,"
 set ^DIC("B","ZFSL WIDGET",999300)=""
 set ^DD(999300,0)="ZFSL WIDGET^L^7^8"
 set ^DD(999300,.01,0)="NAME^RF^^0;1^K:$L(X)>30!($L(X)<1) X"
 set ^DD(999300,.01,1,0)="^.1"
 set ^DD(999300,.01,1,1,0)="999300^B"
 set ^DD(999300,.01,1,1,1)="S ^ZFSL(999300,""B"",$E(X,1,30),DA)="""""
 set ^DD(999300,.01,1,1,2)="K ^ZFSL(999300,""B"",$E(X,1,30),DA)"
 set ^DD(999300,1,0)="CODE^F^^1;1^K:$L(X)>10 X"
 set ^DD(999300,2,0)="QTY^NJ6,0^^2;1^K:+X'=X!(X>999999)!(X<0)!(X?.E1""."".E) X"
 set ^DD(999300,3,0)="STATUS^S^A:ACTIVE;I:INACTIVE;^3;1^Q"
 set ^DD(999300,3,1,0)="^.1"
 set ^DD(999300,3,1,1,0)="999300^ST"
 set ^DD(999300,3,1,1,1)="S ^ZFSL(999300,""ST"",$E(X,1,30),DA)="""""
 set ^DD(999300,3,1,1,2)="K ^ZFSL(999300,""ST"",$E(X,1,30),DA)"
 set ^DD(999300,4,0)="WHEN^D^^4;1^S %DT=""EX"" D ^%DT S X=Y K:Y<1 X"
 set ^DD(999300,5,0)="CAT^P999301'^ZFSL(999301,^5;1^Q"
 set ^DD(999300,6,0)="NOTES^999300.06^^6;0"
 set ^DD(999300,7,0)="ITEMS^999300.07^^7;0"
 ; subfile registry — FileMan derives subfile data roots through these
 set ^DD(999300,"SB",999300.06,6)=""
 set ^DD(999300,"SB",999300.07,7)=""
 set ^DD(999300,"B","NAME",.01)=""
 set ^DD(999300,"B","CODE",1)=""
 set ^DD(999300,"B","QTY",2)=""
 set ^DD(999300,"B","STATUS",3)=""
 set ^DD(999300,"B","WHEN",4)=""
 set ^DD(999300,"B","CAT",5)=""
 set ^DD(999300,"B","NOTES",6)=""
 set ^DD(999300,"B","ITEMS",7)=""
 set ^DD(999300,"IX",.01)=""
 set ^DD(999300,"IX",3)=""
 set ^DD(999300,"RQ",.01)=""
 set ^DD(999300,"GL",0,1,.01)=""
 set ^DD(999300,"GL",1,1,1)=""
 set ^DD(999300,"GL",2,1,2)=""
 set ^DD(999300,"GL",3,1,3)=""
 set ^DD(999300,"GL",4,1,4)=""
 set ^DD(999300,"GL",5,1,5)=""
 set ^DD(999300,"GL",6,0,6)=""
 set ^DD(999300,"GL",7,0,7)=""
 ; --- #999300.06 NOTES (word-processing subfile) ------------------
 set ^DD(999300.06,0)="NOTES SUB-FIELD^^.01^1"
 set ^DD(999300.06,0,"UP")=999300
 set ^DD(999300.06,0,"NM","NOTES")=""
 set ^DD(999300.06,.01,0)="NOTES^W^^0;1^Q"
 set ^DD(999300.06,"B","NOTES",.01)=""
 set ^DD(999300.06,"GL",0,1,.01)=""
 ; --- #999300.07 ITEMS (multiple) ---------------------------------
 set ^DD(999300.07,0)="ITEMS SUB-FIELD^^1^2"
 set ^DD(999300.07,0,"UP")=999300
 set ^DD(999300.07,0,"NM","ITEMS")=""
 set ^DD(999300.07,.01,0)="ITEM^MF^^0;1^K:$L(X)>20!($L(X)<1) X"
 set ^DD(999300.07,.01,1,0)="^.1"
 set ^DD(999300.07,.01,1,1,0)="999300.07^B"
 set ^DD(999300.07,.01,1,1,1)="S ^ZFSL(999300,DA(1),7,""B"",$E(X,1,30),DA)="""""
 set ^DD(999300.07,.01,1,1,2)="K ^ZFSL(999300,DA(1),7,""B"",$E(X,1,30),DA)"
 set ^DD(999300.07,1,0)="SUBQTY^NJ6,0^^0;2^K:+X'=X!(X>999999)!(X<0) X"
 set ^DD(999300.07,"B","ITEM",.01)=""
 set ^DD(999300.07,"B","SUBQTY",1)=""
 set ^DD(999300.07,"IX",.01)=""
 set ^DD(999300.07,"GL",0,1,.01)=""
 set ^DD(999300.07,"GL",0,2,1)=""
 quit
 ;
cat(name) ; File one category; 1 = ok.
 ; doc: @internal
 new FSLFDA,FSLIEN,FSLFE
 set FSLFDA(999301,"+1,",.01)=name
 do UPDATE^DIE("","FSLFDA","FSLIEN","FSLFE")
 quit $$clean(.FSLFE)
 ;
widget(name,code,qty,status,when,catien) ; File one widget; 1 = ok.
 ; doc: @internal
 new FSLFDA,FSLIEN,FSLFE
 set FSLFDA(999300,"+1,",.01)=name
 set FSLFDA(999300,"+1,",1)=code
 set FSLFDA(999300,"+1,",2)=qty
 set FSLFDA(999300,"+1,",3)=status
 if when'="" set FSLFDA(999300,"+1,",4)=when
 set FSLFDA(999300,"+1,",5)=catien
 do UPDATE^DIE("","FSLFDA","FSLIEN","FSLFE")
 quit $$clean(.FSLFE)
 ;
notes() ; WP NOTES onto widget 1 via WP^DIE; 1 = ok.
 ; doc: @internal
 new FSLWP,FSLFE
 set FSLWP(1,0)="First note line."
 set FSLWP(2,0)="Second note line."
 do WP^DIE(999300,"1,",6,"","FSLWP","FSLFE")
 quit $$clean(.FSLFE)
 ;
items() ; Two ITEMS entries onto widget 1 via UPDATE^DIE; 1 = ok.
 ; doc: @internal
 new FSLFDA,FSLIEN,FSLFE
 set FSLFDA(999300.07,"+1,1,",.01)="BOLT"
 set FSLFDA(999300.07,"+1,1,",1)=50
 set FSLFDA(999300.07,"+2,1,",.01)="NUT"
 set FSLFDA(999300.07,"+2,1,",1)=20
 do UPDATE^DIE("","FSLFDA","FSLIEN","FSLFE")
 quit $$clean(.FSLFE)
 ;
clean(fmerr) ; 1 = no FM error state (clearing it either way).
 ; doc: @internal
 new n,errs
 set n=$$collect^FSLERR(.fmerr,.errs)
 quit n=0
