# f-stdlib docs

The one index for this repo's documentation (org folder standard —
`.github/CONVENTIONS.md`).

- **Proposal / charter (canonical, cross-repo):** `docs` repo
  `proposals/fileman-stdlib/fileman-stdlib.md` — the accepted FSL proposal
  (roster §4, tiers §5, gates §9, NOT-list §10). This repo carries no copy.
- **Tracker (live ledger):** `docs` repo
  `proposals/fileman-stdlib/fileman-stdlib-tracker.md` — updated at every
  code increment here (coordinator-style).
- [`modules/`](modules/index.md) — generated per-module API reference
  (mdoc chain, drift-gated by `make manifest-check` + `make skill-check`).
  Do not hand-edit.
- [`memory/`](memory/) — per-repo auto-memory (durable lessons only),
  committed with the code.
