# Memory index — f-stdlib

Per-repo auto-memory (durable lessons only — the keep-test). One line per
entry; detail in topic files.

- [Hand-built fixture DDs: the nodes FileMan actually needs](fixture-dd-required-nodes.md) — "SB"+"NM" subfile registry nodes or subfile filing faults/errors 408; DD shape changes need the ^ZFSLFIX("ddv") version bump (stateful engines keep old DDs).
- [M string-equality trap + STDDATE non-canonical args](m-string-equality-canonicalize.md) — `"01"=0` is FALSE (M `=` is string compare); canonicalize `$extract` results with `+`; STDDATE `validDate/daysInMonth` silently mis-answer on non-canonical args ("02"≠2).
- [fmt preset is `identity` on purpose](fmt-preset-identity.md) — m-cli T0-3 (96d8bc3, 2026-07-19) hard-errors unknown [fmt] presets; pythonic-lower is a hand-written convention checked by lint, not a formatter preset.
- [Compat-tier truths pinned by tests](compat-tier-truths.md) — FileMan does NOT validate INTERNAL values (use validate()/VALS^DIE); partial filing is real; FSLDB tests pin both.
