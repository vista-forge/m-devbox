# Hand-built fixture DDs: the nodes FileMan actually needs

FMPRB (vista-fileman probes) proved a hand-emitted DD works for top-level
fields — but filing into a SUBFILE through UPDATE^DIE needs two node
families FMPRB never exercised:

- **`^DD(parent,"SB",subfile,field)=""`** — without it, subfile root
  resolution faults `%YDB-E-VAREXPECTED` at `CREATE+3^DICA3` (DIROOT
  indirection built empty).
- **`^DD(subfile,0,"NM",name)=""`** — without it, UPDATE^DIE errors 408
  "File# … lacks a name."

WP filing works via `WP^DIE(file,iens,fld,"K","ROOT","ERR")` with
`ROOT(n,0)=line`.

**Version-stamp the DD shape**: scratch engines are stateful across suite
runs, so `installed()` alone would skip a rebuild after a buildDd change —
`^ZFSLFIX("ddv")` must match `$$ddv^FSLFIX` or install() rebuilds. Bump
`ddv()` on ANY buildDd edit.

Also: the fixture sets `^DD(target,0,"PT",source,field)=""` by hand — the
inbound-pointer registry FSLDB.delete walks; DICATT would maintain it, a
hand DD must.
