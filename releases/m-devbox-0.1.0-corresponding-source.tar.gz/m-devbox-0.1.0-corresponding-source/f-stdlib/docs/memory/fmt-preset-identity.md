# fmt preset is `identity` on purpose

m-cli commit `96d8bc3` (2026-07-19, T0-3) made an unknown `[fmt] rules`
preset a hard `BAD_CONFIG` (exit 2) on EVERY m command that loads config
— by design, because the old behavior silently mapped unknown presets to
identity while reporting success. `pythonic-lower` is not an implemented
formatter preset (see the mumps-modern-style skill): it is a hand-written
convention checked by lint. So this repo pins `[fmt] rules = "identity"`.
Switch only when m-cli ships a real lowercasing preset.

(Org note: m-stdlib / v-stdlib carried the same invalid value at the time
and were left for their own fix increments, per the m-cli commit message.)
