# Compat-tier truths pinned by tests

Measured on the scratch standalone FileMan 22.2 floor (increment 3):

- **INTERNAL values bypass input transforms.** `UPDATE^DIE`/`FILE^DIE`
  file internal values as given (a 47-char .01 filed without complaint).
  This is the documented DBS contract. Pre-flight user input with
  `$$validate^FSLDB` (VALS^DIE, external→internal). FSLDBTST pins this
  with a test so nobody "fixes" it into a false safety claim.
- **Partial filing is real** (G-1): FSLDB.create files scalars → WP →
  multiples in sequence; an error midway leaves earlier parts filed —
  documented in the module header, resolved by FSLTX (Tier 1) not here.
- **MSG_ROOT vs ^TMP:** with a local MSG_ROOT, errors land ONLY in the
  local array (`root("DIERR",…)`) — `^TMP("DIERR",$J)` stays empty; with
  no MSG_ROOT they land in `^TMP("DIERR",$J)`. `CLEAN^DILF` clears both
  plus DIERR. FSLERR handles both paths.
