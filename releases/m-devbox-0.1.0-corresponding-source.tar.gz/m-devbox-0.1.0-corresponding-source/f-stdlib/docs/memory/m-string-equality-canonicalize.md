# M string-equality trap + STDDATE non-canonical args

M `=` is STRING equality: `"01"=0` and `"00"=0` are **FALSE** (`"0"` vs
`"01"`). Any value produced by `$extract`/`$piece` that will be compared
with `=` or passed to a numeric API must be canonicalized with unary `+`
at the point of extraction. This silently broke FSLDATE's imprecise-date
and midnight branches until fixed (increment 3).

**Upstream flag (owner attention, m-stdlib):** `validDate^STDDATE` /
`daysInMonth^STDDATE` use `=` on the month arg, so NON-canonical input
mis-answers silently — measured: `$$validDate^STDDATE(2026,"02","30")=1`
(because `"02"=2` is false in `daysInMonth`, Feb falls through to 31),
while `(2026,2,30)=0`. Callers must pass canonical numbers; consider a
`+`-coercion hardening in m-stdlib.
