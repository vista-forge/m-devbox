FSLQTST ; f-stdlib — unit tests for FSLQ (declarative reads, FMQL model).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tListDefault(.pass,.fail)
 do tListPaged(.pass,.fail)
 do tListDesc(.pass,.fail)
 do tListStatusIndex(.pass,.fail)
 do tListFields(.pass,.fail)
 do tListFilter(.pass,.fail)
 do tListNoIdx(.pass,.fail)
 do tListBadFilter(.pass,.fail)
 do tFind(.pass,.fail)
 do tFindMissing(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
setup(env,ok) ; seed env + fresh fixture floor
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 quit
 ;
iens(out,list) ; collect items[*].ien from an envelope into a comma list
 new tree,jok,i
 set jok=$$parse^STDJSON(out,.tree)
 set list=""
 if 'jok quit
 set i=0
 for  set i=$order(tree("data","items",i)) quit:i=""  do
 . set list=list_$select(list="":"",1:",")_$piece($get(tree("data","items",i,"ien")),":",2)
 quit
 ;
cursor(out) ; extract data.cursor from an envelope
 new tree,jok
 set jok=$$parse^STDJSON(out,.tree)
 quit $piece($get(tree("data","cursor")),":",2,99)
 ;
tListDefault(pass,fail) ;@TEST "GOLDEN: list() walks the B index in order, one page, no cursor"
 new env,ok,out,g
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","","","","","")
 set g="{""data"":{""cursor"":"""",""items"":[{""ien"":4,""value"":""ANVIL""},{""ien"":3,""value"":""GADGET""},"
 set g=g_"{""ien"":1,""value"":""HAMMER""},{""ien"":5,""value"":""PLIERS""},{""ien"":2,""value"":""WRENCH""}],""more"":0},""ok"":true}"
 do eq^STDASSERT(.pass,.fail,out,g,"list golden (B, defaults)")
 quit
 ;
tListPaged(pass,fail) ;@TEST "list() paginates with an opaque cursor across three pages"
 new env,ok,out,l1,l2,l3,c
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","",2,"","","")
 do iens(out,.l1)
 do eq^STDASSERT(.pass,.fail,l1,"4,3","page 1 iens")
 do contains^STDASSERT(.pass,.fail,out,"""more"":1","page 1 has more")
 set c=$$cursor(out)
 do true^STDASSERT(.pass,.fail,c'="","page 1 cursor opaque non-empty")
 set out=$$list^FSLQ(999300,"",c,2,"","","")
 do iens(out,.l2)
 do eq^STDASSERT(.pass,.fail,l2,"1,5","page 2 iens resume exactly after cursor")
 set c=$$cursor(out)
 set out=$$list^FSLQ(999300,"",c,2,"","","")
 do iens(out,.l3)
 do eq^STDASSERT(.pass,.fail,l3,"2","page 3 final item")
 do contains^STDASSERT(.pass,.fail,out,"""more"":0","page 3 exhausts")
 quit
 ;
tListDesc(pass,fail) ;@TEST "list() dir=- walks the index descending"
 new env,ok,out,l
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","",2,"-","","")
 do iens(out,.l)
 do eq^STDASSERT(.pass,.fail,l,"2,5","descending page")
 quit
 ;
tListStatusIndex(pass,fail) ;@TEST "list() over a named secondary index (the status-lane query)"
 new env,ok,out,l
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"ST","","","","","")
 do iens(out,.l)
 do eq^STDASSERT(.pass,.fail,l,"1,2,4,3,5","ST index (value,ien) order")
 quit
 ;
tListFields(pass,fail) ;@TEST "list() hydrates requested scalar fields per item (typed)"
 new env,ok,out,tree,jok,i,found
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","","","","QTY,WHEN","")
 set jok=$$parse^STDJSON(out,.tree)
 do true^STDASSERT(.pass,.fail,jok,"envelope parses")
 set i=0
 set found=0
 for  set i=$order(tree("data","items",i)) quit:i=""  do
 . if $get(tree("data","items",i,"value"))="s:HAMMER" set found=i
 do true^STDASSERT(.pass,.fail,found,"HAMMER item present")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","items",found,"QTY")),"n:10","QTY hydrated")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","items",found,"WHEN")),"s:2026-01-10","WHEN hydrated as ISO")
 quit
 ;
tListFilter(pass,fail) ;@TEST "list() compiles &&-conjoined field-op-value filters against the DD"
 new env,ok,out,l
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","","","","","QTY > 7")
 do iens(out,.l)
 do eq^STDASSERT(.pass,.fail,l,"4,1","numeric > filter")
 set out=$$list^FSLQ(999300,"","","","","","STATUS = A && QTY < 8")
 do iens(out,.l)
 do eq^STDASSERT(.pass,.fail,l,"2","conjunction filter")
 set out=$$list^FSLQ(999300,"","","","","","WHEN >= 2026-01-12")
 do iens(out,.l)
 do eq^STDASSERT(.pass,.fail,l,"4,5","ISO date literal compiled to FM internal")
 quit
 ;
tListNoIdx(pass,fail) ;@TEST "list() REFUSES an unindexed walk (guard rail, never scans)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"CODE","","","","","")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOIDX","unindexed field refused")
 set out=$$list^FSLQ(999300,"ZZ","","","","","")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOIDX","unknown index refused")
 quit
 ;
tListBadFilter(pass,fail) ;@TEST "list() rejects unknown filter fields and operators"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$list^FSLQ(999300,"","","","","","BOGUS = 1")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOFIELD","unknown filter field")
 set out=$$list^FSLQ(999300,"","","","","","QTY %% 1")
 do contains^STDASSERT(.pass,.fail,out,"FSL-BADOP","unknown operator")
 quit
 ;
tFind(pass,fail) ;@TEST "GOLDEN: find() wraps FIND^DIC (exact lookup)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$find^FSLQ(999300,"HAMMER","","")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""count"":1,""items"":[{""ien"":1,""value"":""HAMMER""}],""more"":0},""ok"":true}","find golden")
 quit
 ;
tFindMissing(pass,fail) ;@TEST "find() with no match returns an empty ok envelope"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$find^FSLQ(999300,"ZZZNOPE","","")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""count"":0,""items"":[],""more"":0},""ok"":true}","find-missing golden")
 quit
