FSLDATETST ; f-stdlib — unit tests for FSLDATE (ISO 8601 <-> FM internal).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tToFmDates(.pass,.fail)
 do tToFmTimes(.pass,.fail)
 do tToFmTz(.pass,.fail)
 do tToFmInvalid(.pass,.fail)
 do tFromFm(.pass,.fail)
 do tFromFmTz(.pass,.fail)
 do tFromFmInvalid(.pass,.fail)
 do tMidnight(.pass,.fail)
 do tRoundTrip(.pass,.fail)
 do tCrossCheckDt(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
tToFmDates(pass,fail) ;@TEST "toFm: dates incl imprecise year/month forms"
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15"),3260115,"full date")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01"),3260100,"month-only -> DD=00")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026"),3260000,"year-only -> MMDD=0000")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("1999-12-31"),2991231,"pre-2000 century arithmetic")
 quit
 ;
tToFmTimes(pass,fail) ;@TEST "toFm: second-granularity times, canonical trailing-zero trim"
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:45"),"3260115.143045","full time")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:00"),"3260115.143","trailing zeros trimmed")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T08:05"),"3260115.0805","minutes-only form")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:45.000"),"3260115.143045","zero fraction accepted (lossless)")
 quit
 ;
tToFmTz(pass,fail) ;@TEST "toFm: explicit site-TZ mapping (offset-carrying inputs shift to site wall)"
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T23:30:00Z",-300),"3260115.183","Z instant -> UTC-5 site wall")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T18:30:00-05:00",-300),"3260115.183","same-offset input is identity")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-01T01:00:00Z",-300),"3251231.2","day rollover backward across year")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T23:30:00Z",120),"3260116.013","day rollover forward (UTC+2)")
 quit
 ;
tToFmInvalid(pass,fail) ;@TEST "toFm: invalid inputs return empty string, never fudge"
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-02-30"),"","impossible civil date")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-13-01"),"","month 13")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("15/01/2026"),"","non-ISO format")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:61"),"","minute 61")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:45.500"),"","non-zero sub-second fraction rejected (second granularity, stated)")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:00Z"),"","offset input without a site TZ refused")
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE(""),"","empty")
 quit
 ;
tFromFm(pass,fail) ;@TEST "fromFm: internal -> ISO incl imprecise + truncated time forms"
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115),"2026-01-15","date only")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260100),"2026-01","imprecise month")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260000),"2026","imprecise year")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE("3260115.143045"),"2026-01-15T14:30:45","full time")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.143),"2026-01-15T14:30:00","truncated FM time right-pads")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.1),"2026-01-15T10:00:00","single-digit fraction is 10:00")
 quit
 ;
tFromFmTz(pass,fail) ;@TEST "fromFm: site-TZ suffix labels the wall time (no shifting)"
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.183,-300),"2026-01-15T18:30:00-05:00","negative offset label")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.183,330),"2026-01-15T18:30:00+05:30","half-hour offset label")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.183,0),"2026-01-15T18:30:00Z","zero offset is Z")
 quit
 ;
tFromFmInvalid(pass,fail) ;@TEST "fromFm: invalid internals return empty string"
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(""),"","empty")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE("garbage"),"","non-numeric")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3261315),"","month 13")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260100.12),"","time on an imprecise date")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260115.25),"","hour 25")
 quit
 ;
tMidnight(pass,fail) ;@TEST "midnight: ISO T00:00:00 <-> FM previous-day .24 convention"
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T00:00:00"),"3260114.24","ISO midnight -> prev-day .24")
 do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE(3260114.24),"2026-01-15T00:00:00",".24 -> next-day ISO midnight")
 quit
 ;
tRoundTrip(pass,fail) ;@TEST "round-trip: toFm(fromFm(x))=x and fromFm(toFm(y))=y over the type card"
 new fms,isos,i,v
 set fms(1)=3260115
 set fms(2)="3260115.143045"
 set fms(3)=3260100
 set fms(4)=3260000
 set fms(5)="3260114.24"
 set i=0
 for  set i=$order(fms(i)) quit:i=""  do
 . set v=fms(i)
 . do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE($$fromFm^FSLDATE(v)),v,"fm round-trip "_v)
 set isos(1)="2026-01-15"
 set isos(2)="2026-01-15T14:30:45"
 set isos(3)="2026-01"
 set isos(4)="2026"
 set i=0
 for  set i=$order(isos(i)) quit:i=""  do
 . set v=isos(i)
 . do eq^STDASSERT(.pass,.fail,$$fromFm^FSLDATE($$toFm^FSLDATE(v)),v,"iso round-trip "_v)
 quit
 ;
tCrossCheckDt(pass,fail) ;@TEST "cross-check: toFm agrees with FileMan's own %DT parse"
 new ok,%DT,X,Y
 set ok=$$init^FSLENV()
 set %DT="TS"
 set X="JAN 15,2026@14:30:45"
 set Y=""
 do ^%DT
 do eq^STDASSERT(.pass,.fail,$$toFm^FSLDATE("2026-01-15T14:30:45"),Y,"FSLDATE = %DT on the same instant")
 quit
