FSLFIXTST ; f-stdlib — unit tests for FSLFIX (scratch-engine fixtures).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tInstall(.pass,.fail)
 do tLookupLive(.pass,.fail)
 do tStatusIndex(.pass,.fail)
 do tWpAndItems(.pass,.fail)
 do tReset(.pass,.fail)
 do tRemoveReinstall(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
tRemoveReinstall(pass,fail) ;@TEST "remove() deletes the whole fixture; install() rebuilds DDs from nothing"
 new env,ok
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 do remove^FSLFIX
 do false^STDASSERT(.pass,.fail,$$installed^FSLFIX(),"not installed after remove")
 do false^STDASSERT(.pass,.fail,$data(^DD(999300)),"widget DD gone")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL),"data global gone")
 set ok=$$install^FSLFIX()
 do eq^STDASSERT(.pass,.fail,ok,1,"reinstall from nothing")
 do true^STDASSERT(.pass,.fail,$$installed^FSLFIX(),"installed again")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"1,",.01),"HAMMER","seed records back")
 quit
 ;
tInstall(pass,fail) ;@TEST "install() builds the fixture DDs and seeds deterministic records"
 new ok,env
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 do eq^STDASSERT(.pass,.fail,ok,1,"install returns 1")
 do true^STDASSERT(.pass,.fail,$$installed^FSLFIX(),"installed() predicate")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"1,",.01),"HAMMER","widget 1 .01")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"1,",3),"ACTIVE","set-of-codes resolves external")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"1,",5),"TOOLS","pointer resolves external")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"3,",3),"INACTIVE","widget 3 status")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,0)),"^",4),5,"five widgets seeded")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999301,0)),"^",4),2,"two categories seeded")
 quit
 ;
tLookupLive(pass,fail) ;@TEST "fixture B x-refs are filer-maintained: FIND1^DIC finds records (C-2 class check)"
 new ok,env,ien,FMERR
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 set ien=$$FIND1^DIC(999300,"","QX","WRENCH","","","FMERR")
 do eq^STDASSERT(.pass,.fail,ien,2,"FIND1 via live B index")
 set ien=$$FIND1^DIC(999301,"","QX","PARTS","","","FMERR")
 do eq^STDASSERT(.pass,.fail,ien,2,"category lookup live")
 quit
 ;
tStatusIndex(pass,fail) ;@TEST "STATUS carries a live ST x-ref (the FSLQ status-lane index)"
 new ok,env
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,"ST","A",1)),"ST index holds active widget 1")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,"ST","I",3)),"ST index holds inactive widget 3")
 quit
 ;
tWpAndItems(pass,fail) ;@TEST "widget 1 carries WP notes and ITEMS multiple entries"
 new ok,env
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,1,6,1,0)),"^"),"First note line.","WP line 1 stored")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,1,7,1,0)),"ITEMS entry 1 exists")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300.07,"1,1,",.01),"BOLT","subfile .01 reads")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300.07,"1,1,",1),50,"subfile SUBQTY reads")
 quit
 ;
tReset(pass,fail) ;@TEST "reset() restores the seed state (fresh floor between arms)"
 new ok,env,FDA,IEN,FMERR
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 kill FDA,IEN,FMERR
 set FDA(999300,"+1,",.01)="EXTRA WIDGET"
 do UPDATE^DIE("","FDA","IEN","FMERR")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,0)),"^",4),6,"sixth record filed")
 set ok=$$reset^FSLFIX()
 do eq^STDASSERT(.pass,.fail,ok,1,"reset returns 1")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,0)),"^",4),5,"back to five widgets")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,6)),"extra record gone")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"1,",.01),"HAMMER","seed records intact")
 quit
