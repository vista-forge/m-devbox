FSLDBTST ; f-stdlib — unit tests for FSLDB (CRUD verbs, compat tier).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tCreate(.pass,.fail)
 do tCreateNested(.pass,.fail)
 do tCreateBadField(.pass,.fail)
 do tCreateBadValue(.pass,.fail)
 do tReadGolden(.pass,.fail)
 do tReadNestedGolden(.pass,.fail)
 do tReadExternal(.pass,.fail)
 do tReadOmitsEmpty(.pass,.fail)
 do tReadMissing(.pass,.fail)
 do tUpdate(.pass,.fail)
 do tUpdateWp(.pass,.fail)
 do tUpdateMultipleRefused(.pass,.fail)
 do tValidateOk(.pass,.fail)
 do tValidateBad(.pass,.fail)
 do tDeleteRefuse(.pass,.fail)
 do tDeleteNoRefs(.pass,.fail)
 do tDeleteCascade(.pass,.fail)
 do tDeleteMissing(.pass,.fail)
 do tReindexRepair(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
setup(env,ok) ; seed env + fresh fixture floor
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 quit
 ;
tCreate(pass,fail) ;@TEST "create() files a record from typed JSON (ISO date converted)"
 new env,ok,out,tree,jok
 do setup(.env,.ok)
 set out=$$create^FSLDB(999300,"{""NAME"":""CHISEL"",""CODE"":""FFF"",""QTY"":3,""STATUS"":""A"",""WHEN"":""2026-01-14"",""CAT"":2}")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""ien"":6},""ok"":true}","create envelope golden")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300,"6,",.01),"CHISEL","record filed")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,6,4)),"^"),3260114,"ISO date stored FM-internal")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,"B","CHISEL",6)),"B x-ref live")
 quit
 ;
tCreateNested(pass,fail) ;@TEST "create() files WP arrays and multiple entries from nested JSON"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$create^FSLDB(999300,"{""NAME"":""KIT"",""NOTES"":[""kit note""],""ITEMS"":[{""ITEM"":""SCREW"",""SUBQTY"":9},{""ITEM"":""WASHER""}]}")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""ien"":6},""ok"":true}","nested create envelope")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,6,6,1,0)),"^"),"kit note","WP line filed")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300.07,"1,6,",.01),"SCREW","ITEMS entry 1 filed")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300.07,"1,6,",1),9,"SUBQTY filed")
 do eq^STDASSERT(.pass,.fail,$$GET1^DIQ(999300.07,"2,6,",.01),"WASHER","ITEMS entry 2 filed")
 quit
 ;
tCreateBadField(pass,fail) ;@TEST "create() with an unknown field is a structured failure"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$create^FSLDB(999300,"{""NAME"":""OK"",""BOGUS"":1}")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOFIELD","FSL-NOFIELD code")
 do contains^STDASSERT(.pass,.fail,out,"""field"":""BOGUS""","offending key named")
 quit
 ;
tCreateBadValue(pass,fail) ;@TEST "create() rejects a bad ISO date; internal values are NOT FileMan-validated (documented)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$create^FSLDB(999300,"{""NAME"":""OKNAME"",""WHEN"":""2026-02-30""}")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 do contains^STDASSERT(.pass,.fail,out,"FSL-BADDATE","FSL-BADDATE code")
 do contains^STDASSERT(.pass,.fail,out,"""field"":""WHEN""","offending field named")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"no FM error state left")
 ; the compat-tier truth, pinned: FileMan does NOT validate internal values
 set out=$$create^FSLDB(999300,"{""NAME"":""THIS NAME IS FAR TOO LONG TO PASS THE TRANSFORM""}")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":true","internal filing bypasses transforms (use validate())")
 quit
 ;
tReadGolden(pass,fail) ;@TEST "GOLDEN: read() internal-typed shape (dates ISO, numbers bare)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$read^FSLDB(999300,2,"","")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""CAT"":1,""CODE"":""BBB"",""NAME"":""WRENCH"",""QTY"":5,""STATUS"":""A"",""WHEN"":""2026-01-11T09:00:00"",""ien"":2},""ok"":true}","read golden widget 2")
 quit
 ;
tReadNestedGolden(pass,fail) ;@TEST "GOLDEN: read() nests multiples as arrays and WP as string arrays"
 new env,ok,out,g
 do setup(.env,.ok)
 set out=$$read^FSLDB(999300,1,"","")
 set g="{""data"":{""CAT"":1,""CODE"":""AAA"",""ITEMS"":[{""ITEM"":""BOLT"",""SUBQTY"":50,""ien"":1},{""ITEM"":""NUT"",""SUBQTY"":20,""ien"":2}],"
 set g=g_"""NAME"":""HAMMER"",""NOTES"":[""First note line."",""Second note line.""],""QTY"":10,""STATUS"":""A"",""WHEN"":""2026-01-10"",""ien"":1},""ok"":true}"
 do eq^STDASSERT(.pass,.fail,out,g,"read golden widget 1 (nested)")
 quit
 ;
tReadExternal(pass,fail) ;@TEST "read() flag E returns FileMan display values"
 new env,ok,out,tree,jok
 do setup(.env,.ok)
 set out=$$read^FSLDB(999300,1,"","E")
 set jok=$$parse^STDJSON(out,.tree)
 do true^STDASSERT(.pass,.fail,jok,"envelope parses")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","STATUS")),"s:ACTIVE","set label external")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","CAT")),"s:TOOLS","pointer resolved external")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","WHEN")),"s:JAN 10,2026","date external")
 quit
 ;
tReadOmitsEmpty(pass,fail) ;@TEST "read() omits empty-valued fields (stable sparse shape)"
 new env,ok,out,tree,jok
 do setup(.env,.ok)
 set out=$$read^FSLDB(999300,3,"","")
 set jok=$$parse^STDJSON(out,.tree)
 do true^STDASSERT(.pass,.fail,jok,"envelope parses")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","NAME")),"s:GADGET","name present")
 do false^STDASSERT(.pass,.fail,$data(tree("data","WHEN")),"unset date omitted")
 quit
 ;
tReadMissing(pass,fail) ;@TEST "read() of a missing record is a structured failure"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$read^FSLDB(999300,99,"","")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"FM error state cleared")
 quit
 ;
tUpdate(pass,fail) ;@TEST "update() files scalar edits via FILE^DIE (ISO date converted)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$update^FSLDB(999300,2,"{""QTY"":6,""WHEN"":""2026-02-01""}")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""updated"":2},""ok"":true}","update envelope golden")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,2,2)),"^"),6,"QTY updated")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,2,4)),"^"),3260201,"date updated internal")
 quit
 ;
tUpdateWp(pass,fail) ;@TEST "update() replaces WP content wholesale"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$update^FSLDB(999300,1,"{""NOTES"":[""only line""]}")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""updated"":1},""ok"":true}","wp update envelope")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,1,6,1,0)),"^"),"only line","line 1 replaced")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,1,6,2)),"old line 2 gone")
 quit
 ;
tUpdateMultipleRefused(pass,fail) ;@TEST "update() refuses multiples (documented compat-tier hole)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$update^FSLDB(999300,1,"{""ITEMS"":[{""ITEM"":""X""}]}")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOSUB","FSL-NOSUB code")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 quit
 ;
tValidateOk(pass,fail) ;@TEST "validate() converts external values to internal without filing"
 new env,ok,out,tree,jok,before
 do setup(.env,.ok)
 set before=$piece($get(^ZFSL(999300,2,3)),"^")
 set out=$$validate^FSLDB(999300,2,"{""STATUS"":""INACTIVE"",""QTY"":""7""}")
 set jok=$$parse^STDJSON(out,.tree)
 do true^STDASSERT(.pass,.fail,jok,"envelope parses")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","internal","STATUS")),"s:I","set label -> internal code")
 do eq^STDASSERT(.pass,.fail,$get(tree("data","internal","QTY")),"n:7","numeric internal")
 do eq^STDASSERT(.pass,.fail,$piece($get(^ZFSL(999300,2,3)),"^"),before,"nothing filed")
 quit
 ;
tValidateBad(pass,fail) ;@TEST "validate() reports an invalid value as a field-tagged failure"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$validate^FSLDB(999300,2,"{""QTY"":""notanumber""}")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"FM error state cleared")
 quit
 ;
tDeleteRefuse(pass,fail) ;@TEST "delete(refuse) blocks on inbound references (G-5 closed at the verb)"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$delete^FSLDB(999301,1,"")
 do contains^STDASSERT(.pass,.fail,out,"FSL-REFS","FSL-REFS code")
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","failure envelope")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999301,1)),"referenced record intact")
 quit
 ;
tDeleteNoRefs(pass,fail) ;@TEST "delete() of an unreferenced record removes record + x-refs via ^DIK"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$delete^FSLDB(999300,5,"")
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""deleted"":[{""file"":999300,""ien"":5}]},""ok"":true}","delete envelope golden")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,5)),"record gone")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,"B","PLIERS",5)),"B x-ref swept")
 quit
 ;
tDeleteCascade(pass,fail) ;@TEST "delete(cascade) removes referencers first, then the target — zero dangling"
 new env,ok,out,g
 do setup(.env,.ok)
 set out=$$delete^FSLDB(999301,2,"cascade")
 set g="{""data"":{""deleted"":[{""file"":999300,""ien"":3},{""file"":999300,""ien"":4},{""file"":999301,""ien"":2}]},""ok"":true}"
 do eq^STDASSERT(.pass,.fail,out,g,"cascade envelope golden")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999301,2)),"category gone")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,3)),"referencing widget 3 gone")
 do false^STDASSERT(.pass,.fail,$data(^ZFSL(999300,4)),"referencing widget 4 gone")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,1)),"unrelated widget intact")
 quit
 ;
tDeleteMissing(pass,fail) ;@TEST "delete() of a missing record is a structured failure"
 new env,ok,out
 do setup(.env,.ok)
 set out=$$delete^FSLDB(999300,99,"")
 do contains^STDASSERT(.pass,.fail,out,"FSL-NOREC","FSL-NOREC code")
 quit
 ;
tReindexRepair(pass,fail) ;@TEST "reindex() reconstructs IX markers, reindexes, verifies lookups live (C-2)"
 new env,ok,out
 do setup(.env,.ok)
 ; simulate the C-2 state: marker lost + index dead
 kill ^DD(999300,"IX",3)
 kill ^ZFSL(999300,"ST")
 set out=$$reindex^FSLDB(999300)
 do contains^STDASSERT(.pass,.fail,out,"""ok"":true","reindex succeeds")
 do contains^STDASSERT(.pass,.fail,out,"""verified"":1","live-lookup verified")
 do true^STDASSERT(.pass,.fail,$data(^DD(999300,"IX",3))#10,"IX marker reconstructed")
 do true^STDASSERT(.pass,.fail,$data(^ZFSL(999300,"ST","A",1)),"ST index rebuilt")
 quit
