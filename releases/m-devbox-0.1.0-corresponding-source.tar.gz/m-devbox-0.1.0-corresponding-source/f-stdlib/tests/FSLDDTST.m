FSLDDTST ; f-stdlib — unit tests for FSLDD (DD introspection -> JSON, the codegen contract).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tJsonWidget(.pass,.fail)
 do tJsonCategory(.pass,.fail)
 do tJsonUnknown(.pass,.fail)
 do tFiles(.pass,.fail)
 do tFldnum(.pass,.fail)
 do tFieldSubfile(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
setup(env,ok) ; seed env + fixture
 set env=$$init^FSLENV()
 set ok=$$install^FSLFIX()
 quit
 ;
tJsonWidget(pass,fail) ;@TEST "GOLDEN: $$json freezes the full widget-file contract (fields/indexes/keys)"
 new env,ok,g
 do setup(.env,.ok)
 set g="{""fields"":[{""name"":""NAME"",""node"":""0"",""number"":0.01,""piece"":1,""required"":true,""type"":""free-text""},"
 set g=g_"{""name"":""CODE"",""node"":""1"",""number"":1,""piece"":1,""required"":false,""type"":""free-text""},"
 set g=g_"{""name"":""QTY"",""node"":""2"",""number"":2,""piece"":1,""required"":false,""type"":""numeric""},"
 set g=g_"{""name"":""STATUS"",""node"":""3"",""number"":3,""piece"":1,""required"":false,""set"":[{""code"":""A"",""label"":""ACTIVE""},{""code"":""I"",""label"":""INACTIVE""}],""type"":""set""},"
 set g=g_"{""name"":""WHEN"",""node"":""4"",""number"":4,""piece"":1,""required"":false,""type"":""date""},"
 set g=g_"{""name"":""CAT"",""node"":""5"",""number"":5,""piece"":1,""pointer"":999301,""required"":false,""type"":""pointer""},"
 set g=g_"{""multiple"":999300.06,""name"":""NOTES"",""node"":""6"",""number"":6,""piece"":0,""required"":false,""type"":""wp""},"
 set g=g_"{""multiple"":999300.07,""name"":""ITEMS"",""node"":""7"",""number"":7,""piece"":0,""required"":false,""type"":""multiple""}],"
 set g=g_"""global"":""^ZFSL(999300,"",""indexes"":[{""field"":0.01,""live"":true,""name"":""B"",""type"":""traditional""},"
 set g=g_"{""field"":3,""live"":true,""name"":""ST"",""type"":""traditional""}],""keys"":[],""name"":""ZFSL WIDGET"",""number"":999300}"
 do eq^STDASSERT(.pass,.fail,$$json^FSLDD(999300),g,"widget-file golden JSON")
 quit
 ;
tJsonCategory(pass,fail) ;@TEST "GOLDEN: $$json freezes the category-file contract"
 new env,ok,g
 do setup(.env,.ok)
 set g="{""fields"":[{""name"":""NAME"",""node"":""0"",""number"":0.01,""piece"":1,""required"":true,""type"":""free-text""}],"
 set g=g_"""global"":""^ZFSL(999301,"",""indexes"":[{""field"":0.01,""live"":true,""name"":""B"",""type"":""traditional""}],"
 set g=g_"""keys"":[],""name"":""ZFSL CATEGORY"",""number"":999301}"
 do eq^STDASSERT(.pass,.fail,$$json^FSLDD(999301),g,"category-file golden JSON")
 quit
 ;
tJsonUnknown(pass,fail) ;@TEST "$$json of an unknown file returns empty string"
 new env,ok
 do setup(.env,.ok)
 do eq^STDASSERT(.pass,.fail,$$json^FSLDD(999999),"","unknown file -> empty")
 quit
 ;
tFiles(pass,fail) ;@TEST "files() lists the fixture files with name+global"
 new env,ok,out,i,found,name,glob
 do setup(.env,.ok)
 do files^FSLDD(.out)
 set found=0
 set i=0
 for  set i=$order(out(i)) quit:i=""  do
 . if $get(out(i,"number"))="n:999300" do
 . . set found=1
 . . set name=$get(out(i,"name"))
 . . set glob=$get(out(i,"global"))
 do true^STDASSERT(.pass,.fail,found,"999300 listed")
 do eq^STDASSERT(.pass,.fail,$get(name),"s:ZFSL WIDGET","name in files()")
 do eq^STDASSERT(.pass,.fail,$get(glob),"s:^ZFSL(999300,","global in files()")
 quit
 ;
tFldnum(pass,fail) ;@TEST "fldnum() resolves names and numbers to field numbers"
 new env,ok
 do setup(.env,.ok)
 do eq^STDASSERT(.pass,.fail,$$fldnum^FSLDD(999300,"STATUS"),3,"name -> number")
 do eq^STDASSERT(.pass,.fail,$$fldnum^FSLDD(999300,"NAME"),.01,"name -> .01")
 do eq^STDASSERT(.pass,.fail,$$fldnum^FSLDD(999300,2),2,"number passes through")
 do eq^STDASSERT(.pass,.fail,$$fldnum^FSLDD(999300,"NOPE"),"","unknown name -> empty")
 do eq^STDASSERT(.pass,.fail,$$fldnum^FSLDD(999300,99),"","unknown number -> empty")
 quit
 ;
tFieldSubfile(pass,fail) ;@TEST "field() introspects a subfile field (node 0 piece 2)"
 new env,ok,out
 do setup(.env,.ok)
 do field^FSLDD(999300.07,1,.out)
 do eq^STDASSERT(.pass,.fail,$get(out("name")),"s:SUBQTY","subfield name")
 do eq^STDASSERT(.pass,.fail,$get(out("type")),"s:numeric","subfield type")
 do eq^STDASSERT(.pass,.fail,$get(out("node")),"s:0","subfield node")
 do eq^STDASSERT(.pass,.fail,$get(out("piece")),"n:2","subfield piece")
 quit
