FSLFLRTST ; f-stdlib — floor smoke suite: the Tier-0 test substrate composes.
 ; Permanent substrate smoke (increment 2): proves the scratch engine
 ; carries standalone FileMan 22.2 (vista-fileman build), that the m test
 ; runner staged MSL (STD*) beside FSL, and that the %-utility seed
 ; (%DT via the 19,"ZS" copy) resolves. No state is written.
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tFilemanCore(.pass,.fail)
 do tFilemanDt(.pass,.fail)
 do tMslStaged(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
tFilemanCore(pass,fail) ;@TEST "floor carries FileMan 22.2: DD version + GET1^DIQ round-trip"
 new DUZ,U,DT,ver,name
 set DUZ=1
 set DUZ(0)="@"
 set U="^"
 set DT=$$dtToday()
 set ver=$get(^DD("VERSION"))
 do eq^STDASSERT(.pass,.fail,ver,22.2,"^DD(""VERSION"") is 22.2")
 set name=$$GET1^DIQ(1,"1,",.01)
 do eq^STDASSERT(.pass,.fail,name,"FILE","$$GET1^DIQ(1,""1,"",.01)")
 quit
 ;
tFilemanDt(pass,fail) ;@TEST "floor %-seed: ^%DT parses an external date"
 new DUZ,U,DT,X,Y,%DT
 set DUZ=1
 set DUZ(0)="@"
 set U="^"
 set DT=$$dtToday()
 set X="JAN 1,2026"
 set Y=""
 do ^%DT
 do eq^STDASSERT(.pass,.fail,Y,3260101,"^%DT external -> FM internal")
 quit
 ;
tMslStaged(pass,fail) ;@TEST "MSL (STD*) is staged beside FSL on the engine"
 do eq^STDASSERT(.pass,.fail,$$encode^STDHEX("foo"),"666f6f","$$encode^STDHEX")
 new tree,ok
 set ok=$$parse^STDJSON("{""a"":1}",.tree)
 do true^STDASSERT(.pass,.fail,ok,"STDJSON parses on the floor")
 quit
 ;
dtToday() ; today as FM internal (YYYMMDD) from $HOROLOG — no Kernel, no DT dependency
 new h,iso
 set h=$horolog
 set iso=$$fromh^STDDATE(h)
 quit ($extract(iso,1,4)-1700)*10000+($extract(iso,6,7)*100)+$extract(iso,9,10)
