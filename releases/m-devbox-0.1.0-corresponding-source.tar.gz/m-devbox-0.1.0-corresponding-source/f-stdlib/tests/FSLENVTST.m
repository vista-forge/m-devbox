FSLENVTST ; f-stdlib — unit tests for FSLENV (standalone environment seeding).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tSeedFresh(.pass,.fail)
 do tRefuseWhenOwned(.pass,.fail)
 do tRefuseWhenDtOwned(.pass,.fail)
 do tSeededPredicate(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
tSeedFresh(pass,fail) ;@TEST "init() seeds DUZ/DUZ(0)/U/DT/IO on a fresh environment"
 new DUZ,DT,U,IO,IOM,IOSL,ok
 set ok=$$init^FSLENV()
 do eq^STDASSERT(.pass,.fail,ok,1,"init returns 1 on fresh env")
 do eq^STDASSERT(.pass,.fail,$get(DUZ),1,"DUZ=1 service identity")
 do eq^STDASSERT(.pass,.fail,$get(DUZ(0)),"@","DUZ(0)=@ programmer access")
 do eq^STDASSERT(.pass,.fail,$get(U),"^","U=^")
 do true^STDASSERT(.pass,.fail,$get(DT)?7N,"DT is FM internal YYYMMDD")
 do true^STDASSERT(.pass,.fail,$get(DT)>3200000,"DT is a current-era date")
 do true^STDASSERT(.pass,.fail,$data(IO)#10,"IO seeded")
 do true^STDASSERT(.pass,.fail,$get(IOM)>0,"IOM seeded")
 quit
 ;
tRefuseWhenOwned(pass,fail) ;@TEST "init() refuses when DUZ already defined — never clobbers"
 new DUZ,DT,U,IO,ok
 set DUZ=42
 set DUZ(0)=""
 set ok=$$init^FSLENV()
 do eq^STDASSERT(.pass,.fail,ok,0,"init returns 0 when env is owned")
 do eq^STDASSERT(.pass,.fail,DUZ,42,"DUZ untouched")
 do eq^STDASSERT(.pass,.fail,DUZ(0),"","DUZ(0) untouched")
 do false^STDASSERT(.pass,.fail,$data(DT),"DT not seeded on refusal")
 quit
 ;
tRefuseWhenDtOwned(pass,fail) ;@TEST "init() refuses when DT already defined (partial managed state)"
 new DUZ,DT,U,IO,ok
 set DT=3260101
 set ok=$$init^FSLENV()
 do eq^STDASSERT(.pass,.fail,ok,0,"init returns 0 when DT is owned")
 do false^STDASSERT(.pass,.fail,$data(DUZ),"DUZ not seeded on refusal")
 do eq^STDASSERT(.pass,.fail,DT,3260101,"DT untouched")
 quit
 ;
tSeededPredicate(pass,fail) ;@TEST "seeded() is true only when the full set is present"
 new DUZ,DT,U,IO
 do false^STDASSERT(.pass,.fail,$$seeded^FSLENV(),"fresh env: not seeded")
 new ok
 set ok=$$init^FSLENV()
 do true^STDASSERT(.pass,.fail,$$seeded^FSLENV(),"after init: seeded")
 quit
