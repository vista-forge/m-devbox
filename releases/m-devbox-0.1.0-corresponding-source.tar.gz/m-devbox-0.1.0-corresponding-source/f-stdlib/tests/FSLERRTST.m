FSLERRTST ; f-stdlib — unit tests for FSLERR (the one error envelope).
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 do tOkEnvelope(.pass,.fail)
 do tOkEmpty(.pass,.fail)
 do tAddFail(.pass,.fail)
 do tCollectReal(.pass,.fail)
 do tCollectClearsTmp(.pass,.fail)
 do tWrapOk(.pass,.fail)
 do tWrapFail(.pass,.fail)
 do report^STDASSERT(pass,fail)
 quit
 ;
tOkEnvelope(pass,fail) ;@TEST "ok() wraps a data tree in the success envelope"
 new data,out
 set data="o"
 set data("x")="n:1"
 set out=$$ok^FSLERR(.data)
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""x"":1},""ok"":true}","ok envelope golden")
 quit
 ;
tOkEmpty(pass,fail) ;@TEST "ok() with no data yields data:null (stable shape)"
 new data,out
 set out=$$ok^FSLERR(.data)
 do eq^STDASSERT(.pass,.fail,out,"{""data"":null,""ok"":true}","ok-empty envelope golden")
 quit
 ;
tAddFail(pass,fail) ;@TEST "add()+fail() build the failure envelope (fixed error shape)"
 new errs,out
 do add^FSLERR(.errs,401,"File #999999 does not exist.","")
 do add^FSLERR(.errs,701,"value is invalid",".01")
 set out=$$fail^FSLERR(.errs)
 do eq^STDASSERT(.pass,.fail,out,"{""errors"":[{""code"":""401"",""field"":"""",""text"":""File #999999 does not exist.""},{""code"":""701"",""field"":"".01"",""text"":""value is invalid""}],""ok"":false}","fail envelope golden")
 quit
 ;
tCollectReal(pass,fail) ;@TEST "collect() translates a real DBS error AND clears all FM error state"
 new ok,FDA,IEN,FMERR,errs,n
 set ok=$$init^FSLENV()
 kill FDA,IEN,FMERR
 set FDA(999999,"+1,",.01)="X"
 do UPDATE^DIE("","FDA","IEN","FMERR")
 do true^STDASSERT(.pass,.fail,$$pending^FSLERR(),"error state pending after bad DBS call")
 set n=$$collect^FSLERR(.FMERR,.errs)
 do eq^STDASSERT(.pass,.fail,n,1,"one error collected")
 do eq^STDASSERT(.pass,.fail,$get(errs(1,"code")),"s:401","code translated")
 do contains^STDASSERT(.pass,.fail,$get(errs(1,"text")),"does not exist","text translated")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"DIERR cleared by collect")
 do false^STDASSERT(.pass,.fail,$data(FMERR("DIERR")),"caller msg root cleared by collect")
 quit
 ;
tCollectClearsTmp(pass,fail) ;@TEST "collect() clears ^TMP(DIERR) when no msg root was passed"
 new ok,FDA,IEN,FMERR,errs,n
 set ok=$$init^FSLENV()
 kill FDA,IEN
 set FDA(999999,"+1,",.01)="X"
 do UPDATE^DIE("","FDA","IEN")
 do true^STDASSERT(.pass,.fail,$data(^TMP("DIERR",$job))>0,"^TMP(DIERR,$J) populated without msg root")
 set n=$$collect^FSLERR(.FMERR,.errs)
 do false^STDASSERT(.pass,.fail,$data(^TMP("DIERR",$job)),"^TMP(DIERR,$J) cleared — nothing above FSL reads it")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"no pending state after collect")
 quit
 ;
tWrapOk(pass,fail) ;@TEST "wrap() returns the ok envelope when no FM error state exists"
 new FMERR,data,out
 do clear^FSLERR
 set data="o"
 set data("ien")="n:7"
 set out=$$wrap^FSLERR(.FMERR,.data)
 do eq^STDASSERT(.pass,.fail,out,"{""data"":{""ien"":7},""ok"":true}","wrap-ok golden")
 quit
 ;
tWrapFail(pass,fail) ;@TEST "wrap() returns the failure envelope from live FM error state, then is clean"
 new ok,FDA,IEN,FMERR,data,out
 set ok=$$init^FSLENV()
 kill FDA,IEN,FMERR
 set FDA(999999,"+1,",.01)="X"
 do UPDATE^DIE("","FDA","IEN","FMERR")
 set out=$$wrap^FSLERR(.FMERR,.data)
 do contains^STDASSERT(.pass,.fail,out,"""ok"":false","wrap-fail is a failure envelope")
 do contains^STDASSERT(.pass,.fail,out,"""code"":""401""","wrap-fail carries the DIERR code")
 do false^STDASSERT(.pass,.fail,$$pending^FSLERR(),"error state cleared by wrap")
 quit
