#!/usr/bin/env python3
"""Per-module coverage floor over an LCOV tracefile.

The Go `m coverage --min-percent` gate is AGGREGATE; the fileman-stdlib
kickoff requires >=85% PER MODULE. This reads the lcov the aggregate run
wrote and reds if any measured module under --only-prefix is below --min.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def parse_lcov(path: Path) -> dict[str, tuple[int, int]]:
    """Return {source_file: (lines_hit, lines_found)}."""
    out: dict[str, tuple[int, int]] = {}
    sf, lh, lf = None, 0, 0
    for line in path.read_text().splitlines():
        if line.startswith("SF:"):
            sf, lh, lf = line[3:].strip(), 0, 0
        elif line.startswith("LH:"):
            lh = int(line[3:])
        elif line.startswith("LF:"):
            lf = int(line[3:])
        elif line == "end_of_record" and sf is not None:
            out[sf] = (lh, lf)
            sf = None
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--lcov", default="coverage.lcov")
    ap.add_argument("--min", type=float, default=85.0)
    ap.add_argument("--only-prefix", default="src/")
    args = ap.parse_args()

    path = Path(args.lcov)
    if not path.is_file():
        print(f"coverage-per-module: FATAL — no lcov at {path}", file=sys.stderr)
        return 2
    records = {
        f: c for f, c in parse_lcov(path).items() if args.only_prefix in f
    }
    if not records:
        print(
            f"coverage-per-module: FATAL — no '{args.only_prefix}' records in {path}",
            file=sys.stderr,
        )
        return 2
    bad = []
    for f in sorted(records):
        lh, lf = records[f]
        pct = 100.0 * lh / lf if lf else 100.0
        mark = "ok" if pct >= args.min else "LOW"
        print(f"  {Path(f).name:<14} {pct:6.1f}%  ({lh}/{lf} lines) [{mark}]")
        if pct < args.min:
            bad.append((f, pct))
    if bad:
        names = ", ".join(f"{Path(f).name}={p:.1f}%" for f, p in bad)
        print(
            f"coverage-per-module: RED — below {args.min}%: {names}",
            file=sys.stderr,
        )
        return 1
    print(f"coverage-per-module: all {len(records)} module(s) >= {args.min}% [ok]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
