package clikit

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"testing"
)

// decodeAll returns every top-level JSON document in b. The single-verdict
// contract (ROOT-CAUSE §3) is that a failing-with-data result emits EXACTLY
// one stdout envelope — so this count is the assertion, not a convenience.
func decodeAll(t *testing.T, b []byte) []Envelope {
	t.Helper()
	dec := json.NewDecoder(bytes.NewReader(b))
	var out []Envelope
	for {
		var e Envelope
		err := dec.Decode(&e)
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			t.Fatalf("decoding envelope stream: %v\nraw:\n%s", err, b)
		}
		out = append(out, e)
	}
	return out
}

// A failing-with-data result in JSON mode must emit EXACTLY ONE stdout envelope
// whose ok/exit are RED and which carries the data, diagnostics AND error — not
// a green data-only envelope on stdout plus a separate error on stderr.
func TestResultErr_JSONSingleVerdict(t *testing.T) {
	var out, errb bytes.Buffer
	c := &Context{Stdout: &out, Stderr: &errb, Format: FormatJSON, Command: "lint"}
	diags := []Diagnostic{{File: "x.m", Line: 2, Rule: "M-MOD-038", Severity: "error", Message: "bad"}}
	data := map[string]any{"filesScanned": 1, "findings": 1}
	ferr := Fail(ExitCheck, "SEVERITY_GATE", "lint findings breach --error-on=error", "")

	rerr := c.ResultErr(data, diags, ferr, func() { t.Fatal("text closure must not run in JSON mode") })

	docs := decodeAll(t, out.Bytes())
	if len(docs) != 1 {
		t.Fatalf("stdout has %d envelope(s), want exactly 1 (the double-verdict is back)\n%s", len(docs), out.String())
	}
	env := docs[0]
	if env.OK {
		t.Error("envelope ok=true, want false — the single verdict must be RED")
	}
	if env.Exit != ExitCheck {
		t.Errorf("envelope exit=%d, want %d", env.Exit, ExitCheck)
	}
	if env.Error == nil || env.Error.Code != "SEVERITY_GATE" {
		t.Errorf("envelope.error=%v, want the SEVERITY_GATE error", env.Error)
	}
	if len(env.Diagnostics) != 1 {
		t.Errorf("envelope carries %d diagnostics, want 1 (data is preserved on the red verdict)", len(env.Diagnostics))
	}
	if env.Data == nil {
		t.Error("envelope.data is nil, want the computed data preserved")
	}
	if errb.Len() != 0 {
		t.Errorf("stderr must be empty (no second envelope), got: %s", errb.String())
	}

	// The returned error carries the exit code but is marked emitted, so Run
	// honors the exit and skips a second RenderError.
	if !alreadyEmitted(rerr) {
		t.Error("returned error should be alreadyEmitted so Run skips a 2nd RenderError")
	}
	if exitOf(rerr) != ExitCheck {
		t.Errorf("exitOf(returned)=%d, want %d", exitOf(rerr), ExitCheck)
	}
	var e *Error
	if !errors.As(rerr, &e) || e.Code != "SEVERITY_GATE" {
		t.Error("returned error must Unwrap to the *Error (exitOf/isUsageError keep working)")
	}
	// A usage-coded verdict still isn't a usage error once emitted (it isn't
	// ExitUsage here), and an emitted ExitUsage would be short-circuited by the
	// alreadyEmitted check in Run before isUsageError is consulted.
}

// In text mode ResultErr runs the human closure and returns the RAW error, so
// Run renders it to stderr the usual way (no early emitted short-circuit).
func TestResultErr_TextMode(t *testing.T) {
	var out, errb bytes.Buffer
	c := &Context{Stdout: &out, Stderr: &errb, Format: FormatText, Command: "lint"}
	ferr := Fail(ExitCheck, "SEVERITY_GATE", "findings", "")
	ran := false
	rerr := c.ResultErr(nil, nil, ferr, func() { ran = true })
	if !ran {
		t.Error("text closure must run in text mode")
	}
	if alreadyEmitted(rerr) {
		t.Error("text mode must return the RAW error (Run renders it to stderr), not an emittedError")
	}
	var e *Error
	if !errors.As(rerr, &e) || e != ferr {
		t.Errorf("text mode should return the raw *Error, got %v", rerr)
	}
}

// A nil error degrades to a normal passing Diagnostics result (ok:true, exit:0)
// — so a command can pass its gate result straight through.
func TestResultErr_NilErrDegradesToPass(t *testing.T) {
	var out bytes.Buffer
	c := &Context{Stdout: &out, Format: FormatJSON, Command: "lint"}
	rerr := c.ResultErr(map[string]any{"findings": 0}, nil, nil, nil)
	if rerr != nil {
		t.Errorf("nil err should be a passing result, got %v", rerr)
	}
	docs := decodeAll(t, out.Bytes())
	if len(docs) != 1 || !docs[0].OK || docs[0].Exit != ExitOK {
		t.Errorf("want one ok:true exit:0 envelope, got %+v", docs)
	}
}

// Regression anchor for WHY ResultErr exists: the bare Diagnostics(...) helper
// emits ok:true / exit:0 unconditionally — correct for a passing result, but if
// a command then `return Fail(...)`, the failure envelope lands on stderr and a
// stdout consumer sees this green document (ROOT-CAUSE §3). ResultErr is the fix.
func TestDiagnostics_IsGreenOnlyByDesign(t *testing.T) {
	var out bytes.Buffer
	c := &Context{Stdout: &out, Format: FormatJSON, Command: "lint"}
	_ = c.Diagnostics(map[string]any{"findings": 1},
		[]Diagnostic{{Severity: "error", Message: "x"}}, nil)
	docs := decodeAll(t, out.Bytes())
	if len(docs) != 1 || !docs[0].OK || docs[0].Exit != ExitOK {
		t.Fatalf("Diagnostics should emit one ok:true envelope, got %+v", docs)
	}
}
