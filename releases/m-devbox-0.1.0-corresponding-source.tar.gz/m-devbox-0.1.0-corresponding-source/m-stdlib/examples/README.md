# `examples/` — living examples + demos

Two kinds of example live here, plus their generated index and two run
reports — [`REPORT.md`](REPORT.md) (the *examples* live tier) and
[`LIVE-QC.md`](LIVE-QC.md) (the *suite* live tier; see below).

## `programs/STD*EX.m` — generated, self-verifying examples ⚠ DO NOT EDIT BY HAND

One self-asserting program per module, **generated** by `tools/gen-examples.py`
(`make examples`) from each module's `@example` tags in `src/STD*.m`. Their job
is to **prove the documented usage examples actually run** — a drift gate on the
docs, not a coverage suite. CI rejects manual edits.

- **Change an example:** edit the `@example` tag in `src/STD*.m`, then run
  `make examples`. Never edit `programs/*EX.m`, [`index.md`](index.md), or
  `REPORT.md` directly — all three are generated.
- **Run:** `make examples-run` (bare, both engines) · `make examples-run-live`
  (nightly `vehu`/`foia` cadence).

## `LIVE-QC.md` — live MSL *suite* tier run report ⚠ GENERATED, DO NOT EDIT

The **suite**-tier sibling of `REPORT.md`: the hand-written `tests/STD*TST.m`
suites run on the LIVE engines (vehu YDB + foia IRIS `VISTA` ns) through the
driver stack, written by `tools/run-live-qc.py` (`make live-qc`) on the same
nightly cron. It records each engine's identity (`$ZYRELEASE` / IRIS build) and,
on a red, the failing assertion lines — so an engine-**version**-sensitive
regression the bare CI tier can't see (e.g. STDJSONTST on vehu / YDB r2.02) is
diagnosable from the committed diff. **Fail-soft** — a red is a committed diff,
not a failed job; the bare tier in CI stays the hard gate. A run snapshot, not
drift-gated. See the continuous-live-QC harness proposal (central `docs` repo).

## `std*-demo.m` — hand-written onboarding demos

Runnable, hand-written tutorials for a few common modules (`stdargs`, `stdcsv`,
`stdjson`, `stdlog`) showing a realistic end-to-end workflow. Edited by hand;
add one when a module is popular enough to warrant a "here's the whole shape"
walkthrough.

## `data/` — sample input files used by the demos and examples.

---

These are two of three verification surfaces — see
[`docs/guides/verification-surfaces.md`](../docs/guides/verification-surfaces.md)
for how `examples/` relates to the hand-written `tests/STD*TST.m` suites.
