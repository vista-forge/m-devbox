stdjsondemo     ; m-stdlib STDJSON demo — parse, walk, encode.
        ;
        ; A runnable taste of STDJSON: parse a document into a caller-owned
        ; tree, walk it, read scalars, then round-trip back to text. Each node
        ; carries a one-character sigil (o=object, a=array, s:=string, n:=number,
        ; t=true, f=false, z=null).
        ;
        ; KEY IDIOM: to read a node's scalar with $$valueOf, merge its subtree
        ; into a WHOLE local first — a subscripted by-reference actual like
        ; `.tree("name")` is rejected by YottaDB/GT.M (M-MOD-037).
        ;
        ; Try:
        ;   yottadb -run ^stdjsondemo
        ;
        do main()
        quit
        ;
main()  ; Parse a sample doc, walk it, and re-encode it.
        new tree,doc
        set doc="{""name"":""ada"",""langs"":[""m"",""go""],""active"":true}"
        if '$$parse^STDJSON(doc,.tree) write "json error: ",$$lastError^STDJSON(),! quit
        ;
        write "name   : ",$$scalar(.tree,"name"),!
        write "active : ",$$scalar(.tree,"active"),!
        write "langs  :",!
        do langs(.tree)
        write "re-encoded: ",$$encode^STDJSON(.tree),!
        quit
        ;
scalar(tree,key)        ; The scalar value at tree(key) (merge then valueOf).
        new n
        merge n=tree(key)
        quit $$valueOf^STDJSON(.n)
        ;
langs(tree)     ; Print each element of the langs array.
        new i,el
        set i=""
        for  set i=$order(tree("langs",i)) quit:i=""  do
        . merge el=tree("langs",i)
        . write "  - ",$$valueOf^STDJSON(.el),!
        . kill el
        quit
