stdlogdemo      ; m-stdlib STDLOG demo — structured key=value logging.
        ;
        ; One line per record: "<ISO-8601 UTC ts> level=<NAME> event=<event>
        ; k=v ...". The level sets the threshold; sub-threshold lines are
        ; dropped at no cost. Switch to JSON-line output with FORMAT.
        ;
        ; Try:
        ;   yottadb -run ^stdlogdemo
        ;
        do main()
        quit
        ;
main()  ; Emit a few records at different levels and formats.
        do LEVEL^STDLOG("INFO")                         ; drop DEBUG and below
        do INFO^STDLOG("login","user","alice","ip","1.2.3.4")
        do DEBUG^STDLOG("trace","step","7")             ; dropped (sub-threshold)
        do WARN^STDLOG("retry","attempt","3")
        do ERROR^STDLOG("db_failed","sqlcode","-803")
        ;
        write "--- JSON-line format ---",!
        do FORMAT^STDLOG("json")
        do INFO^STDLOG("login","user","bob","ip","10.0.0.9")
        quit
