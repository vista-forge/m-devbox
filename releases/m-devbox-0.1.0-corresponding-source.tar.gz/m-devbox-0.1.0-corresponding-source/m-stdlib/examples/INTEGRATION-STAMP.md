# INTEGRATION tier — freshness anchor

generated: 2026-07-27T05:30:08Z
net: m-stdlib STDS3 end-to-end round-trip against a live MinIO/S3 sink (STDS3MINIOTST)
tier: INTEGRATION
engine: m-test-engine (ydb) + MinIO S3 testbed
suites_discovered: 1
ran: 1
passed: 1
verdict: green

Opt-in test tier freshness anchor (safety-net-reconciliation P1-N4). This tier
runs in no PR-gated context — it is exercised only on demand / on a scheduled
cadence — so nothing would notice if it stopped running. `tools/stamp-tier.py`
rewrites this file with a fresh `generated:` line + the RECONCILED counts ONLY
after a fully green run (every discovered suite ran and passed). The org
meta-gate reds if this anchor is stale, absent, or the counts do not reconcile,
so this opt-in tier can no longer silently stop being exercised. DO NOT
hand-edit — it is regenerated; a stale timestamp IS the alarm.
