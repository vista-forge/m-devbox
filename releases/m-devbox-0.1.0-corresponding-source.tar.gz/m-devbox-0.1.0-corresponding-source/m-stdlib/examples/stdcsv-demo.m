stdcsvdemo      ; m-stdlib STDCSV demo — parse and write RFC-4180 CSV.
        ;
        ; parse() populates rows(i,j); write() inverts a rows() array back to
        ; CSV text (quoting fields that need it). Round-trips cleanly.
        ;
        ; Try:
        ;   yottadb -run ^stdcsvdemo
        ;
        do main()
        quit
        ;
main()  ; Parse a small CSV, print a cell, then re-emit it.
        new text,rows,n,out
        set text="name,role"_$char(13,10)_"ada,eng"_$char(13,10)_"grace,""rear admiral"""_$char(13,10)
        set n=$$parse^STDCSV(text,.rows)
        write "rows parsed: ",n,!
        write "rows(2,1)  : ",rows(2,1),!                ; "ada"
        write "rows(3,2)  : ",rows(3,2),!                ; "rear admiral"
        ;
        set out=$$write^STDCSV(.rows)
        write "re-emitted:",!
        write out
        quit
