---
title: Living examples — index
doc_type: [INDEX]
generated_from: dist/stdlib-manifest.json
---

# Living examples

Generated, self-verifying runnable example programs — one per module — built from each module's `@example` tags by `tools/gen-examples.py` (`make examples`). DO NOT edit by hand. Each `examples/programs/<MODULE>EX.m` runs as a suite (`do ^<MODULE>EX`) and asserts its own results.

**Executable-example coverage: 323/359 public labels (89%)** across 40 module program(s). The remaining labels carry no *executable* (`write … ; "expected"`, self-contained) example yet — closing that gap to 100% (with `@raises` error cases + sample data + live-VistA runs) is the Living Executable Examples roadmap (E2–E4).

| Module | Labels | With executable example | Program |
|---|---|---|---|
| `STDARGS` | 7 | 7 | [`STDARGSEX.m`](programs/STDARGSEX.m) |
| `STDASSERT` | 10 | 8 | [`STDASSERTEX.m`](programs/STDASSERTEX.m) |
| `STDB64` | 5 | 5 | [`STDB64EX.m`](programs/STDB64EX.m) |
| `STDCACHE` | 8 | 8 | [`STDCACHEEX.m`](programs/STDCACHEEX.m) |
| `STDCOLL` | 48 | 48 | [`STDCOLLEX.m`](programs/STDCOLLEX.m) |
| `STDCOMPRESS` | 7 | 7 | [`STDCOMPRESSEX.m`](programs/STDCOMPRESSEX.m) |
| `STDCRYPTO` | 28 | 14 | [`STDCRYPTOEX.m`](programs/STDCRYPTOEX.m) |
| `STDCSPRNG` | 8 | 8 | [`STDCSPRNGEX.m`](programs/STDCSPRNGEX.m) |
| `STDCSV` | 4 | 4 | [`STDCSVEX.m`](programs/STDCSVEX.m) |
| `STDDATE` | 9 | 9 | [`STDDATEEX.m`](programs/STDDATEEX.m) |
| `STDENV` | 8 | 8 | [`STDENVEX.m`](programs/STDENVEX.m) |
| `STDFIX` | 5 | 5 | [`STDFIXEX.m`](programs/STDFIXEX.m) |
| `STDFMT` | 2 | 2 | [`STDFMTEX.m`](programs/STDFMTEX.m) |
| `STDFS` | 18 | 18 | [`STDFSEX.m`](programs/STDFSEX.m) |
| `STDHARN` | 3 | 3 | [`STDHARNEX.m`](programs/STDHARNEX.m) |
| `STDHEX` | 4 | 4 | [`STDHEXEX.m`](programs/STDHEXEX.m) |
| `STDHTTP` | 9 | 5 | [`STDHTTPEX.m`](programs/STDHTTPEX.m) |
| `STDHTTPD` | 7 | 6 | [`STDHTTPDEX.m`](programs/STDHTTPDEX.m) |
| `STDHTTPMSG` | 5 | 5 | [`STDHTTPMSGEX.m`](programs/STDHTTPMSGEX.m) |
| `STDJSON` | 8 | 8 | [`STDJSONEX.m`](programs/STDJSONEX.m) |
| `STDJWT` | 5 | 5 | [`STDJWTEX.m`](programs/STDJWTEX.m) |
| `STDKV` | 4 | 4 | [`STDKVEX.m`](programs/STDKVEX.m) |
| `STDLOG` | 8 | 8 | [`STDLOGEX.m`](programs/STDLOGEX.m) |
| `STDMATH` | 6 | 6 | [`STDMATHEX.m`](programs/STDMATHEX.m) |
| `STDMOCK` | 7 | 7 | [`STDMOCKEX.m`](programs/STDMOCKEX.m) |
| `STDNET` | 8 | 8 | [`STDNETEX.m`](programs/STDNETEX.m) |
| `STDOS` | 11 | 7 | [`STDOSEX.m`](programs/STDOSEX.m) |
| `STDPROF` | 11 | 11 | [`STDPROFEX.m`](programs/STDPROFEX.m) |
| `STDREGEX` | 10 | 10 | [`STDREGEXEX.m`](programs/STDREGEXEX.m) |
| `STDS3` | 15 | 5 | [`STDS3EX.m`](programs/STDS3EX.m) |
| `STDSEED` | 5 | 5 | [`STDSEEDEX.m`](programs/STDSEEDEX.m) |
| `STDSEMVER` | 9 | 9 | [`STDSEMVEREX.m`](programs/STDSEMVEREX.m) |
| `STDSIGV4` | 8 | 8 | [`STDSIGV4EX.m`](programs/STDSIGV4EX.m) |
| `STDSNAP` | 4 | 3 | [`STDSNAPEX.m`](programs/STDSNAPEX.m) |
| `STDSTR` | 13 | 13 | [`STDSTREX.m`](programs/STDSTREX.m) |
| `STDTOML` | 4 | 4 | [`STDTOMLEX.m`](programs/STDTOMLEX.m) |
| `STDURL` | 7 | 7 | [`STDURLEX.m`](programs/STDURLEX.m) |
| `STDUUID` | 5 | 5 | [`STDUUIDEX.m`](programs/STDUUIDEX.m) |
| `STDXFRM` | 3 | 3 | [`STDXFRMEX.m`](programs/STDXFRMEX.m) |
| `STDXML` | 13 | 13 | [`STDXMLEX.m`](programs/STDXMLEX.m) |

