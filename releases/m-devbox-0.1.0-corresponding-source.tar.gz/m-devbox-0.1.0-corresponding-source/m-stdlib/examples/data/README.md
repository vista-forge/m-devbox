# examples/data — sample input/output fixtures

Real sample data the living examples read and assert against (CSV / JSON /
fixed-format / binary), organised one subfolder per module
(`data/<module>/…`). Round-trip examples keep an expected-output golden beside
the input (e.g. `people.csv` + `people.expected.csv`).

**Status (E1):** this is the established home; the fixtures themselves land with
the `@fixture`-tag binding and the example backfill (E2–E3 of the Living
Executable Examples proposal — docs `proposals/living-executable-examples.md`).

**Reuse first.** m-stdlib already ships real conformance corpora under
`tests/conformance/{b64,csv,json,url,uuid}/` (RFC vectors). Examples should
reference those rather than re-invent sample inputs; module-specific demo
fixtures live here.

No synthetic PHI. Fixtures are small, curated, and deterministic.
