# m-stdlib

Pure-M (and selectively `$ZF`-bound) runtime library that fills the
highest-impact gaps in M's standard library — assertions, UUIDs,
base64/hex, formatting, structured logging, datetime, CSV, argparse,
fixtures, mocks, seed loaders, JSON, regex, collections, URLs, file
I/O, process / env / cmdline, SemVer, string helpers, TOML, LRU
cache, profiling, snapshot testing, `.env` loaders, XML, numeric
helpers, higher-order array transforms, SHA + HMAC, gzip / deflate /
zstd, and HTTP/1.1.

Sibling project to [m-cli](https://github.com/vista-forge/m-cli) (the
toolchain), [m-standard](https://github.com/vista-forge/m-standard) (the
modern-M style guide), and
[tree-sitter-m](https://github.com/vista-forge/tree-sitter-m) (the parser).

YottaDB-first; IRIS-portable where reasonable.

> **Run the engine in byte (M) mode** (`ydb_chset=M`). m-stdlib is
> byte-oriented: binary routines (STDCSPRNG, STDB64, STDHEX, STDJSON's UTF-8
> decode) assume *one M character == one byte*. Under `ydb_chset=UTF-8`, byte
> values > 127 are re-encoded, so binary results differ and STDCSPRNG requires
> M mode.
>
> **Core is dependency-free; three modules are optional.** STDCOMPRESS
> (libz/libzstd), STDCRYPTO (libcrypto), and STDHTTP need compiled C call-out
> libraries and are tagged `"tier": "optional"` in
> `dist/stdlib-manifest.json`. `make test` runs the dependency-free core;
> `make test-optional` runs the call-out suites.

## Contents

- [1. What this library is](#1-what-this-library-is)
  - [Non-goals](#non-goals)
- [2. Why a standard library, why now](#2-why-a-standard-library-why-now)
  - [The point of a standard library](#the-point-of-a-standard-library)
  - [The alternative is per-site reinvention](#the-alternative-is-per-site-reinvention)
  - [Now because the toolchain finally supports it](#now-because-the-toolchain-finally-supports-it)
- [3. Per-module acceptance gate](#3-per-module-acceptance-gate)
- [4. Module inventory](#4-module-inventory)
- [5. Module reference](#5-module-reference)
- [6. What's next](#6-whats-next)
- [7. Cross-references](#7-cross-references)

## 1. What this library is

`m-stdlib` is a runtime library that fills the highest-impact gaps in
MUMPS / M's standard library: things every other modern runtime ships
out-of-the-box — assertions, UUIDs, base64, JSON, regex, collections,
datetime, logging, CSV, URL parsing, argparse, XML, file I/O,
HTTP, SHA / HMAC, gzip / zstd, and more — but that M historically
shipped only as ad-hoc per-site routines, packages, or, most often,
not at all.

The library is:

- **Pure-M for the entire ergonomics surface; `$ZF`-bound only where
  performance and correctness require it.** Phases 1, 1b, 2, and the
  P4 promotion wave are 100% pure M (no host callouts). Phase 3 — the
  three modules that bind to libcrypto / libz / libzstd / libcurl
  (`STDCRYPTO`, `STDCOMPRESS`, `STDHTTP`) plus the byte-faithful
  arms of `STDFS` and `STDCSPRNG` — uses YottaDB's `$&pkg.fn`
  external-call ABI through a shared deployment harness
  (`scripts/seed-callouts.sh`). Routines are upper-case
  six-or-fewer-character names per the M routine-name convention,
  prefixed `STD*` (the prefix is reserved family-wide).
- **YottaDB-first; IRIS-portable where reasonable.** Every pure-M
  module passes against the `intersystemsdc/iris-community` image on
  the **bare IRIS test tier** (`m-test-iris`), run offline by
  `make test` beside the YottaDB tier, except where a feature is
  structurally engine-specific (e.g. YDB `view "TRACE"` for coverage).
- **Sibling to `m-cli`** (the toolchain), `m-standard` (the modern-M
  style guide), and `tree-sitter-m` (the parser). Architectural rule:
  **m-stdlib has priority over m-cli**. When both projects need a
  utility it lands here first; m-cli imports.

### Non-goals

- **Not a framework.** No global registries, no init hook, no
  dependency injection. Each module is a flat routine; you `do`-call
  or `$$`-call public labels.
- **Not a compatibility shim.** Does not paper over differences
  between YDB and IRIS — `STDREGEX` runs a Thompson-NFA on every
  engine, but the public API is what's portable, not the
  implementation.
- **Not a security boundary.** Nothing in m-stdlib enforces
  authentication, authorisation, or input sanitisation across trust
  domains. Treat it as a library, not a gateway.
- **Not a TDD framework, though seven of its modules** —
  `STDASSERT`, `STDFIX`, `STDMOCK`, `STDSEED`, `STDPROF`, `STDSNAP`,
  `STDENV` — are the operational primitives behind the m-cli runner's
  TDD support. If you're building a test suite *on top of* m-stdlib
  rather than just consuming utility code, see
  [`docs/guides/m-tdd-guide.md`](docs/guides/m-tdd-guide.md) for the integrated workflow.

## 2. Why a standard library, why now

### The point of a standard library

A standard library exists to enable **rapid, reliable, reproducible,
portable** development with **minimal re-invention**. Every other
modern runtime — Python, Go, Rust, Node, Java — assumes you can call
into a single canonical answer for base64, JSON, regex, datetime,
collections, HTTP, crypto digests, and the rest, and that the answer
behaves the same on every supported platform. `m-stdlib` brings the
same guarantee to MUMPS / M:

- **Rapid** because the canonical answer is one `$$call^STDxxx`
  away — no scaffolding, no shopping for which `^XB*` routine the
  current site happens to use this quarter.
- **Reliable** because every module ships with a vendored conformance
  corpus tied to the relevant RFC or NIST publication (RFC-4648 for
  base64/hex, RFC-4180 for CSV, RFC 8259 for JSON, RFC 3986 for URLs,
  RFC 4122/9562 for UUIDs, FIPS 180-4 for SHA, RFC 4231 for HMAC,
  the JSONTestSuite for JSON edge cases, the W3C XML Test Suite for
  XML, …) and runs all of it on every commit.
- **Reproducible** because the test corpus runs against a containerised
  YottaDB endpoint (`vista-meta`) — the same engine the upstream
  consumers run, with no host-side YDB install to drift.
- **Portable** because IRIS is a first-class CI target: every pure-M
  module is verified against `intersystemsdc/iris-community:latest`
  in fail-soft CI. Phase 3 callouts are YDB-only by design and
  document that explicitly.
- **Minimal re-invention** because contributing a fix at the library
  level fixes it for every consumer instead of the diff propagating
  ad-hoc through forks of `^XB*BASE64` across forty sites.

### The alternative is per-site reinvention

Every M shop with more than a few engineers has a private `^XB*`,
`^DI*`, or `^%Z*` routine that does base64 encoding, JSON parsing,
date arithmetic, or string formatting. Each of those private routines
has its own bug history, its own un-versioned conventions, and its
own opinions about what to do at edge cases. `m-stdlib` publishes a
canonical answer per concern.

### Now because the toolchain finally supports it

The library only works because the toolchain landed first:

- **`m-cli`** ships `m fmt` (style enforcement), `m lint` (XINDEX
  rules + ASTGREP-driven analyses), `m test` (test discovery +
  execution + TAP/JUnit output + coverage minimums + `--changed`
  diff-driven runs + `--seed` / `--update-snapshots` / `--env` /
  `--timings` / `--no-isolation` flags consuming the seven m-cli-
  integrated TDD primitives), and `m coverage` (line + branch +
  LCOV / JSON).
- **`tree-sitter-m`** parses M into a real AST so per-module docs,
  lint rules, and coverage tooling can target language constructs
  rather than line patterns.
- **`vista-meta`** publishes a containerised YottaDB endpoint so
  `make test` runs against a real engine without a host install. The
  dual-engine bare tier adds an IRIS container (`m-test-iris`) beside it.

The toolchain is what makes the canonical-answer guarantee
mechanically enforceable — a per-module §9 acceptance gate
(fmt-check + lint + tests + coverage) blocks any release that drifts.

## 3. Per-module acceptance gate

Every module follows the same gate. The fast inner loop:

```bash
make check        # fmt-check + lint + test — under a minute on the dev box
```

The release-readiness loop (what the pre-push hook and the offline
forge-ci sweep run):

```bash
make ci           # check + JUnit XML + LCOV coverage at min-percent 85
```

The per-module §9 acceptance gate, applied before any `vN.N.N` tag:

| Gate | Tool | Command | Pass threshold |
|---|---|---|---|
| Format | `m fmt --check` | `make fmt-check` | clean (no diffs) |
| Lint | `m lint --error-on=error` | `make lint` | 0 errors |
| Tests | `m test --format=tap` | `make test` | 100 % assertions pass |
| Coverage | `m coverage --min-percent=85` | `make coverage` | ≥ 85 % per-module label coverage (most modules ship at 100 %) |
| IRIS portability | `m-test-iris` bare tier | `make test` (dual-engine) | fail-soft — surfaces regressions but does not gate merges |

The `make check` invocation talks to vista-meta's YottaDB container
over SSH (`~/data/vista-meta/conn.env`), so there is no host YDB
install to manage. For projects building tests on top of m-stdlib's
TDD primitives, per-test isolation, mocking, fixture seeding, and
the runner-protocol details live in [`docs/guides/m-tdd-guide.md`](docs/guides/m-tdd-guide.md).

## 4. Module inventory

Generated from the drift-gated
[`dist/stdlib-manifest.json`](dist/stdlib-manifest.json) (the same source as
[`docs/modules/`](docs/modules/index.md) and the skill) — per-module backend,
m-cli companion, and gate detail live on each module's page and in
[`docs/module-tracker.md`](docs/module-tracker.md).

<!-- gen:begin block=modules -->
| Module | Tier | Summary |
|---|---|---|
| [`STDARGS`](docs/modules/stdargs.md) | core | argparse |
| [`STDASSERT`](docs/modules/stdassert.md) | core | assertion library |
| [`STDB64`](docs/modules/stdb64.md) | core | RFC-4648 Base64 (standard + URL-safe) |
| [`STDCACHE`](docs/modules/stdcache.md) | core | LRU + TTL cache over a caller-owned local array |
| [`STDCOLL`](docs/modules/stdcoll.md) | core | collections (Set, Map, Stack, Queue, Deque, Heap, OrderedDict) |
| [`STDCOMPRESS`](docs/modules/stdcompress.md) | optional | gzip / deflate / zstd via $&stdcompress callouts |
| [`STDCRYPTO`](docs/modules/stdcrypto.md) | optional | Cryptographic digests via $&stdcrypto → libcrypto |
| [`STDCSPRNG`](docs/modules/stdcsprng.md) | core | Cryptographic random (kernel CSPRNG via getrandom(2) \| /dev/urandom \| IRIS GenCryptRand) |
| [`STDCSV`](docs/modules/stdcsv.md) | core | RFC-4180 CSV parser/writer (pure-M) |
| [`STDDATE`](docs/modules/stddate.md) | core | ISO-8601 datetime + arithmetic |
| [`STDENV`](docs/modules/stdenv.md) | core | .env file loader with typed accessors |
| [`STDFIX`](docs/modules/stdfix.md) | core | fixture lifecycle and per-test isolation |
| [`STDFMT`](docs/modules/stdfmt.md) | core | printf-style formatter (subset of Python str.format) |
| [`STDFS`](docs/modules/stdfs.md) | core | File-system primitives (text I/O, path manipulation, bytes) |
| [`STDHARN`](docs/modules/stdharn.md) | core | resident test/coverage harness orchestrator |
| [`STDHEX`](docs/modules/stdhex.md) | core | RFC-4648 §8 hex encoding (lowercase by default) |
| [`STDHTTP`](docs/modules/stdhttp.md) | optional | HTTP/1.1 client (track H3, target tag v0.4.0) |
| [`STDHTTPD`](docs/modules/stdhttpd.md) | core | portable HTTP server framework (router + middleware + worker loop) |
| [`STDHTTPMSG`](docs/modules/stdhttpmsg.md) | core | pure-M HTTP/1.1 parse+serialize codec (the §5 seam) |
| [`STDJSON`](docs/modules/stdjson.md) | core | RFC 8259 JSON parser + serialiser |
| [`STDJWT`](docs/modules/stdjwt.md) | optional | JSON Web Token (RFC 7519 / 9068) validation |
| [`STDKV`](docs/modules/stdkv.md) | core | minimal keyed record-store seam (the S1 storage contract) |
| [`STDLOG`](docs/modules/stdlog.md) | core | structured key=value logger |
| [`STDMATH`](docs/modules/stdmath.md) | core | Numeric helpers (clamp / min / max / sum / count / mean over arrays) |
| [`STDMOCK`](docs/modules/stdmock.md) | core | opt-in test-time call interception (mock registry) |
| [`STDNET`](docs/modules/stdnet.md) | optional | portable raw-TCP socket primitives (engine-native sockets) |
| [`STDOS`](docs/modules/stdos.md) | core | Process / env / cmdline helpers (dual-engine: YDB + IRIS) |
| [`STDPROF`](docs/modules/stdprof.md) | core | Wall-clock profiler with per-tag aggregates + percentiles |
| [`STDREGEX`](docs/modules/stdregex.md) | core | regular expressions (track L12, v0.2.0) |
| [`STDS3`](docs/modules/stds3.md) | optional | AWS S3 REST client (PutObject / GetObject / List / multipart) |
| [`STDSEED`](docs/modules/stdseed.md) | core | declarative test data loader |
| [`STDSEMVER`](docs/modules/stdsemver.md) | core | SemVer 2.0.0 parse / compare / range matching |
| [`STDSIGV4`](docs/modules/stdsigv4.md) | optional | AWS Signature Version 4 request signer |
| [`STDSNAP`](docs/modules/stdsnap.md) | core | Snapshot testing: serialize an M tree, diff against a baseline |
| [`STDSTR`](docs/modules/stdstr.md) | core | String helpers (pad / trim / split / replaceAll / case / repeat) |
| [`STDTOML`](docs/modules/stdtoml.md) | core | TOML 1.0 parser (deliberately narrow v1 subset) |
| [`STDURL`](docs/modules/stdurl.md) | core | RFC 3986 URI parser, builder, encoder, resolver |
| [`STDUUID`](docs/modules/stduuid.md) | core | UUID v4 + v7 (RFC 4122 / RFC 9562) |
| [`STDXFRM`](docs/modules/stdxfrm.md) | core | Higher-order array transforms (map / filter / reduce via @-indirection lambdas) |
| [`STDXML`](docs/modules/stdxml.md) | core | XML parser (well-formed XML 1.0 subset, in-progress) |
<!-- gen:end -->

Current per-module gate results, coverage, and suite counts live in the
generated [`docs/modules/index.md`](docs/modules/index.md) and in
[`docs/module-tracker.md`](docs/module-tracker.md) (live status, in-flight
extensions, proposed modules) — not in this file. Every module ships with a
`*TST.m` suite run by `m test` on both engines.

## 5. Module reference

The per-module five-minute orientation — one subsection for every
shipped module, with the public surface, typical usage pattern, and
the conformance corpus tied to it — lives in the user's guide:

→ **[`docs/guides/users-guide.md` § 4](docs/guides/users-guide.md#4-module-reference)**

For each module that section gives:

- The headline plus the one-line "why you'd reach for this".
- The minimal code example you'd write as a first call.
- The per-module backend (pure-M vs. `$&pkg.fn` callout) with the
  deployment runbook where relevant.
- A pointer into the authoritative per-module document at
  [`docs/modules/<module>.md`](docs/modules/) for the full label
  list, error codes, edge cases, and extended examples.

The canonical inventory (one row per shipped module, conformance
corpus pointers, cross-module dependency map) is at
[`docs/modules/index.md`](docs/modules/index.md).

## 6. What's next

Live work — proposed modules, in-flight extensions, deferred ToDos —
is tracked in [`docs/module-tracker.md`](docs/module-tracker.md). Open
toolchain bugs that block or limit m-stdlib work live in
[`docs/discoveries.md`](docs/discoveries.md).
Release history is in [`docs/changelog.md`](docs/changelog.md).

## 7. Cross-references

The `docs/` tree uses the org-standard layout (normalized 2026-06-28):
**guides/** (long-form orientation), **modules/** (per-module authoritative API
docs + conformance-corpus pointers), **design/** (this repo's own design notes +
forward plans), **memory/** (auto-memory), and **archive/** (retired docs,
including the point-in-time corpus-validation reports). Live work boards sit at
`docs/` root.

### `docs/guides/` — long-form orientation

- [`docs/guides/users-guide.md`](docs/guides/users-guide.md) — full user's guide, including the § 5 per-module reference that this README links to.
- [`docs/guides/m-tdd-guide.md`](docs/guides/m-tdd-guide.md) — operational TDD guide for projects building tests on top of m-stdlib's seven m-cli-integrated TDD primitives (STDASSERT / STDFIX / STDMOCK / STDSEED / STDPROF / STDSNAP / STDENV).

### `docs/modules/` — per-module authoritative API docs

- [`docs/modules/index.md`](docs/modules/index.md) — canonical module inventory grouped by phase (v0.1.0 / v0.1.1–v0.1.3 / v0.2.0 / v0.3.0 / v0.4.0); conformance corpus + cross-module dependency map.
- One file per shipped module — `docs/modules/<name>.md` — full label list, error codes, edge cases, extended examples. The **§ 4 Module inventory** table above links each module row directly into its per-module page.

### `docs/design/` — design notes + forward plans

- [`docs/proposals/future-modules-plan.md`](docs/proposals/future-modules-plan.md) — proposal pipeline / parking lot for module candidates that haven't crossed TDD-red yet.
- [`docs/design/m-stdlib-s3-design.md`](docs/design/m-stdlib-s3-design.md) — S3 connector design (realized as the shipped STDSIGV4 + STDS3).
- [`docs/design/vista-de-facto-library-analysis.md`](docs/design/vista-de-facto-library-analysis.md) — empirical census of code reuse/redundancy in VistA.
- `vista-library-promotion-plan.md` — forward `v lib` plan; **moved to the central `docs` repo** (`proposals/vista-library-promotion-plan.md` — cross-repo proposals live there); awaits graduation to the `v-cli` repo.

### `docs/archive/` — corpus validation reports (point-in-time snapshots)

- [`docs/archive/realcode-validation.md`](docs/archive/realcode-validation.md) — toolchain-side findings against `m-modern-corpus`; STD\* prefix collision-free across 4,215 routines; lint matrix per project.
- [`docs/archive/modern-m-corpus-test-results.md`](docs/archive/modern-m-corpus-test-results.md) — library-fit findings; concrete LOC reductions in real projects (e.g. `_zewdJSON.m` 833 LOC → STDJSON ~50).
- [`docs/archive/vista-corpus-lint-results.md`](docs/archive/vista-corpus-lint-results.md) — lint results against the VistA M corpus, calibrating the `pythonic` profile against legacy code.

### `docs/` root — live work boards

- [`docs/module-tracker.md`](docs/module-tracker.md) — canonical per-module tracker (Summary table + closed-ticket archaeology + Must-know). Per-module deep history at [`docs/modules/<m>.md` § History](docs/modules/); proposal pipeline at [`docs/proposals/future-modules-plan.md`](docs/proposals/future-modules-plan.md).
- [`docs/discoveries.md`](docs/discoveries.md) — discoveries register: in-project pivots + external toolchain findings, with severity / plan impact / status.
- [`docs/changelog.md`](docs/changelog.md) — release history.
- [`docs/TODO.md`](docs/TODO.md) — resume-here pointer; thin index over the tracker.

### `docs/archive/` — retired docs (`git mv`'d)

Completed-effort plans/trackers and executed prompts, e.g.
[`m-stdlib-implementation-plan.md`](docs/archive/m-stdlib-implementation-plan.md),
[`tdd-orchestration-plan.md`](docs/archive/tdd-orchestration-plan.md),
[`m-libraries-remediation.md`](docs/archive/m-libraries-remediation.md), and the
[`parallel-tracks.md`](docs/archive/parallel-tracks.md) dispatch view.

## Releases

Releases are **annotated git tags** (`git tag -a vX.Y.Z && git push origin vX.Y.Z`)
— forge-agnostic by design (de-GitHub ruling Q3, 2026-07-18). The former GitHub
Releases workflow is retired; distribution artifacts (`dist/`, `kids/MSL.kids`)
are committed in-repo at the tag, so a checkout of the tag IS the release.

## License

[AGPL-3.0-or-later](LICENSE) / [`NOTICE`](NOTICE) (dual-licensed, commercial option) — the vista-forge org-wide
license across the m/v toolchain.
