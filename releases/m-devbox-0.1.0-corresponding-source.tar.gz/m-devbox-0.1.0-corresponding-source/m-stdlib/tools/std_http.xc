$STDLIB_LIB/http.so
perform: ydb_int_t http_perform(I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*, I:ydb_long_t, I:ydb_long_t, I:ydb_long_t, O:ydb_int_t*, O:ydb_string_t*[1048576], O:ydb_string_t*[1048576], O:ydb_string_t*[256])
available: ydb_long_t http_available()
