"""mdoc_config.py — m-stdlib's RepoConfig for the shared mdoc core (W5).

This file is the ONLY place m-stdlib's repo-specific doc-toolchain knowledge
lives: the m-only registry tags (@tag/@phase — F8 frontmatter ownership), the
house helper-raise idiom (`do raise("SUFFIX")`, suffix group → U-<MOD>-<SUFFIX>),
the standing raise exemptions, and the changelog path history. The parser
itself is the sibling-shared `tools/mdoc/` package.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mdoc import RepoConfig, Tag  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parent.parent

# m-only registry tags, appended after the shared set (the §5.17/5.18 grammar
# sections). Moved verbatim from the retired tools/mdoc_tags.py.
EXTRA_TAGS = (
    Tag("@tag", "module", "0..1", "VERSION", "tag",
        "The release version this module first shipped in — the owner of the "
        "per-module `tag`/`since` frontmatter fields (routine-header tag). "
        "Replaces the old hand-written docs/modules/index.md table as the input.",
        '@tag v0.2.0'),
    Tag("@phase", "module", "0..1", "BODY", "phase",
        "The delivery phase/wave this module shipped in — the owner of the "
        "per-module `phase` frontmatter field (routine-header tag). The body is "
        "free text (may contain spaces), e.g. 'Phase 5 — web stack + AWS S3 egress'.",
        '@phase Phase 2'),
)

CONFIG = RepoConfig(
    lib_name="stdlib",
    repo_root=REPO_ROOT,
    src_glob="STD*.m",
    manifest_filename="stdlib-manifest.json",
    extra_tags=EXTRA_TAGS,
    foreign_tags=frozenset(),
    # m-stdlib's house helper is `do raise("SUFFIX")` backed by
    # `set $ecode=",U-<MODULE>-"_err_","` (STDARGS/STDFMT/STDREGEX — the L12
    # Pass B fresh-frame raise pattern); the call site carries only the suffix.
    # STDJSON's `do raise(.ctx,msg)` takes a MESSAGE, not a code — deliberately
    # unmatched (its fixed code is a literal site inside its raise helper).
    helper_raise_res=(
        re.compile(r'\bdo raise\("(?P<suffix>[A-Z][A-Z0-9-]*)"\)'),
    ),
    raise_exempt={
        # STDREGEX raises these via `do raise(err)` where err is DATA
        # (st("err")="BAD-PATTERN"/"UNSUPPORTED" set deep in the parser) — no
        # static site carries the code. Both are demonstrated LIVE by compile's
        # raises^STDASSERT examples (the nightly examples cadence executes them).
        "U-STDREGEX-BAD-PATTERN":
            'raised via do raise(err) with a data-flow code (st("err")); '
            "statically invisible — demonstrated by compile's raises-example",
        "U-STDREGEX-UNSUPPORTED":
            'raised via do raise(err) with a data-flow code (st("err")); '
            "statically invisible — demonstrated by compile's raises-example",
        # shaLen's defensive guard: every caller passes a literal valid name
        # ("sha256"/"sha384"/"sha512"), so this cannot fire through the public
        # API — documenting it as a public @raises would be false.
        "U-STDCRYPTO-BAD-ALGO":
            "defensive guard in @internal shaLen; unreachable via the public API "
            "(all callers pass literal valid algorithm names)",
    },
    publicness_exempt={},
    # The changelog has lived at a few paths over time: `CHANGELOG.md` at the
    # repo root, then `docs/tracking/changelog.md`, and (after the 2026-06-28
    # docs-layout normalization) `docs/changelog.md`. Current path first,
    # older ones for back-compat with earlier checkouts.
    changelog_paths=("docs/changelog.md", "docs/tracking/changelog.md", "CHANGELOG.md"),
    parse_module_tag_phase=True,
)
