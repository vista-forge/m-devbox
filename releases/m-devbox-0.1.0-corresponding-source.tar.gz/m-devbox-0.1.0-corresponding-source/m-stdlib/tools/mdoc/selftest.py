"""mdoc.selftest — the SHARED golden corpus (stdlib-doc-accuracy W5).

One synthetic-config self-test of the core machinery, invoked from EVERY
consumer's gate (m-stdlib / v-stdlib `gen-manifest.py --self-test` inside
`manifest-check`; v-web's `gates`) — so a parser-core change is exercised by
all three repos' gates from the single copy (the Phase 7 acceptance shape).

The config here is SYNTHETIC on purpose: it exercises every config axis (both
helper-raise group shapes, an extra tag, a foreign tag, a publicness
exemption, module/label/manifest hooks, strict + lenient) independent of any
real repo's tag set. Each repo's shell adds only *config-wiring* assertions
for its own RepoConfig on top of this.
"""

from __future__ import annotations

import dataclasses
import re
import shutil
import sys
import tempfile
from pathlib import Path

from . import core
from .config import RepoConfig
from .tags import Tag

# The synthetic fixture: m-stdlib's proven STDFOO corpus extended with the
# config-axis labels (exempt / foreign-tag / extra-tag) and a tagged header.
FIXTURE = """STDFOO   ; mdoc selftest — fixture module.
        ;
        ; A toy module used only by mdoc.selftest.
        ;
        ; doc: @tag v9.9.9
        ; doc: @phase Test wave
        quit
        ;
greet(who)      ; Say hi to `who` and return the greeting.
        ; doc: @param who    string  the name to greet
        ; doc: @returns      string  the rendered greeting
        ; doc: @example      write $$greet^STDFOO("world")  ; "hello, world"
        ; doc: @since        v0.1.0
        ; doc: @stable       stable
        ; doc: @see          $$bye^STDFOO
        ; doc: @seam         STDFOO v2
        ; doc: A free-form description. Continuation prose lives here.
        quit "hello, "_who
        ;
internalHelper  ; Internal — not part of public API.
        ; doc: @internal
        ; doc: This is documented for maintainers but should not appear in the manifest.
        quit
        ;
silentHelper    ; No doc block → also excluded.
        quit
        ;
exemptLbl       ; No doc block, but config-exempted (printed disposition).
        quit
        ;
midQuit(flag)   ; ONLY value-quit is mid-line (review F4 class i).
        ; doc: @param flag bool  the input
        ; doc: @returns bool  1 when flag is true
        if flag quit 1
        quit
        ;
postQuit(x)     ; ONLY value-quit is postconditioned (review F4 class ii).
        ; doc: @param x int  the input
        ; doc: @returns int  x when positive
        quit:x>0 x
        quit
        ;
noVal(x)        ; Argumentless quits only (incl. postconditioned) — procedure.
        ; doc: @param x int  the input
        quit:x=0
        set x=x+1
        quit
        ;
ftag(x)         ; Carries a foreign-tag line (another generator's input).
        ; doc: @param x int  the input
        ; doc: @returns int  x unchanged
        ; doc: @xforeign 123 machine input for some other generator
        ; doc: Real prose stays in the description.
        quit x
        ;
xt(x)           ; Carries the config extra label tag.
        ; doc: @param x int  the input
        ; doc: @returns int  x unchanged
        ; doc: @xlabel yes
        quit x
"""

# The proven hard-error fixture (verbatim from the pre-extraction self-tests).
BAD_FIXTURE = """STDBAD   ; fixture for the hard-error checks.
        quit
        ;
badTag(x)       ; Unknown tag.
        ; doc: @param x int  the input
        ; doc: @paramz y int  a misspelled tag
        quit
        ;
twoSince(x)     ; Repeated singleton tag.
        ; doc: @param x int  the input
        ; doc: @since v0.1.0
        ; doc: @since v0.2.0
        quit
        ;
misParam(a,b)   ; @param set != formallist.
        ; doc: @param a int  first
        ; doc: @param wrong int  not the second formal
        quit
        ;
retProc(x)      ; @returns on a procedure.
        ; doc: @param x int  the input
        ; doc: @returns int  never actually returned
        quit
        ;
extNoRet(x)     ; Extrinsic without @returns.
        ; doc: @param x int  the input
        if x quit 1
        quit
        ;
docRaise(x)     ; A raise in doc text only must NOT count as a site.
        ; doc: @param x int  the input
        ; doc: caller pattern: set $ecode=",U-STDBAD-DOCONLY," quit
        quit
        ;
realRaise(x)    ; An @internal label's raise site is still scanned.
        ; doc: @internal
        set:x<0 $ecode=",U-STDBAD-NEG,"
        quit
        ;
strayDoc(x)     ; A stray comment orphans the doc block (RC-3 / W2).
        ; this stray comment sits above the doc block and would silently drop it
        ; doc: @param x int  the input
        quit
"""


def _module_hook(module, header_body_lines, lines, module_name):
    module["xmod"] = module_name


def _label_hook(entry, tags, ctx):
    # The v-stdlib shape: augment AND re-order (insert after `synopsis`).
    out = {}
    for k, v in entry.items():
        out[k] = v
        if k == "synopsis":
            out["xlbl"] = "@xlabel" in tags
    return out


def _manifest_hook(manifest, modules):
    manifest["xtop"] = len(modules)
    return manifest


def _synthetic_config(root: Path) -> RepoConfig:
    return RepoConfig(
        lib_name="selftest",
        repo_root=root,
        src_glob="STD*.m",
        manifest_filename="selftest-manifest.json",
        extra_tags=(
            Tag("@xtag", "module", "0..1", "BODY", "xtag", "selftest module tag.", "@xtag x"),
            Tag("@xlabel", "label", "0..1", "BODY", "xlbl", "selftest label tag.", "@xlabel yes"),
        ),
        foreign_tags=frozenset({"@xforeign"}),
        helper_raise_res=(
            re.compile(r'\bdo raise\("(?P<suffix>[A-Z][A-Z0-9-]*)"\)'),
            re.compile(r'\bdo vraise\("(?P<code>U-[A-Z][A-Z0-9-]*)"'),
        ),
        raise_exempt={},
        publicness_exempt={"STDFOO.exemptLbl": "selftest disposition"},
        changelog_paths=(),
        parse_module_tag_phase=True,
        module_hook=_module_hook,
        label_hook=_label_hook,
        manifest_hook=_manifest_hook,
        strict=True,
    )


def run(restore: RepoConfig | None = None) -> int:
    """Run the shared corpus. Re-configures the core with `restore` on exit."""
    failures: list[str] = []

    def expect(cond, msg):
        if not cond:
            failures.append(msg)

    tmp = Path(tempfile.mkdtemp())
    try:
        (tmp / "src").mkdir()
        fixture_path = tmp / "src" / "STDFOO.m"
        fixture_path.write_text(FIXTURE, encoding="utf-8")
        cfg = _synthetic_config(tmp)
        core.configure(cfg)

        mod = core.parse_module_file(fixture_path)

        expect(mod["synopsis"] == "mdoc selftest — fixture module.",
               f"module synopsis wrong: {mod['synopsis']!r}")
        expect("greet" in mod["labels"], "greet label missing")
        expect("internalHelper" not in mod["labels"], "internalHelper should be excluded (@internal)")
        expect("silentHelper" not in mod["labels"], "silentHelper should be excluded (no doc block)")

        if "greet" in mod["labels"]:
            g = mod["labels"]["greet"]
            expect(g["form"] == "extrinsic", f"greet should be extrinsic, got {g['form']}")
            expect(g["signature"] == "$$greet^STDFOO(who)",
                   f"signature wrong: {g['signature']!r}")
            expect(g["synopsis"] == "Say hi to `who` and return the greeting.",
                   f"label synopsis wrong: {g['synopsis']!r}")
            expect(len(g["params"]) == 1 and g["params"][0]["name"] == "who",
                   f"params wrong: {g['params']}")
            expect(g["params"][0]["type"] == "string",
                   f"param type wrong: {g['params'][0]}")
            expect(g["returns"] is not None and g["returns"]["type"] == "string",
                   f"returns wrong: {g['returns']}")
            expect(g["since"] == "v0.1.0", f"since wrong: {g['since']!r}")
            expect(g["stable"] == "stable", f"stable wrong: {g['stable']!r}")
            expect("$$bye^STDFOO" in g["see_also"], f"see_also wrong: {g['see_also']}")
            expect(len(g["examples"]) == 1, f"examples count wrong: {g['examples']}")
            expect(g["seam"] is not None and g["seam"]["name"] == "STDFOO"
                   and g["seam"]["contract_version"] == 2,
                   f"seam wrong: {g['seam']}")
            expect(g["description"].startswith("A free-form description"),
                   f"description wrong: {g['description']!r}")
            # label_hook: augment + re-order — `xlbl` sits right after `synopsis`.
            keys = list(g.keys())
            expect(keys.index("xlbl") == keys.index("synopsis") + 1,
                   f"label_hook key placement wrong: {keys}")
            expect(g["xlbl"] is False, "greet has no @xlabel → hook field False")

        # Classifier: the two historically-missed value-quit classes (F4).
        for lbl in ("midQuit", "postQuit"):
            expect(lbl in mod["labels"], f"{lbl} label missing")
            if lbl in mod["labels"]:
                expect(mod["labels"][lbl]["form"] == "extrinsic",
                       f"{lbl} should be extrinsic, got {mod['labels'][lbl]['form']}")
        expect("noVal" in mod["labels"] and mod["labels"]["noVal"]["form"] == "procedure",
               "noVal (argumentless quits only) should be procedure")

        # Config axes on the clean fixture.
        expect(mod.get("tag") == "v9.9.9" and mod.get("phase") == "Test wave",
               f"@tag/@phase extraction wrong: {mod.get('tag')!r}/{mod.get('phase')!r}")
        expect("doc:" not in mod["description"],
               f"header doc: lines leaked into description: {mod['description']!r}")
        expect(mod.get("xmod") == "STDFOO", "module_hook did not run")
        if "ftag" in mod["labels"]:
            expect("@xforeign" not in mod["labels"]["ftag"]["description"],
                   f"foreign tag leaked into description: {mod['labels']['ftag']['description']!r}")
            expect(mod["labels"]["ftag"]["description"].startswith("Real prose"),
                   f"prose after foreign line lost: {mod['labels']['ftag']['description']!r}")
        expect("xt" in mod["labels"], "extra-tag label missing")
        if "xt" in mod["labels"]:
            expect(mod["labels"]["xt"]["xlbl"] is True,
                   "extra label tag @xlabel not visible to label_hook")
        expect(core.PROBLEMS == [],
               f"clean fixture should produce no problems, got {core.PROBLEMS}")

        # W2 publicness accounting: 9 col-1 labels = 6 documented (greet,
        # midQuit, postQuit, noVal, ftag, xt) + 1 @internal + 1 exempt
        # (exemptLbl, via config) + 1 unaccounted (silentHelper).
        expect(core.PUBLICNESS["col1"] == 9, f"col1 count wrong: {core.PUBLICNESS}")
        expect(core.PUBLICNESS["documented"] == 6, f"documented count wrong: {core.PUBLICNESS}")
        expect(core.PUBLICNESS["internal"] == 1, f"internal count wrong: {core.PUBLICNESS}")
        expect(core.PUBLICNESS["exempt"] == 1, f"exempt count wrong: {core.PUBLICNESS}")
        expect(len(core.UNACCOUNTED) == 1 and core.UNACCOUNTED[0].endswith("STDFOO.silentHelper"),
               f"unaccounted should be exactly [silentHelper], got {core.UNACCOUNTED}")
        expect(core.PUBLICNESS["col1"] == core.PUBLICNESS["documented"]
               + core.PUBLICNESS["internal"] + core.PUBLICNESS["exempt"]
               + len(core.UNACCOUNTED), "publicness invariant broken")

        # Seam aggregation: build_seams over a one-module dict.
        seams = core.build_seams({"STDFOO": mod})
        expect("STDFOO" in seams, "STDFOO seam missing from build_seams")
        if "STDFOO" in seams:
            expect(seams["STDFOO"]["contract_version"] == 2,
                   f"seam contract_version wrong: {seams['STDFOO']}")
            eps = seams["STDFOO"]["entry_points"]
            expect(len(eps) == 1 and eps[0]["label"] == "$$greet^STDFOO(who)",
                   f"seam entry_points wrong: {eps}")

        # build_manifest end-to-end over src/ (glob + manifest_hook plumbing).
        manifest, _errs = core.build_manifest()
        expect(manifest.get("xtop") == 1, "manifest_hook did not run over build_manifest")
        expect("STDFOO" in manifest["modules"], "build_manifest missed the fixture module")
        expect(manifest["stdlib_version"] == "", "empty changelog_paths should read version ''")

        # Value-quit walk: line-level unit cases (string/postcondition/dot
        # edges the fixture bodies don't reach).
        for line, want in [
            ('        if ok quit 1', True),
            ('        quit:x>0 x', True),
            ('        quit:x=0', False),
            ('        quit', False),
            ('        q 0', True),
            ('        q', False),
            ('        for  set y=1 quit:y  set z=2', False),
            ('        xecute "set x=1 quit 1" quit', False),
            ('        xecute "try { x } catch e { y }" quit ok', True),
            ('        set x=$select(a:"do it",1:"quit 1") quit', False),
            ('        do foo^BAR(a,b) quit ""', True),
            ('        . . set x=1 quit:done x', True),
            ('        set x=1 ; quit 1', False),
        ]:
            expect(core.line_has_value_quit(line) == want,
                   f"line_has_value_quit({line!r}) should be {want}")

        # Hard-error checks: a deliberately-broken fixture must produce one
        # problem per planted contradiction.
        core.PROBLEMS.clear()
        bad_path = tmp / "STDBAD.m"
        bad_path.write_text(BAD_FIXTURE, encoding="utf-8")
        core.parse_module_file(bad_path)
        for needle in ("unknown tag @paramz", "repeated singleton tag @since",
                       "@param set != formallist", "@returns documented on a procedure",
                       "has no @returns", "stray comment line"):
            expect(any(needle in p for p in core.PROBLEMS),
                   f"expected a problem containing {needle!r}, got {core.PROBLEMS}")
        expect(len(core.PROBLEMS) == 6, f"expected exactly 6 problems, got {core.PROBLEMS}")

        # Raise-site scan: code lines only, @internal labels included; BOTH
        # helper idiom group shapes (suffix-expanded and full-code verbatim).
        sites = [c for c, _ in core.collect_raise_sites(BAD_FIXTURE.splitlines(), "STDBAD")]
        expect(sites == ["U-STDBAD-NEG"],
               f"raise sites should be exactly ['U-STDBAD-NEG'] "
               f"(doc-text U-STDBAD-DOCONLY excluded), got {sites}")
        helper_sites = [c for c, _ in core.collect_raise_sites(
            ['        if bad do raise("BOOM") quit'], "STDX")]
        expect(helper_sites == ["U-STDX-BOOM"],
               f"suffix-group helper idiom should yield ['U-STDX-BOOM'], got {helper_sites}")
        code_sites = [c for c, _ in core.collect_raise_sites(
            [' if $get(id)="" do vraise("U-VSL-X-ARG","get: an id is required") quit ""'],
            "VSLX")]
        expect(code_sites == ["U-VSL-X-ARG"],
               f"code-group helper idiom should yield ['U-VSL-X-ARG'], got {code_sites}")

        # Raise verifier: both directions + module attribution + exemption.
        core.PROBLEMS.clear()
        core.verify_raises({"X": []}, {"U-X-GONE": {"modules": {"X": ["a"]}}})
        expect(any("documented-but-never-raised" in p for p in core.PROBLEMS),
               f"never-raised direction missed: {core.PROBLEMS}")
        core.PROBLEMS.clear()
        core.verify_raises({"X": [("U-X-NEW", 5, "src/X.m")]}, {})
        expect(any("raised-but-unregistered" in p for p in core.PROBLEMS),
               f"unregistered direction missed: {core.PROBLEMS}")
        core.PROBLEMS.clear()
        core.verify_raises({"X": [("U-Y-CODE", 5, "src/X.m")]},
                           {"U-Y-CODE": {"modules": {"Y": ["b"]}}})
        expect(any("raised-but-unregistered" in p for p in core.PROBLEMS),
               "a code registered only under ANOTHER module must still red "
               "(module attribution)")
        core.PROBLEMS.clear()
        core.verify_raises({"X": [("U-X-OK", 5, "src/X.m")]},
                           {"U-X-OK": {"modules": {"X": ["a"]}}})
        expect(core.PROBLEMS == [], f"registered raise should be clean: {core.PROBLEMS}")
        # Exemption path — via config, the only way in (RAISE_EXEMPT is
        # configure()-owned state now, not a mutable module global).
        core.configure(dataclasses.replace(cfg, raise_exempt={"U-X-WAIVED": "selftest"}))
        core.verify_raises({"X": [("U-X-WAIVED", 5, "src/X.m")]}, {})
        expect(core.PROBLEMS == [], f"exempted code should be skipped: {core.PROBLEMS}")

        # Lenient (pre-W1) mode: an unknown tag demotes to prose, no problem.
        core.configure(dataclasses.replace(cfg, strict=False))
        parsed = core.parse_doc_block(["@paramz y int  a misspelled tag"], "lenient-test")
        expect(core.PROBLEMS == [], f"lenient mode should not red: {core.PROBLEMS}")
        expect("@paramz" in parsed["description"],
               f"lenient mode should demote the unknown tag to prose: {parsed['description']!r}")

        if failures:
            for f in failures:
                print(f"FAIL: {f}", file=sys.stderr)
            return 1
        print(f"mdoc selftest OK ({len(mod['labels'])} public labels in fixture; "
              f"strict + lenient + both idioms + hooks exercised)")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        if restore is not None:
            core.configure(restore)
