"""mdoc.core — the ONE M-doc parser/verifier core (stdlib-doc-accuracy W5, D-2a).

Extracted 2026-07-19 from the (measured code-identical) m-stdlib/v-stdlib
`gen-manifest.py` backbone; consumed by m-stdlib, v-stdlib and v-web via each
repo's `tools/gen-manifest.py` shell + `tools/mdoc_config.py` (`RepoConfig`).
An RC-2-class parser fix is now a one-repo change picked up by all three
consumers' gates.

Spec: m-stdlib docs/guides/m-doc-grammar.md (the doc-comment grammar this
consumes). This is a hand-rolled parser, not a tree-sitter pass — see the
m-stdlib module tracker D3 for the deferred decision. Labels without a
`; doc:` block (internal helpers) are excluded automatically. The parser is
otherwise STRICT (stdlib-doc-accuracy W1 — the tag↔code verifier): unknown
`@tags`, repeated singleton tags, an `@param` set that differs from the
label's formallist, a `returns`⇄form contradiction, a raise site no label of
its module registers, a documented code no code ever raises, and a version
heading still marked pending/unreleased are all HARD ERRORS — accumulated in
PROBLEMS so one run reports every problem; `run_generate()` exits 2 without
writing outputs, so each repo's `manifest-check` reds.

State model: module-level, initialized by `configure(RepoConfig)` — the shape
the proven per-repo copies used, kept so the extraction is a lift with
line-auditable byte-parity, not a rewrite. Single-threaded generators only.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from . import tags as tags_registry
from .config import RepoConfig

# ── configure(): per-repo state (set from RepoConfig; see config.py) ─────────

CONFIG: RepoConfig | None = None
REPO_ROOT = Path(".")
SRC_DIR = Path("src")
DIST_DIR = Path("dist")
KNOWN_TAGS: set[str] = set()
SINGLETON_TAGS: set[str] = set()
FOREIGN_TAGS: frozenset[str] = frozenset()
HELPER_RAISE_RES: list[re.Pattern] = []
RAISE_EXEMPT: dict[str, str] = {}
PUBLICNESS_EXEMPT: dict[str, str] = {}
MERGED_TAGS: list = []


def configure(cfg: RepoConfig) -> None:
    """Initialize the core for one consumer. Call before any parse/build."""
    global CONFIG, REPO_ROOT, SRC_DIR, DIST_DIR, KNOWN_TAGS, SINGLETON_TAGS
    global FOREIGN_TAGS, HELPER_RAISE_RES, RAISE_EXEMPT, PUBLICNESS_EXEMPT, MERGED_TAGS
    CONFIG = cfg
    REPO_ROOT = cfg.repo_root
    SRC_DIR = REPO_ROOT / "src"
    DIST_DIR = REPO_ROOT / "dist"
    MERGED_TAGS = tags_registry.merged(cfg.extra_tags)
    # DERIVED from the merged registry — the generator cannot drift from the
    # documented grammar; editing the tag set means editing mdoc/tags.py (shared)
    # or the repo's mdoc_config.py extra_tags (repo-only).
    KNOWN_TAGS = tags_registry.label_tags(MERGED_TAGS)
    # Singleton tags (registry multiplicity "0..1"): a repeat is a hard error,
    # not a silent [0] truncation (RC-4 — deflate's second @illustrative was
    # dropped unseen for weeks).
    SINGLETON_TAGS = {t.name for t in MERGED_TAGS
                      if t.level == "label" and t.multiplicity.startswith("0..1")}
    FOREIGN_TAGS = frozenset(cfg.foreign_tags)
    HELPER_RAISE_RES = list(cfg.helper_raise_res)
    RAISE_EXEMPT = dict(cfg.raise_exempt)
    PUBLICNESS_EXEMPT = dict(cfg.publicness_exempt)
    PROBLEMS.clear()
    reset_publicness()


def _relpath(path: Path) -> str:
    """Return path relative to REPO_ROOT when possible; fall back to str(path)."""
    try:
        return str(path.relative_to(REPO_ROOT))
    except ValueError:
        return str(path)


# ── Hard-error accumulator (stdlib-doc-accuracy W1) ─────────────────────────
# Every tag↔code contradiction found during a build lands here; run_generate()
# prints the lot and exits 2 without writing outputs. Checks accumulate rather
# than raise so ONE run reports EVERY problem.
PROBLEMS: list[str] = []

# ── Publicness accounting (stdlib-doc-accuracy W2 / RC-3) ────────────────────
# Every column-1 label is exactly one of: documented (has a `; doc:` block that
# is not @internal → in the manifest), @internal (explicitly marked private,
# excluded from the manifest but ACCOUNTED for), exempt (a printed per-repo
# disposition — PUBLICNESS_EXEMPT), or unaccounted (none of those — the RC-3
# silent omission). The invariant `col1 = documented + internal + exempt +
# unaccounted` is printed on every run; a non-empty UNACCOUNTED red-gates the
# build (return 2, nothing written), turning "748-vs-359" from an unknowable
# gap into a checked invariant.
PUBLICNESS: dict[str, int] = {"col1": 0, "documented": 0, "internal": 0, "exempt": 0}
UNACCOUNTED: list[str] = []  # "file:line MODULE.label" for each offender


def reset_publicness() -> None:
    PUBLICNESS.update({"col1": 0, "documented": 0, "internal": 0, "exempt": 0})
    UNACCOUNTED.clear()


def doc_block_declares_internal(doc_lines: list[str]) -> bool:
    """True iff the `; doc:` block carries an explicit `@internal` marker.

    Mirrors parse_doc_block's `internal` flag without re-parsing (which would
    double-append to PROBLEMS): a doc line whose first token is `@internal`.
    """
    for body in doc_lines:
        if body.lstrip().split(None, 1)[:1] == ["@internal"]:
            return True
    return False


# ── Raise-verifier shared idiom ─────────────────────────────────────────────
# The raise scan is FILE-wide over CODE lines only (comment text stripped, so
# `; doc:` examples can't pollute it — the STDFS `U-OPEN` case) and
# site-level/module-attributed, so raises inside @internal labels are covered.
#
# RAISE_SITE_RE — the house literal idiom: a `",U-<CODE>,"` string literal in
# code position (any expression context: direct `set $ecode=`, `$select(...)`
# arms, concatenations). The per-repo helper idioms (HELPER_RAISE_RES) and the
# exemption list (RAISE_EXEMPT) come from RepoConfig.
RAISE_SITE_RE = re.compile(r'",U-(?P<code>[A-Z][A-Z0-9-]*),"')

# A `@seam` tag body: a seam name (the module/contract it belongs to)
# optionally followed by a contract version `v<N>` (default 1). Examples:
#   @seam STDENV v2
#   @seam STDFS
# The seam name groups entry points into one versioned contract (§5.2 of the
# MSL⟷VSL coordination plan); the contract version bumps only when a seam
# signature changes incompatibly, enforced by the seam-snapshot bump-forcer.
SEAM_BODY_RE = re.compile(r"^(?P<name>[A-Za-z][A-Za-z0-9]*)(?:\s+v(?P<version>\d+))?\s*$")

# A label line at column 1: optional name, optional formal-list, optional inline comment.
# Examples:
#   parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
#   lastError()     ; Return the message from the most recent failed parse.
#   parseFail
LABEL_RE = re.compile(
    r"^(?P<name>[A-Za-z][A-Za-z0-9]*)"
    r"(?:\((?P<formals>[^)]*)\))?"
    r"(?:\s+(?P<rest>.*))?$"
)

# A `; doc:` line. Allow leading whitespace (the routine indent), then `; doc:`,
# then a single optional space, then body.
DOC_LINE_RE = re.compile(r"^\s+;\s*doc:\s?(?P<body>.*)$")

# A regular comment line (not `; doc:`). Used for the routine-header block.
COMMENT_LINE_RE = re.compile(r"^\s+;\s?(?P<body>.*)$")

# A routine line: column 1, ALL-CAPS, then `;` and inline comment.
# YDB allows routine names up to 31 characters; use {0,30} as a sane
# upper bound that catches every stdlib name (STDCOMPRESS at 11 chars is
# the longest today). The 8-char cap previously here was the M89 standard
# limit, which YDB and IRIS both relax.
ROUTINE_LINE_RE = re.compile(
    r"^(?P<name>[A-Z][A-Z0-9]{0,30})\s+;\s?(?P<rest>.*)$"
)

# ── M line scanning (comment stripping + the value-quit classifier) ─────────

def strip_comment(line: str) -> str:
    """Return the code portion of an M line (drop `;` comments, string-aware).

    M string literals are double-quoted with `""` as the escaped quote; a `;`
    inside a string is data, outside it starts the comment. Toggling on every
    `"` handles the `""` escape naturally (it toggles out and straight back in,
    and a `;` can never sit between the two quotes of an escape).
    """
    in_str = False
    for i, ch in enumerate(line):
        if ch == '"':
            in_str = not in_str
        elif ch == ";" and not in_str:
            return line[:i]
    return line


def _skip_expr(code: str, i: int) -> int:
    """Advance past an expression/argument field: to the next space outside a
    string, or EOL. M expressions contain no top-level spaces (space is the
    command separator); spaces occur only inside string literals."""
    n = len(code)
    while i < n:
        ch = code[i]
        if ch == '"':
            i += 1
            while i < n:
                if code[i] == '"':
                    if i + 1 < n and code[i + 1] == '"':
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
            continue
        if ch == " ":
            return i
        i += 1
    return i


def line_has_value_quit(line: str) -> bool:
    """True iff the line contains a value-quit (`quit expr` / `q expr`),
    ANYWHERE on the line, including postconditioned (`quit:cond expr`).

    A per-line command walk (stdlib-doc-accuracy RC-2/F4 — the old
    line-initial `startswith` test missed mid-line value-quits and its
    postcondition branch was dead code, publishing `do f^MOD` for extrinsic
    labels). The walk leans on real M syntax: commands sit at command
    positions; an argumented command is separated from its argument by exactly
    ONE space; an argumentless command is followed by two spaces or EOL; and
    expressions carry no top-level spaces. Argumentless quits (bare or
    postconditioned-only) do NOT count.
    """
    code = strip_comment(line).rstrip()
    if not code:
        return False
    n = len(code)
    i = 0
    # Skip a column-1 label field (name + optional formallist) to the first space.
    if not code[0].isspace():
        while i < n and code[i] != " ":
            i += 1
    while i < n:
        # Skip inter-command whitespace and block-level dots.
        while i < n and code[i] in " \t.":
            i += 1
        if i >= n:
            break
        # Read the command word.
        j = i
        while j < n and code[j].isalpha():
            j += 1
        if j == i:
            # Not a command position we understand (malformed line) — bail.
            return False
        cmd = code[i:j].lower()
        i = j
        # Optional postcondition `:expr` rides the command word.
        if i < n and code[i] == ":":
            i = _skip_expr(code, i)
        # Argument presence: exactly ONE space then a non-space ⇒ argumented;
        # EOL or two+ spaces ⇒ argumentless.
        if i >= n:
            has_arg = False
        else:
            k = i
            while k < n and code[k] == " ":
                k += 1
            has_arg = (k - i == 1) and k < n
            i = k
        if cmd in ("q", "quit") and has_arg:
            return True
        if has_arg:
            i = _skip_expr(code, i)
    return False


def collect_raise_sites(lines: list[str], module_name: str = "") -> list[tuple[str, int]]:
    """All raise sites in a routine: (code, 1-indexed lineno), CODE LINES ONLY.

    File-wide by construction (the caller passes the whole routine), so raises
    inside @internal labels are covered; comment text is stripped first, so
    doc examples cannot pollute the scan (the STDFS `U-OPEN` case).
    """
    sites: list[tuple[str, int]] = []
    for lineno, line in enumerate(lines, start=1):
        code = strip_comment(line)
        if not code.strip():
            continue
        for m in RAISE_SITE_RE.finditer(code):
            sites.append(("U-" + m.group("code"), lineno))
        for helper_re in HELPER_RAISE_RES:
            for m in helper_re.finditer(code):
                groups = m.groupdict()
                if groups.get("suffix"):
                    # Suffix-style helper: the module prefix is implicit.
                    sites.append((f"U-{module_name}-{groups['suffix']}", lineno))
                elif groups.get("code"):
                    # Full-code helper (the v-stdlib house shape): verbatim.
                    sites.append((groups["code"], lineno))
    return sites


def parse_module_file(path: Path) -> dict:
    """Parse one src routine file into a module entry.

    Returns the module dict (without the wrapping {modules: {NAME: ...}}).
    """
    lines = path.read_text(encoding="utf-8").splitlines()
    module = {
        "synopsis": "",
        "description": "",
        "errors": [],
        "labels": {},
        "source": {"file": _relpath(path), "line": 1},
    }

    if not lines:
        return module

    # Line 1: routine line with synopsis as inline comment.
    m = ROUTINE_LINE_RE.match(lines[0])
    if m:
        module_name = m.group("name")
        module["synopsis"] = m.group("rest").strip()
    else:
        # Tolerate a non-conforming first line: derive module name from filename.
        module_name = path.stem.upper()

    # Header block: contiguous comment-only lines following line 1, before the
    # first label. Stops at the first `quit` or non-comment line at module
    # scope (the `quit` that exits the routine head).
    header_body_lines: list[str] = []
    i = 1
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        # Stop at the routine-scope `quit` (which terminates the header).
        # In src/*.m the convention is `        quit` indented at the
        # routine's standard indent.
        stripped = line.strip()
        if stripped.lower() == "quit":
            i += 1
            break
        # Stop at a label line (col 1 alphanum).
        if line[0].isalpha() and not line.startswith(" ") and not line.startswith("\t"):
            break
        cm = COMMENT_LINE_RE.match(line)
        if cm:
            header_body_lines.append(cm.group("body").rstrip())
            i += 1
            continue
        # Anything else — skip silently (could be a setup line we don't care about)
        i += 1

    # The module description is FREEFORM prose only — structured `doc:` tag
    # lines (@tier/@exrun/@exsafe/@tag/@phase/@file/…) are parsed into their own
    # fields below and must not leak into the rendered description (RC-4
    # anti-pollution; the F8 @tag/@phase additions would otherwise prepend to
    # every module's description). The full header_body_lines list is retained
    # for the tag extraction that follows.
    prose_lines = [b for b in header_body_lines if not b.strip().startswith("doc:")]
    module["description"] = "\n".join(prose_lines).strip()

    # Module tier: a header-block "doc: @tier <core|optional>" tag classifies
    # the module. "optional" means it needs a compiled $&/$ZF call-out library
    # to function and is excluded from the dependency-free core (and from the
    # default `make test`). Absent tag → "core".
    tier = "core"
    for body in header_body_lines:
        m_tier = re.match(r"doc:\s*@tier\s+(\S+)", body.strip())
        if m_tier:
            tier = m_tier.group(1).strip().lower()
            break
    module["tier"] = tier

    if CONFIG is not None and CONFIG.parse_module_tag_phase:
        # Module tag + phase (RC-5 / F8 ownership inversion, m-stdlib): @tag is
        # the release version this module first shipped in (owns the frontmatter
        # `tag`/`since` fields); @phase is the delivery wave (owns the
        # frontmatter `phase` field). These replaced the hand-written
        # docs/modules/index.md table as the input — the per-module page
        # frontmatter now derives from the code, not the table. @tag is a
        # single token; @phase is free text (may contain spaces).
        module_tag = ""
        module_phase = ""
        for body in header_body_lines:
            m_tag = re.match(r"doc:\s*@tag\s+(\S+)", body.strip())
            if m_tag:
                module_tag = m_tag.group(1).strip()
            m_phase = re.match(r"doc:\s*@phase\s+(.+)", body.strip())
            if m_phase:
                module_phase = m_phase.group(1).strip()
        module["tag"] = module_tag
        module["phase"] = module_phase

    # Living-examples execution scope + side-effect class (E4). Routine-header
    # tags, same extraction shape as @tier. @exrun = which engine tier runs
    # <MOD>EX.m (dual|ydb|live; absent → dual); @exsafe = the live-VistA
    # side-effect class for the residue safety model (read-only|transactional|
    # illustrative-skip; absent → read-only).
    example_run = "dual"
    example_safety = "read-only"
    for body in header_body_lines:
        m_run = re.match(r"doc:\s*@exrun\s+(\S+)", body.strip())
        if m_run:
            example_run = m_run.group(1).strip().lower()
        m_safe = re.match(r"doc:\s*@exsafe\s+(\S+)", body.strip())
        if m_safe:
            example_safety = m_safe.group(1).strip().lower()
    module["example_run"] = example_run
    module["example_safety"] = example_safety

    # Repo-specific header-derived fields (v-stdlib: @file footprint,
    # @dispatch, call-DAG, sprawl) — via the config hook, so VistA vocabulary
    # never enters the core.
    if CONFIG is not None and CONFIG.module_hook is not None:
        CONFIG.module_hook(module, header_body_lines, lines, module_name)

    # Walk the rest of the file label-by-label.
    while i < len(lines):
        line = lines[i]
        # Label line: column-1 alphabetic identifier.
        if line and line[0].isalpha() and not line[0].isspace():
            label_name, formals, label_synopsis, label_start = parse_label_line(line, i)
            # Find label body bounds: from the next line until the next col-1 label or EOF.
            body_start = i + 1
            body_end = body_start
            while body_end < len(lines):
                ln = lines[body_end]
                if ln and ln[0].isalpha() and not ln[0].isspace():
                    break
                body_end += 1
            ctx = f"{_relpath(path)}:{label_start + 1} {module_name}.{label_name}"
            doc_lines = collect_doc_lines(lines, body_start, body_end, ctx)
            label_body = lines[body_start:body_end]

            # W2 publicness accounting: classify this column-1 label.
            PUBLICNESS["col1"] += 1
            if f"{module_name}.{label_name}" in PUBLICNESS_EXEMPT:
                PUBLICNESS["exempt"] += 1
            elif not doc_lines:
                UNACCOUNTED.append(ctx)
            elif doc_block_declares_internal(doc_lines):
                PUBLICNESS["internal"] += 1
            else:
                PUBLICNESS["documented"] += 1

            entry = build_label_entry(
                module_name=module_name,
                label_name=label_name,
                formals=formals,
                synopsis=label_synopsis,
                doc_lines=doc_lines,
                label_body=label_body,
                source_path=_relpath(path),
                source_line=label_start + 1,  # 1-indexed
            )
            if entry is not None:
                module["labels"][label_name] = entry
                # Aggregate errors at module level.
                for r in entry.get("raises", []):
                    code = r.get("code")
                    if code and code not in module["errors"]:
                        module["errors"].append(code)
            i = body_end
        else:
            i += 1

    return module


def parse_label_line(line: str, lineno: int) -> tuple[str, list[str], str, int]:
    """Parse a label line into (name, formals, synopsis, start_line)."""
    # Split off the inline comment (`;`) — synopsis lives there.
    synopsis = ""
    code = line
    if ";" in line:
        # Find the first `;` that's not inside a string. For label lines
        # this is essentially always the literal `;` because formal-list
        # parens contain only identifiers.
        idx = line.index(";")
        code = line[:idx].rstrip()
        synopsis = line[idx + 1:].strip()
    m = LABEL_RE.match(code.strip())
    if not m:
        return ("", [], synopsis, lineno)
    name = m.group("name")
    formals_raw = m.group("formals") or ""
    formals = [f.strip() for f in formals_raw.split(",") if f.strip()]
    return (name, formals, synopsis, lineno)


def collect_doc_lines(lines: list[str], start: int, end: int, ctx: str = "") -> list[str]:
    """Return the `; doc:` block bodies (in order) within [start, end).

    Only the contiguous run of `; doc:` lines beginning at `start` (skipping
    blanks at the very top is fine) is taken — the doc block is the prefix,
    not random `; doc:` lines deeper in the body.

    Hardened (stdlib-doc-accuracy W2 / RC-3): a stray NON-`doc:` comment line
    that sits between the label and its `; doc:` block used to break the
    contiguous-prefix scan and SILENTLY DROP the whole doc block (making a
    documented label look undocumented). That is now a HARD ERROR — an orphaned
    doc block is a source bug, not a silent omission.
    """
    out: list[str] = []
    i = start
    # Allow leading blank lines (rare).
    while i < end and not lines[i].strip():
        i += 1
    while i < end:
        m = DOC_LINE_RE.match(lines[i])
        if not m:
            break
        out.append(m.group("body").rstrip())
        i += 1
    if out:
        return out
    # No doc block at the top of the body. Distinguish a genuinely
    # undocumented label (fine — W2 accounting handles it) from the RC-3 bug: a
    # stray comment line orphaning a real `; doc:` block that follows it.
    if (
        i < end
        and COMMENT_LINE_RE.match(lines[i])
        and not DOC_LINE_RE.match(lines[i])
        and any(DOC_LINE_RE.match(lines[k]) for k in range(i, end))
    ):
        PROBLEMS.append(
            f"{ctx}: stray comment line {i + 1} separates the label from its "
            f"`; doc:` block — the doc block would be silently dropped; move "
            f"the comment below the doc block or make it a `; doc:` line"
        )
    return out


def parse_doc_block(doc_lines: list[str], ctx: str = "") -> dict:
    """Parse a doc block into structured tag dict + free-form description.

    `ctx` names the owning label (file:line MODULE.label) for hard-error
    messages. An unknown `@tag` and a repeated singleton tag are HARD ERRORS
    (appended to PROBLEMS) — not silently demoted to prose / [0]-truncated.
    (Under a `strict=False` config — the pre-W1 lenient mode — an unknown tag
    demotes to prose instead; everything else is unchanged.)

    Returns: {"tags": {tag_name: [body, body, ...]}, "description": str, "internal": bool}

    Rules (matching docs/guides/m-doc-grammar.md §3):
    - A line whose body's first token is `@<word>` starts a new tag.
    - A non-tag line whose body STARTS WITH WHITESPACE is continuation of the
      most recent tag (extends its body with a newline join).
    - A non-tag line whose body does NOT start with whitespace flushes the
      current tag (if any) and joins the free-form description.
    - An empty `; doc:` line flushes the current tag without ending the doc
      block — anything that follows starts fresh.

    FOREIGN_TAGS lines (other generators' machine input, e.g. `@icr`) are
    recognized and skipped: neither prose nor an error.

    The body strings passed in here have already had the trailing whitespace
    rstripped (collect_doc_lines did that) but their LEADING whitespace is
    preserved — that's the signal the rules above key on.
    """
    tags: dict[str, list[str]] = {}
    description_lines: list[str] = []
    current_tag: str | None = None
    current_buf: list[str] = []
    internal = False

    def flush_tag() -> None:
        nonlocal current_tag, current_buf
        if current_tag is not None:
            tags.setdefault(current_tag, []).append("\n".join(current_buf).rstrip())
        current_tag = None
        current_buf = []

    for raw in doc_lines:
        if not raw.strip():
            flush_tag()
            continue
        stripped = raw.lstrip()
        first_token = stripped.split(None, 1)[0]
        is_indented = bool(raw) and raw[0].isspace()

        if first_token in KNOWN_TAGS:
            flush_tag()
            if first_token == "@internal":
                internal = True
                if "@internal" in tags:
                    PROBLEMS.append(f"{ctx}: repeated singleton tag @internal")
                tags.setdefault("@internal", []).append("")
                # Body ignored; @internal is a flag, not a tag with content.
                continue
            current_tag = first_token
            tail = stripped[len(first_token):].lstrip()
            current_buf = [tail] if tail else []
        elif first_token in FOREIGN_TAGS:
            # Another generator's machine input (e.g. `@icr …` → gen-icr.py):
            # flush and skip — neither prose nor an unknown-tag error.
            flush_tag()
        elif is_indented and current_tag is not None:
            # Indented continuation extends the current tag's body.
            current_buf.append(stripped)
        else:
            # Close the current tag either way — this line does not extend it.
            flush_tag()
            # A tag-shaped first token that is NOT in the registry is a hard
            # error — it would otherwise silently become description prose
            # (RC-4; this replaces the old lenient behavior).
            if re.fullmatch(r"@[A-Za-z][A-Za-z0-9]*", first_token):
                if CONFIG is None or CONFIG.strict:
                    PROBLEMS.append(
                        f"{ctx}: unknown tag {first_token} — register it in "
                        f"mdoc/tags.py (shared) or this repo's mdoc_config.py "
                        f"extra_tags, or fix the spelling"
                    )
                    continue
                # Lenient (pre-W1) mode: demote to prose.
                description_lines.append(stripped)
                continue
            # Non-indented prose line (or indented line outside any tag) →
            # join into the description block.
            description_lines.append(stripped)

    flush_tag()

    for tag_name, bodies in tags.items():
        if tag_name in SINGLETON_TAGS and len(bodies) > 1 and tag_name != "@internal":
            PROBLEMS.append(
                f"{ctx}: repeated singleton tag {tag_name} "
                f"({len(bodies)} occurrences — the grammar allows 0..1; "
                f"merge the bodies or use a continuation line)"
            )

    tags.pop("@internal", None)  # bookkeeping only — `internal` flag carries it.

    return {
        "tags": tags,
        "description": "\n".join(description_lines).strip(),
        "internal": internal,
    }


def build_label_entry(
    *,
    module_name: str,
    label_name: str,
    formals: list[str],
    synopsis: str,
    doc_lines: list[str],
    label_body: list[str],
    source_path: str,
    source_line: int,
) -> dict | None:
    """Construct a label entry, or None if the label should be excluded."""
    if not doc_lines:
        # No `; doc:` block → internal helper. Skip.
        return None

    ctx = f"{source_path}:{source_line} {module_name}.{label_name}"
    parsed = parse_doc_block(doc_lines, ctx)
    if parsed["internal"]:
        return None

    tags = parsed["tags"]

    # Extrinsic vs procedure: a value-quit ANYWHERE in the body (per-line
    # command walk — mid-line and postconditioned value-quits included).
    is_extrinsic = any(line_has_value_quit(ln) for ln in label_body)

    sig_form = "extrinsic" if is_extrinsic else "procedure"
    formals_str = ", ".join(formals)
    if is_extrinsic:
        signature = f"$${label_name}^{module_name}({formals_str})"
    else:
        signature = f"do {label_name}^{module_name}({formals_str})"

    # @param tags: parse "NAME [TYPE] BODY" shape leniently.
    params: list[dict] = []
    for body in tags.get("@param", []):
        parts = body.split(None, 2)
        if not parts:
            continue
        name = parts[0]
        if len(parts) == 1:
            params.append({"name": name, "type": "", "doc": ""})
        elif len(parts) == 2:
            # Could be "NAME BODY" with no TYPE — treat parts[1] as type if it
            # looks like a single token vocabulary word, else as doc.
            if parts[1].isalpha() and parts[1].islower():
                params.append({"name": name, "type": parts[1], "doc": ""})
            else:
                params.append({"name": name, "type": "", "doc": parts[1]})
        else:
            params.append({"name": name, "type": parts[1], "doc": parts[2]})

    # @returns: "TYPE BODY" or "BODY" alone.
    returns: dict | None = None
    if "@returns" in tags and tags["@returns"]:
        body = tags["@returns"][0]
        parts = body.split(None, 1)
        if len(parts) == 0:
            returns = {"type": "", "doc": ""}
        elif len(parts) == 1:
            returns = {"type": parts[0] if parts[0].isalpha() else "", "doc": "" if parts[0].isalpha() else parts[0]}
        else:
            returns = {"type": parts[0], "doc": parts[1]}

    # @raises: "CODE BODY" → list of {code, doc}.
    raises: list[dict] = []
    for body in tags.get("@raises", []):
        parts = body.split(None, 1)
        if not parts:
            continue
        code = parts[0]
        doc = parts[1] if len(parts) > 1 else ""
        raises.append({"code": code, "doc": doc})

    examples = list(tags.get("@example", []))
    since = tags["@since"][0] if "@since" in tags and tags["@since"] else ""
    stable = tags["@stable"][0] if "@stable" in tags and tags["@stable"] else ""
    see_raw = tags["@see"][0] if "@see" in tags and tags["@see"] else ""
    see_also = [s.strip() for s in see_raw.split(",") if s.strip()] if see_raw else []
    deprecated = tags["@deprecated"][0] if "@deprecated" in tags and tags["@deprecated"] else ""

    # @seam: marks this label as a side-effecting seam entry point. The body is
    # "NAME [v<N>]" — the seam contract it belongs to plus an optional contract
    # version (default 1). Aggregated into the manifest's top-level `seams` block.
    seam: dict | None = None
    if "@seam" in tags and tags["@seam"]:
        sm = SEAM_BODY_RE.match(tags["@seam"][0].strip())
        if sm:
            seam = {
                "name": sm.group("name"),
                "contract_version": int(sm.group("version")) if sm.group("version") else 1,
            }

    # Tag↔code cross-checks (stdlib-doc-accuracy RC-1) — hard errors.
    # @param set must equal the formallist exactly: names, count, order.
    doc_param_names = [p["name"] for p in params]
    if doc_param_names != formals:
        PROBLEMS.append(
            f"{ctx}: @param set != formallist "
            f"(@param: {doc_param_names!r}, formals: {formals!r})"
        )
    # returns⇄form: a procedure must not document a return value; an extrinsic
    # must document one.
    if sig_form == "procedure" and returns is not None:
        PROBLEMS.append(
            f"{ctx}: @returns documented on a procedure-form label "
            f"(no value-quit in the body)"
        )
    if sig_form == "extrinsic" and returns is None:
        PROBLEMS.append(
            f"{ctx}: extrinsic-form label (value-quit in the body) "
            f"has no @returns"
        )

    # @fixture: a Living-Examples sample-data dependency. Body is "PATH [doc]".
    fixtures: list[dict] = []
    for body in tags.get("@fixture", []):
        parts = body.strip().split(None, 1)
        if parts:
            fixtures.append({"path": parts[0], "doc": parts[1].strip() if len(parts) > 1 else ""})
    # @illustrative: the coverage-exemption reason (label has no executable example).
    illustrative = tags["@illustrative"][0].strip() if tags.get("@illustrative") else ""
    # @raisesnodemo: "CODE REASON" → a @raises code exempted from the
    # demonstration requirement (an infra/environment failure not triggerable on
    # a healthy engine). Aggregated as {code, reason}.
    raises_nodemo: list[dict] = []
    for body in tags.get("@raisesnodemo", []):
        parts = body.strip().split(None, 1)
        if parts:
            raises_nodemo.append({"code": parts[0], "reason": parts[1].strip() if len(parts) > 1 else ""})

    entry = {
        "form": sig_form,
        "signature": signature,
        "synopsis": synopsis,
        "params": params,
        "returns": returns,
        "raises": raises,
        "examples": examples,
        "since": since,
        "stable": stable,
        "see_also": see_also,
        "deprecated": deprecated,
        "seam": seam,
        "description": parsed["description"],
        "source": {"file": source_path, "line": source_line},
    }
    # Repo-specific label fields (v-stdlib: @mutates/@mutates_doc) — the hook
    # runs BEFORE the conditional Living-Examples fields below and may both
    # augment and RE-ORDER keys (manifest key order is part of the committed
    # byte-for-byte artifact).
    if CONFIG is not None and CONFIG.label_hook is not None:
        entry = CONFIG.label_hook(entry, tags, ctx)
    # Emit the Living-Examples fields only when present, so existing manifests are
    # unchanged until a label actually carries the tag (E3 backfill).
    if fixtures:
        entry["fixtures"] = fixtures
    if illustrative:
        entry["illustrative"] = illustrative
    if raises_nodemo:
        entry["raises_nodemo"] = raises_nodemo
    return entry


def read_stdlib_version() -> str:
    """Read the most-recent versioned entry from the changelog.

    Skips an `[Unreleased]` heading if present so the manifest's
    stdlib_version stays anchored to the last shipped tag while
    work accumulates against the next one.

    The candidate paths are per-repo config (`changelog_paths`, repo-root-
    relative, first existing hit wins) — the changelog has lived at different
    paths per repo and over time.
    """
    candidates = tuple(REPO_ROOT / p for p in (CONFIG.changelog_paths if CONFIG else ()))
    changelog = next((p for p in candidates if p.exists()), None)
    if changelog is None:
        return ""
    for line in changelog.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^##\s*\[([^\]]+)\]", line)
        if m:
            v = m.group(1).strip()
            if v.lower() == "unreleased":
                continue
            # The heading this version is TAKEN from must be a shipped release
            # — a `pending`/`unreleased` marker here means the manifest would
            # publish a version that never shipped (RC-4; hard error). Park
            # unshipped work under a `## [Unreleased]` heading instead.
            rest = line[m.end():]
            if re.search(r"\b(pending|unreleased)\b", rest, re.IGNORECASE):
                PROBLEMS.append(
                    f"{_relpath(changelog)}: version heading {v!r} is marked "
                    f"pending/unreleased — stdlib_version must come from a "
                    f"shipped release ({line.strip()!r})"
                )
            return v
    return ""


def build_seams(modules: dict[str, dict]) -> dict:
    """Aggregate the `seams` contract view from per-label @seam tags.

    Returns `{ "<seam>": { "contract_version": N, "entry_points": [ {label,
    args, returns, raises}, ... ] } }`, keyed by seam name. Entry points are
    sorted by label and seams by name so the artifact is deterministic (a
    requirement for the drift gate). All entry points of one seam must declare
    the same contract version; a disagreement is a hard error (a forgotten bump
    on one of several entry points is exactly what the bump-forcer guards).
    """
    seams: dict[str, dict] = {}
    versions: dict[str, int] = {}
    for module_name in sorted(modules):
        labels = modules[module_name]["labels"]
        for label_name in sorted(labels):
            label = labels[label_name]
            seam = label.get("seam")
            if not seam:
                continue
            name = seam["name"]
            version = seam["contract_version"]
            if name in versions and versions[name] != version:
                raise ValueError(
                    f"seam {name!r} declares inconsistent contract_version "
                    f"({versions[name]} vs {version}) across its entry points — "
                    f"bump every entry point of a seam together"
                )
            versions[name] = version
            seams.setdefault(name, {"contract_version": version, "entry_points": []})
            seams[name]["entry_points"].append({
                "label": label["signature"],
                "args": list(label.get("params", [])),
                "returns": label.get("returns"),
                "raises": list(label.get("raises", [])),
            })
    for name in seams:
        seams[name]["entry_points"].sort(key=lambda e: e["label"])
    return {name: seams[name] for name in sorted(seams)}


def verify_raises(
    sites_by_module: dict[str, list[tuple[str, int, str]]],
    errors_index: dict[str, dict],
) -> None:
    """The two raise-verifier directions (stdlib-doc-accuracy W1 / review F5).

    `sites_by_module`: module -> [(code, lineno, relpath)] — the FILE-wide,
    code-lines-only raise sites. `errors_index`: the per-module errors index
    built from `@raises` tags. Appends hard errors to PROBLEMS; RAISE_EXEMPT
    codes are skipped (each exemption is printed by the caller).

    1. documented-but-never-raised (label-scoped attribution): every code some
       label documents must have a raise site somewhere in src/ — a code no
       code ever sets is a doc lie or a typo. Repo-wide site set, because a
       label may legitimately document a code its callee module raises.
    2. raised-but-unregistered (site-level, module-attributed): every raise
       site's code must be registered — via some label's @raises — under the
       module that raises it, so raises inside @internal labels are covered.
    """
    all_site_codes = {code for sites in sites_by_module.values()
                      for (code, _, _) in sites}
    for code in sorted(errors_index):
        if code in RAISE_EXEMPT:
            continue
        if code not in all_site_codes:
            for module_name, labels in sorted(errors_index[code]["modules"].items()):
                PROBLEMS.append(
                    f"{module_name}.{'/'.join(labels)}: @raises {code} but no "
                    f"raise site exists anywhere in src/ "
                    f"(documented-but-never-raised)"
                )
    for module_name in sorted(sites_by_module):
        seen: set[str] = set()
        for code, lineno, relpath in sites_by_module[module_name]:
            if code in RAISE_EXEMPT or code in seen:
                continue
            seen.add(code)
            owners = errors_index.get(code, {}).get("modules", {})
            if module_name not in owners:
                PROBLEMS.append(
                    f"{relpath}:{lineno}: raises {code} but no {module_name} "
                    f"label documents it via @raises "
                    f"(raised-but-unregistered)"
                )


def build_manifest() -> tuple[dict, dict]:
    """Walk src/ and produce (manifest, errors_index)."""
    reset_publicness()
    modules: dict[str, dict] = {}
    errors_index: dict[str, dict] = {}
    sites_by_module: dict[str, list[tuple[str, int, str]]] = {}

    for path in sorted(SRC_DIR.glob(CONFIG.src_glob if CONFIG else "STD*.m")):
        module = parse_module_file(path)
        # Re-derive the module name from the routine line; fall back to filename stem.
        # parse_module_file already normalises this internally.
        name_from_first_line = ""
        lines = path.read_text(encoding="utf-8").splitlines()
        if lines:
            m = ROUTINE_LINE_RE.match(lines[0])
            if m:
                name_from_first_line = m.group("name")
        module_name = name_from_first_line or path.stem.upper()
        modules[module_name] = module

        # File-wide raise-site scan (code lines only) for the verifier.
        sites_by_module[module_name] = [
            (code, lineno, _relpath(path))
            for code, lineno in collect_raise_sites(lines, module_name)
        ]

        # Build the errors inverted index from each label's raises — PER
        # MODULE (RC-9): a code raised in N modules lists each owner with its
        # own labels, instead of merging every raiser under the
        # alphabetically-first module.
        for label_name, label in module["labels"].items():
            for r in label.get("raises", []):
                code = r["code"]
                bucket = errors_index.setdefault(code, {"modules": {}})
                mod_labels = bucket["modules"].setdefault(module_name, [])
                if label_name not in mod_labels:
                    mod_labels.append(label_name)

    # Deterministic ordering for the drift gate: sort module keys per code.
    for code in errors_index:
        errors_index[code]["modules"] = {
            name: errors_index[code]["modules"][name]
            for name in sorted(errors_index[code]["modules"])
        }

    verify_raises(sites_by_module, errors_index)

    # No `generated_at` field by design — it would change every run and
    # would force the WA5 manifest-check gate to fail spuriously. The
    # version of the source the manifest was generated from is captured
    # by `stdlib_version`; the file's git history captures the rest.
    manifest = {
        "stdlib_version": read_stdlib_version(),
        "modules": modules,
        "errors": errors_index,
        "seams": build_seams(modules),
    }
    # Repo-specific top-level blocks + cross-module stitching (v-stdlib:
    # sprawl fan_in, envelope, decodeContract) — the hook may re-order keys.
    if CONFIG is not None and CONFIG.manifest_hook is not None:
        manifest = CONFIG.manifest_hook(manifest, modules)
    return manifest, errors_index


def write_outputs(manifest: dict, errors_index: dict) -> None:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    manifest_path = DIST_DIR / (CONFIG.manifest_filename if CONFIG else "manifest.json")
    errors_path = DIST_DIR / "errors.json"
    # Pretty-print with stable key order so diffs read cleanly.
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=False, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    errors_path.write_text(
        json.dumps(errors_index, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        f"wrote {manifest_path.relative_to(REPO_ROOT)} "
        f"({len(manifest['modules'])} modules, "
        f"{sum(len(m['labels']) for m in manifest['modules'].values())} public labels)"
    )
    print(f"wrote {errors_path.relative_to(REPO_ROOT)} ({len(errors_index)} error codes)")


def run_generate() -> int:
    """The full generate flow (the shells' non-self-test main): build, print
    every exemption + the publicness invariant, red on problems, else write."""
    import sys

    if not SRC_DIR.exists():
        print(f"src/ not found at {SRC_DIR}", file=sys.stderr)
        return 2

    manifest, errors_index = build_manifest()

    # Every exemption is printed on every run — an escape hatch must be
    # visible, never a silence.
    for code in sorted(RAISE_EXEMPT):
        print(f"raise-exempt: {code} — {RAISE_EXEMPT[code]}")
    for label in sorted(PUBLICNESS_EXEMPT):
        print(f"publicness-exempt: {label} — {PUBLICNESS_EXEMPT[label]}")

    # W2 publicness invariant — printed on every run (RC-3: the col-1-vs-manifest
    # gap is now a checked, visible count, not an unknowable silence).
    print(
        f"publicness: {PUBLICNESS['col1']} col-1 = "
        f"{PUBLICNESS['documented']} documented + "
        f"{PUBLICNESS['internal']} @internal + "
        f"{PUBLICNESS['exempt']} exempt + "
        f"{len(UNACCOUNTED)} unaccounted"
    )
    if UNACCOUNTED:
        print(
            f"gen-manifest: {len(UNACCOUNTED)} column-1 label(s) carry neither a "
            f"`; doc:` block nor `; doc: @internal` — add a doc block if public, "
            f"or `; doc: @internal` if a private helper (nothing written):",
            file=sys.stderr,
        )
        for offender in UNACCOUNTED:
            print(f"  - {offender}", file=sys.stderr)

    if PROBLEMS:
        print(
            f"gen-manifest: {len(PROBLEMS)} tag<->code error(s) — "
            f"fix the source tags (nothing written):",
            file=sys.stderr,
        )
        for problem in PROBLEMS:
            print(f"  - {problem}", file=sys.stderr)

    if PROBLEMS or UNACCOUNTED:
        return 2

    write_outputs(manifest, errors_index)
    return 0
