"""mdoc.tags — the SHARED M-doc tag registry (stdlib-doc-accuracy W5 de-fork).

This is the single source of truth for the tag grammar's SHARED core — the 16
tags common to every consumer. Per-repo extension tags ride each consumer's
`tools/mdoc_config.py` (`RepoConfig.extra_tags`) and are appended AFTER the
shared set by `merged()`: m-stdlib adds `@tag`/`@phase` (F8 frontmatter
ownership), v-stdlib adds `@mutates`/`@dispatch`/`@file` (VistA vocabulary —
kept above the m/v waterline by living in v-stdlib's config, never here).

Consumers (the reason this file exists once, not three times):
  - mdoc.core            derives KNOWN_TAGS/SINGLETON_TAGS from the merged
                         registry at configure() time, so the generator can
                         never recognise a tag absent from the registry, or
                         miss one present (registry ≡ generator by construction).
  - m-stdlib gen-grammar renders the §5 tag table in docs/guides/m-doc-grammar.md
                         from the merged m view, and `--check` drift-gates it.

Editing the SHARED tag set means editing THIS file; a repo-only tag goes in
that repo's config. The registry tags handled by other generators
(@icr/@source/@call/@status/@custodian → gen-icr / check_citations) are
deliberately NOT here — different concern (they are `foreign_tags` config so
the strict parser skips rather than reds on them).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Tag:
    name: str            # e.g. "@param"
    level: str           # "label" (a label's doc block) | "module" (routine header)
    multiplicity: str    # human-readable, e.g. "0..N", "0..1", "0..1 (1 for public)"
    body_syntax: str     # e.g. "NAME [TYPE] BODY"
    manifest_field: str  # where it lands in the manifest, e.g. "params", "seams"
    synopsis: str        # one-line description (matches the grammar §5 entry)
    example: str         # a canonical `; doc:`-stripped example body
    status: str = "stable"


# The sixteen SHARED doc-manifest tags. Order = the grammar's §5 order; a
# consumer's extra_tags append after these (the §5.N prose sections for the
# m extras already sit at the end — §5.17/5.18).
TAGS: list[Tag] = [
    Tag("@param", "label", "0..N", "NAME [TYPE] BODY", "params",
        "Parameter declaration.",
        '@param text string  RFC-8259 JSON document text'),
    Tag("@returns", "label", "0..1", "[TYPE] BODY", "returns",
        "Return-value declaration.",
        '@returns bool  1 on success, 0 on failure'),
    Tag("@raises", "label", "0..N", "CODE [BODY]", "raises",
        "Error-code declaration.",
        '@raises U-STDJSON-PARSE  malformed input'),
    Tag("@example", "label", "0..N", "BODY", "examples",
        "A runnable usage example (consecutive @example lines join).",
        '@example do parse^STDJSON("[1,2,3]",.t)'),
    Tag("@since", "label", "0..1 (1 for public)", "VERSION", "since",
        "The first version this label appeared in.",
        '@since v0.2.0'),
    Tag("@stable", "label", "0..1 (1 for public)", "experimental|stable|deprecated",
        "stable",
        "API-stability tier.",
        '@stable stable'),
    Tag("@see", "label", "0..1", "SYMBOL[, SYMBOL]*", "see_also",
        "Cross-references to related symbols.",
        '@see $$valid^STDJSON, $$encode^STDJSON'),
    Tag("@deprecated", "label", "0..1", "VERSION BODY", "deprecated",
        "Deprecation version + replacement (requires @stable deprecated).",
        '@deprecated v0.5.0  use $$newThing^STDX'),
    Tag("@internal", "label", "0..1", "(no body)", "(excludes the label)",
        "Marks a documented label as NOT part of the public surface.",
        '@internal'),
    Tag("@seam", "label", "0..1", "NAME [vN]", "seams",
        "Marks a side-effecting seam entry point (a versioned contract).",
        '@seam STDENV v2'),
    Tag("@tier", "module", "0..1", "core|optional", "tier",
        "Classifies the whole module (routine-header tag).",
        '@tier optional'),
    Tag("@exrun", "module", "0..1", "dual|bare|bare-ydb|ydb|live", "example_run",
        "Living-examples execution scope (E4) — which engine tier/arms run the "
        "module's examples/programs/<MOD>EX.m. dual (default) = both bare engines "
        "(m-test-engine YDB + m-test-iris IRIS), gating, plus the live tier; bare "
        "= both bare engines only, NOT live (a module that exercises its own "
        "shared global, e.g. the tap family writing ^VSLTAP); bare-ydb = the YDB "
        "bare engine only (IRIS-bare-incompatible and not live); ydb = YDB only "
        "(bare m-test-engine + live vehu — its IRIS-bare backend is absent, e.g. "
        "a $ZF call-out/$ZCMDLINE demo); live = live VistA only (vehu/foia), "
        "skipped on the bare engines (needs Kernel/FileMan). Absent → dual. "
        "Routine-header tag.",
        '@exrun bare'),
    Tag("@exsafe", "module", "0..1", "read-only|transactional|illustrative-skip", "example_safety",
        "Living-examples live-VistA side-effect class (E4 §8 safety model) — "
        "read-only (default; reads known data), transactional (mutates inside "
        "TSTART/TROLLBACK or self-restores the prior value), illustrative-skip "
        "(cannot be made safe on a shared live system; not run live). The live "
        "runner's pre/post residue check enforces a byte-identical engine "
        "regardless of the declared class. Routine-header tag.",
        '@exsafe transactional'),
    Tag("@fixture", "label", "0..N", "PATH [BODY]", "fixtures",
        "Declares an example's sample-data fixture dependency (Living Examples).",
        '@fixture examples/data/stdcsv/people.csv  the input rows'),
    Tag("@illustrative", "label", "0..1", "REASON", "illustrative",
        "Marks a label whose example is illustrative-only — exempt from the "
        "executable-example coverage requirement; the reason is required.",
        '@illustrative needs a configured live S3 sink to run'),
    Tag("@raisesnodemo", "label", "0..N", "CODE REASON", "raises_nodemo",
        "Marks a documented @raises CODE as not demonstrable by an executable "
        "error-example — an infrastructure/environment failure that cannot be "
        "triggered on a healthy engine (e.g. a missing call-out library, or a "
        "live-only side-effecting failure). Exempts that code from the "
        "@raises-demonstration coverage requirement; the reason is required.",
        '@raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  cannot fire when the callout is loaded'),
]


def merged(extra: tuple[Tag, ...] | list[Tag] = ()) -> list[Tag]:
    """The full registry for one consumer: shared tags + its extras, appended."""
    return TAGS + list(extra)


def all_names(tags: list[Tag] | None = None) -> set[str]:
    return {t.name for t in (TAGS if tags is None else tags)}


def label_tags(tags: list[Tag] | None = None) -> set[str]:
    """The tag names valid inside a label's doc block (drives KNOWN_TAGS)."""
    return {t.name for t in (TAGS if tags is None else tags) if t.level == "label"}


def module_tags(tags: list[Tag] | None = None) -> set[str]:
    """The tag names valid in the routine header (e.g. @tier)."""
    return {t.name for t in (TAGS if tags is None else tags) if t.level == "module"}


def by_name(name: str, tags: list[Tag] | None = None) -> Tag | None:
    for t in (TAGS if tags is None else tags):
        if t.name == name:
            return t
    return None
