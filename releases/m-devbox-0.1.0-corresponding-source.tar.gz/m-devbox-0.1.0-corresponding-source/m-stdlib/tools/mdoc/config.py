"""mdoc.config — the per-repo configuration contract (stdlib-doc-accuracy W5).

One `RepoConfig` instance per consumer, defined in that repo's
`tools/mdoc_config.py` and applied with `mdoc.core.configure(CONFIG)`. The
config is the ONLY place repo-specific knowledge lives — the core stays
engine-neutral parsing machinery (the m/v waterline applied to the toolchain:
VistA vocabulary like `@file`/`@dispatch`/envelope blocks enters exclusively
through a v repo's `extra_tags` + hooks, never the core).

Hook contracts (all optional; None = no-op):

- module_hook(module, header_body_lines, lines, module_name) -> None
    Called at the end of the routine-header parse, before the label walk.
    Mutates `module` in place to add repo-specific header-derived fields
    (v-stdlib: `@file` footprint, `@dispatch`, call-DAG, sprawl counters).

- label_hook(entry, tags, ctx) -> dict
    Called with the freshly-built base label entry (BEFORE the conditional
    fixtures/illustrative/raises_nodemo fields are appended) plus the parsed
    tag dict. Returns the entry to use — it may augment AND re-order keys
    (v-stdlib inserts `mutates` after `synopsis` and appends `mutates_doc`),
    since manifest key order is part of the committed byte-for-byte artifact.

- manifest_hook(manifest, modules) -> dict
    Called with the fully-built manifest dict. Returns the manifest to write —
    it may stitch cross-module facts (v-stdlib: sprawl fan_in) and add/re-order
    top-level blocks (v-stdlib: `envelope`, `decodeContract`).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Mapping, Pattern

from .tags import Tag


@dataclass(frozen=True)
class RepoConfig:
    lib_name: str                       # "stdlib" | "vsl" | "vweb" — messages only
    repo_root: Path
    src_glob: str                       # "STD*.m" / "VSL*.m" / "VWEB*.m"
    manifest_filename: str              # e.g. "stdlib-manifest.json"
    extra_tags: tuple[Tag, ...] = ()    # appended to the shared registry
    foreign_tags: frozenset[str] = frozenset()   # other generators' machine input (v: @icr)
    helper_raise_res: tuple[Pattern, ...] = ()   # suffix-group and/or code-group idioms
    raise_exempt: Mapping[str, str] = field(default_factory=dict)        # code -> reason, printed
    publicness_exempt: Mapping[str, str] = field(default_factory=dict)   # "MOD.label" -> reason, printed
    changelog_paths: tuple[str, ...] = ()        # repo-root-relative, first hit wins
    parse_module_tag_phase: bool = False         # m-only @tag/@phase header extraction
    module_hook: Callable | None = None
    label_hook: Callable | None = None
    manifest_hook: Callable | None = None
    strict: bool = True                 # False: unknown tags demote to prose (pre-W1 lenient)
