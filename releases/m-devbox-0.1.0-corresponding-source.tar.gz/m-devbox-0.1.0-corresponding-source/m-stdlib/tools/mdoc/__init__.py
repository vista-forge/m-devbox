"""mdoc — the canonical M-doc parser/verifier core (stdlib-doc-accuracy W5).

Canonical home: m-stdlib `tools/mdoc/` (the engine-neutral layer owner, D-2a).
Consumers: m-stdlib in-repo; v-stdlib and v-web via the sibling checkout
(`MSTDLIB` env override, org-layout default — absence is a HARD red in their
shells). Each consumer defines a `RepoConfig` in its own `tools/mdoc_config.py`
and applies it with `mdoc.core.configure(CONFIG)`; the shared golden corpus is
`mdoc.selftest.run()`, invoked from every consumer's gate.

Pure-stdlib python3 (the F7 constraint) — no parser dependency; the
m-parse/tree-sitter graduation stays the recorded D3 follow-on.
"""

from .config import RepoConfig  # noqa: F401
from .tags import Tag  # noqa: F401
