#!/usr/bin/env python3
"""Generate the §5 tag table in m-doc-grammar.md from the tag registry, and
drift-gate the grammar against the registry + the generator.

The spec-from-code gate (docs/archive/grammar-spec-from-code-gate-plan.md). The
canonical M-doc tag grammar's §5 tag reference is generated from the single
source of truth (tools/mdoc/tags.py + tools/mdoc_config.py extras), between markers (the gen-bodies.py
pattern). The rich per-tag prose (§5.1–5.N) stays hand-written and preserved.

`--check` red-gates any of:
  (a) the generated table block is stale vs the registry (regenerate + diff);
  (b) the registry's tag set != the §5.N hand-prose subsection headers
      (a removed tag whose prose lingers, or a new tag with no prose);
  (c) the registry's label tags != gen-manifest.py's KNOWN_TAGS (a future
      refactor that re-hardcodes the set);
  and WARNS (non-gating) on any `@tag` used in src/*.m that is neither a
  registry tag nor a known registry-tag exception (a typo'd tag in source).

m-stdlib only (the canonical grammar home; v-stdlib keeps its pointer).

Usage:
  python3 tools/gen-grammar.py            # rewrite the §5 table block
  python3 tools/gen-grammar.py --check    # exit 1 on (a)/(b)/(c); warn on typos
  python3 tools/gen-grammar.py --self-test
"""

from __future__ import annotations

import argparse
import importlib.util
import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
TOOLS = REPO_ROOT / "tools"
GRAMMAR = REPO_ROOT / "docs" / "guides" / "m-doc-grammar.md"
SRC_DIR = REPO_ROOT / "src"

sys.path.insert(0, str(TOOLS))
from mdoc import tags as mdoc_tags_mod  # noqa: E402
from mdoc_config import CONFIG  # noqa: E402

# The m view of the registry: shared tags + the m-only extras (@tag/@phase),
# appended — the same merged view mdoc.core.configure() derives KNOWN_TAGS from.
TAGS = mdoc_tags_mod.merged(CONFIG.extra_tags)

BEGIN = ("<!-- BEGIN GENERATED TAG TABLE — managed by tools/gen-grammar.py "
         "(`make grammar`); edits between these markers are overwritten. -->")
END = "<!-- END GENERATED TAG TABLE -->"

# `; doc:` tags consumed by OTHER generators (gen-icr / check_citations), not
# the doc-manifest grammar — see m-doc-grammar.md §5 "Tags outside this grammar".
REGISTRY_TAG_EXCEPTIONS = {"@icr", "@call", "@status", "@custodian", "@source"}


def _cell(s: str) -> str:
    return s.replace("|", "\\|").replace("\n", " ")


def render_block() -> str:
    lines = [BEGIN, ""]
    lines.append("| Tag | Level | Multiplicity | Body | Manifest field | Synopsis |")
    lines.append("|---|---|---|---|---|---|")
    for t in TAGS:
        lines.append(
            f"| `{t.name}` | {t.level} | {_cell(t.multiplicity)} | "
            f"`{_cell(t.body_syntax)}` | `{_cell(t.manifest_field)}` | {_cell(t.synopsis)} |"
        )
    lines.append("")
    lines.append(END)
    return "\n".join(lines)


def splice(page: str, block: str) -> str:
    if BEGIN in page and END in page:
        pre, rest = page.split(BEGIN, 1)
        _, post = rest.split(END, 1)
        return pre + block + post
    # Insert just before the first `### 5.` subsection (after the §5 intro).
    lines = page.splitlines(keepends=True)
    for i, line in enumerate(lines):
        if re.match(r"^### 5\.\d", line):
            head = "".join(lines[:i]).rstrip("\n")
            tail = "".join(lines[i:])
            return head + "\n\n" + block + "\n\n" + tail
    # Fallback: append.
    return page.rstrip("\n") + "\n\n" + block + "\n"


def prose_subsection_tags(page: str) -> set[str]:
    """The @tags that have a `### 5.N` hand-prose subsection."""
    return set(re.findall(r"^### 5\.\d+\s+`?(@[a-z]+)", page, re.M))


def _gen_manifest_known_tags() -> set[str]:
    spec = importlib.util.spec_from_file_location("gen_manifest", TOOLS / "gen-manifest.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return set(mod.KNOWN_TAGS)


def _source_tags() -> set[str]:
    tags: set[str] = set()
    for p in SRC_DIR.glob("*.m"):
        for m in re.finditer(r";\s*doc:\s*(@[a-z]+)", p.read_text(encoding="utf-8")):
            tags.add(m.group(1))
    return tags


def check() -> int:
    page = GRAMMAR.read_text(encoding="utf-8")
    problems: list[str] = []

    # (a) generated table block matches the registry.
    if splice(page, render_block()) != page:
        problems.append("(a) the §5 generated tag table is stale — run `make grammar` and commit.")

    # (b) registry tags == the §5.N hand-prose subsection headers.
    reg = mdoc_tags_mod.all_names(TAGS)
    prose = prose_subsection_tags(page)
    if reg - prose:
        problems.append(f"(b) registry tags with NO §5.N prose subsection: {sorted(reg - prose)} "
                        "— add a hand-written subsection.")
    if prose - reg:
        problems.append(f"(b) §5.N prose subsections for tags NOT in the registry: {sorted(prose - reg)} "
                        "— remove the prose or add to mdoc/tags.py (shared) or mdoc_config.py extra_tags.")

    # (c) registry label tags == gen-manifest.py's KNOWN_TAGS.
    known = _gen_manifest_known_tags()
    if mdoc_tags_mod.label_tags(TAGS) != known:
        problems.append(f"(c) registry label tags {sorted(mdoc_tags_mod.label_tags(TAGS))} != "
                        f"gen-manifest KNOWN_TAGS {sorted(known)}.")

    # (d) WARN: unknown @tags in source (typo catch) — non-gating.
    unknown = _source_tags() - reg - REGISTRY_TAG_EXCEPTIONS
    if unknown:
        print(f"check-grammar: WARNING — @tag(s) in src/*.m not in the registry "
              f"and not a known registry-tag: {sorted(unknown)} (typo? or add to mdoc/tags.py / mdoc_config.py)",
              file=sys.stderr)

    if problems:
        print("check-grammar: DRIFT — the grammar is out of sync with the registry/generator:",
              file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        return 1
    print(f"check-grammar: clean — {len(TAGS)} tags; §5 table + prose + "
          "gen-manifest KNOWN_TAGS all agree with the registry")
    return 0


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--check", action="store_true", help="drift-gate; exit 1 on a/b/c")
    p.add_argument("--self-test", action="store_true", help="run the inline self-test")
    args = p.parse_args(argv)

    if args.self_test:
        return self_test()
    if args.check:
        return check()

    page = GRAMMAR.read_text(encoding="utf-8")
    new = splice(page, render_block())
    if new != page:
        GRAMMAR.write_text(new, encoding="utf-8")
        print(f"gen-grammar: rewrote the §5 tag table in {GRAMMAR.relative_to(REPO_ROOT)}")
    else:
        print("gen-grammar: §5 tag table already current")
    return 0


def self_test() -> int:
    failures: list[str] = []

    def expect(cond, msg):
        if not cond:
            failures.append(msg)

    block = render_block()
    expect(block.startswith(BEGIN) and block.rstrip().endswith(END), "block markers")
    for t in TAGS:
        expect(f"`{t.name}`" in block, f"table missing {t.name}")

    # insert into a page with no markers — lands before the first ### 5.
    page = ("## 5. Tag reference\n\nEleven tags.\n\n### 5.1 `@param NAME`\n\nprose.\n")
    out = splice(page, block)
    expect("Eleven tags." in out and "prose." in out, "insert preserves prose")
    expect(out.index(BEGIN) < out.index("### 5.1"), "block lands before §5.1")
    # idempotent
    expect(splice(out, block) == out, "splice idempotent")
    # replace-in-place
    expect(splice(out, render_block()).count(BEGIN) == 1, "no duplicate block")

    # prose-subsection extraction
    tags = prose_subsection_tags(
        "### 5.1 `@param NAME`\n### 5.11 `@tier core|optional`  (module-level)\n")
    expect(tags == {"@param", "@tier"}, f"prose-tag extraction: {tags}")

    if failures:
        for f in failures:
            print(f"FAIL: {f}", file=sys.stderr)
        return 1
    print("gen-grammar self-test OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
