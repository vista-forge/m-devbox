#!/usr/bin/env python3
"""gen-examples (E1) — the living-examples generator.

Reads dist/<lib>-manifest.json and emits, per module, a self-verifying
runnable example program `examples/programs/<MOD>EX.m` from the module's
executable `@example` tags, plus a living-doc index `examples/index.md`
that surfaces every module's example coverage. Drift-gated (`--check`).

This is the E1 increment of the Living Executable Examples proposal
(docs `proposals/living-executable-examples.md`). It evolves the older
`gen-doctests.py` — same eligible-example classification — but writes to
the repo's `examples/` tree (the living-doc surface that travels with the
library) and adds the index. The richer surface (every label, `@raises`
error cases, `@fixture` sample data, live-VistA execution) is E2–E4; the
example PROGRAMS here subsume the `tests/*DOCTST.m` suites once E4 wires
their execution.

Engine-free; pure manifest-in, files-out; deterministic (sorted, no
timestamps). A byte-identical sibling between the stdlibs except the
manifest name (auto-discovered).

Usage:
  python3 tools/gen-examples.py            # regenerate examples/programs/ + index.md
  python3 tools/gen-examples.py --check    # drift gate
  python3 tools/gen-examples.py --coverage # E2 comprehensiveness report (advisory)
  python3 tools/gen-examples.py --coverage --strict  # exit 1 if <100% (flip-to-red, L5)
  python3 tools/gen-examples.py --self-test
  python3 tools/gen-examples.py --verbose  # trace classify decisions / list gaps
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
MANIFEST_CANDIDATES = ("vsl-manifest.json", "stdlib-manifest.json")
EXAMPLES_DIR = REPO_ROOT / "examples"
PROGRAMS_DIR = EXAMPLES_DIR / "programs"
INDEX_PATH = EXAMPLES_DIR / "index.md"
# The coverage baseline-ratchet (D-3b): a committed ceiling of the still-open
# example gaps. `--coverage --baseline` reds when a count is WORSE than the
# committed file (a regression), stays green at-or-below, and prints a ratchet
# hint when a gain is unpinned; `--coverage --write-baseline` recaptures it.
BASELINE_PATH = EXAMPLES_DIR / "coverage-baseline.json"
BASELINE_KEYS = ("uncovered", "illustrative", "raises_undemonstrated",
                 "fixtures_missing", "fixtures_orphan")
# Modules whose labels structurally cannot carry executable examples — a printed
# disposition, never a silence (scoped-negative-is-not-proof-of-absence). Their
# uncovered labels are reported under `coverage-exempt`, not `uncovered`, so the
# ratchet tracks only real backfillable gaps. Empty in m-stdlib; v-stdlib exempts
# VSLAPIT (the gen-dispatcher `$text` verb table — a doc block would shift the
# dispatch walk and break the live dispatcher).
COVERAGE_EXEMPT_MODULES: frozenset[str] = frozenset()

# Pattern A (string): write <expr>  ; "<expected>"
PAT_WRITE_EXPECT_STR = re.compile(r'^\s*(?:write|w)\s+(.+?)\s+;\s*"((?:[^"\\]|\\.)*)"\s*$')
# Pattern A-num: write <expr>  ; <number>
PAT_WRITE_EXPECT_NUM = re.compile(r'^\s*(?:write|w)\s+(.+?)\s+;\s*(-?\d+(?:\.\d+)?)\s*$')
# Pattern B (self-asserting statement): a complete `do …^STDASSERT(…)` line that
# asserts its own result. Emitted VERBATIM into the EX routine — this is how a
# label whose example needs set-up locals, a by-reference array, a procedure
# call, or an error trigger (@raises, via `do raises^STDASSERT(…)`) is made
# executable. The body runs under the routine's own .pass/.fail counters.
PAT_STDASSERT_STMT = re.compile(r"\b(?:do|d)(?::\S+)?\s+[A-Za-z%][A-Za-z0-9]*\^STDASSERT\(", re.IGNORECASE)
# The same shape, but capturing the label so we can tell an ASSERTING call
# (eq/ne/true/false/near/raises/contains/len) from a LIFECYCLE/internal one.
PAT_STDASSERT_LABEL = re.compile(r"\b(?:do|d)(?::\S+)?\s+([A-Za-z%][A-Za-z0-9]*)\^STDASSERT\(", re.IGNORECASE)
# STDASSERT labels that make NO assertion: the suite lifecycle (start/report/
# silent/nohalt/stash) and internal helpers (recordPass/recordFail/quote/
# irisRaises). An @example whose ONLY ^STDASSERT calls are these is a
# harness-lifecycle DEMO, not a test case — run as a live @TEST case it asserts
# nothing, and `start` resets the runner's by-reference pass/fail counters,
# driving the case's assertion delta NEGATIVE, which the m-cli runner reports as
# a crashed case ("did not complete under runner dispatch") that aborts the run.
# Such examples are illustrative (documented, not executed); see STDASSERT.start
# / .report (both carry @illustrative). Case-sensitive: M labels are.
NON_ASSERTING_STDASSERT = frozenset({
    "start", "report", "silent", "nohalt", "stash",
    "recordPass", "recordFail", "quote", "irisRaises",
})


def manifest_path() -> Path | None:
    for name in MANIFEST_CANDIDATES:
        p = REPO_ROOT / "dist" / name
        if p.is_file():
            return p
    return None


def expression_is_self_contained(expr: str) -> bool:
    """True if expr references only literals + routine/intrinsic calls (no free vars)."""
    s = expr
    s = re.sub(r'"(?:[^"]|"")*"', "", s)
    s = re.sub(r"\$\$[A-Za-z%][A-Za-z0-9]*\^[A-Za-z%][A-Za-z0-9]*", "", s)
    s = re.sub(r"\$[A-Za-z]+", "", s)
    s = re.sub(r"\^[A-Za-z%][A-Za-z0-9]*", "", s)
    s = re.sub(r"-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?", "", s)
    return re.search(r"[A-Za-z]", s) is None


# M command words that are not data references (ignored in the free-var scan).
# FULL words only — house style is modern/pythonic-lower (`set`, `do`, `write`),
# never the VistA-compact single-letter abbreviations, so we must NOT treat
# `s`/`d`/`f`/… as keywords (they are common local names, e.g. `$length(s)`).
# `pass`/`fail` are the by-reference assertion counters, always present.
_M_KEYWORD_SET = {
    "set", "do", "new", "if", "else", "for", "quit", "write", "read", "kill",
    "merge", "goto", "xecute", "tstart", "tcommit", "trollback", "halt", "hang",
    "lock", "close", "open", "use", "view", "job", "break", "pass", "fail",
}


def statement_is_self_contained(stmt: str) -> bool:
    """True if a Pattern-B `do …^STDASSERT(…)` statement references no free var.

    A statement may set up its own locals (`set x=… do eq^STDASSERT(…,$$f^M(x),…)`);
    those LHS names are not free. After removing strings, label^ROUTINE / $$f^R
    calls, $intrinsics, ^globals, numbers, M command words, the by-ref counters,
    and every locally-assigned name, any remaining bareword identifier is a free
    var → not executable. Rejects illustrative usage demos that read undefined
    placeholders (e.g. STDASSERT's own `do eq^STDASSERT(.pass,.fail,result,…)`).
    """
    nostr = re.sub(r'"(?:[^"]|"")*"', "", stmt)
    # A name is "local" (not free) if it is: the LHS of an assignment (incl.
    # comma-lists `set a=1,b=2` and subscripted `set a(1)=…`), passed by
    # reference (`.name` — an output array the example owns), or NEWed.
    assigned: set[str] = set(re.findall(r"([A-Za-z%][A-Za-z0-9]*)\s*(?:\([^()]*\))?\s*=", nostr))
    assigned |= set(re.findall(r"\.([A-Za-z%][A-Za-z0-9]*)", nostr))
    for mm in re.finditer(r"(?:^|\s)new\s+([A-Za-z%][A-Za-z0-9,]*)", nostr, re.IGNORECASE):
        assigned.update(re.findall(r"[A-Za-z%][A-Za-z0-9]*", mm.group(1)))
    t = nostr
    t = re.sub(r"[A-Za-z%][A-Za-z0-9]*\^[A-Za-z%][A-Za-z0-9]*", "", t)  # label^R and $$f^R
    t = re.sub(r"\$[A-Za-z]+", "", t)                                   # $intrinsics / SVNs
    t = re.sub(r"\^[A-Za-z%][A-Za-z0-9]*", "", t)                       # bare ^globals
    # Tokenize the residual into identifiers (NOT a \b/regex-strip: M's
    # concatenation operator `_` is a regex word char, so `\bcrlf\b` would miss
    # `crlf` inside `"a"_crlf_"b"`). Any identifier left that is neither an M
    # command word nor a local the statement assigns is a free var.
    for ident in re.findall(r"[A-Za-z%][A-Za-z0-9]*", t):
        if ident.lower() in _M_KEYWORD_SET or ident in assigned:
            continue
        return False
    return True


@dataclass(frozen=True)
class Example:
    module: str
    label: str
    kind: str            # "expr" (Pattern A) | "stmt" (Pattern B, verbatim)
    index: int = 0       # disambiguates multiple examples on one label
    expr: str = ""       # kind == "expr"
    expected: str = ""   # kind == "expr"
    is_prefix: bool = False
    is_numeric: bool = False
    stmt: str = ""       # kind == "stmt" (emitted verbatim)

    @property
    def routine_name(self) -> str:
        safe = re.sub(r"[^A-Za-z0-9]", "", self.label) or "x"
        suffix = str(self.index + 1) if self.index else ""
        return "tExample" + safe[:1].upper() + safe[1:] + suffix

    @property
    def description(self) -> str:
        return f"example: {self.module}.{self.label}"


def classify(example: str) -> tuple | None:
    """Classify an @example body into an executable shape, or None.

    Returns ("expr", expr, expected, is_prefix, is_numeric) for Pattern A
    (a self-contained `write <expr> ; "<expected>"`), or ("stmt", body) for
    Pattern B (a complete self-asserting `do …^STDASSERT(…)` line, emitted
    verbatim). Anything else (free-var snippet, prose, multi-line) → None.
    """
    s = example.strip()
    m = PAT_WRITE_EXPECT_STR.match(s)
    if m:
        expr = m.group(1).strip()
        if not expression_is_self_contained(expr):
            return None
        expected = m.group(2)
        is_prefix = expected.endswith("...")
        if is_prefix:
            expected = expected[:-3]
        return "expr", expr, expected, is_prefix, False
    m = PAT_WRITE_EXPECT_NUM.match(s)
    if m:
        expr = m.group(1).strip()
        if not expression_is_self_contained(expr):
            return None
        return "expr", expr, m.group(2), False, True
    if PAT_STDASSERT_STMT.search(s) and statement_is_self_contained(s):
        # Executable only if it makes at least one real assertion. A statement
        # whose every ^STDASSERT call is a lifecycle/internal label (start/report/
        # …) asserts nothing — it is illustrative, never a runnable @TEST case.
        labels = PAT_STDASSERT_LABEL.findall(s)
        if labels and all(lab in NON_ASSERTING_STDASSERT for lab in labels):
            return None
        return "stmt", s
    return None


def collect(manifest: dict, *, verbose: bool = False) -> dict[str, list[Example]]:
    by_module: dict[str, list[Example]] = {}
    for module_name in sorted(manifest.get("modules", {})):
        labels = manifest["modules"][module_name].get("labels", {})
        for label_name in sorted(labels):
            seq = 0
            for ex in labels[label_name].get("examples", []):
                cls = classify(ex)
                if cls is None:
                    if verbose:
                        print(f"  skip [{module_name}.{label_name}] {ex.strip()}", file=sys.stderr)
                    continue
                if cls[0] == "expr":
                    _, expr, expected, is_prefix, is_numeric = cls
                    item = Example(module_name, label_name, "expr", seq,
                                   expr=expr, expected=expected,
                                   is_prefix=is_prefix, is_numeric=is_numeric)
                else:
                    item = Example(module_name, label_name, "stmt", seq, stmt=cls[1])
                by_module.setdefault(module_name, []).append(item)
                seq += 1
    return by_module


def m_string_literal(s: str) -> str:
    return '"' + s.replace('"', '""') + '"'


def render_program(module: str, examples: list[Example]) -> str:
    routine = f"{module}EX"
    indent = " " * 8

    def header(label: str, comment: str) -> str:
        return f"{label}{' ' * max(1, 8 - len(label))}{comment}"

    lines: list[str] = []
    lines.append(header(routine, f"; Living examples for {module} — generated from @example tags."))
    lines.append(f"{indent}; Generated by tools/gen-examples.py — DO NOT EDIT BY HAND.")
    lines.append(f"{indent}; Source: the {module} label @example tags (regenerate with `make examples`).")
    lines.append(f"{indent}; m-lint: disable-file=M-MOD-020,M-MOD-001,M-MOD-031")
    lines.append(f"{indent}new pass,fail")
    lines.append(f"{indent}do start^STDASSERT(.pass,.fail)")
    lines.append(f"{indent};")
    for ex in examples:
        lines.append(f"{indent}do {ex.routine_name}(.pass,.fail)")
    lines.append(f"{indent};")
    lines.append(f"{indent}do report^STDASSERT(pass,fail)")
    lines.append(f"{indent}quit")
    lines.append(f"{indent};")
    for ex in examples:
        desc = m_string_literal(ex.description)
        hdr = f"{ex.routine_name}(pass,fail)"
        lines.append(f"{hdr}{' ' * max(1, 32 - len(hdr))};@TEST {desc}")
        if ex.kind == "stmt":
            # Pattern B: the example IS a self-asserting statement — emit verbatim.
            lines.append(f"{indent}{ex.stmt}")
        else:
            helper = "contains" if ex.is_prefix else "eq"
            expected_arg = ex.expected if ex.is_numeric else m_string_literal(ex.expected)
            lines.append(f"{indent}do {helper}^STDASSERT(.pass,.fail,{ex.expr},{expected_arg},{desc})")
        lines.append(f"{indent}quit")
        lines.append(f"{indent};")
    return "\n".join(lines) + "\n"


def render_index(manifest: dict, by_module: dict[str, list[Example]], lib: str) -> str:
    modules = manifest.get("modules", {})
    total_labels = sum(len(m.get("labels", {})) for m in modules.values())
    labels_with_exec = sum(len({e.label for e in by_module.get(name, [])}) for name in modules)
    n_programs = len(by_module)

    lines: list[str] = []
    lines.append("---")
    lines.append("title: Living examples — index")
    lines.append("doc_type: [INDEX]")
    lines.append(f"generated_from: dist/{lib}-manifest.json")
    lines.append("---")
    lines.append("")
    lines.append("# Living examples")
    lines.append("")
    lines.append(
        "Generated, self-verifying runnable example programs — one per module — built "
        "from each module's `@example` tags by `tools/gen-examples.py` (`make examples`). "
        "DO NOT edit by hand. Each `examples/programs/<MODULE>EX.m` runs as a suite "
        "(`do ^<MODULE>EX`) and asserts its own results."
    )
    lines.append("")
    pct = (100 * labels_with_exec // total_labels) if total_labels else 0
    lines.append(
        f"**Executable-example coverage: {labels_with_exec}/{total_labels} public labels "
        f"({pct}%)** across {n_programs} module program(s). The remaining labels carry no "
        "*executable* (`write … ; \"expected\"`, self-contained) example yet — closing that "
        "gap to 100% (with `@raises` error cases + sample data + live-VistA runs) is the "
        "Living Executable Examples roadmap (E2–E4)."
    )
    lines.append("")
    lines.append("| Module | Labels | With executable example | Program |")
    lines.append("|---|---|---|---|")
    for name in sorted(modules):
        labs = modules[name].get("labels", {})
        exec_labels = {e.label for e in by_module.get(name, [])}
        prog = f"[`{name}EX.m`](programs/{name}EX.m)" if name in by_module else "—"
        lines.append(f"| `{name}` | {len(labs)} | {len(exec_labels)} | {prog} |")
    lines.append("")
    return "\n".join(lines) + "\n"


def write_or_check(path: Path, content: str, *, check: bool) -> bool:
    if check:
        if not path.exists():
            print(f"DRIFT: missing {path.relative_to(REPO_ROOT)}", file=sys.stderr)
            return False
        if path.read_text(encoding="utf-8") != content:
            print(f"DRIFT: {path.relative_to(REPO_ROOT)} differs", file=sys.stderr)
            return False
        return True
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def run(check: bool, verbose: bool) -> int:
    mpath = manifest_path()
    if mpath is None:
        print("gen-examples: no dist/*-manifest.json — run `make manifest` first.", file=sys.stderr)
        return 2
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    lib = "vsl" if mpath.name.startswith("vsl") else "stdlib"
    by_module = collect(manifest, verbose=verbose)

    clean = True
    expected: set[Path] = set()
    for module in sorted(by_module):
        path = PROGRAMS_DIR / f"{module}EX.m"
        expected.add(path)
        clean &= write_or_check(path, render_program(module, by_module[module]), check=check)
    # orphan programs (a module that lost all eligible examples)
    if PROGRAMS_DIR.is_dir():
        for stale in set(PROGRAMS_DIR.glob("*EX.m")) - expected:
            if check:
                print(f"DRIFT: orphan {stale.relative_to(REPO_ROOT)}", file=sys.stderr)
                clean = False
            else:
                stale.unlink()
    clean &= write_or_check(INDEX_PATH, render_index(manifest, by_module, lib), check=check)

    if check:
        if clean:
            print(f"examples: clean — {len(by_module)} program(s) match the manifest")
        return 0 if clean else 1
    total = sum(len(v) for v in by_module.values())
    print(f"examples: wrote {len(by_module)} program(s), {total} example(s) + index")
    return 0


def raises_demonstrated(label_obj: dict, code: str) -> bool:
    """True if some @example in this label asserts `code` via raises^STDASSERT.

    The error-example contract (proposal §4): a `@raises CODE` is demonstrated by
    an example that triggers the path and asserts the code, e.g.
    `do raises^STDASSERT(.pass,.fail,"<trigger>","<CODE>","...")`. We detect it
    structurally: an example body that both calls raises^STDASSERT and names the
    code. Honest by construction — undemonstrated raises stay visible until E3
    authors the error-examples.
    """
    for body in label_obj.get("examples", []):
        if "raises^STDASSERT" in body and code in body:
            return True
    return False


@dataclass(frozen=True)
class Coverage:
    total: int
    executable: list[tuple[str, str]]
    illustrative: list[tuple[str, str, str]]
    uncovered: list[tuple[str, str]]
    exempt: list[tuple[str, str]]        # uncovered labels in COVERAGE_EXEMPT_MODULES — dispositioned, printed
    raises_total: int
    raises_exempt: int
    raises_undemonstrated: list[tuple[str, str, str]]
    fixtures_referenced: int
    fixtures_missing: list[tuple[str, str, str]]
    fixtures_orphan: list[str]

    @property
    def clean(self) -> bool:
        return not (self.uncovered or self.raises_undemonstrated
                    or self.fixtures_missing or self.fixtures_orphan)

    def gaps(self) -> dict[str, int]:
        """The ratchet axes — the still-open backfillable gap counts (exempt excluded)."""
        return {
            "uncovered": len(self.uncovered),
            "illustrative": len(self.illustrative),
            "raises_undemonstrated": len(self.raises_undemonstrated),
            "fixtures_missing": len(self.fixtures_missing),
            "fixtures_orphan": len(self.fixtures_orphan),
        }


def gather_coverage(manifest: dict, by_module: dict[str, list[Example]]) -> Coverage:
    modules = manifest.get("modules", {})
    exec_labels = {name: {e.label for e in by_module.get(name, [])} for name in modules}
    total = 0
    executable: list[tuple[str, str]] = []
    illustrative: list[tuple[str, str, str]] = []
    uncovered: list[tuple[str, str]] = []
    exempt_labels: list[tuple[str, str]] = []
    raises_total = 0
    raises_exempt = 0
    raises_undemonstrated: list[tuple[str, str, str]] = []
    referenced: set[str] = set()
    fixtures_missing: list[tuple[str, str, str]] = []

    for name in sorted(modules):
        labels = modules[name].get("labels", {})
        for label in sorted(labels):
            total += 1
            obj = labels[label]
            if label in exec_labels[name]:
                executable.append((name, label))
            elif obj.get("illustrative"):
                illustrative.append((name, label, obj["illustrative"]))
            elif name in COVERAGE_EXEMPT_MODULES:
                exempt_labels.append((name, label))
            else:
                uncovered.append((name, label))
            exempt = {n["code"] for n in obj.get("raises_nodemo", [])}
            for r in obj.get("raises", []):
                raises_total += 1
                if raises_demonstrated(obj, r["code"]):
                    continue
                if r["code"] in exempt:        # @raisesnodemo — not triggerable; accounted, not a gap
                    raises_exempt += 1
                    continue
                raises_undemonstrated.append((name, label, r["code"]))
            for fx in obj.get("fixtures", []):
                path = fx["path"]
                referenced.add(path)
                if not (REPO_ROOT / path).is_file():
                    fixtures_missing.append((name, label, path))

    orphan: list[str] = []
    data_dir = EXAMPLES_DIR / "data"
    if data_dir.is_dir():
        for f in sorted(data_dir.rglob("*")):
            if f.is_file() and f.name != "README.md":
                rel = f.relative_to(REPO_ROOT).as_posix()
                if rel not in referenced:
                    orphan.append(rel)

    return Coverage(
        total=total, executable=executable, illustrative=illustrative, uncovered=uncovered,
        exempt=exempt_labels, raises_total=raises_total, raises_exempt=raises_exempt,
        raises_undemonstrated=raises_undemonstrated,
        fixtures_referenced=len(referenced), fixtures_missing=fixtures_missing,
        fixtures_orphan=orphan,
    )


def read_baseline() -> dict[str, int] | None:
    if not BASELINE_PATH.is_file():
        return None
    data = json.loads(BASELINE_PATH.read_text(encoding="utf-8"))
    return {k: int(data[k]) for k in BASELINE_KEYS}


def write_baseline(cov: Coverage) -> None:
    gaps = cov.gaps()
    payload = {
        "_note": ("Committed coverage ceiling (D-3b baseline-ratchet). "
                  "`make examples-coverage-check` reds when a count exceeds this file "
                  "(a regression); at-or-below is green. Ratchet DOWN with "
                  "`make examples-coverage-baseline` as the E3 example backfill lands — "
                  "never edit up to accommodate a regression."),
        **{k: gaps[k] for k in BASELINE_KEYS},
    }
    BASELINE_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"examples coverage: baseline written → {BASELINE_PATH.relative_to(REPO_ROOT)}")
    for k in BASELINE_KEYS:
        print(f"    {k}: {gaps[k]}")


def coverage(strict: bool, verbose: bool, baseline: bool, write_bl: bool) -> int:
    mpath = manifest_path()
    if mpath is None:
        print("gen-examples: no dist/*-manifest.json — run `make manifest` first.", file=sys.stderr)
        return 2
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    lib = "vsl" if mpath.name.startswith("vsl") else "stdlib"
    by_module = collect(manifest)
    cov = gather_coverage(manifest, by_module)

    if write_bl:
        write_baseline(cov)
        return 0

    n_exec, n_illus = len(cov.executable), len(cov.illustrative)
    n_covered = n_exec + n_illus
    pct = (100 * n_covered // cov.total) if cov.total else 0
    n_undemo = len(cov.raises_undemonstrated)
    n_demo = cov.raises_total - n_undemo - cov.raises_exempt
    n_accounted = n_demo + cov.raises_exempt

    print(f"examples coverage — {lib}")
    print(f"  labels:   {n_covered}/{cov.total} covered ({pct}%)"
          f" — {n_exec} executable, {n_illus} illustrative, {len(cov.uncovered)} uncovered")
    print(f"  @raises:  {n_accounted}/{cov.raises_total} accounted"
          f" — {n_demo} demonstrated, {cov.raises_exempt} exempt (@raisesnodemo), {n_undemo} undemonstrated")
    print(f"  @fixture: {cov.fixtures_referenced} referenced"
          f" — {len(cov.fixtures_missing)} missing, {len(cov.fixtures_orphan)} orphan")
    # Printed disposition for exempt modules — absence is a decision, not a silence.
    if cov.exempt:
        mods = sorted({m for m, _ in cov.exempt})
        print(f"  exempt:   {len(cov.exempt)} label(s) in generated module(s) {', '.join(mods)}"
              f" — structurally un-exampleable, dispositioned (not counted as uncovered)")
        for mod, lab in cov.exempt:
            print(f"    coverage-exempt: {mod}.{lab}")

    if verbose:
        for mod, lab in cov.uncovered:
            print(f"    uncovered: {mod}.{lab}", file=sys.stderr)
        for mod, lab, code in cov.raises_undemonstrated:
            print(f"    raises-undemonstrated: {mod}.{lab} → {code}", file=sys.stderr)
        for mod, lab, path in cov.fixtures_missing:
            print(f"    fixture-missing: {mod}.{lab} → {path}", file=sys.stderr)
        for path in cov.fixtures_orphan:
            print(f"    fixture-orphan: {path}", file=sys.stderr)

    if baseline:
        return _check_baseline(cov)

    if cov.clean:
        print("examples coverage: 100% — every label exampled, every @raises demonstrated, no orphan fixtures")
        return 0
    sys.stdout.flush()
    if strict:
        print("examples coverage: INCOMPLETE (strict) — see gaps above"
              " (re-run with --verbose to list them)", file=sys.stderr)
        return 1
    print("examples coverage: advisory — gaps above are the E3 backfill (not yet gating)")
    return 0


def _check_baseline(cov: Coverage) -> int:
    """Ratchet gate: red on any gap count WORSE than the committed baseline."""
    base = read_baseline()
    if base is None:
        print(f"examples coverage: no baseline at {BASELINE_PATH.relative_to(REPO_ROOT)} —"
              " run `make examples-coverage-baseline` to pin the current counts.", file=sys.stderr)
        return 2
    gaps = cov.gaps()
    regressions = [(k, gaps[k], base[k]) for k in BASELINE_KEYS if gaps[k] > base[k]]
    gains = [(k, gaps[k], base[k]) for k in BASELINE_KEYS if gaps[k] < base[k]]
    if regressions:
        print("examples coverage: REGRESSION vs committed baseline — a documented gap grew:",
              file=sys.stderr)
        for k, now, was in regressions:
            print(f"    {k}: {now} > baseline {was} (+{now - was})", file=sys.stderr)
        print("  Fix by adding the missing example(s)/error-case(s), or — if the growth is"
              " a deliberate, accepted new gap — re-pin with `make examples-coverage-baseline`"
              " and record why in the tracker.", file=sys.stderr)
        return 2
    if gains:
        # At-or-below is green (D-3b), but an unpinned gain can mask a later regression —
        # surface it so the operator ratchets the baseline down.
        print("examples coverage: baseline OK — below ceiling on:"
              f" {', '.join(f'{k} {now}<{was}' for k, now, was in gains)};"
              " run `make examples-coverage-baseline` to pin the gain (ratchet down).")
        return 0
    print("examples coverage: baseline OK — at committed ceiling, no regression")
    return 0


def self_test() -> int:
    failures: list[str] = []

    def expect(c, m):
        if not c:
            failures.append(m)

    expect(classify('write $$enc^STDB64("hi")  ; "aGk="')[0] == "expr", "Pattern-A string not classified")
    expect(classify("write $$n^STDX()  ; 42")[0] == "expr", "Pattern-A num not classified")
    expect(classify("write $$size^STDFS(path)  ; 5") is None, "free-var Pattern-A must be skipped")
    expect(classify("do something") is None, "non-assert do must be skipped")
    expect(classify('do eq^STDASSERT(.pass,.fail,$$f^STDFOO(1),"y","d")')[0] == "stmt",
           "Pattern-B self-asserting statement classified")
    expect(classify('set x=5 do eq^STDASSERT(.pass,.fail,$$f^STDFOO(x),"y","d")')[0] == "stmt",
           "Pattern-B with leading set-up (locals assigned in-line) is self-contained")
    expect(classify('do eq^STDASSERT(.pass,.fail,result,"hi","d")') is None,
           "Pattern-B reading an undefined free var (result) is rejected")
    expect(classify('do raises^STDASSERT(.pass,.fail,"set x=1/0","Z150373058","divzero")')[0] == "stmt",
           "a raises^STDASSERT error-case is Pattern-B")
    expect(classify("do start^STDASSERT(.pass,.fail)") is None,
           "a lifecycle-only start^STDASSERT example is NOT executable (makes no assertion)")
    expect(classify("do report^STDASSERT(pass,fail)") is None,
           "a lifecycle-only report^STDASSERT example is NOT executable (makes no assertion)")
    expect(classify('set x=5 do start^STDASSERT(.pass,.fail) do eq^STDASSERT(.pass,.fail,x,5,"d")')[0] == "stmt",
           "a statement mixing a lifecycle call with a real assertion stays executable")
    prog = render_program("STDFOO", [
        Example("STDFOO", "greet", "expr", expr='$$greet^STDFOO("x")', expected="hi, x"),
        Example("STDFOO", "greet", "stmt", index=1,
                stmt='do true^STDASSERT(.pass,.fail,$$ok^STDFOO(),"ok")'),
    ])
    expect(prog.startswith("STDFOOEX"), "program routine name")
    expect("eq^STDASSERT" in prog and "tExampleGreet" in prog, "Pattern-A assertion shape")
    expect("tExampleGreet2" in prog and "true^STDASSERT" in prog,
           "Pattern-B verbatim emission + unique routine name")

    # coverage classification
    demo = {"examples": ['do raises^STDASSERT(.pass,.fail,"set x=$$f^STDFOO()","U-STDFOO-BAD","bad")'],
            "raises": [{"code": "U-STDFOO-BAD", "doc": "x"}]}
    expect(raises_demonstrated(demo, "U-STDFOO-BAD"), "@raises with matching error-example is demonstrated")
    expect(not raises_demonstrated(demo, "U-STDFOO-OTHER"), "@raises with no matching example is undemonstrated")
    expect(not raises_demonstrated({"examples": ['write $$f^STDFOO()  ; "1"'],
                                    "raises": []}, "U-STDFOO-BAD"),
           "a non-raises example does not demonstrate a raise")
    synth = {"modules": {"STDFOO": {"labels": {
        "a": {"examples": ['write $$a^STDFOO()  ; "1"'], "raises": []},
        "b": {"examples": [], "raises": [], "illustrative": "needs a live sink"},
        "c": {"examples": [], "raises": [{"code": "U-STDFOO-X", "doc": "x"}]},
        "d": {"examples": [], "raises": [{"code": "U-STDFOO-INFRA", "doc": "callout missing"}],
              "raises_nodemo": [{"code": "U-STDFOO-INFRA", "reason": "not triggerable on a healthy engine"}]},
    }}}}
    cov = gather_coverage(synth, collect(synth))
    expect(cov.total == 4, "coverage counts all labels")
    expect(len(cov.executable) == 1 and len(cov.illustrative) == 1 and len(cov.uncovered) == 2,
           "coverage buckets labels into executable / illustrative / uncovered")
    expect(cov.raises_total == 2 and len(cov.raises_undemonstrated) == 1 and cov.raises_exempt == 1,
           "coverage flags the undemonstrated raise and exempts the @raisesnodemo one")
    expect(not cov.clean, "synthetic coverage with gaps is not clean")
    expect(cov.gaps() == {"uncovered": 2, "illustrative": 1, "raises_undemonstrated": 1,
                          "fixtures_missing": 0, "fixtures_orphan": 0},
           "gaps() reports the backfillable ratchet axes")
    expect(len(cov.exempt) == 0, "no exempt modules configured → empty exempt bucket")

    # coverage-exempt: a label in a COVERAGE_EXEMPT_MODULES module leaves `uncovered`
    # for `exempt` (dispositioned, printed) so the ratchet tracks only real gaps.
    global COVERAGE_EXEMPT_MODULES
    saved = COVERAGE_EXEMPT_MODULES
    try:
        COVERAGE_EXEMPT_MODULES = frozenset({"STDGEN"})
        exsynth = {"modules": {
            "STDFOO": {"labels": {"a": {"examples": [], "raises": []}}},
            "STDGEN": {"labels": {"g": {"examples": [], "raises": []}}},
        }}
        excov = gather_coverage(exsynth, collect(exsynth))
        expect(excov.uncovered == [("STDFOO", "a")] and excov.exempt == [("STDGEN", "g")],
               "exempt-module uncovered labels move to the exempt bucket, not uncovered")
        expect(excov.gaps()["uncovered"] == 1, "exempt labels are excluded from the ratchet uncovered count")
    finally:
        COVERAGE_EXEMPT_MODULES = saved

    # ratchet comparison: worse-than-baseline is a regression, at-or-below is green.
    def regressions(gaps, base):
        return [k for k in BASELINE_KEYS if gaps[k] > base[k]]
    base = {"uncovered": 0, "illustrative": 36, "raises_undemonstrated": 6,
            "fixtures_missing": 0, "fixtures_orphan": 0}
    expect(regressions({**base, "illustrative": 37}, base) == ["illustrative"],
           "an illustrative count above baseline is a regression")
    expect(regressions({**base, "illustrative": 30}, base) == [],
           "an illustrative count below baseline is not a regression (at-or-below is green)")
    expect(regressions(base, base) == [], "at the ceiling is green")

    if failures:
        for f in failures:
            print(f"FAIL: {f}", file=sys.stderr)
        return 1
    print("gen-examples self-test OK")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--coverage", action="store_true")
    ap.add_argument("--strict", action="store_true", help="with --coverage: exit 1 if <100%")
    ap.add_argument("--baseline", action="store_true",
                    help="with --coverage: red (exit 2) on any gap count worse than the committed baseline")
    ap.add_argument("--write-baseline", action="store_true",
                    help="with --coverage: (re)capture the committed baseline from current counts")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    if args.coverage:
        return coverage(args.strict, args.verbose, args.baseline, args.write_baseline)
    return run(args.check, args.verbose)


if __name__ == "__main__":
    sys.exit(main())
