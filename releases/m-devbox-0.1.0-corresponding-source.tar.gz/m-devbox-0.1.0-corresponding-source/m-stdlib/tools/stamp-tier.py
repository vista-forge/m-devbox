#!/usr/bin/env python3
"""stamp-tier — green-only freshness anchor for an opt-in test tier.

Safety-net-reconciliation P1-N4. The tier-coverage gate (N3) proves every
`tests/*TST.m` is *claimed* by a tier; it deliberately does NOT prove the
opt-in tiers actually RUN. A tier that runs in no scheduled-and-gated context
(m-stdlib INTEGRATION `STDS3MINIOTST`; the v-stdlib LIVE `@exrun live` suites)
can rot silently. This tool closes that: it runs the tier's suites through the
driver stack (`m test … -o json`), reconciles suites-discovered × ran × passed,
and — ONLY on a fully green run — rewrites a COMMITTED anchor carrying those
counts + an RFC3339 `generated:` line. The org meta-gate reds if the anchor is
stale / absent / inconsistent, so an opt-in tier can no longer stop being
exercised without something going red.

This is the M-suite sibling of m-cli's N1 guardrail self-test stamp
(m-cli/examples/GUARDRAIL-SELFTEST.md + writeSelftestStamp): same `generated:`
anchor shape, same green-ONLY discipline (a red/partial/absent run leaves the
old stamp to go stale — the staleness IS the alarm, never an unconditional
re-stamp, which is the exact class this whole effort closes).

Reconciliation (mirrors meta-gate.sh's content-integrity check):
  * suites_discovered = the suite files this tier claims (argv).
  * ran      = suites that actually executed (total assertions > 0). A 0/0 is a
               silent abort, NOT a run (the incident's Tier-ii #6 class).
  * passed   = suites green (ok AND total > 0 AND failed == 0).
  * verdict  = green  IFF  ran == discovered  AND  passed == ran.
Anything else → NOT stamped (the run reds; the old anchor stays put and ages).

Fully argv-driven so it is byte-identical across repos (drop into any repo's
tools/). Engine transport flags are passed verbatim to `m test`.

Usage:
  tools/stamp-tier.py --m <mbin> --tier INTEGRATION \
      --stamp examples/INTEGRATION-STAMP.md \
      --net "m-stdlib STDS3 integration round-trip (MinIO)" \
      --engine-label "m-test-engine (ydb) + MinIO" \
      --engine ydb --docker m-test-engine --chset m --routines src \
      tests/STDS3MINIOTST.m
  tools/stamp-tier.py --self-test     # engine-free reconciliation self-test
"""

from __future__ import annotations

import argparse
import datetime
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SuiteResult:
    suite: str
    passed: int
    failed: int
    total: int
    ok: bool

    @property
    def ran(self) -> bool:
        # total assertions > 0 → the suite actually executed (a 0/0 is a silent
        # abort, which must NOT count as a run).
        return self.total > 0

    @property
    def green(self) -> bool:
        return self.ok and self.total > 0 and self.failed == 0


@dataclass
class Reconciliation:
    discovered: int
    ran: int
    passed: int

    @property
    def green(self) -> bool:
        return (
            self.discovered > 0
            and self.ran == self.discovered
            and self.passed == self.ran
        )


def parse_test_json(stdout: str) -> list[SuiteResult]:
    """Parse `m test -o json` stdout into per-suite results ([] if non-JSON)."""
    try:
        env = json.loads(stdout)
    except json.JSONDecodeError:
        return []
    data = env.get("data", {}) or {}
    out: list[SuiteResult] = []
    for s in data.get("results", []):
        out.append(
            SuiteResult(
                suite=s.get("suite", "?"),
                passed=s.get("passed", 0),
                failed=s.get("failed", 0),
                total=s.get("total", 0),
                ok=bool(s.get("ok")),
            )
        )
    return out


def reconcile(discovered_suites: list[str], results: list[SuiteResult]) -> Reconciliation:
    ran = sum(1 for r in results if r.ran)
    passed = sum(1 for r in results if r.green)
    return Reconciliation(discovered=len(discovered_suites), ran=ran, passed=passed)


STAMP_TEMPLATE = """\
# {tier} tier — freshness anchor

generated: {generated}
net: {net}
tier: {tier}
engine: {engine}
suites_discovered: {discovered}
ran: {ran}
passed: {passed}
verdict: green

Opt-in test tier freshness anchor (safety-net-reconciliation P1-N4). This tier
runs in no PR-gated context — it is exercised only on demand / on a scheduled
cadence — so nothing would notice if it stopped running. `tools/stamp-tier.py`
rewrites this file with a fresh `generated:` line + the RECONCILED counts ONLY
after a fully green run (every discovered suite ran and passed). The org
meta-gate reds if this anchor is stale, absent, or the counts do not reconcile,
so this opt-in tier can no longer silently stop being exercised. DO NOT
hand-edit — it is regenerated; a stale timestamp IS the alarm.
"""


def write_stamp(path: Path, tier: str, net: str, engine: str, rec: Reconciliation) -> None:
    body = STAMP_TEMPLATE.format(
        tier=tier,
        net=net,
        engine=engine,
        generated=datetime.datetime.now(datetime.timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z"),
        discovered=rec.discovered,
        ran=rec.ran,
        passed=rec.passed,
    )
    path.write_text(body)


def run_tier(mbin: str, engine_flags: list[str], suites: list[str], verbose: bool):
    cmd = [mbin, "test", *engine_flags, "-o", "json", *suites]
    if verbose:
        print("  $ " + " ".join(cmd), file=sys.stderr)
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return proc, parse_test_json(proc.stdout)


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--self-test", action="store_true", help="engine-free reconciliation self-test")
    ap.add_argument("--m", default="m", help="the `m` toolchain binary (default: PATH)")
    ap.add_argument("--tier", help="tier name (e.g. INTEGRATION, LIVE)")
    ap.add_argument("--stamp", help="path to the committed freshness anchor")
    ap.add_argument("--net", default="", help="human description of the net")
    ap.add_argument("--engine-label", default="", help="engine identity string for the stamp")
    # Engine transport flags, passed verbatim to `m test`.
    ap.add_argument("--engine")
    ap.add_argument("--docker")
    ap.add_argument("--chset")
    ap.add_argument("--namespace")
    ap.add_argument("--routines", action="append", default=[])
    ap.add_argument("-v", "--verbose", action="store_true")
    ap.add_argument("suites", nargs="*", help="tier suite files (tests/*TST.m)")
    args = ap.parse_args(argv)

    if args.self_test:
        return self_test()

    if not args.tier or not args.stamp or not args.suites:
        ap.error("--tier, --stamp, and at least one suite are required (or pass --self-test)")

    engine_flags: list[str] = []
    if args.engine:
        engine_flags += ["--engine", args.engine]
    if args.docker:
        engine_flags += ["--docker", args.docker]
    if args.chset:
        engine_flags += ["--chset", args.chset]
    if args.namespace:
        engine_flags += ["--namespace", args.namespace]
    for r in args.routines:
        engine_flags += ["--routines", r]

    proc, results = run_tier(args.m, engine_flags, args.suites, args.verbose)
    rec = reconcile(args.suites, results)

    print(
        f"{args.tier}: discovered={rec.discovered} ran={rec.ran} passed={rec.passed} "
        f"(m test exit {proc.returncode})"
    )
    for r in results:
        mark = "ok" if r.green else ("ABORT 0/0" if not r.ran else "RED")
        print(f"    {r.suite:24} {mark}  ({r.passed}/{r.total})")

    if not rec.green:
        print(
            f"{args.tier}: NOT green — anchor {args.stamp} left stale on purpose "
            "(a red/partial/aborted run must not re-stamp)",
            file=sys.stderr,
        )
        if not results and proc.stdout:
            print(proc.stdout[-1500:], file=sys.stderr)
            print(proc.stderr[-1500:], file=sys.stderr)
        return 1

    write_stamp(Path(args.stamp), args.tier, args.net, args.engine_label or "unknown", rec)
    print(f"{args.tier}: green — stamped {args.stamp} ({rec.passed}/{rec.discovered} suites)")
    return 0


# ---------------------------------------------------------------------------
# Engine-free self-test of the reconciliation logic (wired into `make` checks).
# ---------------------------------------------------------------------------
def _json(results: list[dict]) -> str:
    return json.dumps({"ok": all(r.get("ok") for r in results), "data": {"results": results}})


def self_test() -> int:
    failures: list[str] = []

    def check(name: str, cond: bool):
        if not cond:
            failures.append(name)

    # All green → verdict green, counts reconcile.
    res = parse_test_json(_json([
        {"suite": "STDS3MINIOTST", "passed": 11, "failed": 0, "total": 11, "ok": True},
    ]))
    rec = reconcile(["tests/STDS3MINIOTST.m"], res)
    check("all-green reconciles", rec.green and rec.discovered == 1 and rec.ran == 1 and rec.passed == 1)

    # A failing suite → not green.
    res = parse_test_json(_json([
        {"suite": "A", "passed": 2, "failed": 1, "total": 3, "ok": False},
    ]))
    check("failing suite not green", not reconcile(["tests/A.m"], res).green)

    # A 0/0 silent abort → ran < discovered → not green.
    res = parse_test_json(_json([
        {"suite": "A", "passed": 0, "failed": 0, "total": 0, "ok": True},
    ]))
    rec = reconcile(["tests/A.m"], res)
    check("0/0 abort not a run", rec.ran == 0 and not rec.green)

    # A discovered suite that never appears in results (crash before it) → ran < discovered.
    res = parse_test_json(_json([
        {"suite": "A", "passed": 3, "failed": 0, "total": 3, "ok": True},
    ]))
    rec = reconcile(["tests/A.m", "tests/B.m"], res)
    check("missing suite -> ran<discovered", rec.discovered == 2 and rec.ran == 1 and not rec.green)

    # Non-JSON (crashed invocation) → no results → not green.
    check("non-JSON -> empty", parse_test_json("boom not json") == [])
    check("empty results not green", not reconcile(["tests/A.m"], []).green)

    # Multi-suite all green.
    res = parse_test_json(_json([
        {"suite": "A", "passed": 5, "failed": 0, "total": 5, "ok": True},
        {"suite": "B", "passed": 3, "failed": 0, "total": 3, "ok": True},
    ]))
    check("multi all-green", reconcile(["tests/A.m", "tests/B.m"], res).green)

    if failures:
        print("stamp-tier self-test FAILED: " + ", ".join(failures), file=sys.stderr)
        return 1
    print("stamp-tier self-test: all reconciliation cases pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
