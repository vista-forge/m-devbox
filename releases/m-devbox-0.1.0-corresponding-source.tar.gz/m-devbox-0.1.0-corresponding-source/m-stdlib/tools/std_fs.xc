$STDLIB_LIB/stdfs.so
available:   ydb_long_t stdfs_available()
writeBytes:  ydb_long_t stdfs_writeBytes(I:ydb_string_t*, I:ydb_string_t*)
appendBytes: ydb_long_t stdfs_appendBytes(I:ydb_string_t*, I:ydb_string_t*)
readBytes:   ydb_long_t stdfs_readBytes(I:ydb_string_t*, O:ydb_string_t*[1048576])
lastError:   ydb_long_t stdfs_lasterror(O:ydb_string_t*[1024])
