#!/usr/bin/env python3
"""run-live-qc (QC-B) — the nightly live MSL *suite* tier + LIVE-QC.md generator.

Runs the m-stdlib **test suites** (`tests/*TST.m`) on the LIVE engines through
the **driver stack only** (`m test --docker …` / `--namespace VISTA` — never raw
`docker exec`; the org engine-access rule) and turns the result into the trust
artifact `examples/LIVE-QC.md`: a (suite × engine) pass/fail grid, the captured
engine identity (`$ZYRELEASE` / IRIS build), and — on a red — the failing
assertion lines, so a live-only regression is diagnosable from the committed
artifact.

This is the missing coverage class from the continuous-live-QC proposal
(`docs` repo `proposals/continuous-live-qc-harness.md` §Design → 2): MSL
*suites* run only on the BARE engines in CI (the nightly living-examples cadence
runs *examples*, not suites), so an engine-version-sensitive suite failure — the
STDJSONTST-on-vehu (YDB r2.02) case — cannot be caught. This tier closes gap B.

It is the suite-tier sibling of `tools/run-examples.py` (which runs the generated
`examples/programs/*EX.m` and writes `examples/REPORT.md`); the two are wired into
the same nightly cron and share the same fail-soft contract.

Tiers & arms:

  | arm       | engine | container | transport         | suites                     |
  |-----------|--------|-----------|-------------------|----------------------------|
  | ydb-live  | ydb    | vehu      | --docker --chset m| core (optional = WAIVED*)  |
  | iris-live | iris   | foia-t12  | --namespace VISTA | core + full optional tier  |

  *ydb-live optional tier is a DECLARED WAIVER (F5), never a silent skip: the
   call-out `.so`s (libz/libzstd/libcrypto) are not deployed on the live
   YDB-VistA engine (vehu). Listed + counted in the report until they are.

Fail-soft contract: the BARE tier in CI stays the hard gate. This live tier
reds VISIBLY in `examples/LIVE-QC.md` and always exits 0 (the cron commits the
refreshed artifact; a red is a committed diff, not a failed job).

The core / optional suite lists are supplied by the Makefile (single source of
truth — the same `CORE_SUITES` / `OPTIONAL_PATHS` that `make test` uses), so
this tool never re-derives the tier split and cannot drift from it.

Usage:
  # the nightly cadence (both live engines, write the report):
  python3 tools/run-live-qc.py --m <mbin> \
      --core-suites tests/STDJSONTST.m … --optional-suites tests/STDCRYPTOTST.m … \
      --report examples/LIVE-QC.md
  # one arm:
  python3 tools/run-live-qc.py --m <mbin> --arms ydb-live --core-suites …
  python3 tools/run-live-qc.py --self-test
"""

from __future__ import annotations

import argparse
import datetime
import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Arm:
    name: str            # "ydb-live" | "iris-live"
    engine: str          # "ydb" | "iris"
    docker: str          # container name (the --docker / driver transport target)
    chset: str = ""      # "m" for YDB byte mode; "" elsewhere
    namespace: str = ""  # IRIS namespace (live VistA = VISTA)
    run_optional: bool = True   # False → the optional tier is a declared waiver

    def test_flags(self, extra_routines: list[str]) -> list[str]:
        """`m test` transport + staging flags for this live arm."""
        f = ["--engine", self.engine, "--docker", self.docker]
        if self.chset:
            f += ["--chset", self.chset]
        if self.namespace:
            f += ["--namespace", self.namespace]
        f += ["--routines", "src"]
        for r in extra_routines:
            f += ["--routines", r]
        return f

    def identity_env(self) -> dict[str, str]:
        """Env for the driver-backed `m vista exec` identity probe.

        `m vista exec` reads the container/namespace from `M_<ENGINE>_*` env
        (it has no --docker/--namespace flags), unlike `m test`.
        """
        env = dict(os.environ)
        if self.engine == "ydb":
            env["M_YDB_CONTAINER"] = self.docker
        else:
            env["M_IRIS_CONTAINER"] = self.docker
            if self.namespace:
                env["M_IRIS_NAMESPACE"] = self.namespace
        return env

    def identity_expr(self) -> str:
        """The M command that writes this engine's version string."""
        return "write $zyrelease" if self.engine == "ydb" else "write $zversion"


# The two live arms. Docker names are overridable (vehu / foia-t12).
def live_arms(ydb_docker: str, iris_docker: str) -> dict[str, Arm]:
    return {
        "ydb-live": Arm("ydb-live", "ydb", ydb_docker, chset="m", run_optional=False),
        "iris-live": Arm("iris-live", "iris", iris_docker, namespace="VISTA", run_optional=True),
    }


def suite_name(path: str) -> str:
    """tests/STDJSONTST.m → STDJSONTST (matches the JSON `suite` field)."""
    return Path(path).stem


@dataclass
class SuiteResult:
    suite: str
    passed: int
    failed: int
    total: int
    ok: bool
    failures: list[dict] = field(default_factory=list)  # [{description,expected,actual}]

    @property
    def green(self) -> bool:
        # A 0/0 is a silent abort → failure (the kickoff's hard rule).
        return self.ok and self.total > 0 and self.failed == 0


def run_m_test(mbin: str, arm: Arm, extra_routines: list[str], suites: list[str],
               verbose: bool = False) -> list[SuiteResult]:
    """Invoke `m test … -o json` over the driver stack; parse the suite results.

    Returns [] on a non-JSON / crashed invocation (surfaced by the caller as an
    empty arm — reds the report, never raises).
    """
    if not suites:
        return []
    flags = arm.test_flags(extra_routines)
    cmd = [mbin, "test", *flags, "-o", "json", *suites]
    if verbose:
        print("  $ " + " ".join(cmd), file=sys.stderr)
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return parse_test_json(proc.stdout, arm, proc.returncode, proc.stderr, verbose)


def parse_test_json(stdout: str, arm: Arm, returncode: int = 0, stderr: str = "",
                    verbose: bool = False) -> list[SuiteResult]:
    try:
        env = json.loads(stdout)
    except json.JSONDecodeError:
        print(f"  ! {arm.name}: non-JSON output (exit {returncode})", file=sys.stderr)
        if verbose:
            print(stdout[-2000:], file=sys.stderr)
            print(stderr[-2000:], file=sys.stderr)
        return []
    data = env.get("data", {}) or {}
    out: list[SuiteResult] = []
    for s in data.get("results", []):
        out.append(SuiteResult(
            suite=s["suite"],
            passed=s.get("passed", 0),
            failed=s.get("failed", 0),
            total=s.get("total", 0),
            ok=bool(s.get("ok")),
            failures=list(s.get("failures", []) or []),
        ))
    return out


def capture_identity(mbin: str, arm: Arm, verbose: bool = False) -> str:
    """Engine version string via the driver stack (`m vista exec`).

    Resilient: any failure returns a visible placeholder rather than raising —
    identity is diagnostic context, never a gate.
    """
    cmd = [mbin, "vista", "exec", "--engine", arm.engine, "--transport", "docker",
           "-o", "json", arm.identity_expr()]
    if verbose:
        print("  $ " + " ".join(cmd), file=sys.stderr)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, env=arm.identity_env())
        env = json.loads(proc.stdout)
    except (json.JSONDecodeError, OSError):
        return "unknown (identity probe failed)"
    return parse_identity_json(proc.stdout)


def parse_identity_json(stdout: str) -> str:
    try:
        env = json.loads(stdout)
    except json.JSONDecodeError:
        return "unknown (identity probe failed)"
    out = (env.get("data", {}) or {}).get("stdout", "")
    line = out.strip().splitlines()[0].strip() if out.strip() else ""
    return line or "unknown (empty identity)"


@dataclass
class ArmRun:
    arm: Arm
    identity: str
    results: list[SuiteResult]
    waived: list[str] = field(default_factory=list)   # suites declared-waived on this arm

    @property
    def all_green(self) -> bool:
        return bool(self.results) and all(r.green for r in self.results)

    @property
    def reds(self) -> list[SuiteResult]:
        return [r for r in self.results if not r.green]


def run_arm(mbin: str, arm: Arm, core: list[str], optional: list[str],
            extra_routines: list[str], verbose: bool) -> ArmRun:
    """Run one live arm: core always; optional iff the arm runs it, else waived."""
    identity = capture_identity(mbin, arm, verbose)
    suites = list(core)
    waived: list[str] = []
    if arm.run_optional:
        suites += optional
    else:
        waived = [suite_name(p) for p in optional]
    results = run_m_test(mbin, arm, extra_routines, suites, verbose)
    return ArmRun(arm, identity, results, waived)


# ── LIVE-QC.md ────────────────────────────────────────────────────────────────

def render_report(arms: list[ArmRun], stamp: str) -> str:
    arm_names = [r.arm.name for r in arms]
    by_suite: dict[str, dict[str, SuiteResult]] = {}
    for r in arms:
        for s in r.results:
            by_suite.setdefault(s.suite, {})[r.arm.name] = s
    # Stable suite order: sorted union of everything observed.
    all_suites = sorted(by_suite)

    L: list[str] = []
    L.append("---")
    L.append("title: Live MSL suite QC — run report")
    L.append("doc_type: [REPORT]")
    L.append("generated_from: tests/*TST.m (core + optional suites)")
    L.append("tier: live")
    L.append(f"generated_at: {stamp}")
    L.append("---")
    L.append("")
    L.append("# Live MSL suite QC — run report")
    L.append("")
    L.append(
        "GENERATED by `tools/run-live-qc.py` (`make live-qc` / the nightly live "
        "cadence) — DO NOT edit by hand. This is the **suite** half of the live "
        "trust surface (its sibling `REPORT.md` is the *examples* half): the "
        "m-stdlib test suites are shown here running on the real VistA engines, "
        "through the driver stack only. The BARE tier in CI stays the hard gate; "
        "this live tier is **fail-soft** — a red is a committed diff in this file "
        "(with the failing assertion lines below), not a failed job. It exists to "
        "catch engine-**version**-sensitive regressions the bare tier cannot see "
        "(the STDJSONTST-on-vehu / YDB r2.02 case)."
    )
    L.append("")
    L.append(f"- **Generated:** {stamp}")
    L.append(f"- **Engines:** {', '.join(f'`{a}`' for a in arm_names)}")
    L.append("")

    # Engine identity (F2 — engine version is a real axis; a silent upgrade must
    # show up here as a diff, not a mystery red).
    L.append("## Engine identity")
    L.append("")
    L.append("| Arm | Container | Identity |")
    L.append("|---|---|---|")
    for r in arms:
        L.append(f"| `{r.arm.name}` | `{r.arm.docker}` | `{r.identity}` |")
    L.append("")
    L.append("> A change to any identity string above is an engine upgrade — expect "
             "it to correlate with any new red, and treat the pairing as the first "
             "diagnostic (F2: engine *version* is a real behavioural axis).")
    L.append("")

    # Pass/fail grid.
    L.append("## Pass / fail by suite × engine")
    L.append("")
    header = "| Suite | " + " | ".join(f"`{a}`" for a in arm_names) + " |"
    L.append(header)
    L.append("|" + "---|" * (1 + len(arm_names)))
    waived_by_arm = {r.arm.name: set(r.waived) for r in arms}
    for suite in all_suites:
        cells = []
        for a in arm_names:
            s = by_suite.get(suite, {}).get(a)
            if s is None:
                if suite in waived_by_arm.get(a, set()):
                    cells.append("⚠️ waived")
                else:
                    cells.append("·")
            elif s.green:
                cells.append(f"✅ {s.passed}/{s.total}")
            elif s.total == 0:
                cells.append("🟥 0/0")
            else:
                cells.append(f"🟥 {s.passed}/{s.total}")
        L.append(f"| `{suite}` | " + " | ".join(cells) + " |")
    L.append("")

    # Declared waivers (F5 — never a silent skip).
    waived_any = [r for r in arms if r.waived]
    if waived_any:
        L.append("## Declared waivers")
        L.append("")
        for r in waived_any:
            names = ", ".join(f"`{n}`" for n in r.waived)
            L.append(f"- **`{r.arm.name}`** — optional tier waived ({len(r.waived)} "
                     f"suite(s): {names}). The call-out `.so`s (libz/libzstd/"
                     "libcrypto) are not deployed on the live YDB-VistA engine "
                     "(F5). A *declared* waiver, not a silent skip — it is listed "
                     "and counted here until the libraries are installed on vehu.")
        L.append("")

    # Failing-assertion detail (acceptance 3 — a live-only red is diagnosable
    # from the committed artifact).
    reds = [(r, s) for r in arms for s in r.reds]
    L.append("## Failing assertions")
    L.append("")
    if not reds:
        L.append("None — every suite that ran is green on both live engines. ✅")
        L.append("")
    else:
        for r, s in reds:
            L.append(f"### 🟥 `{s.suite}` on `{r.arm.name}` ({r.arm.docker} — "
                     f"`{r.identity}`)")
            L.append("")
            if s.total == 0:
                L.append("- **0/0** — suite aborted before any assertion ran "
                         "(a silent abort counts as a failure). No per-assertion "
                         "detail available; run the suite with `-v` on this engine "
                         "to see the abort.")
            else:
                L.append(f"- **{s.passed}/{s.total} passed, {s.failed} failed.**")
                if s.failures:
                    L.append("")
                    L.append("| Assertion | Expected | Actual |")
                    L.append("|---|---|---|")
                    for f in s.failures:
                        d = str(f.get("description", "")).replace("|", "\\|")
                        e = str(f.get("expected", "")).replace("|", "\\|")
                        a = str(f.get("actual", "")).replace("|", "\\|")
                        L.append(f"| {d} | `{e}` | `{a}` |")
                else:
                    L.append("- (no per-assertion detail in the JSON envelope; "
                             "the runner reported a failure count without "
                             "`failures[]` — rerun with `-v`.)")
            L.append("")

    # Verdict.
    all_green = all(r.all_green for r in arms) and bool(arms)
    verdict = "✅ all green" if all_green else "🟥 see red cells / failing assertions above"
    L.append(f"**Verdict:** {verdict}.")
    L.append("")
    return "\n".join(L) + "\n"


# ── driver ───────────────────────────────────────────────────────────────────

def gate_summary(arms: list[ArmRun]) -> tuple[bool, list[str]]:
    lines: list[str] = []
    ok = True
    for r in arms:
        greens = sum(1 for s in r.results if s.green)
        total = len(r.results)
        reds = [s.suite for s in r.results if not s.green]
        lines.append(f"  {r.arm.name:10} [{r.identity}]  {greens}/{total} suites green"
                     + (f"  RED: {', '.join(reds)}" if reds else "")
                     + (f"  (waived {len(r.waived)})" if r.waived else ""))
        if reds or not total:
            ok = False
    return ok, lines


def run(args: argparse.Namespace) -> int:
    core = list(args.core_suites or [])
    optional = list(args.optional_suites or [])
    if not core:
        print("run-live-qc: no --core-suites given (the Makefile supplies these).",
              file=sys.stderr)
        return 2

    all_arms = live_arms(args.ydb_live_docker, args.iris_live_docker)
    names = ([a.strip() for a in args.arms.split(",") if a.strip()]
             if args.arms else list(all_arms))
    try:
        arms_def = [all_arms[n] for n in names]
    except KeyError as e:
        print(f"run-live-qc: unknown arm {e}; valid: {', '.join(all_arms)}", file=sys.stderr)
        return 2

    extra = list(args.extra_routines or [])
    print(f"run-live-qc tier=live arms={', '.join(a.name for a in arms_def)} "
          f"({len(core)} core + {len(optional)} optional suite(s))")

    runs = [run_arm(args.m, a, core, optional, extra, args.verbose) for a in arms_def]

    ok, lines = gate_summary(runs)
    for ln in lines:
        print(ln)

    if args.report:
        stamp = args.stamp or datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        Path(args.report).write_text(render_report(runs, stamp), encoding="utf-8")
        print(f"run-live-qc: wrote {args.report}")

    # Fail-soft ALWAYS (this is the nightly live tier; the bare tier gates).
    if not ok:
        print("run-live-qc: reds above (fail-soft live tier — not gating; "
              "the report carries the diff)")
    return 0


def self_test() -> int:
    fails: list[str] = []

    def expect(c, m):
        if not c:
            fails.append(m)

    arms = live_arms("vehu", "foia-t12")

    # Arm construction + transport flags.
    ydb, iris = arms["ydb-live"], arms["iris-live"]
    expect(ydb.test_flags([]) == ["--engine", "ydb", "--docker", "vehu",
                                  "--chset", "m", "--routines", "src"],
           "ydb-live test flags = docker vehu + chset m")
    expect(iris.test_flags(["../m-stdlib/src"]) == [
        "--engine", "iris", "--docker", "foia-t12", "--namespace", "VISTA",
        "--routines", "src", "--routines", "../m-stdlib/src"],
        "iris-live test flags = VISTA ns + extra routines")
    expect(ydb.run_optional is False and iris.run_optional is True,
           "ydb-live waives optional; iris-live runs it")

    # Identity probe env + expression.
    expect(ydb.identity_env().get("M_YDB_CONTAINER") == "vehu", "ydb identity env container")
    e = iris.identity_env()
    expect(e.get("M_IRIS_CONTAINER") == "foia-t12" and e.get("M_IRIS_NAMESPACE") == "VISTA",
           "iris identity env container + namespace")
    expect(ydb.identity_expr() == "write $zyrelease", "ydb identity = $zyrelease")
    expect(iris.identity_expr() == "write $zversion", "iris identity = $zversion")

    # suite_name mapping.
    expect(suite_name("tests/STDJSONTST.m") == "STDJSONTST", "suite_name strips dir + .m")

    # SuiteResult.green semantics.
    expect(SuiteResult("X", 5, 0, 5, True).green, "5/5 ok is green")
    expect(not SuiteResult("X", 0, 0, 0, False).green, "0/0 is not green (silent abort)")
    expect(not SuiteResult("X", 4, 1, 5, True).green, "a failed assertion is not green")

    # JSON parse incl. the F3 failures[] shape.
    passing = json.dumps({"data": {"results": [
        {"suite": "STDSTRTST", "passed": 12, "failed": 0, "total": 12, "ok": True}]}})
    res = parse_test_json(passing, ydb)
    expect(len(res) == 1 and res[0].green and res[0].failures == [], "parse passing suite")
    failing = json.dumps({"data": {"results": [
        {"suite": "STDJSONTST", "passed": 40, "failed": 2, "total": 42, "ok": False,
         "failures": [{"description": "round-trips", "expected": "=1", "actual": "=0"},
                      {"description": "escapes", "expected": "=a", "actual": "=b"}]}]}})
    res = parse_test_json(failing, ydb)
    expect(len(res) == 1 and not res[0].green and len(res[0].failures) == 2,
           "parse failing suite carries failures[]")
    expect(parse_test_json("not json", ydb) == [], "non-JSON → empty (no raise)")

    # Identity parse.
    idj = json.dumps({"data": {"stdout": "YottaDB r2.02 Linux x86_64\n", "status": 0}})
    expect(parse_identity_json(idj) == "YottaDB r2.02 Linux x86_64", "identity parsed + trimmed")
    expect(parse_identity_json("garbage").startswith("unknown"), "bad identity JSON → placeholder")
    expect(parse_identity_json('{"data":{"stdout":""}}').startswith("unknown"),
           "empty identity → placeholder")

    # ArmRun aggregation.
    green_run = ArmRun(ydb, "YottaDB r2.02", [SuiteResult("A", 3, 0, 3, True)])
    red_run = ArmRun(iris, "IRIS 2026.1",
                     [SuiteResult("A", 3, 0, 3, True), SuiteResult("B", 2, 1, 3, False)])
    expect(green_run.all_green and not red_run.all_green, "all_green aggregation")
    expect([s.suite for s in red_run.reds] == ["B"], "reds picks the failing suite")
    empty_run = ArmRun(ydb, "x", [])
    expect(not empty_run.all_green, "empty arm is not all-green (crashed invocation)")

    # Waiver: ydb waives optional, iris runs it (verified via run_arm's suite
    # partitioning logic without an engine — parse pre-baked JSON is separate;
    # here we just assert the waiver list is the optional suite basenames).
    expect([suite_name("tests/STDCRYPTOTST.m")] == ["STDCRYPTOTST"], "optional waiver name")

    # Report renders without engine access, shows identity + failing assertions
    # + waiver.
    ydb_red = ArmRun(ydb, "YottaDB r2.02 Linux x86_64",
                     [SuiteResult("STDJSONTST", 40, 2, 42, False,
                                  [{"description": "round-trips a big int",
                                    "expected": "=1", "actual": "=0"}]),
                      SuiteResult("STDSTRTST", 12, 0, 12, True)],
                     waived=["STDCRYPTOTST", "STDCOMPRESSTST"])
    iris_ok = ArmRun(iris, "IRIS for UNIX 2026.1 (Build 234U)",
                     [SuiteResult("STDJSONTST", 42, 0, 42, True),
                      SuiteResult("STDSTRTST", 12, 0, 12, True),
                      SuiteResult("STDCRYPTOTST", 8, 0, 8, True)])
    rep = render_report([ydb_red, iris_ok], "2026-07-07 04:00")
    expect("Live MSL suite QC" in rep, "report title")
    expect("YottaDB r2.02 Linux x86_64" in rep and "IRIS for UNIX 2026.1 (Build 234U)" in rep,
           "report shows both engine identities")
    expect("🟥 40/42" in rep and "✅ 12/12" in rep, "grid shows red + green cells")
    expect("round-trips a big int" in rep and "`=0`" in rep, "failing assertion lines visible")
    expect("⚠️ waived" in rep and "Declared waivers" in rep, "waiver shown + counted")
    expect("**Verdict:** 🟥" in rep, "red verdict")
    # All-green path.
    rep2 = render_report([iris_ok], "2026-07-07 04:00")
    expect("**Verdict:** ✅ all green" in rep2 and "None — every suite" in rep2,
           "all-green verdict + no failing assertions")

    # gate_summary.
    ok, _ = gate_summary([iris_ok])
    expect(ok, "all-green arm → gate ok")
    bad, _ = gate_summary([ydb_red])
    expect(not bad, "red arm → gate not ok (still fail-soft at the run() layer)")

    if fails:
        for f in fails:
            print(f"FAIL: {f}", file=sys.stderr)
        return 1
    print("run-live-qc self-test OK")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--m", default="m", help="the `m` toolchain binary (default: m on PATH)")
    ap.add_argument("--arms", default="", help="comma-separated arm subset (default: both live arms)")
    ap.add_argument("--core-suites", nargs="*", default=[],
                    help="core suite paths (Makefile CORE_SUITES) — run on every arm")
    ap.add_argument("--optional-suites", nargs="*", default=[],
                    help="optional suite paths (Makefile OPTIONAL_PATHS) — run on iris-live, waived on ydb-live")
    ap.add_argument("--extra-routines", action="append", default=[],
                    help="extra --routines dir to stage (v-stdlib: ../m-stdlib/src). Repeatable.")
    ap.add_argument("--report", default="", help="write LIVE-QC.md to this path")
    ap.add_argument("--stamp", default="", help="override the report timestamp (else now)")
    ap.add_argument("--ydb-live-docker", default="vehu")
    ap.add_argument("--iris-live-docker", default="foia-t12")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
