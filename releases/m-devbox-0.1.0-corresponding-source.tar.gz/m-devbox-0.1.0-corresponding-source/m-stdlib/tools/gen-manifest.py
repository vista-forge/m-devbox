#!/usr/bin/env python3
"""Generate dist/stdlib-manifest.json from src/STD*.m.

Spec: docs/guides/m-doc-grammar.md (the doc-comment grammar this consumes)
      docs/archive/discoverability-and-tooling-plan.md  § 3.2 (the schema)

Since the stdlib-doc-accuracy Phase 7 de-fork (W5/D-2a) this file is a thin
SHELL over the canonical shared parser core, `tools/mdoc/` (this repo is the
core's home; v-stdlib and v-web consume the same package via the sibling
checkout). Repo-specific knowledge — the m-only @tag/@phase registry tags,
the suffix-group helper-raise idiom, the raise exemptions, the changelog
paths — lives in `tools/mdoc_config.py` (`CONFIG`); an RC-2-class parser fix
is a one-repo change in mdoc/core.py picked up by all three consumers' gates.

The parser is STRICT (stdlib-doc-accuracy W1 — the tag↔code verifier):
unknown `@tags`, repeated singleton tags, an `@param` set that differs from
the label's formallist, a `returns`⇄form contradiction, a raise site no label
of its module registers, a documented code no code ever raises, and a version
heading still marked pending/unreleased are all HARD ERRORS — the generator
prints every problem and exits 2 without writing outputs, so
`make manifest-check` reds.

Usage:
    python3 tools/gen-manifest.py                # writes dist/stdlib-manifest.json + dist/errors.json
    python3 tools/gen-manifest.py --self-test    # shared mdoc corpus + m config-wiring checks
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mdoc import core, selftest  # noqa: E402
from mdoc_config import CONFIG  # noqa: E402

core.configure(CONFIG)

# Module-level API for the file-path importers (seam_contract.py loads this
# shell and calls build_manifest(); gen-grammar.py reads KNOWN_TAGS; the golden
# tests call parse_module_file). Bound AFTER configure() so they carry the
# configured state.
REPO_ROOT = core.REPO_ROOT
SRC_DIR = core.SRC_DIR
DIST_DIR = core.DIST_DIR
KNOWN_TAGS = core.KNOWN_TAGS
PROBLEMS = core.PROBLEMS
PUBLICNESS = core.PUBLICNESS
UNACCOUNTED = core.UNACCOUNTED
RAISE_EXEMPT = core.RAISE_EXEMPT
parse_module_file = core.parse_module_file
parse_doc_block = core.parse_doc_block
parse_label_line = core.parse_label_line
collect_doc_lines = core.collect_doc_lines
collect_raise_sites = core.collect_raise_sites
line_has_value_quit = core.line_has_value_quit
strip_comment = core.strip_comment
verify_raises = core.verify_raises
build_label_entry = core.build_label_entry
build_seams = core.build_seams
build_manifest = core.build_manifest
write_outputs = core.write_outputs
read_stdlib_version = core.read_stdlib_version


def self_test() -> int:
    """The shared mdoc corpus, then m-stdlib config-wiring assertions."""
    rc = selftest.run(restore=CONFIG)
    if rc != 0:
        return rc

    failures: list[str] = []

    def expect(cond, msg):
        if not cond:
            failures.append(msg)

    # The real m config drives the core: suffix-group helper idiom wired.
    helper_sites = [c for c, _ in core.collect_raise_sites(
        ['        if bad do raise("BOOM") quit'], "STDX")]
    expect(helper_sites == ["U-STDX-BOOM"],
           f"m helper-raise idiom should yield ['U-STDX-BOOM'], got {helper_sites}")
    # m registry = shared 16 + @tag/@phase appended.
    merged_names = {t.name for t in core.MERGED_TAGS}
    expect({"@tag", "@phase"} <= merged_names,
           f"m extra tags missing from merged registry: {sorted(merged_names)}")
    expect(core.CONFIG is CONFIG and CONFIG.parse_module_tag_phase,
           "m config must parse module @tag/@phase")
    expect(len(core.RAISE_EXEMPT) == 3,
           f"m raise exemptions wrong: {sorted(core.RAISE_EXEMPT)}")
    expect(not core.PUBLICNESS_EXEMPT, "m has no publicness exemptions")

    if failures:
        for f in failures:
            print(f"FAIL: {f}", file=sys.stderr)
        return 1
    print("self-test OK (shared mdoc corpus + m config wiring)")
    return 0


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(description="Generate dist/stdlib-manifest.json + dist/errors.json from src/STD*.m.")
    p.add_argument("--self-test", action="store_true", help="Run the shared mdoc corpus + m config-wiring checks and exit.")
    args = p.parse_args(argv)

    if args.self_test:
        return self_test()

    return core.run_generate()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
