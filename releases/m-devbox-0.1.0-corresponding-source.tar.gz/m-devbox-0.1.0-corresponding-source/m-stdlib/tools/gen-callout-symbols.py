#!/usr/bin/env python3
"""Generate dist/callout-symbols.json from tools/*.xc — the required-symbol registry.

Safety-net-reconciliation P3.3 (source-tag -> generate -> registry -> red-gate).

The problem this closes: the callout .so's required-symbol list was a HAND list.
The vehu image Dockerfile's `nm` gate checked only `crypto_verify` for weeks
(2026-07-10 incident, Phase-4) because that's all anyone wrote by hand, so a
seeded-but-symbol-incomplete std_crypto.so read as healthy. The .xc descriptor
is the callout's OWN function registry — the ground truth of what the .so must
export. This generator derives the required-symbol set FROM the .xc so no hand
list can drift from it:

  - scripts/seed-engine-callouts.sh reads this registry for its nm gate.
  - the engine-image build (P3.3-img, engine-image repo) reads the same registry.
  - `make check-callout-symbols` re-runs this generator and reds on drift, so a
    function added to a .xc without regenerating (and thus without the .so being
    rebuilt to export it) is caught.

A .xc line is `label: <ret-type> <c_symbol>(<sig>)`; the C symbol is the token
immediately before the first `(`. The first line is the `$STDLIB_LIB/<name>.so`
path (no `(`), which names the library and is skipped for symbols.

Usage:
    python3 tools/gen-callout-symbols.py                # writes dist/callout-symbols.json
    python3 tools/gen-callout-symbols.py --check        # regenerate to a temp buffer, diff committed
    python3 tools/gen-callout-symbols.py --self-test    # parse a synthetic fixture and check structure
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
XC_DIR = REPO / "tools"
OUT = REPO / "dist" / "callout-symbols.json"


def parse_xc(text: str) -> tuple[str, list[str]]:
    """Return (so_basename, sorted_unique_symbols) for one .xc descriptor.

    so_basename comes from the first line's `$STDLIB_LIB/<name>.so`; symbols are
    the identifier immediately before the first `(` on every entry line.
    """
    so = ""
    symbols: set[str] = set()
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if "(" not in line:
            # library-path line (or any non-entry line): capture the .so name.
            if line.endswith(".so"):
                so = os.path.basename(line)
            continue
        head = line.split("(", 1)[0]
        tok = head.split()[-1] if head.split() else ""
        if tok:
            symbols.add(tok)
    return so, sorted(symbols)


def build() -> dict:
    libraries = []
    for xc in sorted(XC_DIR.glob("*.xc")):
        so, symbols = parse_xc(xc.read_text())
        if not so or not symbols:
            continue
        libraries.append({"xc": xc.name, "so": so, "symbols": symbols})
    return {
        "generatedFrom": "tools/*.xc",
        "note": "Required exported C symbols per callout .so, derived from the .xc "
        "descriptor. Regenerate with `make callout-symbols`; drift-gated by "
        "`make check-callout-symbols`. Do not hand-edit.",
        "libraries": libraries,
    }


def render(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=False) + "\n"


def self_test() -> int:
    fixture = (
        "$STDLIB_LIB/std_demo.so\n"
        "sha256:     ydb_int_t demo_sha256(I:ydb_string_t*, O:ydb_string_t*[64])\n"
        "avail:      ydb_long_t demo_available()\n"
        "\n"
        "sign:       ydb_int_t demo_sign(I:ydb_string_t*, O:ydb_string_t*[512])\n"
    )
    so, syms = parse_xc(fixture)
    assert so == "std_demo.so", so
    assert syms == ["demo_available", "demo_sha256", "demo_sign"], syms
    # A path-only descriptor yields no symbols and is dropped.
    so2, syms2 = parse_xc("$STDLIB_LIB/empty.so\n")
    assert so2 == "empty.so" and syms2 == [], (so2, syms2)
    print("gen-callout-symbols self-test: ok")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="diff committed vs freshly generated; exit 1 on drift")
    ap.add_argument("--self-test", action="store_true", help="parse a synthetic fixture and check structure")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    rendered = render(build())
    if args.check:
        current = OUT.read_text() if OUT.exists() else ""
        if current != rendered:
            print(f"ERROR: {OUT.relative_to(REPO)} out of date — run 'make callout-symbols' and commit.", file=sys.stderr)
            return 1
        print("callout-symbols: clean")
        return 0

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(rendered)
    print(f"wrote {OUT.relative_to(REPO)} ({sum(len(l['symbols']) for l in build()['libraries'])} symbols across {len(build()['libraries'])} libraries)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
