$STDLIB_LIB/cs_random.so
random:             ydb_int_t cs_random(I:ydb_long_t, O:ydb_string_t*[1048576])
