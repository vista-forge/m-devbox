#!/usr/bin/env python3
"""Backfill YAML frontmatter onto every docs/modules/std<name>.md, and
regenerate the module catalogue table in docs/modules/index.md.

Spec: docs/archive/discoverability-and-tooling-plan.md § 3.3
Tracker: docs/archive/discoverability-tracker.md WA6
Ownership inversion: stdlib-doc-accuracy Phase 4 (F8 / RC-5).

Reads:
  - dist/stdlib-manifest.json  (synopsis, labels, errors, tag, phase per module)
  - docs/modules/index.md      (conformance corpora + cross-module dependency
                                map only — the sources for the `conformance`
                                and `see_also` frontmatter fields)

Writes:
  - docs/modules/std<name>.md  (prepends/replaces frontmatter)
  - docs/modules/index.md      (rewrites the generated module-catalogue table
                                between its sentinel markers, in place)

**F8 ownership inversion.** A module's `tag` (the release it first shipped in)
and `phase` (delivery wave) now live as `; doc: @tag` / `; doc: @phase` tags in
the routine header of src/STD*.m — parsed by tools/gen-manifest.py into the
manifest. This file DERIVES those frontmatter fields from the manifest, and the
index.md module table is a GENERATED projection of the manifest, not a hand
input. A new module appears in both automatically once its src header carries
the two tags; the old hand-written index table can no longer omit a module
(the earlier STDHARN/STDKV/STDNET empty-frontmatter hole).

Idempotent. If a file already starts with `---` (frontmatter already present),
the file is skipped — re-running won't trample manual edits. Use `--force`
to overwrite an existing frontmatter block. The index.md catalogue is always
rewritten in place from its markers (like a generated block).

Frontmatter schema:
  module:        STDXXX
  tag:           vX.Y.Z (the release this module first shipped in — @tag)
  phase:         "Phase 1" / "P4 wave" / ... (delivery wave — @phase)
  stable:        "stable" (default; modules in a tagged release are stable)
  since:         vX.Y.Z (same as tag)
  synopsis:      one-line summary from the routine header
  errors:        list of U-STDxxx-NAME codes raised (from manifest)
  labels:        list of public label names (from manifest)
  conformance:   list of conformance-corpus paths (from index.md table) or []
  see_also:      list of related modules (from index.md cross-deps section) or []

Usage:
  python3 tools/write-module-frontmatter.py            # idempotent backfill
  python3 tools/write-module-frontmatter.py --force    # overwrite existing FM
  python3 tools/write-module-frontmatter.py --dry-run  # print what would change
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
MODULES_DIR = REPO_ROOT / "docs" / "modules"
INDEX_PATH = MODULES_DIR / "index.md"
MANIFEST_PATH = REPO_ROOT / "dist" / "stdlib-manifest.json"

# Generated module-catalogue markers in index.md. The table between them is a
# projection of the manifest; edits are overwritten on the next `make frontmatter`
# and `frontmatter-check` (which diffs all of docs/modules/) red-gates drift.
CATALOGUE_BEGIN = (
    "<!-- BEGIN GENERATED: module-catalogue — managed by "
    "tools/write-module-frontmatter.py (`make frontmatter`); edits between "
    "these markers are overwritten. -->"
)
CATALOGUE_END = "<!-- END GENERATED: module-catalogue -->"

# Match a conformance-corpora row:
#   | `tests/conformance/b64/` | RFC-4648 §10 ... | `STDB64` |
CONFORMANCE_ROW_RE = re.compile(
    r"^\|\s*`(?P<path>tests/conformance/[^`]+)`\s*\|.*\|\s*`(?P<module>STD[A-Z0-9]+)`\s*\|"
)

# Match a cross-dep bullet:
#   - **STDLOG → STDDATE** — ...
#   - **STDLOG `FORMAT="json"` → STDJSON** — ...
#   - **STDCSPRNG → STDB64 / STDHEX / STDUUID** — ...
CROSS_DEP_RE = re.compile(
    r"^\s*-\s+\*\*(?P<src>STD[A-Z0-9]+)[^→]*→\s*(?P<rest>[^*]+)\*\*"
)


def parse_index() -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    """Walk docs/modules/index.md for the two hand-maintained maps that are
    NOT derivable from code — conformance corpora and cross-module deps.

    (tag/phase are no longer read here; they come from the manifest — F8.)

    Returns:
      conformance: {NAME: [path, ...]}     (only for modules with corpora)
      see_also:    {NAME: [other_module, ...]}  (from cross-deps section)
    """
    text = INDEX_PATH.read_text(encoding="utf-8")
    conformance: dict[str, list[str]] = {}
    see_also: dict[str, list[str]] = {}

    for raw_line in text.splitlines():
        line = raw_line.rstrip()

        # Conformance corpora row.
        m = CONFORMANCE_ROW_RE.match(line)
        if m:
            name = m.group("module")
            path = m.group("path")
            conformance.setdefault(name, []).append(path)
            continue

        # Cross-dependency bullet.
        m = CROSS_DEP_RE.match(line)
        if m:
            src = m.group("src")
            rest = m.group("rest")
            # `rest` may contain inline code or " / " separators — pull every STDxxx token.
            for tok in re.findall(r"\bSTD[A-Z0-9]+\b", rest):
                if tok != src and tok not in see_also.setdefault(src, []):
                    see_also.setdefault(src, []).append(tok)
                # Reverse edge — if A depends on B, B's "see also" should mention A too.
                if src not in see_also.setdefault(tok, []):
                    see_also.setdefault(tok, []).append(src)

    return conformance, see_also


def clean_synopsis(mod: dict) -> str:
    """The manifest synopsis, cleaned for a one-line field/cell."""
    synopsis = (mod.get("synopsis") or "").strip()
    if synopsis.startswith("m-stdlib — "):
        synopsis = synopsis[len("m-stdlib — "):]
    if synopsis.endswith("."):
        synopsis = synopsis[:-1]
    return synopsis


def render_frontmatter(name: str, manifest: dict, conformance: dict, see_also: dict) -> str:
    """Render the YAML frontmatter block for one module."""
    mod = manifest["modules"].get(name, {})

    tag = (mod.get("tag") or "").strip()
    phase = (mod.get("phase") or "").strip()
    synopsis = clean_synopsis(mod)

    labels = sorted(mod.get("labels", {}).keys())
    errors = sorted(mod.get("errors", []) or [])
    conf = conformance.get(name, [])
    sees = sorted(set(see_also.get(name, [])))

    lines = [
        "---",
        f"module: {name}",
        f"tag: {tag}",
        f"phase: {phase}",
        "stable: stable",
        f"since: {tag}",
        f"synopsis: {yaml_str(synopsis)}",
        f"labels: {yaml_list(labels)}",
        f"errors: {yaml_list(errors)}",
        f"conformance: {yaml_list(conf)}",
        f"see_also: {yaml_list(sees)}",
        "---",
        "",
        "",  # produces a blank line between frontmatter and prose
    ]
    return "\n".join(lines)


def yaml_str(s: str) -> str:
    """Render a string as a YAML scalar — quote if it would be ambiguous."""
    if not s:
        return '""'
    # Always single-quote to avoid surprises with colons, leading dashes, etc.
    # Escape any embedded single quotes by doubling them (YAML 1.1/1.2 rule).
    return "'" + s.replace("'", "''") + "'"


def yaml_list(items: list[str]) -> str:
    """Render a list as a YAML flow sequence."""
    if not items:
        return "[]"
    # Each item gets the same single-quote treatment as scalars.
    rendered = ", ".join(yaml_str(i) for i in items)
    return "[" + rendered + "]"


# ── index.md module-catalogue table (generated projection of the manifest) ──


def render_catalogue(manifest: dict) -> str:
    """Render the generated module-catalogue table for docs/modules/index.md.

    One row per module, sorted by module name — a pure projection of the
    manifest. Purpose = the module synopsis; Since/Phase = the @tag/@phase
    the src header carries. This replaces the old hand-written per-phase
    tables (which could — and did — silently omit shipped modules).
    """
    rows = []
    for name in sorted(manifest["modules"].keys()):
        mod = manifest["modules"][name]
        tag = (mod.get("tag") or "").strip()
        phase = (mod.get("phase") or "").strip()
        purpose = clean_synopsis(mod).replace("|", "\\|")
        since = f"`{tag}`" if tag else ""
        rows.append(
            f"| [`{name}`]({name.lower()}.md) | {since} | {phase} | {purpose} |"
        )

    lines = [
        CATALOGUE_BEGIN,
        "",
        f"One row per shipped module — a generated projection of "
        f"`dist/stdlib-manifest.json` ({len(rows)} modules). **Since** is the "
        f"release the module first shipped in (`; doc: @tag`); **Phase** its "
        f"delivery wave (`; doc: @phase`). Regenerate with `make frontmatter`; "
        f"`frontmatter-check` red-gates drift.",
        "",
        "| Module | Since | Phase | Purpose |",
        "|---|---|---|---|",
        *rows,
        "",
        CATALOGUE_END,
    ]
    return "\n".join(lines)


def splice_catalogue(page: str, block: str) -> str:
    """Return `page` with the catalogue `block` replaced between its markers."""
    if CATALOGUE_BEGIN not in page or CATALOGUE_END not in page:
        raise SystemExit(
            f"ERROR: {INDEX_PATH} is missing the catalogue markers "
            f"({CATALOGUE_BEGIN!r} / {CATALOGUE_END!r}). Add them once by hand."
        )
    pre, rest = page.split(CATALOGUE_BEGIN, 1)
    _, post = rest.split(CATALOGUE_END, 1)
    return pre + block + post


def write_catalogue(manifest: dict, dry_run: bool) -> str:
    """Rewrite the generated catalogue block in index.md. Returns an action word."""
    page = INDEX_PATH.read_text(encoding="utf-8")
    new_page = splice_catalogue(page, render_catalogue(manifest))
    if new_page == page:
        return "index: clean"
    if dry_run:
        return "index: would update"
    INDEX_PATH.write_text(new_page, encoding="utf-8")
    return "index: updated"


def write_one(path: Path, frontmatter: str, force: bool, dry_run: bool) -> str:
    """Apply (or simulate) the frontmatter prefix.

    Returns one of: "wrote", "force-replaced", "skip-has-fm", "skip-dry".
    """
    content = path.read_text(encoding="utf-8")
    has_fm = content.startswith("---\n")

    if has_fm and not force:
        return "skip-has-fm"

    if has_fm and force:
        # Strip the existing frontmatter block (everything up to the second `---\n`).
        end = content.find("\n---\n", 4)
        if end < 0:
            # Malformed — leave the file alone.
            return "skip-has-fm"
        content = content[end + len("\n---\n"):].lstrip("\n")
        new = frontmatter + content
        action = "force-replaced"
    else:
        new = frontmatter + content
        action = "wrote"

    if dry_run:
        return f"would {action}"

    path.write_text(new, encoding="utf-8")
    return action


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--force", action="store_true", help="Overwrite existing frontmatter blocks.")
    p.add_argument("--dry-run", action="store_true", help="Report what would change without writing.")
    args = p.parse_args(argv)

    if not MANIFEST_PATH.exists():
        print(f"manifest missing — run `make manifest` first ({MANIFEST_PATH})", file=sys.stderr)
        return 2

    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    conformance, see_also = parse_index()

    wrote = 0
    skipped = 0
    forced = 0

    for path in sorted(MODULES_DIR.glob("std*.md")):
        # Module name = "STD" + stem-uppercase-without-leading-std.
        name = "STD" + path.stem[3:].upper()
        if name not in manifest["modules"]:
            print(f"warning: {path.name} → {name} not in manifest; skipping", file=sys.stderr)
            continue

        fm = render_frontmatter(name, manifest, conformance, see_also)
        action = write_one(path, fm, args.force, args.dry_run)
        if action.startswith("skip"):
            skipped += 1
        elif "force" in action:
            forced += 1
        else:
            wrote += 1
        if action != "skip-has-fm":
            print(f"  {action}: {path.relative_to(REPO_ROOT)}")

    # The index.md module catalogue is a generated projection of the manifest.
    print(f"  {write_catalogue(manifest, args.dry_run)}")

    print(f"\nwrote: {wrote}, force-replaced: {forced}, skipped (already had FM): {skipped}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
