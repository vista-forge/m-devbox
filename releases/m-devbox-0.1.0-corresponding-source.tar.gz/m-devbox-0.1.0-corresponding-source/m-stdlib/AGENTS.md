---
# Machine-readable project descriptor.
name: m-stdlib
kind: [m-library, library]
status: active
languages: [mumps]

runtime:
  needs:
    - "yottadb (primary target)"
  optional:
    - "iris (portability target where reasonable)"
  excludes:
    - "gtm (deliberately out of scope)"

distribution:
  pypi: null
  github: vista-forge/m-stdlib

location: ~/projects/m-stdlib

exposes:
  m_routines: "see docs/modules/index.md"
  formats_produced: []

consumes:
  formats: []
  services: []

companions:
  - project: m-cli
    relation: "m-stdlib has architectural priority over m-cli — m-cli should consume m-stdlib utilities, not duplicate them"
  - project: m-standard
    relation: "m-stdlib obeys m-standard's reconciled language definitions; rules apply via m-cli lint"
  - project: tree-sitter-m
    relation: "syntax must parse cleanly under tree-sitter-m"
  - project: m-test-engine
    relation: "default Docker engine for `make test` and CI"

incompatibilities:
  - "GT.M not supported. AGPL-3.0 YottaDB and IRIS only."
  - "Ships pure-M source; no compiled artifacts. Caller links the routines via $ZRO."

docs:
  primary: README.md
  index: docs/README.md
  module_tracker: docs/module-tracker.md      # canonical "what's done / in flight / proposed" view
  changelog: docs/changelog.md                # release history (Keep-a-Changelog)
  discoveries: docs/discoveries.md            # discoveries register: in-project pivots + external toolchain findings
  todo: docs/TODO.md                          # resume-here pointer
  design: docs/design/                        # this repo's stable design notes / analyses
  proposals: docs/proposals/                  # live, in-progress proposals (decision-seeking)
  archive: docs/archive/                      # retired docs (completed plans/trackers, executed prompts)
---

# m-stdlib — Claude Project Context

Pure-M (and selectively `$ZF`-bound) runtime library filling the
highest-impact gaps in M's standard library. Sibling project to m-cli,
m-standard, and tree-sitter-m. YottaDB-first; IRIS-portable where
reasonable.

See [README.md](README.md) for the public-facing overview and
[`docs/guides/users-guide.md`](docs/guides/users-guide.md) for the
deep user reference.

## Tracking conventions

m-stdlib follows the **org-standard `docs/` layout** (normalized 2026-06-28):
live status sits at `docs/` root, this repo's own design notes in
[`docs/design/`](docs/design/), retired docs in [`docs/archive/`](docs/archive/).
The former `docs/tracking/` + `docs/plans/` + `docs/prompts/` folders were folded
in — see the docs-organization remediation plan in the central `docs` repo. The
repo root carries no change-tracking documents; CLAUDE.md / README.md are
pointers only.

The canonical live status files at `docs/` root:

| File | Purpose |
|------|---------|
| [`module-tracker.md`](docs/module-tracker.md) | Master per-module tracker — Summary table (Done checkbox + module rows) + closed-tickets archaeology (T1–T30) + Must-know section. Per-module deep history lives in [`docs/modules/<m>.md` § History](docs/modules/); the proposal pipeline lives in [`docs/proposals/future-modules-plan.md`](docs/proposals/future-modules-plan.md). |
| [`changelog.md`](docs/changelog.md) | Release history (Keep-a-Changelog format). One entry per tag. |
| [`discoveries.md`](docs/discoveries.md) | Discoveries register — every issue that wasn't anticipated in a locked plan but had to be addressed during implementation. Both internal m-stdlib pivots and external findings against m-cli / tree-sitter-m / YDB. |
| [`TODO.md`](docs/TODO.md) | "Resume here" pointer; thin index over the tracker. |

**Process rule.** Any commit that touches a module's source, tests,
or per-module doc MUST update the relevant row(s) in
[`docs/module-tracker.md`](docs/module-tracker.md) in the same commit. Commits
that ship a tagged release MUST add a corresponding entry to
[`docs/changelog.md`](docs/changelog.md).

Live, in-progress proposals live in [`docs/proposals/`](docs/proposals/) (the
house "propose before you build" loop; kickoff prompts ride with their proposal
in a `proposals/<effort>/` subfolder); stable design notes & analyses live in
[`docs/design/`](docs/design/). Completed proposals/plans/trackers — and their
prompts — are `git mv`'d to [`docs/archive/`](docs/archive/) when the effort lands.

## Engine charset & module tiers

**Run the engine in byte (M) mode** — `ydb_chset=M`. m-stdlib is byte-oriented:
binary routines (STDCSPRNG, STDB64, STDHEX, STDJSON's UTF-8 decode) assume *one
M character == one byte*. Under `ydb_chset=UTF-8`, byte values > 127 re-encode,
so binary output differs and STDCSPRNG fails. Tests are byte-exact via
`$ZCHAR`/`$ZASCII`.

**Core is dependency-free; 3 modules are optional.** Optional modules carry a
`; doc: @tier optional` header tag → `"tier": "optional"` in
`dist/stdlib-manifest.json`, and need compiled C call-out libraries:

| Optional | Call-out | Library |
|---|---|---|
| `STDCOMPRESS` | `$&stdcompress` | libz / libzstd |
| `STDCRYPTO`   | `$&stdcrypto`   | libcrypto |
| `STDHTTP`     | `$&stdhttp`     | HTTP backend |

`make test` runs the dependency-free core only; `make test-optional` runs the
call-out suites (STDCOMPRESSTST, STDCRYPTOTST, STDHTTPTST).

## Architectural rule

**m-stdlib has priority over m-cli.** When both projects need a utility,
implement it here first; m-cli imports.

## Setup

m-stdlib ships pure-M source; there is no compiled artifact to install.
The toolchain is the **Go `m`** (github.com/vista-forge/m-cli) — one
binary for fmt / lint / test / coverage — plus a YottaDB runtime (the
`m-test-engine` Docker container by default). The Python drift-gate
generators under `tools/` need only system `python3` (pure-stdlib).

```bash
# Build the Go `m` from m-cli (one static binary; no venv).
git clone https://github.com/vista-forge/m-cli ~/vista-forge/m-cli
cd ~/vista-forge/m-cli && go build -o dist/m .

# Engine: start m-test-engine for `make test` / `make coverage`.
# The engine image is built locally and archive-backed — vista-forge publishes
# no engine images (de-GitHub rules 5/6), so there is nothing to pull. If the
# image is missing, restore it:
#   zstd -dc ~/data/vista-forge/images/m-test-engine_0.3.0-local.tar.zst | docker load
docker run -d --name m-test-engine m-test-engine:0.3.0-local
```

The `M` Makefile variable defaults to `m` on `$PATH`; override it to point at
the build, e.g. `make check M=$HOME/vista-forge/m-cli/dist/m`. The engine
transport is `$(M_ENGINE_FLAGS)` (default `--engine ydb --docker m-test-engine
--chset m`); override for a host-YDB box, e.g.
`make test M_ENGINE_FLAGS='--engine ydb --chset m'`.

## Test

```bash
make test          # core suites via $(M_ENGINE_FLAGS) (default: --docker m-test-engine, byte mode)
make safe-test     # legacy vista-meta auto-recovery wrapper (not the Go-m path)
make coverage      # aggregate line coverage gated ≥85% (--lcov coverage.lcov)
make check         # fmt-check + lint + test (fast dev loop)
make ci            # check + coverage + ci-json (CI-shaped; writes *.json + coverage.lcov)
```

Engine-free checks (`fmt-check`, `lint`, `manifest-check`,
`skill-check`, `examples-check`) work on a fresh clone without an engine
configured. The living-examples programs are EXECUTED by `make examples-run`
(bare tier, both engines, gating) and `make examples-run-live` (the nightly
`vehu`/`foia` cadence + the §8 residue check); see the Living Executable
Examples proposal. The nightly cron also runs `make live-qc` — the live MSL
*suite* tier (`tools/run-live-qc.py`): the `tests/STD*TST.m` suites on vehu
(YDB) + foia (IRIS `VISTA` ns), writing `examples/LIVE-QC.md` with engine
identity + failing-assertion detail. Fail-soft; catches engine-version-sensitive
suite reds the bare CI tier can't (continuous-live-QC harness, QC-B).

## CI / toolchain (Go `m`)

The quality gate is `make check` (fmt-check + lint + test + the engine-free doc
battery) plus `make coverage`, run **offline** by the pre-push git hook and the
org forge-ci sweep. De-GitHub (2026-07-18) deleted this repo's
`.github/workflows/` — there is no cloud CI; the gate is the local `make` target,
portable to any git host. `make check` drives the Go `m` (built from m-cli) over
the Python drift gates + `m` fmt/lint (engine-free) and `make test` against the
`m-test-engine` container (`--docker`, the locally-proven path). The forge-ci
sweep also runs the shared `m arch check` waterline gate.

Two reconciliations from the legacy Python m-cli are worth knowing:

- **Lint severity.** The Go `m` has no `--error-on=<severity>` flag (its
  `--check` fails on *any* finding). The house gate — zero **error**-severity
  findings, style/warning advisory — lives in `scripts/m-lint-gate.sh`
  (reads `m lint -o json`). `make lint` calls it.
- **Aggregate coverage.** `m coverage --min-percent` gates **aggregate** line
  coverage across the measured set, not per-module. m-stdlib already treated
  the few sub-85% modules (STDFS, STDHARN, …) as documented exceptions, so the
  aggregate gate (currently ~93%) is the faithful continuation. The optional
  modules (STDCOMPRESS/STDCRYPTO/STDHTTP — no core suites) are excluded from
  the measured set (`CORE_SRC`) so they don't drag the aggregate down.

## Build / generate

The repo commits its own generated artefacts under `dist/` — every
change to `src/STD*.m` or to a `; doc:` block must be followed by a
regenerate-and-commit, gated by CI.

```bash
make manifest        # → dist/stdlib-manifest.json (now incl. the `seams` block) + dist/errors.json
make skill           # → dist/skill/{SKILL.md,manifest-index.md,patterns.md,error-codes.md}
make examples        # → examples/programs/<MOD>EX.m + examples/index.md (living examples)
make frontmatter     # re-syncs YAML frontmatter on docs/modules/std*.md
make seams           # → dist/seam-snapshot.json   (the @seam contract projection)
make icr             # → dist/icr-registry.json     (the @icr / DBIA registry)
make namespaces      # → dist/namespace-registry.json (declared vs discovered prefixes)
```

The four VSL T0b.3 drift gates (`check-seams` / `check-icr` / `check-citations`
/ `check-namespaces`) run engine-free in CI alongside `check-manifest`. They are
green on empty/clean registries (m-stdlib declares no `@seam`/`@icr` tags yet)
and red on a planted violation. `check-citations` needs the vdocs corpus
(`~/data/vdocs`) and SKIPS green when it is absent (cadence gate, §5.5).

The root `repo.meta.json` is hand-edited — not regenerated — and is
covered by `make check-manifest` (see below). It lives at the repo ROOT
(the standardized "one meta artifact, one location"); `m arch check`
reads it root-first and validates its shape.

## Verify

These commands match `repo.meta.json`'s `verification_commands`
and are what an agent should run to confirm a change in this repo:

```bash
make manifest          # regenerate dist/
make test              # run the suite
make check-manifest    # drift gate: dist/ matches src/ AND repo.meta.json is committed
```

## Guardrails

- **Do not hand-edit `dist/stdlib-manifest.json`, `dist/errors.json`,
  `dist/skill/`, `examples/programs/*EX.m`, `examples/index.md`,
  `dist/seam-snapshot.json`, `dist/icr-registry.json`, or
  `dist/namespace-registry.json`.** They are regenerated from `src/STD*.m`
  doc-comments (+ `repo.meta.json` namespaces) by
  `make manifest`/`skill`/`examples`/`seams`/`icr`/`namespaces`. CI's drift
  gates will reject any direct edit. (`examples/REPORT.md` and
  `examples/LIVE-QC.md` are also generated — by `make examples-run-live` /
  `make live-qc`, the nightly cadence — but are run snapshots, not drift-gated.)
- **The root `repo.meta.json` is the hand-edited meta artifact** (the
  rest of `dist/` is generated). Bump `verified_on` to today's date
  whenever you touch it; `make check-manifest` asserts it is committed
  and clean.
- **Do not introduce GT.M support.** AGPL-3.0 YottaDB and IRIS only —
  GT.M is deliberately out of scope.
- **Do not duplicate utilities into m-cli.** m-stdlib has architectural
  priority; m-cli consumes from here.
- **Trackers update in the same commit.** Any commit that touches a
  module's source, tests, or per-module doc must update the relevant
  row in `docs/module-tracker.md` (see "Tracking conventions" above).

## Layout conventions

`docs/` holds **only** human-readable prose. Technical artifacts live
elsewhere — m-stdlib's top-level layout:

| Path | Contents |
|---|---|
| `repo.meta.json` (root) | Hand-edited repo meta (id/layer/language/verification_commands); `m arch check` reads it root-first |
| `docs/` | Org-standard layout — live trackers at root (`module-tracker.md` / `changelog.md` / `discoveries.md` / `TODO.md`), per-module API reference (`modules/`, generated), `design/` (stable notes/analyses), `proposals/` (live proposals), `guides/`, `memory/` (auto-memory), `archive/` (retired) |
| `dist/` | Generated drift-gated artifacts — `stdlib-manifest.json` / `errors.json` / `skill/` |
| `examples/` | Living examples — generated `programs/<MOD>EX.m` + `index.md` + run reports `REPORT.md` (examples tier) / `LIVE-QC.md` (suite tier), sample `data/`, hand demos (e.g. `stdargs-demo.m`) |
| `templates/` | Project scaffolds (e.g. `m-vista-test-suite/`) |
| `scripts/` | Shell helpers |
| `src/` | M (`.m`) source |
| `tests/` | Test suites — hand-written `STD*TST.m` |
| `tools/` | Python generator scripts (gen-manifest, gen-skill, gen-examples, run-examples, write-module-frontmatter) |

Enforced by `make check-docs-prose` (CI gate; `docs/readme-gen.toml` is the
one allowed non-prose file — org truth-gate config). Org-level rule:
[`CONVENTIONS.md` § Folder layout](https://github.com/vista-forge/.github/blob/main/CONVENTIONS.md#folder-layout-vista-forge-house-standard).
