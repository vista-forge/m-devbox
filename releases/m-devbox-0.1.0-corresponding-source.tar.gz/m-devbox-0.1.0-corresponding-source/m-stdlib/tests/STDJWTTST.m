STDJWTTST ; m-stdlib — STDJWT (RFC 7519 / 9068 JWT validation) suite.
 ; HS256 (HMAC-SHA-256) is the symmetric leg: sign (dev/test only), verify the
 ; signature, and validate the registered claims (exp/nbf/iss/aud) per RFC
 ; 7519 §4.1 + the RFC 9068 resource-server checks. RS256/ES256 (the asymmetric
 ; leg, D1) verify via $$verifySig^STDCRYPTO against the caller's SPKI public key.
 ;
 ; The ASYMMETRIC leg owns the algorithm-confusion defense (proposal §11 / N-1)
 ; that STDCRYPTO is alg-agnostic-by-design and cannot provide: reject alg:"none",
 ; enforce a CALLER-supplied alg allowlist (the token never widens it), and pin
 ; alg-family to key-type (an HMAC alg is never verifiable when an asymmetric key
 ; is expected — the RS->HS forgery). Those defenses are RED-tested below.
 ; The RS256/ES256 KAT vectors are the RFC 7515 App A.2/A.3 fixtures shared from
 ; STDCRYPTOTST ($$vRs256*/$$vEs256* — one source of truth, decoded via STDHEX).
 ;
 ; Engine-neutral but signature-bound: STDJWT consumes STDCRYPTO (HMAC + verify),
 ; an OPTIONAL callout module. This suite soft-skips loudly when the std_crypto
 ; callout is unavailable (a core-only engine) and runs under `make test-
 ; optional` where the lib is deployed (same posture as STDCRYPTOTST).
 ;
 ; The clock is INJECTED via opts("now") (epoch seconds) so exp/nbf tests are
 ; deterministic and never flake on wall-clock — the real default is
 ; $$epoch^STDDATE().
 new pass,fail
 do start^STDASSERT(.pass,.fail)
 ;
 if '$$available^STDCRYPTO do report^STDASSERT(pass,fail) quit
 ;
 do tRoundTrip(.pass,.fail)
 do tWrongKey(.pass,.fail)
 do tTampered(.pass,.fail)
 do tExpired(.pass,.fail)
 do tLeeway(.pass,.fail)
 do tNotYetValid(.pass,.fail)
 do tIssuerOk(.pass,.fail)
 do tIssuerMismatch(.pass,.fail)
 do tAudienceString(.pass,.fail)
 do tAudienceArray(.pass,.fail)
 do tAudienceMismatch(.pass,.fail)
 do tMalformed(.pass,.fail)
 do tDefaultAllowlistRejectsAsym(.pass,.fail)
 do tDecodeNoVerify(.pass,.fail)
 do tClaim(.pass,.fail)
 ;
 ; --- asymmetric leg (D1): RS256/ES256 verify + the alg-confusion defense ---
 do tRs256Kat(.pass,.fail)
 do tEs256Kat(.pass,.fail)
 do tAlgNoneRejected(.pass,.fail)
 do tAlgNoneEvenIfAllowlisted(.pass,.fail)
 do tAlgNotInAllowlist(.pass,.fail)
 do tRsHsKeyConfusion(.pass,.fail)
 do tMixedFamilyAllowlist(.pass,.fail)
 do tAsymTamperedPayload(.pass,.fail)
 do tAsymGarbageKey(.pass,.fail)
 do tAsymWrongKey(.pass,.fail)
 do tAlgSingleOptStillWorks(.pass,.fail)
 do tEdDsaEngineSplit(.pass,.fail)
 ;
 do report^STDASSERT(pass,fail)
 quit
 ;
mk(key,exp,nbf,iss,aud,sub) ; (helper) build an HS256 token with the given claims.
 new CL
 set CL="o"
 set CL("iss")="s:"_$get(iss,"https://sts.example/issuer")
 set CL("sub")="s:"_$get(sub,"secid-12345")
 set:$get(exp)'="" CL("exp")="n:"_exp
 set:$get(nbf)'="" CL("nbf")="n:"_nbf
 if $get(aud)'="" set CL("aud")="s:"_aud
 quit $$sign^STDJWT(.CL,key)
 ;
tRoundTrip(pass,fail) ;@TEST "sign then verify with the same key -> 1, claims populated"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000)
 set opts("now")=1000000000
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"a well-formed, in-date, correctly-signed token verifies")
 do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON($get(OUT("sub"))),"secid-12345","the sub claim is exposed to the caller")
 do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON($get(OUT("iss"))),"https://sts.example/issuer","the iss claim is exposed")
 quit
 ;
tWrongKey(pass,fail) ;@TEST "a token signed with one key fails verification under another -> 0 (bad signature)"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000)
 set opts("now")=1000000000
 set ok=$$verify^STDJWT(tok,"WRONGkey",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a wrong-key signature is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["signature","lastError names the signature failure")
 quit
 ;
tTampered(pass,fail) ;@TEST "flipping a byte of the payload segment breaks the signature -> 0"
 new tok,bad,OUT,opts,ok,p2,c
 set tok=$$mk("s3cret",2000000000)
 ; mutate one char in the payload (2nd) segment
 set p2=$piece(tok,".",2),c=$extract(p2,1)
 set $extract(p2,1)=$select(c="A":"B",1:"A")
 set bad=$piece(tok,".",1)_"."_p2_"."_$piece(tok,".",3)
 set opts("now")=1000000000
 set ok=$$verify^STDJWT(bad,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a tampered payload no longer matches the signature")
 quit
 ;
tExpired(pass,fail) ;@TEST "now past exp -> 0 (expired)"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",1000000000)
 set opts("now")=1000000100
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"an expired token is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["expired","lastError names the expiry")
 quit
 ;
tLeeway(pass,fail) ;@TEST "an exp just past but within opts(""leeway"") still verifies"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",1000000000)
 set opts("now")=1000000030,opts("leeway")=60
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"clock-skew leeway keeps a barely-expired token valid")
 quit
 ;
tNotYetValid(pass,fail) ;@TEST "now before nbf -> 0 (not yet valid)"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000,1500000000)
 set opts("now")=1000000000
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a not-yet-valid (nbf in the future) token is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["not yet valid","lastError names the nbf failure")
 quit
 ;
tIssuerOk(pass,fail) ;@TEST "a matching expected issuer passes"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000,,"https://good.example")
 set opts("now")=1000000000,opts("iss")="https://good.example"
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"the configured issuer matches the token iss")
 quit
 ;
tIssuerMismatch(pass,fail) ;@TEST "an unexpected issuer -> 0"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000,,"https://evil.example")
 set opts("now")=1000000000,opts("iss")="https://good.example"
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a token from an untrusted issuer is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["issuer","lastError names the issuer failure")
 quit
 ;
tAudienceString(pass,fail) ;@TEST "a string aud matching opts(""aud"") passes"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000,,,"vweb-fhir")
 set opts("now")=1000000000,opts("aud")="vweb-fhir"
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"a scalar aud claim matching the expected audience passes")
 quit
 ;
tAudienceArray(pass,fail) ;@TEST "an array aud containing opts(""aud"") passes (RFC 7519 4.1.3)"
 new CL,tok,OUT,opts,ok
 set CL="o",CL("exp")="n:2000000000",CL("sub")="s:u1"
 set CL("aud")="a",CL("aud",1)="s:other",CL("aud",2)="s:vweb-fhir"
 set tok=$$sign^STDJWT(.CL,"s3cret")
 set opts("now")=1000000000,opts("aud")="vweb-fhir"
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"an array audience containing the expected value passes")
 quit
 ;
tAudienceMismatch(pass,fail) ;@TEST "an aud not covering opts(""aud"") -> 0"
 new tok,OUT,opts,ok
 set tok=$$mk("s3cret",2000000000,,,"some-other-api")
 set opts("now")=1000000000,opts("aud")="vweb-fhir"
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a token for a different audience is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["audience","lastError names the audience failure")
 quit
 ;
tMalformed(pass,fail) ;@TEST "a token without three segments -> 0 (malformed)"
 new OUT,opts,ok
 set opts("now")=1000000000
 set ok=$$verify^STDJWT("not.a.valid.jwt.token","s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a non-3-segment token is rejected")
 set ok=$$verify^STDJWT("onlyonesegment","s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a single-segment string is rejected")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["malformed","lastError names the malformed token")
 quit
 ;
tDefaultAllowlistRejectsAsym(pass,fail) ;@TEST "with no opts alg/algs the allowlist defaults to HS256, so an RS256 token -> 0"
 new HD,si,sig,tok,OUT,opts,ok
 ; hand-craft a token whose header advertises RS256; the default allowlist is HS256-only.
 set HD="{""alg"":""RS256"",""typ"":""JWT""}"
 set si=$$urlencode^STDB64(HD)_"."_$$urlencode^STDB64("{""sub"":""u1"",""exp"":2000000000}")
 set sig=$$urlencode^STDB64($$hmacSha256Bytes^STDCRYPTO("s3cret",si))
 set tok=si_"."_sig
 set opts("now")=1000000000
 set ok=$$verify^STDJWT(tok,"s3cret",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a token whose alg is outside the (default HS256) allowlist is rejected, not silently accepted")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["allowlist","lastError names the allowlist rejection")
 quit
 ;
tDecodeNoVerify(pass,fail) ;@TEST "$$decode exposes header+claims without checking the signature"
 new tok,HD,CL,ok
 set tok=$$mk("s3cret",2000000000)
 set ok=$$decode^STDJWT(tok,.HD,.CL)
 do true^STDASSERT(.pass,.fail,ok,"a structurally valid token decodes")
 do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON($get(HD("alg"))),"HS256","the header alg is decoded")
 do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON($get(CL("sub"))),"secid-12345","the sub claim is decoded without a key")
 quit
 ;
tClaim(pass,fail) ;@TEST "$$claim is a one-shot unverified single-claim read"
 new tok
 set tok=$$mk("s3cret",2000000000,,"https://iss.example","aud9","secid-777")
 do eq^STDASSERT(.pass,.fail,$$claim^STDJWT(tok,"sub"),"secid-777","$$claim returns the sub value")
 do eq^STDASSERT(.pass,.fail,$$claim^STDJWT(tok,"iss"),"https://iss.example","$$claim returns the iss value")
 quit
 ;
 ; ---------- asymmetric leg (D1): RS256/ES256 + alg-confusion defense ----------
 ; The App-A tokens are (signing-input)"."(base64url raw sig): the signing input
 ; IS b64url(header)"."b64url(payload) (STDCRYPTOTST vRs256Msg/vEs256Msg, hex),
 ; and the raw signature is the STDHEX-decoded vRs256Sig/vEs256Sig re-encoded as
 ; base64url — exactly what $$verify base64url-decodes back to raw bytes. The
 ; RFC A.2/A.3 payload carries exp=1300819380, so the clock is pinned before it.
 ;
asymTok(msgHex,sigHex) ; (helper) assemble an App-A JWS from its hex signing-input + hex raw sig.
 quit $$decode^STDHEX(msgHex)_"."_$$urlencode^STDB64($$decode^STDHEX(sigHex))
 ;
tRs256Kat(pass,fail) ;@TEST "an RFC 7515 App A.2 RS256 token verifies under its SPKI public key + an RS256 allowlist"
 new tok,key,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="RS256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"the RFC A.2 RS256 KAT verifies with the caller's public key")
 do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON($get(OUT("iss"))),"joe","the iss claim is exposed to the caller")
 quit
 ;
tEs256Kat(pass,fail) ;@TEST "an RFC 7515 App A.3 ES256 token verifies (JWT R||S passed straight through)"
 new tok,key,OUT,opts,ok
 set tok=$$asymTok($$vEs256Msg^STDCRYPTOTST(),$$vEs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vEs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="ES256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"the RFC A.3 ES256 KAT verifies (STDCRYPTO does R||S->DER internally)")
 quit
 ;
tAlgNoneRejected(pass,fail) ;@TEST "alg:none is rejected unconditionally (no signature-skipping path)"
 new HD,tok,OUT,opts,ok
 set HD="{""alg"":""none"",""typ"":""JWT""}"
 set tok=$$urlencode^STDB64(HD)_"."_$$urlencode^STDB64("{""sub"":""u1""}")_"."
 set opts("now")=1000000000,opts("algs")="HS256,RS256"
 set ok=$$verify^STDJWT(tok,"anykey",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a none-alg token never verifies")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["none","lastError names the none rejection")
 quit
 ;
tAlgNoneEvenIfAllowlisted(pass,fail) ;@TEST "alg:none is rejected even if a caller foolishly allowlists ""none"""
 new HD,tok,OUT,opts,ok
 set HD="{""alg"":""None""}" ; also proves the reject is case-insensitive
 set tok=$$urlencode^STDB64(HD)_"."_$$urlencode^STDB64("{""sub"":""u1""}")_"."
 set opts("now")=1000000000,opts("algs")="none,None,NONE"
 set ok=$$verify^STDJWT(tok,"anykey",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"'none' can never be whitelisted into acceptance")
 quit
 ;
tAlgNotInAllowlist(pass,fail) ;@TEST "a valid RS256 token is rejected when the caller allowlist is ES256-only (token can't widen it)"
 new tok,key,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="ES256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a real RS256 signature is rejected because RS256 is not in the caller allowlist")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["allowlist","lastError names the allowlist rejection")
 quit
 ;
tRsHsKeyConfusion(pass,fail) ;@TEST "an HS256 token forged with the RSA PUBLIC key as HMAC secret -> 0 when RS256 is expected"
 new key,HD,si,sig,tok,OUT,opts,ok
 ; The classic RS->HS attack: the attacker knows the public key and HMAC-signs an
 ; HS256 token with it. The caller expects RS256 and passes the public key. The
 ; allowlist (RS256) never contains HS256, so the HMAC path is unreachable -> 0.
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set HD="{""alg"":""HS256"",""typ"":""JWT""}"
 set si=$$urlencode^STDB64(HD)_"."_$$urlencode^STDB64("{""sub"":""attacker"",""exp"":2000000000}")
 set sig=$$urlencode^STDB64($$hmacSha256Bytes^STDCRYPTO(key,si))
 set tok=si_"."_sig
 set opts("now")=1000000000,opts("algs")="RS256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"the RS->HS key-confusion forgery is structurally closed (HS256 not in the RS256 allowlist)")
 quit
 ;
tMixedFamilyAllowlist(pass,fail) ;@TEST "an allowlist mixing an HMAC alg with an asymmetric alg is a config error -> 0"
 new tok,key,OUT,opts,ok
 ; One verify call has ONE key param, so one family. Mixing HS* with RS*/ES* in a
 ; single allowlist reopens the RS->HS door and is refused fail-closed.
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="HS256,RS256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a family-mixing allowlist is refused even with an otherwise-valid RS256 token")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["family","lastError names the mixed-family config error")
 quit
 ;
tAsymTamperedPayload(pass,fail) ;@TEST "flipping a byte of an RS256 token's payload breaks the signature -> 0"
 new tok,bad,key,p2,c,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set p2=$piece(tok,".",2),c=$extract(p2,1)
 set $extract(p2,1)=$select(c="e":"f",1:"e")
 set bad=$piece(tok,".",1)_"."_p2_"."_$piece(tok,".",3)
 set opts("now")=1300000000,opts("algs")="RS256"
 set ok=$$verify^STDJWT(bad,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a tampered payload no longer matches the RS256 signature")
 quit
 ;
tAsymGarbageKey(pass,fail) ;@TEST "an unparseable public key is a clean 0 + lastError, never a raise out of $$verify"
 new tok,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="RS256"
 set ok=$$verify^STDJWT(tok,"not-a-real-spki-key",.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"a garbage key (STDCRYPTO BADKEY raise) is mapped to verify=0, not a trap")
 do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()'="","lastError is set for the key failure")
 quit
 ;
tAsymWrongKey(pass,fail) ;@TEST "an RS256 token verified under the (wrong) ES256 public key -> 0"
 new tok,key,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vEs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("algs")="RS256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"an RS256 signature does not verify under an EC public key")
 quit
 ;
tAlgSingleOptStillWorks(pass,fail) ;@TEST "the legacy single opts(""alg"") seeds a one-element allowlist"
 new tok,key,OUT,opts,ok
 set tok=$$asymTok($$vRs256Msg^STDCRYPTOTST(),$$vRs256Sig^STDCRYPTOTST())
 set key=$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST())
 set opts("now")=1300000000,opts("alg")="RS256"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do true^STDASSERT(.pass,.fail,ok,"opts(""alg"")=RS256 admits an RS256 token (allowlist = {RS256})")
 quit
 ;
tEdDsaEngineSplit(pass,fail) ;@TEST "EdDSA inherits STDCRYPTO's YDB-only support — a visible engine split, never a silent pass"
 ; No JSON-payload EdDSA KAT exists (RFC 8037 A.1 signs a non-JSON string, and
 ; STDCRYPTO is verify-only so we cannot mint one), so this asserts the negative
 ; contract on both arms: the token never verifies (0), and IRIS surfaces the
 ; YDB-only inheritance as a clean U-STDCRYPTO-BADALG (same discipline as
 ; STDCRYPTOTST's edDsaSkip) while YDB reports a plain signature mismatch.
 new HD,si,tok,key,OUT,opts,ok
 set HD="{""alg"":""EdDSA"",""typ"":""JWT""}"
 set si=$$urlencode^STDB64(HD)_"."_$$urlencode^STDB64("{""sub"":""u1""}")
 set tok=si_"."_$$urlencode^STDB64($$decode^STDHEX($$vEdSig^STDCRYPTOTST()))
 set key=$$decode^STDHEX($$vEdPubDer^STDCRYPTOTST())
 set opts("now")=1000000000,opts("algs")="EdDSA"
 set ok=$$verify^STDJWT(tok,key,.OUT,.opts)
 do eq^STDASSERT(.pass,.fail,ok,0,"an EdDSA token never verifies here (bad sig on YDB; BADALG on IRIS)")
 if $zversion["IRIS" do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["BADALG","IRIS: EdDSA is YDB-only, surfaced as a clean U-STDCRYPTO-BADALG -> 0")
 if '($zversion["IRIS") do true^STDASSERT(.pass,.fail,$$lastError^STDJWT()["signature","YDB: EdDSA verifies the bytes, so a non-matching signature is a plain mismatch")
 quit
