STDKVTST ; m-stdlib — STDKV (keyed record-store seam) test suite.
        ; Exercises the portable record-store reference implementation on a bare
        ; engine (global-backed, no VistA): $$set/$$get/$$exists/$$kill over a
        ; (collection, key, field) address. This is the MSL S1 storage seam that
        ; v-stdlib's VSLFS binds to FileMan DBS above the waterline.
        ;
        ; All four verbs are extrinsic functions; callers use $$ (a $$-style
        ; `quit <value>` label cannot be invoked with `do`). Side-effecting
        ; verbs ($$set/$$kill) return 1; the tests consume the return.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tSetGetRoundtrip(.pass,.fail)
        do tGetDefaultWhenUnset(.pass,.fail)
        do tExistsLifecycle(.pass,.fail)
        do tKillRemovesRecord(.pass,.fail)
        do tMultiFieldIndependent(.pass,.fail)
        do tByteFidelity(.pass,.fail)
        do tSetReturnsTrue(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
tSetGetRoundtrip(pass,fail)     ;@TEST "$$set then $$get returns the stored value byte-identical"
        new c,x
        set c="STDKVTST.rt"
        set x=$$kill^STDKV(c,1)
        set x=$$set^STDKV(c,1,".01","Hello, world")
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".01","MISS"),"Hello, world","stored value reads back")
        set x=$$kill^STDKV(c,1)
        quit
        ;
tGetDefaultWhenUnset(pass,fail) ;@TEST "$$get returns the default for an absent field/record"
        new c,x
        set c="STDKVTST.def"
        set x=$$kill^STDKV(c,1)
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".01","fallback"),"fallback","absent record yields default")
        set x=$$set^STDKV(c,1,".01","x")
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".02","fallback"),"fallback","absent field yields default")
        set x=$$kill^STDKV(c,1)
        quit
        ;
tExistsLifecycle(pass,fail)     ;@TEST "$$exists is false before a set, true after"
        new c,x
        set c="STDKVTST.ex"
        set x=$$kill^STDKV(c,7)
        do eq^STDASSERT(.pass,.fail,$$exists^STDKV(c,7),0,"record absent before set")
        set x=$$set^STDKV(c,7,".01","present")
        do eq^STDASSERT(.pass,.fail,$$exists^STDKV(c,7),1,"record present after set")
        set x=$$kill^STDKV(c,7)
        quit
        ;
tKillRemovesRecord(pass,fail)   ;@TEST "$$kill removes the record so $$exists is false and $$get returns default"
        new c,x
        set c="STDKVTST.kill"
        set x=$$set^STDKV(c,3,".01","doomed")
        do eq^STDASSERT(.pass,.fail,$$exists^STDKV(c,3),1,"record exists pre-kill")
        set x=$$kill^STDKV(c,3)
        do eq^STDASSERT(.pass,.fail,$$exists^STDKV(c,3),0,"record gone post-kill")
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,3,".01","gone"),"gone","field gone post-kill")
        quit
        ;
tMultiFieldIndependent(pass,fail)       ;@TEST "fields on one record store and read independently"
        new c,x
        set c="STDKVTST.mf"
        set x=$$kill^STDKV(c,1)
        set x=$$set^STDKV(c,1,".01","name")
        set x=$$set^STDKV(c,1,".02","value")
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".01","MISS"),"name","field .01 intact")
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".02","MISS"),"value","field .02 intact")
        set x=$$kill^STDKV(c,1)
        quit
        ;
tByteFidelity(pass,fail)        ;@TEST "values with control and high bytes round-trip byte-exact"
        new c,x,v
        set c="STDKVTST.bytes"
        set v=$char(0)_"a"_$char(9)_$char(200)_$char(255)
        set x=$$kill^STDKV(c,1)
        set x=$$set^STDKV(c,1,".01",v)
        do eq^STDASSERT(.pass,.fail,$$get^STDKV(c,1,".01",""),v,"byte-exact round-trip")
        set x=$$kill^STDKV(c,1)
        quit
        ;
tSetReturnsTrue(pass,fail)      ;@TEST "$$set returns 1 on success"
        new c,x
        set c="STDKVTST.ret"
        set x=$$kill^STDKV(c,1)
        do eq^STDASSERT(.pass,.fail,$$set^STDKV(c,1,".01","ok"),1,"$$set returns 1")
        set x=$$kill^STDKV(c,1)
        quit
