STDCRYPTOTST    ; Test suite for STDCRYPTO (v0.3.x — Phase 3, $ZF → libcrypto).
        ; m-lint: disable-file=M-MOD-020
        ; Test labels delegate counters by-ref to STDASSERT helpers; m-cli's
        ; by-ref analyzer can't see writes-via-callee.
        ;
        ; Vectors:
        ;   SHA-256 / SHA-384 / SHA-512 — RFC 6234 §8.5 / FIPS 180-4 examples.
        ;   HMAC-SHA-256 / HMAC-SHA-384 / HMAC-SHA-512 — RFC 4231 test cases.
        ;
        ; Engine prerequisite: the std_crypto callout package must be loaded
        ; (env var ydb_xc_std_crypto=/path/to/std_crypto.xc, .so compiled via
        ; tools/build-callouts.sh). When the package is not loaded, every test
        ; here fails — the runner reports the gap loudly. See
        ; docs/modules/stdcrypto.md for the deployment runbook.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tAvailableReturnsBool(.pass,.fail)
        do tSha256Empty(.pass,.fail)
        do tSha256Abc(.pass,.fail)
        do tSha256LongerInput(.pass,.fail)
        do tSha256BytesIs32(.pass,.fail)
        do tSha384Empty(.pass,.fail)
        do tSha384Abc(.pass,.fail)
        do tSha384BytesIs48(.pass,.fail)
        do tSha512Empty(.pass,.fail)
        do tSha512Abc(.pass,.fail)
        do tSha512BytesIs64(.pass,.fail)
        do tHmacSha256Rfc4231Case1(.pass,.fail)
        do tHmacSha256Rfc4231Case2(.pass,.fail)
        do tHmacSha256BytesIs32(.pass,.fail)
        do tHmacSha384Rfc4231Case1(.pass,.fail)
        do tHmacSha384BytesIs48(.pass,.fail)
        do tHmacSha512Rfc4231Case1(.pass,.fail)
        do tHmacSha512BytesIs64(.pass,.fail)
        do tHmacKeyLongerThanBlockOk(.pass,.fail)
        do tHmacEmptyKeyOk(.pass,.fail)
        do tHexLowercaseAlphabet(.pass,.fail)
        do tBinaryInputRoundTrips(.pass,.fail)
        ;
        ; ---- asymmetric signature verify (RS*) — T32 ----
        do tVerifyAvailableIsOne(.pass,.fail)
        do tVerifyRs256RfcKat(.pass,.fail)
        do tVerifyRs256PemKey(.pass,.fail)
        do tVerifyRs384Kat(.pass,.fail)
        do tVerifyRs512Kat(.pass,.fail)
        do tVerifyRs256WrapperOk(.pass,.fail)
        do tVerifyWrongKeyIsZero(.pass,.fail)
        do tVerifyBitFlipIsZero(.pass,.fail)
        do tVerifyZeroSigIsZero(.pass,.fail)
        do tVerifyTruncSigIsZero(.pass,.fail)
        do tVerifyUnknownAlgRaises(.pass,.fail)
        do tVerifyEmptyKeyRaises(.pass,.fail)
        do tVerifyBadKeyRaises(.pass,.fail)
        do tVerifyErrorCodesDistinct(.pass,.fail)
        ;
        ; ---- asymmetric signature verify (ES*/EdDSA/PS*) — T32 Phase 2 ----
        do tVerifyEs256RfcKat(.pass,.fail)
        do tVerifyEs384Kat(.pass,.fail)
        do tVerifyEs521Kat(.pass,.fail)
        do tVerifyEs256WrapperOk(.pass,.fail)
        do tVerifyEs256BitFlipIsZero(.pass,.fail)
        do tVerifyEs256WrongCurveIsZero(.pass,.fail)
        do tVerifyEsZeroSigIsZero(.pass,.fail)
        do tVerifyEsTruncSigIsZero(.pass,.fail)
        do tVerifyEsOddSigIsZero(.pass,.fail)
        do tVerifyPs256Kat(.pass,.fail)
        do tVerifyPs384Kat(.pass,.fail)
        do tVerifyPs512Kat(.pass,.fail)
        do tVerifyPs256WrapperOk(.pass,.fail)
        do tVerifyPs256BitFlipIsZero(.pass,.fail)
        do tVerifyEdDSAKat(.pass,.fail)
        do tVerifyEdDSABitFlip(.pass,.fail)
        ;
        ; ---- asymmetric signing (signRs256/signEs256/signSig) ----
        do tSignRs256ExactKat(.pass,.fail)
        do tSignRs256Verifies(.pass,.fail)
        do tSignEs256RoundTrip(.pass,.fail)
        do tSignEs256SigLen64(.pass,.fail)
        do tSignSigGenericEs256(.pass,.fail)
        do tSignEmptyKeyRaises(.pass,.fail)
        do tSignUnknownAlgRaises(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
tAvailableReturnsBool(pass,fail)        ;@TEST "available() returns 0 or 1, never raises"
        new ok
        set ok=$$available^STDCRYPTO()
        do true^STDASSERT(.pass,.fail,(ok=0)!(ok=1),"available is 0 or 1")
        quit
        ;
tSha256Empty(pass,fail) ;@TEST "sha256('') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha256^STDCRYPTO(""),"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","SHA-256 of empty string")
        quit
        ;
tSha256Abc(pass,fail)   ;@TEST "sha256('abc') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha256^STDCRYPTO("abc"),"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA-256 of 'abc'")
        quit
        ;
tSha256LongerInput(pass,fail)   ;@TEST "sha256 of 56-char message matches FIPS 180-4 vector"
        new msg
        set msg="abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
        do eq^STDASSERT(.pass,.fail,$$sha256^STDCRYPTO(msg),"248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1","SHA-256 of 56-char fixture")
        quit
        ;
tSha256BytesIs32(pass,fail)     ;@TEST "sha256Bytes returns 32 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$sha256Bytes^STDCRYPTO("abc")),32,"SHA-256 byte length")
        quit
        ;
tSha384Empty(pass,fail) ;@TEST "sha384('') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha384^STDCRYPTO(""),"38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b","SHA-384 of empty string")
        quit
        ;
tSha384Abc(pass,fail)   ;@TEST "sha384('abc') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha384^STDCRYPTO("abc"),"cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed8086072ba1e7cc2358baeca134c825a7","SHA-384 of 'abc'")
        quit
        ;
tSha384BytesIs48(pass,fail)     ;@TEST "sha384Bytes returns 48 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$sha384Bytes^STDCRYPTO("abc")),48,"SHA-384 byte length")
        quit
        ;
tSha512Empty(pass,fail) ;@TEST "sha512('') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha512^STDCRYPTO(""),"cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e","SHA-512 of empty string")
        quit
        ;
tSha512Abc(pass,fail)   ;@TEST "sha512('abc') matches FIPS 180-4 vector"
        do eq^STDASSERT(.pass,.fail,$$sha512^STDCRYPTO("abc"),"ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f","SHA-512 of 'abc'")
        quit
        ;
tSha512BytesIs64(pass,fail)     ;@TEST "sha512Bytes returns 64 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$sha512Bytes^STDCRYPTO("abc")),64,"SHA-512 byte length")
        quit
        ;
tHmacSha256Rfc4231Case1(pass,fail)      ;@TEST "HMAC-SHA-256 RFC 4231 test 1 (key=0x0b*20, msg='Hi There')"
        new key,msg
        set key=$$repByte(11,20)
        set msg="Hi There"
        do eq^STDASSERT(.pass,.fail,$$hmacSha256^STDCRYPTO(key,msg),"b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7","HMAC-SHA-256 RFC 4231 §4.2")
        quit
        ;
tHmacSha256Rfc4231Case2(pass,fail)      ;@TEST "HMAC-SHA-256 RFC 4231 test 2 (key='Jefe', msg='what do ya want for nothing?')"
        do eq^STDASSERT(.pass,.fail,$$hmacSha256^STDCRYPTO("Jefe","what do ya want for nothing?"),"5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843","HMAC-SHA-256 RFC 4231 §4.3")
        quit
        ;
tHmacSha256BytesIs32(pass,fail) ;@TEST "hmacSha256Bytes returns 32 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$hmacSha256Bytes^STDCRYPTO("k","m")),32,"HMAC-SHA-256 byte length")
        quit
        ;
tHmacSha384Rfc4231Case1(pass,fail)      ;@TEST "HMAC-SHA-384 RFC 4231 test 1"
        new key,msg
        set key=$$repByte(11,20)
        set msg="Hi There"
        do eq^STDASSERT(.pass,.fail,$$hmacSha384^STDCRYPTO(key,msg),"afd03944d84895626b0825f4ab46907f15f9dadbe4101ec682aa034c7cebc59cfaea9ea9076ede7f4af152e8b2fa9cb6","HMAC-SHA-384 RFC 4231 §4.2")
        quit
        ;
tHmacSha384BytesIs48(pass,fail) ;@TEST "hmacSha384Bytes returns 48 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$hmacSha384Bytes^STDCRYPTO("k","m")),48,"HMAC-SHA-384 byte length")
        quit
        ;
tHmacSha512Rfc4231Case1(pass,fail)      ;@TEST "HMAC-SHA-512 RFC 4231 test 1"
        new key,msg
        set key=$$repByte(11,20)
        set msg="Hi There"
        do eq^STDASSERT(.pass,.fail,$$hmacSha512^STDCRYPTO(key,msg),"87aa7cdea5ef619d4ff0b4241a1d6cb02379f4e2ce4ec2787ad0b30545e17cdedaa833b7d6b8a702038b274eaea3f4e4be9d914eeb61f1702e696c203a126854","HMAC-SHA-512 RFC 4231 §4.2")
        quit
        ;
tHmacSha512BytesIs64(pass,fail) ;@TEST "hmacSha512Bytes returns 64 raw bytes"
        do len^STDASSERT(.pass,.fail,$length($$hmacSha512Bytes^STDCRYPTO("k","m")),64,"HMAC-SHA-512 byte length")
        quit
        ;
tHmacKeyLongerThanBlockOk(pass,fail)    ;@TEST "HMAC accepts keys longer than the hash block"
        new key,m
        set key=$$repByte(170,131)
        set m=$$hmacSha256^STDCRYPTO(key,"hello")
        do len^STDASSERT(.pass,.fail,$length(m),64,"HMAC-SHA-256 with 131-byte key returns 64 hex chars")
        quit
        ;
tHmacEmptyKeyOk(pass,fail)      ;@TEST "HMAC with empty key produces a deterministic 32-byte result"
        new m
        set m=$$hmacSha256^STDCRYPTO("","msg")
        do len^STDASSERT(.pass,.fail,$length(m),64,"HMAC-SHA-256 empty key length")
        do eq^STDASSERT(.pass,.fail,m,$$hmacSha256^STDCRYPTO("","msg"),"HMAC-SHA-256 empty key is deterministic")
        quit
        ;
tHexLowercaseAlphabet(pass,fail)        ;@TEST "hex digests use lowercase a-f only"
        new d
        set d=$$sha256^STDCRYPTO("abc")
        do eq^STDASSERT(.pass,.fail,$translate(d,"abcdef0123456789",""),"","SHA-256 hex contains only [0-9a-f]")
        quit
        ;
tBinaryInputRoundTrips(pass,fail)       ;@TEST "binary input (bytes 0..255) hashes without truncation"
        new data,d
        set data=$$range255()
        set d=$$sha256^STDCRYPTO(data)
        do len^STDASSERT(.pass,.fail,$length(d),64,"SHA-256 of 256-byte 0..255 fixture is 64 hex chars")
        quit
        ;
        ; ---------- helpers ----------
        ;
repByte(b,n)    ; n copies of $char(b)
        new s,i
        set s=""
        for i=1:1:n  set s=s_$char(b)
        quit s
        ;
range255()      ; All bytes 0..255 in order — exercises binary safety.
        new s,i
        set s=""
        for i=0:1:255  set s=s_$char(i)
        quit s
        ;
        ;
        ; ---------- asymmetric verify (RS*) tests — T32 ----------
        ; Vectors: RFC 7515 App A.2 (RS256 KAT) + RS384/512 signed over rskMsg
        ; with a fixed generated key. Keys/sigs carried as hex, decoded in-suite
        ; via $$decode^STDHEX for byte-fidelity on both engines (R-BYTE / A-8).
        ;
tVerifyAvailableIsOne(pass,fail)        ;@TEST "verifyAvailable() is 1 on a healthy verify-capable engine"
        do true^STDASSERT(.pass,.fail,$$verifyAvailable^STDCRYPTO()=1,"verifyAvailable is 1")
        quit
        ;
tVerifyRs256RfcKat(pass,fail)   ;@TEST "verifySig RS256 accepts the RFC 7515 App A.2 KAT (DER key)"
        new key,msg,sig
        set key=$$decode^STDHEX($$vRs256PubDer())
        set msg=$$decode^STDHEX($$vRs256Msg())
        set sig=$$decode^STDHEX($$vRs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,msg,sig)=1,"RFC 7515 A.2 RS256 verifies")
        quit
        ;
tVerifyRs256PemKey(pass,fail)   ;@TEST "verifySig RS256 accepts a PEM-encoded key (engine-neutral)"
        new key,msg,sig
        set key="-----BEGIN PUBLIC KEY-----"_$char(10)_$$vRs256PubB64()_$char(10)_"-----END PUBLIC KEY-----"
        set msg=$$decode^STDHEX($$vRs256Msg())
        set sig=$$decode^STDHEX($$vRs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,msg,sig)=1,"RS256 verifies with PEM key")
        quit
        ;
tVerifyRs384Kat(pass,fail)      ;@TEST "verifySig RS384 accepts a matching signature"
        new key,sig
        set key=$$decode^STDHEX($$vRskPubDer())
        set sig=$$decode^STDHEX($$vRs384Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS384",key,$$rskMsg(),sig)=1,"RS384 verifies")
        quit
        ;
tVerifyRs512Kat(pass,fail)      ;@TEST "verifySig RS512 accepts a matching signature"
        new key,sig
        set key=$$decode^STDHEX($$vRskPubDer())
        set sig=$$decode^STDHEX($$vRs512Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS512",key,$$rskMsg(),sig)=1,"RS512 verifies")
        quit
        ;
tVerifyRs256WrapperOk(pass,fail)        ;@TEST "verifyRs256 thin wrapper verifies a matching signature"
        new key,sig
        set key=$$decode^STDHEX($$vRskPubDer())
        set sig=$$decode^STDHEX($$vRs256bSig())
        do true^STDASSERT(.pass,.fail,$$verifyRs256^STDCRYPTO(key,$$rskMsg(),sig)=1,"verifyRs256 wrapper verifies")
        quit
        ;
tVerifyWrongKeyIsZero(pass,fail)        ;@TEST "verifySig returns 0 for a valid signature under the wrong key"
        new key,msg,sig
        set key=$$decode^STDHEX($$vWrongPubDer())
        set msg=$$decode^STDHEX($$vRs256Msg())
        set sig=$$decode^STDHEX($$vRs256Sig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,msg,sig),0,"wrong key -> 0")
        quit
        ;
tVerifyBitFlipIsZero(pass,fail) ;@TEST "verifySig returns 0 for a bit-flipped signature"
        new key,msg,sig
        set key=$$decode^STDHEX($$vRs256PubDer())
        set msg=$$decode^STDHEX($$vRs256Msg())
        set sig=$$decode^STDHEX($$vRs256SigBad())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,msg,sig),0,"bit-flip -> 0")
        quit
        ;
tVerifyZeroSigIsZero(pass,fail) ;@TEST "verifySig returns 0 for an all-zero signature (Wycheproof-class)"
        new key,msg,sig
        set key=$$decode^STDHEX($$vRs256PubDer())
        set msg=$$decode^STDHEX($$vRs256Msg())
        set sig=$$decode^STDHEX($$vZeroSig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,msg,sig),0,"zero sig -> 0")
        quit
        ;
tVerifyTruncSigIsZero(pass,fail)        ;@TEST "verifySig returns 0 for a truncated signature (Wycheproof-class)"
        new key,sig
        set key=$$decode^STDHEX($$vRskPubDer())
        set sig=$$decode^STDHEX($$vTruncSig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("RS256",key,$$rskMsg(),sig),0,"truncated sig -> 0")
        quit
        ;
tVerifyUnknownAlgRaises(pass,fail)      ;@TEST "verifySig raises U-STDCRYPTO-BADALG for an unknown alg"
        do raises^STDASSERT(.pass,.fail,"new x set x=$$verifySig^STDCRYPTO(""ZZ000"",$$decode^STDHEX($$vRs256PubDer^STDCRYPTOTST()),""m"",""s"")",",U-STDCRYPTO-BADALG,","unknown alg raises BADALG")
        quit
        ;
tVerifyEmptyKeyRaises(pass,fail)        ;@TEST "verifySig raises U-STDCRYPTO-BADKEY for an empty key"
        do raises^STDASSERT(.pass,.fail,"new x set x=$$verifySig^STDCRYPTO(""RS256"","""",""m"",""s"")",",U-STDCRYPTO-BADKEY,","empty key raises BADKEY")
        quit
        ;
tVerifyBadKeyRaises(pass,fail)  ;@TEST "verifySig raises U-STDCRYPTO-BADKEY for an unparseable key (fail-closed)"
        do raises^STDASSERT(.pass,.fail,"new x set x=$$verifySig^STDCRYPTO(""RS256"",""not-a-real-spki-key"",""m"",""s"")",",U-STDCRYPTO-BADKEY,","garbage key raises BADKEY")
        quit
        ;
tVerifyErrorCodesDistinct(pass,fail)    ;@TEST "the four verify error codes are distinct (N-3 regression)"
        new codes,c,n
        set codes("U-STDCRYPTO-BADKEY")=""
        set codes("U-STDCRYPTO-BADALG")=""
        set codes("U-STDCRYPTO-VERIFY-FAIL")=""
        set codes("U-STDCRYPTO-CALLOUT-MISSING")=""
        set n=0,c=""
        for  set c=$order(codes(c)) quit:c=""  set n=n+1
        do eq^STDASSERT(.pass,.fail,n,4,"four verify error codes are distinct")
        quit
        ;
        ; ---------- asymmetric verify (ES*/EdDSA/PS*) tests — T32 Phase 2 ----------
        ; Positive KATs: RFC 7515 App A.3 (ES256), RFC 8037 App A.1 (Ed25519),
        ; scripted ES384/ES521 + PS256/384/512 over rskMsg (OpenSSL 3.0.13).
        ; ES* sigs are the JWT R||S concatenation (P-521 halves are 66 bytes, not
        ; 64). EdDSA is YDB-only: IRIS has no CFRG method, so verifySig raises
        ; BADALG there — asserted as a VISIBLE tracked skip (edDsaSkip), never a
        ; silent pass. Keys/sigs carried as hex, decoded in-suite for byte-fidelity.
        ;
tVerifyEs256RfcKat(pass,fail)   ;@TEST "verifySig ES256 accepts the RFC 7515 App A.3 KAT"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig)=1,"RFC 7515 A.3 ES256 verifies")
        quit
        ;
tVerifyEs384Kat(pass,fail)      ;@TEST "verifySig ES384 accepts a matching signature"
        new key,sig
        set key=$$decode^STDHEX($$vEs384PubDer())
        set sig=$$decode^STDHEX($$vEs384Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES384",key,$$rskMsg(),sig)=1,"ES384 verifies")
        quit
        ;
tVerifyEs521Kat(pass,fail)      ;@TEST "verifySig ES521 accepts a matching signature (P-521 66-byte halves)"
        new key,sig
        set key=$$decode^STDHEX($$vEs521PubDer())
        set sig=$$decode^STDHEX($$vEs521Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES512",key,$$rskMsg(),sig)=1,"ES521 verifies (132-byte R||S)")
        quit
        ;
tVerifyEs256WrapperOk(pass,fail)        ;@TEST "verifyEs256 thin wrapper verifies a matching signature"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifyEs256^STDCRYPTO(key,msg,sig)=1,"verifyEs256 wrapper verifies")
        quit
        ;
tVerifyEs256BitFlipIsZero(pass,fail)    ;@TEST "verifySig ES256 returns 0 for a bit-flipped signature"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEs256SigBad())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig),0,"ES256 bit-flip -> 0")
        quit
        ;
tVerifyEs256WrongCurveIsZero(pass,fail) ;@TEST "verifySig ES256 returns 0 under a wrong-curve (P-384) key"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs384PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEs256Sig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig),0,"ES256 wrong-curve key -> 0")
        quit
        ;
tVerifyEsZeroSigIsZero(pass,fail)       ;@TEST "verifySig ES256 returns 0 for an all-zero R||S (r=0,s=0; Wycheproof-class)"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEsZeroSig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig),0,"ES256 zero R||S -> 0")
        quit
        ;
tVerifyEsTruncSigIsZero(pass,fail)      ;@TEST "verifySig ES256 returns 0 for a half-width (32-byte) signature"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEsTruncSig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig),0,"ES256 truncated R||S -> 0")
        quit
        ;
tVerifyEsOddSigIsZero(pass,fail)        ;@TEST "verifySig ES256 returns 0 for an odd-length (63-byte) signature"
        new key,msg,sig
        set key=$$decode^STDHEX($$vEs256PubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$decode^STDHEX($$vEsOddSig())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",key,msg,sig),0,"ES256 odd-length R||S -> 0")
        quit
        ;
tVerifyPs256Kat(pass,fail)      ;@TEST "verifySig PS256 accepts a matching RSASSA-PSS signature"
        new key,sig
        set key=$$decode^STDHEX($$vPsPubDer())
        set sig=$$decode^STDHEX($$vPs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("PS256",key,$$rskMsg(),sig)=1,"PS256 verifies")
        quit
        ;
tVerifyPs384Kat(pass,fail)      ;@TEST "verifySig PS384 accepts a matching RSASSA-PSS signature"
        new key,sig
        set key=$$decode^STDHEX($$vPsPubDer())
        set sig=$$decode^STDHEX($$vPs384Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("PS384",key,$$rskMsg(),sig)=1,"PS384 verifies")
        quit
        ;
tVerifyPs512Kat(pass,fail)      ;@TEST "verifySig PS512 accepts a matching RSASSA-PSS signature"
        new key,sig
        set key=$$decode^STDHEX($$vPsPubDer())
        set sig=$$decode^STDHEX($$vPs512Sig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("PS512",key,$$rskMsg(),sig)=1,"PS512 verifies")
        quit
        ;
tVerifyPs256WrapperOk(pass,fail)        ;@TEST "verifyPs256 thin wrapper verifies a matching signature"
        new key,sig
        set key=$$decode^STDHEX($$vPsPubDer())
        set sig=$$decode^STDHEX($$vPs256Sig())
        do true^STDASSERT(.pass,.fail,$$verifyPs256^STDCRYPTO(key,$$rskMsg(),sig)=1,"verifyPs256 wrapper verifies")
        quit
        ;
tVerifyPs256BitFlipIsZero(pass,fail)    ;@TEST "verifySig PS256 returns 0 for a bit-flipped signature"
        new key,sig
        set key=$$decode^STDHEX($$vPsPubDer())
        set sig=$$decode^STDHEX($$vPs256SigBad())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("PS256",key,$$rskMsg(),sig),0,"PS256 bit-flip -> 0")
        quit
        ;
tVerifyEdDSAKat(pass,fail)      ;@TEST "verifySig EdDSA — RFC 8037 A.1 verifies on YDB; BADALG (YDB-only skip) on IRIS"
        new key,msg,sig
        if $zversion["IRIS" do edDsaSkip(.pass,.fail,"EdDSA KAT") quit
        set key=$$decode^STDHEX($$vEdPubDer())
        set msg=$$decode^STDHEX($$vEdMsg())
        set sig=$$decode^STDHEX($$vEdSig())
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("EdDSA",key,msg,sig)=1,"RFC 8037 A.1 Ed25519 verifies on YDB")
        quit
        ;
tVerifyEdDSABitFlip(pass,fail)  ;@TEST "verifySig EdDSA returns 0 for a bit-flipped sig (YDB); BADALG on IRIS"
        new key,msg,sig
        if $zversion["IRIS" do edDsaSkip(.pass,.fail,"EdDSA bit-flip") quit
        set key=$$decode^STDHEX($$vEdPubDer())
        set msg=$$decode^STDHEX($$vEdMsg())
        set sig=$$decode^STDHEX($$vEdSigBad())
        do eq^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("EdDSA",key,msg,sig),0,"EdDSA bit-flip -> 0 on YDB")
        quit
        ;
edDsaSkip(pass,fail,what)       ; IRIS: assert EdDSA raises BADALG (YDB-only — a visible tracked skip, not a silent pass).
        do raises^STDASSERT(.pass,.fail,"new x set x=$$verifySig^STDCRYPTO(""EdDSA"",$$decode^STDHEX($$vEdPubDer^STDCRYPTOTST()),$$decode^STDHEX($$vEdMsg^STDCRYPTOTST()),$$decode^STDHEX($$vEdSig^STDCRYPTOTST()))",",U-STDCRYPTO-BADALG,",what_": EdDSA is YDB-only — IRIS raises BADALG")
        quit
        ;
        ; ---------- asymmetric SIGN (signSig / signRs256 / signEs256) tests ----------
        ; RS256 is deterministic (PKCS#1 v1.5), so it gets an EXACT-byte KAT against
        ; an openssl reference signature (independent implementation). ES256 is
        ; non-deterministic (random k), so it is proven by a sign->verify round-trip —
        ; and verify is itself pinned to correctness by the RFC 7515 A.3 external KAT
        ; above, so the round-trip cannot mask a sign bug. Keys are NON-SECRET test
        ; fixtures (fresh RSA-2048 / EC P-256), carried as hex, decoded in-suite. The
        ; signed message reuses vEs256Msg (the A.3 JWS signing input).
        ;
tSignRs256ExactKat(pass,fail)   ;@TEST "signRs256 matches the openssl RS256 reference signature exactly (deterministic KAT)"
        new priv,msg,sig
        set priv=$$decode^STDHEX($$vSignRsaPrivP8())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$signRs256^STDCRYPTO(priv,msg)
        do eq^STDASSERT(.pass,.fail,$$encode^STDHEX(sig),$$vSignRs256Sig(),"RS256 signature is byte-identical to the openssl reference")
        quit
        ;
tSignRs256Verifies(pass,fail)   ;@TEST "a signRs256 signature verifies under the matching public key (interop)"
        new priv,pub,msg,sig
        set priv=$$decode^STDHEX($$vSignRsaPrivP8())
        set pub=$$decode^STDHEX($$vSignRsaPubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$signRs256^STDCRYPTO(priv,msg)
        do true^STDASSERT(.pass,.fail,$$verifyRs256^STDCRYPTO(pub,msg,sig)=1,"signed RS256 token verifies")
        quit
        ;
tSignEs256RoundTrip(pass,fail)  ;@TEST "signEs256 -> verifyEs256 round-trips (sign, then verify with the public key)"
        new priv,pub,msg,sig
        set priv=$$decode^STDHEX($$vSignEcPrivP8())
        set pub=$$decode^STDHEX($$vSignEcPubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$signEs256^STDCRYPTO(priv,msg)
        do true^STDASSERT(.pass,.fail,$$verifyEs256^STDCRYPTO(pub,msg,sig)=1,"signed ES256 token verifies")
        quit
        ;
tSignEs256SigLen64(pass,fail)   ;@TEST "signEs256 returns a 64-byte JWT R||S signature (not a DER SEQUENCE)"
        new priv,msg,sig
        set priv=$$decode^STDHEX($$vSignEcPrivP8())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$signEs256^STDCRYPTO(priv,msg)
        do eq^STDASSERT(.pass,.fail,$length(sig),64,"ES256 R||S is exactly 64 bytes")
        quit
        ;
tSignSigGenericEs256(pass,fail) ;@TEST "generic signSig(ES256,...) round-trips through verifySig"
        new priv,pub,msg,sig
        set priv=$$decode^STDHEX($$vSignEcPrivP8())
        set pub=$$decode^STDHEX($$vSignEcPubDer())
        set msg=$$decode^STDHEX($$vEs256Msg())
        set sig=$$signSig^STDCRYPTO("ES256",priv,msg)
        do true^STDASSERT(.pass,.fail,$$verifySig^STDCRYPTO("ES256",pub,msg,sig)=1,"generic signSig ES256 round-trips")
        quit
        ;
tSignEmptyKeyRaises(pass,fail)  ;@TEST "signSig raises U-STDCRYPTO-BADKEY for an empty private key"
        do raises^STDASSERT(.pass,.fail,"new x set x=$$signSig^STDCRYPTO(""ES256"","""",""m"")",",U-STDCRYPTO-BADKEY,","empty private key raises BADKEY")
        quit
        ;
tSignUnknownAlgRaises(pass,fail)        ;@TEST "signSig raises U-STDCRYPTO-BADALG for an unknown alg"
        do raises^STDASSERT(.pass,.fail,"new x set x=$$signSig^STDCRYPTO(""ZZ000"",$$decode^STDHEX($$vSignEcPrivP8^STDCRYPTOTST()),""m"")",",U-STDCRYPTO-BADALG,","unknown alg raises BADALG")
        quit
        ;
        ; ---------- ES*/EdDSA/PS* test vectors (hex; decoded in-suite) ----------
        ;
        ; sign-KAT fixtures — fresh RSA-2048 + EC P-256 keys (openssl 3.x), NON-SECRET
        ; test material. The RS256 reference sig is openssl's deterministic output over
        ; vEs256Msg; the EC key is round-tripped (its sig is non-deterministic).
        ;
vSignRsaPrivP8() ; sign KAT — fresh RSA-2048 PKCS#8 DER private key (hex; NON-SECRET test fixture)
        new h set h="308204be020100300d06092a864886f70d0101010500048204a8308204a40201000282010100d6858e6df46981cabdad166f046741d6ee04"
        set h=h_"b731960066bcf1b20ab8c31ef84ab4f5bd4fcc5b4af5187702b31dd15b77df5af4db4af7a96e282ab4e8a9ff348df1f9cb7fdf7dac663260"
        set h=h_"a65e151dfa0f6f2bc5cd8d8e858636a47d660610bf1f4c5e90587a85386b9af03396f92c2eecff2adfb12d35a09991e616d31f94fdc5974b"
        set h=h_"738d596d6e30ebd5e3168c6fce3fc1ca67e8881db42acfbda46ebc107c18d0ac35443f5d734ede4b641f04363774c03bde57a73645a14ed1"
        set h=h_"2709b27c53bf25cdfdb1c07dc2da60d2162af76d21a69df059d3309a7b7b76ad5cc2f910beff2d35cf9bd654aad6070c2fb41b816357f868"
        set h=h_"e2c5917c6ee8ff73f26423200bc70203010001028201004666e66b677f08bd84aa3d6689c769702405202a01d477e3225f0fedbafb7af8e9"
        set h=h_"928c6297ea8e1b09c064fe6b96bdb20577504c77b9f7bcd329d0dd5a8d0aae5aef63bdbf96faf13f2f40ea377bf30905af13e775c184489b"
        set h=h_"be37f9379c5f5ce22f56a7f2edadaa82dab9d39e4ac5cbb9a2546f4d2b005de5e7e12dc07ba11c91cb4ea994ee24ffcde4fae7a344d403d8"
        set h=h_"60354dcb6486f8cedb1ab05438be455106bdd431f8c8ca0b0d2274e8dc94ff91d87da371ebf342ead6d101b291094336733a917c3b37b48d"
        set h=h_"7b78c2f548edd4c9e2cef33d218df1945c702d93be5cfe3122e684c58eb8b040cf93f2a962789375519979a62f397391aeba07734024a102"
        set h=h_"818100ecb356cc99e19076840badf096550d6e897aeae3cd37162237336c15928ec7b961d86f70b7972d20d4f27ba2c5b9e6abc2a2e7ab48"
        set h=h_"267cfd0b55ab788789b5cd88df8690aa04d97b4995f2da6c44755be1942254b863e13340dc82d440d4cdda81784848d233948be9e60bee27"
        set h=h_"acc854c994dedb8dd739173525574156f43e7b02818100e80347052b3e6dd22d13c17eeb3e6bf7c791a582cb27e90d2509e46b1397dc7bd1"
        set h=h_"243f634495b9fb5563fbbe3d6ba13e99ff0bc3f190bee5219c6216e8ed6df323d4691363ecfc6b130b8050e66dd043c9be54d85b4df152e5"
        set h=h_"23e086bd6ca36fd26f36c590ba69aacad53db1b3c80359dbc88e3b0d03a025bcc228cc464bcc2502818028bc88b0b7bf114cc456fa3d90b1"
        set h=h_"dc98ec824210a88dd57a5803ba934fe0d0d0bfdd2ef8b830056d4418e35c55293460d5239239713666866a3ff93dca1dd233285e47db77d7"
        set h=h_"53d29b0c7a7a4aedd140d9e6d3adbefa3994c791ebd639be261b77f2ca85f5df38ae87b7b6cfeaf61a98350531019a3cb32fa24ee5e071e5"
        set h=h_"a12702818100aae43f1b7f8eac35731e6a17a20e885829970de218e17cb741e0d76e47304426af1593dafa598e73a1a1d37b7ca21a5291fb"
        set h=h_"5a1f297f041ca1751e8ae16680e5e62e3e7719d324d9795daf55e7645b5292f6ae67ee58aab7f42f48e1f6045f1dae525c7588f4c5801786"
        set h=h_"99ba9a4168b6773c7206ecbf0ee6bcf2063af04c444102818100a59fa1b8b021a0b8f3759adf827a63adb6eca6c9872bfe2961a1b44c1348"
        set h=h_"b1cc9f82b3c1fd7b615ed2bf5d0eb5bd8ec92740d10c47502ffa18f3c6dba4b44869b17a6fa1abf1a729eb59c1dfa91f542d00102cb4b87e"
        set h=h_"5942555c59e893183a71a117f319216829cbe84592ba2d944097633e4db1875fead05b5139b6a960c742"
        quit h
        ;
vSignRsaPubDer() ; sign KAT — matching RSA-2048 SPKI DER public key (hex)
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100d6858e6df46981cabdad166f046741d6ee04b731960066"
        set h=h_"bcf1b20ab8c31ef84ab4f5bd4fcc5b4af5187702b31dd15b77df5af4db4af7a96e282ab4e8a9ff348df1f9cb7fdf7dac663260a65e151dfa"
        set h=h_"0f6f2bc5cd8d8e858636a47d660610bf1f4c5e90587a85386b9af03396f92c2eecff2adfb12d35a09991e616d31f94fdc5974b738d596d6e"
        set h=h_"30ebd5e3168c6fce3fc1ca67e8881db42acfbda46ebc107c18d0ac35443f5d734ede4b641f04363774c03bde57a73645a14ed12709b27c53"
        set h=h_"bf25cdfdb1c07dc2da60d2162af76d21a69df059d3309a7b7b76ad5cc2f910beff2d35cf9bd654aad6070c2fb41b816357f868e2c5917c6e"
        set h=h_"e8ff73f26423200bc70203010001"
        quit h
        ;
vSignRs256Sig() ; sign KAT — openssl RS256 signature of vEs256Msg under vSignRsaPrivP8 (hex; deterministic PKCS#1 v1.5 reference)
        new h set h="cb5b3e870c36d5c64a4478f0d1b539434014472caf6e226d1f7b7e2e8aecdc0ae6dbafb14f6076c9d2c6c5ec85a05ee7eedf5a6ddfee5504"
        set h=h_"eecc9bcb439c50a2f23c2d9ec8130a4ce5f61e7f36a4ac31c0126680e91bfa884607efb5b033d3ff66b2380bc8b246c6264b90c9311d2c4d"
        set h=h_"a514e153a9be98cbe45e715699b46b4eac5bf2f230353072e4aa60d2dcb2c688f22df25e4c610f2defb5a9e6cc91a85bcd8a224c9078bdfd"
        set h=h_"d2480a9ec8233f3050e978c1361d864891e555f52b40fd626659d236c7d281721d09bb83a0b305688330aa99c687983e72b3c85e7cb2f163"
        set h=h_"0700912511528906953e4b9caf8db26d51de23dfc3de8b349c1a494c623068bc"
        quit h
        ;
vSignEcPrivP8() ; sign KAT — fresh EC P-256 PKCS#8 DER private key (hex; NON-SECRET test fixture)
        new h set h="308187020100301306072a8648ce3d020106082a8648ce3d030107046d306b0201010420fb643cb6b6fe163fd7c5a2eea73605bba0641057"
        set h=h_"3305cb447ddc9687af15a24da14403420004ed48bd33739f3837123b72115dd2fb0e410df018e708de989f6c3c5febec7632f4cfb84173a2"
        set h=h_"90a5e3e8fabe07672548af46ac011ce2caf6e5a8dfebaf12bf9d"
        quit h
        ;
vSignEcPubDer() ; sign KAT — matching EC P-256 SPKI DER public key (hex)
        new h set h="3059301306072a8648ce3d020106082a8648ce3d03010703420004ed48bd33739f3837123b72115dd2fb0e410df018e708de989f6c3c5feb"
        set h=h_"ec7632f4cfb84173a290a5e3e8fabe07672548af46ac011ce2caf6e5a8dfebaf12bf9d"
        quit h
        ;
vEs256PubDer() ; RFC 7515 App A.3 ES256 (P-256) public key, SPKI DER (hex)
        new h set h="3059301306072a8648ce3d020106082a8648ce3d030107034200047fcdce2770f6c45d4183cbee6fdb4b7b580733357be9ef13bacf6e3c7bd15445"
        set h=h_"c7f144cd1bbd9b7e872cdfedb9eeb9f4b3695d6ea90b24ad8a4623288588e5ad"
        quit h
        ;
vEs256Msg() ; RFC 7515 App A.3 ES256 JWS signing input (hex)
        new h set h="65794a68624763694f694a46557a49314e694a392e65794a7063334d694f694a71623255694c41304b49434a6c654841694f6a457a4d4441344d54"
        set h=h_"6b7a4f44417344516f67496d6830644841364c79396c654746746347786c4c6d4e76625339706331397962323930496a7030636e566c6651"
        quit h
        ;
vEs256Sig() ; RFC 7515 App A.3 ES256 signature — JWT R||S, 64 bytes (hex)
        new h set h="0ed1215379636c483c2f7f155807d402a3b228033af97c7e17819ac3169ea665c50a07d38c3c70e5d8f12daf084a5480a66590c5f293509a8f3f7f"
        set h=h_"8a83a354d5"
        quit h
        ;
vEs256SigBad() ; RFC A.3 ES256 sig, first byte bit-flipped (hex)
        new h set h="0fd1215379636c483c2f7f155807d402a3b228033af97c7e17819ac3169ea665c50a07d38c3c70e5d8f12daf084a5480a66590c5f293509a8f3f7f"
        set h=h_"8a83a354d5"
        quit h
        ;
vEs384PubDer() ; ES384 (P-384) KAT key over rskMsg, SPKI DER (hex)
        new h set h="3076301006072a8648ce3d020106052b81040022036200049dbf0dcd3020fe53702b4725c0d8686b58ec4177e8864110c1a4277512b727ca1043c7"
        set h=h_"ccd062079b7f509abc5001d5f6ef73afbe566cc6eebacc47d7b52d45e1bc6681c4c96c73d24f38bf403e6f7c12073931bc3f5d7083bc9243c613f6"
        set h=h_"16a4"
        quit h
        ;
vEs384Sig() ; ES384 signature over rskMsg — R||S, 96 bytes (hex)
        new h set h="fde9116173dce10cc468e6f751f873b930ee0ebd73f135f42812d340ae88ce06d64a70dab2092258a8b30a759d5210b00bb01682215d2acff37f46"
        set h=h_"f08b8b81fe7651a7ee6a02860fd5bd92e830f9c399d6018887848c02ce569de9c1880685fe"
        quit h
        ;
vEs521PubDer() ; ES521 (P-521) KAT key over rskMsg, SPKI DER (hex)
        new h set h="30819b301006072a8648ce3d020106052b81040023038186000401c647dbb10629fad9b8c4e21bb8282aaf4819b4e3f711874c9a51091345a580eb"
        set h=h_"7f9f4fbd7ab11bf1a633d255a8022a678d6d3c5e5452627dfdad54adab690a127d019216372391554106d0c476142a923f57de43e3f6969b5e61b2"
        set h=h_"1fd2f1160e4dcf6d2b3ba9096c7e01ad26ca1ab613d85d4f0a7e8cbafbf600b6280c229cf0868846"
        quit h
        ;
vEs521Sig() ; ES521 signature over rskMsg — R||S, 132 bytes = 66-byte halves (hex)
        new h set h="002639c2bf8c0944af8c44e5adb46bf3108a537270aee47bfb20d8a7eb73592b6d1532437d9e2c48f93905524793e74e531cbaae5bf561bf42c4f6"
        set h=h_"ab05b710c060580002fbf5515e1f3f19f99298dfd8a1cffee0180f7498e5a78866360dd4fd175b28fb813dd66fa648e2aea7a627e42394f027c2f5"
        set h=h_"462de6c84bed9c4ad7490e804de0"
        quit h
        ;
vEdPubDer() ; RFC 8037 App A.1 Ed25519 public key, SPKI DER (hex)
        new h set h="302a300506032b6570032100d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
        quit h
        ;
vEdMsg() ; RFC 8037 App A.1 EdDSA signing input (hex)
        new h set h="65794a68624763694f694a465a45525451534a392e52586868625842735a5342765a6942465a4449314e54453549484e705a323570626d63"
        quit h
        ;
vEdSig() ; RFC 8037 App A.1 Ed25519 signature, 64 bytes (hex)
        new h set h="860c98d2297f3060a33f42739672d61b53cf3adefed3d3c672f320dc021b411e9d59b8628dc351e248b88b29468e0e41855b0fb7d83bb15be902bf"
        set h=h_"ccb8cd0a02"
        quit h
        ;
vEdSigBad() ; RFC A.1 Ed25519 sig, first byte bit-flipped (hex)
        new h set h="870c98d2297f3060a33f42739672d61b53cf3adefed3d3c672f320dc021b411e9d59b8628dc351e248b88b29468e0e41855b0fb7d83bb15be902bf"
        set h=h_"ccb8cd0a02"
        quit h
        ;
vPsPubDer() ; PS* KAT RSA-2048 key (shared), SPKI DER (hex)
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100db906f39ee2e55407c2c16bcd285fefdf3efe820a70d7e389b8c"
        set h=h_"5b45392f1d2068c07537e4bbb9ea6bf9cec639c5d407a14f6f2b32dffa1db4da2cd846d7c097503cfae2b1df0152b3eb73386be744783c0c286fd5"
        set h=h_"010277f58e665ba4d2a099bf426e63b41cec230538f2c923e6450e5763766c66c3b0340b860144f28493ce1210ae42a011310bbca867194d31e1ac"
        set h=h_"d67f91ba1e782914ddb7816d4daee4c6b71eb9fdd400a853352f0b0f55225df0523ab450d187e3c39401cf2d4a68de8f1934d1599ae97915b4c6af"
        set h=h_"c370bb4b537876c522c3cd2f69f03fb1f1ec801c1bffa44b90f603963a5a1b812c46fb16bcfcaa3093521b8c96e6b417b42c6de20d0203010001"
        quit h
        ;
vPs256Sig() ; PS256 (RSASSA-PSS) signature over rskMsg (hex)
        new h set h="cd032f988a4cf1be46d86cdfa92ce9ab88b81a084667d0e0ba3ee198c52eb7096808015d3636ef756eaa53300c002fd914c04001294acd5fdf6751"
        set h=h_"78d33e47b3c32051328ca5cd9d4bbb9224b06b9a101570d60a5794a3e783144294e862f5e6a1121f9558c9fae5ac6bb5b26720bd780ca3064fdf7a"
        set h=h_"40e3f659db61ffa74add8475fb863914bdda64ad5ca48201b11377c7e03018ac034f1e8b5c2a4606e55ef0e95ee59dcc587011887d7ab57407ed11"
        set h=h_"37bfaed8d048afb9f2be6d9f662ad793b4cd1f21f6f45d9be5033d1f7d73d7e8b5084e36465b42ce9c8c286480c080c4c9ddf53136a62deb058d93"
        set h=h_"c728a75252f504af26d334fa0b3277ffbeb5f54f"
        quit h
        ;
vPs384Sig() ; PS384 signature over rskMsg (hex)
        new h set h="0fe2bcd7d67efae54046289ec74d8f2e9c5e774159d736de9661445222d4cb8a6ca227108776497359f3640421755551e822b1ef399235c17a1bd1"
        set h=h_"c119e9f42f86730ab4ef474f5ed6c155327b8999a34dabf99691acbe650d8e26716fecee9316c7eaf87069baac7c429e406ef2893ac93989d5e206"
        set h=h_"9a2faf738f9ff14aa2ef9dd0bb6bf142a411307eb51eff890c3694b1a4c157ba69ba92b71ab4c7f745804d6c7d708dac799ac2221c9233b54fbdd7"
        set h=h_"0280d959186625653a995b7538d212f8c88ac43e1d56c6a783456aa6f2b6bd0dbd5e33b998870972b2b9fa834be4d76ffd929646d1e710b0455c6f"
        set h=h_"30cf4a5b16b0cdd0bc64b5e7dc6f390a3b1dbcfd"
        quit h
        ;
vPs512Sig() ; PS512 signature over rskMsg (hex)
        new h set h="848381f322378fd685d9c2ccb30f9d035f1025347a0ad1d4692ef89ddcdb818f2ee9f5be9e5f1c7f083867fe9a0ee8bfd16261cfb15201fb6f9f20"
        set h=h_"c69d817bedb38b9d865092ca34be51d4b900ddc17a935ed2c7fd49505cf18cdab484b0481ffaf31ab4414b881ce649b31cc535a6aa488c36d4bbda"
        set h=h_"c40fc718b90ce00bd01f23b5ebe183055eaaeecdae697215faaa67aafc84ebe69d4e4fd6f9f39fd04fb511498dd2dd15b4f52f8ee948e49f4c5550"
        set h=h_"c069fe5102c734619301bf6ee3758ee67c7a79d4a5899d3b683f7528e19e130d2d7cc1a3dfed5af0d8f8223d3ae75e3fd63b9f1792aac7afdcca26"
        set h=h_"1bc91373df6abb3887a3484dca27a51614b7364a"
        quit h
        ;
vPs256SigBad() ; PS256 sig, first byte bit-flipped (hex)
        new h set h="cc032f988a4cf1be46d86cdfa92ce9ab88b81a084667d0e0ba3ee198c52eb7096808015d3636ef756eaa53300c002fd914c04001294acd5fdf6751"
        set h=h_"78d33e47b3c32051328ca5cd9d4bbb9224b06b9a101570d60a5794a3e783144294e862f5e6a1121f9558c9fae5ac6bb5b26720bd780ca3064fdf7a"
        set h=h_"40e3f659db61ffa74add8475fb863914bdda64ad5ca48201b11377c7e03018ac034f1e8b5c2a4606e55ef0e95ee59dcc587011887d7ab57407ed11"
        set h=h_"37bfaed8d048afb9f2be6d9f662ad793b4cd1f21f6f45d9be5033d1f7d73d7e8b5084e36465b42ce9c8c286480c080c4c9ddf53136a62deb058d93"
        set h=h_"c728a75252f504af26d334fa0b3277ffbeb5f54f"
        quit h
        ;
vEsZeroSig() ; All-zero 64-byte ES sig (r=0,s=0; Wycheproof-class) (hex)
        new h set h="0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        set h=h_"0000000000"
        quit h
        ;
vEsTruncSig() ; Truncated ES256 sig — 32 bytes (half width) (hex)
        new h set h="0ed1215379636c483c2f7f155807d402a3b228033af97c7e17819ac3169ea665"
        quit h
        ;
vEsOddSig() ; Odd-length ES256 sig — 63 bytes → invalid(0) (hex)
        new h set h="0ed1215379636c483c2f7f155807d402a3b228033af97c7e17819ac3169ea665c50a07d38c3c70e5d8f12daf084a5480a66590c5f293509a8f3f7f"
        set h=h_"8a83a354"
        quit h
        ;
        ; ---------- RS* test vectors (hex; decoded in-suite) ----------
        ;
rskMsg()        ; The message the RS384/512 (and rsk RS256) KATs sign.
        quit "The quick brown fox jumps over the lazy dog"
        ;
vRs256PubDer() ; RFC 7515 App A.2 RSA public key, SPKI DER (hex)
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100a1f8160ae2e3c9b465ce8d2d656263362b927dbe29e1f02477fc"
        set h=h_"1625cc90a136e38bd93497c5b6ea63dd7711e67c7429f956b0fb8a8f089adc4b69893cc1333f53edd019b87784252fec914fe4857769594bea4280"
        set h=h_"d32c0f55bf62944f130396bc6e9bdf6ebdd2bda3678eeca0c668f701b38dbffb38c8342ce2fe6d27fade4a5a4874979dd4b9cf9adec4c75b05852c"
        set h=h_"2c0f5ef8a5c1750392f944e8ed64c110c6b647609aa4783aeb9c6c9ad755313050638b83665c6f6f7a82a396702a1f641b82d3ebf2392219491fb6"
        set h=h_"86872c5716f50af8358d9a8b9d17c340728f7f87d89a18d8fcab67ad84590c2ecf759339363c07034d6f606f9e21e05456cae5e9a10203010001"
        quit h
        ;
vRs256PubB64() ; RFC A.2 public key, SPKI base64 body (for PEM assembly)
        new h set h="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAofgWCuLjybRlzo0tZWJjNiuSfb4p4fAkd/wWJcyQoTbji9k0l8W26mPddxHmfHQp+Vaw+4qPCJ"
        set h=h_"rcS2mJPMEzP1Pt0Bm4d4QlL+yRT+SFd2lZS+pCgNMsD1W/YpRPEwOWvG6b32690r2jZ47soMZo9wGzjb/7OMg0LOL+bSf63kpaSHSXndS5z5rexMdbBYUs"
        set h=h_"LA9e+KXBdQOS+UTo7WTBEMa2R2CapHg665xsmtdVMTBQY4uDZlxvb3qCo5ZwKh9kG4LT6/I5IhlJH7aGhyxXFvUK+DWNmoudF8NAco9/h9iaGNj8q2ethF"
        set h=h_"kMLs91kzk2PAcDTW9gb54h4FRWyuXpoQIDAQAB"
        quit h
        ;
vRs256Msg() ; RFC 7515 App A.2 JWS signing input (hex; embeds CRLF)
        new h set h="65794a68624763694f694a53557a49314e694a392e65794a7063334d694f694a71623255694c41304b49434a6c654841694f6a457a4d4441344d54"
        set h=h_"6b7a4f44417344516f67496d6830644841364c79396c654746746347786c4c6d4e76625339706331397962323930496a7030636e566c6651"
        quit h
        ;
vRs256Sig() ; RFC 7515 App A.2 RS256 signature (hex)
        new h set h="702e218943e88fd11eb5d82dbf7845f34106ae1b81fff7731116add1717d83656d420afd3c96eedd73a2663e5166687b000b87226e0187ed1073f9"
        set h=h_"45e582adfcef16d85a798ee8c66ddb3db8975b17d09402beedd5d9d97007108db28160d5f8040ca7445762b81fbe7ff9d92e0ae76f24f25b33bbe6"
        set h=h_"f44ae61eb1040acb20044d3ef9128ed40130795bd4bd3b41eecad066ab651981fde48df77f372dc38b9fafdd3befb18b5da3cc3c2eb02f9e3a41d6"
        set h=h_"12caad15911273a05f23b9e838faaf849d698429ef5a1e88798236c3d40e604522a544c8f27a7a2db80663d16cf7caea56de405cb2215a45b2c255"
        set h=h_"66b55ac1a748a070dfc8a32a469543d019eefb47"
        quit h
        ;
vRs256SigBad() ; RFC A.2 signature, first byte bit-flipped (hex)
        new h set h="712e218943e88fd11eb5d82dbf7845f34106ae1b81fff7731116add1717d83656d420afd3c96eedd73a2663e5166687b000b87226e0187ed1073f9"
        set h=h_"45e582adfcef16d85a798ee8c66ddb3db8975b17d09402beedd5d9d97007108db28160d5f8040ca7445762b81fbe7ff9d92e0ae76f24f25b33bbe6"
        set h=h_"f44ae61eb1040acb20044d3ef9128ed40130795bd4bd3b41eecad066ab651981fde48df77f372dc38b9fafdd3befb18b5da3cc3c2eb02f9e3a41d6"
        set h=h_"12caad15911273a05f23b9e838faaf849d698429ef5a1e88798236c3d40e604522a544c8f27a7a2db80663d16cf7caea56de405cb2215a45b2c255"
        set h=h_"66b55ac1a748a070dfc8a32a469543d019eefb47"
        quit h
        ;
vWrongPubDer() ; A different RSA-2048 public key, SPKI DER (hex)
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100d96178ad356bb516db9b85cdf9854e5ea4637e3598a7a1eaf740"
        set h=h_"859550abdc343b9ff784eb26d6f12357909aadf1447769480d9a88bbcf5480732501a72f3b6a7d6b5b98d09569963e925fa57cf781f019f6e5710b"
        set h=h_"914d07cca512323f00c4fd0192309c73d4ee5930f710bda606f9e2a99caabbb0c94917f5e6bc659b5e681f00cb6276f1cfd8b3a5028cf15115493e"
        set h=h_"277fe62b85784d77c5e47b1cdda74f11669b527548cc9d9b8af3d56ec32d704fc49e37c7ece8b5b52839e1fed933e9f6e95ea528d900a7121acbf7"
        set h=h_"12a641b79af41dd48bfc8188c483b82de21a1f4cbfd47edfe973df2ddad1f2b13e40137188e85c08d1af947ceb2bc49c861973d7970203010001"
        quit h
        ;
vRskPubDer() ; RS384/512 KAT key, SPKI DER (hex)
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100c67a8e8d80e07812636532647d3a0ae75dda73eb772f289f4fcb"
        set h=h_"916d270fa02aa42579982c6c876ec2215f1479ba3d4c8b2024bc7a1de50e72a042aac56df302f3939f0ad05a6689f0187398a0e08e50b365195140"
        set h=h_"1a3219afaa1f1586b55b2b3c761bf2a779bcb1cad5b9b3636b8f156b3c926f38762d25701de59ee7be884419290f65bb9332f8373a421162e5004d"
        set h=h_"46bfcb8c8af2c956e85ff26abca7b4f2f00813413116edb89cf70581908ffd511dae6be682a45fdf0bdc3692bb5b597b861d4c73e0100e653e1bdf"
        set h=h_"1720dfd1a8a4ad1db26d82f213d68841dbed42d1a28768ed7badd24fb01353a6b494a65f46f2d49e733718d266d39bd10e6a58b5dd0203010001"
        quit h
        ;
vRs256bSig() ; RS256 signature over rskMsg (hex)
        new h set h="6c3c92836a6ffd3a3eda930910b223306c3303d8a8b303be4cc20e893de5c8c6ac2dc202384423e51b7140de03dda8abe2005c8caff737c3be8183"
        set h=h_"6c612cc6af54128ae3ecb773dddc5df5b04da450356cc19a6f84149e66f68eeacbef9c85ecca9e0bd6b05e3cbff814763b080b4650ddfab435a2f5"
        set h=h_"1609d0d570ebcdba96e56e3708ab5ab44ee88a14a64a65b9c14ce780f6eb5db3e723b2641324822debf3556b64d6e74f49ae3dd13fbc6fd9cd93c2"
        set h=h_"98db542edaf21700f8512690f937dbb07599dcfc5c6cf927a50e08ac203f16373a899bde7b597902694cf1faebdfc0fe179ae96d63d4ec8d0f55a5"
        set h=h_"82348814d9fad1c07c1c98e42c974cc4bb5b6609"
        quit h
        ;
vRs384Sig() ; RS384 signature over rskMsg (hex)
        new h set h="c162e444c652696dd1791a2b03bb0324575fd255b27e7b9c8fa53c6479939e540f3c3fcc07d59e2a9d65112023b0a94e9011fa691d6d85a271033a"
        set h=h_"f6f616f96a76a7cda73563d330ae0b0fb3f69b66aa4f935a60574501caeed0121fe70cdc919597d9507c1ff8f42838669e67bd3e9628db577cd9ee"
        set h=h_"52d401ba505bff354680ee75ef4e643c348b926a3a51980cc98bb186ba7e69d286b94f31f4302fc425fa130586244a8238194fc526066b8c129d40"
        set h=h_"8d163c06da0a21ca682d828627c3492b3c0b729f3f3f54f506473eef3ebc87cecbed544eb08fc5e79f1bf4e80990dc5586f0dc45b6c49b435225b8"
        set h=h_"0c519451e15be2b22be643feba44dbea59de65aa"
        quit h
        ;
vRs512Sig() ; RS512 signature over rskMsg (hex)
        new h set h="79ddd5afd26135c884a1fde32ac93b8a27bbb6b5387dd1498a648703a29a8269642af2a3370cc6ee51956fa5106612b98fb34751d66a32f65910c8"
        set h=h_"1192c827fc615b70224c74b9e9aa3baff2466392f4dfbebea67ec68f743f09440d39d19c8b7b4570bcda0e33bb4e2366bdf402b04888570e3308a9"
        set h=h_"04e7f0b48cb83e6b3fa25d8b0dac84abbc676c06f60403e9a91ca1eddc74a378a65fea6afdad12758675a05168591da4747fd9dfd67361ccc7b2fa"
        set h=h_"65187d2a9429c936ea0f78605ac3fb83c3af83cbc94df102b329688f00b5a861d49bd9d08ef031014a3fc572108e337b54264add6f2c660a69c59a"
        set h=h_"38134bffb29b99831611a6e3183b2412fb069e26"
        quit h
        ;
vZeroSig() ; All-zero 256-byte signature (hex)
        new h set h="0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        set h=h_"0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        set h=h_"0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        set h=h_"0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
        set h=h_"0000000000000000000000000000000000000000"
        quit h
        ;
vTruncSig() ; Truncated RS256 signature (hex)
        new h set h="6c3c92836a6ffd3a3eda930910b223306c3303d8a8b303be4cc20e893de5c8c6ac2dc202384423e51b7140de03dda8abe2005c8caff737c3be8183"
        set h=h_"6c612cc6af54128ae3ecb773dddc5df5b04da450356cc19a6f84149e66f68eeacbef9c85ecca9e0bd6b05e3cbff814763b080b4650ddfab435a2f5"
        set h=h_"1609d0d570ebcdba96e56e3708ab5ab44ee88a14a64a65b9c14ce780f6eb5db3e723b2641324822debf3556b64d6e74f49ae3dd13fbc6fd9cd93c2"
        set h=h_"98db542edaf21700f8512690f937dbb07599dcfc5c6cf9"
        quit h
        ;
