STDNETTST ; m-stdlib — STDNET (portable raw-TCP sockets) test suite.
        ; Loopback echo over real engine-native sockets. On engines where STDNET
        ; is not wired ($$available^STDNET()=0, e.g. IRIS today) the socket test
        ; soft-skips green — the same posture as STDHTTP's libcurl soft-fail. Run
        ; over the driver stack only (m/v waterline):
        ;   m test --engine ydb --docker m-test-engine --chset m \
        ;     --routines src tests/STDNETTST.m
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tAvailableIsBoolean(.pass,.fail)
        do tLoopbackEcho(.pass,.fail)
        do tCrlfByteExact(.pass,.fail)
        do tPeerClosedDrainsThenEof(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
tAvailableIsBoolean(pass,fail)  ;@TEST "$$available returns a strict 0/1"
        new a
        set a=$$available^STDNET()
        do true^STDASSERT(.pass,.fail,(a=0)!(a=1),"available is boolean")
        quit
        ;
tLoopbackEcho(pass,fail)        ;@TEST "raw TCP loopback round-trips a byte string end to end (single process)"
        new srv,cli,conn,port,buf,n
        if '$$available^STDNET() do true^STDASSERT(.pass,.fail,1,"sockets not wired here - skipped") quit
        set srv=$$listen^STDNET(0)
        do true^STDASSERT(.pass,.fail,srv>0,"listener opened")
        set port=$$boundport^STDNET(srv)
        do true^STDASSERT(.pass,.fail,+port>0,"bound to an OS-assigned port")
        set cli=$$connect^STDNET("127.0.0.1",port,5)
        do true^STDASSERT(.pass,.fail,cli>0,"client connected")
        set conn=$$accept^STDNET(srv,5)
        do true^STDASSERT(.pass,.fail,conn>0,"server accepted the connection")
        do true^STDASSERT(.pass,.fail,$$write^STDNET(cli,"ping"),"client wrote")
        set n=$$read^STDNET(conn,99,5,.buf)
        do eq^STDASSERT(.pass,.fail,buf,"ping","server read the client's bytes")
        do true^STDASSERT(.pass,.fail,$$write^STDNET(conn,buf),"server echoed the bytes")
        set n=$$read^STDNET(cli,99,5,.buf)
        do eq^STDASSERT(.pass,.fail,buf,"ping","client read the echoed bytes")
        set n=$$close^STDNET(cli),n=$$close^STDNET(conn),n=$$close^STDNET(srv)
        quit
        ;
tCrlfByteExact(pass,fail)       ;@TEST "raw TCP read is byte-exact across CR/LF and embedded binary bytes (no terminator stripping)"
        ; Regression for the IRIS readIris CR-terminated-read defect: a read on a
        ; |TCP| device stopped at the first CR and stripped the CRLF, mangling HTTP
        ; framing. YDB's read x#n:t already returned raw bytes. The payload carries
        ; the HTTP request-line/header shape (\r\n\r\n) plus a lone CR and a lone LF
        ; so the read must return EXACTLY what was written, byte for byte.
        new srv,cli,conn,port,buf,n,msg,i,got,b
        if '$$available^STDNET() do true^STDASSERT(.pass,.fail,1,"sockets not wired here - skipped") quit
        set msg="GET /x"_$char(13,10)_"H: y"_$char(13,10)_$char(13,10)_"a"_$char(13)_"b"_$char(10)_"c"
        set srv=$$listen^STDNET(0)
        do true^STDASSERT(.pass,.fail,srv>0,"listener opened")
        set port=$$boundport^STDNET(srv)
        set cli=$$connect^STDNET("127.0.0.1",port,5)
        do true^STDASSERT(.pass,.fail,cli>0,"client connected")
        set conn=$$accept^STDNET(srv,5)
        do true^STDASSERT(.pass,.fail,conn>0,"server accepted the connection")
        do true^STDASSERT(.pass,.fail,$$write^STDNET(cli,msg),"client wrote the CRLF-bearing message")
        ; A socket read returns *available* bytes (may chunk); accumulate up to len.
        set got="",n=1
        for  quit:('n)!($length(got)'<$length(msg))  do
        . set n=$$read^STDNET(conn,16384,5,.buf)
        . set got=got_buf
        do eq^STDASSERT(.pass,.fail,$length(got),$length(msg),"byte count matches end to end")
        do eq^STDASSERT(.pass,.fail,got,msg,"bytes round-trip byte-exact (CRLF preserved)")
        ; Belt-and-suspenders: assert $ascii at every position is identical.
        set b=1
        for i=1:1:$length(msg) set:$ascii(got,i)'=$ascii(msg,i) b=0
        do true^STDASSERT(.pass,.fail,b,"every byte position matches by $ascii")
        set n=$$close^STDNET(cli),n=$$close^STDNET(conn),n=$$close^STDNET(srv)
        quit
        ;
tPeerClosedDrainsThenEof(pass,fail)     ;@TEST "a read on a PEER-CLOSED socket drains the buffered bytes then EOFs (no job abort)"
        ; Regression for the IRIS readIris peer-closed defect (GAP 2): a $$read on a
        ; socket whose peer has already $$close'd raised an IRIS <DSCON>-class
        ; disconnect that KILLED the job (aborting the suite to 0/0) instead of
        ; yielding the buffered bytes and then EOF. YDB already drains + EOFs. The
        ; fix traps the disconnect (IRIS-arm only) so this case completes on BOTH
        ; engines and `report` fires. The peer writes a few bytes then closes; the
        ; read side must return those bytes, then 0 (EOF), without faulting.
        new srv,cli,conn,port,buf,n,got
        if '$$available^STDNET() do true^STDASSERT(.pass,.fail,1,"sockets not wired here - skipped") quit
        set srv=$$listen^STDNET(0)
        do true^STDASSERT(.pass,.fail,srv>0,"listener opened")
        set port=$$boundport^STDNET(srv)
        set cli=$$connect^STDNET("127.0.0.1",port,5)
        do true^STDASSERT(.pass,.fail,cli>0,"client connected")
        set conn=$$accept^STDNET(srv,5)
        do true^STDASSERT(.pass,.fail,conn>0,"server accepted the connection")
        ; client writes a few bytes then CLOSES it (peer close) before the server reads.
        do true^STDASSERT(.pass,.fail,$$write^STDNET(cli,"bye"),"client wrote then closed")
        set n=$$close^STDNET(cli)
        ; server drains: a socket read returns *available* bytes (may chunk), so
        ; accumulate until a read returns 0 (EOF) - it must NOT abort the job.
        set got="",n=1
        for  quit:'n  set n=$$read^STDNET(conn,16384,2,.buf),got=got_buf
        do eq^STDASSERT(.pass,.fail,got,"bye","peer-closed read drained the buffered bytes")
        set n=$$read^STDNET(conn,16384,2,.buf)
        do eq^STDASSERT(.pass,.fail,n,0,"a further read on the closed peer returns 0 (EOF) without aborting")
        set n=$$close^STDNET(conn),n=$$close^STDNET(srv)
        quit
