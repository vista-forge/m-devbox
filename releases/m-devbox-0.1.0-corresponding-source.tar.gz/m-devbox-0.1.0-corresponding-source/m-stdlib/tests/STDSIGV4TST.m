STDSIGV4TST     ; Test suite for STDSIGV4 (AWS Signature Version 4 signer).
        ; doc: @tier optional
        ; m-lint: disable-file=M-MOD-020
        ; Known-answer vectors derived from an independent Python (hmac/hashlib)
        ; oracle; the S3 GET signature + canonical-request hash match AWS's
        ; published "Authenticating Requests: Authorization Header" S3 example
        ; byte-for-byte (the G-SIGV4 raw-byte-chain gate, S3 design §6).
        ; Run via `make test-optional` (depends on STDCRYPTO call-outs).
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tEmptyHash(.pass,.fail)
        do tSigningKeyKnownAnswer(.pass,.fail)
        do tEncPathPreservesSlash(.pass,.fail)
        do tEncPathEncodesSpace(.pass,.fail)
        do tEncQuerySortsAndEncodes(.pass,.fail)
        do tCanonRequestS3Get(.pass,.fail)
        do tSignS3GetKnownAnswer(.pass,.fail)
        do tAuthHeaderS3Get(.pass,.fail)
        do tAmzDateFormat(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; ---------- fixtures ----------
        ;
s3GetCtx(ctx)   ; AWS S3 GET-Object documented example credential context
        set ctx("accessKey")="AKIAIOSFODNN7EXAMPLE"
        set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        set ctx("region")="us-east-1",ctx("service")="s3"
        quit
        ;
s3GetHeaders(h) ; signed headers of the S3 GET-Object example
        set h("host")="examplebucket.s3.amazonaws.com"
        set h("range")="bytes=0-9"
        set h("x-amz-content-sha256")="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        set h("x-amz-date")="20130524T000000Z"
        quit
        ;
        ; ---------- tests ----------
        ;
tEmptyHash(pass,fail)   ;@TEST "emptyHash() is the canonical empty-payload SHA-256"
        do eq^STDASSERT(.pass,.fail,$$emptyHash^STDSIGV4(),"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","empty SHA-256")
        quit
        ;
tSigningKeyKnownAnswer(pass,fail)       ;@TEST "signingKey() raw-byte chain matches the known answer"
        new key,secret
        set secret="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        set key=$$signingKey^STDSIGV4(secret,"20150830","us-east-1","iam")
        do eq^STDASSERT(.pass,.fail,$$encode^STDHEX(key),"2c94c0cf5378ada6887f09bb697df8fc0affdb34ba1cdd5bda32b664bd55b73c","signing key hex")
        quit
        ;
tEncPathPreservesSlash(pass,fail)       ;@TEST "encPath() URI-encodes but keeps the path separator"
        do eq^STDASSERT(.pass,.fail,$$encPath^STDSIGV4("vista/2026/06/site508.ndjson"),"vista/2026/06/site508.ndjson","slash preserved")
        quit
        ;
tEncPathEncodesSpace(pass,fail) ;@TEST "encPath() percent-encodes a space"
        do eq^STDASSERT(.pass,.fail,$$encPath^STDSIGV4("my key.txt"),"my%20key.txt","space encoded")
        quit
        ;
tEncQuerySortsAndEncodes(pass,fail)     ;@TEST "encQuery() sorts keys and URI-encodes value"
        new q
        set q("prefix")="vista/2026/06/",q("list-type")=2
        do eq^STDASSERT(.pass,.fail,$$encQuery^STDSIGV4(.q),"list-type=2&prefix=vista%2F2026%2F06%2F","sorted+encoded query")
        quit
        ;
tCanonRequestS3Get(pass,fail)   ;@TEST "canonRequest() hashes to the AWS S3 example value"
        new h,signed,cr,phash
        do s3GetHeaders(.h)
        set phash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        set cr=$$canonRequest^STDSIGV4("GET","/test.txt","",.h,phash,.signed)
        do eq^STDASSERT(.pass,.fail,signed,"host;range;x-amz-content-sha256;x-amz-date","signed headers list")
        do eq^STDASSERT(.pass,.fail,$$sha256^STDCRYPTO(cr),"7344ae5b7ee6c3e7e6b0fe0640412a37625d1fbfff95c48bbb2dc43964946972","canonical request hash")
        quit
        ;
tSignS3GetKnownAnswer(pass,fail)        ;@TEST "sign() reproduces the AWS S3 example signature"
        new ctx,h,phash,sig
        do s3GetCtx(.ctx),s3GetHeaders(.h)
        set phash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        set sig=$$sign^STDSIGV4(.ctx,"GET","/test.txt","",.h,phash,"20130524T000000Z","20130524")
        do eq^STDASSERT(.pass,.fail,sig,"f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","S3 GET signature")
        quit
        ;
tAuthHeaderS3Get(pass,fail)     ;@TEST "authHeader() embeds credential scope, signed headers and signature"
        new ctx,h,phash,auth
        do s3GetCtx(.ctx),s3GetHeaders(.h)
        set phash="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        set auth=$$authHeader^STDSIGV4(.ctx,"GET","/test.txt","",.h,phash,"20130524T000000Z","20130524")
        do contains^STDASSERT(.pass,.fail,auth,"AWS4-HMAC-SHA256 ","algorithm prefix")
        do contains^STDASSERT(.pass,.fail,auth,"Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request","credential scope")
        do contains^STDASSERT(.pass,.fail,auth,"SignedHeaders=host;range;x-amz-content-sha256;x-amz-date","signed headers")
        do contains^STDASSERT(.pass,.fail,auth,"Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","signature")
        quit
        ;
tAmzDateFormat(pass,fail)       ;@TEST "amzDate() is 16-char basic-ISO UTC ending in Z"
        new d
        set d=$$amzDate^STDSIGV4()
        do len^STDASSERT(.pass,.fail,$length(d),16,"length 16")
        do eq^STDASSERT(.pass,.fail,$extract(d,9),"T","T separator at 9")
        do eq^STDASSERT(.pass,.fail,$extract(d,16),"Z","trailing Z")
        do true^STDASSERT(.pass,.fail,$extract(d,1,8)?8N,"date part all digits")
        quit
        ;
