STDS3MINIOTST   ; STDS3 end-to-end round-trip suite against a local MinIO sink.
        ; doc: @tier optional
        ; m-lint: disable-file=M-MOD-020
        ; INTEGRATION suite — requires the MinIO testbed (scripts/s3-testbed.sh up)
        ; reachable from inside the engine at http://m-s3-minio:9000. It exercises
        ; the REAL request-build + SigV4-sign + HTTP path against an S3-compatible
        ; store (the §15.1 local S3-equivalent): PUT -> GET (byte-equal) -> LIST ->
        ; DELETE -> GET(404), incl. a control-byte body to prove byte-fidelity.
        ; NOT in OPTIONAL_SUITES (no MinIO in plain `make test-optional`); run via
        ; `make test-s3`. Throwaway creds, hardcoded to mirror scripts/s3-testbed.sh.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tPutGetRoundTrip(.pass,.fail)
        do tBinaryByteFidelity(.pass,.fail)
        do tListFindsKey(.pass,.fail)
        do tDeleteThen404(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; ---------- fixtures ----------
        ;
cfg(ctx,opt)    ; MinIO testbed credential context + path-style endpoint
        set ctx("accessKey")="minioadmin"
        set ctx("secretKey")="minioadmin"
        set ctx("region")="us-east-1",ctx("service")="s3"
        set opt("endpoint")="http://m-s3-minio:9000"
        quit
        ;
bucket()        ; the pre-created testbed bucket
        quit "vista-test-logs"
        ;
        ; ---------- tests ----------
        ;
tPutGetRoundTrip(pass,fail)     ;@TEST "putObject then getObject returns the same NDJSON bytes"
        new ctx,opt,resp,sc,key,body
        do cfg(.ctx,.opt)
        set opt("contentType")="application/x-ndjson"
        set key="stds3test/a.ndjson"
        set body="{""ts"":""2026-06-19"",""level"":""info"",""msg"":""round-trip""}"_$char(10)
        set sc=$$putObject^STDS3(.ctx,$$bucket(),key,body,.opt,.resp)
        do eq^STDASSERT(.pass,.fail,sc,200,"PUT status 200 (err="_$get(resp("error","code"))_")")
        kill resp
        set sc=$$getObject^STDS3(.ctx,$$bucket(),key,.opt,.resp)
        do eq^STDASSERT(.pass,.fail,sc,200,"GET status 200")
        do eq^STDASSERT(.pass,.fail,$get(resp("body")),body,"GET body equals PUT body")
        quit
        ;
tBinaryByteFidelity(pass,fail)  ;@TEST "a control-byte body round-trips byte-for-byte"
        new ctx,opt,resp,sc,key,body,i
        do cfg(.ctx,.opt)
        set key="stds3test/bin.dat"
        ; bytes 0..31 + 200..255 + a $C(1)-delimited fragment (RPC-envelope shape)
        set body=""
        for i=0:1:31 set body=body_$char(i)
        set body=body_"PART"_$char(1)_"A"_$char(1)_"B"
        for i=200:1:255 set body=body_$char(i)
        set sc=$$putObject^STDS3(.ctx,$$bucket(),key,body,.opt,.resp)
        do eq^STDASSERT(.pass,.fail,sc,200,"PUT binary status 200 (err="_$get(resp("error","code"))_")")
        kill resp
        set sc=$$getObject^STDS3(.ctx,$$bucket(),key,.opt,.resp)
        do eq^STDASSERT(.pass,.fail,sc,200,"GET binary status 200")
        do eq^STDASSERT(.pass,.fail,$length($get(resp("body"))),$length(body),"binary length preserved")
        do eq^STDASSERT(.pass,.fail,$get(resp("body")),body,"binary bytes identical")
        quit
        ;
tListFindsKey(pass,fail)        ;@TEST "listObjectsV2 returns the keys under the test prefix"
        new ctx,opt,listing,sc,i,found
        do cfg(.ctx,.opt)
        set sc=$$listObjectsV2^STDS3(.ctx,$$bucket(),"stds3test/",.opt,.listing)
        do eq^STDASSERT(.pass,.fail,sc,200,"LIST status 200")
        set found=0,i=""
        for  set i=$order(listing(i)) quit:i=""  if $get(listing(i,"key"))="stds3test/a.ndjson" set found=1
        do true^STDASSERT(.pass,.fail,found,"listing contains stds3test/a.ndjson")
        quit
        ;
tDeleteThen404(pass,fail)       ;@TEST "deleteObject removes the key and a subsequent GET is 404"
        new ctx,opt,resp,sc,key
        do cfg(.ctx,.opt)
        set key="stds3test/a.ndjson"
        set sc=$$deleteObject^STDS3(.ctx,$$bucket(),key,.opt)
        do true^STDASSERT(.pass,.fail,(sc=204)!(sc=200),"DELETE status 204/200 (got "_sc_")")
        kill resp
        set sc=$$getObject^STDS3(.ctx,$$bucket(),key,.opt,.resp)
        do eq^STDASSERT(.pass,.fail,sc,404,"GET after delete is 404")
        quit
        ;
