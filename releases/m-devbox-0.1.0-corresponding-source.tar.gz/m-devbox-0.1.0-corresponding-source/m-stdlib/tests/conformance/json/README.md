# JSON conformance vectors

Vendored test vectors for `STDJSON` (Phase 2 module — track L11). Sources of
truth:

- [RFC 8259 — The JavaScript Object Notation (JSON) Data Interchange Format](https://datatracker.ietf.org/doc/html/rfc8259)
- [JSONTestSuite](https://github.com/nst/JSONTestSuite) by Nicolas Seriot
  (CC BY-SA 4.0). The naming convention (`y_*` / `n_*` / `i_*`) is
  borrowed from JSONTestSuite, but only a representative subset is
  vendored here so the corpus stays auditable by eye.

## Layout

| Subdirectory | Contract |
|---|---|
| `y/` | **Must parse.** Conforming RFC-8259 inputs. A parser that rejects any of these is non-conformant. |
| `n/` | **Must reject.** Inputs that violate RFC-8259. A parser that accepts any of these is non-conformant. |
| `i/` | **Implementation-defined.** Inputs the spec leaves to the implementation (extreme numbers, lone surrogates, duplicate keys, embedded NULs). STDJSON's behaviour on each of these is documented in `docs/modules/stdjson.md` once L11 lands. |

## Coverage map (RFC-8259)

### y/ — must parse

| File | RFC § | What it covers |
|---|---|---|
| `y_object_empty.json` | §4 | Empty object `{}` |
| `y_object_basic.json` | §4 | Single-pair object |
| `y_object_string_keys.json` | §4 | Multi-pair object, string keys |
| `y_array_empty.json` | §5 | Empty array `[]` |
| `y_array_basic.json` | §5 | Numeric array |
| `y_array_mixed.json` | §5, §3, §4 | Heterogeneous: number, string, true, false, null, object, nested array |
| `y_string_empty.json` | §7 | `""` |
| `y_string_basic.json` | §7 | ASCII-only string |
| `y_string_escapes.json` | §7 | Every two-char escape: `\\ \" \/ \b \f \n \r \t` |
| `y_string_unicode_escape.json` | §7 | `\uXXXX` BMP escapes |
| `y_string_surrogate_pair.json` | §7 | Valid `𝄞` pair (G clef, U+1D11E) |
| `y_number_int.json` | §6 | Positive integer |
| `y_number_negative.json` | §6 | Negative integer |
| `y_number_zero.json` | §6 | The single zero (no `00`, no `+0`) |
| `y_number_frac.json` | §6 | Fractional part |
| `y_number_exp.json` | §6 | Lowercase `e` exponent |
| `y_number_neg_exp.json` | §6 | Uppercase `E` with negative exponent |
| `y_number_large.json` | §6 | 16-digit integer (within JS-safe-int range) |
| `y_true.json` | §3 | Literal `true` |
| `y_false.json` | §3 | Literal `false` |
| `y_null.json` | §3 | Literal `null` |
| `y_whitespace_around.json` | §2 | Tabs, spaces, newlines around tokens (the four insignificant whitespace bytes) |
| `y_nested_deep.json` | §4, §5 | 5-deep array nesting (well within any sane limit) |

### n/ — must reject

| File | What it covers |
|---|---|
| `n_trailing_comma_obj.json` | `{"a":1,}` — RFC-8259 disallows trailing commas |
| `n_trailing_comma_arr.json` | `[1,2,]` — same |
| `n_unquoted_key.json` | `{a:1}` — keys must be quoted strings (§4) |
| `n_single_quotes.json` | `'string'` — only `"` is allowed (§7) |
| `n_leading_zero.json` | `01` — §6 forbids leading zeros |
| `n_lone_decimal.json` | `.5` — §6 requires `int` before `frac` |
| `n_missing_colon.json` | `{"a" 1}` — name/value separator required (§4) |
| `n_unclosed_obj.json` | `{"a":1` — truncation |
| `n_unclosed_arr.json` | `[1,2` — truncation |
| `n_unclosed_str.json` | `"abc` — truncation |
| `n_garbage.json` | `zomg` — not a JSON token |
| `n_unescaped_ctrl.json` | Literal `0x01` byte inside a string body (§7 forbids control chars in strings) |
| `n_trailing_garbage.json` | `{...}extra` — text after a complete JSON value |
| `n_double_plus.json` | `++` — not a valid number |
| `n_missing_array_comma.json` | `[1 2]` — values must be comma-separated (§5) |

### i/ — implementation-defined

| File | What it covers |
|---|---|
| `i_number_huge_exp.json` | `1e400` — exceeds IEEE-754 double range |
| `i_number_tiny_exp.json` | `1e-400` — underflows to 0 in IEEE-754 double |
| `i_string_lone_high_surrogate.json` | `\uD834` with no paired low surrogate |
| `i_string_lone_low_surrogate.json` | `\uDD1E` with no paired high surrogate |
| `i_object_duplicate_key.json` | `{"a":1,"a":2}` — RFC-8259 §4 says behaviour is unpredictable |
| `i_string_invalid_utf8.json` | Stray byte `0xFF` inside a string body |
| `i_number_int_overflow_64.json` | 20-digit integer beyond `int64` range |
| `i_string_embedded_null_escape.json` | `"\u0000"` — valid per §7, but most languages dislike NUL in strings |

## Why curated, not full

The full JSONTestSuite is ~318 files. This corpus instead vendors ~46
hand-picked files that directly trace to RFC-8259 clauses or to a
specific named ambiguity, so:

1. The corpus fits in one screen of `ls`.
2. Every file maps back to a specific section/decision (this README).
3. New cases can be added narrowly without ballooning the suite.

When STDJSON ships, additional fuzz / property-test corpora can live
alongside this directory under their own subfolders (e.g.
`tests/conformance/json/fuzz/`).

## See also

- [implementation plan §5](../../../docs/m-stdlib-implementation-plan.md#5-project-layout)
  for the canonical `tests/conformance/` layout.
- `docs/modules/stdjson.md` — written once track L11 lands.
