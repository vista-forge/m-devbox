# `tests/` — unit test suites (hand-written)

One `STD*TST.m` suite per module, hand-written **TDD-first** and asserting
through `^STDASSERT`. This is m-stdlib's **correctness specification**: edge
cases, error/`$ECODE` contracts, conformance corpora (RFC vectors, round-trips),
and fixture-isolated setup/teardown. When an example and a test disagree, the
test is the source of truth.

This is one of three verification surfaces — see
[`docs/guides/verification-surfaces.md`](../docs/guides/verification-surfaces.md)
for how `tests/` relates to the generated `examples/programs/*EX.m` and the
hand-written `examples/*-demo.m`.

- **Run:** `make test` (core) · `make test-optional` (call-out modules) ·
  `make coverage` (aggregate ≥ 85%).
- **Conformance vectors** live under `tests/conformance/`.
- **Add a test:** write the failing `STD*TST.m` case first, then implement in
  `src/STD*.m` until green. See [`docs/guides/m-tdd-guide.md`](../docs/guides/m-tdd-guide.md).
