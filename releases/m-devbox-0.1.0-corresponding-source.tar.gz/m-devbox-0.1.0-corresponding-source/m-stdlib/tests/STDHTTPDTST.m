STDHTTPDTST    ; m-stdlib — STDHTTPD (portable HTTP server framework) test suite.
        ; m-lint: disable-file=M-MOD-020
        ; Exercises the engine-agnostic HTTP server framework — the §6 router +
        ; middleware chain + the §4 per-connection worker request/response loop —
        ; that sits on the M6.1 STDHTTPMSG codec and below the VistA-specific
        ; vweb listener (M6.3+). Pure-M, dual-engine: no sockets, no TLS, no
        ; VistA, no $ZF. The worker loop is driven by an INJECTED transport — an
        ; in-memory fake here (XPORT) preloaded with request bytes whose written
        ; response bytes are captured back — so the whole framework is unit
        ; tested with zero network. Fake handlers / middleware / log hook are
        ; tags in this routine, reached from STDHTTPD via M indirection (Q2);
        ; they see the test-frame locals (XPORT/LOG/HITS) by dynamic scope.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        ; ---------- router: $$route + $$match (§6) ----------
        do tMatchSimple(.pass,.fail)
        do tMatchNoRoute(.pass,.fail)
        do tMatchMethodMismatch(.pass,.fail)
        do tMatchWildcard(.pass,.fail)
        do tMatchTrailingSlash(.pass,.fail)
        do tMatchStarMethod(.pass,.fail)
        do tMatchFirstWins(.pass,.fail)
        ;
        ; ---------- middleware chain (§6/§7) ----------
        do tMiddlewareOrder(.pass,.fail)
        do tMiddlewareShortCircuit(.pass,.fail)
        do tBuiltinRequestId(.pass,.fail)
        ;
        ; ---------- $$dispatch (single request pipeline) ----------
        do tDispatchHandler(.pass,.fail)
        do tDispatch404(.pass,.fail)
        do tDispatch405(.pass,.fail)
        do tDispatchHandlerFault(.pass,.fail)
        do tIndirectionByRef(.pass,.fail)
        ;
        ; ---------- worker loop: $$serve over the fake transport (§4) ----------
        do tServeGetExchange(.pass,.fail)
        do tServeKeepAlive(.pass,.fail)
        do tServeParseError(.pass,.fail)
        do tServeFramingCap(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; ================= router tests =================
        ;
tMatchSimple(pass,fail) ;@TEST "match extracts named :segments into params; method+path hit -> 200"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,200,"GET /Patient/123 matches -> 200")
        do eq^STDASSERT(.pass,.fail,params("id"),"123","named :id captured")
        do eq^STDASSERT(.pass,.fail,route("handler"),"get^STDHTTPDTST","handler returned")
        do eq^STDASSERT(.pass,.fail,route("method"),"GET","method returned")
        quit
        ;
tMatchNoRoute(pass,fail)        ;@TEST "no route matches the path -> 404"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/Observation/9",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,404,"unmatched path -> 404")
        quit
        ;
tMatchMethodMismatch(pass,fail) ;@TEST "path matches but method does not -> 405 + Allow"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        do route^STDHTTPD(.SRV,"PUT","/Patient/:id","put^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"DELETE","/Patient/123",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,405,"method mismatch -> 405")
        do eq^STDASSERT(.pass,.fail,route("allow"),"GET, PUT","Allow lists path's methods")
        quit
        ;
tMatchWildcard(pass,fail)       ;@TEST "trailing * captures the remainder into params(*)"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/files/*","files^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/files/a/b/c.txt",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,200,"wildcard route matches -> 200")
        do eq^STDASSERT(.pass,.fail,params("*"),"a/b/c.txt","remainder captured")
        quit
        ;
tMatchTrailingSlash(pass,fail)  ;@TEST "a trailing slash on path or pattern is insignificant"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/Patient","list^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/Patient/",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,200,"trailing-slash path still matches")
        quit
        ;
tMatchStarMethod(pass,fail)     ;@TEST "a * method route matches any verb"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"*","/healthz","health^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/healthz",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,200,"* method matches GET")
        set st=$$match^STDHTTPD(.SRV,"POST","/healthz",.route,.params)
        do eq^STDASSERT(.pass,.fail,st,200,"* method matches POST")
        quit
        ;
tMatchFirstWins(pass,fail)      ;@TEST "first-registered route wins on overlap (deterministic)"
        new SRV,route,params,st
        do route^STDHTTPD(.SRV,"GET","/a/:x","first^STDHTTPDTST")
        do route^STDHTTPD(.SRV,"GET","/a/:y","second^STDHTTPDTST")
        set st=$$match^STDHTTPD(.SRV,"GET","/a/7",.route,.params)
        do eq^STDASSERT(.pass,.fail,route("handler"),"first^STDHTTPDTST","earliest registration wins")
        quit
        ;
        ; ================= middleware tests =================
        ;
tMiddlewareOrder(pass,fail)     ;@TEST "middleware run in registration order before the handler"
        new SRV,REQ,RSP,st,HITS
        do use^STDHTTPD(.SRV,"mwA^STDHTTPDTST")
        do use^STDHTTPD(.SRV,"mwB^STDHTTPDTST")
        do route^STDHTTPD(.SRV,"GET","/x","mark^STDHTTPDTST")
        set REQ("method")="GET",REQ("path")="/x"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,$get(HITS),"A,B,H","mwA then mwB then handler")
        quit
        ;
tMiddlewareShortCircuit(pass,fail)      ;@TEST "a middleware may short-circuit; handler never runs"
        new SRV,REQ,RSP,st,HITS
        do use^STDHTTPD(.SRV,"deny^STDHTTPDTST")
        do route^STDHTTPD(.SRV,"GET","/x","mark^STDHTTPDTST")
        set REQ("method")="GET",REQ("path")="/x"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,RSP("status"),401,"middleware set 401")
        do eq^STDASSERT(.pass,.fail,$get(HITS),"","handler never ran (no H)")
        quit
        ;
tBuiltinRequestId(pass,fail)    ;@TEST "the built-in requestId middleware stamps CTX(requestid)"
        new REQ,RSP,CTX
        do requestId^STDHTTPD(.REQ,.RSP,.CTX)
        do true^STDASSERT(.pass,.fail,$get(CTX("requestid"))'="","requestid populated")
        quit
        ;
        ; ================= $$dispatch tests =================
        ;
tDispatchHandler(pass,fail)     ;@TEST "dispatch routes to the handler, which populates RSP"
        new SRV,REQ,RSP,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        set REQ("method")="GET",REQ("path")="/Patient/42"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,st,200,"dispatch -> 200")
        do eq^STDASSERT(.pass,.fail,RSP("status"),200,"handler set status 200")
        do eq^STDASSERT(.pass,.fail,RSP("json","id"),"s:42","handler echoed the :id param")
        quit
        ;
tDispatch404(pass,fail) ;@TEST "dispatch with no matching route -> 404 sanitized RSP"
        new SRV,REQ,RSP,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        set REQ("method")="GET",REQ("path")="/nope"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,st,404,"dispatch -> 404")
        do eq^STDASSERT(.pass,.fail,RSP("status"),404,"RSP status 404")
        quit
        ;
tDispatch405(pass,fail) ;@TEST "dispatch method mismatch -> 405 with Allow header"
        new SRV,REQ,RSP,st
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        set REQ("method")="POST",REQ("path")="/Patient/42"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,st,405,"dispatch -> 405")
        do eq^STDASSERT(.pass,.fail,RSP("hdr","Allow"),"GET","405 carries Allow")
        quit
        ;
tDispatchHandlerFault(pass,fail)        ;@TEST "an uncaught handler fault -> 500 sanitized; detail to the log hook only"
        new SRV,REQ,RSP,st,LOG,opts,body
        do route^STDHTTPD(.SRV,"GET","/boom","boom^STDHTTPDTST")
        set REQ("method")="GET",REQ("path")="/boom"
        set opts("logref")="log^STDHTTPDTST"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP,.opts)
        do eq^STDASSERT(.pass,.fail,st,500,"handler fault -> 500")
        do eq^STDASSERT(.pass,.fail,RSP("status"),500,"RSP status 500")
        do eq^STDASSERT(.pass,.fail,$get(LOG("type")),"error","log hook fired with an error event")
        do true^STDASSERT(.pass,.fail,$get(LOG("detail"))'="","fault detail captured by the log hook")
        ; the sanitized body must not leak the internal detail
        set body=$$bodyOf(.RSP)
        do false^STDASSERT(.pass,.fail,body[$get(LOG("detail")),"detail not leaked into the HTTP body")
        quit
        ;
tIndirectionByRef(pass,fail)    ;@TEST "Q2: do @ref(.REQ,.RSP) passes arrays by reference (YDB==IRIS)"
        new SRV,REQ,RSP,st
        do route^STDHTTPD(.SRV,"POST","/echo","echo^STDHTTPDTST")
        set REQ("method")="POST",REQ("path")="/echo",REQ("body")="ping"
        set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP)
        do eq^STDASSERT(.pass,.fail,RSP("body"),"ping","handler read REQ + wrote RSP by reference")
        quit
        ;
        ; ================= worker-loop tests =================
        ;
tServeGetExchange(pass,fail)    ;@TEST "serve runs a full request/response cycle over the fake transport"
        new SRV,TR,XPORT,conn,n,R2,st,cr
        set cr=$char(13,10),conn="c1"
        do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^STDHTTPDTST")
        do fakeTransport(.TR)
        set XPORT(conn,"in")="GET /Patient/55 HTTP/1.1"_cr_"Host: x"_cr_"Connection: close"_cr_cr
        set n=$$serve^STDHTTPD(.SRV,.TR,conn)
        do eq^STDASSERT(.pass,.fail,n,1,"one request served")
        set st=$$parseRsp^STDHTTPMSG($get(XPORT(conn,"out")),.R2)
        do eq^STDASSERT(.pass,.fail,st,200,"written response re-parses cleanly")
        do eq^STDASSERT(.pass,.fail,R2("status"),200,"status 200 on the wire")
        do eq^STDASSERT(.pass,.fail,R2("body"),"{""id"":""55""}","handler JSON body on the wire")
        quit
        ;
tServeKeepAlive(pass,fail)      ;@TEST "serve loops keep-alive requests on one connection until Connection: close"
        new SRV,TR,XPORT,conn,n,cr,req1,req2,nresp
        set cr=$char(13,10),conn="k1"
        do route^STDHTTPD(.SRV,"GET","/healthz","health^STDHTTPDTST")
        do fakeTransport(.TR)
        set req1="GET /healthz HTTP/1.1"_cr_"Host: x"_cr_cr
        set req2="GET /healthz HTTP/1.1"_cr_"Host: x"_cr_"Connection: close"_cr_cr
        set XPORT(conn,"in")=req1_req2
        set n=$$serve^STDHTTPD(.SRV,.TR,conn)
        do eq^STDASSERT(.pass,.fail,n,2,"both pipelined requests served on one connection")
        set nresp=$length($get(XPORT(conn,"out")),"HTTP/1.1 200")-1
        do eq^STDASSERT(.pass,.fail,nresp,2,"two responses written")
        quit
        ;
tServeParseError(pass,fail)     ;@TEST "a malformed request -> the matching 4xx written, connection closed"
        new SRV,TR,XPORT,conn,n,R2,st,cr
        set cr=$char(13,10),conn="p1"
        do route^STDHTTPD(.SRV,"GET","/x","mark^STDHTTPDTST")
        do fakeTransport(.TR)
        ; complete headers (CRLFCRLF) but a request line with too few tokens -> 400
        set XPORT(conn,"in")="GET /x"_cr_"Host: x"_cr_cr
        set n=$$serve^STDHTTPD(.SRV,.TR,conn)
        set st=$$parseRsp^STDHTTPMSG($get(XPORT(conn,"out")),.R2)
        do eq^STDASSERT(.pass,.fail,R2("status"),400,"malformed request -> 400 on the wire")
        quit
        ;
tServeFramingCap(pass,fail)     ;@TEST "headers exceeding the cap before terminator -> 431, connection closed"
        new SRV,TR,XPORT,conn,n,R2,opts,cr,i,big
        set cr=$char(13,10),conn="f1"
        do route^STDHTTPD(.SRV,"GET","/x","mark^STDHTTPDTST")
        do fakeTransport(.TR)
        set big="GET /x HTTP/1.1"_cr
        for i=1:1:50 set big=big_"X-Pad-"_i_": aaaaaaaaaaaaaaaaaaaa"_cr
        ; no CRLFCRLF terminator and over a tiny cap
        set XPORT(conn,"in")=big
        set opts("maxhdrbytes")=256
        set n=$$serve^STDHTTPD(.SRV,.TR,conn,.opts)
        do eq^STDASSERT(.pass,.fail,$$parseRsp^STDHTTPMSG($get(XPORT(conn,"out")),.R2),200,"a response was written")
        do eq^STDASSERT(.pass,.fail,R2("status"),431,"oversized headers -> 431")
        quit
        ;
        ; ================= fakes (reached via indirection from STDHTTPD) =================
        ;
fakeTransport(TR)       ; Wire the in-memory read/write entry-refs into a transport descriptor.
        set TR("read")="fakeRead^STDHTTPDTST"
        set TR("write")="fakeWrite^STDHTTPDTST"
        quit
        ;
fakeRead(conn,max,timeout,buf)  ; Read up to `max` bytes from XPORT(conn,"in"); 0 on EOF.
        new avail,take
        set avail=$get(XPORT(conn,"in")),buf=""
        if avail="" quit 0
        set take=$extract(avail,1,max),buf=take
        set XPORT(conn,"in")=$extract(avail,max+1,$length(avail))
        quit $length(take)
        ;
fakeWrite(conn,bytes)   ; Append written bytes to XPORT(conn,"out").
        set XPORT(conn,"out")=$get(XPORT(conn,"out"))_bytes
        quit 1
        ;
log(EV) ; Fake log hook — capture the event into the test-frame LOG array.
        merge LOG=EV
        quit
        ;
        ; ----- fake handlers -----
        ;
get(REQ,RSP)    ; Echo the :id path param as a JSON object.
        set RSP("status")=200,RSP("json")="o",RSP("json","id")="s:"_$get(REQ("param","id"))
        quit
        ;
put(REQ,RSP)    ; Minimal handler.
        set RSP("status")=200
        quit
        ;
list(REQ,RSP)   ; Minimal handler.
        set RSP("status")=200
        quit
        ;
files(REQ,RSP)  ; Minimal handler.
        set RSP("status")=200
        quit
        ;
health(REQ,RSP) ; Liveness handler.
        set RSP("status")=200,RSP("body")="ok"
        quit
        ;
first(REQ,RSP)  ; Overlap handler A.
        set RSP("status")=200
        quit
        ;
second(REQ,RSP) ; Overlap handler B.
        set RSP("status")=200
        quit
        ;
mark(REQ,RSP)   ; Record that the handler ran (appends H to HITS).
        set HITS=$get(HITS)_$select($get(HITS)="":"",1:",")_"H",RSP("status")=200
        quit
        ;
echo(REQ,RSP)   ; Copy REQ body into RSP body (by-ref round-trip).
        set RSP("status")=200,RSP("body")=$get(REQ("body"))
        quit
        ;
boom(REQ,RSP)   ; Deliberately fault (divide by zero — runtime only) to exercise the 500 trap.
        new x
        set x=1/$length("")
        set RSP("body")="unreached"
        quit
        ;
        ; ----- fake middleware -----
        ;
mwA(REQ,RSP,CTX)        ; Append A to HITS.
        set HITS=$get(HITS)_$select($get(HITS)="":"",1:",")_"A"
        quit
        ;
mwB(REQ,RSP,CTX)        ; Append B to HITS.
        set HITS=$get(HITS)_$select($get(HITS)="":"",1:",")_"B"
        quit
        ;
deny(REQ,RSP,CTX)       ; Short-circuit with 401 (auth-fail shape).
        set RSP("status")=401,CTX("stop")=1
        quit
        ;
        ; ----- small helper -----
        ;
bodyOf(RSP)     ; Serialize RSP and return just the body (bytes after CRLFCRLF).
        new raw,bp,sep
        set sep=$char(13,10,13,10),raw=$$serializeRsp^STDHTTPMSG(.RSP),bp=$find(raw,sep)
        quit $extract(raw,bp,$length(raw))
        ;
