STDCAPDOCTST    ; m-stdlib — engine capability DOCTOR (KAT per callout tier).
        ; m-lint: disable-file=M-MOD-020
        ; Test labels delegate counters by-ref to STDASSERT helpers; the
        ; by-ref analyser can't see writes through the callee boundary.
        ;
        ; WHY THIS SUITE EXISTS (safety-net-reconciliation P3.1):
        ; The 2026-07-10 test-integrity incident's Phase-4 finding was
        ; provisioning drift that stayed invisible until an orphaned test
        ; finally exercised the missing callout tier (vehu ran a verify-only
        ; std_crypto.so for weeks). The corrective principle (§3): a
        ; capability check must EXERCISE the capability with a Known-Answer
        ; Test, never a presence/shape/version probe. This suite productizes
        ; the incident's ZZCAPTST / ZZSIGTST throwaway probes into one
        ; permanent doctor: one @TEST per callout tier — digest / verify /
        ; sign / compress / http — each a real round-trip KAT.
        ;
        ; PER-TIER ISOLATION (the "names itself instead of aborting" rule):
        ; EVERY KAT here runs through a local, $ETRAP-guarded helper that can
        ; only ever return a clean 0/1 (see the helpers below) — it NEVER
        ; calls a callout bare. So a callout absent (or hard-raising, as the
        ; STDCOMPRESS IRIS backend does on an un-provisioned engine) on one
        ; tier records a loud, NAMED failing assertion for THAT tier while
        ; every other tier still reports. A missing callout can never abort
        ; the run into the incident's 0/0 "all passed" hole. The failing line
        ; names the capability; the underlying $ECODE is the module's own
        ; U-<MOD>-CALLOUT-MISSING.
        ;
        ; PER-ENGINE EXPECTATION IS NOT THIS SUITE'S JOB. The doctor reports
        ; the TRUTH for whatever engine it runs on; which tiers are expected
        ; green on which engine (e.g. libcurl http is a YDB callout; IRIS has
        ; no $&stdhttp) is the `m engine doctor` verb's concern (P3.2) and the
        ; staleness gate's (P3.5). Here every tier simply reports, crash-free.
        ;
        ; TIER: OPTIONAL, and OPTIONAL runs on YDB (m-test-engine) — which CI
        ; seeds std_crypto.so (scripts/seed-engine-callouts.sh) BEFORE the run,
        ; so crypto_verify / crypto_sign are present and all five tiers are
        ; green there. A partial std_crypto.so (present but missing
        ; crypto_verify) is a SEPARATE known hazard: on YDB 7.1 the
        ; missing-symbol call HANGS rather than raising (the P1-N2c owed
        ; STDCRYPTO robustness fix), which no in-process $ETRAP can catch —
        ; this doctor assumes a complete (seeded) .so, exactly the state
        ; `make test-optional` guarantees.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tDigestKat(.pass,.fail)
        do tVerifyKat(.pass,.fail)
        do tSignKat(.pass,.fail)
        do tCompressKat(.pass,.fail)
        do tHttpKat(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; ---------- capability KATs (one @TEST per tier) ----------
        ; Each asserts on a crash-proof $$*Kat() helper below — never a bare
        ; callout — so no tier can abort the suite.
        ;
tDigestKat(pass,fail)   ;@TEST "capability digest: SHA-256 known-answer (libcrypto / IRIS)"
        do true^STDASSERT(.pass,.fail,$$digestKat()=1,"digest capability present (SHA-256 value KAT)")
        quit
        ;
tVerifyKat(pass,fail)   ;@TEST "capability verify: RS256 asymmetric-verify known-answer"
        do true^STDASSERT(.pass,.fail,$$verifyKat()=1,"verify capability present (RS256 verify KAT)")
        quit
        ;
tSignKat(pass,fail)     ;@TEST "capability sign: ES256 sign->verify round-trip known-answer"
        do true^STDASSERT(.pass,.fail,$$signKat()=1,"sign capability present (ES256 sign->verify KAT)")
        quit
        ;
tCompressKat(pass,fail) ;@TEST "capability compress: libz + libzstd round-trip known-answer"
        ; compress is a YDB $&stdcompress callout tier. IRIS routes to a separate
        ; embedded-Python backend whose failure modes (a Python <THROW>) do NOT
        ; unwind cleanly through an M $ETRAP — they hang (STDCOMPRESS irisC note).
        ; So this doctor probes compress on YDB only; on IRIS it asserts scope.
        if $zversion["IRIS" do true^STDASSERT(.pass,.fail,$zversion["IRIS","compress is a YDB-callout tier — not probed on IRIS (embedded-Python backend)") quit
        do true^STDASSERT(.pass,.fail,$$compressKat()=1,"compress capability present (gzip+zstd round-trip KAT)")
        quit
        ;
tHttpKat(pass,fail)     ;@TEST "capability http: libcurl transport init known-answer"
        ; http is a YDB $&stdhttp (libcurl) callout tier with no IRIS backend, so
        ; the doctor probes it on YDB only; on IRIS it asserts scope.
        if $zversion["IRIS" do true^STDASSERT(.pass,.fail,$zversion["IRIS","http is a YDB-callout tier — no IRIS backend to probe") quit
        do true^STDASSERT(.pass,.fail,$$httpKat()=1,"http transport capability present (libcurl init KAT)")
        quit
        ;
        ; ---------- crash-proof KAT helpers (never raise; return 0/1) ----------
        ; Each arms a local $ETRAP that clears $ECODE and quits, so any raise
        ; from a missing/partial callout leaves the pre-set 0 in place and the
        ; caller's assertion still runs (records a NAMED per-tier failure).
        ;
digestKat()     ; 1 iff the SHA-256 value KAT passes.
        ; doc: @internal
        new ok,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        ; $$available^STDCRYPTO already value-compares a fixed digest.
        set ok=+($$available^STDCRYPTO()=1)
        quit ok
        ;
verifyKat()     ; 1 iff the RS256 asymmetric-verify KAT passes.
        ; doc: @internal
        new ok,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        set ok=+($$verifyAvailable^STDCRYPTO()=1)
        quit ok
        ;
signKat()       ; 1 iff an ES256 sign->verify round-trip succeeds.
        ; doc: @internal
        new ok,priv,pub,msg,sig,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        set priv=$$decode^STDHEX($$katSignPriv())
        set pub=$$decode^STDHEX($$katSignPub())
        set msg=$$decode^STDHEX($$katSignMsg())
        set sig=$$signEs256^STDCRYPTO(priv,msg)
        set ok=+($$verifyEs256^STDCRYPTO(pub,msg,sig)=1)
        quit ok
        ;
compressKat()   ; 1 iff gzip->gunzip AND zstd round-trip a known payload by VALUE.
        ; doc: @internal
        ; doc: Bare-calls the callout under a local $ETRAP — the STDCOMPRESS IRIS
        ; doc: embedded-Python backend hard-raises on an un-provisioned engine, so
        ; doc: even $$available^STDCOMPRESS is unsafe to call outside a trap here.
        new ok,buf,raw,payload,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        set payload="m-stdlib capability doctor — round-trip KAT"
        if $$gzip^STDCOMPRESS(payload,.buf),$$gunzip^STDCOMPRESS(buf,.raw),raw=payload,$$zstdCompress^STDCOMPRESS(payload,.buf),$$zstdDecompress^STDCOMPRESS(buf,.raw),raw=payload set ok=1
        quit ok
        ;
httpKat()       ; 1 iff the libcurl callout resolves and curl_easy_init() works.
        ; doc: @internal
        ; doc: available() runs a real curl_easy_init round-trip (not a symbol
        ; doc: probe). No network egress is asserted — that is the live tier.
        new ok,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        set ok=+($$available^STDHTTP()=1)
        quit ok
        ;
        ; ---------- KAT vectors (NON-SECRET test fixtures) ----------
        ; ES256 sign/verify round-trip — fresh EC P-256 pair + RFC 7515 A.3
        ; signing input. Same fixtures as STDCRYPTOTST's sign round-trip.
        ;
katSignPriv()   ; EC P-256 PKCS#8 DER private key (hex; NON-SECRET fixture).
        ; doc: @internal
        new h set h="308187020100301306072a8648ce3d020106082a8648ce3d030107046d306b0201010420fb643cb6b6fe163fd7c5a2eea73605bba0641057"
        set h=h_"3305cb447ddc9687af15a24da14403420004ed48bd33739f3837123b72115dd2fb0e410df018e708de989f6c3c5febec7632f4cfb84173a2"
        set h=h_"90a5e3e8fabe07672548af46ac011ce2caf6e5a8dfebaf12bf9d"
        quit h
        ;
katSignPub()    ; matching EC P-256 SPKI DER public key (hex).
        ; doc: @internal
        new h set h="3059301306072a8648ce3d020106082a8648ce3d03010703420004ed48bd33739f3837123b72115dd2fb0e410df018e708de989f6c3c5feb"
        set h=h_"ec7632f4cfb84173a290a5e3e8fabe07672548af46ac011ce2caf6e5a8dfebaf12bf9d"
        quit h
        ;
katSignMsg()    ; RFC 7515 App A.3 ES256 JWS signing input (hex).
        ; doc: @internal
        new h set h="65794a68624763694f694a46557a49314e694a392e65794a7063334d694f694a71623255694c41304b49434a6c654841694f6a457a4d4441344d54"
        set h=h_"6b7a4f44417344516f67496d6830644841364c79396c654746746347786c4c6d4e76625339706331397962323930496a7030636e566c6651"
        quit h
