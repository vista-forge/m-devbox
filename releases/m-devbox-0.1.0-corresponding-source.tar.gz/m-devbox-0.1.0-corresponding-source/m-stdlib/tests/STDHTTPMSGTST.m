STDHTTPMSGTST   ; m-stdlib — STDHTTPMSG (HTTP/1.1 parse+serialize codec) test suite.
        ; m-lint: disable-file=M-MOD-020
        ; Exercises the portable, dual-engine HTTP/1.1 message codec — the §5
        ; REQ/RSP contract of the VistA-native HTTPS stack (VWEB capstone). The
        ; codec is byte-level only: no sockets, no TLS, no VistA, no $ZF. Every
        ; assertion is byte-exact so the same wire bytes parse identically on
        ; YottaDB and IRIS (the D5 conformance foundation STDHTTPD/VWEBR build on).
        ;
        ; Public surface under test (all extrinsic — call with $$):
        ;   $$parseReq(buf,.REQ,.opts)   -> HTTP status (200 ok; 400/413/414/431)
        ;   $$parseRsp(buf,.RSP,.opts)   -> HTTP status (200 ok; 400/413)
        ;   $$serializeReq(.REQ)         -> request bytes
        ;   $$serializeRsp(.RSP)         -> response bytes
        ;   $$hdr(.MSG,name)             -> case-insensitive header lookup
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        ; ---------- parseReq: request line / path / query / headers ----------
        do tParseGetSimple(.pass,.fail)
        do tParsePercentDecode(.pass,.fail)
        do tParseHeaderCaseInsensitive(.pass,.fail)
        do tParseQueryMultiValue(.pass,.fail)
        do tParseRootPathNoQuery(.pass,.fail)
        ;
        ; ---------- parseReq: body framing ----------
        do tParseBodyContentLength(.pass,.fail)
        do tParseChunked(.pass,.fail)
        do tParseConnectionMgmt(.pass,.fail)
        ;
        ; ---------- parseReq: caps / malformed (status-code returns) ----------
        do tParseReqLineTooLong(.pass,.fail)
        do tParseTooManyHeaders(.pass,.fail)
        do tParseBodyTooLarge(.pass,.fail)
        do tParseMalformed(.pass,.fail)
        ;
        ; ---------- serializeRsp ----------
        do tSerializeRspExact(.pass,.fail)
        do tSerializeRspJson(.pass,.fail)
        do tSerializeRspDefaults(.pass,.fail)
        do tSerializeRspReasonPhrase(.pass,.fail)
        ;
        ; ---------- helpers + round-trips ----------
        do tHdrHelper(.pass,.fail)
        do tRoundTripReq(.pass,.fail)
        do tRoundTripRsp(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
tParseGetSimple(pass,fail)      ;@TEST "parseReq decodes a simple GET into the REQ contract"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET /Patient/123?_count=5 HTTP/1.1"_cr_"Host: vista.example"_cr_"Accept: application/json"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,st,200,"status 200 on a well-formed request")
        do eq^STDASSERT(.pass,.fail,REQ("method"),"GET","method upper-cased")
        do eq^STDASSERT(.pass,.fail,REQ("ver"),"1.1","HTTP version")
        do eq^STDASSERT(.pass,.fail,REQ("path"),"/Patient/123","decoded path, no query")
        do eq^STDASSERT(.pass,.fail,REQ("rawpath"),"/Patient/123","raw path, no query")
        do eq^STDASSERT(.pass,.fail,REQ("query","_count"),"5","query param parsed")
        do eq^STDASSERT(.pass,.fail,REQ("hdr","host"),"vista.example","Host header lower-cased")
        do eq^STDASSERT(.pass,.fail,REQ("hdr","accept"),"application/json","Accept header")
        do eq^STDASSERT(.pass,.fail,REQ("keepalive"),1,"HTTP/1.1 defaults to keep-alive")
        do eq^STDASSERT(.pass,.fail,REQ("body","len"),0,"no body -> length 0")
        quit
        ;
tParsePercentDecode(pass,fail)  ;@TEST "parseReq percent-decodes path and query via STDURL"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET /a%20b/%C3%A9?q=hello%20world HTTP/1.1"_cr_"Host: x"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,st,200,"status 200")
        do eq^STDASSERT(.pass,.fail,REQ("path"),"/a b/"_$char(195)_$char(169),"path percent-decoded byte-faithful")
        do eq^STDASSERT(.pass,.fail,REQ("rawpath"),"/a%20b/%C3%A9","rawpath left encoded")
        do eq^STDASSERT(.pass,.fail,REQ("query","q"),"hello world","query value percent-decoded")
        quit
        ;
tParseHeaderCaseInsensitive(pass,fail)  ;@TEST "header names lower-case for lookup; values preserved"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET / HTTP/1.1"_cr_"HOST: a"_cr_"Content-Type: text/plain"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,REQ("hdr","host"),"a","HOST -> host")
        do eq^STDASSERT(.pass,.fail,REQ("hdr","content-type"),"text/plain","Content-Type -> content-type")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.REQ,"HoSt"),"a","hdr() helper is case-insensitive")
        quit
        ;
tParseQueryMultiValue(pass,fail)        ;@TEST "repeated query params: last-wins scalar + numbered list (D2)"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET /s?a=1&a=2&b=3 HTTP/1.1"_cr_"Host: x"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,REQ("query","a"),"2","last value wins")
        do eq^STDASSERT(.pass,.fail,REQ("query","a",1),"1","first occurrence in list")
        do eq^STDASSERT(.pass,.fail,REQ("query","a",2),"2","second occurrence in list")
        do eq^STDASSERT(.pass,.fail,REQ("query","b"),"3","unrepeated param")
        quit
        ;
tParseRootPathNoQuery(pass,fail)        ;@TEST "parseReq handles a bare / target with no query"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET / HTTP/1.1"_cr_"Host: x"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,st,200,"status 200")
        do eq^STDASSERT(.pass,.fail,REQ("path"),"/","root path")
        do eq^STDASSERT(.pass,.fail,$data(REQ("query")),0,"no query subtree")
        quit
        ;
tParseBodyContentLength(pass,fail)      ;@TEST "parseReq frames a body by Content-Length"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="POST /x HTTP/1.1"_cr_"Host: h"_cr_"Content-Length: 11"_cr_cr_"hello world"
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,st,200,"status 200")
        do eq^STDASSERT(.pass,.fail,REQ("method"),"POST","POST verb")
        do eq^STDASSERT(.pass,.fail,REQ("body"),"hello world","body bytes")
        do eq^STDASSERT(.pass,.fail,REQ("body","len"),11,"decoded content length")
        quit
        ;
tParseChunked(pass,fail)        ;@TEST "parseReq de-chunks Transfer-Encoding: chunked"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="POST /x HTTP/1.1"_cr_"Host: h"_cr_"Transfer-Encoding: chunked"_cr_cr
        set req=req_"5"_cr_"hello"_cr_"6"_cr_" world"_cr_"0"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,st,200,"status 200")
        do eq^STDASSERT(.pass,.fail,REQ("body"),"hello world","de-chunked body assembled")
        do eq^STDASSERT(.pass,.fail,REQ("body","len"),11,"length is the assembled size")
        quit
        ;
tParseConnectionMgmt(pass,fail) ;@TEST "keep-alive vs close per version + Connection header"
        new cr,r,REQ,st
        set cr=$char(13,10)
        set r="GET / HTTP/1.1"_cr_"Connection: close"_cr_cr
        set st=$$parseReq^STDHTTPMSG(r,.REQ)
        do eq^STDASSERT(.pass,.fail,REQ("keepalive"),0,"HTTP/1.1 + close -> 0")
        set r="GET / HTTP/1.0"_cr_"Host: x"_cr_cr
        set st=$$parseReq^STDHTTPMSG(r,.REQ)
        do eq^STDASSERT(.pass,.fail,REQ("keepalive"),0,"HTTP/1.0 default close")
        set r="GET / HTTP/1.0"_cr_"Connection: keep-alive"_cr_cr
        set st=$$parseReq^STDHTTPMSG(r,.REQ)
        do eq^STDASSERT(.pass,.fail,REQ("keepalive"),1,"HTTP/1.0 + keep-alive -> 1")
        quit
        ;
tParseReqLineTooLong(pass,fail) ;@TEST "an over-long request line returns 414"
        new cr,req,REQ,st,opts
        set cr=$char(13,10)
        set opts("maxline")=20
        set req="GET /this/path/is/way/too/long HTTP/1.1"_cr_"Host: x"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ,.opts)
        do eq^STDASSERT(.pass,.fail,st,414,"414 URI Too Long")
        quit
        ;
tParseTooManyHeaders(pass,fail) ;@TEST "exceeding the header-count cap returns 431"
        new cr,req,REQ,st,opts
        set cr=$char(13,10)
        set opts("maxhdrcount")=2
        set req="GET / HTTP/1.1"_cr_"A: 1"_cr_"B: 2"_cr_"C: 3"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ,.opts)
        do eq^STDASSERT(.pass,.fail,st,431,"431 Request Header Fields Too Large")
        quit
        ;
tParseBodyTooLarge(pass,fail)   ;@TEST "a Content-Length over the cap returns 413"
        new cr,req,REQ,st,opts
        set cr=$char(13,10)
        set opts("maxbody")=4
        set req="POST /x HTTP/1.1"_cr_"Content-Length: 10"_cr_cr_"0123456789"
        set st=$$parseReq^STDHTTPMSG(req,.REQ,.opts)
        do eq^STDASSERT(.pass,.fail,st,413,"413 Payload Too Large")
        quit
        ;
tParseMalformed(pass,fail)      ;@TEST "malformed requests return 400 (normal traffic, not $ECODE)"
        new cr,REQ,st
        set cr=$char(13,10)
        set st=$$parseReq^STDHTTPMSG("GARBAGE-NO-CRLF",.REQ)
        do eq^STDASSERT(.pass,.fail,st,400,"no request line -> 400")
        set st=$$parseReq^STDHTTPMSG("GET /x"_cr_cr,.REQ)
        do eq^STDASSERT(.pass,.fail,st,400,"two-token request line -> 400")
        set st=$$parseReq^STDHTTPMSG("GET /x HTTP/9.9"_cr_cr,.REQ)
        do eq^STDASSERT(.pass,.fail,st,400,"bad HTTP version -> 400")
        set st=$$parseReq^STDHTTPMSG("GET /x HTTP/1.1"_cr_"BadHeaderNoColon"_cr_cr,.REQ)
        do eq^STDASSERT(.pass,.fail,st,400,"header without colon -> 400")
        quit
        ;
tSerializeRspExact(pass,fail)   ;@TEST "serializeRsp emits byte-exact status line, headers, CRLFs, body"
        new cr,RSP,raw,exp
        set cr=$char(13,10)
        set RSP("status")=200
        set RSP("hdr","Content-Type")="text/plain"
        set RSP("hdr","Date")="Thu, 01 Jan 1970 00:00:00 GMT"
        set RSP("hdr","Server")="m-stdlib"
        set RSP("hdr","Connection")="close"
        set RSP("body")="hello"
        set raw=$$serializeRsp^STDHTTPMSG(.RSP)
        set exp="HTTP/1.1 200 OK"_cr
        set exp=exp_"Connection: close"_cr
        set exp=exp_"Content-Length: 5"_cr
        set exp=exp_"Content-Type: text/plain"_cr
        set exp=exp_"Date: Thu, 01 Jan 1970 00:00:00 GMT"_cr
        set exp=exp_"Server: m-stdlib"_cr
        set exp=exp_cr_"hello"
        do eq^STDASSERT(.pass,.fail,raw,exp,"exact response bytes")
        quit
        ;
tSerializeRspJson(pass,fail)    ;@TEST "RSP(json) is serialized to body with application/json"
        new RSP,raw,R2,st
        set RSP("status")=200
        set RSP("json")="o"
        set RSP("json","name")="s:Jdoe"
        set raw=$$serializeRsp^STDHTTPMSG(.RSP)
        set st=$$parseRsp^STDHTTPMSG(raw,.R2)
        do eq^STDASSERT(.pass,.fail,st,200,"re-parse status 200")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"content-type"),"application/json","default JSON content-type")
        do eq^STDASSERT(.pass,.fail,R2("body"),"{""name"":""Jdoe""}","JSON-encoded body")
        quit
        ;
tSerializeRspDefaults(pass,fail)        ;@TEST "serializeRsp injects Date/Server/Connection/Content-Length when absent"
        new RSP,raw,R2,st
        set RSP("status")=204
        set raw=$$serializeRsp^STDHTTPMSG(.RSP)
        set st=$$parseRsp^STDHTTPMSG(raw,.R2)
        do eq^STDASSERT(.pass,.fail,st,200,"re-parse ok")
        do true^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"date")'="","Date present")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"server"),"m-stdlib","Server default")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"content-length"),0,"Content-Length 0 for empty body")
        do true^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"connection")'="","Connection present")
        quit
        ;
tSerializeRspReasonPhrase(pass,fail)    ;@TEST "serializeRsp derives a standard reason phrase from the status"
        new RSP,raw,R2,st
        set RSP("status")=404
        set raw=$$serializeRsp^STDHTTPMSG(.RSP)
        set st=$$parseRsp^STDHTTPMSG(raw,.R2)
        do eq^STDASSERT(.pass,.fail,R2("status"),404,"status 404")
        do eq^STDASSERT(.pass,.fail,R2("reason"),"Not Found","reason phrase")
        quit
        ;
tHdrHelper(pass,fail)   ;@TEST "$$hdr returns the matching value or empty"
        new cr,req,REQ,st
        set cr=$char(13,10)
        set req="GET / HTTP/1.1"_cr_"X-Trace: abc"_cr_cr
        set st=$$parseReq^STDHTTPMSG(req,.REQ)
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.REQ,"x-trace"),"abc","present header")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.REQ,"x-absent"),"","absent header -> empty")
        quit
        ;
tRoundTripReq(pass,fail)        ;@TEST "serializeReq then parseReq is structurally identical"
        new REQ,raw,R2,st
        set REQ("method")="POST"
        set REQ("rawpath")="/Patient"
        set REQ("ver")="1.1"
        set REQ("hdr","host")="h"
        set REQ("hdr","content-type")="application/json"
        set REQ("body")="{}"
        set raw=$$serializeReq^STDHTTPMSG(.REQ)
        set st=$$parseReq^STDHTTPMSG(raw,.R2)
        do eq^STDASSERT(.pass,.fail,st,200,"re-parse ok")
        do eq^STDASSERT(.pass,.fail,R2("method"),"POST","method round-trips")
        do eq^STDASSERT(.pass,.fail,R2("rawpath"),"/Patient","path round-trips")
        do eq^STDASSERT(.pass,.fail,R2("hdr","content-type"),"application/json","header round-trips")
        do eq^STDASSERT(.pass,.fail,R2("body"),"{}","body round-trips")
        do eq^STDASSERT(.pass,.fail,R2("body","len"),2,"content length round-trips")
        quit
        ;
tRoundTripRsp(pass,fail)        ;@TEST "serializeRsp then parseRsp is structurally identical"
        new RSP,raw,R2,st
        set RSP("status")=201
        set RSP("hdr","Content-Type")="text/plain"
        set RSP("body")="created"
        set raw=$$serializeRsp^STDHTTPMSG(.RSP)
        set st=$$parseRsp^STDHTTPMSG(raw,.R2)
        do eq^STDASSERT(.pass,.fail,st,200,"re-parse ok")
        do eq^STDASSERT(.pass,.fail,R2("status"),201,"status round-trips")
        do eq^STDASSERT(.pass,.fail,R2("reason"),"Created","reason phrase")
        do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.R2,"content-type"),"text/plain","content-type round-trips")
        do eq^STDASSERT(.pass,.fail,R2("body"),"created","body round-trips")
        do eq^STDASSERT(.pass,.fail,R2("body","len"),7,"body length round-trips")
        quit
