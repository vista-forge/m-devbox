STDHARNTST     ; Test suite for STDHARN (resident harness orchestrator).
        ; m-lint: disable-file=M-MOD-020
        ; Test labels delegate counters by-ref to STDASSERT helpers; the by-ref
        ; analyzer can't see writes-via-callee, so it false-positives against the
        ; test idiom. Suppressed file-wide (same as STDASSERTTST).
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tHeaderFormat(.pass,.fail)
        do tSuiteOpenFormat(.pass,.fail)
        do tSuiteCloseFormat(.pass,.fail)
        do tTrailerFormat(.pass,.fail)
        do tEngineLabel(.pass,.fail)
        do tRunFramesNoopSuite(.pass,.fail)
        do tRunMarksErroringSuite(.pass,.fail)
        do tRunCountsMultipleSuites(.pass,.fail)
        do tCovFramesMonBlock(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; --- composer functions (pure; the testable bulk) -------------
        ;
tHeaderFormat(pass,fail)        ;@TEST "header() emits the ##M-HARNESS line"
        ; Built from engine()/ns(), so the expected value is engine-aware — the
        ; suite runs on both YDB and IRIS.
        new want
        set want="##M-HARNESS frame=1 tier=integration engine="_$$engine^STDHARN()_" ns="_$$ns^STDHARN()
        do eq^STDASSERT(.pass,.fail,$$header^STDHARN("integration"),want,"header line")
        quit
        ;
tSuiteOpenFormat(pass,fail)     ;@TEST "suiteOpen() emits ##SUITE ^NAME"
        do eq^STDASSERT(.pass,.fail,$$suiteOpen^STDHARN("MATHTST"),"##SUITE ^MATHTST","suite open line")
        quit
        ;
tSuiteCloseFormat(pass,fail)    ;@TEST "suiteClose() emits ##END ^NAME exit=N"
        do eq^STDASSERT(.pass,.fail,$$suiteClose^STDHARN("MATHTST",0),"##END ^MATHTST exit=0","clean close")
        do eq^STDASSERT(.pass,.fail,$$suiteClose^STDHARN("MATHTST",1),"##END ^MATHTST exit=1","crash close")
        quit
        ;
tTrailerFormat(pass,fail)       ;@TEST "trailer() cross-check totals"
        do eq^STDASSERT(.pass,.fail,$$trailer^STDHARN(2,3,1),"##END-HARNESS suites=2 pass=3 fail=1","trailer totals")
        quit
        ;
tEngineLabel(pass,fail)         ;@TEST "engine() resolves the running engine"
        new e
        set e=$$engine^STDHARN()
        do true^STDASSERT(.pass,.fail,(e="ydb")!(e="iris"),"engine is ydb or iris")
        quit
        ;
        ; --- orchestration (run/suite/emit), via capture mode ---------
        ;
tRunFramesNoopSuite(pass,fail)  ;@TEST "run() frames a no-output suite"
        do capture^STDHARN(1)
        do run^STDHARN("noop^STDHARNTST")
        do capture^STDHARN(0)
        new f
        set f=$$captured^STDHARN()
        do contains^STDASSERT(.pass,.fail,f,"##M-HARNESS frame=1 tier=integration","header framed")
        do contains^STDASSERT(.pass,.fail,f,"##SUITE ^noop","suite open framed")
        do contains^STDASSERT(.pass,.fail,f,"##END ^noop exit=0","suite close exit 0")
        do contains^STDASSERT(.pass,.fail,f,"##END-HARNESS suites=1 pass=0 fail=0","trailer framed")
        quit
        ;
tRunMarksErroringSuite(pass,fail)       ;@TEST "run() marks a crashing suite exit!=0 and survives"
        do capture^STDHARN(1)
        do run^STDHARN("boom^STDHARNTST")
        do capture^STDHARN(0)
        new f
        set f=$$captured^STDHARN()
        do contains^STDASSERT(.pass,.fail,f,"##END ^boom exit=1","crash → exit=1")
        do contains^STDASSERT(.pass,.fail,f,"##END-HARNESS suites=1","orchestrator survived crash")
        quit
        ;
tRunCountsMultipleSuites(pass,fail)     ;@TEST "run() counts every suite in scope"
        do capture^STDHARN(1)
        do run^STDHARN("noop^STDHARNTST noop^STDHARNTST")
        do capture^STDHARN(0)
        new f
        set f=$$captured^STDHARN()
        do contains^STDASSERT(.pass,.fail,f,"##END-HARNESS suites=2 ","two suites counted")
        quit
        ;
tCovFramesMonBlock(pass,fail)   ;@TEST "cov() wraps the frame in a ##MON…##END-MON block"
        do capture^STDHARN(1)
        do cov^STDHARN("noop^STDHARNTST","STDHARN")
        do capture^STDHARN(0)
        new f
        set f=$$captured^STDHARN()
        do contains^STDASSERT(.pass,.fail,f,"##MON","mon block open")
        do contains^STDASSERT(.pass,.fail,f,"##END-MON","mon block close")
        ; The IRIS monitor yields MLINE rows; on YDB the block is empty by design
        ; (YDB coverage stays the host-side view "TRACE" path).
        if $$isiris^STDHARN do contains^STDASSERT(.pass,.fail,f,"MLINE:STDHARN:","iris monitor rows present")
        quit
        ;
        ; --- fixtures (NOT t*/suite-named, so never auto-discovered) ---
        ;
noop    ; fixture suite: produces no STDASSERT output.
        quit
        ;
boom    ; fixture suite: errors mid-run (DIVZERO) to exercise the trap path.
        new x
        set x=1/0
        quit
