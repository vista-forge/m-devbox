STDS3TST        ; Test suite for STDS3 (S3 REST client) — deterministic unit layer.
        ; doc: @tier optional
        ; m-lint: disable-file=M-MOD-020
        ; These tests cover the request-assembly, addressing (virtual-hosted vs
        ; path-style endpoint override), the SigV4 binding, and the XML parsers
        ; WITHOUT a network — the live capture→PUT→read-back round-trip against a
        ; MinIO container lives in STDS3MINIOTST (the §15 end-to-end harness).
        ; The PUT Authorization is a known answer from the same independent
        ; Python oracle that anchors STDSIGV4TST. Run via `make test-optional`.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        ;
        do tHostVirtualHosted(.pass,.fail)
        do tHostPathStyleEndpoint(.pass,.fail)
        do tUrlVirtualHosted(.pass,.fail)
        do tUrlPathStyle(.pass,.fail)
        do tCanonUriVirtualHosted(.pass,.fail)
        do tCanonUriPathStyle(.pass,.fail)
        do tBuildRequestSignsPut(.pass,.fail)
        do tParseErrorXml(.pass,.fail)
        do tParseListXml(.pass,.fail)
        ;
        do report^STDASSERT(pass,fail)
        quit
        ;
        ; ---------- fixtures ----------
        ;
ctx(ctx)        ; the documented AWS example credentials (us-east-1 / s3)
        set ctx("accessKey")="AKIAIOSFODNN7EXAMPLE"
        set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        set ctx("region")="us-east-1",ctx("service")="s3"
        quit
        ;
        ; ---------- tests ----------
        ;
tHostVirtualHosted(pass,fail)   ;@TEST "host() builds the virtual-hosted endpoint by default"
        new ctx,opt
        do ctx(.ctx)
        do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"my-bucket",.opt),"my-bucket.s3.us-east-1.amazonaws.com","vhost host")
        quit
        ;
tHostPathStyleEndpoint(pass,fail)       ;@TEST "host() uses the endpoint override host for path-style"
        new ctx,opt
        do ctx(.ctx)
        set opt("endpoint")="http://localhost:9000"
        do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"my-bucket",.opt),"localhost:9000","endpoint host")
        quit
        ;
tUrlVirtualHosted(pass,fail)    ;@TEST "url() encodes the key and keeps the path separator (vhost)"
        new ctx,opt
        do ctx(.ctx)
        do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"my-bucket","a/k c.txt","",.opt),"https://my-bucket.s3.us-east-1.amazonaws.com/a/k%20c.txt","vhost url")
        quit
        ;
tUrlPathStyle(pass,fail)        ;@TEST "url() puts the bucket in the path under an endpoint override"
        new ctx,opt
        do ctx(.ctx)
        set opt("endpoint")="http://localhost:9000"
        do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"my-bucket","a/k c.txt","",.opt),"http://localhost:9000/my-bucket/a/k%20c.txt","path-style url")
        quit
        ;
tCanonUriVirtualHosted(pass,fail)       ;@TEST "canonUri() is just the key path in virtual-hosted style"
        new ctx,opt
        do ctx(.ctx)
        do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"my-bucket","vista/o.ndjson",.opt),"/vista/o.ndjson","vhost canonical uri")
        quit
        ;
tCanonUriPathStyle(pass,fail)   ;@TEST "canonUri() prefixes the bucket under an endpoint override"
        new ctx,opt
        do ctx(.ctx)
        set opt("endpoint")="http://localhost:9000"
        do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"my-bucket","vista/o.ndjson",.opt),"/my-bucket/vista/o.ndjson","path-style canonical uri")
        quit
        ;
tBuildRequestSignsPut(pass,fail)        ;@TEST "buildRequest() assembles a correctly-signed PUT (known answer)"
        new ctx,opt,req,resp
        do ctx(.ctx)
        set opt("amzdate")="20130524T000000Z"
        set opt("contentType")="application/x-ndjson"
        do buildRequest^STDS3(.ctx,"PUT","my-vista-logs","vista/site508-0001.ndjson","",$char(123,34,97,34,58,49,125,10),.opt,.req,.resp)
        do eq^STDASSERT(.pass,.fail,req("method"),"PUT","method")
        do eq^STDASSERT(.pass,.fail,req("url"),"https://my-vista-logs.s3.us-east-1.amazonaws.com/vista/site508-0001.ndjson","url")
        do eq^STDASSERT(.pass,.fail,$data(req("header","host")),0,"host not sent explicitly (client adds it from the URL)")
        do eq^STDASSERT(.pass,.fail,req("header","x-amz-content-sha256"),"e346432021b04179518d9614f3560ccd71354a4ee101ddcb893d6959a9d6301c","payload hash")
        do contains^STDASSERT(.pass,.fail,req("header","Authorization"),"SignedHeaders=content-type;host;x-amz-content-sha256;x-amz-date","signed headers")
        do contains^STDASSERT(.pass,.fail,req("header","Authorization"),"Signature=9fce0a76d95dd171c52a8ba417f7364e71b196a1912599342c7c773cde4b5e80","signature")
        quit
        ;
tParseErrorXml(pass,fail)       ;@TEST "parseError() lifts <Code>/<Message> from an S3 error body"
        new resp,xml
        set xml="<?xml version=""1.0"" encoding=""UTF-8""?><Error><Code>NoSuchKey</Code><Message>The specified key does not exist.</Message><Key>x</Key></Error>"
        do parseError^STDS3(xml,.resp)
        do eq^STDASSERT(.pass,.fail,$get(resp("error","code")),"NoSuchKey","error code")
        do eq^STDASSERT(.pass,.fail,$get(resp("error","message")),"The specified key does not exist.","error message")
        quit
        ;
tParseListXml(pass,fail)        ;@TEST "parseList() extracts keys/size/etag + pagination from ListBucketResult"
        new listing,xml,n
        set xml="<?xml version=""1.0"" encoding=""UTF-8""?><ListBucketResult><IsTruncated>false</IsTruncated>"
        set xml=xml_"<Contents><Key>vista/a.ndjson</Key><Size>10</Size><ETag>""e1""</ETag></Contents>"
        set xml=xml_"<Contents><Key>vista/b.ndjson</Key><Size>20</Size><ETag>""e2""</ETag></Contents></ListBucketResult>"
        set n=$$parseList^STDS3(xml,.listing)
        do eq^STDASSERT(.pass,.fail,n,2,"count")
        do eq^STDASSERT(.pass,.fail,$get(listing(1,"key")),"vista/a.ndjson","key 1")
        do eq^STDASSERT(.pass,.fail,$get(listing(2,"size")),"20","size 2")
        do eq^STDASSERT(.pass,.fail,$get(listing("truncated")),"false","truncated flag")
        quit
        ;
