#!/usr/bin/env bash
# iris-transport-probe.sh — the evidence gate for the IRIS transport decision.
#
# Question (docs repo, proposals/iris-transport-standardization/): the VA reaches
# IRIS over Atelier, never Docker — so can the toolchain be standardized on the
# remote/Atelier transport? Four things the code cannot answer, plus one number that
# did not exist:
#
#   P-1  STDCRYPTO   — can the Atelier SqlProc gateway invoke $SYSTEM.Encryption?
#   P-2  STDCOMPRESS — can it invoke %SYS.Python + ctypes.CDLL('libzstd.so.1')?
#   P-3  STDFS/STDNET/STDHTTP — does a device open/use/`use prev` round-trip survive
#        the remote runner's output-capture hook (^mIrisIO / %Device.ReDirectIO)?
#        THE LOAD-BEARING ONE: STDS3 rides STDNET, and that is shipped product.
#   P-4  programmer context / ambient DUZ in the gateway process
#   P-5  the docker-vs-remote performance number
#
# METHOD. Both arms are driven identically — stage (journaled) -> run the suite via
# `exec eval 'do run^STDHARN(...)'` -> unstage -> compare. Driving both arms the same
# way is the point: it isolates the TRANSPORT, not the harness.
#
# Note what this method already demonstrates: a suite runs over Atelier through
# `exec eval` alone. `exec script` (which Atelier refuses) is NOT required — which is
# the routine-wrap insight v-pkg already proved, applied to `m test`.
#
# SAFETY. Engine access is through the m-iris driver only (never raw
# `docker exec … iris session`). Every stage is journaled with --stage-dir and
# restored with `exec unstage`, so foia is left byte-clean. IRIS CE has 8 licence
# units and an externally-killed session leaks one — do not brute-force-iterate the
# docker arm.
#
# Usage:  direnv exec . ./scripts/iris-transport-probe.sh            # both arms
#         TRANSPORTS="remote" ./scripts/iris-transport-probe.sh      # one arm
set -uo pipefail

MIRIS="${MIRIS:-../m-iris/dist/m-iris}"
SRC="${SRC:-src}"
TESTS="${TESTS:-tests}"
TRANSPORTS="${TRANSPORTS:-docker remote}"
# STDJSONTST is the truncation canary: it returned 84/209 over docker vs 209/209 over
# remote (m-stdlib/docs/discoveries.md:72, still open). STDNET/STDHTTP/STDFS are the
# device-I/O suites — the P-3 surface, and the one STDS3 rides.
SUITES="${SUITES:-STDCRYPTOTST STDCOMPRESSTST STDFSTST STDNETTST STDHTTPTST STDJSONTST}"

[[ -x "$MIRIS" ]] || { echo "no m-iris binary at $MIRIS (build it: cd ../m-iris && make build)"; exit 2; }

jqf() { python3 -c "import sys,json;d=json.load(sys.stdin);$1" 2>/dev/null; }

echo "# IRIS transport probe — $(date -u +%FT%TZ)"
echo "# engine: ${M_IRIS_CONTAINER:-?} / ns ${M_IRIS_NAMESPACE:-?} / atelier ${M_IRIS_BASE_URL:-?}"
echo

# --- P-4: programmer context in the executing process --------------------------
echo "## P-4 — programmer context"
for t in $TRANSPORTS; do
  printf '  %-7s ' "$t"
  "$MIRIS" exec eval 'w "DUZ=[",$g(DUZ),"] DUZ0=[",$g(DUZ(0)),"] USER=[",$username,"] ROLES=[",$roles,"] NS=[",$znspace,"]"' \
    --transport "$t" -o json 2>/dev/null | jqf "print((d.get('data') or {}).get('stdout','') or d.get('error'))"
done
echo

# --- P-1/P-2: privilege of the executing process --------------------------------
echo "## P-1/P-2 — engine-API privilege (the calls STDCRYPTO/STDCOMPRESS actually make)"
declare -A CALLS=(
  [P1-SHAHash]='s h=$SYSTEM.Encryption.SHAHash(256,"abc") w "len=",$l(h)'
  [P1-HMACSHA]='s m=$SYSTEM.Encryption.HMACSHA(256,"abc","key") w "len=",$l(m)'
  [P2-py-zlib]='s py=##class(%SYS.Python).Import("zlib") w "isobj=",$isobject(py)'
  [P2-ctypes-zstd]='s ct=##class(%SYS.Python).Import("ctypes") s lib=ct.CDLL("libzstd.so.1") w "isobj=",$isobject(lib)'
)
for t in $TRANSPORTS; do
  for k in P1-SHAHash P1-HMACSHA P2-py-zlib P2-ctypes-zstd; do
    printf '  %-16s %-7s ' "$k" "$t"
    "$MIRIS" exec eval "${CALLS[$k]}" --transport "$t" -o json 2>/dev/null | jqf "
e=d.get('engineError')
print(('FAULT '+str(e.get('mnemonic'))) if e else ('OK  '+repr((d.get('data') or {}).get('stdout',''))))"
  done
done
echo

# --- P-3: does the capture survive a device round-trip? --------------------------
# The exact shape STDFS uses: set prev=\$io … open/use/close … use prev  (STDFS.m:165-170)
echo "## P-3 — device open/use/'use prev' vs the output-capture hook"
for t in $TRANSPORTS; do
  printf '  %-7s write+restore : ' "$t"
  "$MIRIS" exec eval 's prev=$io w "MARK_A|" o "/tmp/zzprb.txt":("NWS"):5 u "/tmp/zzprb.txt" w "payload" c "/tmp/zzprb.txt" u prev w "MARK_B"' \
    --transport "$t" -o json 2>/dev/null | jqf "print(repr((d.get('data') or {}).get('stdout','')))"
  printf '  %-7s read+restore  : ' "$t"
  "$MIRIS" exec eval 's prev=$io,l="" w "MARK_A|" o "/tmp/zzprb.txt":("R"):5 u "/tmp/zzprb.txt" r l:5 c "/tmp/zzprb.txt" u prev w "READ=[",l,"]|MARK_B"' \
    --transport "$t" -o json 2>/dev/null | jqf "print(repr((d.get('data') or {}).get('stdout','')))"
  "$MIRIS" exec eval 'o "/tmp/zzprb.txt":("R"):2 c "/tmp/zzprb.txt":"D"' --transport "$t" -o json >/dev/null 2>&1
done
echo
echo "  (PASS = MARK_A, the post-'use prev' READ, and MARK_B are ALL captured."
echo "   A partial capture is a FAILURE, not a warning — right counts / wrong bytes.)"
echo

# --- P-1/P-2/P-3 (real suites) + P-5 (timings) -----------------------------------
echo "## Suites + P-5 timings — stage(journaled) -> run -> unstage, identical on both arms"
printf '  %-16s %-7s %8s %8s %8s  %s\n' SUITE TRANSPORT PASS FAIL "RUN(s)" VERDICT
for t in $TRANSPORTS; do
  tok="mtest-probe-$t"
  t0=$(date +%s.%N)
  "$MIRIS" exec load "$SRC" $(for s in $SUITES; do echo "$TESTS/$s.m"; done) \
      --stage-dir "$tok" --transport "$t" -o json >/tmp/probe-load.json 2>&1
  t1=$(date +%s.%N)
  nload=$(jqf "print(len((d.get('data') or {}).get('loaded',[])))" </tmp/probe-load.json)
  printf '  %-16s %-7s %8s %8s %8.2f  stage of %s routines\n' "(stage)" "$t" - - \
      "$(echo "$t1-$t0" | bc)" "${nload:-ERR}"

  for s in $SUITES; do
    r0=$(date +%s.%N)
    out=$("$MIRIS" exec eval "do run^STDHARN(\"$s\")" --stage-dir "$tok" --transport "$t" -o json 2>/dev/null \
          | jqf "print((d.get('data') or {}).get('stdout','') if not d.get('engineError') else 'FAULT '+str(d['engineError'].get('mnemonic')))")
    r1=$(date +%s.%N)
    # the harness frame is the ground truth, not a scraped count
    line=$(printf '%s' "$out" | tr -d '\r' | grep -o '##END-HARNESS suites=[0-9]* pass=[0-9]* fail=[0-9]*' | tail -1)
    p=$(printf '%s' "$line" | sed -n 's/.*pass=\([0-9]*\).*/\1/p')
    f=$(printf '%s' "$line" | sed -n 's/.*fail=\([0-9]*\).*/\1/p')
    if [[ -z "$line" ]]; then v="NO-FRAME (truncated? faulted?)"; p=?; f=?; else v=""; fi
    printf '  %-16s %-7s %8s %8s %8.2f  %s\n' "$s" "$t" "${p:-?}" "${f:-?}" "$(echo "$r1-$r0" | bc)" "$v"
  done

  "$MIRIS" exec unstage --stage-dir "$tok" --transport "$t" -o json >/dev/null 2>&1 \
    && echo "  (unstage $t: restored)" || echo "  (unstage $t: FAILED — foia may carry residue!)"
done
echo
echo "# Verdict rule: identical pass/fail counts on both arms = the transport is not"
echo "# the variable. A count delta or a NO-FRAME on remote is a P-3 FAILURE."
