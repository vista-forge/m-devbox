#!/usr/bin/env bash
# Remove m-stdlib's routines and scratch globals from vista-meta.
set -euo pipefail

PROJECT="m-stdlib"
XTMP_KEY="M-STDLIB"

CONN="${VISTA_CONN_FILE:-$HOME/data/vista-meta/conn.env}"
[ -f "$CONN" ] || exit 0
# shellcheck disable=SC1090
source "$CONN"

# NOTE (m/v waterline transport monopoly): this hand-rolls the raw GT.M interpreter
# over SSH against the LEGACY vista-meta host — NOT the vehu/foia VSL-MSL driver
# stack (which is reached only through m-driver-sdk -> m-ydb/m-iris via the `m`
# toolchain). vista-meta is winding down and has no driver transport, so this stays
# raw. The trailing `stack-exempt` marker keeps the offending line visible to the
# engine-access gate (it is a harmless comment to the remote bash — ends at its
# own newline, so the closing quote on the next line is untouched).
ssh -p "$VISTA_SSH_PORT" -o StrictHostKeyChecking=no -o BatchMode=yes \
    "$VISTA_SSH_USER@$VISTA_HOST" "bash -lc '
  source /etc/profile.d/ydb_env.sh
  rm -rf \$HOME/export/seed/$PROJECT
  \$ydb_dist/mumps -run %XCMD \"K ^XTMP(\\\"$XTMP_KEY\\\")\" 2>/dev/null || true  # stack-exempt: legacy vista-meta SSH cleanup, no driver transport
' " 2>/dev/null || true

echo "[$PROJECT] unseed done"
