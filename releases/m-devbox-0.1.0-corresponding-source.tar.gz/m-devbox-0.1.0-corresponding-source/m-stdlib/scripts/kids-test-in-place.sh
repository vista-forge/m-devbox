#!/usr/bin/env bash
#
# kids-test-in-place.sh — VSL T0b.2: the MSL "KIDS-install-as-green" loop.
#
# Build the MSL base .KID, install it via `v pkg` onto a live FOIA VistA
# engine, run the pure-module *TST suites IN PLACE against the *installed*
# routines, then uninstall and verify the engine is clean. A green REQUIRES
# install-via-KIDS + test-in-place + a provably-clean uninstall — never a
# source-loaded sidecar of the modules under test.
#
#   build  →  v pkg build kids/std.build.json → dist/kids/MSL.kids
#   install→  v pkg install MSL.kids --engine <e>     (#9.7 status 3)
#   test   →  load STDASSERT+STDHARN+*TST as the (never-shipped) harness
#             sidecar, then `do run^STDHARN("<suites>")` — the suites call
#             the KIDS-installed STD* routines, so the modules under test
#             are the installed copies, not the source
#   uninst →  v pkg uninstall MSL.kids --engine <e>   (reversible)
#   verify →  v pkg verify → installed:false; sidecar routines deleted
#
# The modules under test (STDSTR, STDMATH, … — see kids/std.build.json) are
# KIDS-installed. STDASSERT (the assertion library) + STDHARN (the resident
# orchestrator) + the *TST suites are test infrastructure that never ships to
# a production VistA, so loading them as a sidecar does not violate the
# install-as-green invariant: the code being *certified* is the installed copy.
#
# Usage:
#   scripts/kids-test-in-place.sh ydb       # vehu  (docker transport)
#   scripts/kids-test-in-place.sh iris      # foia  (remote/Atelier transport)
#
# Engine connection is read by the m-<engine> driver from its M_<ENGINE>_*
# environment; this script sets sensible defaults for the local vehu/foia test
# engines, overridable from the caller's environment.
#
# PREREQUISITE (YDB): the m-ydb *docker* transport must establish vehu's global
# directory. As of 2026-06-12 it does not (execEnv() omits ydb_gbldir; see
# docs/discoveries.md), so `v pkg --engine ydb --transport docker`
# fails with %YDB-E-ZGBLDIRUNDEF. The YDB leg of this loop is blocked until that
# m-ydb fix lands (inject -e ydb_gbldir/ydb_routines, or source an env-file like
# the remote transport). The IRIS leg works today against foia.
#
set -euo pipefail

engine="${1:-}"
case "$engine" in
  ydb|iris) ;;
  *) echo "usage: $0 <ydb|iris>" >&2; exit 2 ;;
esac

here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # m-stdlib repo root
ws="$(cd "$here/.." && pwd)"                              # vista-forge workspace
spec="$here/kids/std.build.json"
kid="$here/dist/kids/MSL.kids"

VPKG="${VPKG:-$ws/v-pkg/dist/v-pkg}"
DRIVER="${DRIVER:-$ws/m-$engine/dist/m-$engine}"
[ -x "$VPKG" ]   || { echo "v-pkg not found at $VPKG (build it / set VPKG)" >&2; exit 1; }
[ -x "$DRIVER" ] || { echo "m-$engine not found at $DRIVER (build it / set DRIVER)" >&2; exit 1; }

# ── engine connection defaults (overridable from the environment) ────────────
if [ "$engine" = "ydb" ]; then
  TRANSPORT="${TRANSPORT:-docker}"
  export M_YDB_TRANSPORT="$TRANSPORT"
  export M_YDB_CONTAINER="${M_YDB_CONTAINER:-vehu}"
  export M_YDB_DIST="${M_YDB_DIST:-/home/vehu/lib/gtm}"
  export M_YDB_GBLDIR="${M_YDB_GBLDIR:-/home/vehu/g/vehu.gld}"
  export M_YDB_ROUTINES="${M_YDB_ROUTINES:-/home/vehu/p/r2.02_x86_64*(/home/vehu/p) /home/vehu/s/r2.02_x86_64*(/home/vehu/s) /home/vehu/r/r2.02_x86_64*(/home/vehu/r) /home/vehu/lib/gtm/libgtmutil.so}"
else
  TRANSPORT="${TRANSPORT:-remote}"
  export M_IRIS_TRANSPORT="$TRANSPORT"
  export M_IRIS_BASE_URL="${M_IRIS_BASE_URL:-http://127.0.0.1:52773/api/atelier/v1/}"
  export M_IRIS_NAMESPACE="${M_IRIS_NAMESPACE:-VISTA}"
  export M_IRIS_USER="${M_IRIS_USER:-_SYSTEM}"
  : "${M_IRIS_PASSWORD:?set M_IRIS_PASSWORD for the foia _SYSTEM account (see the IRIS unblock recipe)}"
  export M_IRIS_USER M_IRIS_PASSWORD
fi

# ── derive the suite list + sidecar files from the build spec ────────────────
# Base routines → their *TST suite routine names; sidecar = the harness
# (STDASSERT, STDHARN) + each suite's source. Suites run by routine name; the
# library routines they call resolve to the KIDS-installed copies.
mapfile -t routines < <(python3 -c '
import json,sys
spec=json.load(open(sys.argv[1]))
for r in spec["components"]["routines"]:
    print(r)
' "$spec")
suites=(); sidecar=("$here/src/STDASSERT.m" "$here/src/STDHARN.m")
for r in "${routines[@]}"; do
  suites+=("${r}TST")
  sidecar+=("$here/tests/${r}TST.m")
done
scope="${suites[*]}"

say() { printf '\n=== %s ===\n' "$*"; }
# jget KEY — read .data.KEY from a JSON envelope on stdin.
jget() { python3 -c 'import json,sys; print(json.load(sys.stdin).get("data",{}).get(sys.argv[1],""))' "$1"; }

say "build  $spec → $kid"
"$VPKG" build "$spec" --src "$here/src" --out "$kid" -o json >/dev/null
echo "ok ($(grep -c '' "$kid") lines)"

say "install MSL base on $engine ($TRANSPORT)"
out="$("$VPKG" install "$kid" --engine "$engine" --transport "$TRANSPORT" -o json)"
echo "$out" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("data") or d.get("error"))'
status="$(echo "$out" | jget status)"
[ "$(echo "$out" | jget installed)" = "True" ] && [ "$status" = "3" ] \
  || { echo "INSTALL FAILED (status=$status)" >&2; exit 1; }

say "load test-harness sidecar (STDASSERT, STDHARN, ${#suites[@]} suites)"
"$DRIVER" exec load "${sidecar[@]}" --transport "$TRANSPORT" -o json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print("loaded", len(d.get("data",{}).get("loaded",[])), "routines")'

say "test-in-place: run^STDHARN per suite against the installed routines"
# One harness call per suite: each call's output frame stays small (a single
# 15-suite frame overflows the IRIS runner's output capture). A suite whose
# driver eval errors outright (vs returning a result frame) is a RUNNER error,
# not a test failure — currently the m-iris runner's GetOut faults on output
# containing wide (Unicode >255) characters, which STDURLTST/STDREGEXTST emit in
# their descriptions. Those are reported separately so the loop still completes.
frames=""; runner_err=""
for s in "${suites[@]}"; do
  env="$("$DRIVER" exec eval "do run^STDHARN(\"$s\")" --transport "$TRANSPORT" -o json 2>/dev/null)" || true
  fr="$(printf '%s' "$env" | python3 -c 'import json,sys
try:
 d=json.load(sys.stdin); print(d.get("data",{}).get("stdout","") if d.get("ok") else "")
except Exception: print("")')"
  if [ -z "$fr" ]; then runner_err="$runner_err $s"; continue; fi
  frames+="$fr"$'\n'
done
printf '%s\n' "$frames" | grep -E '##END' || true
[ -n "$runner_err" ] && echo "RUNNER-ERRORED (not a test failure):$runner_err"
# Aggregate every result frame: green iff total fail=0, every exit=0, and no
# suite was runner-errored.
printf '%s' "$frames" | runner_err="$runner_err" python3 -c '
import re,sys,os
f=sys.stdin.read()
trailers=re.findall(r"##END-HARNESS suites=(\d+) pass=(\d+) fail=(\d+)", f)
exits=[int(m) for m in re.findall(r"##END \S+ exit=(\d+)", f)]
rerr=os.environ.get("runner_err","").split()
if not trailers: sys.exit("no ##END-HARNESS trailer — harness did not complete")
nsuites=sum(int(s) for s,_,_ in trailers)
p=sum(int(x) for _,x,_ in trailers); fail=sum(int(x) for _,_,x in trailers)
bad=[e for e in exits if e]
rerr_note=(" "+" ".join(rerr)) if rerr else ""
print("suites=%d pass=%d fail=%d nonzero-exits=%d runner-errored=%d%s" % (nsuites,p,fail,len(bad),len(rerr),rerr_note))
sys.exit(0 if (fail==0 and not bad and not rerr) else "RED: in-place suite failures or runner errors")
'

say "uninstall MSL base (reversibility)"
"$VPKG" uninstall "$kid" --engine "$engine" --transport "$TRANSPORT" -o json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("data") or d.get("error"))'

say "verify clean + remove harness sidecar"
"$VPKG" verify "$kid" --engine "$engine" --transport "$TRANSPORT" -o json \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("data"))'
# Delete the never-shipped harness routines so the engine returns to pre-state
# (best-effort; ^%ZOSF("DEL") is the engine-neutral Kernel routine-delete).
delcmd=''
for r in STDASSERT STDHARN "${suites[@]}"; do delcmd="$delcmd new X set X=\"$r\" xecute ^%ZOSF(\"DEL\")"; done
"$DRIVER" exec eval "$delcmd" --transport "$TRANSPORT" -o json >/dev/null || true

say "T0b.2 loop complete on $engine"
