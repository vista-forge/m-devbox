#!/usr/bin/env bash
# Seed (or re-seed) the std_crypto callout into a RUNNING m-test-engine-style
# YottaDB container — the durable, portable form of T-DEPLOY (proposal §15.6).
#
# Why this exists: the pinned m-test-engine image bakes std_crypto.so, but T32's
# crypto_verify (asymmetric verify) is new code, so the .so must be rebuilt and
# placed in the running container. This does that WITHOUT `docker exec` into the
# running engine (the org transport-monopoly rule bans exec-into-a-live-engine;
# `docker cp` is a file copy and `docker run` of a throwaway build container is a
# build step, neither reaches the live engine — and the m-ci.yml engine-access
# scan greps only for `docker exec`, so nothing here trips it).
#
# ABI-safety: the .so is compiled INSIDE a throwaway container spun from the
# engine's OWN image, so it is built against the exact glibc / OpenSSL / YottaDB
# headers the running engine uses. This removes every host-runner-vs-container
# skew risk (glibc version, missing libssl-dev, header extraction) — the build
# environment IS the runtime environment. Only std_crypto.so is rebuilt (the one
# callout with new code); the image's other baked callouts (libz/libcurl) are
# untouched, and the rebuilt .so is a superset (sha/hmac + verify) so it never
# regresses the already-green digest/HMAC suites.
#
# The functional gate ("does verify actually work") is STDCRYPTOTST's
# tVerifyAvailableIsOne, run by `make test-optional` immediately after this in CI.
# This script's own gate is that the built .so exports EVERY symbol declared in
# tools/std_crypto.xc — derived from dist/callout-symbols.json (safety-net P3.3),
# not a hand list (nm; see the loop below).
#
# Usage:
#   scripts/seed-engine-callouts.sh [CONTAINER]     # default: m-test-engine
# Env:
#   ENGINE_CONTAINER   container name (overrides the positional arg)
#   STDLIB_SO_DIR      in-container .so dir  (default: /opt/stdlib/lib)
#   STDLIB_XC_DIR      in-container .xc dir  (default: /opt/stdlib/xc)
set -euo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
CONTAINER="${ENGINE_CONTAINER:-${1:-m-test-engine}}"
SO_DIR="${STDLIB_SO_DIR:-/opt/stdlib/lib}"
XC_DIR="${STDLIB_XC_DIR:-/opt/stdlib/xc}"
XC="${PROJECT_ROOT}/tools/std_crypto.xc"
REGISTRY="${PROJECT_ROOT}/dist/callout-symbols.json"

say() { echo "[seed-engine-callouts] $*"; }

# ── required-symbol list DERIVED from the registry (safety-net P3.3) ──────────
# The nm gate below is no longer a hand list (the vehu Dockerfile checked only
# crypto_verify by hand for weeks — 2026-07-10 incident, Phase-4). It is derived
# from dist/callout-symbols.json, itself generated from tools/std_crypto.xc (the
# callout's own function registry) and drift-gated by `make check-callout-symbols`.
# So the .so must export EVERY symbol the .xc declares — add one to the .xc and
# this gate reds until the .so is rebuilt to export it. python3 runs on the HOST
# (guaranteed per repo CLAUDE.md); the space-separated list is substituted into
# the throwaway build container, which needs no python3.
[ -f "${REGISTRY}" ] || { echo "registry ${REGISTRY} missing — run 'make callout-symbols'" >&2; exit 1; }
REQUIRED_SYMBOLS="$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(" ".join(next(l["symbols"] for l in d["libraries"] if l["so"]=="std_crypto.so")))' "${REGISTRY}")"
[ -n "${REQUIRED_SYMBOLS}" ] || { echo "no std_crypto.so symbols in ${REGISTRY} — run 'make callout-symbols'" >&2; exit 1; }

command -v docker >/dev/null || { echo "docker not found" >&2; exit 1; }
docker inspect "${CONTAINER}" >/dev/null 2>&1 || { echo "container '${CONTAINER}' not running" >&2; exit 1; }

# ── resolve the engine's own image (build environment == runtime environment) ──
IMAGE="$(docker inspect -f '{{.Config.Image}}' "${CONTAINER}")"
[ -n "${IMAGE}" ] || { echo "could not resolve image for ${CONTAINER}" >&2; exit 1; }
say "engine container=${CONTAINER} image=${IMAGE}"

WORK="$(mktemp -d)"
trap 'rm -rf "${WORK}"' EXIT

# ── build std_crypto.so inside a throwaway container from the engine's image ──
# The container already carries the YottaDB headers (/opt/yottadb/current) and the
# right libcrypto; we only add a compiler (+ openssl dev headers) for the build.
# Read the per-source `// link: -lfoo` directive the same way build-callouts.sh does.
LINK="$(sed -n '1,30s|^// link:[[:space:]]*||p' "${PROJECT_ROOT}/src/callouts/std_crypto.c" | head -1)"
say "compiling std_crypto.so in a throwaway ${IMAGE} container (link: ${LINK})"
# --entrypoint bash: engine images that boot a full system from their ENTRYPOINT
# (e.g. the vehu gold master's start.sh) would otherwise IGNORE the build command
# and start a whole VistA in the throwaway container. Overriding the entrypoint
# runs the build on every engine-style image; images without an entrypoint are
# unaffected.
docker run --rm \
  -v "${PROJECT_ROOT}/src/callouts:/src:ro" \
  -v "${WORK}:/out" \
  --entrypoint bash \
  "${IMAGE}" -c '
    set -e
    export DEBIAN_FRONTEND=noninteractive
    if ! command -v gcc >/dev/null; then
      apt-get update -qq && apt-get install -y -qq gcc libssl-dev >/dev/null
    elif ! echo "#include <openssl/evp.h>" | gcc -E -xc - >/dev/null 2>&1; then
      apt-get update -qq && apt-get install -y -qq libssl-dev >/dev/null
    fi
    # ydb_dist is often profile-set, not a container ENV (e.g. the vehu gold
    # master), and --entrypoint bash -c sources no profile — so probe for the
    # header when the env var is absent or stale.
    ydb="${ydb_dist:-/opt/yottadb/current}"
    if [ ! -f "$ydb/libyottadb.h" ]; then
      ydb="$(dirname "$(find /opt /home /usr/local -maxdepth 5 -name libyottadb.h -print -quit 2>/dev/null)")"
    fi
    [ -f "$ydb/libyottadb.h" ] || { echo "no libyottadb.h in build image (ydb_dist unset and probe found none)" >&2; exit 1; }
    gcc -shared -fPIC -I"$ydb" -O2 -Wall -Wextra -o /out/std_crypto.so /src/std_crypto.c '"${LINK}"'
    # nm gate — every symbol the .xc declares (list derived host-side, substituted here).
    if command -v nm >/dev/null; then
      for sym in '"${REQUIRED_SYMBOLS}"'; do
        nm -D /out/std_crypto.so | grep -q "\b${sym}\b" || { echo "built std_crypto.so missing ${sym}" >&2; exit 1; }
      done
    fi
  '

# ── belt-and-braces host-side symbol assertion (registry-derived) ──────────
if command -v nm >/dev/null; then
  for sym in ${REQUIRED_SYMBOLS}; do
    nm -D "${WORK}/std_crypto.so" | grep -q "\b${sym}\b" \
      || { echo "built std_crypto.so is missing ${sym} (declared in tools/std_crypto.xc via dist/callout-symbols.json) — aborting" >&2; exit 1; }
  done
fi
[ -s "${WORK}/std_crypto.so" ] || { echo "build produced no std_crypto.so — aborting" >&2; exit 1; }
say "all ${REGISTRY##*/} std_crypto.so symbols present: ${REQUIRED_SYMBOLS}"

# ── place the .so + descriptor into the running container (docker cp) ─────
say "deploying to ${CONTAINER}:${SO_DIR}/std_crypto.so and ${XC_DIR}/std_crypto.xc"
docker cp "${WORK}/std_crypto.so" "${CONTAINER}:${SO_DIR}/std_crypto.so"
docker cp "${XC}"                 "${CONTAINER}:${XC_DIR}/std_crypto.xc"

say "done — 'make test-optional' now exercises \$\$verifyAvailable + the verify suite"
