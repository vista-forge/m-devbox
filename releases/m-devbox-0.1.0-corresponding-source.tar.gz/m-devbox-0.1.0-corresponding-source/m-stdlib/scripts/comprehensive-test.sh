#!/usr/bin/env bash
# scripts/comprehensive-test.sh — run the FULL comprehensive test + quality sweep
# on demand, from one command, for BOTH libraries (m-stdlib + v-stdlib) on BOTH
# bare engines (YottaDB + InterSystems IRIS).
#
# This is the §1 "whole thing, in order" sequence from
# docs/guides/comprehensive-testing.md, mechanized:
#   per repo →  engine-free gates  →  engine-bound suites (YDB + IRIS,
#               optional tier on BOTH engines with tracked skips)
#            →  executable examples (both engines)  →  coverage
#   (S3 integration has NO live gate since the old tap subsystem was removed —
#   the sweep states that explicitly instead of skipping it silently.)
#
# Tier: BARE only. The LIVE-VistA tier (vehu/foia) is a separate nightly cadence —
# see .github/scripts/cron/examples-live-cron.sh and §5 of the guide.
#
# Engine access is through the driver stack ONLY: every step shells out to a `make`
# target that routes through m-driver-sdk → m-ydb/m-iris. This script hand-rolls no
# `docker exec`/`iris session`/`mumps -direct` (that would be a red gate).
#
# Runs every step (does NOT stop at the first failure), then prints a PASS/FAIL
# summary and exits non-zero if anything failed.
#
# Usage:
#   scripts/comprehensive-test.sh [--m PATH] [--skip-optional] [-h]
#
# Env overrides (flags win over env):
#   M            path to the m binary  (default: the sibling m-cli/dist/m)
#   YDB_DOCKER   bare YDB engine container   (default: m-test-engine)
#   IRIS_DOCKER  bare IRIS engine container  (default: m-test-iris)
set -uo pipefail

M="${M:-$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)/m-cli/dist/m}"  # sibling, not $HOME
YDB_DOCKER="${YDB_DOCKER:-m-test-engine}"
IRIS_DOCKER="${IRIS_DOCKER:-m-test-iris}"
SKIP_OPTIONAL=0

# Repo roots: this script lives in <m-stdlib>/scripts; v-stdlib is its sibling.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MSTDLIB="$(cd -- "$SCRIPT_DIR/.." && pwd)"
WORKSPACE="$(cd -- "$MSTDLIB/.." && pwd)"
VSTDLIB="$WORKSPACE/v-stdlib"

usage() { awk 'NR>1 && /^#/ {sub(/^# ?/,""); print; next} NR>1 {exit}' "${BASH_SOURCE[0]}"; }

while [ $# -gt 0 ]; do
  case "$1" in
    --m)            M="$2"; shift 2 ;;
    --m=*)          M="${1#*=}"; shift ;;
    --skip-optional) SKIP_OPTIONAL=1; shift ;;
    -h|--help)      usage; exit 0 ;;
    *) echo "unknown arg: $1" >&2; usage >&2; exit 2 ;;
  esac
done

# --- preflight -------------------------------------------------------------
if [ ! -x "$M" ]; then
  cat >&2 <<EOF
error: m binary not found/executable at: $M
Build it once from m-cli, or pass --m PATH:
  git clone https://github.com/vista-forge/m-cli "$WORKSPACE/m-cli"
  ( cd "$WORKSPACE/m-cli" && go build -o dist/m . )
EOF
  exit 2
fi
[ -d "$VSTDLIB" ] || { echo "error: v-stdlib not found at $VSTDLIB" >&2; exit 2; }

# Soft check: the bare engines should be up for the engine-bound steps. Not fatal —
# the engine-free gates still run, and the engine steps will fail loudly if missing.
running="$(docker ps --format '{{.Names}}' 2>/dev/null || true)"
for c in "$YDB_DOCKER" "$IRIS_DOCKER"; do
  case " $running " in
    *" $c "*) ;;
    *) echo "WARNING: engine container '$c' is not running — its engine-bound steps will fail." >&2
       echo "         start it, e.g.: docker start $c" >&2 ;;
  esac
done

# --- step runner -----------------------------------------------------------
# Colours only on a TTY (logs/pipes stay clean).
if [ -t 1 ]; then BOLD=$'\033[1m'; GREEN=$'\033[32m'; RED=$'\033[31m'; RESET=$'\033[0m'
else BOLD=''; GREEN=''; RED=''; RESET=''; fi

declare -a RESULTS
FAILED=0
RUN_START=$SECONDS

step() {           # step "label" <command...>
  local label="$1"; shift
  printf '\n%s========== %s ==========%s\n' "$BOLD" "$label" "$RESET"
  printf '  $ %s\n\n' "$*"
  local start=$SECONDS rc=0
  "$@" || rc=$?
  local secs=$((SECONDS - start))
  if [ "$rc" -eq 0 ]; then
    RESULTS+=("PASS  $(printf '%4ss' "$secs")  $label")
    printf '\n  %s✓ PASS%s  %s  (%ss)\n' "$GREEN" "$RESET" "$label" "$secs"
  else
    RESULTS+=("FAIL  $(printf '%4ss' "$secs")  $label (rc=$rc)")
    FAILED=$((FAILED + 1))
    printf '\n  %s✗ FAIL%s  %s  (rc=%s, %ss)\n' "$RED" "$RESET" "$label" "$rc" "$secs"
  fi
}

echo "comprehensive-test: M=$M  YDB=$YDB_DOCKER  IRIS=$IRIS_DOCKER  (bare tier, both engines)"

# ========================= m-stdlib (STD*) =========================
cd "$MSTDLIB" || exit 2

step "m-stdlib: engine-free gates" \
  make check-manifest skill-check docs-check frontmatter-check grammar-check \
       check-seams check-icr check-citations check-namespaces check-kids \
       check-docs-prose examples-check "M=$M"

step "m-stdlib: fmt-check + lint" \
  make fmt-check lint "M=$M"

step "m-stdlib: test (YDB bare, byte mode)" \
  make test "M=$M" "M_ENGINE_FLAGS=--engine ydb --docker $YDB_DOCKER --chset m"

step "m-stdlib: test (IRIS bare)" \
  make test "M=$M" "M_ENGINE_FLAGS=--engine iris --docker $IRIS_DOCKER"

if [ "$SKIP_OPTIONAL" -eq 0 ]; then
  step "m-stdlib: test-optional (YDB — STDCRYPTO/STDCOMPRESS/STDHTTP callouts)" \
    make test-optional "M=$M"
  # The optional tier on the STANDARD IRIS engine (sweep-truth 2026-07-16):
  # before this step existed the tier ran YDB-only while the banner claimed
  # both engines — five modules' IRIS arms were unobserved by any sweep.
  # STDCOMPRESSTST is a tracked skip inside the target (m-test-iris embedded
  # Python is non-functional; the IRIS arm is gated on foia).
  step "m-stdlib: test-optional-iris (IRIS bare — explicit suite list, tracked skip printed)" \
    make test-optional-iris "M=$M" "IRIS_ENGINE_FLAGS=--engine iris --docker $IRIS_DOCKER"
else
  echo "  (skipping m-stdlib test-optional + test-optional-iris — --skip-optional)"
fi

step "m-stdlib: examples-run (both bare engines)" \
  make examples-run "M=$M"

step "m-stdlib: coverage (aggregate ≥85%)" \
  make coverage "M=$M"

# ========================= v-stdlib (VSL*) =========================
cd "$VSTDLIB" || exit 2

step "v-stdlib: engine-free gates (check-fast = fmt + lint + arch + drift gates)" \
  make check-fast "M=$M"

step "v-stdlib: test-bare (YDB, byte mode)" \
  make test-bare "M=$M" ENGINE=ydb "DOCKER=$YDB_DOCKER" CHSET=m

step "v-stdlib: test-bare (IRIS)" \
  make test-bare "M=$M" ENGINE=iris "DOCKER=$IRIS_DOCKER"

step "v-stdlib: examples-run (both bare engines)" \
  make examples-run "M=$M"

step "v-stdlib: coverage (YDB, ≥85%)" \
  make coverage "M=$M" ENGINE=ydb "DOCKER=$YDB_DOCKER" CHSET=m

step "v-stdlib: coverage (IRIS, ≥85%)" \
  make coverage "M=$M" ENGINE=iris "DOCKER=$IRIS_DOCKER"

# S3 integration: NO live gate exists (stated, not skipped-over). The prior
# `test-s3-matrix` target + MinIO testbed were removed from v-stdlib with the
# old tap subsystem (v-stdlib Makefile, "prior S3 round-trip targets" note) —
# this sweep called the dead target until 2026-07-16, so the step could only
# fail or be --skip-s3'd. The greenfield v-rpc-tap effort brings its own
# validation when it lands; until then absence is printed, never silent.
echo
echo "  S3 integration: no live gate (tap parked; prior test-s3-matrix removed with the old tap subsystem)"

# ============================ summary ============================
total=$((SECONDS - RUN_START))
printf '\n%s==================== SUMMARY (%ss) ====================%s\n' "$BOLD" "$total" "$RESET"
for r in "${RESULTS[@]}"; do
  case "$r" in
    PASS*) printf '  %s%s%s\n' "$GREEN" "$r" "$RESET" ;;
    FAIL*) printf '  %s%s%s\n' "$RED" "$r" "$RESET" ;;
  esac
done
printf '%s\n' "------------------------------------------------------"
if [ "$FAILED" -eq 0 ]; then
  printf '  %sALL %s STEPS PASSED%s\n' "$GREEN" "${#RESULTS[@]}" "$RESET"
  exit 0
else
  printf '  %s%s of %s STEPS FAILED%s\n' "$RED" "$FAILED" "${#RESULTS[@]}" "$RESET"
  exit 1
fi
