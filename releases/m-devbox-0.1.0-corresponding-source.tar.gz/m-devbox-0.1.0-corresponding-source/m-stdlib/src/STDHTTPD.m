STDHTTPD       ; m-stdlib — portable HTTP server framework (router + middleware + worker loop).
        ; doc: @tag v0.11.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ; m-lint: disable-file=M-MOD-036
        ; (M-MOD-036 = tainted-local-into-indirection. This module's contract IS
        ;  dispatch to caller-injected TAG^ROUTINE refs — the transport read/
        ;  write refs, handler/middleware refs, and the log hook (Q1/Q2/Q4). The
        ;  indirection is the seam, not an injection bug; suppressed file-wide.)
        ;
        ; The engine-agnostic half of the VistA-native HTTPS stack (the VWEB
        ; capstone): the §6 route-match engine, the §6/§7 middleware chain, and
        ; the §4 per-connection worker request/response loop. It sits directly
        ; on the M6.1 STDHTTPMSG codec (parse/serialize) and below the
        ; VistA-specific vweb listener (VWEBL/VWEBIO, M6.3+). Pure-M and
        ; identical on YottaDB and IRIS: no sockets, no TLS, no VistA, no
        ; FileMan, no XPAR, no $ZF.
        ;
        ; Three design seams keep it portable (kickoff Q1-Q4):
        ;   Q1 TRANSPORT IS INJECTED. serve() never touches a socket — the
        ;      caller supplies a transport descriptor TR with read/write
        ;      entry-refs and an opaque connection handle. STDHTTPD reaches the
        ;      wire only via  set n=$$@TR("read")(conn,max,timeout,.buf)  and
        ;      do/$$@TR("write")(conn,bytes). The signatures match STDNET's
        ;      $$read/$$write so VWEBL (M6.3) can hand a real STDNET/VWEBIO
        ;      transport down unchanged; tests drive an in-memory fake.
        ;   Q2 HANDLERS / MIDDLEWARE ARE TAG^ROUTINE refs invoked by M
        ;      indirection with a fixed by-ref signature:
        ;        handler     do @ref(.REQ,.RSP)
        ;        middleware   do @ref(.REQ,.RSP,.CTX)   (may set CTX("stop")=1)
        ;   Q3 THE ROUTE TABLE IS CALLER-OWNED DATA (the SRV local array), never
        ;      FileMan — VWEBR (M6.4) sources routes from a FileMan file and
        ;      registers them into this same array. Patterns are literal + :named
        ;      segments + an optional trailing * wildcard; trailing slashes are
        ;      insignificant; first-registered route wins on overlap.
        ;   Q4 A handler fault -> 500 with a SANITIZED body; the internal detail
        ;      goes only to an INJECTED log hook (opts("logref")), never the HTTP
        ;      body. Caught with a flag-based $ETRAP (NEVER zgoto — the M4
        ;      harness-abort gotcha); a parse-status from STDHTTPMSG (400/413/
        ;      414/431) is turned into the matching error response; an unmatched
        ;      route -> 404; a method mismatch -> 405 (+ Allow).
        ;
        ; Public extrinsics / entry points:
        ;   $$route(.SRV,method,pattern,handler,.opts)  — register a route -> index
        ;   $$match(.SRV,method,path,.route,.params)     — match -> 200/404/405
        ;   $$use(.SRV,mwref,.opts)                       — register a middleware -> index
        ;   $$dispatch(.SRV,.REQ,.RSP,.opts)             — run one request -> status
        ;   $$serve(.SRV,.TR,conn,.opts)                 — worker loop -> requests served
        ;   requestId / noop                             — built-in middlewares
        ;
        quit
        ;
        ; ---------- router (spec §6) ----------
        ;
route(SRV,method,pattern,handler,opts)  ; Register a route into the caller-owned SRV table.
        ; doc: @param SRV     array   by-ref route table (caller-owned; VWEBR sources it from FileMan later)
        ; doc: @param method  string  HTTP verb, or "*" to match any verb
        ; doc: @param pattern string  path pattern: literal + :named segments + optional trailing *
        ; doc: @param handler string  TAG^ROUTINE handler ref, invoked do @handler(.REQ,.RSP)
        ; doc: @param opts    array   by-ref per-route opts (e.g. auth/scope — consumed by middleware); optional
        ; doc: @returns       numeric the new route's index
        ; doc: @example       new SRV do eq^STDASSERT(.pass,.fail,$$route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP"),1,"first route registered -> index 1")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPD
        ; doc: @see           $$match^STDHTTPD, $$dispatch^STDHTTPD
        new n,k
        set n=$get(SRV("route"))+1,SRV("route")=n
        set SRV("route",n,"method")=$$ucase(method)
        set SRV("route",n,"pattern")=$$normPath(pattern)
        set SRV("route",n,"handler")=handler
        merge SRV("route",n,"opt")=opts
        ; usable via $$ (returns the index) or DO (side-effect only) — $quit guards the value
        if $quit quit n
        quit
        ;
match(SRV,method,path,route,params)     ; Match a method+path against the route table.
        ; doc: @param SRV     array   by-ref route table populated by $$route
        ; doc: @param method  string  request verb
        ; doc: @param path    string  decoded request path (REQ("path"))
        ; doc: @param route   array   by-ref; on 200 filled with method/pattern/handler/idx/opt; on 405 filled with allow
        ; doc: @param params  array   by-ref; on 200 filled with the captured :named segments (+ "*")
        ; doc: @returns       numeric 200 match; 404 no path matched; 405 path matched but method did not
        ; doc: @example       new SRV,route,params do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") do eq^STDASSERT(.pass,.fail,$$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params),200,"method+path hit -> 200")
        ; doc: @example       new SRV,route,params,st do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") set st=$$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params) do eq^STDASSERT(.pass,.fail,params("id"),"123","named :id segment captured into params")
        ; doc: @example       new SRV,route,params do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") do eq^STDASSERT(.pass,.fail,$$match^STDHTTPD(.SRV,"GET","/nope",.route,.params),404,"no path matched -> 404")
        ; doc: @example       new SRV,route,params,st do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") set st=$$match^STDHTTPD(.SRV,"POST","/Patient/123",.route,.params) do eq^STDASSERT(.pass,.fail,route("allow"),"GET","path matched but method did not -> 405 fills Allow")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPD
        ; doc: @see           $$route^STDHTTPD
        new n,p,um,anyhit,allow,result,rm,rpat,prm,pm
        kill route,params
        set p=$$normPath(path),um=$$ucase(method),anyhit=0,result=404
        set n=$order(SRV("route",""))
        for  quit:(n="")!(result=200)  do
        . kill prm
        . set rm=SRV("route",n,"method"),rpat=SRV("route",n,"pattern"),pm=$$matchPath(rpat,p,.prm)
        . set:pm anyhit=1,allow(rm)=""
        . if pm,(rm="*")!(rm=um) do
        . . ; m-lint: disable-next-line=M-MOD-024
        . . merge:$data(prm) params=prm
        . . set route("idx")=n,route("method")=rm,route("handler")=SRV("route",n,"handler"),route("pattern")=rpat
        . . merge route("opt")=SRV("route",n,"opt")
        . . set result=200
        . set n=$order(SRV("route",n))
        if result=200 quit 200
        if 'anyhit quit 404
        set route("allow")=$$joinKeys(.allow)
        quit 405
        ;
        ; ---------- middleware chain (spec §6/§7) ----------
        ;
use(SRV,mwref,opts)     ; Register a middleware ref (run in registration order before the handler).
        ; doc: @param SRV     array   by-ref route table / server config
        ; doc: @param mwref   string  TAG^ROUTINE middleware ref, invoked do @mwref(.REQ,.RSP,.CTX)
        ; doc: @param opts    array   by-ref per-middleware opts; optional
        ; doc: @returns       numeric the new middleware's index (its run order)
        ; doc: @example       new SRV do eq^STDASSERT(.pass,.fail,$$use^STDHTTPD(.SRV,"requestId^STDHTTPD"),1,"first middleware registered -> run order 1")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPD
        ; doc: @see           $$dispatch^STDHTTPD
        new n
        set n=$get(SRV("mw"))+1,SRV("mw")=n,SRV("mw",n)=mwref
        merge SRV("mw",n,"opt")=opts
        ; usable via $$ (returns the index) or DO (side-effect only) — $quit guards the value
        if $quit quit n
        quit
        ;
        ; ---------- single-request pipeline (spec §6 dispatch) ----------
        ;
dispatch(SRV,REQ,RSP,opts)      ; Run one parsed request through middleware -> route -> handler.
        ; doc: @param SRV     array   by-ref route table + middleware chain
        ; doc: @param REQ     array   by-ref parsed request (spec §5.1)
        ; doc: @param RSP     array   by-ref; populated with the response (spec §5.2)
        ; doc: @param opts    array   by-ref; opts("logref") = injected log hook ref do @ref(.EV); optional
        ; doc: @returns       numeric the final HTTP status (200 handler-ok / 404 / 405 / 401.. / 500)
        ; doc: @example       new SRV,REQ,RSP do route^STDHTTPD(.SRV,"GET","/healthz","noop^STDHTTPD") set REQ("method")="GET",REQ("path")="/healthz" do eq^STDASSERT(.pass,.fail,$$dispatch^STDHTTPD(.SRV,.REQ,.RSP),200,"matched route, handler returned cleanly -> 200")
        ; doc: @example       new SRV,REQ,RSP do route^STDHTTPD(.SRV,"GET","/healthz","noop^STDHTTPD") set REQ("method")="GET",REQ("path")="/nope" do eq^STDASSERT(.pass,.fail,$$dispatch^STDHTTPD(.SRV,.REQ,.RSP),404,"no matching route -> 404 sanitized")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPD
        ; doc: @see           $$serve^STDHTTPD, $$match^STDHTTPD
        ; doc: Middleware run in registration order; any may short-circuit by
        ; doc: setting CTX("stop")=1 (and populating RSP) so the handler never
        ; doc: runs. An uncaught middleware/handler fault -> 500 sanitized, with
        ; doc: detail to opts("logref") only (flag-based $ETRAP, never zgoto).
        new logref,i,mw,CTX,st,detail,mst,route,params
        set logref=$get(opts("logref"))
        ; middleware chain (run before the handler; first non-200 -> 500)
        set i=$order(SRV("mw",""))
        for  quit:(i="")!($get(CTX("stop")))!($get(st,200)'=200)  do
        . set mw=SRV("mw",i),st=$$invoke(1,mw,.REQ,.RSP,.CTX,.detail)
        . if st'=200 do logFault(logref,detail,.REQ,500),setError(.RSP,500)
        . set i=$order(SRV("mw",i))
        if $get(st,200)'=200 quit 500
        if $get(CTX("stop")) quit $get(RSP("status"),200)
        ; route
        set mst=$$match(.SRV,$get(REQ("method")),$get(REQ("path")),.route,.params)
        if mst=404 do setError(.RSP,404) quit 404
        if mst=405 do setError(.RSP,405,$get(route("allow"))) quit 405
        merge REQ("param")=params
        ; handler (trapped)
        set st=$$invoke(0,route("handler"),.REQ,.RSP,.CTX,.detail)
        if st'=200 do logFault(logref,detail,.REQ,500),setError(.RSP,500) quit 500
        quit 200
        ;
invoke(kind,ref,REQ,RSP,CTX,detail)     ; Call a handler/middleware ref under an engine-appropriate fault trap.
        ; doc: @internal
        ; doc: kind 1 = middleware (3-arg do @ref(.REQ,.RSP,.CTX)); kind 0 =
        ; doc: handler (2-arg do @ref(.REQ,.RSP)). Returns 200 on clean return,
        ; doc: 500 on an uncaught fault (detail by-ref = $zstatus). Fault trapping
        ; doc: genuinely diverges per engine (same split as STDHARN): YDB uses a
        ; doc: flag-based $ETRAP (NEVER zgoto — the M4 harness-abort gotcha); IRIS
        ; doc: needs an ObjectScript try/catch (no flag-$ETRAP catch). By-ref args
        ; doc: are top-level (REQ/RSP/CTX), so they survive the IRIS xecute boundary.
        new $etrap,st,call
        set st=200,detail=""
        ; full-argument indirection: `do @ref(args)` (entryref indirection + an
        ; actuallist) is NOT accepted by YDB — indirect the WHOLE command argument.
        set call=ref_$select(kind:"(.REQ,.RSP,.CTX)",1:"(.REQ,.RSP)")
        ; IRIS error detail is $zerror (not the YDB $zstatus); referencing
        ; $zstatus inside an IRIS catch raises, which would re-abort the trap.
        if $zversion["IRIS" xecute "try { do "_call_" } catch ex { set st=500,detail=$zerror }" quit st
        set $etrap="set detail=$zstatus,st=500,$ecode="""" quit"
        do @call
        quit st
        ;
        ; ---------- worker request/response loop (spec §4) ----------
        ;
serve(SRV,TR,conn,opts) ; Run the full HTTP exchange for one connection over the injected transport.
        ; doc: @param SRV     array   by-ref route table + middleware chain
        ; doc: @param TR      array   by-ref transport descriptor: TR("read")/TR("write") entry-refs
        ; doc: @param conn    string  opaque connection handle passed to the transport refs
        ; doc: @param opts    array   by-ref injected limits + logref (maxhdrbytes/maxbody/maxrequests/idletimeout/logref); optional
        ; doc: @returns       numeric the number of requests served on this connection
        ; doc: @example       set n=$$serve^STDHTTPD(.SRV,.TR,conn,.opts)
        ; doc: @illustrative  needs an injected transport (TR read/write entry-refs) bound to a live connection; the worker loop cannot run self-contained on a one-line expression (see STDHTTPDTST tServeGetExchange for the in-memory-fake harness)
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPD
        ; doc: @see           $$dispatch^STDHTTPD, $$parseReq^STDHTTPMSG
        ; doc: Reads a complete request (honoring Content-Length / chunked) over
        ; doc: TR, parses it with $$parseReq^STDHTTPMSG, dispatches, serializes
        ; doc: with $$serializeRsp^STDHTTPMSG, writes via TR, then loops the
        ; doc: request/response cycle until Connection: close, a clean close, or
        ; doc: the max-requests-per-connection cap. A parse/framing error -> the
        ; doc: matching 4xx response, then close.
        new cap,BUF,reqcount,done,st,reqbytes,REQ,RSP,pst,ka
        do srvcaps(.opts,.cap)
        set BUF="",reqcount=0,done=0
        for  do  quit:done
        . kill REQ,RSP
        . set st=$$nextRequest(.TR,conn,.cap,.BUF,.reqbytes)
        . if st=0 set done=1 quit
        . set reqcount=reqcount+1
        . if st'=200 do errClose(.TR,conn,.RSP,st,.done) quit
        . set pst=$$parseReq^STDHTTPMSG(reqbytes,.REQ,.opts)
        . if pst'=200 do errClose(.TR,conn,.RSP,pst,.done) quit
        . set st=$$dispatch(.SRV,.REQ,.RSP,.opts)
        . set ka=$$wantKeepAlive(.REQ,.RSP,reqcount,cap("maxrequests"))
        . set RSP("keepalive")=ka
        . do writeResponse(.TR,conn,.RSP)
        . if 'ka set done=1
        quit reqcount
        ;
nextRequest(TR,conn,cap,BUF,reqbytes)   ; Read/frame one complete request; trim it off BUF.
        ; doc: @internal
        ; doc: Returns 200 (reqbytes holds one complete request), 0 (clean close,
        ; doc: no more data), or 400/413/431 (a framing/cap error). BUF carries
        ; doc: any pipelined remainder across calls.
        new rref,fr,end,n,chunk,done,res,tmo
        set rref=TR("read"),reqbytes="",done=0,res=0,tmo=cap("idletimeout"),n=0
        for  do  quit:done
        . set fr=$$frameEnd(BUF,.cap,.end)
        . if fr>1 set res=fr,done=1 quit
        . if fr=1 set reqbytes=$extract(BUF,1,end),BUF=$extract(BUF,end+1,$length(BUF)),res=200,done=1 quit
        . ; full-argument indirection — `set n=$$@rref(args)` is rejected by YDB
        . set chunk="" set @("n=$$"_rref_"(conn,16384,tmo,.chunk)")
        . if n'>0 set res=$select(BUF="":0,1:400),done=1 quit
        . set BUF=BUF_chunk
        quit res
        ;
frameEnd(buf,cap,end)   ; Find the end byte of the first complete request in buf.
        ; doc: @internal
        ; doc: Returns 0 (need more), 1 (complete; end = last byte index), 431
        ; doc: (headers over cap before terminator) or 413 (body over cap). This
        ; doc: is FRAMING only — STDHTTPMSG does the real parse on the framed bytes.
        new crlf,bp,head,te,cl,bodylen,tpos,res
        set crlf=$char(13,10),end=0,res=0
        set bp=$find(buf,crlf_crlf)
        if 'bp quit $select($length(buf)>cap("maxhdrbytes"):431,1:0)
        set head=$extract(buf,1,bp-5)
        set te=$$lcase($$scanHdr(head,"transfer-encoding"))
        if te["chunked" do  quit res
        . if $extract(buf,bp,bp+4)=("0"_crlf_crlf) set end=bp+4,res=1 quit
        . set tpos=$find(buf,crlf_"0"_crlf_crlf,bp-1)
        . if 'tpos set res=$select(($length(buf)-bp+1)>cap("maxbody"):413,1:0) quit
        . set end=tpos-1,res=1
        set cl=$$scanHdr(head,"content-length")
        if cl="" set end=bp-1 quit 1
        if cl'?1.N set end=bp-1 quit 1
        if cl>cap("maxbody") quit 413
        set bodylen=$length(buf)-(bp-1)
        if bodylen<cl quit 0
        set end=(bp-1)+cl
        quit 1
        ;
scanHdr(head,name)      ; Case-insensitive single-header lookup over a raw header block (framing only).
        ; doc: @internal
        new crlf,n,i,line,cp,hn,want,val
        set crlf=$char(13,10),want=$$lcase(name),val="",n=$length(head,crlf)
        for i=2:1:n do  quit:val'=""
        . set line=$piece(head,crlf,i),cp=$find(line,":")
        . if 'cp quit
        . set hn=$$lcase($$trim^STDSTR($extract(line,1,cp-2)))
        . if hn=want set val=$$trim^STDSTR($extract(line,cp,$length(line)))
        quit val
        ;
writeResponse(TR,conn,RSP)      ; Serialize RSP and write it over the transport.
        ; doc: @internal
        new wref,bytes,ok
        set wref=TR("write"),bytes=$$serializeRsp^STDHTTPMSG(.RSP)
        ; full-argument indirection — `set ok=$$@wref(args)` is rejected by YDB
        set @("ok=$$"_wref_"(conn,bytes)")
        quit
        ;
sendClose(TR,conn,RSP)  ; Write an error RSP with Connection: close.
        ; doc: @internal
        set RSP("keepalive")=0
        do writeResponse(.TR,conn,.RSP)
        quit
        ;
wantKeepAlive(REQ,RSP,reqcount,maxreq)  ; Decide whether to keep the connection alive after this response.
        ; doc: @internal
        ; doc: Honors the request's keep-alive intent, a handler-forced close
        ; doc: (RSP Connection: close or RSP("keepalive")=0), and the
        ; doc: max-requests-per-connection cap.
        new ka
        set ka=$get(REQ("keepalive"),0)
        if reqcount'<maxreq set ka=0
        if $$lcase($$hdr^STDHTTPMSG(.RSP,"connection"))["close" set ka=0
        if $data(RSP("keepalive")),'RSP("keepalive") set ka=0
        quit ka
        ;
        ; ---------- error responses + log hook (spec §6 step 5 / §12) ----------
        ;
setError(RSP,status,allow)      ; Build a sanitized JSON error response (no internal detail).
        ; doc: @internal
        new reason
        kill RSP
        set reason=$$phrase(status)
        set RSP("status")=status,RSP("json")="o",RSP("json","error")="s:"_reason
        if $get(allow)'="" set RSP("hdr","Allow")=allow
        quit
        ;
logFault(logref,detail,REQ,status)      ; Emit a fault event to the injected log hook (default no-op).
        ; doc: @internal
        new EV
        if $get(logref)="" quit
        set EV("type")="error",EV("detail")=$get(detail)
        set EV("method")=$get(REQ("method")),EV("path")=$get(REQ("path")),EV("status")=status
        do @(logref_"(.EV)")
        quit
        ;
        ; ---------- built-in middlewares (usable refs; not VistA) ----------
        ;
requestId(REQ,RSP,CTX)  ; Built-in middleware: stamp a per-request correlation id into CTX.
        ; doc: @param REQ     array   by-ref request
        ; doc: @param RSP     array   by-ref response
        ; doc: @param CTX     array   by-ref pipeline context; sets CTX("requestid")
        ; doc: @example       new REQ,RSP,CTX do requestId^STDHTTPD(.REQ,.RSP,.CTX) do true^STDASSERT(.pass,.fail,$get(CTX("requestid"))'="","stamps a non-empty correlation id (value varies per run)")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        set CTX("requestid")=$job_"-"_$piece($horolog,",",2)_"-"_$increment(^STDLIB($job,"httpd","seq"))
        quit
        ;
noop(REQ,RSP,CTX)       ; Built-in no-op middleware (a placeholder / chain probe).
        ; doc: @param REQ     array   by-ref request
        ; doc: @param RSP     array   by-ref response
        ; doc: @param CTX     array   by-ref pipeline context (untouched)
        ; doc: @example       new REQ,RSP,CTX do noop^STDHTTPD(.REQ,.RSP,.CTX) do false^STDASSERT(.pass,.fail,$data(CTX),"no-op leaves CTX untouched")
        ; doc: @since         v0.11.0
        ; doc: @stable        stable
        quit
        ;
        ; ---------- internal helpers ----------
        ;
errClose(TR,conn,RSP,status,done)       ; Write a sanitized error response, close, and stop the worker loop.
        ; doc: @internal
        do setError(.RSP,status)
        do sendClose(.TR,conn,.RSP)
        set done=1
        quit
        ;
joinKeys(arr)   ; Comma-join an array's first-level subscripts (deterministic $order collation).
        ; doc: @internal
        new k,out
        set out="",k=$order(arr(""))
        for  quit:k=""  do
        . set out=out_$select(out="":"",1:", ")_k,k=$order(arr(k))
        quit out
        ;
srvcaps(opts,cap)       ; Resolve injected worker limits with safe defaults.
        ; doc: @internal
        set cap("maxhdrbytes")=$get(opts("maxhdrbytes"),16384)
        set cap("maxbody")=$get(opts("maxbody"),1048576)
        set cap("maxrequests")=$get(opts("maxrequests"),100)
        set cap("idletimeout")=$get(opts("idletimeout"),30)
        quit
        ;
matchPath(pat,path,prm) ; True iff path matches pattern; captures :named segments (+ trailing *).
        ; doc: @internal
        new np,nx,i,pseg,xseg,ok,last
        kill prm
        set ok=0,np=$length(pat,"/"),nx=$length(path,"/"),last=$piece(pat,"/",np)
        if last="*" do  quit ok
        . set ok=1
        . if nx<(np-1) set ok=0 quit
        . for i=1:1:np-1 do  quit:'ok
        . . set pseg=$piece(pat,"/",i),xseg=$piece(path,"/",i)
        . . if $extract(pseg,1)=":" set prm($extract(pseg,2,$length(pseg)))=xseg quit
        . . if pseg'=xseg set ok=0
        . if ok set prm("*")=$piece(path,"/",np,nx)
        if np'=nx quit 0
        set ok=1
        for i=1:1:np do  quit:'ok
        . set pseg=$piece(pat,"/",i),xseg=$piece(path,"/",i)
        . if $extract(pseg,1)=":" set prm($extract(pseg,2,$length(pseg)))=xseg quit
        . if pseg'=xseg set ok=0
        quit ok
        ;
normPath(p)     ; Normalize a path/pattern: empty -> "/"; strip one trailing slash (except root).
        ; doc: @internal
        if p="" quit "/"
        if p="/" quit "/"
        if $extract(p,$length(p))="/" quit $extract(p,1,$length(p)-1)
        quit p
        ;
ucase(s)        ; ASCII upper-case (delegates to STDSTR).
        ; doc: @internal
        quit $$toUpperASCII^STDSTR(s)
        ;
lcase(s)        ; ASCII lower-case (delegates to STDSTR).
        ; doc: @internal
        quit $$toLowerASCII^STDSTR(s)
        ;
phrase(status)  ; Short reason phrase for the handful of status codes STDHTTPD emits.
        ; doc: @internal
        new r
        set r=$select(status=400:"Bad Request",status=404:"Not Found",status=405:"Method Not Allowed",1:"")
        if r="" set r=$select(status=413:"Payload Too Large",status=414:"URI Too Long",1:"")
        if r="" set r=$select(status=431:"Request Header Fields Too Large",status=500:"Internal Server Error",1:"Error")
        quit r
        ;
