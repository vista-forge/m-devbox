STDJWT  ; m-stdlib — JSON Web Token (RFC 7519 / 9068) validation.
        ; doc: @tag v0.13.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ; doc: @tier optional
        ; doc: @seam STDJWT v2
        ;
        ; Resource-server-side token handling: parse a compact JWS, verify the
        ; signature, and validate the registered claims (RFC 7519 §4.1 exp/nbf/
        ; iss/aud) the way an OAuth 2.0 resource server must (RFC 9068). This is
        ; deliberately NOT an authorization server — there is no production token
        ; issuance here; $$sign exists for dev/test fixtures only.
        ;
        ; Algorithms: HS256 (HMAC-SHA-256, symmetric) plus the ASYMMETRIC leg —
        ; RS/PS/ES256/384/512 and EdDSA — verified via $$verifySig^STDCRYPTO
        ; against the CALLER's SubjectPublicKeyInfo key. STDJWT owns the algorithm
        ; POLICY that STDCRYPTO (alg-agnostic by design) cannot: it rejects
        ; alg:"none", enforces a caller-supplied alg allowlist the token can never
        ; widen, and pins alg-family to key-type (an HMAC alg is unreachable when
        ; an asymmetric key is expected — the RS->HS forgery). See §11 / N-1 of
        ; docs/proposals/stdcrypto-asymmetric-verify-v2.md. EdDSA is YDB-only
        ; (IRIS raises U-STDCRYPTO-BADALG -> a clean verify=0), inherited from
        ; STDCRYPTO. The trusted key is ALWAYS the `key` param — never a key lifted
        ; from the token's own jwk/x5c/kid header.
        ;
        ; Layer m (engine-neutral): consumes STDB64 (base64url), STDCRYPTO (HMAC +
        ; public-key verify — an OPTIONAL callout, so STDJWT is @tier optional
        ; too), STDJSON (header/claims trees) and STDDATE (the epoch clock). NO
        ; VistA. The VistA identity binding (a validated subject -> NEW PERSON
        ; #200 / DUZ) lives ABOVE the waterline in v-stdlib — never here.
        ;
        ; Claims/header trees use the STDJSON typed-node convention
        ; ("o"/"a"/"s:VALUE"/"n:VALUE"); read a scalar with $$valueOf^STDJSON.
        ;
        ; Public:
        ;   $$verify(token,key,.claims,.opts) — signature + claims; 1/0, claims by-ref
        ;   $$decode(token,.hdr,.claims)      — parse header+claims, NO verify; 1/0
        ;   $$claim(token,name)               — one-shot unverified single-claim value
        ;   $$sign(.claims,key,.opts)         — DEV/TEST ONLY: build an HS256 token
        ;   $$lastError()                     — last failure reason ("" when none)
        ;
        ; opts (verify, all optional): now=epoch override (default $$epoch^STDDATE);
        ;   leeway=clock-skew seconds (default 0); iss=required issuer;
        ;   aud=required audience.
        ;   ALG ALLOWLIST (the token can never widen it): algs=a CSV of accepted
        ;   algs (e.g. "RS256,ES256"); alg=a single accepted alg (legacy seed).
        ;   Precedence algs > alg > default "HS256". For an asymmetric alg, `key`
        ;   is the caller's SPKI public key; for HS256 it is the HMAC secret. A
        ;   single verify call has ONE key, so ONE family — an allowlist mixing an
        ;   HMAC alg with an asymmetric alg is refused fail-closed (it would reopen
        ;   the RS->HS door).
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
verify(token,key,claims,opts)   ; Verify signature + registered claims; 1 iff valid.
        ; doc: @param token   string  compact JWS (header.payload.signature, base64url)
        ; doc: @param key     string  HMAC shared secret (HS256) OR the caller's SPKI public key (DER/PEM) for an asymmetric alg
        ; doc: @param claims  array   by-ref; populated with the claims tree (STDJSON typed nodes)
        ; doc: @param opts    array   by-ref; now/leeway/iss/aud + the alg allowlist algs/alg (all optional)
        ; doc: @returns       bool    1 if signature + exp/nbf/iss/aud all pass; 0 otherwise ($$lastError set)
        ; doc: @example       new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do true^STDASSERT(.pass,.fail,$$verify^STDJWT($$sign^STDJWT(.c,"secret"),"secret"),"verify a self-signed token")
        ; doc: @example       do false^STDASSERT(.pass,.fail,$$verify^STDJWT("not.a.jwt","k"),"a malformed token verifies as 0")
        ; doc: @since         v0.13.0
        ; doc: @stable        stable
        ; doc: @seam          STDJWT v2
        ; doc: @see           $$decode^STDJWT, $$sign^STDJWT, $$verifySig^STDCRYPTO, $$valueOf^STDJSON
        ; doc: ALGORITHM-CONFUSION DEFENSE (proposal §11, finding N-1) — STDCRYPTO
        ; doc: answers one question over bytes and delegates ALL alg policy here.
        ; doc: Before verifying a signature this verb (1) rejects alg:"none"/absent
        ; doc: unconditionally; (2) requires the header alg to be in the CALLER's
        ; doc: allowlist (opts algs/alg; default HS256) — the token never widens it;
        ; doc: (3) selects the verify PATH from the vetted alg's FAMILY, never the
        ; doc: raw header, and refuses an allowlist mixing HMAC with asymmetric algs,
        ; doc: so the RS->HS key-confusion forgery is structurally closed; (4) uses
        ; doc: only the caller's `key`, never one embedded in the token's header.
        new HD,si,want,got,alg,allow,fam,ok,now,leeway,exp,nbf
        kill claims
        if $length(token,".")'=3 do setErr("malformed token: expected 3 base64url segments") quit 0
        if '$$decode(token,.HD,.claims) quit 0
        set alg=$$valueOf^STDJSON($get(HD("alg")))
        ; --- (1) reject none/absent unconditionally: never a signature-skipping path ---
        if alg="" do setErr("missing alg header") quit 0
        if $zconvert(alg,"L")="none" do setErr("alg 'none' is never accepted") quit 0
        ; --- (2)+(3) the verify alg must be a single-family member of the caller allowlist ---
        set allow=$$allowlist(.opts)
        if $$mixedFamily(allow) do setErr("allowlist mixes HMAC and asymmetric algs (one key = one family)") quit 0
        if '$$inList(allow,alg) do setErr("alg '"_alg_"' not in the caller allowlist ("_allow_")") quit 0
        ; --- signature check: PATH chosen by the vetted alg's family, key = caller's `key` ---
        set si=$piece(token,".",1)_"."_$piece(token,".",2)
        set got=$piece(token,".",3)
        set ok=0,fam=$$family(alg)
        if fam="hmac" set ok=$$hmacOk(key,si,got)
        if fam="asym" set ok=$$asymVerify(alg,key,si,$$urldecode^STDB64(got))
        if fam="" do setErr("unsupported alg '"_alg_"'")
        if 'ok quit 0
        ; --- registered-claim checks (RFC 7519 §4.1) ---
        set now=$get(opts("now")) set:now="" now=$$epoch^STDDATE()
        set leeway=+$get(opts("leeway"))
        set exp=$$valueOf^STDJSON($get(claims("exp")))
        if exp'="",now'<(exp+leeway) do setErr("token expired") quit 0
        set nbf=$$valueOf^STDJSON($get(claims("nbf")))
        if nbf'="",now<(nbf-leeway) do setErr("token not yet valid (nbf in the future)") quit 0
        if $get(opts("iss"))'="",$$valueOf^STDJSON($get(claims("iss")))'=opts("iss") do setErr("issuer mismatch") quit 0
        if $get(opts("aud"))'="",'$$audOk(.claims,opts("aud")) do setErr("audience mismatch") quit 0
        do clearErr()
        quit 1
        ;
decode(token,hdr,claims)        ; Parse header + claims trees; NO signature/claim check.
        ; doc: @param token   string  compact JWS
        ; doc: @param hdr     array   by-ref; the decoded JOSE header tree
        ; doc: @param claims  array   by-ref; the decoded claims (payload) tree
        ; doc: @returns       bool    1 if both segments base64url-decode and parse as JSON; else 0
        ; doc: @example       new c,h,cl set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$$decode^STDJWT($$sign^STDJWT(.c,"k"),.h,.cl),1,"decode parses a signed token")
        ; doc: @since         v0.13.0
        ; doc: @stable        stable
        ; doc: @seam          STDJWT v2
        ; doc: @see           $$verify^STDJWT
        ; doc: Inspect-only: a 1 here means "well-formed", NOT "trusted". Never
        ; doc: make an authorization decision on $$decode output — use $$verify.
        kill hdr,claims
        if $length(token,".")'=3 do setErr("malformed token: expected 3 base64url segments") quit 0
        if '$$parse^STDJSON($$urldecode^STDB64($piece(token,".",1)),.hdr) do setErr("malformed token: header is not JSON") quit 0
        if '$$parse^STDJSON($$urldecode^STDB64($piece(token,".",2)),.claims) do setErr("malformed token: claims are not JSON") quit 0
        quit 1
        ;
claim(token,name)       ; One-shot UNVERIFIED read of a single claim's scalar value.
        ; doc: @param token   string  compact JWS
        ; doc: @param name    string  claim name (e.g. "sub", "iss", "scope")
        ; doc: @returns       string  the claim's scalar value, or "" if absent/unparseable
        ; doc: @example       new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$$claim^STDJWT($$sign^STDJWT(.c,"k"),"sub"),"u1","read the sub claim")
        ; doc: @since         v0.13.0
        ; doc: @stable        stable
        ; doc: @seam          STDJWT v2
        ; doc: @see           $$verify^STDJWT
        ; doc: Convenience for logging/diagnostics. UNVERIFIED — do not authorize on it.
        new HD,CL
        if '$$decode(token,.HD,.CL) quit ""
        quit $$valueOf^STDJSON($get(CL(name)))
        ;
sign(claims,key,opts)   ; DEV/TEST ONLY — build an HS256 compact JWS from a claims tree.
        ; doc: @param claims  array   by-ref claims tree (STDJSON typed nodes)
        ; doc: @param key     string  HMAC shared secret
        ; doc: @param opts    array   by-ref; reserved (header overrides) — optional
        ; doc: @returns       string  a signed HS256 token
        ; doc: @example       new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$length($$sign^STDJWT(.c,"k"),"."),3,"sign emits a 3-part compact JWS")
        ; doc: @since         v0.13.0
        ; doc: @stable        stable
        ; doc: @seam          STDJWT v2
        ; doc: @see           $$verify^STDJWT
        ; doc: For test fixtures and local dev tokens. NOT a production issuer —
        ; doc: real tokens come from the IdP/STS; this never manages signing keys.
        new hdr,si
        set hdr="{""alg"":""HS256"",""typ"":""JWT""}"
        set si=$$urlencode^STDB64(hdr)_"."_$$urlencode^STDB64($$encode^STDJSON(.claims))
        quit si_"."_$$urlencode^STDB64($$hmacSha256Bytes^STDCRYPTO(key,si))
        ;
lastError()     ; The reason the most recent $$verify/$$decode failed ("" when none).
        ; doc: @returns       string  the last failure message, or ""
        ; doc: @example       set v=$$verify^STDJWT("a.b","k") do eq^STDASSERT(.pass,.fail,$$lastError^STDJWT(),"malformed token: expected 3 base64url segments","lastError reports the prior failure")
        ; doc: @since         v0.13.0
        ; doc: @stable        stable
        ; doc: @seam          STDJWT v2
        quit $get(^STDLIB($job,"stdjwt","err"))
        ;
        ; ---------- internals ----------
        ;
audOk(claims,want)      ; 1 iff the aud claim (scalar or array, RFC 7519 §4.1.3) covers `want`.
        ; doc: @internal
        new node,i,found
        set node=$get(claims("aud"))
        if node="" quit 0
        if node'="a" quit ($$valueOf^STDJSON(node)=want)
        set found=0,i=""
        for  set i=$order(claims("aud",i)) quit:(i="")!found  if $$valueOf^STDJSON($get(claims("aud",i)))=want set found=1
        quit found
        ;
cteq(a,b)       ; Best-effort constant-time string equality (no early-exit on first diff).
        ; doc: @internal
        new i,n,d
        set n=$length(a)
        if $length(b)'=n quit 0
        set d=0
        for i=1:1:n set d=d+($ascii(a,i)'=$ascii(b,i))
        quit 'd
        ;
hmacOk(key,si,got)      ; HS256 path: recompute the HMAC over the signing input and constant-time compare.
        ; doc: @internal
        ; doc: The HMAC leg NEVER routes through $$verifySig (that is public-key
        ; doc: verify); it recomputes and compares, so `key` is the shared secret.
        new want
        set want=$$urlencode^STDB64($$hmacSha256Bytes^STDCRYPTO(key,si))
        if $$cteq(got,want) quit 1
        do setErr("signature mismatch")
        quit 0
        ;
asymVerify(alg,key,si,sig)      ; Asymmetric path: $$verifySig^STDCRYPTO under an engine-appropriate trap.
        ; doc: @internal
        ; doc: A forged/oddball token must be a NORMAL 0, never a raise out of
        ; doc: $$verify. verifySig returns 0 for a bad signature but RAISES for a
        ; doc: bad key / unsupported alg (e.g. EdDSA on IRIS -> U-STDCRYPTO-BADALG).
        ; doc: The engine split mirrors raises^STDASSERT: YDB uses $ETRAP; IRIS has
        ; doc: no ZGOTO/$ZLEVEL unwind so the YDB $ETRAP-resume faults there (<NOLINE>)
        ; doc: — it uses an ObjectScript try/catch instead. Either way a raise
        ; doc: becomes verify=0 with a clean lastError.
        if $zversion["IRIS" quit $$asymVerifyIris(alg,key,si,sig)
        quit $$asymVerifyYdb(alg,key,si,sig)
        ;
asymVerifyYdb(alg,key,si,sig)   ; YDB arm: $ETRAP maps a nested verifySig raise to a 0 return.
        ; doc: @internal
        ; doc: The trap QUITs 0 straight out of this extrinsic (STDCRYPTO's dispatchV
        ; doc: pattern) — never relying on resume-after-error, which unwinds a nested
        ; doc: frame ambiguously.
        new $etrap,ok
        set $etrap="new ze set ze=$ecode,$ecode="""" do asymErr(ze) quit 0"
        set ok=0
        set ok=+$$verifySig^STDCRYPTO(alg,key,si,sig)
        if 'ok do setErr("signature verification failed")
        quit ok
        ;
asymVerifyIris(alg,key,si,sig)  ; IRIS arm: ObjectScript try/catch (mirrors irisRaises^STDASSERT).
        ; doc: @internal
        new ok,ze
        set ok=0,ze=""
        ; m-lint: disable-next-line=M-MOD-036
        xecute "try { set ok=+$$verifySig^STDCRYPTO(alg,key,si,sig) } catch ex { set ze=$ecode set $ecode="""" }"
        if ze'="" do asymErr(ze) quit 0
        if 'ok do setErr("signature verification failed")
        quit ok
        ;
asymErr(ze)     ; Map a captured STDCRYPTO $ECODE to a clean lastError — never propagate it.
        ; doc: @internal
        do setErr("asymmetric verify error"_$select(ze="":"",1:" ("_$piece(ze,",",2)_")"))
        quit
        ;
allowlist(opts) ; The caller's accepted-alg CSV — the token can never widen it. algs > alg > "HS256".
        ; doc: @internal
        new a
        set a=$get(opts("algs"))
        if a'="" quit a
        set a=$get(opts("alg"))
        if a'="" quit a
        quit "HS256"
        ;
inList(list,alg)        ; 1 iff alg is an exact comma-separated member of list.
        ; doc: @internal
        new i,found
        set found=0
        for i=1:1:$length(list,",") if $piece(list,",",i)=alg set found=1
        quit found
        ;
family(alg)     ; Verify-path family for a JWS alg: "hmac" (HS256), "asym" (RS/PS/ES*/EdDSA), "" if unknown.
        ; doc: @internal
        if $$isHmac(alg) quit "hmac"
        if $$isAsym(alg) quit "asym"
        quit ""
        ;
isHmac(alg)     ; 1 iff alg is the wired HMAC alg (HS256).
        ; doc: @internal
        quit alg="HS256"
        ;
isAsym(alg)     ; 1 iff alg is an $$verifySig-supported asymmetric alg (RS/PS/ES 256/384/512 or EdDSA).
        ; doc: @internal
        new f,s
        if alg="EdDSA" quit 1
        if $length(alg)'=5 quit 0
        set f=$extract(alg,1,2),s=$extract(alg,3,5)
        if '((f="RS")!(f="PS")!(f="ES")) quit 0
        quit (s="256")!(s="384")!(s="512")
        ;
mixedFamily(list)       ; 1 iff the allowlist mixes an HMAC alg with an asymmetric alg (one key = one family).
        ; doc: @internal
        new i,alg,h,a
        set h=0,a=0
        for i=1:1:$length(list,",") set alg=$piece(list,",",i) set:$$isHmac(alg) h=1 set:$$isAsym(alg) a=1
        quit h&a
        ;
setErr(msg)     ; Stash the failure reason for $$lastError.
        ; doc: @internal
        set ^STDLIB($job,"stdjwt","err")=msg
        quit
        ;
clearErr()      ; Clear the stashed failure reason on success.
        ; doc: @internal
        kill ^STDLIB($job,"stdjwt","err")
        quit
