STDNET ; m-stdlib — portable raw-TCP socket primitives (engine-native sockets).
        ; doc: @tag v0.8.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ; doc: @tier optional
        ; m-lint: disable-file=M-MOD-024
        ; M-MOD-024 false positives: the analyser parses the SOCKET-device
        ; OPEN/USE deviceparameters (`listen=`, `connect=`, `delimiter=`,
        ; `socket=`) as local-variable reads-before-definition. They are device
        ; keywords, not locals. Same suppression as STDJSON/STDHTTP.
        ;
        ; The portable socket seam (S4 of the MSL<->VSL coordination plan): a thin
        ; handle-based, raw-byte TCP API that VSLIO binds to VistA's device
        ; handler (^%ZIS / CALL^%ZISTCP) above the waterline, and that any pure-M
        ; service can use directly on a bare engine. No C call-outs — it drives the
        ; engine's NATIVE socket device, with the (large) engine divergence behind
        ; $ZVERSION["IRIS" arms.
        ;
        ; Public API (all raw bytes — no record delimiter / packet framing):
        ;   $$available^STDNET()                 — 1 iff sockets are wired here
        ;   $$listen^STDNET(port)                — open a listening socket -> handle or 0
        ;   $$boundport^STDNET(id)               — the actual bound port of a listener
        ;   $$accept^STDNET(id,timeout)          — accept a pending conn -> conn handle or 0
        ;   $$connect^STDNET(host,port,timeout)  — client connect -> handle or 0
        ;   $$read^STDNET(id,maxlen,timeout,.buf)— raw read up to maxlen bytes -> count
        ;   $$write^STDNET(id,buf)               — raw write -> 1/0
        ;   $$close^STDNET(id)                   — close a handle -> 1
        ;
        ; Handles are small integers; per-handle state (device name, accepted
        ; socket name, bound port) lives in the process-private
        ; ^STDLIB($job,"stdnet",id,*) (portable: no null subscripts).
        ;
        ; Engine support: YottaDB and IRIS. YottaDB's SOCKET device is a
        ; collection of sockets per device, so one process can listen + connect +
        ; accept directly. IRIS has no such device, so the IRIS arm uses |TCP|
        ; devices in accept mode ("A"): the listener's first READ returns "" on
        ; accept and the listener device itself becomes the connection (one
        ; connection per listener); writes flush with WRITE *-3. Both run the
        ; single-process loopback the suite exercises.
        ;
        quit
        ;
        ; ---------- capability ----------
        ;
available()     ; 1 iff STDNET raw sockets are wired on this engine.
        ; doc: @returns bool  1 on YottaDB and IRIS
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @example       write $$available^STDNET()  ; 1
        quit 1
        ;
        ; ---------- socket verbs (the STDNET seam) ----------
        ;
listen(port)    ; Open a listening TCP socket on `port` (0 => OS-assigned).
        ; doc: @param   port     numeric  TCP port to bind; 0 lets the OS choose
        ; doc: @returns numeric  a listener handle (>0), or 0 on failure
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       new srv set srv=$$listen^STDNET(0) do true^STDASSERT(.pass,.fail,srv>0,"opened a listener") set srv=$$close^STDNET(srv)
        new dev,id,pio
        if $$isIris() quit $$listenIris(port)
        set pio=$io,id=$$newid(),dev=$$dev(id)
        open dev:(listen=port_":TCP":delimiter=""):2:"SOCKET"
        if '$test use pio quit 0
        use dev
        write /listen(1)
        set ^STDLIB($job,"stdnet",id,"dev")=dev
        set ^STDLIB($job,"stdnet",id,"port")=$piece($key,"|",3)
        use pio
        quit id
        ;
boundport(id)   ; The actual bound port of a listener handle.
        ; doc: @param   id       numeric  a listener handle from $$listen
        ; doc: @returns numeric  the bound TCP port (meaningful after $$listen)
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @example       new srv set srv=$$listen^STDNET(0) do true^STDASSERT(.pass,.fail,$$boundport^STDNET(srv)>0,"bound to a port") set srv=$$close^STDNET(srv)
        quit +$get(^STDLIB($job,"stdnet",id,"port"))
        ;
accept(id,timeout)      ; Accept a pending connection on a listener handle.
        ; doc: @param   id       numeric  a listener handle from $$listen
        ; doc: @param   timeout  numeric  seconds to wait for a connection
        ; doc: @returns numeric  a connected handle (>0), or 0 on timeout/failure
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       new srv,cli,conn set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5) do true^STDASSERT(.pass,.fail,conn>0,"accepted a connection") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
        new dev,conn,sock,pio
        if $$isIris() quit $$acceptIris(id,timeout)
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set pio=$io
        use dev
        write /wait(timeout)
        if '$test use pio quit 0
        set sock=$piece($key,"|",2)
        use pio
        set conn=$$newid()
        set ^STDLIB($job,"stdnet",conn,"dev")=dev
        set ^STDLIB($job,"stdnet",conn,"sock")=sock
        quit conn
        ;
connect(host,port,timeout)      ; Open a client TCP connection to host:port.
        ; doc: @param   host     string   host/IP to connect to
        ; doc: @param   port     numeric  TCP port
        ; doc: @param   timeout  numeric  seconds to wait for the connect
        ; doc: @returns numeric  a connected handle (>0), or 0 on failure
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       new srv,cli set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5) do true^STDASSERT(.pass,.fail,cli>0,"client connected") set cli=$$close^STDNET(cli),srv=$$close^STDNET(srv)
        new dev,id,pio
        if $$isIris() quit $$connectIris(host,port,timeout)
        set pio=$io,id=$$newid(),dev=$$dev(id)
        open dev:(connect=host_":"_port_":TCP":delimiter=""):timeout:"SOCKET"
        if '$test use pio quit 0
        set ^STDLIB($job,"stdnet",id,"dev")=dev
        use pio
        quit id
        ;
read(id,maxlen,timeout,buf)     ; Raw-read up to maxlen bytes from a handle.
        ; doc: @param   id       numeric  a connected handle
        ; doc: @param   maxlen   numeric  maximum bytes to read
        ; doc: @param   timeout  numeric  seconds to wait for data
        ; doc: @param   buf      string   by-ref; receives the bytes read
        ; doc: @returns numeric  bytes read (0 on timeout/EOF)
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       new srv,cli,conn,buf,n set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5),n=$$write^STDNET(cli,"ping"),n=$$read^STDNET(conn,99,5,.buf) do eq^STDASSERT(.pass,.fail,buf,"ping","server read the client's bytes") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
        new dev,sock,x,pio
        set buf=""
        if $$isIris() quit $$readIris(id,maxlen,timeout,.buf)
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set sock=$get(^STDLIB($job,"stdnet",id,"sock")),pio=$io
        do useh(dev,sock)
        read x#maxlen:timeout
        use pio
        set buf=x
        quit $length(x)
        ;
write(id,buf)   ; Raw-write `buf` to a connected handle.
        ; doc: @param   id       numeric  a connected handle
        ; doc: @param   buf      string   bytes to write (raw, no delimiter)
        ; doc: @returns bool     1 on success; 0 on failure
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       new srv,cli,conn,buf,n set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5),n=$$write^STDNET(cli,"hello"),n=$$read^STDNET(conn,99,5,.buf) do eq^STDASSERT(.pass,.fail,buf,"hello","the written bytes arrived") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
        new dev,sock,pio
        if $$isIris() quit $$writeIris(id,buf)
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set sock=$get(^STDLIB($job,"stdnet",id,"sock")),pio=$io
        do useh(dev,sock)
        write buf
        use pio
        quit 1
        ;
close(id)       ; Close a handle (listener or connection) and free its state.
        ; doc: @param   id       numeric  a handle from $$listen/$$accept/$$connect
        ; doc: @returns bool     1 (idempotent)
        ; doc: @since   v0.8.0
        ; doc: @stable  stable
        ; doc: @seam    STDNET
        ; doc: @example       write $$close^STDNET(0)  ; 1
        new dev,sock
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 1
        set sock=$get(^STDLIB($job,"stdnet",id,"sock"))
        if sock'="" close dev:(socket=sock)
        if sock="" close dev
        kill ^STDLIB($job,"stdnet",id)
        quit 1
        ;
        ; ---------- IRIS socket backend ----------
        ;
        ; IRIS has no collection-of-sockets device, so each handle is its own
        ; |TCP| device. A listener is opened in accept mode ("A"); its first READ
        ; returns "" the moment a client is accepted, and the listener device then
        ; IS the connection (one connection per listener). Writes must flush with
        ; WRITE *-3 (default wait mode buffers otherwise). The ##class call that
        ; reports the bound port is xecute-hidden so YottaDB never compiles it.
        ;
listenIris(port)        ; IRIS: open an accept-mode stream listener on `port`.
        ; doc: @internal
        new dev,id,pio,ok
        set pio=$io,id=$$newid(),dev=$$dev(id)
        ; The IRIS accept-mode OPEN is xecute-hidden so the YottaDB compiler never
        ; parses its IRIS device-parameter syntax (else %YDB-E-DEVPARPARSE reds the
        ; whole ZLINK). $test is captured INSIDE the xecute — it does not propagate
        ; out — so the timeout-failure check below still works. YDB never reaches
        ; this arm; the hide is purely to let the routine compile there.
        xecute "open dev:(:port:""AM""):2 set ok=$test"
        if 'ok use pio quit 0
        use dev
        set ^STDLIB($job,"stdnet",id,"dev")=dev
        set ^STDLIB($job,"stdnet",id,"port")=$$irisport()
        use pio
        quit id
        ;
acceptIris(id,timeout)  ; IRIS: the listener device itself becomes the connection.
        ; doc: @internal
        new dev,conn,x,pio
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set pio=$io
        use dev read x#256:timeout
        use pio
        if '$test quit 0
        set conn=$$newid()
        set ^STDLIB($job,"stdnet",conn,"dev")=dev
        quit conn
        ;
connectIris(host,port,timeout)  ; IRIS: client stream connect to host:port.
        ; doc: @internal
        new dev,id,pio,ok
        set pio=$io,id=$$newid(),dev=$$dev(id)
        ; xecute-hidden IRIS OPEN — see listenIris ($test captured within; the
        ; compiler never sees the IRIS device syntax).
        xecute "open dev:(host:port:""M""):timeout set ok=$test"
        if 'ok use pio quit 0
        set ^STDLIB($job,"stdnet",id,"dev")=dev
        use pio
        quit id
        ;
readIris(id,maxlen,timeout,buf) ; IRIS: raw-read up to maxlen bytes into buf.
        ; doc: @internal
        ; `read x#n:t` on a |TCP| device is CR-TERMINATED — it stops at the first
        ; CR (char 13) and strips the CRLF, mangling binary/HTTP (\r\n) data. So
        ; read one byte at a time with `read *c:t` (a single-character read that
        ; never interprets a terminator) and accumulate. The first read waits up to
        ; `timeout`; once data is flowing, follow-on bytes are read with a zero
        ; timeout so we drain only what is currently available (up to maxlen),
        ; matching the raw-bytes contract. `read *c` returns the byte code, or -1 on
        ; timeout/EOF.
        ;
        ; PEER-CLOSED: a read on a socket whose peer has already closed raises an
        ; IRIS <DSCON>-class disconnect — NOT a flag-$ETRAP-catchable M error; left
        ; alone it kills the whole job. Run the drain loop under an ObjectScript
        ; try/catch (the same idiom invoke^STDHTTPD uses for IRIS faults) so a peer
        ; close yields the already-buffered bytes and THEN a clean 0/EOF return,
        ; matching YDB — instead of aborting. The loop body is byte-identical to the
        ; pre-existing one; only the disconnect trap is added. The whole loop is
        ; xecute-hidden so the YottaDB compiler never sees the ObjectScript braces
        ; (YDB never reaches this arm — read^STDNET routes here only when isIris()).
        new dev,c,pio,t
        set buf=""
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set pio=$io,t=timeout
        use dev
        xecute "try { for { quit:$length(buf)'<maxlen  read *c:t  quit:c<0  set buf=buf_$char(c),t=0 } } catch ex { }"
        use pio
        quit $length(buf)
        ;
writeIris(id,buf)       ; IRIS: raw-write buf to a handle, then flush (WRITE *-3).
        ; doc: @internal
        new dev,pio
        set dev=$get(^STDLIB($job,"stdnet",id,"dev"))
        if dev="" quit 0
        set pio=$io
        use dev write buf write *-3
        use pio
        quit 1
        ;
irisport()      ; IRIS bound local port of the current TCP device (xecute-hidden ##class).
        ; doc: @internal
        new p
        xecute "set p=##class(%SYSTEM.TCPDevice).LocalPort()"
        quit +p
        ;
        ; ---------- internals ----------
        ;
useh(dev,sock)  ; Make the right socket within `dev` current (accepted vs sole).
        ; doc: @internal
        if sock'="" use dev:(socket=sock) quit
        use dev
        quit
        ;
isIris()        ; 1 iff running on InterSystems IRIS.
        ; doc: @internal
        quit $zversion["IRIS"
        ;
dev(id) ; Per-handle socket device name.
        ; doc: @internal
        if $$isIris() quit "|TCP|"_id
        quit "stdnetsk"_id
        ;
newid() ; Allocate a fresh per-process handle id.
        ; doc: @internal
        quit $increment(^STDLIB($job,"stdnet","seq"))
