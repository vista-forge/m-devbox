STDCRYPTO       ; m-stdlib — Cryptographic digests via $&stdcrypto → libcrypto.
        ; doc: @tag v0.4.0
        ; doc: @phase Phase 3 + post-P4 wave
        ; doc: @tier optional
        ; m-lint: disable-file=M-MOD-024
        ; m-lint: disable-file=M-MOD-036
        ; m-lint: disable-file=M-MOD-020
        ; M-MOD-024 false positives: rc is initialised by every entry to
        ; dispatch3 / dispatch4 before any read, but the analyser cannot
        ; track flow through the $ETRAP indirection used to recover from
        ; missing-callout failures.
        ; M-MOD-036 (XECUTE injection) is intentional here: the XECUTE
        ; wrapper is the only way to embed $&stdcrypto.<fn>() without
        ; the tree-sitter-m grammar tripping on the package-prefixed
        ; external-call syntax (open work in tree-sitter-m). The
        ; XECUTEd command string is built only from a literal template
        ; and a `sym` argument that the M-side public surface controls
        ; — no user data ever flows into the XECUTE source. Same
        ; pattern as STDXFRM's @expr indirection.
        ; M-MOD-020 (by-ref formal not written) false positives: dispatch3
        ; / dispatch4 write to `out` by reference, but the writes happen
        ; through the XECUTE'd command string, which the by-ref analyser
        ; can't introspect.
        ;
        ; Public extrinsics:
        ;   $$sha256^STDCRYPTO(data)              — 64-char lowercase hex
        ;   $$sha384^STDCRYPTO(data)              — 96-char lowercase hex
        ;   $$sha512^STDCRYPTO(data)              — 128-char lowercase hex
        ;   $$sha256Bytes^STDCRYPTO(data)         — 32 raw bytes
        ;   $$sha384Bytes^STDCRYPTO(data)         — 48 raw bytes
        ;   $$sha512Bytes^STDCRYPTO(data)         — 64 raw bytes
        ;   $$hmacSha256^STDCRYPTO(key,msg)       — 64-char lowercase hex
        ;   $$hmacSha384^STDCRYPTO(key,msg)       — 96-char lowercase hex
        ;   $$hmacSha512^STDCRYPTO(key,msg)       — 128-char lowercase hex
        ;   $$hmacSha256Bytes^STDCRYPTO(key,msg)  — 32 raw bytes
        ;   $$hmacSha384Bytes^STDCRYPTO(key,msg)  — 48 raw bytes
        ;   $$hmacSha512Bytes^STDCRYPTO(key,msg)  — 64 raw bytes
        ;   $$available^STDCRYPTO()               — 1 iff stdcrypto callout
        ;                                            is loaded
        ;   $$verifySig^STDCRYPTO(alg,pubKey,msg,sig) — 1 valid | 0 invalid
        ;   $$verifyRs256/384/512^STDCRYPTO(pubKey,msg,sig) — RS* thin wrappers
        ;   $$verifyPs256/384/512^STDCRYPTO(pubKey,msg,sig) — PS* thin wrappers
        ;   $$verifyEs256/384/512^STDCRYPTO(pubKey,msg,sig) — ES* thin wrappers
        ;   $$verifyEdDSA^STDCRYPTO(pubKey,msg,sig)   — EdDSA (Ed25519) wrapper (YDB-only)
        ;   $$verifyAvailable^STDCRYPTO()             — 1 iff verify KAT passes
        ;   $$signSig^STDCRYPTO(alg,privKey,msg)      — raw signature bytes (ES* = JWT R||S)
        ;   $$signRs256^STDCRYPTO(privKey,msg)        — RS256 sign thin wrapper
        ;   $$signEs256^STDCRYPTO(privKey,msg)        — ES256 sign thin wrapper (JWT R||S, 64 bytes)
        ;
        ; Backend (engine-branched in dispatch3 / dispatch4 / dispatchV on
        ; $zversion["IRIS"):
        ;   YottaDB: $&stdcrypto.<fn> → libcrypto (OpenSSL EVP_Digest + HMAC +
        ;            EVP_DigestVerify). C source src/callouts/std_crypto.c;
        ;            descriptor tools/std_crypto.xc; built by tools/build-callouts.sh.
        ;   IRIS:    $SYSTEM.Encryption.SHAHash / .HMACSHA / .RSASHAVerify
        ;            (built-in classes; no callout, no .so). Same raw-byte digest
        ;            output and verify verdict, so the public API and the *TST.m
        ;            vectors are identical on both engines. Asymmetric verify
        ;            (RS256/384/512) is T32 — see docs/design/stdcrypto-asymmetric-
        ;            verify-design.md for the G-IRIS / G-ERR Phase-0 findings.
        ;
        ; YottaDB ABI note — argc-prefixed C signatures: YDB's
        ; $&pkg.fn(args) external-call ABI prepends an `int argc` to
        ; every C entry point. The .xc descriptor still describes the
        ; user-visible signature (sha256(I:,O:) etc.), but the actual
        ; C function is `int crypto_sha256(int argc, ydb_string_t* in,
        ; ydb_string_t* out)`. A wrong argc returns -5. The legacy
        ; $ZF + ydb_ci form was abandoned because YDB r2.02's parser
        ; rejects the `.var` byref-output syntax for $ZF.
        ;
        ; Deployment runbook (full detail in docs/modules/stdcrypto.md):
        ;   1. tools/build-callouts.sh             ; so/<plat>/std_crypto.so
        ;   2. export STDLIB_LIB=<dir-of-so>       ; resolved by the .xc
        ;   3. export ydb_xc_stdcrypto=<abs>/tools/std_crypto.xc
        ;   4. ensure libcrypto.so.3 (or .so.1.1) is on the loader path
        ;
        ; Implementation note — XECUTE wrapper:
        ; M-side calls go through dispatch3 / dispatch4, which build the
        ; "set rc=$&stdcrypto.<fn>(...)" command as a STRING and XECUTE
        ; it. This serves two purposes:
        ;   (a) sidesteps the tree-sitter-m grammar gap for the
        ;       `$&pkg.fn` external-call syntax (literal strings are
        ;       not introspected by the parser);
        ;   (b) sidesteps a pre-existing m fmt longest-prefix bug
        ;       where bare $ZF was rewritten to $zfind / $ZFIND.
        ; The XECUTE template is closed over a `sym` argument that the
        ; public extrinsics control directly — no caller-supplied data
        ; ever appears in the command source.
        ;
        ; All error paths set $ECODE rather than raising directly so callers
        ; can wrap with a single $ETRAP — matches STDCSPRNG / STDCSV style.
        ;
        ; Asymmetric SIGNING (private keys) — the mirror of $$verifySig, for the
        ; VSL-JWT first-party issuer. $$signSig(alg,privKey,msg) → raw signature
        ; (ES* = JWT R||S); RS256/ES256 ship thin wrappers. Backed by
        ; EVP_DigestSign (YDB) / $SYSTEM.Encryption.{RSASHASign,ECSHASign} (IRIS).
        ; The privKey is the issuer's crown jewel — a leak forges any token, so a
        ; caller MUST hold it in key-store custody and never log/commit it.
        ;
        ; Out of scope at v1 (queued under T-N follow-ups):
        ;   - AES-128/256-GCM encrypt/decrypt
        ;   - Asymmetric sign wrappers beyond RS256/ES256 (PS*/ES384/512/EdDSA sign
        ;     are reachable through the generic $$signSig; wrap them when a consumer asks)
        ;   - Ed448 sign/verify
        ;   - X25519 key agreement
        ;   - Streaming digest API (init/update/final tied to a handle)
        ;   - SHA-1, MD5 (deprecated; ship only if a real consumer asks)
        ;   - SHA-3 / SHAKE
        ;
        quit
        ;
        ; ---------- public API: SHA digests ----------
        ;
sha256(data)    ; 64-char lowercase hex SHA-256 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       string       64-char lowercase hex digest
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto package not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $$sha256^STDCRYPTO("abc")  ; "ba7816bf..."
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha384^STDCRYPTO, $$sha512^STDCRYPTO, $$sha256Bytes^STDCRYPTO
        quit $$encode^STDHEX($$sha256Bytes(data))
        ;
sha384(data)    ; 96-char lowercase hex SHA-384 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       string       96-char lowercase hex digest
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $$sha384^STDCRYPTO("abc")  ; "cb00753f..."
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha256^STDCRYPTO, $$sha512^STDCRYPTO
        quit $$encode^STDHEX($$sha384Bytes(data))
        ;
sha512(data)    ; 128-char lowercase hex SHA-512 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       string       128-char lowercase hex digest
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $$sha512^STDCRYPTO("abc")  ; "ddaf35a1..."
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha256^STDCRYPTO, $$sha384^STDCRYPTO
        quit $$encode^STDHEX($$sha512Bytes(data))
        ;
sha256Bytes(data)       ; 32 raw bytes — SHA-256 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       byte-string  32 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$sha256Bytes^STDCRYPTO("abc"))  ; 32
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha256^STDCRYPTO, $$sha384Bytes^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha256"))
        if '$$dispatch3("sha256",data,.out,1) quit ""
        quit out
        ;
sha384Bytes(data)       ; 48 raw bytes — SHA-384 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       byte-string  48 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$sha384Bytes^STDCRYPTO("abc"))  ; 48
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha384^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha384"))
        if '$$dispatch3("sha384",data,.out,1) quit ""
        quit out
        ;
sha512Bytes(data)       ; 64 raw bytes — SHA-512 digest of data.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @returns       byte-string  64 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-DIGEST-FAIL      libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-DIGEST-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$sha512Bytes^STDCRYPTO("abc"))  ; 64
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-DIGEST-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha512^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha512"))
        if '$$dispatch3("sha512",data,.out,1) quit ""
        quit out
        ;
        ; ---------- public API: HMAC ----------
        ;
hmacSha256(key,msg)     ; 64-char lowercase hex HMAC-SHA-256 of msg under key.
        ; doc: @param key     byte-string  HMAC key (any length per RFC 2104)
        ; doc: @param msg     byte-string  message to authenticate
        ; doc: @returns       string       64-char lowercase hex MAC
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $$hmacSha256^STDCRYPTO("Jefe","what do ya want for nothing?")  ; "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843"
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha384^STDCRYPTO, $$hmacSha512^STDCRYPTO
        quit $$encode^STDHEX($$hmacSha256Bytes(key,msg))
        ;
hmacSha384(key,msg)     ; 96-char lowercase hex HMAC-SHA-384.
        ; doc: @param key     byte-string  HMAC key
        ; doc: @param msg     byte-string  message to authenticate
        ; doc: @returns       string       96-char lowercase hex MAC
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$hmacSha384^STDCRYPTO("k","m"))  ; 96
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha256^STDCRYPTO, $$hmacSha512^STDCRYPTO
        quit $$encode^STDHEX($$hmacSha384Bytes(key,msg))
        ;
hmacSha512(key,msg)     ; 128-char lowercase hex HMAC-SHA-512.
        ; doc: @param key     byte-string  HMAC key
        ; doc: @param msg     byte-string  message to authenticate
        ; doc: @returns       string       128-char lowercase hex MAC
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$hmacSha512^STDCRYPTO("k","m"))  ; 128
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha256^STDCRYPTO, $$hmacSha384^STDCRYPTO
        quit $$encode^STDHEX($$hmacSha512Bytes(key,msg))
        ;
hmacSha256Bytes(key,msg)        ; 32 raw bytes — HMAC-SHA-256.
        ; doc: @param key     byte-string  HMAC key
        ; doc: @param msg     byte-string  message to authenticate
        ; doc: @returns       byte-string  32 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$hmacSha256Bytes^STDCRYPTO("k","m"))  ; 32
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha256^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha256"))
        if '$$dispatch4("hmacSha256",key,msg,.out) quit ""
        quit out
        ;
hmacSha384Bytes(key,msg)        ; 48 raw bytes — HMAC-SHA-384.
        ; doc: @param key     byte-string  HMAC key
        ; doc: @param msg     byte-string  message
        ; doc: @returns       byte-string  48 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$hmacSha384Bytes^STDCRYPTO("k","m"))  ; 48
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha384^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha384"))
        if '$$dispatch4("hmacSha384",key,msg,.out) quit ""
        quit out
        ;
hmacSha512Bytes(key,msg)        ; 64 raw bytes — HMAC-SHA-512.
        ; doc: @param key     byte-string  HMAC key
        ; doc: @param msg     byte-string  message
        ; doc: @returns       byte-string  64 raw bytes
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCRYPTO-HMAC-FAIL        libcrypto reported failure
        ; doc: @raisesnodemo U-STDCRYPTO-HMAC-FAIL  libcrypto does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       write $length($$hmacSha512Bytes^STDCRYPTO("k","m"))  ; 64
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out library is absent — not reproducible with the call-out loaded; U-STDCRYPTO-HMAC-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$hmacSha512^STDCRYPTO
        new out
        set out=$$zeros($$shaLen("sha512"))
        if '$$dispatch4("hmacSha512",key,msg,.out) quit ""
        quit out
        ;
        ; ---------- public API: probe ----------
        ;
available()     ; 1 iff the callout is loaded AND returns a correct known-answer digest.
        ; doc: @returns       bool    1 iff std_crypto callout is loaded and produces a digest
        ; doc: @example       write $$available^STDCRYPTO()  ; 1
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$sha256^STDCRYPTO
        ; doc: Pre-flight probe — never raises.
        ; KAT, not a length check: an absent callout no longer returns a zero buffer of
        ; the right length (dispatch3 now RAISES CALLOUT-MISSING), and a length-only probe
        ; would still pass a wrong/zero digest. Compute a fixed digest and compare its VALUE;
        ; trap the raise so the probe stays quiet on an absent callout.
        new ok,$etrap
        set ok=0,$etrap="set $ecode="""" quit"
        if $$sha256("")="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" set ok=1
        quit ok
        ;
        ; ---------- public API: asymmetric signature verify (T32) ----------
        ;
        ; SECURITY CONTRACT (proposal §7 / §11, finding N-1) — READ THIS:
        ; verifySig answers ONE question over bytes: "is this signature valid
        ; for this message under this public key and alg?" It is alg-agnostic BY
        ; DESIGN and therefore CANNOT and DOES NOT defend against JWT algorithm
        ; confusion (alg:"none", RS->HS key confusion, header-chosen alg/kid/jwk).
        ; The CALLER MUST, before calling: (1) reject alg:"none"; (2) enforce an
        ; alg allowlist — the token never widens it; (3) pin alg-family to
        ; key-type per kid; (4) never trust a key lifted from the token's own
        ; jwk/x5c header. That defense lives in STDJWT/VSLJWT, not here. Within
        ; this module an RSA key simply fails to verify under a non-RSA alg (EVP
        ; returns 0), so asymmetric<->asymmetric confusion is self-defending.
        ; Constant-time compare is NOT needed: public-key verify holds no secret.
        ;
verifySig(alg,pubKey,msg,sig)   ; 1 iff sig is a valid alg signature of msg under pubKey.
        ; doc: @param alg     string       JWS alg name — RS256/384/512, PS256/384/512, ES256/384/512, EdDSA
        ; doc: @param pubKey  byte-string  public key as SubjectPublicKeyInfo, DER or PEM
        ; doc: @param msg     byte-string  the exact signed bytes (JWS signing input)
        ; doc: @param sig     byte-string  raw signature bytes (ES* is the JWT R||S concatenation, RFC 7518 §3.4)
        ; doc: @returns       bool         1 = valid · 0 = invalid (a forged sig yields 0, never a trap)
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey is empty or not parseable SPKI
        ; doc: @raises        U-STDCRYPTO-BADALG           alg is unsupported/unknown (incl. EdDSA on IRIS — YDB-only)
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto call-out not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @raises        U-STDCRYPTO-VERIFY-FAIL      internal EVP error (not a bad signature)
        ; doc: @raisesnodemo U-STDCRYPTO-VERIFY-FAIL  libcrypto does not fail on well-formed input
        ; doc: @example       write $$verifySig^STDCRYPTO("RS256",key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out is absent; U-STDCRYPTO-VERIFY-FAIL only fires on an internal libcrypto error — not reproducible from M
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifyRs256^STDCRYPTO, $$verifyAvailable^STDCRYPTO
        ; doc: verifySig trusts the caller to have pinned alg against policy and
        ; doc: to supply a TRUSTED key — see the SECURITY CONTRACT above the label.
        quit $$dispatchV(alg,pubKey,msg,sig)
        ;
verifyRs256(pubKey,msg,sig)     ; RS256 (RSASSA-PKCS1-v1_5 + SHA-256) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyRs256^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("RS256",pubKey,msg,sig)
        ;
verifyRs384(pubKey,msg,sig)     ; RS384 verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyRs384^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("RS384",pubKey,msg,sig)
        ;
verifyRs512(pubKey,msg,sig)     ; RS512 verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyRs512^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("RS512",pubKey,msg,sig)
        ;
verifyEs256(pubKey,msg,sig)     ; ES256 (ECDSA P-256 + SHA-256) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  JWT R||S signature (64 bytes)
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyEs256^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("ES256",pubKey,msg,sig)
        ;
verifyEs384(pubKey,msg,sig)     ; ES384 (ECDSA P-384 + SHA-384) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  JWT R||S signature (96 bytes)
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyEs384^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("ES384",pubKey,msg,sig)
        ;
verifyEs512(pubKey,msg,sig)     ; ES512 (ECDSA P-521 + SHA-512) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  JWT R||S signature (132 bytes; P-521 halves are 66 bytes)
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyEs512^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("ES512",pubKey,msg,sig)
        ;
verifyPs256(pubKey,msg,sig)     ; PS256 (RSASSA-PSS + SHA-256) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyPs256^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("PS256",pubKey,msg,sig)
        ;
verifyPs384(pubKey,msg,sig)     ; PS384 (RSASSA-PSS + SHA-384) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyPs384^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("PS384",pubKey,msg,sig)
        ;
verifyPs512(pubKey,msg,sig)     ; PS512 (RSASSA-PSS + SHA-512) verify — thin wrapper.
        ; doc: @param pubKey  byte-string  SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes
        ; doc: @param sig     byte-string  raw signature bytes
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyPs512^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("PS512",pubKey,msg,sig)
        ;
verifyEdDSA(pubKey,msg,sig)     ; EdDSA (Ed25519) verify — thin wrapper. YDB-only.
        ; doc: @param pubKey  byte-string  Ed25519 SPKI public key (DER or PEM)
        ; doc: @param msg     byte-string  signed bytes (Ed25519 is one-shot; no pre-hash)
        ; doc: @param sig     byte-string  raw 64-byte signature
        ; doc: @returns       bool         1 valid · 0 invalid
        ; doc: @raises        U-STDCRYPTO-BADKEY           pubKey not parseable
        ; doc: @raisesnodemo U-STDCRYPTO-BADKEY  garbage keys are attacker-reachable; demoed in the suite
        ; doc: @raises        U-STDCRYPTO-BADALG           IRIS has no CFRG/Ed25519 method — EdDSA is YDB-only
        ; doc: @raisesnodemo U-STDCRYPTO-BADALG  the EdDSA-YDB-only guard fires only on IRIS
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $$verifyEdDSA^STDCRYPTO(key,msg,sig)  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: EdDSA is YDB-only: IRIS's $SYSTEM.Encryption exposes no CFRG method,
        ; doc: so on IRIS verifySig raises BADALG (a visible, fail-closed guard, not
        ; doc: a silent 0). See docs/design/stdcrypto-asymmetric-verify-design.md.
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO
        quit $$verifySig("EdDSA",pubKey,msg,sig)
        ;
verifyAvailable()       ; 1 iff the verify call-out resolves AND verifies a known-good KAT.
        ; doc: @returns       bool    1 iff verifySig verifies its self-test RS256 KAT
        ; doc: @example       write $$verifyAvailable^STDCRYPTO()  ; 1
        ; doc: @since         v0.15.0
        ; doc: @stable        stable
        ; doc: @see           $$available^STDCRYPTO, $$verifySig^STDCRYPTO
        ; doc: Symbol-specific probe (N-8): unlike $$available (which probes only
        ; doc: sha256), this calls verifySig with an embedded RS256 KAT and
        ; doc: expects 1 — so a stale .so present-but-lacking-crypto_verify is
        ; doc: caught rather than reported healthy. Never raises.
        new ok,$etrap
        set ok=0
        set $etrap="set $ecode="""" quit"
        set ok=$$verifySig("RS256",$$decode^STDHEX($$katKey()),$$decode^STDHEX($$katMsg()),$$decode^STDHEX($$katSig()))
        set $ecode=""
        quit +(ok=1)
        ;
        ; ---------- public API: asymmetric signature sign (VSL-JWT issuer) ----------
        ;
        ; SECURITY CONTRACT — READ THIS: signSig is the PRIVATE-key mirror of
        ; verifySig. It answers "produce the alg signature of these bytes under this
        ; private key". The privKey is the trust root's private half — a leaked
        ; signing key forges ANY token (the mirror of a planted JWKS key). The CALLER
        ; MUST: (1) hold privKey in key-store custody with no ambient read; (2) never
        ; log, commit, or echo it; (3) authenticate the subject BEFORE minting a token
        ; over these bytes — signing is the takeover surface. This module never
        ; persists or caches the key; it lives only for the call.
        ;
signSig(alg,privKey,msg)        ; Sign msg with privKey under alg; raw signature bytes (ES* = JWT R||S).
        ; doc: @param alg     string       JWS alg name — RS256/384/512, PS256/384/512, ES256/384/512, EdDSA
        ; doc: @param privKey byte-string  private key (PKCS#8 or traditional; DER or PEM) — the issuer crown jewel
        ; doc: @param msg     byte-string  the exact bytes to sign (the JWS signing input)
        ; doc: @returns       byte-string  raw signature (ES* is the JWT R||S concatenation, RFC 7518 §3.4)
        ; doc: @raises        U-STDCRYPTO-BADKEY           privKey is empty or not parseable
        ; doc: @raises        U-STDCRYPTO-BADALG           alg is unsupported/unknown
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto call-out not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @raises        U-STDCRYPTO-SIGN-FAIL        internal EVP/IRIS signing error
        ; doc: @raisesnodemo U-STDCRYPTO-SIGN-FAIL  libcrypto does not fail on well-formed input
        ; doc: @raises        U-STDCRYPTO-SIGN-BUF         signature exceeds the 512-byte call-out buffer (RSA-8192-class keys)
        ; doc: @raisesnodemo U-STDCRYPTO-SIGN-BUF  needs an RSA key >4096 bits; not provisioned on the test engines
        ; doc: @example       write $length($$signEs256^STDCRYPTO(privKey,msg))  ; 64
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the std_crypto call-out is absent; U-STDCRYPTO-SIGN-FAIL only fires on an internal signing error — not reproducible from M
        ; doc: @since         v0.16.0
        ; doc: @stable        stable
        ; doc: @see           $$verifySig^STDCRYPTO, $$signEs256^STDCRYPTO
        ; doc: signSig trusts the caller to hold a TRUSTED private key in custody and
        ; doc: to have authenticated the subject — see the SECURITY CONTRACT above.
        new out
        if '$$dispatchS(alg,privKey,msg,.out) quit ""
        quit out
        ;
signRs256(privKey,msg)  ; RS256 (RSASSA-PKCS1-v1_5 + SHA-256) sign — thin wrapper.
        ; doc: @param privKey byte-string  RSA private key (PKCS#8 or traditional; DER or PEM)
        ; doc: @param msg     byte-string  the bytes to sign
        ; doc: @returns       byte-string  raw RSA signature bytes
        ; doc: @raises        U-STDCRYPTO-BADKEY           privKey not parseable
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $length($$signRs256^STDCRYPTO(privKey,msg))'=0  ; 1
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.16.0
        ; doc: @stable        stable
        ; doc: @see           $$signSig^STDCRYPTO
        quit $$signSig("RS256",privKey,msg)
        ;
signEs256(privKey,msg)  ; ES256 (ECDSA P-256 + SHA-256) sign — JWT R||S (64 bytes).
        ; doc: @param privKey byte-string  EC P-256 private key (PKCS#8 or traditional; DER or PEM)
        ; doc: @param msg     byte-string  the bytes to sign
        ; doc: @returns       byte-string  JWT R||S signature (64 bytes)
        ; doc: @raises        U-STDCRYPTO-BADKEY           privKey not parseable
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded (YDB)
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  fires only when the call-out is absent
        ; doc: @example       write $length($$signEs256^STDCRYPTO(privKey,msg))  ; 64
        ; doc: @illustrative  U-STDCRYPTO-CALLOUT-MISSING only fires when the call-out is absent
        ; doc: @since         v0.16.0
        ; doc: @stable        stable
        ; doc: @see           $$signSig^STDCRYPTO
        quit $$signSig("ES256",privKey,msg)
        ;
        ; ---------- internal helpers ----------
        ;
shaLen(name)    ; Digest size in bytes for the named algorithm.
        ; doc: @internal
        ; doc: Keeps the magic-number table out of the call sites.
        if name="sha256" quit 32
        if name="sha384" quit 48
        if name="sha512" quit 64
        set $ecode=",U-STDCRYPTO-BAD-ALGO,"
        quit 0
        ;
dispatch3(sym,inp,out,isDigest) ; Invoke $&stdcrypto.<sym>(inp,.out).
        ; doc: @internal
        ; doc: Wraps $& in an XECUTE'd command string. Returns 1 on
        ; doc: success, 0 on failure with $ECODE set. On IRIS, branches to
        ; doc: irisDigest ($SYSTEM.Encryption.SHAHash) instead of the YDB callout.
        if $zversion["IRIS" quit $$irisDigest(sym,inp,.out)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-1 quit -1"
        ; -99 is a SENTINEL the C callout never returns (it returns 0 ok / -1..-5 fail):
        ; if rc is still -99 after the xecute the callout NEVER RAN (an absent callout
        ; that silently no-ops rather than raising — the vehu footgun). Pre-setting rc=0
        ; (== the success code) made that no-op indistinguishable from success, so the
        ; zero-filled `out` buffer was returned as a valid digest. Mirror dispatchV.
        set rc=-99
        set cmd="set rc=$&stdcrypto."_sym_"(inp,.out)"
        xecute cmd
        set $etrap=""   ; disarm so a CALLOUT-MISSING set below propagates to the caller
        if rc=0 quit 1
        if (rc=-99)!(rc=-1) set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
        if isDigest set $ecode=",U-STDCRYPTO-DIGEST-FAIL," quit 0
        set $ecode=",U-STDCRYPTO-HMAC-FAIL,"
        quit 0
        ;
dispatch4(sym,key,msg,out)      ; Invoke $&stdcrypto.<sym>(key,msg,.out).
        ; doc: @internal
        ; doc: Same XECUTE-wrap rationale as dispatch3. On IRIS, branches to
        ; doc: irisHmac ($SYSTEM.Encryption.HMACSHA) instead of the YDB callout.
        if $zversion["IRIS" quit $$irisHmac(sym,key,msg,.out)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-1 quit -1"
        ; -99 sentinel: a still-(-99) rc after the xecute means the callout NEVER RAN
        ; (absent callout that silently no-ops). Pre-setting rc=0 (the success code)
        ; returned a zero HMAC as valid — a security footgun (HS256 would "verify"
        ; against a zero MAC). See dispatch3.
        set rc=-99
        set cmd="set rc=$&stdcrypto."_sym_"(key,msg,.out)"
        xecute cmd
        set $etrap=""   ; disarm so a CALLOUT-MISSING set below propagates to the caller
        if rc=0 quit 1
        if (rc=-99)!(rc=-1) set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
        set $ecode=",U-STDCRYPTO-HMAC-FAIL,"
        quit 0
        ;
dispatchV(alg,key,msg,sig)      ; Invoke $&stdcrypto.verify(alg,key,msg,sig) — verdict as int.
        ; doc: @internal
        ; doc: The verify dispatcher — deliberately NOT dispatch3/4 (finding N-3):
        ; doc: those treat rc=0 as SUCCESS, but for verify rc=0 means INVALID
        ; doc: SIGNATURE, a valid non-exceptional answer. rc is read directly as
        ; doc: the verdict. Disjoint C codes -10 BADKEY / -11 BADALG / -12
        ; doc: VERIFY-FAIL map to distinct $ECODEs; the $ETRAP sentinel is -99
        ; doc: (callout MISSING), distinct from every C code so callout-missing
        ; doc: is never confused with a C error. On IRIS, branches to irisVerify.
        if $zversion["IRIS" quit $$irisVerify(alg,key,msg,sig)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-99 quit -99"
        set rc=-99
        set cmd="set rc=$&stdcrypto.verify(alg,key,msg,sig)"
        xecute cmd
        set $etrap=""   ; disarm the callout-missing trap so an error code below propagates
        if rc=1 quit 1
        if rc=0 quit 0
        if rc=-99 set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
        if rc=-10 set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        if rc=-11 set $ecode=",U-STDCRYPTO-BADALG," quit 0
        set $ecode=",U-STDCRYPTO-VERIFY-FAIL,"
        quit 0
        ;
dispatchS(alg,key,msg,out)      ; Invoke $&stdcrypto.sign(alg,key,msg,.out) — 1 ok (out=sig) / raise.
        ; doc: @internal
        ; doc: The sign dispatcher — mirror of dispatchV. Sign has no "invalid"
        ; doc: verdict: it either produces a signature (rc=0, out set) or fails, so
        ; doc: every non-zero rc maps to a distinct $ECODE and the caller sees a
        ; doc: raise. The -99 $ETRAP sentinel is callout-MISSING, distinct from every
        ; doc: C code. `out` is pre-allocated to the .xc's 512-byte O-buffer so the
        ; doc: C side learns the capacity; it writes the true length back. On IRIS,
        ; doc: branches to irisSign.
        if $zversion["IRIS" quit $$irisSign(alg,key,msg,.out)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-99 quit -99"
        set rc=-99
        set out=$$zeros(512)
        set cmd="set rc=$&stdcrypto.sign(alg,key,msg,.out)"
        xecute cmd
        set $etrap=""   ; disarm so an error code below propagates to the caller
        if rc=0 quit 1
        if rc=-99 set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
        if rc=-10 set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        if rc=-11 set $ecode=",U-STDCRYPTO-BADALG," quit 0
        if rc=-3 set $ecode=",U-STDCRYPTO-SIGN-BUF," quit 0
        set $ecode=",U-STDCRYPTO-SIGN-FAIL,"
        quit 0
        ;
        ; ---------- IRIS-native backend ($SYSTEM.Encryption) ----------
        ; IRIS has no $&pkg.fn callout ABI; it ships SHA / HMAC as built-in
        ; ObjectScript class methods. The calls are XECUTE-wrapped for the
        ; same reason as the YDB arm — $SYSTEM.<class>.<method> is not M the
        ; tree-sitter-m grammar parses, so it must live inside a string.
        ; Both produce raw digest bytes, identical to libcrypto's output.
        ;
digestBits(sym) ; SHA bit-width implied by sym name (256 / 384 / 512).
        ; doc: @internal
        quit $select(sym["512":512,sym["384":384,1:256)
        ;
irisDigest(sym,inp,out) ; IRIS SHA digest into out via $SYSTEM.Encryption.SHAHash.
        ; doc: @internal
        ; doc: Returns 1 on success, 0 (with $ECODE) on failure.
        new $etrap,cmd,bits
        set $etrap="set $ecode="""" quit 0"
        set bits=$$digestBits(sym)
        set cmd="set out=$system.Encryption.SHAHash("_bits_",inp)"
        xecute cmd
        if $length($get(out))'=(bits\8) set $ecode=",U-STDCRYPTO-DIGEST-FAIL," quit 0
        quit 1
        ;
irisHmac(sym,key,msg,out)       ; IRIS HMAC into out via $SYSTEM.Encryption.HMACSHA.
        ; doc: @internal
        ; doc: Returns 1 on success, 0 (with $ECODE) on failure. Arg order is
        ; doc: HMACSHA(bits,data,key) — verified against RFC 4231 vectors.
        new $etrap,cmd,bits
        set $etrap="set $ecode="""" quit 0"
        set bits=$$digestBits(sym)
        set cmd="set out=$system.Encryption.HMACSHA("_bits_",msg,key)"
        xecute cmd
        if $length($get(out))'=(bits\8) set $ecode=",U-STDCRYPTO-HMAC-FAIL," quit 0
        quit 1
        ;
irisVerify(alg,key,msg,sig)     ; IRIS asymmetric verify via $SYSTEM.Encryption.
        ; doc: @internal
        ; doc: One arm for all families, each a native $SYSTEM.Encryption method
        ; doc: (arg shape (shaBits,data,sig,pubKeyPEM), PEM-only key — confirmed on
        ; doc: foia-t12, design note G-IRIS):
        ; doc:   RS* → RSASHAVerify   PS* → RSASSAPSSVerify   ES* → ECSHAVerify
        ; doc: ES* is the JWT R||S concatenation; IRIS (like OpenSSL) wants a DER
        ; doc: SEQUENCE{r,s}, so it is converted M-side ($$rsToDer) first — a
        ; doc: malformed R||S is an INVALID signature (0), never an error.
        ; doc: EdDSA is YDB-only: IRIS exposes no CFRG/Ed25519 method, so it raises
        ; doc: BADALG here — a visible, fail-closed guard, never a silent 0.
        ; doc: A DER key is wrapped to PEM ($$toPem) — IRIS silently returns 0 for a
        ; doc: bare DER key. A bad KEY is separated from a bad SIGNATURE via
        ; doc: RSAGetLastError (decoder error => BADKEY); either way it never verifies.
        new $etrap,cmd,fam,bits,pem,r,err,vsig,meth
        set fam=$$algFam(alg)
        if fam="ED" set $ecode=",U-STDCRYPTO-BADALG," quit 0
        set bits=$$shaBits(alg)
        if (fam="")!(bits="") set $ecode=",U-STDCRYPTO-BADALG," quit 0
        if $length($get(key))=0 set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        set vsig=sig
        if fam="ES" set vsig=$$rsToDer(sig)
        if fam="ES",vsig="" quit 0
        set pem=$$toPem(key)
        set meth=$select(fam="PS":"RSASSAPSSVerify",fam="ES":"ECSHAVerify",1:"RSASHAVerify")
        set $etrap="set $ecode="""" set r=-1 quit -1"
        set r=-1
        set cmd="set r=$system.Encryption."_meth_"("_bits_",msg,vsig,pem)"
        xecute cmd
        set $etrap=""   ; disarm the trap so a BADKEY code below propagates
        if r=1 quit 1
        if r<0 set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        ; r=0 (invalid). Disambiguate a bad KEY (=> BADKEY, engine-neutral with the
        ; YDB C -10) from a bad SIGNATURE (=> 0) via RSAGetLastError — an RSA-only
        ; channel, so only RS* consults it; a failed ES*/PS* verify reports invalid.
        if fam="RS",$$isKeyErr($$rsaErr()) set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        quit 0
        ;
irisSign(alg,key,msg,out)       ; IRIS asymmetric sign via $SYSTEM.Encryption.{RSASHASign,RSASSAPSSSign,ECSHASign}.
        ; doc: @internal
        ; doc: The IRIS arm of dispatchS (mirror of irisVerify). Method by family:
        ; doc:   RS* → RSASHASign   PS* → RSASSAPSSSign   ES* → ECSHASign
        ; doc: all shaped (shaBits, data, privKeyPEM) and returning the raw signature.
        ; doc: ECSHASign returns a DER SEQUENCE{r,s}; JWT wants fixed-width R||S, so it
        ; doc: is converted M-side ($$derToRs), the inverse of the irisVerify $$rsToDer.
        ; doc: The private key is wrapped DER→PEM ($$toPemPriv) — IRIS wants PEM. EdDSA
        ; doc: is YDB-only (no CFRG method), so it raises BADALG here, fail-closed.
        ; doc: 1 on success (out=signature); every failure sets $ECODE (a raise).
        new $etrap,cmd,fam,bits,pem,r,meth
        set fam=$$algFam(alg)
        if fam="ED" set $ecode=",U-STDCRYPTO-BADALG," quit 0
        set bits=$$shaBits(alg)
        if (fam="")!(bits="") set $ecode=",U-STDCRYPTO-BADALG," quit 0
        if $length($get(key))=0 set $ecode=",U-STDCRYPTO-BADKEY," quit 0
        set pem=$$toPemPriv(key)
        set meth=$select(fam="PS":"RSASSAPSSSign",fam="ES":"ECSHASign",1:"RSASHASign")
        set $etrap="set $ecode="""" set r="""" quit"""""
        set r=""
        set cmd="set r=$system.Encryption."_meth_"("_bits_",msg,pem)"
        xecute cmd
        set $etrap=""   ; disarm so a SIGN/KEY code below propagates
        if r="" set $ecode=",U-STDCRYPTO-SIGN-FAIL," quit 0
        if fam="ES" set r=$$derToRs(r,$$esHalf(alg))
        if fam="ES",r="" set $ecode=",U-STDCRYPTO-SIGN-FAIL," quit 0
        set out=r
        quit 1
        ;
algFam(alg)     ; JWS alg family: RS / PS / ES / ED; "" if unknown.
        ; doc: @internal
        if alg="EdDSA" quit "ED"
        if $length(alg)'=5 quit ""
        new f set f=$extract(alg,1,2)
        if (f="RS")!(f="PS")!(f="ES") quit f
        quit ""
        ;
shaBits(alg)    ; SHA bit-width from an RS*/PS*/ES* alg suffix; "" otherwise.
        ; doc: @internal
        if $length(alg)'=5 quit ""
        new s set s=$extract(alg,3,5)
        if s="256" quit 256
        if s="384" quit 384
        if s="512" quit 512
        quit ""
        ;
rsToDer(sig)    ; JWT ES* R||S -> DER SEQUENCE{r,s}; "" if malformed (odd/empty).
        ; doc: @internal
        ; doc: The IRIS analog of the YDB C rs_to_der: component width = siglen/2
        ; doc: (P-256=32, P-384=48, P-521=66), r/s minimally DER-encoded with a
        ; doc: leading 0x00 when the high bit is set. Only used by the IRIS ES* arm
        ; doc: (the YDB path converts in C). An odd/empty siglen -> "" (invalid).
        new n,half,body
        set n=$length(sig)
        if (n<2)!(n#2) quit ""
        set half=n\2
        set body=$$derInt($extract(sig,1,half))_$$derInt($extract(sig,half+1,n))
        quit $char(48)_$$derLen($length(body))_body
        ;
derToRs(der,half)       ; ECDSA DER SEQUENCE{r,s} -> JWT fixed-width R||S (half bytes each); "" if malformed.
        ; doc: @internal
        ; doc: The inverse of rsToDer, for the IRIS ES* sign arm: ECSHASign returns a
        ; doc: DER SEQUENCE{INTEGER r, INTEGER s}; JWT (RFC 7518 §3.4) wants each of r,s
        ; doc: as a fixed-width `half`-byte big-endian value (P-256=32, P-384=48,
        ; doc: P-521=66). r/s INTEGER lengths are always short-form (<128) for every
        ; doc: P-curve; the outer SEQUENCE length may be long-form (P-521), so it is
        ; doc: skipped generically. Each component is stripped of DER sign-padding and
        ; doc: left-padded to `half` ($$leftpad). "" on any structural failure or if a
        ; doc: component exceeds `half` bytes.
        new p,l,r,s
        if half<1 quit ""
        if $ascii(der,1)'=48 quit ""                    ; SEQUENCE tag
        set p=2,l=$ascii(der,p),p=p+1
        if l>127 set p=p+(l-128)                         ; long-form outer length: skip length octets
        if $ascii(der,p)'=2 quit ""                      ; INTEGER r
        set p=p+1,l=$ascii(der,p),p=p+1
        set r=$extract(der,p,p+l-1),p=p+l
        if $ascii(der,p)'=2 quit ""                      ; INTEGER s
        set p=p+1,l=$ascii(der,p),p=p+1
        set s=$extract(der,p,p+l-1),p=p+l
        set r=$$leftpad(r,half),s=$$leftpad(s,half)
        if (r="")!(s="") quit ""
        quit r_s
        ;
leftpad(bytes,half)     ; Strip leading zero bytes, then left-pad to exactly `half` bytes; "" if too long.
        ; doc: @internal
        ; doc: Normalizes a DER INTEGER magnitude to a fixed-width big-endian field:
        ; doc: drop leading 0x00 (incl. DER's sign-pad byte), then zero-fill on the left
        ; doc: to `half`. A magnitude wider than `half` is malformed for the curve -> "".
        for  quit:($ascii(bytes,1)'=0)!($length(bytes)'>1)  set bytes=$extract(bytes,2,$length(bytes))
        if $length(bytes)>half quit ""
        for  quit:$length(bytes)'<half  set bytes=$char(0)_bytes
        quit bytes
        ;
esHalf(alg)     ; JWT R||S component width (bytes) for an ES* alg: ES256=32, ES384=48, ES512=66.
        ; doc: @internal
        quit $select(alg="ES256":32,alg="ES384":48,alg="ES512":66,1:0)
        ;
derInt(bytes)   ; DER INTEGER TLV for a big-endian unsigned magnitude.
        ; doc: @internal
        new i,body
        set i=1
        for  quit:(i>$length(bytes))!($ascii(bytes,i)'=0)  set i=i+1
        set body=$extract(bytes,i,$length(bytes))
        if body="" set body=$char(0)
        if $ascii(body,1)>127 set body=$char(0)_body
        quit $char(2)_$$derLen($length(body))_body
        ;
derLen(n)       ; DER length octet(s) for length n (< 65536).
        ; doc: @internal
        if n<128 quit $char(n)
        if n<256 quit $char(129,n)
        quit $char(130,n\256,n#256)
        ;
toPem(key)      ; Return key as an SPKI PEM string (wraps DER for the IRIS arm).
        ; doc: @internal
        ; doc: IRIS RSASHAVerify accepts PEM only; a bare DER key silently
        ; doc: verifies to 0. A key already in PEM ("-----BEGIN") passes through;
        ; doc: a DER key is base64-armored (single-line body is accepted).
        new b64,cmd
        if $extract(key,1,10)="-----BEGIN" quit key
        set b64=""
        set cmd="set b64=$system.Encryption.Base64Encode(key)"
        xecute cmd
        quit "-----BEGIN PUBLIC KEY-----"_$char(10)_b64_$char(10)_"-----END PUBLIC KEY-----"
        ;
toPemPriv(key)  ; Return a private key as PKCS#8 PEM (wraps DER for the IRIS sign arm).
        ; doc: @internal
        ; doc: The private-key analog of toPem: IRIS's *Sign methods want a PEM key; a
        ; doc: DER PKCS#8 key is base64-armored under a "BEGIN PRIVATE KEY" header. A key
        ; doc: already in PEM (any "-----BEGIN") passes through unchanged.
        new b64,cmd
        if $extract(key,1,10)="-----BEGIN" quit key
        set b64=""
        set cmd="set b64=$system.Encryption.Base64Encode(key)"
        xecute cmd
        quit "-----BEGIN PRIVATE KEY-----"_$char(10)_b64_$char(10)_"-----END PRIVATE KEY-----"
        ;
rsaErr()        ; IRIS $SYSTEM.Encryption.RSAGetLastError(), XECUTE-wrapped.
        ; doc: @internal
        new $etrap,e,cmd
        set $etrap="set $ecode="""" quit """""
        set e=""
        set cmd="set e=$system.Encryption.RSAGetLastError()"
        xecute cmd
        quit e
        ;
isKeyErr(err)   ; 1 iff an OpenSSL error string indicates a key-decode failure.
        ; doc: @internal
        ; doc: A bad KEY yields a DECODER/decode/unsupported error; a bad
        ; doc: SIGNATURE yields an "invalid padding" error — distinct classes.
        quit (err["DECODER")!(err["decode")!(err["unsupported")
        ;
        ; ---------- verifyAvailable self-test KAT (RFC 7515 App A.2) ----------
katKey() ; verifyAvailable self-test key — RFC 7515 A.2 SPKI DER (hex)
        ; doc: @internal
        new h set h="30820122300d06092a864886f70d01010105000382010f003082010a0282010100a1f8160ae2e3c9b465ce8d2d656263362b927dbe29e1f02477fc"
        set h=h_"1625cc90a136e38bd93497c5b6ea63dd7711e67c7429f956b0fb8a8f089adc4b69893cc1333f53edd019b87784252fec914fe4857769594bea4280"
        set h=h_"d32c0f55bf62944f130396bc6e9bdf6ebdd2bda3678eeca0c668f701b38dbffb38c8342ce2fe6d27fade4a5a4874979dd4b9cf9adec4c75b05852c"
        set h=h_"2c0f5ef8a5c1750392f944e8ed64c110c6b647609aa4783aeb9c6c9ad755313050638b83665c6f6f7a82a396702a1f641b82d3ebf2392219491fb6"
        set h=h_"86872c5716f50af8358d9a8b9d17c340728f7f87d89a18d8fcab67ad84590c2ecf759339363c07034d6f606f9e21e05456cae5e9a10203010001"
        quit h
        ;
katMsg() ; verifyAvailable self-test message (hex)
        ; doc: @internal
        new h set h="65794a68624763694f694a53557a49314e694a392e65794a7063334d694f694a71623255694c41304b49434a6c654841694f6a457a4d4441344d54"
        set h=h_"6b7a4f44417344516f67496d6830644841364c79396c654746746347786c4c6d4e76625339706331397962323930496a7030636e566c6651"
        quit h
        ;
katSig() ; verifyAvailable self-test RS256 signature (hex)
        ; doc: @internal
        new h set h="702e218943e88fd11eb5d82dbf7845f34106ae1b81fff7731116add1717d83656d420afd3c96eedd73a2663e5166687b000b87226e0187ed1073f9"
        set h=h_"45e582adfcef16d85a798ee8c66ddb3db8975b17d09402beedd5d9d97007108db28160d5f8040ca7445762b81fbe7ff9d92e0ae76f24f25b33bbe6"
        set h=h_"f44ae61eb1040acb20044d3ef9128ed40130795bd4bd3b41eecad066ab651981fde48df77f372dc38b9fafdd3befb18b5da3cc3c2eb02f9e3a41d6"
        set h=h_"12caad15911273a05f23b9e838faaf849d698429ef5a1e88798236c3d40e604522a544c8f27a7a2db80663d16cf7caea56de405cb2215a45b2c255"
        set h=h_"66b55ac1a748a070dfc8a32a469543d019eefb47"
        quit h
        ;
zeros(n)        ; n NUL bytes — pre-allocates the O:ydb_string_t* output.
        ; doc: @internal
        ; doc: Pre-allocation for YDB callout output buffers.
        new buf,i
        set buf=""
        for i=1:1:n  set buf=buf_$char(0)
        quit buf
        ;
