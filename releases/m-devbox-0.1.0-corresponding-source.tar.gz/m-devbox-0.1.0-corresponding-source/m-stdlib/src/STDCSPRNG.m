STDCSPRNG       ; m-stdlib — Cryptographic random (kernel CSPRNG via getrandom(2) | /dev/urandom | IRIS GenCryptRand).
        ; doc: @tag v0.3.0
        ; doc: @phase P4 wave
        ; doc: @exrun bare
        ; m-lint: disable-file=M-MOD-024
        ; m-lint: disable-file=M-MOD-036
        ; M-MOD-024 false positives: the linter parses YDB OPEN/USE
        ; deviceparams (readonly, nowrap, noecho) as local-variable reads,
        ; then cascades read-of-undefined complaints across bytes/available;
        ; rc / out are also initialised before the XECUTE'd $& dispatch
        ; but the analyser cannot follow flow through XECUTE indirection.
        ; Same finding as STDCSV / STDCRYPTO — tracked as a P2 in
        ; TOOLCHAIN-FINDINGS.md.
        ; M-MOD-036 (XECUTE injection) is intentional: the XECUTE wrapper
        ; keeps the $& external-call token out of the parse tree (m fmt/
        ; lint do not handle it). Same trick as STDCRYPTO / STDHTTP /
        ; STDCOMPRESS; the XECUTE source is built from a literal template
        ; only.
        ; G-FS-YDB class (fixed 2026-07-22): the dispatch originally used
        ; $ZF("cs_random",...) — not YDB syntax (%YDB-E-COMMA at XECUTE
        ; compile, silently trapped) — and guarded on ydb_xc_std_csprng, a
        ; name the engine never reads. The .xc label and the dispatch are
        ; now the underscore-free $&stdcsprng.random, guarded on the
        ; stripped package env var ydb_xc_stdcsprng.
        ;
        ; Public extrinsics:
        ;   $$bytes^STDCSPRNG(n)        — n random bytes
        ;   $$hex^STDCSPRNG(n)          — 2n lowercase hex chars (n bytes hex-encoded)
        ;   $$base64^STDCSPRNG(n)       — URL-safe base64 of n bytes (no padding)
        ;   $$token^STDCSPRNG(n)        — n-char URL-safe token from [A-Za-z0-9_-]
        ;   $$int^STDCSPRNG(min,max)    — uniform integer in [min,max] (inclusive)
        ;   $$uuid4^STDCSPRNG()         — crypto-strong RFC-4122 v4 UUID
        ;   $$available^STDCSPRNG()     — 1 iff /dev/urandom is readable
        ;   $$useCallout^STDCSPRNG()    — 1 iff cs_random callout is loaded
        ;
        ; Entropy: Linux kernel ChaCha20 CSPRNG. The backends share the
        ; same pool, so the choice is purely a perf / portability concern:
        ;   • cs_random — $&stdcsprng.random → getrandom(2) (YDB). Batched
        ;     single-call read; no fd churn, no record-terminator dance.
        ;     Picked when ydb_xc_stdcsprng is set (descriptor deployed)
        ;     and the .so resolves on first probe.
        ;   • /dev/urandom — pure-M READ *b loop (YDB); one device read per
        ;     byte. Always available on Linux YDB; the soft-fall-back
        ;     when the callout is absent.
        ;   • GenCryptRand — $SYSTEM.Encryption.GenCryptRand (IRIS). The
        ;     engine's own CSPRNG, used in place of the /dev/urandom device
        ;     read whose YDB binary deviceparams IRIS rejects (B-6). One call
        ;     returns n bytes; no device open.
        ; The public API is identical across all three — callers never need to
        ; pick. Suitable for session tokens, password reset tokens, JWT
        ; signing salts, nonces.
        ;
        ; Distinct from $RANDOM (Mersenne Twister): $RANDOM is fast and
        ; statistically uniform but its output is predictable from a few
        ; samples — never use it for security-sensitive identifiers. Use
        ; STDCSPRNG instead.
        ;
        ; Deployment runbook (full detail in docs/modules/stdcsprng.md):
        ;   1. tools/build-callouts.sh       ; produce so/<plat>/cs_random.so
        ;   2. export STDLIB_LIB=<dir-of-so> ; substituted into std_csprng.xc
        ;   3. export ydb_xc_stdcsprng=<abs>/tools/std_csprng.xc
        ;   (or simply `m callouts install`, which wires all three)
        ; With those unset, bytes() / hex() / base64() / token() / int() /
        ; uuid4() all keep working via /dev/urandom — the callout is a
        ; perf-only swap.
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
bytes(n)        ; Return n random bytes from the kernel CSPRNG.
        ; doc: @param n       int     byte count (>= 0)
        ; doc: @returns       byte-string  n random bytes; "" for n=0
        ; doc: @raises        U-STDCSPRNG-BAD-COUNT  n < 0
        ; doc: @raises        U-STDCSPRNG-OPEN-FAIL  neither backend can produce bytes
        ; doc: @raisesnodemo U-STDCSPRNG-OPEN-FAIL  fires only when no CSPRNG backend is available; not triggerable on a healthy engine
        ; doc: @example       write $length($$bytes^STDCSPRNG(16))  ; 16
        ; doc: @example       write $$bytes^STDCSPRNG(0)  ; ""
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$bytes^STDCSPRNG(-1)","U-STDCSPRNG-BAD-COUNT","negative count raises")
        ; doc: @illustrative  U-STDCSPRNG-OPEN-FAIL needs both backends unavailable (no callout AND /dev/urandom unopenable) — not reproducible in the test engine.
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$hex^STDCSPRNG, $$base64^STDCSPRNG, $$token^STDCSPRNG, $$uuid4^STDCSPRNG
        ; doc: Tries $&stdcsprng.random (getrandom(2)) first; falls back to a
        ; doc: /dev/urandom READ *b loop when the callout descriptor is unset
        ; doc: or the .so does not resolve.
        if n<0 set $ecode=",U-STDCSPRNG-BAD-COUNT," quit ""
        if 'n quit ""
        new buf
        set buf=$$dispatchRandom(n)
        if buf'="" quit buf
        if $zversion["IRIS" quit $$bytesIris(n)
        quit $$bytesFromDevice(n)
        ;
bytesIris(n)    ; IRIS-native CSPRNG backend — $SYSTEM.Encryption.GenCryptRand.
        ; doc: @internal
        ; doc: The IRIS analogue of the YDB getrandom(2) callout: the engine's own
        ; doc: cryptographic PRNG returns n raw bytes in one call, so IRIS never
        ; doc: opens /dev/urandom (its OPEN rejects YDB's binary deviceparams,
        ; doc: which aborted STDCSPRNGTST 0/0 on IRIS — B-6). XECUTE-hides the
        ; doc: $SYSTEM syntax so YDB's compiler never parses it (same trick as the
        ; doc: $& dispatch and STDFS's engine-branched device facade).
        new buf,cmd
        set buf=""
        set cmd="set buf=$SYSTEM.Encryption.GenCryptRand("_+n_")"
        xecute cmd
        quit buf
        ;
bytesFromDevice(n)      ; /dev/urandom backend — soft-fall-back when callout absent (YDB).
        ; doc: @internal
        ; doc: Reads n bytes one at a time via READ *b so record terminators
        ; doc: (LF=$C(10), CR=$C(13)) in the byte stream don't truncate the read.
        new dev,buf,prev,i,b
        set dev="/dev/urandom",buf="",prev=$io
        open dev:(readonly:nowrap):2  else  set $ecode=",U-STDCSPRNG-OPEN-FAIL," quit ""
        use dev:(noecho)
        for i=1:1:n  read *b  set buf=buf_$char(b)
        use prev
        close dev
        quit buf
        ;
hex(n)  ; Return 2n lowercase hex chars representing n random bytes.
        ; doc: @param n       int     byte count (>= 0)
        ; doc: @returns       string  2n lowercase hex chars
        ; doc: @raises        U-STDCSPRNG-BAD-COUNT  n < 0
        ; doc: @example       write $length($$hex^STDCSPRNG(16))  ; 32
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$hex^STDCSPRNG(-1)","U-STDCSPRNG-BAD-COUNT","negative count raises")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$bytes^STDCSPRNG, $$encode^STDHEX
        if n<0 set $ecode=",U-STDCSPRNG-BAD-COUNT," quit ""
        if 'n quit ""
        quit $$encode^STDHEX($$bytes(n))
        ;
base64(n)       ; Return URL-safe base64 of n random bytes (no padding).
        ; doc: @param n       int     byte count (>= 0)
        ; doc: @returns       string  URL-safe base64 (no padding)
        ; doc: @raises        U-STDCSPRNG-BAD-COUNT  n < 0
        ; doc: @example       write $length($$base64^STDCSPRNG(32))  ; 43
        ; doc: @example       write $length($$base64^STDCSPRNG(0))  ; 0
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$base64^STDCSPRNG(-1)","U-STDCSPRNG-BAD-COUNT","negative count raises")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$bytes^STDCSPRNG, $$urlencode^STDB64
        if n<0 set $ecode=",U-STDCSPRNG-BAD-COUNT," quit ""
        if 'n quit ""
        quit $$urlencode^STDB64($$bytes(n))
        ;
token(n)        ; Return an n-char URL-safe token from alphabet [A-Za-z0-9_-].
        ; doc: @param n       int     character count (>= 0)
        ; doc: @returns       string  n-char token from [A-Za-z0-9_-]
        ; doc: @raises        U-STDCSPRNG-BAD-COUNT  n < 0
        ; doc: @example       write $length($$token^STDCSPRNG(22))  ; 22
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$token^STDCSPRNG(-1)","U-STDCSPRNG-BAD-COUNT","negative count raises")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$base64^STDCSPRNG, $$bytes^STDCSPRNG
        ; doc: Each character is one uniform draw from a 64-char alphabet
        ; doc: (6 bits of entropy per char), giving 6n bits of entropy total.
        if n<0 set $ecode=",U-STDCSPRNG-BAD-COUNT," quit ""
        if 'n quit ""
        new alpha,raw,out,i
        set alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        set raw=$$bytes(n),out=""
        for i=1:1:n  set out=out_$extract(alpha,($ascii(raw,i)#64)+1)
        quit out
        ;
int(min,max)    ; Return uniform integer in [min, max] (inclusive both ends).
        ; doc: @param min     int     lower bound (inclusive)
        ; doc: @param max     int     upper bound (inclusive)
        ; doc: @returns       int     uniform random integer in [min, max]
        ; doc: @raises        U-STDCSPRNG-BAD-RANGE  max < min
        ; doc: @example       write $$int^STDCSPRNG(5,5)  ; 5
        ; doc: @example       set d=$$int^STDCSPRNG(1,6) do true^STDASSERT(.pass,.fail,(d'<1)&(d'>6),"die roll is in [1,6]")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$int^STDCSPRNG(6,1)","U-STDCSPRNG-BAD-RANGE","max<min raises")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$bytes^STDCSPRNG
        ; doc: Uses rejection sampling on the smallest power of 256 covering
        ; doc: the range, so the distribution is unbiased. Range is bounded
        ; doc: by M scalar precision (~10^18 ≈ 2^60).
        if max<min set $ecode=",U-STDCSPRNG-BAD-RANGE," quit ""
        if max=min quit min
        new range,nbytes,limit,accept,r,i,b
        set range=max-min+1
        set nbytes=1,limit=256
        for  quit:limit'<range  set nbytes=nbytes+1,limit=limit*256
        set accept=limit-(limit#range)
        set r=accept
        for  quit:r<accept  do
        . set r=0
        . set b=$$bytes(nbytes)
        . for i=1:1:nbytes  set r=(r*256)+$ascii(b,i)
        quit min+(r#range)
        ;
uuid4() ; Return a cryptographically strong RFC-4122 v4 UUID.
        ; doc: @returns       string  canonical 36-char hex UUID v4 (lowercase, hyphenated)
        ; doc: @example       write $length($$uuid4^STDCSPRNG())  ; 36
        ; doc: @example       write $extract($$uuid4^STDCSPRNG(),15)  ; "4"
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$v4^STDUUID, $$bytes^STDCSPRNG
        ; doc: 122 bits of entropy from the kernel CSPRNG. Use this when the
        ; doc: UUID is a security boundary (session tokens, signed-URL nonces,
        ; doc: JWT jti) — STDUUID's $$v4 uses non-cryptographic $RANDOM.
        new b,h,b7,b9
        set b=$$bytes(16)
        set b7=$ascii(b,7)
        set b7=(b7#16)+64
        set $extract(b,7)=$char(b7)
        set b9=$ascii(b,9)
        set b9=(b9#64)+128
        set $extract(b,9)=$char(b9)
        set h=$$encode^STDHEX(b)
        quit $extract(h,1,8)_"-"_$extract(h,9,12)_"-"_$extract(h,13,16)_"-"_$extract(h,17,20)_"-"_$extract(h,21,32)
        ;
available()     ; Return 1 iff a CSPRNG byte source is available; else 0.
        ; doc: @returns       bool    1 iff a CSPRNG byte source is available
        ; doc: @example       write $$available^STDCSPRNG()  ; 1
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$useCallout^STDCSPRNG
        ; doc: Pre-flight probe — never raises. Engine-portable: on YDB it probes
        ; doc: the /dev/urandom soft-fall-back; on IRIS the native
        ; doc: $SYSTEM.Encryption.GenCryptRand. See useCallout() to detect the
        ; doc: YDB perf-tier callout separately.
        new dev,prev
        if $zversion["IRIS" quit $$availableIris()
        set dev="/dev/urandom",prev=$io
        open dev:(readonly:nowrap):2  else  quit 0
        use prev
        close dev
        quit 1
        ;
availableIris() ; IRIS CSPRNG availability probe — never raises.
        ; doc: @internal
        ; doc: True iff $SYSTEM.Encryption.GenCryptRand yields a byte. Traps so a
        ; doc: missing backend reports 0 rather than aborting the caller. B-6.
        new ok,cmd,$etrap
        set $etrap="set $ecode="""" set ok=0 quit"
        set ok=0
        set cmd="set ok=($length($SYSTEM.Encryption.GenCryptRand(1))=1)"
        xecute cmd
        set $ecode=""
        quit ok
        ;
useCallout()    ; Return 1 iff the cs_random callout resolves; else 0.
        ; doc: @returns       bool    1 iff $&stdcsprng.random is wired and getrandom(2) succeeded
        ; doc: @example       set u=$$useCallout^STDCSPRNG() do true^STDASSERT(.pass,.fail,(u=0)!(u=1),"returns a boolean (0 or 1 depending on whether the callout is deployed)")
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$available^STDCSPRNG, $$bytes^STDCSPRNG
        ; doc: Pre-flight probe for the $&stdcsprng → getrandom(2) backend.
        ; doc: Never raises — clears $ECODE on the way out.
        new buf,n
        if $$env^STDOS("ydb_xc_stdcsprng")="" quit 0
        set buf=$$dispatchRandom(1)
        set n=$length(buf)
        set $ecode=""
        quit $select(n=1:1,1:0)
        ;
        ; ---------- internal helpers ----------
        ;
dispatchRandom(n)       ; Invoke $&stdcsprng.random(n,.out). Returns out on success, "" on miss.
        ; doc: @internal
        ; doc: XECUTE-wraps the $& external call so it stays out of the parse
        ; doc: tree. Returns the filled buffer on rc=0; returns "" when the
        ; doc: descriptor isn't deployed, the .so doesn't resolve, or
        ; doc: getrandom(2) reports failure — caller falls back to
        ; doc: /dev/urandom on "".
        new $etrap,rc,cmd,out,i
        if $$env^STDOS("ydb_xc_stdcsprng")="" quit ""
        set $etrap="set $ecode="""" set rc=-99 quit"
        ; -99 sentinel (mirrors dispatch3^STDCRYPTO): pre-setting rc=0 (the
        ; success code) made a silently-no-op callout indistinguishable from
        ; success — it would return the zero-filled prealloc buffer as
        ; "random" bytes. rc must start at a value the C side never returns.
        set rc=-99
        ; Pre-allocate n NUL bytes — cs_random reads out->length as the
        ; M-side capacity and overwrites in place.
        set out=""
        for i=1:1:n  set out=out_$char(0)
        set cmd="set rc=$&stdcsprng.random(n,.out)"
        xecute cmd
        set $ecode=""
        if rc'=0 quit ""
        quit out
