// link: -lcrypto
/*
 * std_crypto.c — m-stdlib Phase 3 cryptographic digest + HMAC callouts,
 *                plus (T32) public-key signature verification.
 *
 * Backend: OpenSSL libcrypto (EVP_Digest + HMAC + EVP_DigestVerify +
 * EVP_DigestSign). Entry points:
 *   crypto_sha256 / crypto_sha384 / crypto_sha512
 *   crypto_hmac_sha256 / crypto_hmac_sha384 / crypto_hmac_sha512
 *   crypto_verify   (asymmetric verify — RS, PS, ES + EdDSA families)
 *   crypto_sign     (asymmetric sign   — RS, PS, ES + EdDSA families; VSL-JWT
 *                    first-party issuer. The private-key mirror of crypto_verify.)
 *
 * Build:
 *   tools/build-callouts.sh           # produces so/<plat>/std_crypto.so
 * Loading:
 *   tools/std_crypto.xc                # YDB call-out descriptor
 *   export STDLIB_LIB=<abs-path-to-so/<plat>>
 *   export ydb_xc_stdcrypto=<abs-path>/tools/std_crypto.xc
 *
 * Calling convention:
 *   YottaDB's `$&pkg.fn(args)` external-call ABI prepends an `int argc`
 *   to every C entry point. So although the `.xc` descriptor describes
 *   the user-visible signature, e.g.
 *       sha256: ydb_int_t crypto_sha256(I:ydb_string_t*, O:ydb_string_t*[64])
 *   the actual C function takes (argc, in, out) — argc is what the M
 *   side passed (always equal to the descriptor's user-arg count for a
 *   well-formed call).
 *
 *   Each digest/HMAC entry point takes one or two ydb_string_t* INPUT
 *   buffers, plus one ydb_string_t* OUTPUT buffer pre-allocated by YDB
 *   (size declared via O:ydb_string_t*[64] in the .xc descriptor — large
 *   enough for SHA-512). The C side writes raw digest bytes into
 *   out->address and updates out->length to the actual digest size.
 *   Returns 0 on success.
 *
 * Status codes (digest / HMAC path):
 *    0 = ok
 *   -1 = OpenSSL EVP_MD_CTX allocation failed
 *   -2 = EVP_Digest{Init,Update,Final} reported failure
 *   -3 = caller-provided output buffer is too small for the digest
 *   -4 = HMAC() returned NULL
 *   -5 = wrong arity (argc disagreed with descriptor)
 *
 * crypto_verify (asymmetric verify) uses a DISJOINT return channel so a
 * verdict of 0 (invalid signature) is never confused with an error, and a
 * callout-missing M-side $ETRAP sentinel (-99) is distinct from every C code
 * (design: docs/design/stdcrypto-asymmetric-verify-design.md, N-3):
 *    1 = valid signature
 *    0 = invalid signature (a normal, non-exceptional answer)
 *   -5 = wrong arity
 *  -10 = BADKEY   — SPKI public key did not parse (PEM or DER)
 *  -11 = BADALG   — unsupported/unknown alg
 *  -12 = VERIFY-FAIL — internal EVP error (not a bad signature)
 */

#include <stddef.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/rsa.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/bn.h>
#include "libyottadb.h"

static int sha_digest(const EVP_MD *md, ydb_string_t *in, ydb_string_t *out)
{
    EVP_MD_CTX   *ctx;
    unsigned int  len = 0;
    unsigned char buf[EVP_MAX_MD_SIZE];

    if (out == NULL || out->address == NULL) return -3;

    ctx = EVP_MD_CTX_new();
    if (ctx == NULL) return -1;

    if (EVP_DigestInit_ex(ctx, md, NULL) != 1 ||
        EVP_DigestUpdate(ctx, in ? (const void *)in->address : NULL,
                         in ? (size_t)in->length : 0) != 1 ||
        EVP_DigestFinal_ex(ctx, buf, &len) != 1) {
        EVP_MD_CTX_free(ctx);
        return -2;
    }
    EVP_MD_CTX_free(ctx);

    if ((unsigned long)len > (unsigned long)out->length) return -3;
    memcpy(out->address, buf, len);
    out->length = (unsigned long)len;
    return 0;
}

static int hmac_digest(const EVP_MD *md,
                       ydb_string_t *key, ydb_string_t *msg,
                       ydb_string_t *out)
{
    unsigned int   len = 0;
    unsigned char  buf[EVP_MAX_MD_SIZE];
    const void          *kptr = (key && key->address) ? (const void *)key->address : "";
    int                  klen = (key) ? (int)key->length : 0;
    const unsigned char *mptr =
        (const unsigned char *)((msg && msg->address) ? msg->address : "");
    size_t               mlen = (msg) ? (size_t)msg->length : 0;

    if (out == NULL || out->address == NULL) return -3;
    if (HMAC(md, kptr, klen, mptr, mlen, buf, &len) == NULL) return -4;
    if ((unsigned long)len > (unsigned long)out->length) return -3;

    memcpy(out->address, buf, len);
    out->length = (unsigned long)len;
    return 0;
}

int crypto_sha256(int argc, ydb_string_t *in, ydb_string_t *out)
{
    if (argc != 2) return -5;
    return sha_digest(EVP_sha256(), in, out);
}

int crypto_sha384(int argc, ydb_string_t *in, ydb_string_t *out)
{
    if (argc != 2) return -5;
    return sha_digest(EVP_sha384(), in, out);
}

int crypto_sha512(int argc, ydb_string_t *in, ydb_string_t *out)
{
    if (argc != 2) return -5;
    return sha_digest(EVP_sha512(), in, out);
}

int crypto_hmac_sha256(int argc, ydb_string_t *key, ydb_string_t *msg, ydb_string_t *out)
{
    if (argc != 3) return -5;
    return hmac_digest(EVP_sha256(), key, msg, out);
}

int crypto_hmac_sha384(int argc, ydb_string_t *key, ydb_string_t *msg, ydb_string_t *out)
{
    if (argc != 3) return -5;
    return hmac_digest(EVP_sha384(), key, msg, out);
}

int crypto_hmac_sha512(int argc, ydb_string_t *key, ydb_string_t *msg, ydb_string_t *out)
{
    if (argc != 3) return -5;
    return hmac_digest(EVP_sha512(), key, msg, out);
}

/* ── asymmetric signature verify (T32) ──────────────────────────────────
 *
 * crypto_verify(alg, pubKey, msg, sig) — verdict-as-int, no output buffer.
 * pubKey is an SPKI public key in PEM or DER. Supported JWS families:
 *   RS256/384/512  RSASSA-PKCS1-v1_5 (default RSA padding — no CTX tuning)
 *   PS256/384/512  RSASSA-PSS         (explicit padding + MGF1 + saltlen=hlen)
 *   ES256/384/512  ECDSA              (JWT R‖S → DER SEQUENCE{r,s} first)
 *   EdDSA          Ed25519            (one-shot, NULL md, no pre-hash)
 * classify_alg() is the single alg→(family, md) switch. A malformed ES* R‖S
 * (odd/zero length) is an INVALID signature (return 0), never an error.
 */

/* Signature-algorithm family, from the JWS alg name. */
enum sig_family { FAM_NONE = 0, FAM_RSA_PKCS1, FAM_RSA_PSS, FAM_ECDSA, FAM_EDDSA };

/* Parse an SPKI public key that may be PEM or DER. Returns NULL on failure. */
static EVP_PKEY *parse_pubkey(ydb_string_t *key)
{
    EVP_PKEY *pkey = NULL;
    BIO      *bio;

    if (key == NULL || key->address == NULL || key->length == 0) return NULL;

    /* Try PEM first (SubjectPublicKeyInfo, "-----BEGIN PUBLIC KEY-----"). */
    bio = BIO_new_mem_buf((const void *)key->address, (int)key->length);
    if (bio != NULL) {
        pkey = PEM_read_bio_PUBKEY(bio, NULL, NULL, NULL);
        BIO_free(bio);
    }
    if (pkey != NULL) return pkey;

    /* Fall back to DER (d2i_PUBKEY advances the pointer; use a local copy). */
    {
        const unsigned char *p = (const unsigned char *)key->address;
        pkey = d2i_PUBKEY(NULL, &p, (long)key->length);
    }
    return pkey;
}

/* Digest implied by the trailing "256"/"384"/"512" of an {RS,PS,ES}NNN alg.
 * ES512 is P-521 signed under SHA-512, so the suffix→digest map is shared. */
static const EVP_MD *md_by_suffix(const char *alg)
{
    if (memcmp(alg + 2, "256", 3) == 0) return EVP_sha256();
    if (memcmp(alg + 2, "384", 3) == 0) return EVP_sha384();
    if (memcmp(alg + 2, "512", 3) == 0) return EVP_sha512();
    return NULL;
}

/* Map a JWS alg name to its (family, md). Returns FAM_NONE for unsupported;
 * *md is NULL for EdDSA (one-shot) and for FAM_NONE. */
static enum sig_family classify_alg(const char *alg, size_t alglen, const EVP_MD **md)
{
    *md = NULL;
    if (alglen != 5) return FAM_NONE;
    if (memcmp(alg, "EdDSA", 5) == 0) return FAM_EDDSA;      /* md stays NULL */
    if (memcmp(alg, "RS", 2) == 0) { *md = md_by_suffix(alg); return *md ? FAM_RSA_PKCS1 : FAM_NONE; }
    if (memcmp(alg, "PS", 2) == 0) { *md = md_by_suffix(alg); return *md ? FAM_RSA_PSS : FAM_NONE; }
    if (memcmp(alg, "ES", 2) == 0) { *md = md_by_suffix(alg); return *md ? FAM_ECDSA : FAM_NONE; }
    return FAM_NONE;
}

/* Convert a JWT fixed-width R‖S signature (RFC 7518 §3.4) into a DER
 * SEQUENCE{r,s} that EVP_DigestVerify accepts. The component width is
 * siglen/2 — DERIVED, not a constant: P-256=32, P-384=48, P-521=66 (so a
 * P-521 sig is 132 bytes, not 128). An odd or empty siglen is a malformed
 * signature, reported as NULL so the caller returns 0 (invalid), never an
 * error. r/s are read via BN_bin2bn (big-endian, leading-zero tolerant) and
 * i2d_ECDSA_SIG emits canonical minimal-length DER, so this cannot introduce a
 * malleable re-encoding. Returns an OpenSSL-malloc'd buffer (free with
 * OPENSSL_free) and sets *derlen, or NULL on any structural failure. */
static unsigned char *rs_to_der(const unsigned char *sig, size_t siglen, int *derlen)
{
    ECDSA_SIG     *ecsig = NULL;
    BIGNUM        *r = NULL, *s = NULL;
    unsigned char *der = NULL;
    size_t         half;
    int            len;

    *derlen = 0;
    if (sig == NULL || siglen == 0 || (siglen & 1)) return NULL;   /* odd/empty → invalid */
    half = siglen / 2;

    r = BN_bin2bn(sig, (int)half, NULL);
    s = BN_bin2bn(sig + half, (int)half, NULL);
    ecsig = ECDSA_SIG_new();
    if (r == NULL || s == NULL || ecsig == NULL) goto cleanup;

    if (ECDSA_SIG_set0(ecsig, r, s) != 1) goto cleanup;   /* takes ownership on success */
    r = NULL;
    s = NULL;

    len = i2d_ECDSA_SIG(ecsig, &der);
    if (len <= 0) { der = NULL; goto cleanup; }
    *derlen = len;

cleanup:
    BN_free(r);
    BN_free(s);
    ECDSA_SIG_free(ecsig);
    return der;
}

int crypto_verify(int argc, ydb_string_t *alg, ydb_string_t *key,
                  ydb_string_t *msg, ydb_string_t *sig)
{
    EVP_PKEY        *pkey = NULL;
    EVP_MD_CTX      *ctx = NULL;
    EVP_PKEY_CTX    *pctx = NULL;          /* owned by ctx — never freed here */
    const EVP_MD    *md = NULL;
    enum sig_family  fam;
    const unsigned char *vsig;
    size_t           vsiglen;
    unsigned char   *der = NULL;
    int              derlen = 0;
    int              ret = -12;
    int              rc;

    if (argc != 4) return -5;
    if (alg == NULL || alg->address == NULL) return -11;

    fam = classify_alg((const char *)alg->address, (size_t)alg->length, &md);
    if (fam == FAM_NONE) return -11;                  /* BADALG */

    pkey = parse_pubkey(key);
    if (pkey == NULL) return -10;                     /* BADKEY */

    ctx = EVP_MD_CTX_new();
    if (ctx == NULL) { EVP_PKEY_free(pkey); return -12; }

    if (fam == FAM_EDDSA) {
        /* Ed25519: one-shot over the message, NULL md, no pre-hash (RFC 8037). */
        if (EVP_DigestVerifyInit(ctx, NULL, NULL, NULL, pkey) != 1) { ret = -12; goto done; }
    } else {
        if (EVP_DigestVerifyInit(ctx, &pctx, md, NULL, pkey) != 1) { ret = -12; goto done; }
        if (fam == FAM_RSA_PSS) {
            /* PS*: set params EXPLICITLY — defaults vary across OpenSSL versions.
             * MGF1 with the same digest; salt length == digest length. */
            if (EVP_PKEY_CTX_set_rsa_padding(pctx, RSA_PKCS1_PSS_PADDING) <= 0 ||
                EVP_PKEY_CTX_set_rsa_pss_saltlen(pctx, RSA_PSS_SALTLEN_DIGEST) <= 0 ||
                EVP_PKEY_CTX_set_rsa_mgf1_md(pctx, md) <= 0) { ret = -12; goto done; }
        }
    }

    vsig    = (const unsigned char *)(sig ? sig->address : NULL);
    vsiglen = (size_t)(sig ? sig->length : 0);

    if (fam == FAM_ECDSA) {
        /* JWT carries ES* sigs as R‖S; EVP wants DER SEQUENCE{r,s}. */
        der = rs_to_der(vsig, vsiglen, &derlen);
        if (der == NULL) { ret = 0; goto done; }      /* malformed R‖S → invalid */
        vsig    = der;
        vsiglen = (size_t)derlen;
    }

    rc = EVP_DigestVerify(ctx, vsig, vsiglen,
                          (const unsigned char *)(msg ? msg->address : NULL),
                          (size_t)(msg ? msg->length : 0));
    if (rc == 1) ret = 1;                             /* valid   */
    else if (rc == 0) ret = 0;                        /* invalid — normal answer */
    else ret = -12;                                   /* VERIFY-FAIL (rc < 0) */

done:
    if (der != NULL) OPENSSL_free(der);
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return ret;
}

/* ── asymmetric signature SIGN (VSL-JWT first-party issuer) ──────────────
 *
 * crypto_sign(alg, privKey, msg, out) — the PRIVATE-key mirror of crypto_verify.
 * privKey is a PKCS#8 or traditional private key in PEM or DER (parse_privkey →
 * d2i_AutoPrivateKey, which auto-detects PKCS#8 vs SEC1/PKCS#1). The raw
 * signature is written into the caller-preallocated `out` buffer (its ->length
 * on entry is the capacity; on return it is the true signature length):
 *   RS, PS   -> raw RSA signature bytes (== key modulus size)
 *   ES       -> JWT fixed-width R‖S (RFC 7518 §3.4), converted from the DER
 *              SEQUENCE{r,s} EVP emits — the mirror of crypto_verify's rs_to_der.
 *   EdDSA    → 64 raw bytes (one-shot, NULL md)
 *
 * SECURITY: privKey is the issuer's crown jewel — a leak forges any token. This
 * callout never logs, caches, or persists it; it lives only for the call.
 *
 * Status codes (mirror crypto_verify's disjoint channel; sign has no "invalid"
 * verdict — it either produces a signature or fails):
 *    0 = ok (out holds the signature)
 *   -3 = caller output buffer too small for the signature
 *   -5 = wrong arity
 *  -10 = BADKEY   — private key did not parse (PEM or DER)
 *  -11 = BADALG   — unsupported/unknown alg
 *  -12 = SIGN-FAIL — internal EVP error
 */

/* Parse a private key that may be PEM or DER, PKCS#8 or traditional (SEC1/PKCS#1).
 * Returns NULL on failure. */
static EVP_PKEY *parse_privkey(ydb_string_t *key)
{
    EVP_PKEY *pkey = NULL;
    BIO      *bio;

    if (key == NULL || key->address == NULL || key->length == 0) return NULL;

    /* Try PEM first ("-----BEGIN PRIVATE KEY-----" / "EC PRIVATE KEY" / "RSA…"). */
    bio = BIO_new_mem_buf((const void *)key->address, (int)key->length);
    if (bio != NULL) {
        pkey = PEM_read_bio_PrivateKey(bio, NULL, NULL, NULL);
        BIO_free(bio);
    }
    if (pkey != NULL) return pkey;

    /* Fall back to DER; d2i_AutoPrivateKey auto-detects PKCS#8 vs traditional. */
    {
        const unsigned char *p = (const unsigned char *)key->address;
        pkey = d2i_AutoPrivateKey(NULL, &p, (long)key->length);
    }
    return pkey;
}

/* Convert a DER SEQUENCE{r,s} (what EVP_DigestSign emits for ECDSA) into the
 * JWT fixed-width R‖S signature (RFC 7518 §3.4). `half` is the per-component
 * width derived from the key's group order (P-256=32, P-384=48, P-521=66).
 * BN_bn2binpad left-pads each component to exactly `half` big-endian bytes.
 * Returns 0 on success (writes 2*half bytes to out), -3 if out is too small,
 * -12 on any structural failure. */
static int der_to_rs(const unsigned char *der, size_t derlen, int half,
                     unsigned char *out, size_t outcap)
{
    ECDSA_SIG    *sig = NULL;
    const BIGNUM *r, *s;
    const unsigned char *p = der;
    int ret = -12;

    if ((size_t)(2 * half) > outcap) return -3;
    sig = d2i_ECDSA_SIG(NULL, &p, (long)derlen);
    if (sig == NULL) return -12;
    ECDSA_SIG_get0(sig, &r, &s);
    if (BN_bn2binpad(r, out, half) != half) goto done;
    if (BN_bn2binpad(s, out + half, half) != half) goto done;
    ret = 0;
done:
    ECDSA_SIG_free(sig);
    return ret;
}

int crypto_sign(int argc, ydb_string_t *alg, ydb_string_t *key,
                ydb_string_t *msg, ydb_string_t *out)
{
    EVP_PKEY        *pkey = NULL;
    EVP_MD_CTX      *ctx = NULL;
    EVP_PKEY_CTX    *pctx = NULL;          /* owned by ctx — never freed here */
    const EVP_MD    *md = NULL;
    enum sig_family  fam;
    unsigned char   *sigbuf = NULL;
    size_t           siglen = 0;
    int              ret = -12;

    if (argc != 4) return -5;
    if (out == NULL || out->address == NULL) return -3;
    if (alg == NULL || alg->address == NULL) return -11;

    fam = classify_alg((const char *)alg->address, (size_t)alg->length, &md);
    if (fam == FAM_NONE) return -11;                  /* BADALG */

    pkey = parse_privkey(key);
    if (pkey == NULL) return -10;                     /* BADKEY */

    ctx = EVP_MD_CTX_new();
    if (ctx == NULL) { EVP_PKEY_free(pkey); return -12; }

    if (fam == FAM_EDDSA) {
        /* Ed25519: one-shot over the message, NULL md, no pre-hash (RFC 8037). */
        if (EVP_DigestSignInit(ctx, NULL, NULL, NULL, pkey) != 1) { ret = -12; goto done; }
    } else {
        if (EVP_DigestSignInit(ctx, &pctx, md, NULL, pkey) != 1) { ret = -12; goto done; }
        if (fam == FAM_RSA_PSS) {
            /* PS*: same explicit params as the verify path (salt len == digest). */
            if (EVP_PKEY_CTX_set_rsa_padding(pctx, RSA_PKCS1_PSS_PADDING) <= 0 ||
                EVP_PKEY_CTX_set_rsa_pss_saltlen(pctx, RSA_PSS_SALTLEN_DIGEST) <= 0 ||
                EVP_PKEY_CTX_set_rsa_mgf1_md(pctx, md) <= 0) { ret = -12; goto done; }
        }
    }

    /* Two-pass EVP_DigestSign: first NULL to learn the length, then sign. */
    if (EVP_DigestSign(ctx, NULL, &siglen,
                       (const unsigned char *)(msg ? msg->address : NULL),
                       (size_t)(msg ? msg->length : 0)) != 1) { ret = -12; goto done; }
    sigbuf = OPENSSL_malloc(siglen ? siglen : 1);
    if (sigbuf == NULL) { ret = -12; goto done; }
    if (EVP_DigestSign(ctx, sigbuf, &siglen,
                       (const unsigned char *)(msg ? msg->address : NULL),
                       (size_t)(msg ? msg->length : 0)) != 1) { ret = -12; goto done; }

    if (fam == FAM_ECDSA) {
        /* EVP emits DER SEQUENCE{r,s}; JWT wants fixed-width R‖S. Width is the
         * group order size, derived from the key (P-256=32 / P-384=48 / P-521=66). */
        int half = (EVP_PKEY_bits(pkey) + 7) / 8;
        int rc = der_to_rs(sigbuf, siglen, half,
                           (unsigned char *)out->address, (size_t)out->length);
        if (rc != 0) { ret = rc; goto done; }
        out->length = (unsigned long)(2 * half);
        ret = 0;
    } else {
        if (siglen > (size_t)out->length) { ret = -3; goto done; }
        memcpy(out->address, sigbuf, siglen);
        out->length = (unsigned long)siglen;
        ret = 0;
    }

done:
    if (sigbuf != NULL) OPENSSL_free(sigbuf);
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return ret;
}
