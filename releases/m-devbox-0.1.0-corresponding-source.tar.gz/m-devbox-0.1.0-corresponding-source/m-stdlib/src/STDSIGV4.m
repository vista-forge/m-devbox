STDSIGV4        ; m-stdlib — AWS Signature Version 4 request signer.
        ; doc: @tag v0.14.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ; doc: @tier optional
        ;
        ; Service-generic AWS SigV4 signer (S3 is the first consumer; the same
        ; module signs any AWS SigV4 REST service). Implements the four-step
        ; signing process — canonical request, string-to-sign, the HMAC signing-
        ; key chain, and the final signature — over m-stdlib's existing crypto
        ; primitives. There is no new crypto here: every step maps onto a
        ; $$…^STDCRYPTO / $$encode^STDHEX call.
        ;
        ; Public extrinsics:
        ;   $$authHeader^STDSIGV4(ctx,method,uri,query,headers,phash,amz,date)
        ;                                       — the full Authorization header
        ;   $$sign^STDSIGV4(ctx,method,uri,query,headers,phash,amz,date)
        ;                                       — 64-char hex signature
        ;   $$signingKey^STDSIGV4(secret,date,region,service) — raw 32-byte key
        ;   $$canonRequest^STDSIGV4(method,uri,query,headers,phash,.signed)
        ;                                       — canonical-request string
        ;   $$encPath^STDSIGV4(key)             — URI-encode, keep "/"
        ;   $$encQuery^STDSIGV4(.params)        — sorted canonical query string
        ;   $$amzDate^STDSIGV4()                — current UTC YYYYMMDDgHHMMSSZ
        ;   $$emptyHash^STDSIGV4()              — cached empty-payload SHA-256
        ;
        ; Byte-mode correctness: the signing-key chain passes raw 32-byte HMAC
        ; outputs as the key to the next HMAC (steps 1-3 use the …Bytes crypto
        ; variants); only step 4 emits hex. Under ydb_chset=UTF-8 the raw-byte
        ; keys would re-encode and silently produce a wrong signature, so run
        ; the engine in byte (M) mode — the m-stdlib default.
        quit
        ;
        ; ---------- public API ----------
        ;
emptyHash()     ; The SHA-256 of the empty string (the unsigned-body hash constant).
        ; doc: @returns       string  64-char lowercase hex (e3b0c442…b855)
        ; doc: @example       write $$emptyHash^STDSIGV4()  ; "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$sha256^STDCRYPTO
        quit "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        ;
signingKey(secret,datestamp,region,service)     ; SigV4 raw 32-byte signing key (HMAC chain).
        ; doc: @param secret      string  the AWS secret access key
        ; doc: @param datestamp   string  YYYYMMDD (UTC)
        ; doc: @param region      string  AWS region, e.g. us-east-1
        ; doc: @param service     string  AWS service, e.g. s3
        ; doc: @returns           byte-string  raw 32-byte signing key
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @example       do eq^STDASSERT(.pass,.fail,$$encode^STDHEX($$signingKey^STDSIGV4("wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY","20150830","us-east-1","iam")),"2c94c0cf5378ada6887f09bb697df8fc0affdb34ba1cdd5bda32b664bd55b73c","AWS IAM known-answer signing key")
        ; doc: @illustrative  @raises U-STDCRYPTO-CALLOUT-MISSING fires only when libcrypto/std_crypto is unloaded; cannot be triggered where the call-out is present.
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$sign^STDSIGV4
        ; doc: Each line keys the next on RAW bytes (…Bytes variant) — the
        ; doc: single most common SigV4 bug. Byte mode (ydb_chset=M) keeps it exact.
        new kDate,kRegion,kService
        set kDate=$$hmacSha256Bytes^STDCRYPTO("AWS4"_secret,datestamp)
        set kRegion=$$hmacSha256Bytes^STDCRYPTO(kDate,region)
        set kService=$$hmacSha256Bytes^STDCRYPTO(kRegion,service)
        quit $$hmacSha256Bytes^STDCRYPTO(kService,"aws4_request")
        ;
encPath(key)    ; URI-encode an object key (RFC 3986), preserving the "/" separator.
        ; doc: @param key     string  object key (one M character per byte)
        ; doc: @returns       string  percent-encoded path, "/" left literal
        ; doc: @example       write $$encPath^STDSIGV4("a/my key.txt")  ; "a/my%20key.txt"
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$encode^STDURL
        quit $$encode^STDURL(key,"/")
        ;
encQuery(params)        ; Build the canonical query string: keys sorted, both sides URI-encoded.
        ; doc: @param params  array   params(name)=value, by reference
        ; doc: @returns       string  "k1=v1&k2=v2&…" sorted by encoded key
        ; doc: @example       new q set q("b")=2,q("a")=1 do eq^STDASSERT(.pass,.fail,$$encQuery^STDSIGV4(.q),"a=1&b=2","keys sorted into canonical order")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$encPath^STDSIGV4
        new q,k
        set q="",k=""
        for  set k=$order(params(k)) quit:k=""  do
        . set q=q_$select(q="":"",1:"&")_$$encode^STDURL(k,"")_"="_$$encode^STDURL(params(k),"")
        quit q
        ;
canonRequest(method,uri,query,headers,payloadHash,signed)       ; Build the SigV4 canonical request (and the signed-headers list, by ref).
        ; doc: @param method      string  HTTP method (GET/PUT/…)
        ; doc: @param uri         string  canonical URI (already encPath'd, leading "/")
        ; doc: @param query       string  canonical query string ("" if none)
        ; doc: @param headers     array   headers(name)=value, by reference
        ; doc: @param payloadHash string  hex SHA-256 of the body (or UNSIGNED-PAYLOAD)
        ; doc: @param signed      string  OUT — ";"-joined lowercased signed-header names
        ; doc: @returns           string  the canonical-request string (LF-joined)
        ; doc: @example       new h,signed,cr set h("host")="examplebucket.s3.amazonaws.com",h("x-amz-date")="20130524T000000Z" set cr=$$canonRequest^STDSIGV4("GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),.signed) do eq^STDASSERT(.pass,.fail,signed,"host;x-amz-date","signed-header list returned by reference")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$sign^STDSIGV4
        new canHdr
        do canonHeaders(.headers,.canHdr,.signed)
        quit method_$char(10)_uri_$char(10)_query_$char(10)_canHdr_$char(10)_signed_$char(10)_payloadHash
        ;
sign(ctx,method,uri,query,headers,payloadHash,amzdate,datestamp) ; Compute the 64-char hex SigV4 signature.
        ; doc: @param ctx         array   ctx("secretKey"/"region"/"service"), by reference
        ; doc: @param method      string  HTTP method
        ; doc: @param uri         string  canonical URI
        ; doc: @param query       string  canonical query string
        ; doc: @param headers     array   headers(name)=value, by reference
        ; doc: @param payloadHash string  hex SHA-256 of the body
        ; doc: @param amzdate     string  x-amz-date YYYYMMDDgHHMMSSZ
        ; doc: @param datestamp   string  YYYYMMDD (the amzdate's date part)
        ; doc: @returns           string  64-char lowercase hex signature
        ; doc: @raises        U-STDCRYPTO-CALLOUT-MISSING  std_crypto not loaded
        ; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @example       new ctx,h set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",ctx("region")="us-east-1",ctx("service")="s3",h("host")="examplebucket.s3.amazonaws.com",h("range")="bytes=0-9",h("x-amz-content-sha256")=$$emptyHash^STDSIGV4(),h("x-amz-date")="20130524T000000Z" do eq^STDASSERT(.pass,.fail,$$sign^STDSIGV4(.ctx,"GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),"20130524T000000Z","20130524"),"f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","AWS S3 GET-Object documented signature")
        ; doc: @illustrative  @raises U-STDCRYPTO-CALLOUT-MISSING fires only when libcrypto/std_crypto is unloaded; cannot be triggered where the call-out is present.
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$authHeader^STDSIGV4
        new cr,sts,key,signed
        set cr=$$canonRequest(method,uri,query,.headers,payloadHash,.signed)
        set sts="AWS4-HMAC-SHA256"_$char(10)_amzdate_$char(10)
        set sts=sts_datestamp_"/"_ctx("region")_"/"_ctx("service")_"/aws4_request"_$char(10)
        set sts=sts_$$sha256^STDCRYPTO(cr)
        set key=$$signingKey(ctx("secretKey"),datestamp,ctx("region"),ctx("service"))
        quit $$hmacSha256^STDCRYPTO(key,sts)
        ;
authHeader(ctx,method,uri,query,headers,payloadHash,amzdate,datestamp)   ; Build the full Authorization header value.
        ; doc: @param ctx         array   ctx("accessKey"/"secretKey"/"region"/"service"), by reference
        ; doc: @param method      string  HTTP method
        ; doc: @param uri         string  canonical URI
        ; doc: @param query       string  canonical query string
        ; doc: @param headers     array   headers(name)=value, by reference
        ; doc: @param payloadHash string  hex SHA-256 of the body
        ; doc: @param amzdate     string  x-amz-date YYYYMMDDgHHMMSSZ
        ; doc: @param datestamp   string  YYYYMMDD
        ; doc: @returns           string  "AWS4-HMAC-SHA256 Credential=…, SignedHeaders=…, Signature=…"
        ; doc: @example       new ctx,h set ctx("accessKey")="AKIAIOSFODNN7EXAMPLE",ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",ctx("region")="us-east-1",ctx("service")="s3",h("host")="examplebucket.s3.amazonaws.com",h("range")="bytes=0-9",h("x-amz-content-sha256")=$$emptyHash^STDSIGV4(),h("x-amz-date")="20130524T000000Z" do contains^STDASSERT(.pass,.fail,$$authHeader^STDSIGV4(.ctx,"GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),"20130524T000000Z","20130524"),"Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","header embeds the AWS S3 GET-Object signature")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$sign^STDSIGV4
        new sig,signed,canHdr,scope
        set sig=$$sign(.ctx,method,uri,query,.headers,payloadHash,amzdate,datestamp)
        do canonHeaders(.headers,.canHdr,.signed)
        set scope=datestamp_"/"_ctx("region")_"/"_ctx("service")_"/aws4_request"
        quit "AWS4-HMAC-SHA256 Credential="_ctx("accessKey")_"/"_scope_", SignedHeaders="_signed_", Signature="_sig
        ;
amzDate()       ; Current UTC timestamp in SigV4 basic-ISO form YYYYMMDDgHHMMSSZ.
        ; doc: @returns       string  16-char basic-ISO UTC (e.g. 20260619T123456Z)
        ; doc: @example       write $length($$amzDate^STDSIGV4())  ; 16
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$now^STDDATE
        ; doc: Derived from $$now^STDDATE (extended ISO with separators); the
        ; doc: "-", ":" and ".sss" fraction are stripped to the SigV4 basic form.
        new d
        set d=$$now^STDDATE()
        quit $extract(d,1,4)_$extract(d,6,7)_$extract(d,9,10)_"T"_$extract(d,12,13)_$extract(d,15,16)_$extract(d,18,19)_"Z"
        ;
        ; ---------- private ----------
        ;
canonHeaders(headers,canHdr,signed)     ; Build the "name:value\n…" block + ";"-joined signed-header list.
        ; doc: @internal
        new tmp,name,lname
        set name=""
        for  set name=$order(headers(name)) quit:name=""  do
        . set tmp($$toLowerASCII^STDSTR(name))=$$trim^STDSTR($get(headers(name)))
        set canHdr="",signed="",lname=""
        for  set lname=$order(tmp(lname)) quit:lname=""  do
        . set canHdr=canHdr_lname_":"_tmp(lname)_$char(10)
        . set signed=signed_$select(signed="":"",1:";")_lname
        quit
        ;
