STDHTTPMSG      ; m-stdlib — pure-M HTTP/1.1 parse+serialize codec (the §5 seam).
        ; doc: @tag v0.10.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ;
        ; The portability seam the VistA-native HTTPS stack (VWEB capstone) sits
        ; on: a byte-level HTTP/1.1 message codec, identical on YottaDB and IRIS.
        ; It is the engine-neutral half of the inbound/outbound web stack — the
        ; bytes that feed it come from the socket layer (STDNET + the per-engine
        ; VWEBIO adapter, above the waterline); the codec itself knows nothing of
        ; sockets, TLS, VistA, XPAR, or $ZF. That is exactly why it lives here in
        ; m-stdlib and not in the VWEB package.
        ;
        ; Symmetric (P4): the same REQ/RSP contract serves inbound (parse a
        ; request, serialize a response) and outbound (serialize a request, parse
        ; a response). v0.1 is a BUFFER-AT-ONCE codec — the caller (STDHTTPD's
        ; worker loop / the outbound client) owns the socket read and hands a
        ; complete in-memory buffer down. A streaming pull/feed interface is a
        ; documented future extension (spec §15) and is deliberately NOT built
        ; here — the listener does not need it yet.
        ;
        ; Parse failures are NORMAL TRAFFIC, not exceptions: parseReq/parseRsp
        ; return an HTTP status code (200 ok; 400/413/414/431 on a bad message)
        ; and fill REQ/RSP. A loud $ECODE is reserved for a genuine internal
        ; fault — guarded by a flag-based $ETRAP (NEVER zgoto) that maps it to a
        ; 500 / empty-string return.
        ;
        ; Size caps are config-INJECTED parameters with safe defaults (never
        ; XPAR-aware): the VWEB layer sources them from XPAR later and passes
        ; them down via `opts`. Defaults: maxline 8192, maxhdrcount 100,
        ; maxhdrbytes 16384, maxbody 1048576.
        ;
        ; Built on the existing STD* leaves — percent-decode STDURL, string ops
        ; STDSTR, the Date header STDDATE, the JSON body STDJSON. Nothing here is
        ; re-implemented from those.
        ;
        ; Public extrinsics (all functions — call with $$):
        ;   $$parseReq(buf,.REQ,.opts)  — parse a request buffer -> status; fills REQ (§5.1)
        ;   $$parseRsp(buf,.RSP,.opts)  — parse a response buffer -> status; fills RSP (§5.2)
        ;   $$serializeReq(.REQ)        — REQ -> request bytes
        ;   $$serializeRsp(.RSP)        — RSP -> response bytes
        ;   $$hdr(.MSG,name)            — case-insensitive header lookup over MSG("hdr",…)
        ;
        quit
        ;
        ; ---------- parse (inbound request / outbound response) ----------
        ;
parseReq(buf,REQ,opts)  ; Parse an HTTP/1.1 request buffer into the REQ contract.
        ; doc: @param buf     string  complete request bytes (request line + headers + body)
        ; doc: @param REQ     array   by-ref; killed then populated per spec §5.1
        ; doc: @param opts    array   by-ref size caps (maxline/maxhdrcount/maxhdrbytes/maxbody); optional
        ; doc: @returns       numeric HTTP status: 200 ok; 400/413/414/431 on a bad request
        ; doc: @example       set crlf=$char(13,10) set buf="GET /a?x=1 HTTP/1.1"_crlf_"Host: h"_crlf_crlf do eq^STDASSERT(.pass,.fail,$$parseReq^STDHTTPMSG(buf,.req),200,"parseReq ok")
        ; doc: @example       set crlf=$char(13,10) set buf="POST /p HTTP/1.1"_crlf_"Host: h"_crlf_crlf set st=$$parseReq^STDHTTPMSG(buf,.req) do eq^STDASSERT(.pass,.fail,req("method"),"POST","parseReq fills method")
        ; doc: @since         v0.10.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPMSG
        ; doc: @see           $$serializeRsp^STDHTTPMSG, $$hdr^STDHTTPMSG
        new $etrap,cap,sep,crlf,bp,head,body,rl,method,target,verraw,ver,qpos,nlines,i,line,c1,cp,hn,hv,rc,te
        set $etrap="set $ecode="""" quit 500"
        kill REQ
        do caps(.opts,.cap)
        set sep=$char(13,10,13,10),crlf=$char(13,10)
        set bp=$find(buf,sep)
        if 'bp quit 400
        set head=$extract(buf,1,bp-5),body=$extract(buf,bp,$length(buf))
        set rl=$piece(head,crlf,1)
        if $length(rl)>cap("maxline") quit 414
        if $length(rl," ")'=3 quit 400
        set method=$piece(rl," ",1),target=$piece(rl," ",2),verraw=$piece(rl," ",3)
        if (method="")!(target="") quit 400
        if $extract(verraw,1,5)'="HTTP/" quit 400
        set ver=$extract(verraw,6,$length(verraw))
        if (ver'="1.0")&(ver'="1.1") quit 400
        set REQ("method")=$$toUpperASCII^STDSTR(method),REQ("ver")=ver
        set qpos=$find(target,"?")
        if qpos set REQ("rawpath")=$extract(target,1,qpos-2),REQ("rawquery")=$extract(target,qpos,$length(target))
        if 'qpos set REQ("rawpath")=target,REQ("rawquery")=""
        set REQ("path")=$$decode^STDURL(REQ("rawpath"))
        if REQ("rawquery")'="" do parseQuery(REQ("rawquery"),.REQ)
        set nlines=$length(head,crlf)
        if (nlines-1)>cap("maxhdrcount") quit 431
        if $length(head)>cap("maxhdrbytes") quit 431
        set rc=""
        for i=2:1:nlines do  quit:rc'=""
        . set line=$piece(head,crlf,i),c1=$extract(line,1)
        . if (c1=" ")!(c1=$char(9)) set rc=400 quit
        . set cp=$find(line,":")
        . if 'cp set rc=400 quit
        . set hn=$$toLowerASCII^STDSTR($extract(line,1,cp-2)),hv=$$trim^STDSTR($extract(line,cp,$length(line)))
        . if hn="" set rc=400 quit
        . if $data(REQ("hdr",hn)) set REQ("hdr",hn)=REQ("hdr",hn)_", "_hv
        . if '$data(REQ("hdr",hn)) set REQ("hdr",hn)=hv
        if rc'="" quit rc
        set te=$$toLowerASCII^STDSTR($get(REQ("hdr","transfer-encoding")))
        if te["chunked" do
        . new dec,drc
        . set dec=$$dechunk(body,cap("maxbody"),.drc)
        . if drc'=200 set rc=drc quit
        . set REQ("body")=dec,REQ("body","len")=$length(dec)
        if te'["chunked" do
        . new cl
        . set cl=$get(REQ("hdr","content-length"))
        . if cl="" set REQ("body","len")=0 quit
        . if cl'?1.N set rc=400 quit
        . if cl>cap("maxbody") set rc=413 quit
        . if $length(body)<cl set rc=400 quit
        . set REQ("body")=$extract(body,1,cl),REQ("body","len")=cl
        if rc'="" quit rc
        do setKeepalive(ver,$get(REQ("hdr","connection")),.REQ)
        quit 200
        ;
parseRsp(buf,RSP,opts)  ; Parse an HTTP/1.1 response buffer into the RSP contract.
        ; doc: @param buf     string  complete response bytes (status line + headers + body)
        ; doc: @param RSP     array   by-ref; killed then populated per spec §5.2
        ; doc: @param opts    array   by-ref size caps (maxbody); optional
        ; doc: @returns       numeric HTTP status: 200 ok; 400/413 on a bad response
        ; doc: @example       set crlf=$char(13,10) set buf="HTTP/1.1 404 Not Found"_crlf_"Content-Length: 0"_crlf_crlf do eq^STDASSERT(.pass,.fail,$$parseRsp^STDHTTPMSG(buf,.rsp),200,"parseRsp ok")
        ; doc: @example       set crlf=$char(13,10) set buf="HTTP/1.1 201 Created"_crlf_"Content-Length: 0"_crlf_crlf set st=$$parseRsp^STDHTTPMSG(buf,.rsp) do eq^STDASSERT(.pass,.fail,rsp("status"),201,"parseRsp fills status")
        ; doc: @since         v0.10.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPMSG
        ; doc: @see           $$serializeReq^STDHTTPMSG, $$hdr^STDHTTPMSG
        ; doc: Response header names keep their on-the-wire casing (§5.2); use
        ; doc: $$hdr for case-insensitive lookup.
        new $etrap,cap,sep,crlf,bp,head,body,sl,ver,status,reason,nlines,i,line,cp,hn,hv,rc,te
        set $etrap="set $ecode="""" quit 500"
        kill RSP
        do caps(.opts,.cap)
        set sep=$char(13,10,13,10),crlf=$char(13,10)
        set bp=$find(buf,sep)
        if 'bp quit 400
        set head=$extract(buf,1,bp-5),body=$extract(buf,bp,$length(buf))
        set sl=$piece(head,crlf,1)
        if $extract(sl,1,5)'="HTTP/" quit 400
        set ver=$piece($piece(sl," ",1),"/",2),status=$piece(sl," ",2),reason=$piece(sl," ",3,999)
        if status'?3N quit 400
        set RSP("ver")=ver,RSP("status")=status,RSP("reason")=reason
        set nlines=$length(head,crlf),rc=""
        for i=2:1:nlines do  quit:rc'=""
        . set line=$piece(head,crlf,i)
        . set cp=$find(line,":")
        . if 'cp set rc=400 quit
        . set hn=$extract(line,1,cp-2),hv=$$trim^STDSTR($extract(line,cp,$length(line)))
        . if hn="" set rc=400 quit
        . if $data(RSP("hdr",hn)) set RSP("hdr",hn)=RSP("hdr",hn)_", "_hv
        . if '$data(RSP("hdr",hn)) set RSP("hdr",hn)=hv
        if rc'="" quit rc
        set te=$$toLowerASCII^STDSTR($$hdr(.RSP,"transfer-encoding"))
        if te["chunked" do
        . new dec,drc
        . set dec=$$dechunk(body,cap("maxbody"),.drc)
        . if drc'=200 set rc=drc quit
        . set RSP("body")=dec,RSP("body","len")=$length(dec)
        if te'["chunked" do
        . new cl
        . set cl=$$hdr(.RSP,"content-length")
        . if cl="" set RSP("body")=body,RSP("body","len")=$length(body) quit
        . if cl'?1.N set rc=400 quit
        . if cl>cap("maxbody") set rc=413 quit
        . set RSP("body")=$extract(body,1,cl),RSP("body","len")=cl
        if rc'="" quit rc
        do setKeepalive(ver,$$hdr(.RSP,"connection"),.RSP)
        quit 200
        ;
        ; ---------- serialize (inbound response / outbound request) ----------
        ;
serializeRsp(RSP)       ; Serialize the RSP contract into HTTP/1.1 response bytes.
        ; doc: @param RSP     array   by-ref response per spec §5.2 (status/hdr/body/json)
        ; doc: @returns       string  full response bytes (status line + headers + CRLF + body)
        ; doc: @example       set rsp("status")=200,rsp("reason")="OK" do contains^STDASSERT(.pass,.fail,$$serializeRsp^STDHTTPMSG(.rsp),"HTTP/1.1 200 OK","serializeRsp status line")
        ; doc: @since         v0.10.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPMSG
        ; doc: @see           $$parseRsp^STDHTTPMSG
        ; doc: Always emits Content-Length (no server-side chunking in v0.1).
        ; doc: Injects Date/Server/Connection and a JSON Content-Type only when
        ; doc: the caller has not already set them; caller header casing is kept.
        new $etrap,h,body,status,reason,ver,hn,out,crlf
        set $etrap="set $ecode="""" quit """""
        set crlf=$char(13,10)
        set status=$get(RSP("status"),200),ver=$get(RSP("ver"),"1.1")
        set reason=$get(RSP("reason"))
        if reason="" set reason=$$reason(status)
        merge h=RSP("hdr")
        set body=$get(RSP("body"))
        if $data(RSP("json")) do
        . new jnode
        . merge jnode=RSP("json")
        . set body=$$encode^STDJSON(.jnode)
        . if '$data(h("Content-Type")) set h("Content-Type")="application/json"
        if '$data(h("Date")) set h("Date")=$$httpdate^STDDATE($horolog)
        if '$data(h("Server")) set h("Server")="m-stdlib"
        if '$data(h("Connection")) set h("Connection")=$select($get(RSP("keepalive"),1):"keep-alive",1:"close")
        set h("Content-Length")=$length(body)
        set out="HTTP/"_ver_" "_status_" "_reason_crlf,hn=""
        for  do  quit:hn=""
        . set hn=$order(h(hn))
        . if hn'="" set out=out_hn_": "_h(hn)_crlf
        quit out_crlf_body
        ;
serializeReq(REQ)       ; Serialize the REQ contract into HTTP/1.1 request bytes.
        ; doc: @param REQ     array   by-ref request per spec §5.1 (method/rawpath/rawquery/hdr/body)
        ; doc: @returns       string  full request bytes (request line + headers + CRLF + body)
        ; doc: @example       set req("method")="GET",req("rawpath")="/a" do contains^STDASSERT(.pass,.fail,$$serializeReq^STDHTTPMSG(.req),"GET /a HTTP/1.1","serializeReq request line")
        ; doc: @since         v0.10.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPMSG
        ; doc: @see           $$parseReq^STDHTTPMSG
        ; doc: The request-target is REQ("rawpath") (+ "?"_REQ("rawquery") when
        ; doc: set) verbatim — the caller owns query encoding. Content-Length is
        ; doc: emitted when a body is present.
        new $etrap,h,body,method,ver,target,hn,out,crlf
        set $etrap="set $ecode="""" quit """""
        set crlf=$char(13,10)
        set method=$get(REQ("method"),"GET"),ver=$get(REQ("ver"),"1.1")
        set target=$get(REQ("rawpath"),"/")
        if $get(REQ("rawquery"))'="" set target=target_"?"_REQ("rawquery")
        merge h=REQ("hdr")
        set body=$get(REQ("body"))
        if body'="" set h("content-length")=$length(body)
        set out=method_" "_target_" HTTP/"_ver_crlf,hn=""
        for  do  quit:hn=""
        . set hn=$order(h(hn))
        . if hn'="" set out=out_hn_": "_h(hn)_crlf
        quit out_crlf_body
        ;
hdr(MSG,name)   ; Case-insensitive header lookup over MSG("hdr",…).
        ; doc: @param MSG     array   by-ref REQ or RSP carrying an "hdr" subtree
        ; doc: @param name    string  header name (any casing)
        ; doc: @returns       string  the header value, or "" if absent
        ; doc: @example       set msg("hdr","Content-Type")="text/html" do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.msg,"content-type"),"text/html","hdr case-insensitive")
        ; doc: @example       set msg("hdr","Host")="h" do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.msg,"x-missing"),"","hdr absent returns empty")
        ; doc: @since         v0.10.0
        ; doc: @stable        stable
        ; doc: @seam          STDHTTPMSG
        new k,want
        set want=$$toLowerASCII^STDSTR(name),k=""
        for  set k=$order(MSG("hdr",k)) quit:(k="")!($$toLowerASCII^STDSTR(k)=want)
        quit $select(k="":"",1:MSG("hdr",k))
        ;
        ; ---------- internal helpers ----------
        ;
caps(opts,cap) ; Resolve injected size caps with safe defaults.
        ; doc: @internal
        set cap("maxline")=$get(opts("maxline"),8192)
        set cap("maxhdrcount")=$get(opts("maxhdrcount"),100)
        set cap("maxhdrbytes")=$get(opts("maxhdrbytes"),16384)
        set cap("maxbody")=$get(opts("maxbody"),1048576)
        quit
        ;
parseQuery(qs,REQ)      ; Split a raw query string into REQ("query",name) (last-wins) + list.
        ; doc: @internal
        ; doc: D2: last value wins for the scalar; every occurrence is also kept
        ; doc: under REQ("query",name,1..N) in arrival order. Values percent-decoded.
        new i,n,kv,k,v,cnt
        set n=$length(qs,"&")
        for i=1:1:n do
        . set kv=$piece(qs,"&",i)
        . if kv="" quit
        . set k=$$decode^STDURL($piece(kv,"=",1))
        . set v=$$decode^STDURL($piece(kv,"=",2,$length(kv,"=")))
        . set cnt(k)=$get(cnt(k))+1
        . set REQ("query",k)=v,REQ("query",k,cnt(k))=v
        quit
        ;
setKeepalive(ver,conn,MSG)      ; Set MSG("keepalive") from version + Connection header.
        ; doc: @internal
        ; doc: HTTP/1.1 defaults keep-alive (unless "close"); HTTP/1.0 defaults
        ; doc: close (unless "keep-alive").
        new c
        set c=$$toLowerASCII^STDSTR(conn)
        if ver="1.1" set MSG("keepalive")=$select(c["close":0,1:1)
        if ver'="1.1" set MSG("keepalive")=$select(c["keep-alive":1,1:0)
        quit
        ;
dechunk(buf,maxbody,drc)        ; De-chunk a Transfer-Encoding: chunked body.
        ; doc: @internal
        ; doc: Returns the assembled body; sets drc to 200 (ok), 400 (malformed),
        ; doc: or 413 (assembled size over maxbody).
        new crlf,out,pos,nl,hexln,sz,chunk
        set crlf=$char(13,10),out="",pos=1,drc=200,sz=-1
        for  do  quit:(drc'=200)!(sz=0)
        . set nl=$find(buf,crlf,pos)
        . if 'nl set drc=400 quit
        . set hexln=$piece($extract(buf,pos,nl-3),";",1)
        . if '$$ishex(hexln) set drc=400 quit
        . set sz=$$hex2int(hexln)
        . if sz=0 quit
        . if ($length(out)+sz)>maxbody set drc=413 quit
        . set chunk=$extract(buf,nl,nl+sz-1)
        . if $length(chunk)<sz set drc=400 quit
        . set out=out_chunk,pos=nl+sz+2
        quit out
        ;
ishex(s)        ; True iff s is a non-empty run of hex digits.
        ; doc: @internal
        new i,u,ok
        if s="" quit 0
        set u=$$toUpperASCII^STDSTR(s),ok=1
        for i=1:1:$length(u) do
        . if "0123456789ABCDEF"'[$extract(u,i) set ok=0
        quit ok
        ;
hex2int(s)      ; Parse a hex string into an integer (caller has verified $$ishex).
        ; doc: @internal
        new i,u,n
        set u=$$toUpperASCII^STDSTR(s),n=0
        for i=1:1:$length(u) set n=(n*16)+($find("0123456789ABCDEF",$extract(u,i))-2)
        quit n
        ;
reason(status)  ; Standard reason phrase for an HTTP status code.
        ; doc: @internal
        ; doc: Split across $select groups to stay within the line-length and
        ; doc: commands-per-line house limits; unknown codes map to "Status".
        new r
        set r=$select(status=200:"OK",status=201:"Created",status=202:"Accepted",status=204:"No Content",1:"")
        if r="" set r=$select(status=301:"Moved Permanently",status=302:"Found",status=304:"Not Modified",1:"")
        if r="" set r=$select(status=400:"Bad Request",status=401:"Unauthorized",status=403:"Forbidden",status=404:"Not Found",1:"")
        if r="" set r=$select(status=405:"Method Not Allowed",status=409:"Conflict",1:"")
        if r="" set r=$select(status=413:"Payload Too Large",status=414:"URI Too Long",status=415:"Unsupported Media Type",1:"")
        if r="" set r=$select(status=429:"Too Many Requests",status=431:"Request Header Fields Too Large",1:"")
        if r="" set r=$select(status=500:"Internal Server Error",status=501:"Not Implemented",status=503:"Service Unavailable",1:"Status")
        quit r
