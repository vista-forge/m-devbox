STDMOCK ; m-stdlib — opt-in test-time call interception (mock registry).
        ; doc: @tag v0.1.2
        ; doc: @phase Phase 1b
        ;
        ; Three procedure-form labels:
        ;   register^STDMOCK(target,replacement)  — record a redirect
        ;   unregister^STDMOCK(target)            — remove one redirect
        ;   clear^STDMOCK                         — wipe every registration
        ;
        ; Three extrinsics:
        ;   $$resolve^STDMOCK(target)             — replacement, or target
        ;   $$called^STDMOCK(target)              — call count since clear
        ;   $$args^STDMOCK(target,n,i)            — arg i of call n
        ;
        ; And one procedure that exercises the redirect + records the call:
        ;   invoke^STDMOCK(target,.args)          — record + call resolve(target)
        ;
        ; Mechanism — opt-in at the call site. Production code that wants
        ; to be mockable calls invoke^STDMOCK("LBL^ROU",.args) instead of
        ; do ^LBL^ROU(.args), or uses do @$$resolve^STDMOCK("LBL^ROU")(.args)
        ; for the same effect without recording. Tests register a stub and
        ; the indirection picks it up.
        ;
        ; Storage — process-scoped (no cross-process leakage):
        ;   ^STDLIB($job,"stdmock","reg",target)        = replacement
        ;   ^STDLIB($job,"stdmock","cnt",target)        = call count
        ;   ^STDLIB($job,"stdmock","arg",target,n,i)    = arg i of call n
        ;
        ; Note on transactions: the registry lives in a transactional
        ; global, so a TROLLBACK reverts mock registrations. v0.1.2 does
        ; not provide rollback-immune mocks. The m-cli runner clears the
        ; registry between tests so cross-test leakage is also a non-issue.
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
register(target,replacement)    ; Record a target -> replacement redirect.
        ; doc: @param target       string  M call-site to intercept (e.g. "EN^FOO")
        ; doc: @param replacement  string  M call-site to invoke instead
        ; doc: @example            do clear^STDMOCK do register^STDMOCK("EN^FOO","stub^FOOTST") do eq^STDASSERT(.pass,.fail,$$resolve^STDMOCK("EN^FOO"),"stub^FOOTST","register redirects resolve")
        ; doc: @since              v0.1.2
        ; doc: @stable             stable
        ; doc: @see                do unregister^STDMOCK, $$resolve^STDMOCK, do invoke^STDMOCK
        ; doc: Overwrites any prior registration for target.
        set ^STDLIB($job,"stdmock","reg",target)=replacement
        quit
        ;
unregister(target)      ; Remove one redirect (idempotent).
        ; doc: @param target  string  M call-site previously register()ed
        ; doc: @example       do clear^STDMOCK do register^STDMOCK("EN^FOO","stub^FOOTST") do unregister^STDMOCK("EN^FOO") do eq^STDASSERT(.pass,.fail,$$resolve^STDMOCK("EN^FOO"),"EN^FOO","unregister reverts to passthrough")
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           do register^STDMOCK, do clear^STDMOCK
        ; doc: Drops the call count and recorded args for that target so a
        ; doc: subsequent re-register starts fresh.
        kill ^STDLIB($job,"stdmock","reg",target)
        kill ^STDLIB($job,"stdmock","cnt",target)
        kill ^STDLIB($job,"stdmock","arg",target)
        quit
        ;
clear   ; Remove every redirect, counter, and recorded args list.
        ; doc: @example       do register^STDMOCK("EN^FOO","stub^FOOTST") do clear^STDMOCK do eq^STDASSERT(.pass,.fail,$$resolve^STDMOCK("EN^FOO"),"EN^FOO","clear wipes all registrations")
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           do unregister^STDMOCK
        ; doc: Idempotent. The m-cli test runner calls this between tests
        ; doc: so registrations don't leak across cases.
        kill ^STDLIB($job,"stdmock")
        quit
        ;
resolve(target) ; Return the replacement if registered, else target itself.
        ; doc: @param target  string  M call-site
        ; doc: @returns       string  registered replacement; target itself if no registration
        ; doc: @example       do clear^STDMOCK do register^STDMOCK("EN^FOO","stub^FOOTST") do eq^STDASSERT(.pass,.fail,$$resolve^STDMOCK("EN^FOO"),"stub^FOOTST","resolve returns the registered replacement")
        ; doc: @example       write $$resolve^STDMOCK("noSuchTarget^XYZ")  ; "noSuchTarget^XYZ"
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           do register^STDMOCK, do invoke^STDMOCK
        ; doc: Single-level lookup; chains are NOT followed.
        quit $get(^STDLIB($job,"stdmock","reg",target),target)
        ;
invoke(target,args)     ; Record this call + invoke resolve(target).
        ; doc: @param target  string  M call-site
        ; doc: @param args    array   by-ref local; passed verbatim to the resolved target
        ; doc: @example       do clear^STDMOCK do register^STDMOCK("LBL^ROU","start^STDASSERT") new a set a(1)=42 do invoke^STDMOCK("LBL^ROU",.a) do eq^STDASSERT(.pass,.fail,$$args^STDMOCK("LBL^ROU",1,1),42,"invoke records the call args")
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           $$resolve^STDMOCK, $$called^STDMOCK, $$args^STDMOCK
        ; doc: Records the call (count + arg copy) before calling.
        new resolved,callN,key
        set resolved=$$resolve(target)
        set callN=$increment(^STDLIB($job,"stdmock","cnt",target))
        set key=""
        for  set key=$order(args(key)) quit:key=""  do
        . set ^STDLIB($job,"stdmock","arg",target,callN,key)=args(key)
        ; Dispatch via a built xecute, not `do @resolved@(.args)` argument
        ; indirection — IRIS ObjectScript has no argument indirection (it won't
        ; compile it). The xecute hides the call from both compilers; by-ref `.args`
        ; survives because xecute shares the frame. (Same idiom as parseFile^STDCSV.)
        ; m-lint: disable-next-line=M-MOD-036
        xecute "do "_resolved_"(.args)"
        quit
        ;
called(target)  ; Number of invocations for target since clear / unregister.
        ; doc: @param target  string  M call-site
        ; doc: @returns       int     invocation count; 0 if never invoked
        ; doc: @example       do clear^STDMOCK do register^STDMOCK("LBL^ROU","start^STDASSERT") new a do invoke^STDMOCK("LBL^ROU",.a) do invoke^STDMOCK("LBL^ROU",.a) do eq^STDASSERT(.pass,.fail,$$called^STDMOCK("LBL^ROU"),2,"called counts invocations")
        ; doc: @example       write $$called^STDMOCK("noSuchTarget^XYZ")  ; 0
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           do invoke^STDMOCK, $$args^STDMOCK
        quit $get(^STDLIB($job,"stdmock","cnt",target),0)
        ;
args(target,n,i)        ; Return arg i of call n for target; "" if absent.
        ; doc: @param target  string  M call-site
        ; doc: @param n       int     1-based call number
        ; doc: @param i       int     1-based argument position
        ; doc: @returns       string  recorded arg value; "" if absent
        ; doc: @example       do clear^STDMOCK do register^STDMOCK("LBL^ROU","start^STDASSERT") new a set a(1)="x",a(2)="y" do invoke^STDMOCK("LBL^ROU",.a) do eq^STDASSERT(.pass,.fail,$$args^STDMOCK("LBL^ROU",1,2),"y","args returns the recorded argument")
        ; doc: @example       write $$args^STDMOCK("noSuchTarget^XYZ",9,9)  ; ""
        ; doc: @since         v0.1.2
        ; doc: @stable        stable
        ; doc: @see           $$called^STDMOCK, do invoke^STDMOCK
        quit $get(^STDLIB($job,"stdmock","arg",target,n,i),"")
