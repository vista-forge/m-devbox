STDS3   ; m-stdlib — AWS S3 REST client (PutObject / GetObject / List / multipart).
        ; doc: @tag v0.14.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ; doc: @tier optional
        ;
        ; A thin, portable reimplementation of the S3 REST slice an SDK (boto3)
        ; would otherwise generate: build the request, sign it with STDSIGV4,
        ; hand the bytes to STDHTTP. Every entry point takes an explicit
        ; credential context `ctx` (accessKey/secretKey/region/service, plus an
        ; optional sessionToken) by reference — no ambient config — and returns
        ; an integer HTTP status (0 on transport failure, mirroring STDHTTP).
        ;
        ; Addressing: virtual-hosted-style (<bucket>.s3.<region>.amazonaws.com)
        ; by default; an opt("endpoint") override switches to path-style
        ; (<endpoint>/<bucket>/<key>), which is what MinIO / LocalStack and any
        ; S3-compatible store want — the no-code-change hook the testbed rides on.
        ;
        ; Public extrinsics:
        ;   $$putObject^STDS3(ctx,bucket,key,body,opt,resp)
        ;   $$getObject^STDS3(ctx,bucket,key,opt,resp)
        ;   $$headObject^STDS3(ctx,bucket,key,opt,resp)
        ;   $$listObjectsV2^STDS3(ctx,bucket,prefix,opt,listing)
        ;   $$deleteObject^STDS3(ctx,bucket,key,opt)
        ;   $$createMultipart^STDS3(ctx,bucket,key,opt)   — returns uploadId
        ;   $$uploadPart^STDS3(ctx,bucket,key,uploadId,partNo,body,opt,resp)
        ;   $$completeMultipart^STDS3(ctx,bucket,key,uploadId,parts,opt)
        ;   $$abortMultipart^STDS3(ctx,bucket,key,uploadId,opt)
        ; Every op takes `opt` (carrying opt("endpoint")); the endpoint override
        ; reaches buildRequest on ALL ops, not just putObject (so MinIO/LocalStack
        ; round-trips work, not just PUT).
        quit
        ;
        ; ---------- public API: object operations ----------
        ;
putObject(ctx,bucket,key,body,opt,resp) ; PUT an object; returns HTTP status (200 on success).
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param body    byte-string  object bytes
        ; doc: @param opt     array   options (contentType/sse/endpoint/…), by reference
        ; doc: @param resp    array   OUT — resp("header",*)/("error",*), by reference
        ; doc: @returns       int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 PUT over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$getObject^STDS3, $$buildRequest^STDS3
        new req,sc
        do buildRequest(.ctx,"PUT",bucket,key,"",$get(body),.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        if (sc'=200)&(sc'=0) do parseError($get(resp("body")),.resp)
        quit sc
        ;
getObject(ctx,bucket,key,opt,resp)  ; GET an object; resp("body") holds the bytes on 200.
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param opt     array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @param resp    array   OUT — resp("body")/("header",*), by reference
        ; doc: @returns       int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 GET over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$putObject^STDS3
        new req,sc
        do buildRequest(.ctx,"GET",bucket,key,"","",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        if (sc'=200)&(sc'=0) do parseError($get(resp("body")),.resp)
        quit sc
        ;
headObject(ctx,bucket,key,opt,resp) ; HEAD an object; resp("header",*) holds size/etag/metadata.
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param opt     array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @param resp    array   OUT — resp("header",*), by reference
        ; doc: @returns       int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 HEAD over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$getObject^STDS3
        new req,sc
        do buildRequest(.ctx,"HEAD",bucket,key,"","",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        quit sc
        ;
deleteObject(ctx,bucket,key,opt)    ; DELETE an object; returns HTTP status (204 on success).
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param opt     array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @returns       int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 DELETE over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$putObject^STDS3
        new req,resp,sc
        do buildRequest(.ctx,"DELETE",bucket,key,"","",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        quit sc
        ;
listObjectsV2(ctx,bucket,prefix,opt,listing)        ; List objects (V2); listing(n,"key"/"size"/"etag") + ("truncated"/"next").
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param prefix  string  key prefix filter ("" for all)
        ; doc: @param opt     array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @param listing array   OUT — listing(n,…)/("truncated")/("next"), by reference
        ; doc: @returns       int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 ListObjectsV2 over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$getObject^STDS3
        new req,resp,sc,q,query,cnt
        set q("list-type")=2
        if $get(prefix)'="" set q("prefix")=prefix
        set query=$$encQuery^STDSIGV4(.q)
        do buildRequest(.ctx,"GET",bucket,"",query,"",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        ; parseList is an extrinsic (quit n) — invoke via $$, not DO, or YDB
        ; raises %YDB-E-NOTEXTRINSIC (an argumented QUIT in DO context). The
        ; count is unused here; .listing is populated by reference.
        if sc=200 set cnt=$$parseList($get(resp("body")),.listing)
        if (sc'=200)&(sc'=0) do parseError($get(resp("body")),.resp)
        quit sc
        ;
        ; ---------- public API: multipart upload ----------
        ;
createMultipart(ctx,bucket,key,opt)     ; Initiate a multipart upload; returns the UploadId ("" on error).
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param opt     array   options (contentType/sse/endpoint/…), by reference
        ; doc: @returns       string  UploadId; "" on error
        ; doc: @illustrative  initiates a live S3 multipart upload over the network (needs credentials + a reachable endpoint)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$uploadPart^STDS3, $$completeMultipart^STDS3
        new req,resp,sc,tree
        do buildRequest(.ctx,"POST",bucket,key,"uploads=","",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        if sc'=200 quit ""
        if '$$parse^STDXML($get(resp("body")),.tree) quit ""
        quit $$xpathText^STDXML(.tree,"//UploadId")
        ;
uploadPart(ctx,bucket,key,uploadId,partNo,body,opt,resp)    ; Upload one part; resp("header","etag") carries the part ETag.
        ; doc: @param ctx       array   credential context, by reference
        ; doc: @param bucket    string  bucket name
        ; doc: @param key       string  object key
        ; doc: @param uploadId  string  the UploadId from createMultipart
        ; doc: @param partNo    int     part number (1-based)
        ; doc: @param body      byte-string  part bytes
        ; doc: @param opt       array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @param resp      array   OUT — resp("header","etag"), by reference
        ; doc: @returns         int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 UploadPart over the network (needs credentials + an active uploadId)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$createMultipart^STDS3, $$completeMultipart^STDS3
        new req,sc,q,query
        set q("partNumber")=partNo,q("uploadId")=uploadId
        set query=$$encQuery^STDSIGV4(.q)
        do buildRequest(.ctx,"PUT",bucket,key,query,$get(body),.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        quit sc
        ;
completeMultipart(ctx,bucket,key,uploadId,parts,opt)        ; Finalize a multipart upload from parts(partNo)=etag.
        ; doc: @param ctx       array   credential context, by reference
        ; doc: @param bucket    string  bucket name
        ; doc: @param key       string  object key
        ; doc: @param uploadId  string  the UploadId
        ; doc: @param parts     array   parts(partNo)=etag, by reference
        ; doc: @param opt       array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @returns         int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 CompleteMultipartUpload over the network (needs credentials + an active uploadId)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$uploadPart^STDS3
        new req,resp,sc,q,query,body,i
        set q("uploadId")=uploadId
        set query=$$encQuery^STDSIGV4(.q)
        set body="<CompleteMultipartUpload>",i=""
        for  set i=$order(parts(i)) quit:i=""  do
        . set body=body_"<Part><PartNumber>"_i_"</PartNumber><ETag>"_parts(i)_"</ETag></Part>"
        set body=body_"</CompleteMultipartUpload>"
        set opt("contentType")="application/xml"
        do buildRequest(.ctx,"POST",bucket,key,query,body,.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        quit sc
        ;
abortMultipart(ctx,bucket,key,uploadId,opt) ; Abort a multipart upload; returns HTTP status (204 on success).
        ; doc: @param ctx       array   credential context, by reference
        ; doc: @param bucket    string  bucket name
        ; doc: @param key       string  object key
        ; doc: @param uploadId  string  the UploadId
        ; doc: @param opt       array   options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
        ; doc: @returns         int     HTTP status; 0 on transport failure
        ; doc: @illustrative  performs a live S3 AbortMultipartUpload over the network (needs credentials + an active uploadId)
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$createMultipart^STDS3
        new req,resp,sc,q,query
        set q("uploadId")=uploadId
        set query=$$encQuery^STDSIGV4(.q)
        do buildRequest(.ctx,"DELETE",bucket,key,query,"",.opt,.req,.resp)
        set sc=$$request^STDHTTP(.req,.resp)
        quit sc
        ;
        ; ---------- request assembly (testable without a network) ----------
        ;
host(ctx,bucket,opt)    ; The Host header value: endpoint override host, else virtual-hosted.
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param opt     array   options (may carry "endpoint"), by reference
        ; doc: @returns       string  host[:port]
        ; doc: @example       new ctx set ctx("region")="us-east-1" do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"mybucket"),"mybucket.s3.us-east-1.amazonaws.com","host: virtual-hosted")
        ; doc: @example       new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"mybucket",.opt),"localhost:9000","host: endpoint override")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$url^STDS3
        new ep
        set ep=$get(opt("endpoint"))
        if ep'="" quit $$hostOf(ep)
        quit bucket_".s3."_ctx("region")_".amazonaws.com"
        ;
url(ctx,bucket,key,query,opt)   ; The full request URL (virtual-hosted, or path-style under an endpoint override).
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key ("" for bucket-level ops)
        ; doc: @param query   string  canonical query string ("" if none)
        ; doc: @param opt     array   options (may carry "endpoint"), by reference
        ; doc: @returns       string  the request URL
        ; doc: @example       new ctx set ctx("region")="us-east-1" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","k.txt"),"https://b.s3.us-east-1.amazonaws.com/k.txt","url: virtual-hosted")
        ; doc: @example       new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","k.txt","",.opt),"http://localhost:9000/b/k.txt","url: path-style endpoint")
        ; doc: @example       new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","","list-type=2",.opt),"http://localhost:9000/b/?list-type=2","url: with query")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$host^STDS3, $$canonUri^STDS3
        new ep,q
        set q=$select($get(query)="":"",1:"?"_query)
        set ep=$get(opt("endpoint"))
        if ep'="" quit ep_"/"_bucket_"/"_$$encPath^STDSIGV4(key)_q
        quit "https://"_$$host(.ctx,bucket,.opt)_"/"_$$encPath^STDSIGV4(key)_q
        ;
canonUri(ctx,bucket,key,opt)    ; The canonical URI for signing (path-style prefixes the bucket).
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param opt     array   options (may carry "endpoint"), by reference
        ; doc: @returns       string  canonical URI (leading "/")
        ; doc: @example       new ctx do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"b","dir/k.txt"),"/dir/k.txt","canonUri: virtual-hosted")
        ; doc: @example       new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"b","k.txt",.opt),"/b/k.txt","canonUri: path-style")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$url^STDS3
        if $get(opt("endpoint"))'="" quit "/"_bucket_"/"_$$encPath^STDSIGV4(key)
        quit "/"_$$encPath^STDSIGV4(key)
        ;
buildRequest(ctx,method,bucket,key,query,body,opt,req,resp)     ; Assemble a signed STDHTTP request array for an S3 operation.
        ; doc: @param ctx     array   credential context, by reference
        ; doc: @param method  string  HTTP method
        ; doc: @param bucket  string  bucket name
        ; doc: @param key     string  object key
        ; doc: @param query   string  canonical query string ("" if none)
        ; doc: @param body    byte-string  request body ("" if none)
        ; doc: @param opt     array   options (contentType/sse/endpoint/amzdate/timeoutMs/meta/…), by reference
        ; doc: @param req     array   OUT — STDHTTP request array, by reference
        ; doc: @param resp    array   OUT — cleared for the response, by reference
        ; doc: @illustrative  signs the request via $$authHeader^STDSIGV4 (HMAC chain through the STDCRYPTO call-out), unavailable in the core test engine
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$request^STDHTTP, $$authHeader^STDSIGV4
        ; doc: opt("amzdate") pins the timestamp for deterministic tests; in
        ; doc: production it is left unset and $$amzDate^STDSIGV4 supplies it.
        new uri,amz,ds,ph,h,auth,mname
        set uri=$$canonUri(.ctx,bucket,key,.opt)
        set amz=$get(opt("amzdate")) if amz="" set amz=$$amzDate^STDSIGV4()
        set ds=$extract(amz,1,8)
        set ph=$select($get(body)="":$$emptyHash^STDSIGV4(),1:$$sha256^STDCRYPTO(body))
        set h("host")=$$host(.ctx,bucket,.opt)
        set h("x-amz-date")=amz,h("x-amz-content-sha256")=ph
        if $get(opt("contentType"))'="" set h("content-type")=opt("contentType")
        if $get(opt("sse"))'="" set h("x-amz-server-side-encryption")=opt("sse")
        if $get(opt("sseKmsKeyId"))'="" set h("x-amz-server-side-encryption-aws-kms-key-id")=opt("sseKmsKeyId")
        if $get(opt("storageClass"))'="" set h("x-amz-storage-class")=opt("storageClass")
        if $get(opt("acl"))'="" set h("x-amz-acl")=opt("acl")
        if $get(ctx("sessionToken"))'="" set h("x-amz-security-token")=ctx("sessionToken")
        set mname=""
        for  set mname=$order(opt("meta",mname)) quit:mname=""  set h("x-amz-meta-"_mname)=opt("meta",mname)
        set auth=$$authHeader^STDSIGV4(.ctx,method,uri,$get(query),.h,ph,amz,ds)
        kill resp
        set req("method")=method,req("url")=$$url(.ctx,bucket,key,$get(query),.opt)
        if $get(body)'="" set req("body")=body
        merge req("header")=h
        ; Host is SIGNED (SigV4 requires it) but never sent explicitly: both
        ; libcurl (YDB) and %Net.HttpRequest (IRIS) derive Host from the URL,
        ; and IRIS's client errors out if a Host header is set by hand.
        kill req("header","host")
        set req("header","Authorization")=auth
        if $get(opt("timeoutMs"))'="" set req("timeout")=opt("timeoutMs")/1000
        quit
        ;
        ; ---------- response parsing ----------
        ;
parseError(xml,resp)    ; Parse an S3 error body into resp("error","code"/"message").
        ; doc: @param xml     string  S3 error XML body
        ; doc: @param resp    array   OUT — resp("error",*), by reference
        ; doc: @example       new resp do parseError^STDS3("<Error><Code>NoSuchKey</Code><Message>The key does not exist</Message></Error>",.resp) do eq^STDASSERT(.pass,.fail,resp("error","code"),"NoSuchKey","parseError: error code")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$putObject^STDS3
        new tree
        if $get(xml)="" quit
        if '$$parse^STDXML(xml,.tree) quit
        set resp("error","code")=$$xpathText^STDXML(.tree,"//Code")
        set resp("error","message")=$$xpathText^STDXML(.tree,"//Message")
        quit
        ;
parseList(xml,listing)  ; Parse a ListBucketResult into listing(n,…) + pagination; returns the count.
        ; doc: @param xml     string  ListObjectsV2 XML body
        ; doc: @param listing array   OUT — listing(n,"key"/"size"/"etag")/("truncated")/("next")
        ; doc: @returns       int     number of Contents entries
        ; doc: @example       new listing,n set n=$$parseList^STDS3("<ListBucketResult><Contents><Key>a.txt</Key><Size>5</Size><ETag>e1</ETag></Contents><IsTruncated>false</IsTruncated></ListBucketResult>",.listing) do eq^STDASSERT(.pass,.fail,n_"|"_listing(1,"key"),"1|a.txt","parseList: count + first key")
        ; doc: @since         v0.14.0
        ; doc: @stable        stable
        ; doc: @see           $$listObjectsV2^STDS3
        new tree,keys,sizes,etags,n,i
        kill listing
        if $get(xml)="" quit 0
        if '$$parse^STDXML(xml,.tree) quit 0
        set n=$$xpath^STDXML(.tree,"//Contents/Key",.keys)
        do  ; size + etag run in parallel (document order)
        . new ns,ne set ns=$$xpath^STDXML(.tree,"//Contents/Size",.sizes),ne=$$xpath^STDXML(.tree,"//Contents/ETag",.etags)
        for i=1:1:n do
        . set listing(i,"key")=$get(keys(i,"text"))
        . set listing(i,"size")=$get(sizes(i,"text"))
        . set listing(i,"etag")=$get(etags(i,"text"))
        set listing("truncated")=$$xpathText^STDXML(.tree,"//IsTruncated")
        set listing("next")=$$xpathText^STDXML(.tree,"//NextContinuationToken")
        quit n
        ;
        ; ---------- private ----------
        ;
hostOf(ep)      ; Extract host[:port] from an endpoint URL (strip scheme + any path).
        ; doc: @internal
        new h
        set h=ep
        if h["://" set h=$piece(h,"://",2,999)
        quit $piece(h,"/",1)
        ;
