STDSEED ; m-stdlib — declarative test data loader (v0.1.3).
        ; doc: @tag v0.1.3
        ; doc: @phase Phase 1b
        ;
        ; Public API:
        ;   load^STDSEED(path,filer)         ; load TSV manifest via `filer`
        ;   $$loaded^STDSEED(path)           ; 1 iff path is currently tracked
        ;   clear^STDSEED(path)              ; drop bookkeeping for path
        ;   $$validate^STDSEED(path)         ; 1 if manifest parses; raises on syntax
        ;   loadJson^STDSEED(jsonText,filer) ; load JSON-array manifest via `filer`
        ;                                      (each element: {"file":..,"fields":{..}})
        ;
        ; Manifest format (TSV, one row per record):
        ;   <file>\t<field>=<value>\t<field>=<value>...
        ; Lines beginning with '#' are comments. Whitespace-only lines skip.
        ;
        ; Filer hook: the `filer` argument is REQUIRED — a "tag^routine"
        ; reference invoked once per row as
        ;   do @filer@(file,.fda,.iens)
        ; with fda(file,"+1,",field)=value and `iens` an output IEN. STDSEED is
        ; engine-neutral (m layer, the m/v waterline) and ships no FileMan
        ; default; a missing filer raises U-STDSEED-NO-FILER. A VistA caller
        ; injects a FileMan-backed filer from the v layer (v-stdlib).
        ;
        ; State per loaded path lives under ^STDLIB($job,"stdseed",path,...).
        ; clear() drops it. STDSEED does NOT open its own transaction;
        ; callers wanting rollback semantics wrap in STDFIX (v0.1.1+).
        ;
        ; Errors set $ECODE to one of:
        ;   ,U-STDSEED-NO-FILER,
        ;   ,U-STDSEED-FILE-NOT-FOUND,
        ;   ,U-STDSEED-MISSING-FILE,
        ;   ,U-STDSEED-MISSING-FIELD,
        ;   ,U-STDSEED-FILER-ERROR,
        ;   ,U-STDSEED-INVALID-JSON,
        ;   ,U-STDSEED-INVALID-MANIFEST,
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
load(path,filer)        ; Load manifest at `path` via the required `filer`.
        ; doc: @param path    string  filesystem path to a TSV manifest
        ; doc: @param filer   string  REQUIRED M call-site "label^routine" filer
        ; doc: @raises        U-STDSEED-NO-FILER        filer argument was empty
        ; doc: @raises        U-STDSEED-FILE-NOT-FOUND  could not open `path`
        ; doc: @raises        U-STDSEED-MISSING-FILE    a row's first TSV column is empty
        ; doc: @raises        U-STDSEED-MISSING-FIELD   a non-empty TSV piece does not contain "="
        ; doc: @raises        U-STDSEED-FILER-ERROR     filer raised; propagated as a STDSEED code
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do load^STDSEED(""/tmp/x.tsv"","""")","U-STDSEED-NO-FILER","empty filer raises")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do load^STDSEED(""/no/such/manifest.tsv"",""f^R"")","U-STDSEED-FILE-NOT-FOUND","missing manifest raises (filer never reached)")
        ; doc: @example       do writeFile^STDFS("/tmp/stdseed-doc-nofile.tsv",$char(9)_".01=Smith") do raises^STDASSERT(.pass,.fail,"do load^STDSEED(""/tmp/stdseed-doc-nofile.tsv"",""f^R"")","U-STDSEED-MISSING-FILE","a row whose first TSV column is empty raises")
        ; doc: @example       do writeFile^STDFS("/tmp/stdseed-doc-badfield.tsv","2"_$char(9)_"nofieldsep") do raises^STDASSERT(.pass,.fail,"do load^STDSEED(""/tmp/stdseed-doc-badfield.tsv"",""f^R"")","U-STDSEED-MISSING-FIELD","a TSV piece without = raises")
        ; doc: @raisesnodemo  U-STDSEED-FILER-ERROR  needs a soft-raising "tag^routine" filer label that sets $ecode and quits (the runtime ships none below the waterline); a hard error in the filer unwinds past the translation point, so the code cannot be triggered by a one-liner with only src staged — exercised by failingFiler^STDSEEDTST in STDSEEDTST.
        ; doc: @illustrative  the happy path needs a real "tag^routine" filer label (a VistA caller injects a FileMan-backed one); shown above is the required-filer guard
        ; doc: @since         v0.1.3
        ; doc: @stable        stable
        ; doc: @see           $$validate^STDSEED, do loadJson^STDSEED, do clear^STDSEED
        ; doc: Each parsed row is dispatched once. `filer` is required —
        ; doc: STDSEED is engine-neutral and ships no FileMan default.
        new f
        set f=$get(filer)
        if f="" set $ecode=",U-STDSEED-NO-FILER," quit
        do walk(path,f,1)
        quit
        ;
loaded(path)    ; Predicate — 1 iff `path` is currently loaded.
        ; doc: @param path    string  filesystem path
        ; doc: @returns       bool    1 iff `path` has been load()ed in this job; 0 otherwise
        ; doc: @example       write $$loaded^STDSEED("/tmp/never-loaded.tsv")  ; 0
        ; doc: @since         v0.1.3
        ; doc: @stable        stable
        ; doc: @see           do load^STDSEED, do clear^STDSEED
        quit $select($data(^STDLIB($job,"stdseed",path)):1,1:0)
        ;
clear(path)     ; Drop bookkeeping for `path`. Idempotent.
        ; doc: @param path    string  filesystem path of a previously-loaded manifest
        ; doc: @example       do clear^STDSEED("/tmp/never-loaded.tsv") do eq^STDASSERT(.pass,.fail,$$loaded^STDSEED("/tmp/never-loaded.tsv"),0,"clear is idempotent; loaded=0 after")
        ; doc: @since         v0.1.3
        ; doc: @stable        stable
        ; doc: @see           do load^STDSEED, do with^STDFIX
        ; doc: Best-effort — does not delete already-filed records (caller's
        ; doc: responsibility, typically via STDFIX rollback).
        kill ^STDLIB($job,"stdseed",path)
        quit
        ;
validate(path)  ; Parse-only check — return 1 on success; raise on syntax error.
        ; doc: @param path    string  filesystem path to a TSV manifest
        ; doc: @returns       bool    1 on success
        ; doc: @raises        U-STDSEED-FILE-NOT-FOUND  could not open `path`
        ; doc: @raises        U-STDSEED-MISSING-FILE    a row's first TSV column is empty
        ; doc: @raises        U-STDSEED-MISSING-FIELD   a non-empty TSV piece does not contain "="
        ; doc: @example       do writeFile^STDFS("/tmp/stdseed-doc.tsv","2"_$char(9)_".01=Smith") do eq^STDASSERT(.pass,.fail,$$validate^STDSEED("/tmp/stdseed-doc.tsv"),1,"a well-formed manifest validates")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$validate^STDSEED(""/no/such/manifest.tsv"")","U-STDSEED-FILE-NOT-FOUND","missing manifest raises")
        ; doc: @example       do writeFile^STDFS("/tmp/stdseed-nofile.tsv",$char(9)_".01=Smith") do raises^STDASSERT(.pass,.fail,"set x=$$validate^STDSEED(""/tmp/stdseed-nofile.tsv"")","U-STDSEED-MISSING-FILE","empty file column raises")
        ; doc: @example       do writeFile^STDFS("/tmp/stdseed-bad.tsv","2"_$char(9)_"nofieldsep") do raises^STDASSERT(.pass,.fail,"set x=$$validate^STDSEED(""/tmp/stdseed-bad.tsv"")","U-STDSEED-MISSING-FIELD","a piece without = raises")
        ; doc: @since         v0.1.3
        ; doc: @stable        stable
        ; doc: @see           do load^STDSEED
        ; doc: Never invokes the filer. Use as a pre-flight before load().
        do walk(path,"",0)
        quit 1
        ;
loadJson(jsonText,filer)        ; Load JSON-array manifest via the required `filer`.
        ; doc: @param jsonText  string  JSON array; each element {"file":..,"fields":{..}}
        ; doc: @param filer     string  REQUIRED M call-site "label^routine" filer
        ; doc: @raises          U-STDSEED-NO-FILER          filer argument was empty
        ; doc: @raises          U-STDSEED-INVALID-JSON      jsonText does not parse as JSON
        ; doc: @raises          U-STDSEED-INVALID-MANIFEST  parsed JSON is not an array of objects with "file"
        ; doc: @raises          U-STDSEED-MISSING-FILE      element lacks a "file" string member
        ; doc: @raises          U-STDSEED-FILER-ERROR       filer raised; propagated as a STDSEED code
        ; doc: @example         do raises^STDASSERT(.pass,.fail,"do loadJson^STDSEED(""[]"","""")","U-STDSEED-NO-FILER","empty filer raises")
        ; doc: @example         do raises^STDASSERT(.pass,.fail,"do loadJson^STDSEED(""not json"",""f^R"")","U-STDSEED-INVALID-JSON","unparseable JSON raises")
        ; doc: @example         do raises^STDASSERT(.pass,.fail,"do loadJson^STDSEED(""{""""a"""":1}"",""f^R"")","U-STDSEED-INVALID-MANIFEST","valid JSON that is not an array raises")
        ; doc: @example         do raises^STDASSERT(.pass,.fail,"do loadJson^STDSEED(""[{""""x"""":1}]"",""f^R"")","U-STDSEED-MISSING-FILE","an array element lacking a file member raises")
        ; doc: @raisesnodemo    U-STDSEED-FILER-ERROR  needs a soft-raising "tag^routine" filer label that sets $ecode and quits (the runtime ships none below the waterline); a hard error in the filer unwinds past the translation point, so the code cannot be triggered by a one-liner with only src staged — exercised by failingFiler^STDSEEDTST in STDSEEDTST.
        ; doc: @illustrative    the happy path needs a real "tag^routine" filer label (a VistA caller injects a FileMan-backed one); shown above are the input-guard raises
        ; doc: @since           v0.2.0
        ; doc: @stable          stable
        ; doc: @see             do load^STDSEED, $$parse^STDJSON
        new tree,ok,f
        set f=$get(filer)
        if f="" set $ecode=",U-STDSEED-NO-FILER," quit
        set ok=$$parse^STDJSON(jsonText,.tree)
        if 'ok set $ecode=",U-STDSEED-INVALID-JSON," quit
        if $extract(tree)'="a" set $ecode=",U-STDSEED-INVALID-MANIFEST," quit
        do walkJson(.tree,f)
        quit
        ;
        ; ---------- internal: manifest walk ----------
        ;
walk(path,filer,doFile) ; Read TSV at `path`; dispatch per non-blank/non-comment row.
        ; doc: @internal
        ; doc: load() and validate() share this; doFile=0 skips the filer
        ; doc: call and the bookkeeping write.
        new line,trimmed,lines,i,nlines
        ; Read engine-portably via STDFS (readLines strips trailing CR per line and
        ; closes the device before we dispatch — so a filer error can't fire while a
        ; non-principal SEQ device is current, the old ZGOTO-unwind hazard).
        if '$$exists^STDFS(path) set $ecode=",U-STDSEED-FILE-NOT-FOUND," quit
        do readLines^STDFS(path,.lines)
        if $ecode'="" set $ecode=",U-STDSEED-FILE-NOT-FOUND," quit
        set nlines=+$order(lines(""),-1)
        for i=1:1:nlines do  quit:$ecode'=""
        . set line=lines(i)
        . set trimmed=$$trim(line)
        . if trimmed="" quit
        . if $extract(trimmed,1)="#" quit
        . do processRow(path,line,filer,doFile)
        quit
        ;
processRow(path,line,filer,doFile)      ; Parse one TSV row; build FDA; dispatch.
        ; doc: @internal
        ; doc: Sets $ECODE on syntax errors. When doFile=0 only validates
        ; doc: the row's shape.
        new file,fda,col,piece,fname,fval,iens,seq
        set file=$piece(line,$char(9),1)
        if file="" set $ecode=",U-STDSEED-MISSING-FILE," quit
        for col=2:1:$length(line,$char(9)) do  quit:$ecode'=""
        . set piece=$piece(line,$char(9),col)
        . if piece="" quit
        . if piece'["=" set $ecode=",U-STDSEED-MISSING-FIELD," quit
        . set fname=$piece(piece,"=",1)
        . set fval=$piece(piece,"=",2,$length(piece,"="))
        . set fda(file,"+1,",fname)=fval
        if 'doFile quit
        do dispatch(path,file,.fda,filer)
        quit
        ;
dispatch(path,file,fda,filer)   ; Invoke `filer` and book-keep the result.
        ; doc: @internal
        ; doc: Wraps the filer call and translates any $ECODE the filer
        ; doc: raises into U-STDSEED-FILER-ERROR.
        new iens,seq
        ; Dispatch via a built xecute, not `do @filer@(...)` argument indirection —
        ; IRIS ObjectScript has no argument indirection. The xecute hides it from
        ; both compilers; by-ref `.fda`/`.iens` (the filer's output) survive because
        ; xecute shares the frame. (Same idiom as parseFile^STDCSV / invoke^STDMOCK.)
        ; m-lint: disable-next-line=M-MOD-036
        xecute "do "_filer_"(file,.fda,.iens)"
        if $ecode'="" set $ecode=",U-STDSEED-FILER-ERROR," quit
        set seq=$increment(^STDLIB($job,"stdseed",path,"seq"))
        set ^STDLIB($job,"stdseed",path,"row",seq,"file")=file
        set ^STDLIB($job,"stdseed",path,"row",seq,"iens")=$get(iens)
        quit
        ;
walkJson(tree,filer)    ; Iterate a parsed JSON array; dispatch each element.
        ; doc: @internal
        ; doc: tree is the root array node from $$parse^STDJSON.
        ; doc: Element shape: {"file":<string>,"fields":{<fname>:<scalar>,...}}
        new n,i,fileNode,file,fda,fname,fnode,c
        set n=0,i=$order(tree(""))
        for  quit:i=""  set n=n+1,i=$order(tree(i))
        for i=1:1:n do  quit:$ecode'=""
        . if $extract(tree(i))'="o" set $ecode=",U-STDSEED-INVALID-MANIFEST," quit
        . if '$data(tree(i,"file")) set $ecode=",U-STDSEED-MISSING-FILE," quit
        . set fileNode=tree(i,"file")
        . if $extract(fileNode)'="s" set $ecode=",U-STDSEED-INVALID-MANIFEST," quit
        . set file=$extract(fileNode,3,$length(fileNode))
        . kill fda
        . if $data(tree(i,"fields"))#10 do  quit:$ecode'=""
        . . if $extract(tree(i,"fields"))'="o" set $ecode=",U-STDSEED-INVALID-MANIFEST," quit
        . . set fname=$order(tree(i,"fields",""))
        . . for  quit:fname=""  do
        . . . set fnode=tree(i,"fields",fname)
        . . . set c=$extract(fnode)
        . . . if (c="s")!(c="n") set fda(file,"+1,",fname)=$extract(fnode,3,$length(fnode))
        . . . set fname=$order(tree(i,"fields",fname))
        . do dispatchJson(file,.fda,filer)
        quit
        ;
dispatchJson(file,fda,filer)    ; Invoke filer for one JSON element.
        ; doc: @internal
        ; doc: Relays filer $ECODE as U-STDSEED-FILER-ERROR.
        new iens
        ; xecute-built dispatch (IRIS has no argument indirection) — see dispatch().
        ; m-lint: disable-next-line=M-MOD-036
        xecute "do "_filer_"(file,.fda,.iens)"
        if $ecode'="" set $ecode=",U-STDSEED-FILER-ERROR," quit
        quit
        ;
        ; ---------- internal: helpers ----------
        ;
trim(s) ; Strip leading and trailing ASCII whitespace (space, tab, CR, LF).
        ; doc: @internal
        ; doc: TSV manifest hygiene.
        new ws,n,start,fin
        set ws=" "_$char(9)_$char(13)_$char(10)
        set n=$length(s)
        set start=1
        for  quit:start>n  quit:ws'[$extract(s,start)  set start=start+1
        set fin=n
        for  quit:fin<start  quit:ws'[$extract(s,fin)  set fin=fin-1
        quit $extract(s,start,fin)
