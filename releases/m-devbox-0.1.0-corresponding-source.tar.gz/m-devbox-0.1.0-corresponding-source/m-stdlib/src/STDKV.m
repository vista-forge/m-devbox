STDKV   ; m-stdlib — minimal keyed record-store seam (the S1 storage contract).
        ; doc: @tag v0.9.0
        ; doc: @phase Phase 5 — web stack + AWS S3 egress
        ;
        ; A portable record store: $$set/$$get/$$exists/$$kill address a value by
        ; (collection, key, field). It is the engine-neutral half of the MSL/VSL
        ; storage seam (S1) — v-stdlib's VSLFS binds this same four-verb signature
        ; to VistA's FileMan DBS (GETS^DIQ / UPDATE^DIE / …) above the waterline,
        ; mapping collection->file, key->iens, field->field number. On a bare
        ; engine STDKV is its own reference back end (a process-private global),
        ; so the seam is real and testable with no VistA present.
        ;
        ; This is a record store, NOT a filesystem — STDFS stays path/byte I/O.
        ; The contract is deliberately minimal: only the four verbs the storage
        ; acceptance needs. Any non-storage logic stays in the caller; the seam
        ; carries no parsing/formatting.
        ;
        ; Public extrinsics (all functions — call with $$, never `do`):
        ;   $$set^STDKV(coll,key,field,value)   — store a field value -> 1
        ;   $$get^STDKV(coll,key,field,default) — read a field value, else default
        ;   $$exists^STDKV(coll,key)            — 1 iff the record has any field
        ;   $$kill^STDKV(coll,key)              — remove a whole record -> 1
        ;
        ; Reference back end: per-process records live in
        ; ^STDLIB($job,"kv",coll,key,field)=value (process-private; no VistA, no
        ; cross-run bleed). The VSLFS adapter swaps this for FileMan; the
        ; signature is identical, so callers are unchanged across back ends.
        ;
        quit
        ;
        ; ---------- the storage seam (4 verbs) ----------
        ;
set(coll,key,field,value)       ; Store `value` at (coll,key,field); return 1.
        ; doc: @param   coll     string  collection id (VSLFS: a FileMan file number)
        ; doc: @param   key      string  record key (VSLFS: an IENS)
        ; doc: @param   field    string  field id within the record (VSLFS: a field number)
        ; doc: @param   value    string  the value to store (raw bytes; byte-faithful)
        ; doc: @returns          bool    1 on success
        ; doc: @example          write $$set^STDKV("demo.cfg",1,".01","hello")  ; 1
        ; doc: @since            v0.9.0
        ; doc: @stable           stable
        ; doc: @seam             STDKV
        ; doc: @see              $$get^STDKV, $$kill^STDKV
        set ^STDLIB($job,"kv",coll,key,field)=value
        quit 1
        ;
get(coll,key,field,default)     ; Read the value at (coll,key,field); else `default`.
        ; doc: @param   coll     string  collection id
        ; doc: @param   key      string  record key
        ; doc: @param   field    string  field id within the record
        ; doc: @param   default  string  value returned when the field is unset
        ; doc: @returns          string  the stored value, or `default` when unset
        ; doc: @example          new ok set ok=$$kill^STDKV("demo.cfg",1),ok=$$set^STDKV("demo.cfg",1,".01","hello") do eq^STDASSERT(.pass,.fail,$$get^STDKV("demo.cfg",1,".01","none"),"hello","get reads the stored value")
        ; doc: @example          new ok set ok=$$kill^STDKV("demo.cfg",1) do eq^STDASSERT(.pass,.fail,$$get^STDKV("demo.cfg",1,".01","none"),"none","get returns the default when unset")
        ; doc: @since            v0.9.0
        ; doc: @stable           stable
        ; doc: @seam             STDKV
        ; doc: @see              $$set^STDKV
        quit $get(^STDLIB($job,"kv",coll,key,field),default)
        ;
exists(coll,key)        ; Return 1 iff record (coll,key) has any field set; else 0.
        ; doc: @param   coll     string  collection id
        ; doc: @param   key      string  record key
        ; doc: @returns          bool    1 iff the record exists; 0 otherwise
        ; doc: @example          new ok set ok=$$kill^STDKV("demo.cfg",1),ok=$$set^STDKV("demo.cfg",1,".01","x") do eq^STDASSERT(.pass,.fail,$$exists^STDKV("demo.cfg",1),1,"a record with a field exists")
        ; doc: @example          new ok set ok=$$kill^STDKV("demo.cfg",1) do eq^STDASSERT(.pass,.fail,$$exists^STDKV("demo.cfg",1),0,"an absent record does not exist")
        ; doc: @since            v0.9.0
        ; doc: @stable           stable
        ; doc: @seam             STDKV
        ; doc: @see              $$kill^STDKV
        quit $select($data(^STDLIB($job,"kv",coll,key)):1,1:0)
        ;
kill(coll,key)  ; Remove the whole record (coll,key); return 1 (idempotent).
        ; doc: @param   coll     string  collection id
        ; doc: @param   key      string  record key
        ; doc: @returns          bool    1 (idempotent — absent record is a no-op)
        ; doc: @example          write $$kill^STDKV("demo.cfg",1)  ; 1
        ; doc: @since            v0.9.0
        ; doc: @stable           stable
        ; doc: @seam             STDKV
        ; doc: @see              $$set^STDKV, $$exists^STDKV
        kill ^STDLIB($job,"kv",coll,key)
        quit 1
