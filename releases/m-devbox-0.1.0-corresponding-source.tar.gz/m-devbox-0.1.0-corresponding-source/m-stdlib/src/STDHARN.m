STDHARN ; m-stdlib — resident test/coverage harness orchestrator (v0.0.1).
        ; doc: @tag v0.0.1
        ; doc: @phase Phase 1
        ; doc: @exrun ydb
        ;
        ; The server-side half of run-and-verify (m-cli spec §9, resident-harness
        ; -design §3): runs *TST suites IN the live namespace, next to the real
        ; FileMan DD + data, and emits a deterministic result FRAME the Go client
        ; splits back through the unchanged mtest/mcov consumers. Portable pure-M
        ; — the suite execution + framing run identically on YottaDB and IRIS, so
        ; the splitter and the cross-engine parity tests are exercisable file-side
        ; with no IRIS; only the ^%MONLBL coverage probe (STDCOV) and the watch
        ; hooks are IRIS-bound.
        ;
        ; The contract is the OUTPUT FRAME, not the transport (§3.2):
        ;   ##M-HARNESS frame=1 tier=integration engine=ydb ns=
        ;   ##SUITE ^MATHTST
        ;     <verbatim ^STDASSERT output — PASS/FAIL lines + Results: line>
        ;   ##END ^MATHTST exit=0
        ;   ##LCOV … (optional; STDCOV) …
        ;   ##END-HARNESS suites=1 pass=2 fail=0
        ; Per-suite payloads are verbatim ^STDASSERT text (mtest.ParseOutput
        ; consumes them unchanged); only the ## delimiter lines are new and they
        ; never collide with ^STDASSERT / LCOV content.
        ;
        ; Running many suites in ONE process means report^STDASSERT must not halt
        ; (it would kill the orchestrator). RUN flips STDASSERT into no-halt mode:
        ; report then stashes its counts and returns, and STDHARN reads them for
        ; the trailer. Each suite is crash-isolated (a mid-suite error becomes a
        ; non-zero ##END exit and the run continues), matching the file-side
        ; runner's per-process semantics where OK = summary.OK && exit==0.
        quit
        ;
RUN     ; Entry: run the suites named in $ZCMDLINE, emit the frame to the device.
        ; doc: Input rides $ZCMDLINE (space-separated suite routine names) — a
        ; doc: shell-entry special variable, not a formal parameter.
        ; doc: @illustrative     shell entry: ydb -run RUN^STDHARN "MATHTST STRTST"
        ; doc: @example          set $zcmdline="monStop^STDHARN" do capture^STDHARN(1) do RUN^STDHARN do capture^STDHARN(0) do contains^STDASSERT(.pass,.fail,$$captured^STDHARN(),"##M-HARNESS frame=1","RUN frames from $ZCMDLINE")
        ; doc: @since            v0.0.1
        ; doc: @stable           experimental
        ; doc: @see              do run^STDHARN
        ; doc: The CLI trigger path (m test --resident) invokes this via the
        ; doc: engine adapter; the host passes scope as $ZCMDLINE.
        do run($zcmdline)
        quit
        ;
run(scope)      ; Run each suite in scope (space-separated), emit the frame.
        ; doc: @param scope  string  space-separated suite routine names/entryrefs
        ; doc: @example       do capture^STDHARN(1) do run^STDHARN("monStop^STDHARN") do capture^STDHARN(0) do contains^STDASSERT(.pass,.fail,$$captured^STDHARN(),"##END-HARNESS suites=1 ","run() frames one suite")
        ; doc: @since         v0.0.1
        ; doc: @stable        experimental
        ; doc: @see           RUN^STDHARN
        ; doc: Emits the ##M-HARNESS header, one ##SUITE…##END block per suite,
        ; doc: then the ##END-HARNESS trailer (cross-check totals).
        do frame(scope,"")
        quit
        ;
cov(scope,routines)     ; Like run(), but wrap execution in the IRIS line monitor
        ; doc: @param scope     string  space-separated suite routine names
        ; doc: @param routines  string  space-separated production routines to cover
        ; doc: @example          do capture^STDHARN(1) do cov^STDHARN("monStop^STDHARN","STDHARN") do capture^STDHARN(0) do contains^STDASSERT(.pass,.fail,$$captured^STDHARN(),"##MON","cov() wraps a ##MON block")
        ; doc: @since            v0.0.1
        ; doc: @stable           experimental
        ; doc: @see              do run^STDHARN
        ; doc: and emit a ##MON block of raw per-line counts (IRIS ^%MONLBL). The
        ; doc: host joins them to its parse-tree executable lines via mcov — so the
        ; doc: executable-line denominator stays host-side and resident == file-side
        ; doc: coverage holds by construction. YDB coverage stays the host-side
        ; doc: view "TRACE" path, so the ##MON block is empty there.
        do frame(scope,routines)
        quit
        ;
frame(scope,routines)   ; Emit the result frame; monitor `routines` when non-empty.
        ; doc: @internal
        new i,name,np,nf,xc,tp,tf,n
        do emit($$header("integration"))
        set tp=0,tf=0,n=0
        if routines'="" do monStart(routines)
        for i=1:1:$length(scope," ") do
        . set name=$piece(scope," ",i)
        . if name="" quit
        . set n=n+1
        . do suite(name,.np,.nf,.xc)
        . set tp=tp+np,tf=tf+nf
        if routines'="" do monBlock(routines)
        do emit($$trailer(n,tp,tf))
        quit
        ;
monBlock(routines)      ; Emit the ##MON … ##END-MON raw monitor block, then stop.
        ; doc: @internal
        do emit("##MON")
        do monDump(routines)
        do emit("##END-MON")
        do monStop()
        quit
        ;
suite(name,np,nf,xc)    ; Run one suite, emit its ##SUITE…##END block.
        ; doc: @internal
        ; doc: Drives DO ^NAME in no-halt mode, crash-isolated: a mid-suite error
        ; doc: is trapped (YDB ZGOTO unwind / IRIS try-catch) and reported as a
        ; doc: non-zero exit so the orchestrator survives and frames the rest.
        new $etrap,lvl,ref,disp
        set np=0,nf=0,xc=0
        set disp=$piece(name,"^",1)
        set ref=$select(name["^":name,1:"^"_name)
        do emit($$suiteOpen(disp))
        do nohalt^STDASSERT(1)
        kill ^STDLIB($job,"harn","pass"),^STDLIB($job,"harn","fail")
        if $zversion["IRIS" do irisRun(ref,.xc) goto suiteDone
        set lvl=$zlevel
        set $etrap="use $principal set xc=1 set $ecode="""" zgoto "_lvl_":suiteDone^STDHARN"
        ; m-lint: disable-next-line=M-MOD-036
        do @ref   ; entryref from the host-supplied suite scope
suiteDone       ; Trap-resume target — also reached on no-error fall-through.
        ; doc: @internal
        set $ecode=""
        do nohalt^STDASSERT(0)
        set np=+$get(^STDLIB($job,"harn","pass"))
        set nf=+$get(^STDLIB($job,"harn","fail"))
        ; m-lint: disable-next-line=M-MOD-024
        do emit($$suiteClose(disp,xc))   ; disp/xc set in suite() before this GOTO target
        quit
        ;
irisRun(ref,xc) ; IRIS: run ref in a try/catch (no $ZLEVEL/ZGOTO on IRIS).
        ; doc: @internal
        ; doc: ObjectScript try/catch unwinds arbitrary $$ depth and captures the
        ; doc: error — the IRIS analog of the YDB ZGOTO unwind in suite().
        ; m-lint: disable-next-line=M-MOD-036
        xecute "try { do @ref } catch ex { set xc=1 }"
        quit
        ;
        ; --- IRIS line monitor (^%MONLBL) — emits raw per-line counts ---
        ; On YDB these are no-ops (resident coverage is the IRIS tier; YDB
        ; coverage stays the host-side view "TRACE" path), so a YDB coverage
        ; frame carries an empty ##MON block.
        ;
monStart(routines)      ; Start %Monitor.System.LineByLine over `routines`.
        ; doc: @internal
        new lb,i,r
        if '$$isiris quit
        set lb=""
        for i=1:1:$length(routines," ") set r=$piece(routines," ",i) if r'="" set lb=lb_$select(lb="":"",1:",")_$char(34)_r_$char(34)
        ; m-lint: disable-next-line=M-MOD-036
        xecute "set sc=##class(%Monitor.System.LineByLine).Start($listbuild("_lb_"),$listbuild(""RtnLine""),$listbuild($job))"
        quit
        ;
monDump(routines)       ; Emit MLINE:<routine>:<line>:<count> for each routine.
        ; doc: @internal
        new i,r
        if '$$isiris quit
        for i=1:1:$length(routines," ") set r=$piece(routines," ",i) if r'="" do monDumpOne(r)
        quit
        ;
monDumpOne(r)   ; Dump one routine's per-line counts (before Stop clears them).
        ; doc: @internal
        new cmd,q
        set q=$char(34)
        set cmd="set rs=##class(%ResultSet).%New("_q_"%Monitor.System.LineByLine:Result"_q_")"
        set cmd=cmd_" do rs.Execute("_q_r_q_")"
        set cmd=cmd_" set ln=0 while rs.Next() { set ln=ln+1"
        set cmd=cmd_" do emit^STDHARN("_q_"MLINE:"_r_":"_q_"_ln_"_q_":"_q_"_$listget(rs.GetData(1),1)) }"
        ; m-lint: disable-next-line=M-MOD-036
        xecute cmd
        quit
        ;
monStop()       ; Stop the line monitor (its data was already dumped).
        ; doc: @internal
        if '$$isiris quit
        ; m-lint: disable-next-line=M-MOD-036
        xecute "do ##class(%Monitor.System.LineByLine).Stop()"
        quit
        ;
isiris()        ; True on IRIS (where the ^%MONLBL monitor lives).
        ; doc: @internal
        quit $zversion["IRIS"
        ;
        ; --- frame composers (pure; return the delimiter lines) -------
        ;
header(tier)    ; Return the ##M-HARNESS header line.
        ; doc: @internal
        quit "##M-HARNESS frame=1 tier="_tier_" engine="_$$engine_" ns="_$$ns
        ;
suiteOpen(name) ; Return the ##SUITE ^NAME line.
        ; doc: @internal
        quit "##SUITE ^"_name
        ;
suiteClose(name,xc)     ; Return the ##END ^NAME exit=N line.
        ; doc: @internal
        quit "##END ^"_name_" exit="_xc
        ;
trailer(n,p,f)  ; Return the ##END-HARNESS cross-check trailer line.
        ; doc: @internal
        quit "##END-HARNESS suites="_n_" pass="_p_" fail="_f
        ;
engine()        ; Return the running engine label ("ydb" | "iris").
        ; doc: @internal
        quit $select($zversion["IRIS":"iris",1:"ydb")
        ;
ns()    ; Return the namespace render-label (IRIS $namespace; "" on YDB).
        ; doc: @internal
        new n
        set n=""
        ; m-lint: disable-next-line=M-MOD-036
        if $zversion["IRIS" xecute "set n=$namespace"
        quit n
        ;
        ; --- emit / capture (capture mode redirects for in-M testing) -
        ;
emit(line)      ; Write a frame line to the device, or capture it (test mode).
        ; doc: @internal
        if $data(^STDLIB($job,"harncap","on")) do capadd(line) quit
        write line,!
        quit
        ;
capture(on)     ; Toggle capture mode: emit() buffers into a global, not device.
        ; doc: @internal
        ; doc: Lets the M self-tests assert the frame without device redirection.
        ; doc: capture(1) starts a fresh buffer; capture(0) only stops capturing
        ; doc: (the buffer survives for captured() to read).
        if 'on kill ^STDLIB($job,"harncap","on") quit
        kill ^STDLIB($job,"harncap")
        set ^STDLIB($job,"harncap","on")=1,^STDLIB($job,"harncap","n")=0
        quit
        ;
capadd(line)    ; Append a captured frame line.
        ; doc: @internal
        new k
        set k=$increment(^STDLIB($job,"harncap","n"))
        set ^STDLIB($job,"harncap","l",k)=line
        quit
        ;
captured()      ; Return the captured frame (lines joined by LF).
        ; doc: @internal
        new k,out
        set out=""
        for k=1:1:+$get(^STDLIB($job,"harncap","n")) set out=out_$get(^STDLIB($job,"harncap","l",k))_$char(10)
        quit out
