STDJSON ; m-stdlib — RFC 8259 JSON parser + serialiser.
        ; doc: @tag v0.2.0
        ; doc: @phase Phase 2
        ; m-lint: disable-file=M-MOD-024
        ; M-MOD-024 false positives: the linter parses OPEN/CLOSE
        ; deviceparams as local reads (`(readonly)`, `(newversion)`,
        ; `(exception=...)`) and treats `for ... quit:c=""` loops as
        ; reading the iteration variable before assignment.
        ;
        ; Public API:
        ;   $$parse^STDJSON(text,.root)      — populate root, return 1/0
        ;   $$encode^STDJSON(.root)          — serialise to JSON text
        ;   $$valid^STDJSON(text)            — 1 iff text parses
        ;   $$lastError^STDJSON()            — "line:col: msg" or ""
        ;   $$type^STDJSON(.node)            — type label
        ;   $$valueOf^STDJSON(.node)         — scalar string
        ;   parseFile^STDJSON(path,.root)    — read whole file
        ;   writeFile^STDJSON(path,.node)    — write whole file
        ;
        ; Storage convention (one M tree node per JSON value):
        ;   node="o"           object — children at node(key)
        ;   node="a"           array  — children at node(i), i=1..n
        ;   node="s:VALUE"     string — VALUE is the decoded UTF-8 byte string
        ;   node="n:VALUE"     number — VALUE is the canonical numeric string
        ;   node="t" / "f"     true / false
        ;   node="z"           null   ('z' avoids colliding with 'n' for number)
        ;
        ; Engine notes (byte mode + IRIS):
        ;   - string VALUEs are byte-exact UTF-8 on BOTH engines: emitUtf8 builds
        ;     them with $CHAR(0..255), which is byte-equivalent on YDB byte-mode
        ;     and on IRIS (a code-n unit, n<256). \uXXXX and surrogate pairs decode
        ;     identically on both.
        ;   - object children at node(key): the EMPTY key node("") is YDB-only.
        ;     IRIS prohibits null subscripts in local arrays, so on IRIS the parser
        ;     rejects an empty object key with a clean U-STDJSON-PARSE error rather
        ;     than crashing (see parseObject's ENGINE CONSTRAINT note). Non-empty
        ;     keys behave identically on both engines.
        ;
        ; Parser state lives in a local context array `ctx` passed by ref
        ; through every recursive helper; no global writes during parse.
        ; The last error message is stashed at ^STDLIB($job,"stdjson","err")
        ; for $$lastError.
        ;
        ; Errors set $ECODE to one of:
        ;   ,U-STDJSON-PARSE,
        ;   ,U-STDJSON-ENCODE,
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
        ; doc: @param text    string  RFC-8259 JSON document
        ; doc: @param root    array   by-ref local; killed before population
        ; doc: @returns       bool    1 on success; 0 on parse failure
        ; doc: @raises        U-STDJSON-PARSE  malformed input (caught internally; surfaced as a 0 return, not propagated $ECODE)
        ; doc: @raisesnodemo U-STDJSON-PARSE  malformed input is caught internally and surfaced as a 0 return (not an $ECODE raise); the failure path is shown by the parse-returns-0 example
        ; doc: @example       do eq^STDASSERT(.pass,.fail,$$parse^STDJSON("[1,2,3]",.t),1,"parse a small array")
        ; doc: @example       do eq^STDASSERT(.pass,.fail,$$parse^STDJSON("[1,",.t),0,"parse returns 0 on truncated input")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$valid^STDJSON, $$lastError^STDJSON, $$encode^STDJSON
        ; doc: Kills `root` first. On failure, $$lastError() holds the
        ; doc: "line:col: msg" diagnostic and the partial tree is killed.
        new ctx,$etrap,parseLvl
        ; Normalise $ECODE at the public parse entry. parse() owns its own
        ; parse-error handling (raise() sets $ECODE mid-parse to unwind), so a
        ; CALLER's stale $ECODE must not reach parseObject/parseArray's
        ; `for quit:done!($ecode'="")` loop guard — on IRIS that made the member
        ; loop bail right after the opening {/[ and a valid document parse as
        ; empty or "trailing garbage" (discoveries.md 2026-06-21, P1).
        set $ecode=""
        if $zversion["IRIS" quit $$irisParse(text,.root)
        set parseLvl=$zlevel
        set $etrap="set $ecode="""" zgoto "_parseLvl_":parseFail^STDJSON"
        kill root
        do initCtx(.ctx,text)
        do parseValue(.ctx,.root)
        do skipWs(.ctx)
        if $$peek(.ctx)'="" do raise(.ctx,"trailing garbage")
        kill ^STDLIB($job,"stdjson","err")
        quit 1
parseFail
        ; doc: @internal
        kill root
        quit 0
        ;
irisParse(text,root)    ; IRIS: parse via try/catch (no ZGOTO unwind).
        ; doc: @internal
        ; doc: IRIS analog of parse()'s YDB $ETRAP+ZGOTO path — IRIS rejects
        ; doc: the `zgoto LEVEL:label` form (the YDB code faults <SYNTAX> at
        ; doc: the $etrap-set line, reached for every input). ObjectScript
        ; doc: try/catch unwinds the recursive descent on any raise()d $ECODE;
        ; doc: the catch routes to the same kill-root / quit-0 failure outcome.
        ; doc: The off-engine `try{}` is xecute-hidden so the YDB compiler never
        ; doc: parses it (same idiom as STDFS/STDHARN/irisRaises^STDASSERT). The
        ; doc: catch CLEARS $ECODE — a failed parse returns 0 with the diagnostic
        ; doc: in ^STDLIB (lastError), NOT via $ECODE; IRIS try/catch leaves
        ; doc: $ECODE set to the caught code, which would otherwise poison the
        ; doc: NEXT parse (mirrors the YDB $ETRAP's `set $ecode=""` before zgoto,
        ; doc: and the same readLn^STDFS EOF-clear lesson).
        new ctx,ok
        set ok=0
        kill root
        ; m-lint: disable-next-line=M-MOD-036
        xecute "try { do parseBody^STDJSON(.ctx,text,.root) set ok=1 } catch ex { set ok=0 set $ecode="""" }"
        if 'ok kill root quit 0
        kill ^STDLIB($job,"stdjson","err")
        quit 1
        ;
parseBody(ctx,text,root)        ; The recursive-descent body (engine-neutral).
        ; doc: @internal
        ; doc: Shared by irisParse()'s try/catch. Any malformed input sets $ECODE
        ; doc: via raise() — caught by irisParse on IRIS, by the $ETRAP/ZGOTO
        ; doc: trap on YDB's parse() (which inlines these same steps).
        do initCtx(.ctx,text)
        do parseValue(.ctx,.root)
        do skipWs(.ctx)
        if $$peek(.ctx)'="" do raise(.ctx,"trailing garbage")
        quit
        ;
valid(text)     ; True iff `text` is conformant RFC-8259 JSON.
        ; doc: @param text    string  candidate JSON document
        ; doc: @returns       bool    1 iff conformant; 0 otherwise
        ; doc: @example       write $$valid^STDJSON("[1,2,3]")  ; 1
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$parse^STDJSON
        ; doc: Discards the parsed tree; returns just the validity bit.
        ; doc: Empty input is invalid (RFC 8259 §2).
        new tree
        quit $$parse(text,.tree)
        ;
lastError()     ; Return the message from the most recent failed parse.
        ; doc: @returns       string  "line:col: msg" of last failure; "" if last call succeeded
        ; doc: @example       new t do eq^STDASSERT(.pass,.fail,$$parse^STDJSON("[",.t),0,"setup: bad parse") do contains^STDASSERT(.pass,.fail,$$lastError^STDJSON(),"unexpected EOF","lastError after a failed parse")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$parse^STDJSON
        quit $get(^STDLIB($job,"stdjson","err"),"")
        ;
type(node)      ; Return the JSON type label of `node` (or "" if undef).
        ; doc: @param node    node    by-ref node from a parsed JSON tree
        ; doc: @returns       string  one of object/array/string/number/true/false/null; "" if undef
        ; doc: @example       new t,ok set ok=$$parse^STDJSON("[1,2,3]",.t) do eq^STDASSERT(.pass,.fail,$$type^STDJSON(.t),"array","type of a parsed array root")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$valueOf^STDJSON
        new c
        if '$data(node)#10 quit ""
        set c=$extract(node,1)
        if c="o" quit "object"
        if c="a" quit "array"
        if c="s" quit "string"
        if c="n" quit "number"
        if c="t" quit "true"
        if c="f" quit "false"
        if c="z" quit "null"
        quit ""
        ;
valueOf(node)   ; Return the scalar value for s/n leaves; "" otherwise.
        ; doc: @param node    node    by-ref node from a parsed JSON tree
        ; doc: @returns       string  scalar value for s/n leaves; "" for containers/literals/undef
        ; doc: @example       new t,ok,m set ok=$$parse^STDJSON("{""name"":""Ann""}",.t) merge m=t("name") do eq^STDASSERT(.pass,.fail,$$valueOf^STDJSON(.m),"Ann","valueOf of a string member")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$type^STDJSON
        ; doc: For s, returns the decoded string content; for n, the
        ; doc: canonical numeric string as parsed from the source.
        new c
        if '$data(node)#10 quit ""
        set c=$extract(node,1)
        if c="s"!(c="n") quit $extract(node,3,$length(node))
        quit ""
        ;
encode(node)    ; Serialise `node` to JSON text.
        ; doc: @param node    node    by-ref tree to serialise
        ; doc: @returns       string  RFC-8259-conformant JSON text; "" on failure
        ; doc: @raises        U-STDJSON-ENCODE  malformed tree (e.g. gappy array)
        ; doc: @example       new t,ok set ok=$$parse^STDJSON("[1,2,3]",.t) do eq^STDASSERT(.pass,.fail,$$encode^STDJSON(.t),"[1,2,3]","encode round-trips a parsed array")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new g set g=""a"",g(1)=""n:1"",g(3)=""n:3"" if $$encode^STDJSON(.g)="""" set $ecode="",U-STDJSON-ENCODE,""","U-STDJSON-ENCODE","gappy array (gap at index 2) yields U-STDJSON-ENCODE")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$parse^STDJSON, do writeFile^STDJSON
        ; doc: Object members emit in M collation order (numeric subscripts
        ; doc: first, then string subscripts in byte order). A gappy array
        ; doc: (e.g. node(1) and node(3) without node(2)) raises U-STDJSON-ENCODE
        ; doc: rather than inventing a `null`.
        new $etrap,encodeLvl
        if $zversion["IRIS" quit $$irisEncode(.node)
        set encodeLvl=$zlevel
        set $etrap="zgoto "_encodeLvl_":encodeFail^STDJSON"
        quit $$encodeValue(.node)
encodeFail
        ; doc: @internal
        quit ""
        ;
irisEncode(node)        ; IRIS: encode via try/catch (no ZGOTO unwind).
        ; doc: @internal
        ; doc: IRIS analog of encode()'s YDB $ETRAP+ZGOTO path. A malformed tree
        ; doc: (e.g. gappy array) sets $ECODE inside encodeValue(); the catch maps
        ; doc: that to the same empty-string failure outcome as encodeFail.
        new out,ok
        set ok=0,out=""
        ; m-lint: disable-next-line=M-MOD-036
        xecute "try { set out=$$encodeValue^STDJSON(.node) set ok=1 } catch ex { set ok=0 }"
        if 'ok quit ""
        quit out
        ;
parseFile(path,root)    ; Stream-read `path`, parse into `root`.
        ; doc: @param path    path    filesystem path to a JSON file
        ; doc: @param root    array   by-ref local; killed before population
        ; doc: @raises        U-STDJSON-PARSE  open failure or malformed input
        ; doc: @example       new p,t set p="/tmp/stdjson_pf_"_$job do writeFile^STDFS(p,"[1,2,3]") do parseFile^STDJSON(p,.t) do eq^STDASSERT(.pass,.fail,$$type^STDJSON(.t),"array","parseFile reads and parses a JSON file") do remove^STDFS(p)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do parseFile^STDJSON(""/no/such/file.json"",.t)","U-STDJSON-PARSE","a missing file raises U-STDJSON-PARSE")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$parse^STDJSON, do writeFile^STDJSON
        ; doc: Reads the whole file via $$readFile^STDFS (engine-portable) then
        ; doc: defers to parse().
        new buf
        ; Clear a caller's stale $ECODE first: parseFile reads $ECODE after
        ; readFile to detect a read failure, so an inbound value would falsely
        ; flag a perfectly readable file (same P1 root cause as parse()).
        set $ecode=""
        if '$$exists^STDFS(path) set $ecode=",U-STDJSON-PARSE," quit
        set buf=$$readFile^STDFS(path)
        if $ecode'="" set $ecode=",U-STDJSON-PARSE," quit
        if '$$parse(buf,.root) set $ecode=",U-STDJSON-PARSE,"
        quit
        ;
writeFile(path,node)    ; Serialise `node` and write to `path`.
        ; doc: @param path    path    filesystem path; truncated if exists
        ; doc: @param node    node    by-ref tree to serialise
        ; doc: @raises        U-STDJSON-ENCODE  malformed tree or open failure
        ; doc: @example       new p,t,ok set p="/tmp/stdjson_wf_"_$job set ok=$$parse^STDJSON("[1,2,3]",.t) do writeFile^STDJSON(p,.t) do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"[1,2,3]","writeFile then readFile round-trips") do remove^STDFS(p)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new g set g=""a"",g(1)=""n:1"",g(3)=""n:3"" do writeFile^STDJSON(""/tmp/stdjson_bad_""_$job,.g)","U-STDJSON-ENCODE","a gappy tree raises U-STDJSON-ENCODE")
        ; doc: @since         v0.2.0
        ; doc: @stable        stable
        ; doc: @see           $$encode^STDJSON, do parseFile^STDJSON
        new text
        set text=$$encode(.node)
        do writeFile^STDFS(path,text)
        if $ecode'="" set $ecode=",U-STDJSON-ENCODE,"
        quit
        ;
        ; ---------- parser internals ----------
        ;
initCtx(ctx,text)       ; Reset parser state to start of `text`.
        ; doc: @internal
        ; doc: Sets src/len/pos/line/col fields used by the
        ; doc: peek/advance/raise helpers.
        set ctx("src")=text
        set ctx("len")=$length(text)
        set ctx("pos")=1
        set ctx("line")=1
        set ctx("col")=1
        quit
        ;
peek(ctx)       ; One byte at the cursor, or "" at EOF.
        ; doc: @internal
        ; doc: Does not advance. Returns "" for EOF (which is
        ; doc: distinguishable from the NUL byte $CHAR(0) by length).
        if ctx("pos")>ctx("len") quit ""
        quit $extract(ctx("src"),ctx("pos"))
        ;
peekN(ctx,n)    ; Up to n bytes at the cursor (may be shorter at EOF).
        ; doc: @internal
        ; doc: Used to match multi-byte literals like "true".
        quit $extract(ctx("src"),ctx("pos"),ctx("pos")+n-1)
        ;
advance(ctx,n)  ; Move cursor n bytes forward; track line/col.
        ; doc: @internal
        ; doc: Newlines bump line and reset col; everything
        ; doc: else bumps col.
        new i,c
        for i=1:1:n do
        . set c=$extract(ctx("src"),ctx("pos"))
        . set ctx("pos")=ctx("pos")+1
        . if c=$char(10) set ctx("line")=ctx("line")+1,ctx("col")=1 quit
        . set ctx("col")=ctx("col")+1
        quit
        ;
skipWs(ctx)     ; Consume RFC-8259 §2 whitespace (sp / ht / lf / cr).
        ; doc: @internal
        ; doc: Runs to first non-whitespace or EOF.
        new c
        for  do  quit:c'=" "&(c'=$char(9))&(c'=$char(10))&(c'=$char(13))
        . set c=$$peek(.ctx)
        . if c=" "!(c=$char(9))!(c=$char(10))!(c=$char(13)) do advance(.ctx,1)
        quit
        ;
raise(ctx,msg)  ; Stash msg with line:col prefix; set $ECODE; unwind.
        ; doc: @internal
        ; doc: Every parse helper checks $ECODE after a recursive
        ; doc: call and quits early to let the top-level $etrap catch.
        set ^STDLIB($job,"stdjson","err")=ctx("line")_":"_ctx("col")_": "_msg
        set $ecode=",U-STDJSON-PARSE,"
        quit
        ;
parseValue(ctx,node)    ; Dispatch on the first byte; populate `node`.
        ; doc: @internal
        ; doc: Top-level parser entry. Must be preceded by
        ; doc: skipWs by the caller (parseObject/parseArray do this).
        new c
        do skipWs(.ctx)
        set c=$$peek(.ctx)
        if c="" do raise(.ctx,"unexpected EOF") quit
        if c="{" do parseObject(.ctx,.node) quit
        if c="[" do parseArray(.ctx,.node) quit
        if c="""" do parseString(.ctx,.node) quit
        if c="t" do parseLiteral(.ctx,.node,"true","t") quit
        if c="f" do parseLiteral(.ctx,.node,"false","f") quit
        if c="n" do parseLiteral(.ctx,.node,"null","z") quit
        if c="-"!(c?1N) do parseNumber(.ctx,.node) quit
        do raise(.ctx,"unexpected character '"_c_"'")
        quit
        ;
parseLiteral(ctx,node,word,sigil)       ; Match word; set node=sigil.
        ; doc: @internal
        ; doc: Used for the three keyword literals true/false/null.
        new got
        set got=$$peekN(.ctx,$length(word))
        if got'=word do raise(.ctx,"unexpected character '"_$$peek(.ctx)_"'") quit
        do advance(.ctx,$length(word))
        set node=sigil
        quit
        ;
parseObject(ctx,node)   ; Parse {...} into `node`.
        ; doc: @internal
        ; doc: Handles empty object, comma-separated members, and empty-string
        ; doc: keys (RFC 8259 §4 allows them — but see the IRIS note below).
        ; doc: Recurses into a non-subscripted local (`tmp`) and merges back into
        ; doc: node(key) afterwards; passing subscripted formals by
        ; doc: reference (`do parseValue(.ctx,.node(key))`) is invalid
        ; doc: YDB syntax — only whole locals can be passed `.byref`.
        ; doc:
        ; doc: ENGINE CONSTRAINT — empty object key on IRIS (T0b.2, 2026-06-13).
        ; doc: A member is stored at node(key), and members are read back by the
        ; doc: caller via that same direct subscript (e.g. root("")). IRIS
        ; doc: prohibits a null ("") subscript in a LOCAL array unconditionally
        ; doc: (the NULL_SUBSCRIPTS namespace setting governs GLOBALS only, and
        ; doc: the VistA-on-IRIS target rejects it too) — so root("") faults
        ; doc: <SUBSCRIPT> both here at storage AND, more fundamentally, in the
        ; doc: caller that reads it. The tree's public contract IS direct
        ; doc: node(key) indexing (no accessor layer), so the empty key cannot be
        ; doc: made reachable on IRIS without re-architecting every member access
        ; doc: across the library and its consumers — disproportionate for a key
        ; doc: that does not occur in operational JSON (config / RPC / FHIR / logs
        ; doc: never use empty field names). Decision (user-confirmed): degrade
        ; doc: gracefully — raise a clean U-STDJSON-PARSE on IRIS instead of a hard
        ; doc: <SUBSCRIPT> crash; YDB byte-mode keeps full support. All NON-empty
        ; doc: keys behave identically on both engines. See docs/modules/stdjson.md
        ; doc: and the user guide for the full rationale.
        new c,key,done,tmp
        set node="o"
        do advance(.ctx,1)
        do skipWs(.ctx)
        if $$peek(.ctx)="}" do advance(.ctx,1) quit
        set done=0
        for  quit:done!($ecode'="")  do
        . if $$peek(.ctx)'="""" do raise(.ctx,"expected string key") quit
        . set key=$$parseStringValue(.ctx)
        . if $ecode'="" quit
        . if key="",$zversion["IRIS" do raise(.ctx,"empty object key unsupported on IRIS (engine prohibits null local subscripts)") quit
        . do skipWs(.ctx)
        . if $$peek(.ctx)'=":" do raise(.ctx,"expected ':' after key") quit
        . do advance(.ctx,1)
        . kill tmp
        . do parseValue(.ctx,.tmp)
        . merge node(key)=tmp
        . if $ecode'="" quit
        . do skipWs(.ctx)
        . set c=$$peek(.ctx)
        . if c="}" set done=1 do advance(.ctx,1) quit
        . if c'="," do raise(.ctx,"expected ',' or '}'") quit
        . do advance(.ctx,1)
        . do skipWs(.ctx)
        quit
        ;
parseArray(ctx,node)    ; Parse [...] into `node`.
        ; doc: @internal
        ; doc: Handles empty array, comma-separated elements;
        ; doc: trailing comma is rejected (RFC 8259 §5). Recurses into a
        ; doc: non-subscripted local for the same reason as parseObject.
        new c,i,done,tmp
        set node="a"
        do advance(.ctx,1)
        do skipWs(.ctx)
        if $$peek(.ctx)="]" do advance(.ctx,1) quit
        set done=0,i=0
        for  quit:done!($ecode'="")  do
        . set i=i+1
        . kill tmp
        . do parseValue(.ctx,.tmp)
        . merge node(i)=tmp
        . if $ecode'="" quit
        . do skipWs(.ctx)
        . set c=$$peek(.ctx)
        . if c="]" set done=1 do advance(.ctx,1) quit
        . if c'="," do raise(.ctx,"expected ',' or ']'") quit
        . do advance(.ctx,1)
        . do skipWs(.ctx)
        quit
        ;
parseString(ctx,node)   ; Parse "..." into `node` as s:VALUE.
        ; doc: @internal
        ; doc: Uses parseStringValue() to decode; wraps in
        ; doc: the s: sigil.
        new s
        set s=$$parseStringValue(.ctx)
        if $ecode'="" quit
        set node="s:"_s
        quit
        ;
parseStringValue(ctx)   ; Parse "..." and return the decoded content.
        ; doc: @internal
        ; doc: Handles \\\\ \\" \\/ \\b \\f \\n \\r \\t and \\uXXXX
        ; doc: escapes, including UTF-16 surrogate pairs. Bare control
        ; doc: bytes 0x00..0x1F are rejected.
        new out,c,bv,esc,cp,cp2
        set out=""
        if $$peek(.ctx)'="""" do raise(.ctx,"expected '""'") quit ""
        do advance(.ctx,1)
        for  do  quit:$ecode'=""!(c="""")
        . set c=$$peek(.ctx)
        . if c="" do raise(.ctx,"unterminated string") quit
        . if c="""" do advance(.ctx,1) quit
        . set bv=$ascii(c)
        . if bv<32 do raise(.ctx,"unescaped control character") quit
        . if c="\" do
        . . do advance(.ctx,1)
        . . set esc=$$peek(.ctx)
        . . if esc="" do raise(.ctx,"unterminated string") quit
        . . if esc="""" set out=out_"""" do advance(.ctx,1) quit
        . . if esc="\" set out=out_"\" do advance(.ctx,1) quit
        . . if esc="/" set out=out_"/" do advance(.ctx,1) quit
        . . if esc="b" set out=out_$char(8) do advance(.ctx,1) quit
        . . if esc="f" set out=out_$char(12) do advance(.ctx,1) quit
        . . if esc="n" set out=out_$char(10) do advance(.ctx,1) quit
        . . if esc="r" set out=out_$char(13) do advance(.ctx,1) quit
        . . if esc="t" set out=out_$char(9) do advance(.ctx,1) quit
        . . if esc="u" do  quit
        . . . new sawSurrogate
        . . . do advance(.ctx,1)
        . . . set cp=$$parseHex4(.ctx)
        . . . if cp<0 do raise(.ctx,"bad \u escape") quit
        . . . set sawSurrogate=0
        . . . if cp>=55296,cp<=56319 do
        . . . . ; high surrogate — must be followed by \uDCxx..\uDFxx
        . . . . if $$peekN(.ctx,2)'="\u" do raise(.ctx,"lone surrogate") quit
        . . . . do advance(.ctx,2)
        . . . . set cp2=$$parseHex4(.ctx)
        . . . . if cp2<56320!(cp2>57343) do raise(.ctx,"lone surrogate") quit
        . . . . ; no M precedence — parenthesise the *1024 (else (65536+(cp-55296))*1024)
        . . . . set cp=65536+((cp-55296)*1024)+(cp2-56320)
        . . . . set sawSurrogate=1
        . . . if $ecode'="" quit
        . . . if 'sawSurrogate,cp>=56320,cp<=57343 do raise(.ctx,"lone surrogate") quit
        . . . set out=out_$$emitUtf8(cp)
        . . . quit
        . . if $ecode'="" quit
        . . do raise(.ctx,"bad escape '\"_esc_"'")
        . else  set out=out_c do advance(.ctx,1)
        if $ecode'="" quit ""
        quit out
        ;
parseHex4(ctx) ; Parse exactly 4 hex digits; return codepoint or -1.
        ; doc: @internal
        ; doc: Does not raise; caller decides what to do with -1.
        new s,n,i,c,v
        set s=$$peekN(.ctx,4)
        if $length(s)<4 quit -1
        set n=0
        for i=1:1:4 do  quit:v<0
        . set c=$extract(s,i)
        . set v=$$hexVal(c)
        . if v<0 quit
        . set n=n*16+v
        if v<0 quit -1
        do advance(.ctx,4)
        quit n
        ;
hexVal(c)       ; Map a hex char to 0..15; -1 if not hex.
        ; doc: @internal
        ; doc: Accepts 0-9, A-F, a-f.
        new bv
        set bv=$ascii(c)
        if bv>=48,bv<=57 quit bv-48
        if bv>=65,bv<=70 quit bv-55
        if bv>=97,bv<=102 quit bv-87
        quit -1
        ;
emitUtf8(cp)    ; Codepoint -> 1-4 byte UTF-8 byte sequence.
        ; doc: @internal
        ; doc: Assumes cp is a valid scalar (caller filters
        ; doc: out the surrogate range D800-DFFF).
        ; M has no operator precedence (strict left-to-right), so every div/mod
        ; sub-expression is parenthesised — `192+cp\64` would otherwise evaluate as
        ; `(192+cp)\64`, producing garbage UTF-8 bytes (latent until the \uXXXX
        ; decode path got a byte-exact test; see tParseStringUnicodeBmpEscape).
        if cp<128 quit $char(cp)
        if cp<2048 quit $char(192+(cp\64))_$char(128+(cp#64))
        if cp<65536 quit $char(224+(cp\4096))_$char(128+((cp\64)#64))_$char(128+(cp#64))
        quit $char(240+(cp\262144))_$char(128+((cp\4096)#64))_$char(128+((cp\64)#64))_$char(128+(cp#64))
        ;
parseNumber(ctx,node)   ; Parse a number per RFC 8259 §6.
        ; doc: @internal
        ; doc: Captures the source span verbatim; rejects
        ; doc: leading zeros, lone decimals, and missing exponent digits.
        new start,c,saw,len
        set start=ctx("pos")
        if $$peek(.ctx)="-" do advance(.ctx,1)
        set c=$$peek(.ctx)
        if c'?1N do raise(.ctx,"bad number") quit
        if c="0" do advance(.ctx,1)
        else  do
        . for  do  quit:$$peek(.ctx)'?1N
        . . do advance(.ctx,1)
        if $$peek(.ctx)="." do
        . do advance(.ctx,1)
        . if $$peek(.ctx)'?1N do raise(.ctx,"bad number") quit
        . for  do  quit:$$peek(.ctx)'?1N
        . . do advance(.ctx,1)
        if $ecode'="" quit
        set c=$$peek(.ctx)
        if c="e"!(c="E") do
        . do advance(.ctx,1)
        . set c=$$peek(.ctx)
        . if c="+"!(c="-") do advance(.ctx,1)
        . if $$peek(.ctx)'?1N do raise(.ctx,"bad number") quit
        . for  do  quit:$$peek(.ctx)'?1N
        . . do advance(.ctx,1)
        if $ecode'="" quit
        set len=ctx("pos")-start
        set node="n:"_$extract(ctx("src"),start,start+len-1)
        quit
        ;
        ; ---------- encoder internals ----------
        ;
encodeValue(node)       ; Recursive walker — return JSON text for `node`.
        ; doc: @internal
        ; doc: Dispatches on the type sigil; raises
        ; doc: ,U-STDJSON-ENCODE, on unknown sigil.
        new c
        if '$data(node)#10,$data(node)=0 set $ecode=",U-STDJSON-ENCODE," quit ""
        set c=$extract(node,1)
        if c="o" quit $$encodeObject(.node)
        if c="a" quit $$encodeArray(.node)
        if c="s" quit $$encodeString($extract(node,3,$length(node)))
        if c="n" quit $$encodeNumber($extract(node,3,$length(node)))
        if c="t" quit "true"
        if c="f" quit "false"
        if c="z" quit "null"
        set $ecode=",U-STDJSON-ENCODE,"
        quit ""
        ;
encodeNumber(v) ; Emit an n:-node payload as an RFC 8259 §6 number, or raise.
        ; doc: @internal
        ; doc: M-canonical numbers drop the integer-part zero (.5, -.25) but the
        ; doc: RFC requires a leading digit — a verbatim emit is invalid JSON that
        ; doc: parseNumber() itself rejects, so encode->parse would not round-trip.
        ; doc: Normalizes the two M-canonical fraction shapes, then validates the
        ; doc: result against the RFC number grammar; any other payload raises
        ; doc: ,U-STDJSON-ENCODE, (fail loud — never emit an invalid document).
        new w
        set w=v
        if $extract(w)="." set w="0"_w
        else  if $extract(w,1,2)="-." set w="-0"_$extract(w,2,$length(w))
        if '$$jsonNumOk(w) set $ecode=",U-STDJSON-ENCODE," quit ""
        quit w
        ;
jsonNumOk(v)    ; 1 iff `v` matches the RFC 8259 §6 number grammar exactly.
        ; doc: @internal
        ; doc: number = [-] int [frac] [exp]; int = "0" / digit1-9 *digit;
        ; doc: frac = "." 1*digit; exp = ("e"/"E") ["+"/"-"] 1*digit.
        new u,mant,ex,int,frac
        set u=$translate(v,"e","E")
        if $length(u,"E")>2 quit 0
        set mant=$piece(u,"E"),ex=$select(u["E":$piece(u,"E",2),1:"")
        if u["E",ex?1(1"+",1"-").e set ex=$extract(ex,2,$length(ex))
        if u["E",ex'?1.n quit 0
        if $extract(mant)="-" set mant=$extract(mant,2,$length(mant))
        if $length(mant,".")>2 quit 0
        set int=$piece(mant,"."),frac=$select(mant[".":$piece(mant,".",2),1:"")
        if int'?1.n quit 0
        if $length(int)>1,$extract(int)="0" quit 0
        if mant[".",frac'?1.n quit 0
        quit 1
        ;
encodeObject(node)      ; Emit {k:v,...} for an object node.
        ; doc: @internal
        ; doc: Walks node() children in M collation order.
        ; doc: Uses `merge tmp=node(k)` to copy the child subtree into a
        ; doc: non-subscripted local before recursing; passing subscripted
        ; doc: formals by reference (`$$encodeValue(.node(k))`) is invalid
        ; doc: YDB syntax — only whole locals can be passed `.byref`.
        new out,k,first,tmp
        set out="{"
        set first=1
        set k=$order(node(""))
        for  quit:k=""  do
        . if 'first set out=out_","
        . set first=0
        . kill tmp
        . merge tmp=node(k)
        . set out=out_$$encodeString(k)_":"_$$encodeValue(.tmp)
        . set k=$order(node(k))
        set out=out_"}"
        quit out
        ;
encodeArray(node)       ; Emit [v,v,...] for an array node.
        ; doc: @internal
        ; doc: Expects 1..n contiguous indices; sets
        ; doc: ,U-STDJSON-ENCODE, on a gap. Uses merge-into-local before
        ; doc: recursing for the same reason as encodeObject.
        new out,i,n,first,tmp
        set out="["
        set n=0
        set i=$order(node(""))
        for  quit:i=""  set n=n+1,i=$order(node(i))
        set first=1
        for i=1:1:n do  quit:$ecode'=""
        . if '$data(node(i)) set $ecode=",U-STDJSON-ENCODE," quit
        . if 'first set out=out_","
        . set first=0
        . kill tmp
        . merge tmp=node(i)
        . set out=out_$$encodeValue(.tmp)
        if $ecode'="" quit ""
        set out=out_"]"
        quit out
        ;
encodeString(s) ; Wrap `s` in quotes; re-escape per RFC 8259 §7.
        ; doc: @internal
        ; doc: Bytes 0x00-0x1F lacking a named escape become
        ; doc: \\u00XX; bytes 0x20+ pass through (caller is assumed to be
        ; doc: handing in a UTF-8 byte sequence).
        new out,n,i,c,bv
        set out=""""
        set n=$length(s)
        for i=1:1:n do
        . set c=$extract(s,i)
        . set bv=$ascii(c)
        . if c="""" set out=out_"\""" quit
        . if c="\" set out=out_"\\" quit
        . if bv=8 set out=out_"\b" quit
        . if bv=9 set out=out_"\t" quit
        . if bv=10 set out=out_"\n" quit
        . if bv=12 set out=out_"\f" quit
        . if bv=13 set out=out_"\r" quit
        . if bv<32 set out=out_"\u00"_$$hex2(bv) quit
        . set out=out_c
        set out=out_""""
        quit out
        ;
hex2(bv)        ; Two-digit lowercase hex for a byte value 0..255.
        ; doc: @internal
        ; doc: Used for \\u00XX control-byte escaping.
        new alpha,hi,lo
        set alpha="0123456789abcdef"
        set hi=bv\16
        set lo=bv#16
        quit $extract(alpha,hi+1)_$extract(alpha,lo+1)
        ;
