STDFS   ; m-stdlib — File-system primitives (text I/O, path manipulation, bytes).
        ; doc: @tag v0.3.0
        ; doc: @phase P4 wave
        ; m-lint: disable-file=M-MOD-024
        ; m-lint: disable-file=M-MOD-022
        ; m-lint: disable-file=M-MOD-036
        ; m-lint: disable-file=M-MOD-020
        ; M-MOD-024 false positives: the linter parses YDB OPEN/USE/CLOSE
        ; deviceparams (readonly, newversion, append, delete, exception,
        ; nowrap, noecho) as local-variable reads. Same finding as STDCSV
        ; and STDCSPRNG; tracked as P2 in TOOLCHAIN-FINDINGS.md.
        ; M-MOD-022: the SEQ-device text path uses $ZEOF (a YDB extension) on
        ; its YDB arm only. The engine-portable open/read helpers below
        ; (openRead/openWrite/openAppend/readLn) carry a $ZVERSION["IRIS"
        ; branch mapping the YDB deviceparams to IRIS mode strings
        ; (readonly→"R", newversion:stream:nowrap→"WNS", append→"WA",
        ; close:(delete)→close:"D") and catch IRIS's <ENDOFFILE> throw where
        ; YDB sets $ZEOF — so the text I/O API (readFile/writeFile/readLines/
        ; writeLines/exists/size/remove/append) now runs on BOTH engines. The
        ; byte-faithful $&stdfs→libc Bytes API (readBytes/writeBytes/appendBytes)
        ; stays YDB-only (needs the stdfs.so callout); on IRIS $$available
        ; returns 0 and those entries set ,U-STDFS-NOT-WIRED,.
        ; M-MOD-036 (XECUTE injection) is intentional in the *Bytes() dispatch
        ; helpers: the XECUTE wrapper keeps the $& external-call token out of
        ; the parse tree (m fmt/lint do not handle it). The XECUTE source is
        ; built from a literal template only — no user data flows in. Same
        ; trick as STDCRYPTO / STDCOMPRESS / STDHTTP.
        ; G-FS-YDB (fixed 2026-07-22, found by the m-devbox callout build
        ; path): this module originally dispatched via $ZF(...) — which is not
        ; YDB syntax at all (%YDB-E-COMMA at XECUTE compile, silently eaten by
        ; the $etrap) — and guarded on ydb_xc_std_fs, a name the engine never
        ; reads. Same class as STDHTTP's G-HTTP-YDB: labels/packages must be
        ; underscore-free ($&stdfs.available; in M `_` is concatenation) and
        ; the env var is the STRIPPED package name, ydb_xc_stdfs.
        ; M-MOD-020 (by-ref formal not written) false positives: dispatch
        ; helpers write to `out` via the XECUTE'd $& call.
        ;
        ; Public extrinsics:
        ;   $$readFile^STDFS(path)         — read file as string (LF-separated)
        ;   $$writeFile^STDFS(path,data)   — write data; overwrite if file exists
        ;   $$append^STDFS(path,data)      — append data; create if missing
        ;   readLines^STDFS(path,.lines)   — populate lines(1..N) from file
        ;   $$writeLines^STDFS(path,.lines)— write lines(1..N) as LF-separated
        ;   $$exists^STDFS(path)           — 1 iff path exists
        ;   $$remove^STDFS(path)           — delete path; no-op if absent
        ;   $$size^STDFS(path)             — size in bytes; -1 if missing
        ;   $$basename^STDFS(path)         — last path component
        ;   $$dirname^STDFS(path)          — parent path (or "." / "/")
        ;   $$join^STDFS(left,right)       — POSIX path join (absolute right wins)
        ;
        ; Byte-faithful I/O via $&stdfs -> libc read(2)/write(2) callouts (T13+T14):
        ;   $$readBytes^STDFS(path)        — file content as bytes (no CR/LF normalisation)
        ;   writeBytes^STDFS(path,data)    — write data verbatim; no trailing LF
        ;   appendBytes^STDFS(path,data)   — append data via O_APPEND atomically
        ;   $$available^STDFS()            — 1 iff stdfs.so is loaded
        ;
        ; Text I/O semantics: file is read line-by-line and rejoined with LF.
        ; Trailing CR (CRLF input) is normalised to LF on read; write emits LF.
        ; Binary I/O (readBytes / writeBytes / appendBytes) preserves bytes
        ; exactly — no LF added on write, no CR/LF stripped on read. Use these
        ; for non-text payloads (gzipped data, binaries, signed blobs).
        ;
        ; Path semantics: POSIX-flavoured. Trailing slashes on dirname/basename
        ; follow GNU coreutils conventions: basename strips them, dirname keeps
        ; the parent with its trailing slash collapsed.
        ;
        ; Existence checks delegate to $ZSEARCH, which YDB resolves via stat()
        ; on first call and caches per-process. remove() opens the file with
        ; the DELETE deviceparam — succeeds for files; silently no-ops if the
        ; file is already absent (idempotent contract).
        ;
        ; Backend (Bytes API): $&stdfs -> libc open(2)/read(2)/write(2)/close(2).
        ; Source at src/callouts/stdfs.c; descriptor at tools/std_fs.xc.
        ; When the .so is unavailable the *Bytes() entries set $ECODE to
        ; ,U-STDFS-NOT-WIRED, and return; the text-I/O entries (writeFile /
        ; readFile / writeLines / readLines) and append() keep working via
        ; the YDB SEQ device — append() then takes the read-then-rewrite
        ; fallback automatically.
        ;
        ; Deployment runbook (full detail in docs/modules/stdfs.md):
        ;   1. tools/build-callouts.sh      ; produces so/<plat>/stdfs.so
        ;   2. export STDLIB_LIB=<dir-of-so>
        ;   3. export ydb_xc_stdfs=<abs>/tools/std_fs.xc
        ;   (or simply `m callouts install`, which wires all three)
        ;
        quit
        ;
        ; ---------- public API: path manipulation ----------
        ;
basename(path)  ; Return the last component of path.
        ; doc: @param path    path    POSIX path
        ; doc: @returns       string  last path component; "/" for root; "" for empty input
        ; doc: @example       write $$basename^STDFS("/etc/hosts")  ; "hosts"
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$dirname^STDFS, $$join^STDFS
        ; doc: Trailing slash is stripped before extracting the last segment.
        if path="" quit ""
        if path="/" quit "/"
        new p,n
        set p=path
        ; Strip a single trailing slash so "foo/bar/" → "foo/bar".
        if $extract(p,$length(p))="/" set p=$extract(p,1,$length(p)-1)
        set n=$length(p,"/")
        quit $piece(p,"/",n)
        ;
dirname(path)   ; Return the parent path (everything but the last component).
        ; doc: @param path    path    POSIX path
        ; doc: @returns       path    parent path; "." for no-slash input; "/" for root
        ; doc: @example       write $$dirname^STDFS("/etc/hosts")  ; "/etc"
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$basename^STDFS, $$join^STDFS
        ; doc: Trailing slashes are normalised first ("/foo/bar/" → "/foo").
        if path="" quit "."
        if path="/" quit "/"
        new p,n,parent
        set p=path
        if $extract(p,$length(p))="/" set p=$extract(p,1,$length(p)-1)
        if p'["/" quit "."
        set n=$length(p,"/")
        set parent=$piece(p,"/",1,n-1)
        if parent="" quit "/"
        quit parent
        ;
join(left,right)        ; POSIX path join: absolute right replaces left.
        ; doc: @param left    path    left operand
        ; doc: @param right   path    right operand (absolute right wins)
        ; doc: @returns       path    joined path
        ; doc: @example       write $$join^STDFS("/a","b")     ; "/a/b"
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$dirname^STDFS, $$basename^STDFS
        ; doc: Empty operand drops out. Trailing slash on left is collapsed.
        if right="" quit left
        if left="" quit right
        if $extract(right,1)="/" quit right
        if $extract(left,$length(left))="/" quit left_right
        quit left_"/"_right
        ;
        ; ---------- public API: existence / metadata ----------
        ;
exists(path)    ; Return 1 iff path exists; else 0.
        ; doc: @param path    path    filesystem path
        ; doc: @returns       bool    1 iff openable; 0 otherwise
        ; doc: @example       new p set p="/tmp/stdfs_ex_"_$job do writeFile^STDFS(p,"x") do eq^STDASSERT(.pass,.fail,$$exists^STDFS(p),1,"exists is 1 after write") do remove^STDFS(p)
        ; doc: @example       write $$exists^STDFS("/no/such/stdfs/path")  ; 0
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$size^STDFS, $$readFile^STDFS
        ; doc: Probes via $$openRead with timeout=0 — succeeds iff the path is
        ; doc: openable. Avoids $ZSEARCH's per-process cache, so a path created
        ; doc: and removed inside one M process round-trips correctly. Portable:
        ; doc: openRead carries the engine branch and never throws.
        if path="" quit 0
        if '$$openRead(path,0) quit 0
        close path
        quit 1
        ;
size(path)      ; Return size of path in bytes; -1 if missing or unreadable.
        ; doc: @param path    path    filesystem path
        ; doc: @returns       int     byte count; -1 if missing or unreadable
        ; doc: @example       new p set p="/tmp/stdfs_sz_"_$job do writeFile^STDFS(p,"hi") do eq^STDASSERT(.pass,.fail,$$size^STDFS(p),3,"size counts the trailing LF") do remove^STDFS(p)
        ; doc: @example       write $$size^STDFS("/no/such/stdfs/path")  ; -1
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$exists^STDFS, $$readBytes^STDFS
        ; doc: Implemented via a FIXED-mode OPEN/READ byte tally — does not
        ; doc: depend on a stat callout, and is byte-exact in byte mode
        ; doc: (ydb_chset=M), including unterminated final lines.
        if '$$exists(path) quit -1
        if $zversion["IRIS" quit $$sizeIris(path)
        ; Byte-exact tally via a FIXED-mode read (G-FS-YDB, 2026-07-22): the
        ; old line-mode tally reconstructed an LF for every line read, so an
        ; unterminated final line over-counted by one — line reads cannot
        ; distinguish "abc" from "abc"_$char(10) (both tallied 4). FIXED mode
        ; chunks recordsize bytes with no terminator semantics, so the
        ; $length sum is the exact byte count (byte mode — MSL runs
        ; ydb_chset=M). Trap unwinds via ZGOTO, same discipline as openRead.
        new total,x,prev,lvl,$etrap
        set total=0,prev=$io
        set lvl=$zlevel
        set $etrap="use prev set $ecode="""" set total=-1 zgoto "_lvl_":sizeRet^STDFS"
        open path:(readonly:fixed:recordsize=32767):2
        else  quit -1
        use path
        for  read x quit:x=""  set total=total+$length(x)
        use prev
        close path
sizeRet ; Trap-resume target for size(); reached on success fall-through too.
        ; doc: @internal
        quit total
        ;
        ; ---------- public API: portable SEQ-device open ----------
        ;
openRead(path,timeout)  ; Open path read-only on the current engine; return $TEST.
        ; doc: @param path     path    filesystem path to open for reading
        ; doc: @param timeout  int     OPEN timeout in seconds (default 5; 0 = poll)
        ; doc: @returns        bool    1 iff the device opened; 0 on timeout/error
        ; doc: @example        write $$openRead^STDFS("/no/such/stdfs/path",0)  ; 0
        ; doc: @illustrative   caller pattern: `if '$$openRead^STDFS(dev,2) set $ecode=",U-OPEN," quit`
        ; doc: @since          v0.5.0
        ; doc: @stable         stable
        ; doc: @see            $$openWrite^STDFS, $$openAppend^STDFS
        ; doc: Engine-portable: YDB `(readonly)` ↔ IRIS mode "R". Never throws —
        ; doc: a missing/unopenable path returns 0. The caller `use`s + `close`s.
        new ok,$etrap,lvl
        set timeout=$get(timeout,5),ok=0
        if $zversion["IRIS" xecute "try { open path:(""R""):timeout set ok=$test } catch ex { set ok=0 }" quit ok
        ; YDB: a readonly OPEN of a MISSING file raises DEVOPENFAIL (timeout
        ; doesn't catch ENOENT), so unwind it via ZGOTO (arg-less QUIT is illegal
        ; in this extrinsic) — the IRIS arm above catches the same case in try/catch.
        set lvl=$zlevel
        set $etrap="set $ecode="""" zgoto "_lvl_":openReadRet^STDFS"
        open path:(readonly):timeout
        set ok=$test
openReadRet     ; Trap-resume target; reached on success fall-through too.
        ; doc: @internal
        quit ok
        ;
openWrite(path,timeout) ; Open path write-new (create/truncate); return $TEST.
        ; doc: @param path     path    filesystem path; truncated/created
        ; doc: @param timeout  int     OPEN timeout in seconds (default 5)
        ; doc: @returns        bool    1 iff the device opened; 0 otherwise
        ; doc: @example        new p set p="/tmp/stdfs_ow_"_$job do eq^STDASSERT(.pass,.fail,$$openWrite^STDFS(p,5),1,"opened a new file for write") close p do remove^STDFS(p)
        ; doc: @since          v0.5.0
        ; doc: @stable         stable
        ; doc: @see            $$openRead^STDFS, $$openAppend^STDFS
        ; doc: Engine-portable: YDB `(newversion:stream:nowrap)` ↔ IRIS "WNS"
        ; doc: (stream mode, no line wrap). Never throws.
        new ok
        set timeout=$get(timeout,5),ok=0
        if $zversion["IRIS" xecute "try { open path:(""WNS""):timeout set ok=$test } catch ex { set ok=0 }" quit ok
        open path:(newversion:stream:nowrap):timeout
        quit $test
        ;
openAppend(path,timeout)        ; Open path for append (create if missing); return $TEST.
        ; doc: @param path     path    filesystem path; created if absent
        ; doc: @param timeout  int     OPEN timeout in seconds (default 5)
        ; doc: @returns        bool    1 iff the device opened; 0 otherwise
        ; doc: @example        new p set p="/tmp/stdfs_oa_"_$job do eq^STDASSERT(.pass,.fail,$$openAppend^STDFS(p,5),1,"opened a file for append") close p do remove^STDFS(p)
        ; doc: @since          v0.5.0
        ; doc: @stable         stable
        ; doc: @see            $$openWrite^STDFS, do append^STDFS
        ; doc: Engine-portable: YDB `(append)` ↔ IRIS "WA". Never throws.
        new ok
        set timeout=$get(timeout,5),ok=0
        if $zversion["IRIS" xecute "try { open path:(""WA""):timeout set ok=$test } catch ex { set ok=0 }" quit ok
        open path:(append):timeout
        quit $test
        ;
        ; ---------- public API: I/O ----------
        ;
readFile(path)  ; Return file content as a string (lines joined by $C(10)).
        ; doc: @param path    path    filesystem path
        ; doc: @returns       string  file content; lines LF-separated, trailing LF dropped
        ; doc: @raises        U-STDFS-OPEN-FAIL  path is missing or unreadable
        ; doc: @example       new p set p="/tmp/stdfs_rf_"_$job do writeFile^STDFS(p,"alpha") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"alpha","readFile round-trips writeFile") do remove^STDFS(p)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$readFile^STDFS(""/no/such/stdfs/path"")","U-STDFS-OPEN-FAIL","missing path raises OPEN-FAIL")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$writeFile^STDFS, $$readBytes^STDFS, do readLines^STDFS
        ; doc: Trailing CR on each line is dropped (CRLF normalisation).
        ; doc: A trailing LF is normalised away (round-trips with writeFile).
        if '$$exists(path) set $ecode=",U-STDFS-OPEN-FAIL," quit ""
        new buf,line,prev,eof
        set buf="",prev=$io
        if '$$openRead(path,2) set $ecode=",U-STDFS-OPEN-FAIL," quit ""
        use path
        for  set line=$$readLn(.eof) quit:eof&(line="")  do
        . if $extract(line,$length(line))=$char(13) set line=$extract(line,1,$length(line)-1)
        . set buf=$select(buf="":line,1:buf_$char(10)_line)
        use prev
        close path
        quit buf
        ;
writeFile(path,data)    ; Write data to path (overwrite if exists).
        ; doc: @param path    path    filesystem path; truncated if exists
        ; doc: @param data    string  text content (lines may be LF-separated)
        ; doc: @raises        U-STDFS-OPEN-FAIL  could not open `path` for write
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  set only when $$openWrite times out (returns 0); a bad/ENOENT path hard-faults the raw engine DEVOPENFAIL (,Z…) before the soft code, and an OPEN timeout isn't safely/portably reproducible in a unit example — verified on m-test-engine/YDB: a bad-path writeFile raises ,Z… not U-STDFS-OPEN-FAIL
        ; doc: @example       new p set p="/tmp/stdfs_wf_"_$job do writeFile^STDFS(p,"hi") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"hi","writeFile then readFile") do remove^STDFS(p)
        ; doc: @illustrative  U-STDFS-OPEN-FAIL needs an OPEN that times out rather than ENOENT; a bad-path OPEN propagates the raw engine DEVOPENFAIL, not the soft code
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$readFile^STDFS, do writeBytes^STDFS, do writeLines^STDFS
        ; doc: Empty data creates a zero-byte file. Non-empty data ends in exactly
        ; doc: one trailing LF on disk (YDB's SEQ stream-mode close finalises the
        ; doc: last record; IRIS "WNS" does not, so the IRIS arm writes the
        ; doc: terminator explicitly when data doesn't already end in LF) — so the
        ; doc: on-disk byte count is engine-identical and readFile round-trips.
        new prev
        set prev=$io
        if '$$openWrite(path,5) set $ecode=",U-STDFS-OPEN-FAIL," quit
        use path
        if data'="" write data
        if data'="",$zversion["IRIS",$extract(data,$length(data))'=$char(10) write $char(10)
        use prev
        close path
        quit
        ;
append(path,data)       ; Append data to path; create the file if missing.
        ; doc: @param path    path    filesystem path; created if absent
        ; doc: @param data    string  text content
        ; doc: @raises        U-STDFS-OPEN-FAIL  could not open for read or write
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  append delegates to writeFile/openWrite, so the same limit applies: a bad/ENOENT path hard-faults the raw engine DEVOPENFAIL (,Z…), and the soft code only fires on an OPEN timeout that isn't safely reproducible in a unit example — verified on m-test-engine/YDB
        ; doc: @example       new p set p="/tmp/stdfs_ap_"_$job do writeFile^STDFS(p,"a") do append^STDFS(p,$char(10)_"b") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"a"_$char(10)_"b","append adds a second line") do remove^STDFS(p)
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$writeFile^STDFS, do appendBytes^STDFS
        ; doc: Implementation: text-mode read-then-rewrite. For byte-faithful
        ; doc: append at EOF use $$appendBytes^STDFS instead.
        if '$$exists(path) do writeFile(path,data) quit
        new old
        set old=$$readFile(path)
        do writeFile(path,old_data)
        quit
        ;
remove(path)    ; Delete path; idempotent (no-op if already absent).
        ; doc: @param path    path    filesystem path
        ; doc: @raises        U-STDFS-REMOVE-FAIL  open-with-DELETE failed (not the missing-file case)
        ; doc: @raisesnodemo U-STDFS-REMOVE-FAIL  requires a file that exists but resists OS delete (e.g. permissions); not portably triggerable
        ; doc: @example       new p set p="/tmp/stdfs_rm_"_$job do writeFile^STDFS(p,"x") do remove^STDFS(p) do eq^STDASSERT(.pass,.fail,$$exists^STDFS(p),0,"remove deletes the file")
        ; doc: @illustrative  U-STDFS-REMOVE-FAIL needs an existing+openable file whose open-with-DELETE fails (e.g. a permission/FS edge) — not deterministically reproducible in a test harness
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$exists^STDFS
        if '$$exists(path) quit
        if '$$openRead(path,2) set $ecode=",U-STDFS-REMOVE-FAIL," quit
        do closeDelete(path)
        quit
        ;
readLines(path,lines)   ; Read path into lines(1..N) (1-indexed; CRLF normalised).
        ; doc: @param path    path    filesystem path
        ; doc: @param lines   array   by-ref local; killed then populated as lines(1..N)
        ; doc: @raises        U-STDFS-OPEN-FAIL  path is missing or unreadable
        ; doc: @example       new p,lines set p="/tmp/stdfs_rl_"_$job do writeFile^STDFS(p,"a"_$char(10)_"b") do readLines^STDFS(p,.lines) do eq^STDASSERT(.pass,.fail,lines(2),"b","second line lands at lines(2)") do remove^STDFS(p)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do readLines^STDFS(""/no/such/stdfs/path"",.a)","U-STDFS-OPEN-FAIL","missing path raises OPEN-FAIL")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$readFile^STDFS, $$writeLines^STDFS
        ; doc: Each line is one M string under lines(i). Empty file → empty array.
        kill lines
        if '$$exists(path) set $ecode=",U-STDFS-OPEN-FAIL," quit
        new line,n,prev,eof
        set n=0,prev=$io
        if '$$openRead(path,2) set $ecode=",U-STDFS-OPEN-FAIL," quit
        use path
        for  set line=$$readLn(.eof) quit:eof&(line="")  do
        . if $extract(line,$length(line))=$char(13) set line=$extract(line,1,$length(line)-1)
        . set n=n+1,lines(n)=line
        use prev
        close path
        quit
        ;
writeLines(path,lines)  ; Write lines(1..N) to path, separated and terminated by LF.
        ; doc: @param path    path    filesystem path; truncated if exists
        ; doc: @param lines   array   by-ref local subscripted as lines(1..N)
        ; doc: @raises        U-STDFS-OPEN-FAIL  could not open `path` for write
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  set only when $$openWrite times out (returns 0); a bad/ENOENT path hard-faults the raw engine DEVOPENFAIL (,Z…) before the soft code, and an OPEN timeout isn't safely/portably reproducible in a unit example — verified on m-test-engine/YDB
        ; doc: @example       new p,lines set p="/tmp/stdfs_wl_"_$job,lines(1)="a",lines(2)="b" do writeLines^STDFS(p,.lines) do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"a"_$char(10)_"b","writeLines emits LF-separated lines") do remove^STDFS(p)
        ; doc: @illustrative  U-STDFS-OPEN-FAIL needs an OPEN that times out rather than ENOENT; a bad-path OPEN propagates the raw engine DEVOPENFAIL, not the soft code
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           do readLines^STDFS, $$writeFile^STDFS
        ; doc: lines must be 1-indexed and dense (no gaps in $ORDER).
        new i,prev
        set prev=$io
        if '$$openWrite(path,5) set $ecode=",U-STDFS-OPEN-FAIL," quit
        use path
        set i=""
        for  set i=$order(lines(i)) quit:i=""  write lines(i),!
        use prev
        close path
        quit
        ;
        ; ---------- public API: byte-faithful I/O via $&stdfs callouts (T13+T14) ----------
        ;
writeBytes(path,data)   ; Write data to path verbatim — no trailing LF, no transcoding.
        ; doc: @param path    path    filesystem path; truncated if exists
        ; doc: @param data    byte-string  one M character per byte (0..255)
        ; doc: @raises        U-STDFS-NOT-WIRED  stdfs.so is unavailable
        ; doc: @raises        U-STDFS-OPEN-FAIL  open(2) failed
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  unreachable without the callout backend: with no stdfs.so loaded (the default / m-test-engine) the entry short-circuits to U-STDFS-NOT-WIRED before open(2) — verified $$available^STDFS()=0 → a bad-path writeBytes raises NOT-WIRED, not OPEN-FAIL; reaching OPEN-FAIL needs the .so loaded AND a failing open(2)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do writeBytes^STDFS(""/tmp/blob.bin"",""x"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, writeBytes raises NOT-WIRED")
        ; doc: @illustrative  happy path needs stdfs.so loaded (set ydb_xc_stdfs): do writeBytes^STDFS("/tmp/blob.bin",bytes) writes the bytes verbatim; U-STDFS-OPEN-FAIL needs the .so loaded AND an open(2) that fails (e.g. a bad path / permission) — both require the callout backend
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$readBytes^STDFS, do appendBytes^STDFS, $$writeFile^STDFS
        do dispatch2("writeBytes",path,data)
        quit
        ;
appendBytes(path,data)  ; Append data to path via O_APPEND — atomic at EOF, byte-faithful.
        ; doc: @param path    path    filesystem path; created if absent
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @raises        U-STDFS-NOT-WIRED  stdfs.so is unavailable
        ; doc: @raises        U-STDFS-OPEN-FAIL  open(2) failed
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  unreachable without the callout backend: with no stdfs.so loaded (the default / m-test-engine) the entry short-circuits to U-STDFS-NOT-WIRED before open(2) — verified $$available^STDFS()=0 → a bad-path appendBytes raises NOT-WIRED, not OPEN-FAIL; reaching OPEN-FAIL needs the .so loaded AND a failing open(2)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do appendBytes^STDFS(""/tmp/blob.bin"",""x"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, appendBytes raises NOT-WIRED")
        ; doc: @illustrative  happy path needs stdfs.so loaded (set ydb_xc_stdfs): do appendBytes^STDFS("/tmp/blob.bin",chunk) appends via O_APPEND; U-STDFS-OPEN-FAIL needs the .so loaded AND an open(2) that fails — requires the callout backend
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           do writeBytes^STDFS, do append^STDFS
        do dispatch2("appendBytes",path,data)
        quit
        ;
readBytes(path) ; Return file content as a byte string — no CR/LF normalisation.
        ; doc: @param path    path    filesystem path
        ; doc: @returns       byte-string  file contents byte-for-byte
        ; doc: @raises        U-STDFS-NOT-WIRED       stdfs.so is unavailable
        ; doc: @raises        U-STDFS-OPEN-FAIL       open(2) failed
        ; doc: @raises        U-STDFS-READ-TRUNCATED  file exceeds the 1 MiB buffer cap (YDB max string length)
        ; doc: @raisesnodemo U-STDFS-READ-TRUNCATED  requires a >1 MiB file fixture; impractical to trigger in a unit example
        ; doc: @raisesnodemo U-STDFS-OPEN-FAIL  unreachable without the callout backend: with no stdfs.so loaded (the default / m-test-engine) the entry short-circuits to U-STDFS-NOT-WIRED before open(2) — verified $$available^STDFS()=0 → reading a nonexistent file raises NOT-WIRED, not OPEN-FAIL; reaching OPEN-FAIL needs the .so loaded AND a failing open(2)
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"set x=$$readBytes^STDFS(""/tmp/blob.bin"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, readBytes raises NOT-WIRED")
        ; doc: @illustrative  happy path needs stdfs.so loaded (set ydb_xc_stdfs): set blob=$$readBytes^STDFS("/tmp/blob.bin") returns the file bytes verbatim; U-STDFS-OPEN-FAIL and U-STDFS-READ-TRUNCATED need the .so loaded plus, respectively, a failing open(2) and a file over the 1 MiB cap — both require the callout backend
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$readFile^STDFS, do writeBytes^STDFS
        ; doc: For text I/O with newline-joining and CRLF normalisation,
        ; doc: prefer $$readFile^STDFS instead.
        new out
        if '$$available() set $ecode=",U-STDFS-NOT-WIRED," quit ""
        set out=$$dispatchRead("readBytes",path)
        quit out
        ;
available()     ; 1 iff the stdfs callout is loaded and open(2) is reachable.
        ; doc: @returns       bool    1 iff stdfs.so is loaded; 0 otherwise
        ; doc: @example       do true^STDASSERT(.pass,.fail,($$available^STDFS()=0)!($$available^STDFS()=1),"available returns a 0/1 flag")
        ; doc: @illustrative  guard pattern: `if '$$available^STDFS() do warn^MYAPP("byte-faithful I/O unavailable")`
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           do writeBytes^STDFS, $$readBytes^STDFS
        ; doc: Never raises — clears $ECODE on the way out.
        new $etrap,rc,cmd
        if $$env^STDOS("ydb_xc_stdfs")="" quit 0
        set $etrap="set $ecode="""" set rc=0 quit"
        set rc=0
        set cmd="set rc=$&stdfs.available()"
        xecute cmd
        set $ecode=""
        quit +rc
        ;
        ; ---------- internal helpers ----------
        ;
readLn(eof)     ; Read the next line from the CURRENT device; portable EOF.
        ; doc: @internal
        ; doc: YDB sets $ZEOF at end-of-file; IRIS instead throws <ENDOFFILE>
        ; doc: on the read past the last line. This normalises both: returns the
        ; doc: line and sets eof=1 at EOF (line "" then). Real lines — including a
        ; doc: final non-terminated one — come back with eof=0, so callers loop
        ; doc: `for set line=$$readLn(.eof) quit:eof&(line="")  do <process>`.
        ; doc: The IRIS catch clears $ECODE — EOF is a normal loop terminator here
        ; doc: (YDB's $ZEOF path never sets it), so a leftover would falsely trip a
        ; doc: caller's post-read `if $ecode'=""` check (e.g. readLines/parseFile).
        new line
        set eof=0,line=""
        if $zversion["IRIS" xecute "try { read line } catch ex { set eof=1 set $ecode="""" }" quit line
        read line set eof=$zeof
        quit line
        ;
closeDelete(path)       ; Close path AND delete the file; portable.
        ; doc: @internal
        ; doc: YDB `close path:(delete)` ↔ IRIS `close path:"D"`. The IRIS form is
        ; doc: XECUTE'd so the YDB compiler never parses it (it rejects `:"D"` as
        ; doc: DEVPARPARSE) — same trick STDHARN uses to hide ZGOTO from IRIS.
        if $zversion["IRIS" xecute "close path:""D""" quit
        close path:(delete)
        quit
        ;
sizeIris(path)  ; IRIS exact file size via %File.GetFileSize (avoids the read tally).
        ; doc: @internal
        ; doc: IRIS read-loops can't reproduce YDB's per-terminator byte tally
        ; doc: (the final non-terminated line differs), so size() uses the
        ; doc: engine's own stat on IRIS. -1 if unreadable.
        new sz
        set sz=-1
        xecute "set sz=##class(%File).GetFileSize(path)"
        quit +sz
        ;
dispatch2(sym,path,data)        ; Two-input $&stdfs dispatch (writeBytes / appendBytes).
        ; doc: @internal
        ; doc: XECUTE-wraps $&stdfs.<label>(path,data) so the external-call
        ; doc: token stays out of the parse tree. sym is the underscore-free
        ; doc: .xc label (G-FS-YDB). Sets $ECODE on failure:
        ; doc: ,U-STDFS-NOT-WIRED, if the .so is unloaded;
        ; doc: ,U-STDFS-OPEN-FAIL, otherwise.
        new $etrap,rc,cmd
        if $$env^STDOS("ydb_xc_stdfs")="" set $ecode=",U-STDFS-NOT-WIRED," quit
        set $etrap="set $ecode="""" set rc=-1 quit"
        ; -99 sentinel (mirrors dispatch3^STDCRYPTO): the C side returns 1 ok /
        ; 0 fail / trap -1; a still--99 rc means the callout NEVER RAN.
        set rc=-99
        set cmd="set rc=$&stdfs."_sym_"(path,data)"
        xecute cmd
        set $etrap=""   ; disarm so the deliberate $ecode raises below reach the caller
        if (rc=-99)!(rc=-1) set $ecode=",U-STDFS-NOT-WIRED," quit
        if 'rc set $ecode=",U-STDFS-OPEN-FAIL," quit
        quit
        ;
dispatchRead(sym,path)  ; One-input / one-output $&stdfs dispatch (readBytes).
        ; doc: @internal
        ; doc: Preallocates a 1 MiB buffer (matching the .xc-declared cap —
        ; doc: YDB max string length; a larger .xc preallocation is rejected
        ; doc: at call-table load, %YDB-E-ZCPREALLVALINV),
        ; doc: invokes $&stdfs.<label>(path,.out), returns the filled bytes.
        new $etrap,rc,cmd,out
        if $$env^STDOS("ydb_xc_stdfs")="" set $ecode=",U-STDFS-NOT-WIRED," quit ""
        set $etrap="set $ecode="""" set rc=-1 quit"
        ; -99 sentinel (mirrors dispatch3^STDCRYPTO): the C side returns 1 ok /
        ; 0 fail / trap -1; a still--99 rc means the callout NEVER RAN.
        set rc=-99
        set out=$$preallocBuf()
        set cmd="set rc=$&stdfs."_sym_"(path,.out)"
        xecute cmd
        set $etrap=""   ; disarm so the deliberate $ecode raises below reach the caller
        if (rc=-99)!(rc=-1) set $ecode=",U-STDFS-NOT-WIRED," quit ""
        if 'rc do  quit ""
        . new err
        . set err=$$lasterror()
        . if err["U-STDFS-READ-TRUNCATED" set $ecode=",U-STDFS-READ-TRUNCATED," quit
        . set $ecode=",U-STDFS-OPEN-FAIL,"
        quit out
        ;
preallocBuf()   ; 1 MiB pre-allocated output buffer for the C side to fill.
        ; doc: @internal
        ; doc: YDB callouts need the M-side string at full capacity before
        ; doc: the C side writes into it. 1 MiB is YDB's maximum string
        ; doc: length — the old 16 MiB figure was never constructible and
        ; doc: its .xc preallocation red-carded the whole call table
        ; doc: (%YDB-E-ZCPREALLVALINV) — G-FS-YDB, 2026-07-22.
        quit $justify("",1048576)
        ;
lasterror()     ; Return the C-side last-error message ("" if none).
        ; doc: @internal
        ; doc: readBytes uses this to distinguish OPEN-fail from
        ; doc: READ-TRUNCATED. Soft-fails to "" if the callout is missing.
        new $etrap,rc,cmd,out
        if $$env^STDOS("ydb_xc_stdfs")="" quit ""
        set $etrap="set $ecode="""" set rc=0 quit"
        set rc=0
        set out=$justify("",1024)
        set cmd="set rc=$&stdfs.lastError(.out)"
        xecute cmd
        set $ecode=""
        quit out
        ;
