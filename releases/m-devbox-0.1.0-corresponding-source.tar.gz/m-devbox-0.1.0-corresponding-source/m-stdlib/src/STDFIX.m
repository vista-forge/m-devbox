STDFIX  ; m-stdlib — fixture lifecycle and per-test isolation.
        ; doc: @tag v0.1.1
        ; doc: @phase Phase 1b
        ;
        ; YDB nested-transaction-based isolation. YDB enforces TPQUIT:
        ; ``tstart`` and the matching ``trollback`` MUST live in the same
        ; routine frame. STDFIX therefore exposes only one-shot wrappers —
        ; ``with`` and ``invoke`` open AND close their scope before
        ; returning. There is no standalone setup() / teardown() pair.
        ;
        ; Public labels:
        ;   with(tag,code)         ; XECUTEs code inside an auto-managed
        ;                            transaction scope; rolls back on exit
        ;                            and re-raises any error code raised
        ;                            inside ``code``.
        ;   $$active()             ; → 1 if any nested transaction is open
        ;                            (any TSTART, not just STDFIX-owned).
        ;   register(tag,setupCode,teardownCode)  ; declarative fixture
        ;   invoke(tag,code)       ; fixture-aware variant of with(): runs
        ;                            registered setup hook, then code, then
        ;                            registered teardown hook — all inside
        ;                            one rolled-back scope.
        ;   cleanup                ; idempotent rollback of any leaked
        ;                            transaction scope; safe at $tlevel=0.
        ;
        ; State layout (under ^STDLIB($job,"FIX",...)):
        ;   STACK,$tlevel = tag    ; one entry per open scope, set inside
        ;                            the transaction so TROLLBACK erases it.
        ;   REG,tag,"SETUP"        ; registered setup code
        ;   REG,tag,"TEARDOWN"     ; registered teardown code
        ;
        ; ``trollback target`` (target = the pre-tstart $tlevel) rolls back
        ; exactly the level this frame opened, so nested with()/invoke() pairs
        ; roll back inner-only — bare ``trollback`` (which targets level 0) would
        ; unbalance every outer transaction.
        ;
        ; Engine portability (YDB + IRIS): YDB ``trollback n`` rolls back TO level
        ; n; IRIS ``trollback n`` rolls back n LEVELS (opposite meaning), so the
        ; rollback is engine-split — IRIS uses ``trollback $tlevel-target``. Full
        ; partial-rollback fidelity holds on both (nested inner-only rollback works
        ; on IRIS too). REQUIREMENT: IRIS needs the namespace's database to be
        ; JOURNALED for ``TSTART`` (an unjournaled db faults ``<UNIMPLEMENTED>``);
        ; STDFIX is therefore usable only on a journaled IRIS namespace. (TSTART is
        ; also forbidden lexically inside an IRIS ``try{}``/``xecute``, but STDFIX's
        ; own tstart is a direct command, so this never bites here.)
        ;
        ; Errors set $ECODE to one of:
        ;   ,U-STDFIX-EMPTY-TAG,
        ;   ,U-STDFIX-UNREGISTERED-TAG,
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
with(tag,code)  ; XECUTE code inside an auto-managed transaction scope.
        ; doc: @param tag     string  scope identifier (recorded in the stack)
        ; doc: @param code    string  M code XECUTEd inside the transaction
        ; doc: @raises        U-STDFIX-EMPTY-TAG  tag is empty
        ; doc: @example       kill ^STDLIB($job,"FIX","DEMO") do with^STDFIX("scope","set ^STDLIB($job,""FIX"",""DEMO"")=1") do false^STDASSERT(.pass,.fail,$data(^STDLIB($job,"FIX","DEMO")),"a set inside with() is rolled back on exit")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do with^STDFIX("""",""set x=1"")","U-STDFIX-EMPTY-TAG","empty tag raises")
        ; doc: @since         v0.1.1
        ; doc: @stable        stable
        ; doc: @see           do invoke^STDFIX, do register^STDFIX, do cleanup^STDFIX
        ; doc: Opens a YDB transaction, sets the scope tag in the stack,
        ; doc: XECUTEs code, then ``trollback $tlevel-1`` to roll back
        ; doc: exactly this scope. If code raises, the trap rolls back the
        ; doc: scope and re-raises so the caller can observe the original
        ; doc: $ECODE.
        new $etrap,saved,target
        if tag="" set $ecode=",U-STDFIX-EMPTY-TAG," quit
        set saved="",target=$tlevel
        ; YDB `trollback N` rolls back TO level N; IRIS `trollback N` rolls back N
        ; LEVELS. Both must undo exactly back to `target` (this scope's one tstart),
        ; so the rollback form is engine-split — on IRIS use `trollback $tlevel-target`.
        if $zversion["IRIS" set $etrap="set saved=$ecode set $ecode="""" if $tlevel>target trollback $tlevel-target  set $ecode=saved quit"
        else  set $etrap="set saved=$ecode set $ecode="""" if $tlevel>target trollback target  set $ecode=saved quit"
        tstart
        set ^STDLIB($job,"FIX","STACK",$tlevel)=tag
        ; m-lint: disable-next-line=M-MOD-036
        xecute code  ; XECUTE-of-arg is the documented purpose of with().
        ; m-lint: disable-next-line=M-MOD-009
        if $zversion["IRIS" trollback $tlevel-target
        ; m-lint: disable-next-line=M-MOD-009
        else  trollback target  ; matches the tstart above; preserves outer scopes.
        quit
        ;
active()        ; Predicate — is any nested transaction currently open?
        ; doc: @returns       bool    1 if $tlevel > 0; 0 otherwise
        ; doc: @example       write $$active^STDFIX()  ; 0
        ; doc: @since         v0.1.1
        ; doc: @stable        stable
        ; doc: @see           do with^STDFIX, do cleanup^STDFIX
        ; doc: STDFIX-managed scopes also appear in ^STDLIB($job,"FIX","STACK",N)
        ; doc: for callers that need to distinguish their own from foreign transactions.
        quit $select($tlevel>0:1,1:0)
        ;
register(tag,setupCode,teardownCode)    ; Declare a reusable setup/teardown pair.
        ; doc: @param tag           string  fixture tag
        ; doc: @param setupCode     string  M code XECUTEd before the body in invoke()
        ; doc: @param teardownCode  string  M code XECUTEd after the body in invoke()
        ; doc: @raises              U-STDFIX-EMPTY-TAG  tag is empty
        ; doc: @example             do register^STDFIX("db","do reset^X","do drop^X") do eq^STDASSERT(.pass,.fail,$get(^STDLIB($job,"FIX","REG","db","SETUP")),"do reset^X","setup hook is recorded")
        ; doc: @example             do raises^STDASSERT(.pass,.fail,"do register^STDFIX("""",""a"",""b"")","U-STDFIX-EMPTY-TAG","empty tag raises")
        ; doc: @since               v0.1.1
        ; doc: @stable              stable
        ; doc: @see                 do invoke^STDFIX
        if tag="" set $ecode=",U-STDFIX-EMPTY-TAG," quit
        set ^STDLIB($job,"FIX","REG",tag,"SETUP")=setupCode
        set ^STDLIB($job,"FIX","REG",tag,"TEARDOWN")=teardownCode
        quit
        ;
invoke(tag,code)        ; Run code with registered hooks wrapping it.
        ; doc: @param tag     string  fixture tag previously declared via register()
        ; doc: @param code    string  M code XECUTEd between the registered setup/teardown
        ; doc: @raises        U-STDFIX-UNREGISTERED-TAG  tag was never register()ed
        ; doc: @example       kill ^STDLIB($job,"FIX","DEMO") do register^STDFIX("ivk","set ^STDLIB($job,""FIX"",""DEMO"")=1","") do invoke^STDFIX("ivk","") do false^STDASSERT(.pass,.fail,$data(^STDLIB($job,"FIX","DEMO")),"setup hook ran then rolled back")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"do invoke^STDFIX(""neverRegistered"",""set x=1"")","U-STDFIX-UNREGISTERED-TAG","unregistered tag raises")
        ; doc: @since         v0.1.1
        ; doc: @stable        stable
        ; doc: @see           do register^STDFIX, do with^STDFIX
        ; doc: Looks up registered setup/teardown for tag, then runs setup
        ; doc: (if any), code, teardown (if any) — all inside one transaction
        ; doc: that rolls back on exit.
        new $etrap,saved,target,setup,teardown
        if '$data(^STDLIB($job,"FIX","REG",tag)) set $ecode=",U-STDFIX-UNREGISTERED-TAG," quit
        set saved="",target=$tlevel
        ; engine-split rollback (see with(): YDB rolls back TO level, IRIS by count).
        if $zversion["IRIS" set $etrap="set saved=$ecode set $ecode="""" if $tlevel>target trollback $tlevel-target  set $ecode=saved quit"
        else  set $etrap="set saved=$ecode set $ecode="""" if $tlevel>target trollback target  set $ecode=saved quit"
        set setup=$get(^STDLIB($job,"FIX","REG",tag,"SETUP"))
        set teardown=$get(^STDLIB($job,"FIX","REG",tag,"TEARDOWN"))
        tstart
        set ^STDLIB($job,"FIX","STACK",$tlevel)=tag
        ; m-lint: disable-next-line=M-MOD-036
        if setup'="" xecute setup
        ; m-lint: disable-next-line=M-MOD-036
        xecute code
        ; m-lint: disable-next-line=M-MOD-036
        if teardown'="" xecute teardown
        ; m-lint: disable-next-line=M-MOD-009
        if $zversion["IRIS" trollback $tlevel-target
        ; m-lint: disable-next-line=M-MOD-009
        else  trollback target  ; matches the tstart above; preserves outer scopes.
        quit
        ;
cleanup ; Best-effort rollback of any leaked transaction scope.
        ; doc: @example       do cleanup^STDFIX do eq^STDASSERT(.pass,.fail,$$active^STDFIX(),0,"no open transaction remains after cleanup")
        ; doc: @since         v0.1.1
        ; doc: @stable        stable
        ; doc: @see           do with^STDFIX, $$active^STDFIX
        ; doc: TROLLBACKs all the way to $tlevel=0 if any transaction is
        ; doc: open; safe to call at $tlevel=0 (no-op). Useful as a
        ; doc: defensive between-tests reset in runner code. Note: this
        ; doc: rolls back NON-STDFIX transactions too — call only at a
        ; doc: top-level frame that owns no enclosing tstart.
        ; m-lint: disable-next-line=M-MOD-009
        if $tlevel>0 trollback
        quit
        ;
