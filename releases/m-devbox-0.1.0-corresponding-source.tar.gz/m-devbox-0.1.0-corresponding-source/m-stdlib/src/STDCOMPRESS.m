STDCOMPRESS     ; m-stdlib — gzip / deflate / zstd via $&stdcompress callouts.
        ; doc: @tag v0.4.0
        ; doc: @phase Phase 3 + post-P4 wave
        ; doc: @tier optional
        ; doc: @exrun ydb
        ; m-lint: disable-file=M-MOD-024
        ; m-lint: disable-file=M-MOD-036
        ; m-lint: disable-file=M-MOD-020
        ; M-MOD-024 false positives: rc / out are initialised before every
        ; XECUTE'd $& call but the analyser cannot follow flow through the
        ; XECUTE indirection.
        ; M-MOD-036 (XECUTE injection) is intentional: the XECUTE wrapper is
        ; the only way to invoke $&pkg.fn from M code that tree-sitter-m can
        ; still parse — same trick as STDCRYPTO. The XECUTE source is built
        ; from a literal template plus a `sym` symbol that the M-side public
        ; surface controls; no user data flows into the XECUTE string.
        ; M-MOD-020 (by-ref formal not written) false positives: dispatch
        ; helpers write to `out` via the XECUTE'd $& call.
        ;
        ; Public extrinsics (output via .out byref; return 1=ok / 0=fail):
        ;   $$gzip^STDCOMPRESS(data,.out[,level])           — RFC 1952 gzip
        ;   $$gunzip^STDCOMPRESS(data,.out)                 — RFC 1952 gunzip
        ;   $$deflate^STDCOMPRESS(data,.out[,level])        — RFC 1951 deflate
        ;   $$inflate^STDCOMPRESS(data,.out)                — RFC 1951 inflate
        ;   $$zstdCompress^STDCOMPRESS(data,.out[,level])   — RFC 8478 zstd
        ;   $$zstdDecompress^STDCOMPRESS(data,.out)         — RFC 8478 zstd
        ;   $$available^STDCOMPRESS()                       — ""=ok, else missing
        ;
        ; Errors set $ECODE: ,U-STDCOMPRESS-CALLOUT-MISSING, (.so unloaded);
        ; ,U-STDCOMPRESS-BAD-LEVEL, (level out of range); ,U-STDCOMPRESS-LIBZ-FAIL,
        ; (libz returned non-Z_STREAM_END); ,U-STDCOMPRESS-LIBZSTD-FAIL, (zstd
        ; returned an error frame).
        ;
        ; Levels: gzip / deflate accept 1..9 (default 6); zstd accepts 1..22
        ; (default 3). Level 0 (no compression) is rejected to avoid surprise
        ; pass-through.
        ;
        ; Output cap: 1 MiB per call (YDB's max M-string length on this
        ; build; declared in tools/std_compress.xc). Streaming for larger
        ; payloads is queued.
        ;
        ; Backend (engine-branched in dispatchC / dispatchD on $zversion["IRIS"):
        ;   YottaDB: $&stdcompress.<sym> → libz (gzip / deflate) + libzstd
        ;            (zstd). Source src/callouts/stdcompress.c; descriptor
        ;            tools/std_compress.xc.
        ;   IRIS:    embedded Python — zlib (wbits 31 gzip / -15 raw deflate)
        ;            and libzstd.so.1 via ctypes (no zstd Python module is
        ;            shipped, but the system .so is). M<->Python binary is
        ;            bridged latin-1 (codepoint==byte). Same wire formats
        ;            (RFC 1952 / 1951 / 8478), so the *TST.m vectors hold on
        ;            both engines.
        ;
        ; Deployment runbook (full detail in docs/modules/stdcompress.md):
        ;   1. tools/build-callouts.sh                  ; produce so/<plat>/stdcompress.so
        ;   2. export STDLIB_LIB=<dir-of-so>
        ;   3. export ydb_xc_stdcompress=<abs>/tools/std_compress.xc
        ;   4. ensure libz.so.1 + libzstd.so.1 are on the loader path
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
gzip(data,out,level)    ; RFC 1952 gzip-format compress.
        ; doc: @param data    byte-string  one M character per byte
        ; doc: @param out     byte-string  by-ref local; populated with compressed bytes
        ; doc: @param level   int          compression level 1..9 (default 6)
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-BAD-LEVEL       level outside 1..9
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING  .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZ-FAIL        libz reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZ-FAIL  libz does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$gzip^STDCOMPRESS("hello",.buf) set rt=$$gunzip^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"hello","gzip then gunzip round-trips 'hello'")
        ; doc: @example       set ok=$$gzip^STDCOMPRESS("hello",.buf) do eq^STDASSERT(.pass,.fail,$ascii(buf),31,"gzip output starts with magic byte 0x1F")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new buf set ok=$$gzip^STDCOMPRESS(""x"",.buf,0)","U-STDCOMPRESS-BAD-LEVEL","gzip level 0 raises BAD-LEVEL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process); LIBZ-FAIL on compress needs a forced libz failure; corrupt-input LIBZ-FAIL is shown under $$gunzip
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$gunzip^STDCOMPRESS, $$deflate^STDCOMPRESS
        new lvl,st
        set lvl=$$libzLevel($get(level,6))
        if lvl=-1 set $ecode=",U-STDCOMPRESS-BAD-LEVEL," quit 0
        set st=$$dispatchC("gzip",data,.out,lvl)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZ-FAIL,") quit 0
        ;
gunzip(data,out)        ; RFC 1952 gunzip.
        ; doc: @param data    byte-string  gzip-format compressed bytes
        ; doc: @param out     byte-string  by-ref local; populated with raw bytes
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING  .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZ-FAIL        libz reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZ-FAIL  libz does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$gzip^STDCOMPRESS("payload",.buf) set rt=$$gunzip^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"payload","gunzip recovers the original bytes")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new raw set ok=$$gunzip^STDCOMPRESS(""not a gzip stream"",.raw)","LIBZ-FAIL","gunzip of non-gzip raises LIBZ-FAIL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process)
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$gzip^STDCOMPRESS
        new st
        set st=$$dispatchD("gunzip",data,.out)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZ-FAIL,") quit 0
        ;
deflate(data,out,level) ; RFC 1951 raw deflate (no header / trailer).
        ; doc: @param data    byte-string
        ; doc: @param out     byte-string  by-ref local; populated with deflated bytes
        ; doc: @param level   int          compression level 1..9 (default 6)
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-BAD-LEVEL        level outside 1..9
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING  .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZ-FAIL        libz reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZ-FAIL  libz does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$deflate^STDCOMPRESS("hello",.buf) set rt=$$inflate^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"hello","deflate then inflate round-trips 'hello'")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new buf set ok=$$deflate^STDCOMPRESS(""x"",.buf,10)","U-STDCOMPRESS-BAD-LEVEL","deflate level 10 raises BAD-LEVEL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process); LIBZ-FAIL on compress needs a forced libz failure; corrupt-input LIBZ-FAIL is shown under $$inflate
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$inflate^STDCOMPRESS, $$gzip^STDCOMPRESS
        new lvl,st
        set lvl=$$libzLevel($get(level,6))
        if lvl=-1 set $ecode=",U-STDCOMPRESS-BAD-LEVEL," quit 0
        set st=$$dispatchC("deflate",data,.out,lvl)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZ-FAIL,") quit 0
        ;
inflate(data,out)       ; RFC 1951 raw inflate.
        ; doc: @param data    byte-string  raw deflated bytes
        ; doc: @param out     byte-string  by-ref local; populated with raw bytes
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING  .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZ-FAIL        libz reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZ-FAIL  libz does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$deflate^STDCOMPRESS("payload",.buf) set rt=$$inflate^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"payload","inflate recovers the original bytes")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new raw set ok=$$inflate^STDCOMPRESS($char(0,0,0,0,0),.raw)","LIBZ-FAIL","inflate of garbage raises LIBZ-FAIL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process)
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$deflate^STDCOMPRESS
        new st
        set st=$$dispatchD("inflate",data,.out)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZ-FAIL,") quit 0
        ;
zstdCompress(data,out,level)    ; Zstandard (RFC 8478) compress.
        ; doc: @param data    byte-string
        ; doc: @param out     byte-string  by-ref local; populated with compressed bytes
        ; doc: @param level   int          compression level 1..22 (default 3)
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-BAD-LEVEL         level outside 1..22
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING   .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZSTD-FAIL      libzstd reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZSTD-FAIL  libzstd does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$zstdCompress^STDCOMPRESS("hello",.buf) set rt=$$zstdDecompress^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"hello","zstd compress then decompress round-trips 'hello'")
        ; doc: @example       set ok=$$zstdCompress^STDCOMPRESS("hello",.buf) do eq^STDASSERT(.pass,.fail,$ascii(buf),40,"zstd output starts with magic byte 0x28")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new buf set ok=$$zstdCompress^STDCOMPRESS(""x"",.buf,23)","U-STDCOMPRESS-BAD-LEVEL","zstd level 23 raises BAD-LEVEL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process); LIBZSTD-FAIL on compress needs a forced libzstd failure; corrupt-input LIBZSTD-FAIL is shown under $$zstdDecompress
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$zstdDecompress^STDCOMPRESS
        new lvl,st
        set lvl=$$zstdLevel($get(level,3))
        if lvl=-1 set $ecode=",U-STDCOMPRESS-BAD-LEVEL," quit 0
        set st=$$dispatchC("zstdCompress",data,.out,lvl)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZSTD-FAIL,") quit 0
        ;
zstdDecompress(data,out)        ; Zstandard decompress.
        ; doc: @param data    byte-string  zstd-compressed bytes
        ; doc: @param out     byte-string  by-ref local; populated with raw bytes
        ; doc: @returns       bool         1 on success; 0 with $ECODE on failure
        ; doc: @raises        U-STDCOMPRESS-CALLOUT-MISSING   .so unloaded
        ; doc: @raisesnodemo U-STDCOMPRESS-CALLOUT-MISSING  the call-out library is present on a healthy engine; this fires only when it is absent
        ; doc: @raises        U-STDCOMPRESS-LIBZSTD-FAIL      libzstd reported failure
        ; doc: @raisesnodemo U-STDCOMPRESS-LIBZSTD-FAIL  libzstd does not fail on valid input; not triggerable on a healthy engine
        ; doc: @example       set rt=$$zstdCompress^STDCOMPRESS("payload",.buf) set rt=$$zstdDecompress^STDCOMPRESS(buf,.raw) do eq^STDASSERT(.pass,.fail,raw,"payload","zstd decompress recovers the original bytes")
        ; doc: @example       do raises^STDASSERT(.pass,.fail,"new raw set ok=$$zstdDecompress^STDCOMPRESS(""not a zstd frame"",.raw)","LIBZSTD-FAIL","zstd decompress of non-zstd raises LIBZSTD-FAIL")
        ; doc: @illustrative  CALLOUT-MISSING needs the stdcompress .so unloaded (deployment-environment state, not reproducible in-process)
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$zstdCompress^STDCOMPRESS
        new st
        set st=$$dispatchD("zstdDecompress",data,.out)
        if st="" quit 1
        set $ecode=$select(st="MISSING":",U-STDCOMPRESS-CALLOUT-MISSING,",1:",U-STDCOMPRESS-LIBZSTD-FAIL,") quit 0
        ;
available()     ; "" iff both libz and libzstd loaded; else missing list.
        ; doc: @returns       string  "" if both backends OK; comma-separated names of missing libs otherwise
        ; doc: @example       write $$available^STDCOMPRESS()  ; ""
        ; doc: @since         v0.4.0
        ; doc: @stable        stable
        ; doc: @see           $$gzip^STDCOMPRESS, $$zstdCompress^STDCOMPRESS
        ; doc: Probes by attempting an empty round-trip on each backend.
        ; doc: Never raises — clears $ECODE on the way out.
        new gz,zstd,buf,miss
        set gz=$$gzip("",.buf,6)
        set zstd=$$zstdCompress("",.buf,3)
        set $ecode=""
        set miss=""
        if 'gz set miss="libz"
        if 'zstd set miss=$select(miss="":"libzstd",1:miss_",libzstd")
        quit miss
        ;
        ; ---------- internal helpers ----------
        ;
libzLevel(n)    ; Validate libz compression level — 1..9 valid, else -1.
        ; doc: @internal
        ; doc: Level 0 (no compression) deliberately rejected.
        if n'=(n+0) quit -1
        if n<1 quit -1
        if n>9 quit -1
        quit n
        ;
zstdLevel(n)    ; Validate zstd compression level — 1..22 valid, else -1.
        ; doc: @internal
        ; doc: Negative levels (--fast tier) deferred.
        if n'=(n+0) quit -1
        if n<1 quit -1
        if n>22 quit -1
        quit n
        ;
preallocBuf()   ; 1 MiB pre-allocated output buffer for the C side to fill.
        ; doc: @internal
        ; doc: YDB callouts need the M-side string at full capacity before
        ; doc: the C side writes into it. 1,048,576 is YDB's max M-string
        ; doc: on r2.02 — the engine ceiling exactly, not a tunable. YDB
        ; doc: $ZF arm only: dispatchC/dispatchD route IRIS to the Python
        ; doc: backend before reaching this buffer, so IRIS never uses it
        ; doc: (measured on foia: a >1 MiB gzip round-trips byte-exact
        ; doc: with no prealloc in the path).
        quit $justify("",1048576)
        ;
dispatchC(sym,data,out,lvl)     ; Compress dispatch — 3-arg $&. Returns status.
        ; doc: @internal
        ; doc: XECUTE-wraps $&stdcompress.<sym>(data,.out,lvl).
        ; doc: Returns "" on success, "MISSING" if .so unloaded,
        ; doc: "FAIL" if libz/libzstd returned non-success. On IRIS, branches
        ; doc: to the embedded-Python backend (irisC).
        if $zversion["IRIS" quit $$irisC($$irisFn(sym),data,.out,lvl)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-1 quit ""MISSING"""
        set rc=0
        set out=$$preallocBuf()
        set cmd="set rc=$&stdcompress."_sym_"(data,.out,lvl)"
        xecute cmd
        if rc=-1 quit "MISSING"
        if 'rc quit "FAIL"
        quit ""
        ;
dispatchD(sym,data,out)         ; Decompress dispatch — 2-arg $&. Returns status.
        ; doc: @internal
        ; doc: Same XECUTE-wrap rationale as dispatchC. On IRIS, branches to
        ; doc: the embedded-Python backend (irisD).
        if $zversion["IRIS" quit $$irisD($$irisFn(sym),data,.out)
        new $etrap,rc,cmd
        set $etrap="set $ecode="""" set rc=-1 quit ""MISSING"""
        set rc=0
        set out=$$preallocBuf()
        set cmd="set rc=$&stdcompress."_sym_"(data,.out)"
        xecute cmd
        if rc=-1 quit "MISSING"
        if 'rc quit "FAIL"
        quit ""
        ;
        ; ---------- IRIS-native backend (embedded Python: zlib + ctypes/zstd) -
        ; IRIS has no $&pkg.fn ABI and ships no string-level gzip/zstd class, so
        ; the IRIS arm drives embedded Python: zlib (wbits 31 gzip / -15 raw
        ; deflate) and libzstd.so.1 via ctypes. M<->Python binary is bridged by
        ; latin-1 (codepoint==byte for 0..255). The helpers are defined once per
        ; process in __main__; every IRIS call is XECUTE-wrapped so tree-sitter-m
        ; never sees ##class / OREF-dot syntax (same rationale as the $& wrap).
        ;
irisFn(sym)     ; Map a YDB callout symbol to its Python helper name.
        ; doc: @internal
        quit $select(sym="gzip":"gz",sym="deflate":"df",sym="zstdCompress":"zc",sym="gunzip":"gunz",sym="inflate":"inf",sym="zstdDecompress":"zd",1:"")
        ;
irisInit()      ; Define the zlib/zstd Python helpers in __main__.
        ; doc: @internal
        ; doc: Re-run per call (idempotent): redefining the helpers in
        ; doc: __main__ is cheap and ctypes.CDLL of an already-loaded .so
        ; doc: refcounts the same handle rather than reloading. A per-process
        ; doc: memo via a `^||` process-private global was dropped — the
        ; doc: pinned tree-sitter-m grammar can't parse `^||` (discoveries
        ; doc: 2026-06-14), and the re-exec cost is negligible vs the codec.
        new c,b,main
        set c="import zlib,ctypes"_$char(10)
        set c=c_"def gz(s,l):"_$char(10)_" o=zlib.compressobj(l,zlib.DEFLATED,31);return (o.compress(s.encode('latin-1'))+o.flush()).decode('latin-1')"_$char(10)
        set c=c_"def gunz(s):"_$char(10)_" return zlib.decompress(s.encode('latin-1'),31).decode('latin-1')"_$char(10)
        set c=c_"def df(s,l):"_$char(10)_" o=zlib.compressobj(l,zlib.DEFLATED,-15);return (o.compress(s.encode('latin-1'))+o.flush()).decode('latin-1')"_$char(10)
        set c=c_"def inf(s):"_$char(10)_" return zlib.decompress(s.encode('latin-1'),-15).decode('latin-1')"_$char(10)
        set c=c_"_z=ctypes.CDLL('libzstd.so.1')"_$char(10)
        set c=c_"_z.ZSTD_compressBound.restype=ctypes.c_size_t"_$char(10)
        set c=c_"_z.ZSTD_compress.restype=ctypes.c_size_t"_$char(10)
        set c=c_"_z.ZSTD_decompress.restype=ctypes.c_size_t"_$char(10)
        set c=c_"_z.ZSTD_isError.restype=ctypes.c_uint"_$char(10)
        set c=c_"_z.ZSTD_getFrameContentSize.restype=ctypes.c_ulonglong"_$char(10)
        set c=c_"def zc(s,l):"_$char(10)_" src=s.encode('latin-1');cap=_z.ZSTD_compressBound(len(src));d=ctypes.create_string_buffer(cap);n=_z.ZSTD_compress(d,cap,src,len(src),l);return d.raw[:n].decode('latin-1')"_$char(10)
        set c=c_"def zd(s):"_$char(10)_" src=s.encode('latin-1')"_$char(10)_" cs=_z.ZSTD_getFrameContentSize(src,len(src))"_$char(10)_" if cs>=2**64-2:"_$char(10)_"  raise ValueError('bad zstd frame')"_$char(10)
        set c=c_" d=ctypes.create_string_buffer(int(cs) if cs>0 else 1)"_$char(10)_" n=_z.ZSTD_decompress(d,int(cs),src,len(src))"_$char(10)
        set c=c_" if _z.ZSTD_isError(n):"_$char(10)_"  raise ValueError('zstd error')"_$char(10)_" return d.raw[:n].decode('latin-1')"_$char(10)
        xecute "set main=##class(%SYS.Python).Import(""__main__"")"
        xecute "set b=##class(%SYS.Python).Builtins()"
        xecute "do b.exec(c,main.""__dict__"")"
        quit
        ;
irisC(fn,data,out,lvl)  ; IRIS compress via the Python helper fn(data,lvl).
        ; doc: @internal
        ; doc: "" on success, "FAIL" if Python raised. The call is wrapped in an
        ; doc: ObjectScript try/catch, NOT an M $ETRAP: a Python <THROW> does not
        ; doc: unwind cleanly through $ETRAP (it hangs), but try/catch catches it
        ; doc: and the init+compress run as one guarded block.
        new ok
        if fn="" quit "FAIL"
        set ok=0
        xecute "try { do irisInit^STDCOMPRESS() set out=##class(%SYS.Python).Import(""__main__"")."_fn_"(data,lvl) set ok=1 } catch ex { set ok=0 }"
        quit $select(ok:"",1:"FAIL")
        ;
irisD(fn,data,out)      ; IRIS decompress via the Python helper fn(data).
        ; doc: @internal
        ; doc: "" on success, "FAIL" if Python raised (corrupt input). Same
        ; doc: ObjectScript try/catch rationale as irisC.
        new ok
        if fn="" quit "FAIL"
        set ok=0
        xecute "try { do irisInit^STDCOMPRESS() set out=##class(%SYS.Python).Import(""__main__"")."_fn_"(data) set ok=1 } catch ex { set ok=0 }"
        quit $select(ok:"",1:"FAIL")
        ;
