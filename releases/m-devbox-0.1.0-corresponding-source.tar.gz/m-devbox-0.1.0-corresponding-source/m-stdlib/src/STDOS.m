STDOS   ; m-stdlib — Process / env / cmdline helpers (dual-engine: YDB + IRIS).
        ; doc: @tag v0.3.0
        ; doc: @phase P4 wave
        ; m-lint: disable-file=M-MOD-020
        ; m-lint: disable-file=M-MOD-021
        ; m-lint: disable-file=M-MOD-022
        ; m-lint: disable-file=M-MOD-023
        ; M-MOD-020: splitArgs writes to its by-ref second formal `args` but
        ; not to `s`; the by-ref analyzer flags every caller as a candidate
        ; without seeing the `args` write inside splitArgs.
        ; M-MOD-021/022/023: STDOS is a thin layer over $ZTRNLNM / $J /
        ; $ZCMDLINE / ZHALT — YDB extensions to the M standard. Each label now
        ; has an IRIS arm ($zversion["IRIS"): env→$system.Util.GetEnviron,
        ; cwd→$system.Process.CurrentDirectory, user→$username,
        ; hostname→$system.INetInfo.LocalHostName (all xecute-hidden so YDB never
        ; parses the $system.*/$username references); cmdline (and argc/arg/argv
        ; built on it) return ""/0 on IRIS, which has no $ZCMDLINE process-args
        ; model. The YDB intrinsics still drive the YDB arm, hence the disables.
        ;
        ; Public extrinsics:
        ;   $$env^STDOS(name)            — environment variable lookup ("" if unset)
        ;   $$pid^STDOS()                — current process ID (integer)
        ;   $$cmdline^STDOS()            — raw $ZCMDLINE
        ;   $$splitArgs^STDOS(s,.args)   — populate args(1..N), return N
        ;   $$argc^STDOS()               — count of $ZCMDLINE arguments
        ;   $$arg^STDOS(i)               — i-th $ZCMDLINE arg (1-indexed; "" out of bounds)
        ;   argv^STDOS(.args)            — populate args(1..N) from $ZCMDLINE
        ;   $$cwd^STDOS()                — current working directory ($ZDIRECTORY / IRIS $system)
        ;   $$user^STDOS()               — current username (from $USER)
        ;   $$hostname^STDOS()           — host name (from $HOSTNAME; may be "")
        ;   exit^STDOS(rc)               — terminate the process with exit code rc
        ;
        ; Argument splitting in v1 is whitespace-only — runs of spaces are
        ; collapsed to a single separator and leading / trailing whitespace
        ; is dropped. Quote handling (single and double quotes preserving
        ; embedded spaces) lands in v0.2.y when STDARGS' quote-aware
        ; tokeniser is back-ported. For now, callers that need quote-aware
        ; parsing should pre-tokenise via the shell or use STDARGS directly.
        ;
        quit
        ;
        ; ---------- public API ----------
        ;
env(name)       ; Return the value of environment variable `name`, or "" if unset.
        ; doc: @param name    string  environment variable name
        ; doc: @returns       string  value, or "" if `name` is empty or unset
        ; doc: @example       write $$env^STDOS("")  ; ""
        ; doc: @illustrative  a populated lookup (e.g. $$env^STDOS("HOME")) is host-specific
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$user^STDOS, $$cwd^STDOS, $$hostname^STDOS
        if name="" quit ""
        if $zversion["IRIS" quit $$envIris(name)
        quit $ztrnlnm(name)
        ;
envIris(name)   ; IRIS environment-variable read (%SYSTEM.Util.GetEnviron).
        ; doc: @internal
        ; doc: IRIS arm of env(): $ztrnlnm is a YDB intrinsic, so on IRIS read the
        ; doc: variable via $system.Util.GetEnviron — XECUTE'd so the YDB compiler
        ; doc: never parses the $system.* reference. Returns "" for an unset name,
        ; doc: matching $ztrnlnm.
        new v
        set v=""
        ; m-lint: disable-next-line=M-MOD-036
        xecute "set v=$system.Util.GetEnviron(name)"
        quit v
        ;
pid()   ; Return the current process ID as an integer.
        ; doc: @returns       int     process ID
        ; doc: @example       do true^STDASSERT(.pass,.fail,$$pid^STDOS()>0,"pid is a positive integer")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: Equivalent to YDB's $J / $JOB special variable.
        quit +$job
        ;
cmdline()       ; Return the raw $ZCMDLINE string.
        ; doc: @returns       string  whole command-line tail (post-`-run ENTRY`), un-tokenised
        ; doc: @illustrative  the raw $ZCMDLINE tail is host/invocation-specific (varies per run)
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$argc^STDOS, $$arg^STDOS, do argv^STDOS, $$splitArgs^STDOS
        ; doc: IRIS has no $ZCMDLINE process-args model, so cmdline() returns ""
        ; doc: there (argc/arg/argv, built on this, then yield 0/empty). $zcmdline
        ; doc: compiles on IRIS but errors at runtime, so the guard returns first.
        if $zversion["IRIS" quit ""
        quit $zcmdline
        ;
splitArgs(s,args)       ; Tokenise `s` on whitespace; populate args(1..N); return N.
        ; doc: @param s       string  input string
        ; doc: @param args    array   by-ref local; killed then populated as args(1..N)
        ; doc: @returns       int     number of tokens
        ; doc: @example       new args do eq^STDASSERT(.pass,.fail,$$splitArgs^STDOS("a b c",.args),3,"three tokens")
        ; doc: @example       new args set args=$$splitArgs^STDOS("a b c",.args) do eq^STDASSERT(.pass,.fail,args(2),"b","second token")
        ; doc: @example       new args do eq^STDASSERT(.pass,.fail,$$splitArgs^STDOS("",.args),0,"empty input yields 0")
        ; doc: @example       new args do eq^STDASSERT(.pass,.fail,$$splitArgs^STDOS("  a   b  ",.args),2,"runs collapse, ends trimmed")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           do argv^STDOS, $$cmdline^STDOS
        ; doc: Runs of spaces collapse; leading and trailing whitespace are
        ; doc: dropped. Tab and LF are NOT treated as separators in v1
        ; doc: (cmdline tails rarely contain them). Empty input yields 0.
        kill args
        new trimmed,n,i,token,start
        if s="" quit 0
        ; Trim leading and trailing spaces.
        set trimmed=s
        for  quit:$extract(trimmed,1)'=" "  set trimmed=$extract(trimmed,2,$length(trimmed))
        for  quit:$extract(trimmed,$length(trimmed))'=" "  set trimmed=$extract(trimmed,1,$length(trimmed)-1)
        if trimmed="" quit 0
        ; Collapse runs of spaces and split via $piece.
        for  quit:trimmed'["  "  set trimmed=$$replaceDouble(trimmed)
        set n=$length(trimmed," ")
        for i=1:1:n  set args(i)=$piece(trimmed," ",i)
        quit n
        ;
argc()  ; Return the number of $ZCMDLINE arguments.
        ; doc: @returns       int     count of whitespace-separated tokens in $ZCMDLINE
        ; doc: @example       do true^STDASSERT(.pass,.fail,$$argc^STDOS()'<0,"argc is a non-negative count")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$arg^STDOS, do argv^STDOS
        new args
        quit $$splitArgs($$cmdline(),.args)
        ;
arg(i)  ; Return the i-th $ZCMDLINE argument (1-indexed); "" if out of bounds.
        ; doc: @param i       int     1-based argument index
        ; doc: @returns       string  the i-th token, or "" if i is out of bounds
        ; doc: @example       write $$arg^STDOS(0)  ; ""
        ; doc: @illustrative  an in-bounds read (e.g. $$arg^STDOS(1)) depends on the live $ZCMDLINE
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$argc^STDOS, do argv^STDOS
        new args,n
        if i<1 quit ""
        set n=$$splitArgs($$cmdline(),.args)
        if i>n quit ""
        quit args(i)
        ;
argv(args)      ; Populate args(1..N) from $ZCMDLINE; N is the implicit return.
        ; doc: @param args    array   by-ref local; killed then populated from $ZCMDLINE tokens
        ; doc: @example       new args do argv^STDOS(.args) do true^STDASSERT(.pass,.fail,1,"argv populates without error")
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$argc^STDOS, $$arg^STDOS, $$splitArgs^STDOS
        new n
        kill args
        set n=$$splitArgs($$cmdline(),.args)
        quit
        ;
cwd()   ; Return the current working directory.
        ; doc: @returns       path    absolute current working directory
        ; doc: @example       write $$cwd^STDOS()  ; "/..."
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$env^STDOS
        ; doc: YDB reads $ZDIRECTORY (the process working directory — always set,
        ; doc: and authoritative, unlike the $PWD env var which is absent in some
        ; doc: container `docker exec` contexts where the prior $PWD-based read
        ; doc: returned ""). On IRIS the value comes from
        ; doc: $system.Process.CurrentDirectory() (xecute-hidden; YDB can't parse
        ; doc: the $system.* reference). Both are absolute.
        if $zversion["IRIS" new d set d="" xecute "set d=$system.Process.CurrentDirectory()" quit d
        quit $zdirectory
        ;
user()  ; Return the current username (from $USER).
        ; doc: @returns       string  $USER if set; otherwise $LOGNAME; "" if neither
        ; doc: @illustrative  the current username is host/account-specific
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$env^STDOS, $$hostname^STDOS
        ; doc: Falls back to $LOGNAME if $USER is unset (System V convention).
        ; doc: On IRIS the value comes from the $USERNAME special variable
        ; doc: (xecute-hidden; YDB can't parse it) rather than the $USER env var.
        new u
        if $zversion["IRIS" set u="" xecute "set u=$username" quit u
        set u=$ztrnlnm("USER")
        if u="" set u=$ztrnlnm("LOGNAME")
        quit u
        ;
hostname()      ; Return the host name (from $HOSTNAME) or "" if unset.
        ; doc: @returns       string  value of $HOSTNAME; "" if unset
        ; doc: @illustrative  the host name is host-specific and may be "" in minimal containers
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: @see           $$env^STDOS, $$user^STDOS
        ; doc: $HOSTNAME is exported by some shells (bash) but stripped in
        ; doc: minimal containers; callers that always need a value should
        ; doc: wait on the $ZF→gethostname(2) callout backend. On IRIS the value
        ; doc: comes from $system.INetInfo.LocalHostName() (xecute-hidden), which
        ; doc: is always populated, not $HOSTNAME.
        if $zversion["IRIS" new h set h="" xecute "set h=$system.INetInfo.LocalHostName()" quit h
        quit $ztrnlnm("HOSTNAME")
        ;
exit(rc)        ; Terminate the YDB process with exit code rc (default 0).
        ; doc: @param rc      int     exit code; defaults to 0 if unsupplied
        ; doc: @illustrative  terminates the process immediately (ZHALT); cannot run inside a test suite
        ; doc: @since         v0.3.0
        ; doc: @stable        stable
        ; doc: Implemented via ZHALT. The process exits immediately; no
        ; doc: $ETRAP fires, no cleanup runs, no further M code executes.
        zhalt $get(rc,0)
        ;
        ; ---------- internal helpers ----------
        ;
replaceDouble(s)        ; Collapse one occurrence of "  " (two spaces) to " ".
        ; doc: @internal
        ; doc: Driven by splitArgs's run-collapse loop. The loop re-checks
        ; doc: containment so multi-run collapse converges in O(log n)
        ; doc: iterations.
        new before,after
        set before=$piece(s,"  ",1)
        set after=$piece(s,"  ",2,$length(s,"  "))
        quit before_" "_after
