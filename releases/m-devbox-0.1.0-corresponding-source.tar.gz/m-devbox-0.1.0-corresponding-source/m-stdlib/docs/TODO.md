---
created: 2026-04-30
last_modified: 2026-06-07
revisions: 15
doc_type: [STATUS]
---

# m-stdlib — resume-here TODO

**Status:** **`v0.4.0` shipped 2026-05-08** (tag `53ecf70`). 32
modules; 32 suites; **2483/2483 assertions green on engine**;
per-module label coverage ≥ 91% (most at 100%); 0 lint errors;
fmt clean across 65 files. **All numbered tracker tickets T1–T30
closed.** Phase 3 (`STDCRYPTO` H1, `STDCOMPRESS` H2, `STDHTTP` H3)
all engine-green; STDXML T26 closed (full XPath / DTD envelope);
STDFS T13/T14 closed (byte-faithful I/O); STDCSPRNG T12 closed
(`getrandom(2)` callout); deployment loop automated via
`scripts/seed-callouts.sh`.

## Live work board

The single source of truth for in-flight + proposed work is
[`module-tracker.md`](module-tracker.md).
This TODO is a thin pointer; do not duplicate state here.

> **2026-06-14 dual-engine validation** →
> [`dual-engine-validation-2026-06-14.md`](archive/dual-engine-validation-2026-06-14.md).
> YDB 49/49 (2585 assertions, 0 fail); IRIS 45/49. Prioritized backlog (B-1…B-6):
> **P1** B-1 (m-cli IRIS runner: no timeout, masks 0/0, contradictory stdout) ·
> **P1** B-6 (merge the B2 IRIS-native-backends PR — STDCRYPTO/STDCOMPRESS/STDCSPRNG
> hang/abort on IRIS without it) · **P2** B-2 (coverage gate is aggregate, not
> per-module) · P3 B-3/B-4/B-5. Fixes are per-repo follow-up sessions.

- **Summary table** — 32 shipped modules with Done / Tag / Effort /
  ToDo / Dependency / Headline / m-cli-integration. Per-module deep
  history (scaffolding, migrations, engine deploy, T-ticket closes)
  lives in each module's [`../modules/<m>.md` § History](../modules/)
  section.
- **Proposals** — at [`proposals/future-modules-plan.md`](proposals/future-modules-plan.md)
  (STDYAML, STDNET — both multi-session, deferred until concrete
  consumers drive them).

For dispatch view across all parallel tracks (L1–L27, H1–H3, m-cli
companion C-tracks, conformance-corpus A-tracks):
[`parallel-tracks.md`](archive/parallel-tracks.md).

## Three living docs

- [`../plans/completed/m-stdlib-implementation-plan.md`](../plans/completed/m-stdlib-implementation-plan.md)
  — per-module work plan (authoritative for v0.0.1 → v0.4.0 specs).
- [`../plans/completed/tdd-orchestration-plan.md`](../plans/completed/tdd-orchestration-plan.md)
  — m-stdlib ↔ m-cli joint milestones; M0–M5 fully realised.
  Operational follow-up is
  [`../guides/m-tdd-guide.md`](../guides/m-tdd-guide.md).
- [`parallel-tracks.md`](archive/parallel-tracks.md)
  — dispatch view; current execution status.

## Open work — optional add-ons

All gating tickets (T1–T30) closed. The remaining items in the
tracker are **optional add-ons** that activate only when a concrete
consumer drives them. None is gating any further release:

- **T15** — STDOS `setenv` / quote-aware `splitArgs` / IRIS arm via
  `$ZF → libc setenv/getcwd/gethostname`.
- **T16** — STDSEMVER range syntax extensions (`||` OR, hyphen
  ranges, `*` / `x` / `X` placeholders, prerelease-aware
  comparators, `^0.x.y` zero-major narrowing).
- **T17** — STDSTR Unicode whitespace + locale-aware case folding
  (deferred behind a future STDUNICODE).
- **T18** — STDTOML out-of-scope features (arrays, inline tables,
  dotted keys, array-of-tables, multi-line / literal strings, integer
  underscores + hex/oct/bin, special floats, exponent notation,
  datetime values).
- **T19** — STDCACHE rebase onto STDCOLL OrderedDict + explicit
  `prune()` for batch sweeps.
- **T22** — STDENV variable substitution (`${VAR}`) + `export`
  prefix + multi-line values + process-environment write-back
  (depends on T15 STDOS setenv).
- **STDHTTP iter 3** — IRIS arm via `%Net.HttpRequest`
  `$CLASSMETHOD`. Shares the same M-side req/resp shape as iter 2.
- **A4** — Vendor RFC-4122 UUID test vectors at
  `tests/conformance/uuid/`.
- **A5** — IRIS `iris-portability-check` CI job re-add (fail-soft).

## Architectural rule to remember

**m-stdlib has priority over m-cli; m-cli is a downstream consumer
of m-stdlib artifacts.** When STDASSERT (or any other m-stdlib
convention) lands, m-cli adapts.

## Open toolchain findings

See [`discoveries.md`](discoveries.md). None of the
remaining toolchain items gate any m-stdlib suite at v0.4.0.

## VistA Standard Library (VSL) track (planning, pre-implementation)

The MSL↔VistA integration layer (`VSL` / v-stdlib) is
specified but not yet built. **Front door → [`../plans/vsl-overview.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/vsl-overview.md)**
(the single-page overview + doc map + milestone ladder M0a–M6). The detailed plans:

- [`../plans/msl-vsl-architecture.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md)
  (v0.3) — **what** the L2 `STD*` / L3 `VSL*` seam is; the five
  side-effect seams; VistaEngine; the VWEB smoke test.
- [`../plans/msl-vsl-coordination-implementation-plan.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md)
  (**v0.5**) — **how** MSL and VSL stay coordinated: contract-as-coupling,
  versioning/pinning, frozen-MSL windows, re-sequenced milestones **M0a–M6**.
  **v0.2 anti-drift hardening:** three seam boundaries each made registry+gate-driven
  so none can drift silently — ① MSL⟷VSL `seams` block + MSL-side STDSNAP
  **bump-forcer** (§9); ② VSL→L4 **`icr-registry.json` + `make check-icr`** (§5.4);
  ③ →VDL **citation `body_sha` + `make check-citations`** (§5.5); plus the
  **embedded-first-class / KIDS-install-as-GREEN rule** (§8.4). **v0.3 (2026-06-11):**
  (a) the **KIDS build→install→verify→back-out lifecycle is its own modular,
  TDD-proven tooling workstream in `m-kids`** (§7.1) — assemble/disassemble has prior
  work; load/install/verify/back-out is the deepest unknown — with **git as source
  of truth for the KIDS package** (declarative spec + drift-gated normalized export,
  §7.2); (b) the first vertical is a **walking skeleton** (M1, §12.1): `VPNG`
  config-echo over `VSLCFG`/XPAR, success = one golden byte string, with a
  per-layer **determinism ledger**. `VSLIO` TLS spike slides to M2. New risks
  C13–C16; CQ9/CQ10.

**v0.4 (2026-06-11): the KIDS tooling is the first domain of a single `v` CLI.**
`m-kids` refiles as **`v pkg`** (repo `v-pkg`) — first domain of the new **`v` CLI
platform** for VistA developer tools (`docs/archive/v-cli-platform-redirect.md`): a single `v`
CLI wrapping vista-ese in plain-language domains (`v pkg`/`v db`/`v config`/…), each
with a generated command **contract + registry** and a shared Go template. Prefix
split by **scope not language**: `m-*` engine-neutral, `v-*` VistA-specific (both
Go). Verbs renamed developer-friendly (`unpack/build/check` + `install/verify/
uninstall`). **v0.5:** "registry-driven everything" added as principle §3 #8;
KIDS/M1 gates written as literal `v pkg` command chains (§8.4, §12.1); the
`m-*`/`v-*` scheme + registry discipline **promoted to the org `CLAUDE.md`**; VSL
repo renamed **`vista-stdlib` → `v-stdlib`**. **v0.6: ALL open questions resolved**
— architecture Q1–Q9, coordination CQ1–CQ10, platform CQ1–CQ5 all DECIDED; the two
external items (VA DBA namespace, VA OAuth AS) are pre-pilot gates, NOT dev
blockers. **Clear to implement.** (architecture→v0.3, platform→v0.3)

**Ready to execute.** The build is broken into TDD-trackable tasks in
[`../plans/vsl-implementation-plan.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/vsl-implementation-plan.md); live
status + the fresh-session **kickoff prompt** are in
[`vsl-implementation-tracker.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/vsl-implementation-tracker.md).

**Resume here → T0.1** (provision `VistaEngine` — FOIA VistA on YDB + IRIS) → **T0a.0**
(stand up the single `v` CLI + refile `m-kids`→`v-pkg`) → the `v pkg`
install/verify/uninstall lifecycle on a **one-routine throwaway package** (M0a, the
three invariants, both engines) → M0b → M1 walking skeleton. `v-stdlib`, the consumer
repo, the `v` CLI, and `v-tool-template` do **not** exist yet; `v-pkg` exists (today's
`m-kids`, offline half only).

## Cross-references

- [`../../README.md`](../../README.md) — public-facing overview;
  mirrors `../guides/users-guide.md` §§ 1–4 + 6–7.
- [`changelog.md`](changelog.md) — release history.
- [`../guides/users-guide.md`](../guides/users-guide.md) — full
  user's guide including § 5 per-module reference.
- [`../modules/index.md`](../modules/index.md) — canonical
  module inventory; one row per shipped module.
