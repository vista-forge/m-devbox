---
title: m-stdlib — future module proposals
status: draft
tracker: docs/module-tracker.md
created: 2026-05-10
last_modified: 2026-06-07
revisions: 3
doc_type: [PROPOSAL]
---

# m-stdlib — future module proposals

This document is the parking lot for module candidates that haven't
crossed TDD-red yet. Each candidate has a sketch, a priority, an
effort estimate, and a rationale for *why this one and not others*.
None has tests staked.

**Scope (v3, 2026-06-07).** The proposal set now spans **two tiers** and is
organized around **two end-to-end demonstrations**:

- **Tier `STD*` (m-stdlib)** — portable, engine-agnostic modules (YottaDB +
  IRIS, zero VistA dependency). This repo's own backlog; promotion target is
  [`module-tracker.md`](../module-tracker.md) Table 1.
- **Tier `VSL*` (v-stdlib)** — the VistA-coupled adapter library that binds
  each side-effecting `STD*` seam to its real VistA back end (FileMan, Kernel,
  XPAR, TaskMan, Device Handler). `VSL*` is a **separately-tracked sibling
  track** ([`msl-vsl-architecture.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md),
  [`msl-vsl-coordination-implementation-plan.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md));
  its rows are listed here **only** to make the full-stack dependency picture
  legible — canonical `VSL*` tracking lives in the v-stdlib track, not in
  this m-stdlib doc.

The two demonstrations — **outbound** VistA→S3 log egress and **inbound** FHIR
R4 over `VWEB` — are what set the priorities below: a module's rank is driven
by *which demo it unblocks and where it sits in that demo's dependency chain*.
See [§ Driving demonstrations & dependency-ordered roadmap](#driving-demonstrations-module-tiers--dependency-ordered-roadmap).

**Promotion process.** Promote a row from this table into
[`docs/module-tracker.md`](../module-tracker.md)'s
**Table 1 (Module tracker)** the moment you write `tests/STDxxxTST.m`
and confirm it fails red — at that point assign a track ID (next
available L-number for pure-M or H-number for `$ZF`-bound), bump the
row out of this table, and add it to Table 1 with phase **P4** (or
whatever phase fits).

When promoting, also:

- Add the per-module spec stub to
  [`m-stdlib-implementation-plan.md`](../archive/m-stdlib-implementation-plan.md)
  (current sections 8 / 11 / 12 are the spec home for Phase 1 / 2 / 3
  — extend with §13 or later as needed).
- Open the dispatch row in
  [`docs/archive/parallel-tracks.md`](../archive/parallel-tracks.md)
  §3.x with the block-on edges (if any) marked in §2's dependency map.
- Update this file's frontmatter `status` if all candidates promote
  out (status becomes `realized`).

## Table of Contents

- [Driving demonstrations, module tiers & dependency-ordered roadmap](#driving-demonstrations-module-tiers--dependency-ordered-roadmap)
  - [Demonstration A (inbound) — FHIR R4 over `VWEB`](#demonstration-a-inbound--fhir-r4-over-vweb)
  - [Demonstration B (outbound) — VistA → S3 log egress](#demonstration-b-outbound--vista--s3-log-egress)
  - [Required libraries per demo — prioritized, dependency-ordered](#required-libraries-per-demo--prioritized-dependency-ordered)
    - [Demo A (inbound) — FHIR R4 over `VWEB`](#demo-a-inbound--fhir-r4-over-vweb)
    - [Demo B (outbound) — VistA → S3 log egress](#demo-b-outbound--vista--s3-log-egress)
    - [Other — no consumer yet (demand-gated)](#other--no-consumer-yet-demand-gated)
- [Active proposals — m-stdlib (`STD*`) tier](#active-proposals--m-stdlib-std-tier)
  - [STDCRYPTO in-module extensions (tracker tickets, not new modules)](#stdcrypto-in-module-extensions-tracker-tickets-not-new-modules)
  - [Driving consumer — `VWEB` HTTPS stack](#driving-consumer--vweb-https-stack)
  - [Provenance — the secure-web-app review](#provenance--the-secure-web-app-review)
- [v-stdlib (`VSL*`) tier — adapter proposals](#v-stdlib-vsl-tier--adapter-proposals)
- [Promoted out — historical record](#promoted-out--historical-record)
- [Cross-references](#cross-references)

---

## Driving demonstrations, module tiers & dependency-ordered roadmap

Two **full-stack demonstrations** prove the `STD*`⟷`VSL*` seam in both
directions. Each exercises the *same* layering discipline (every portable hop is
`STD*`; every VistA hop is `VSL*`; they never blur) — one as a **client of
VistA**, one as **VistA acting as a client**. Standing both up is the concrete
goal the proposal priorities serve.

### Demonstration A (inbound) — FHIR R4 over `VWEB`

**Shape:** request/response; the outside world reaching *into* VistA over HTTPS.
A third-party FHIR R4 REST client issues `GET /metadata`, `GET /Patient/123`,
and resource-ingest writes against the `VWEB` HTTPS endpoint — the only entry
point — and never touches the M layers directly. This is the inbound *server*
path: TLS accept → HTTP parse → route → auth (Bearer→`DUZ`, scope→context
option) → FileMan read/write → FHIR-map → JSON serialize → frame → respond.
Canonical write-up: [architecture §6.1](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#61-example-application-1--fhir-r4-façade)
and the smoke-test walkthrough in [§9](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#9-part-f--worked-example-bidirectional-http-web-services-vweb-as-the-smoke-test);
the driving consumer spec is [`https-stack-spec.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/https-stack-spec.md) (`VWEB`).

**`STD*` critical path:** `STDNET` → `STDHTTPMSG` → `STDHTTPD`, plus `STDJWT`
(auth) and `STDVALID` (untrusted-body validation on ingest), over the existing
`STDJSON`/`STDURL`/`STDB64`/`STDCRYPTO` primitives. **`VSL*` critical path:**
`VSLIO` (socket+TLS), `VSLSEC` (DUZ/context-option authz), `VSLFS` (FileMan DBS
storage), `VSLTASK` (listener startup), `VSLBLD` (KIDS packaging).

### Demonstration B (outbound) — VistA → S3 log egress

**Shape:** fire-and-forget data egress; **VistA acting as a client** of an
external service. Any package calls the ordinary `STDLOG` API; records are
batched, serialized to NDJSON, SigV4-signed, framed, and `PUT` to an S3 bucket
over TLS — **no log ever lands in a MUMPS global** (the structural reason VistA
barely logs today). Canonical write-up:
[architecture §6.2](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#62-example-application-2--vista-log-streaming-to-aws-s3)
and the full design [`m-stdlib-s3-design.md`](../design/m-stdlib-s3-design.md).

**`STD*` critical path:** `STDSIGV4` → `STDS3`, over existing
`STDCRYPTO`/`STDHEX`/`STDJSON`/`STDXML`/`STDHTTP(MSG)`. `STDSIGV4` has **zero
proposed-module dependencies** (only shipped primitives), so this demo's
portable half can start immediately and is the **fastest path to a first
working full-stack vertical**. **`VSL*` critical path:** `VSLS3` (the `STDLOG`
sink), reusing the *shared* `VSLIO`/`VSLCFG`/`VSLTASK` adapters — only the sink
is S3-specific, and it is provider-swappable (`VSLGCS`/`VSLAZ` drop in behind
the same seam).

### Required libraries per demo — prioritized, dependency-ordered

Three lists: the libraries **Demo A** requires, the libraries **Demo B**
requires, and the **Other** modules that have **no consumer yet**. Within each
demo the sequence is **dependency-ordered** (`Seq` = build order; a module never
precedes something it depends on). Bold deps are *other proposed modules* (the
gating edges); plain deps already ship. Modules marked **(shared)** appear in
both demos — one build, reused; not duplicated effort. All `VSL*` rows gate on
the **`VistaEngine`** live-VistA test transport
([architecture §8](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#8-part-e--end-to-end-testing-against-vista-no-mocking))
before they can cross TDD-red.

#### Demo A (inbound) — FHIR R4 over `VWEB`

| Seq | Module | Tier | Depends on (proposed **bold**) | Notes |
|---|---|---|---|---|
| A1 | `STDNET` **(shared)** | `STD` | `$ZF`/engine sockets | leaf — startable now |
| A2 | `STDHTTPMSG` **(shared)** | `STD` | STDURL; STDB64/STDSTR (soft) | HTTP/1.1 codec — startable now |
| A3 | `$$ctEquals` (STDCRYPTO ext) | `STD` | STDCRYPTO | ship-now ticket; gates `STDJWT` — **PARTLY LANDED v0.13.0: shipped private as `cteq` in STDJWT; promote to public `$$ctEquals^STDCRYPTO` on a 2nd consumer** |
| A4 | `STDVALID` | `STD` | STDJSON; STDREGEX/STDDATE (soft) | leaf — startable now; ingest-body validation |
| A5 | `STDJWT` | `STD` | STDB64, STDCRYPTO + **`$$ctEquals`**, STDJSON | Bearer auth (HS256 now) — **✅ LANDED v0.13.0 (HS256 leg); RS256/ES256 via JWKS pending STDCRYPTO public-key sigs. See module-tracker #38** |
| A6 | `STDHTTPD` | `STD` | **STDHTTPMSG**, **STDNET** | accept-loop / router / middleware |
| A7 | `VSLIO` **(shared)** | `VSL` | **STDNET**; `^%ZIS`/`CALL^%ZISTCP` + TLS | socket+TLS; needs `VistaEngine` |
| A8 | `VSLCFG` **(shared)** | `VSL` | STDENV/STDOS; `$$GET^XPAR` | XPAR config |
| A9 | `VSLTASK` **(shared)** | `VSL` | `$$PSET^%ZTLOAD` | listener startup (TaskMan) |
| A10 | `VSLLOG` | `VSL` | STDLOG; FileMan audit / MailMan | inbound audit record |
| A11 | `VSLSEC` | `VSL` | **STDJWT**, STDCRYPTO; `DUZ`/#200, `^XUSEC`, OPTION #19 | scope → context-option authz |
| A12 | `VSLFS` | `VSL` | STDFS; FileMan DBS (`GETS^DIQ`/`UPDATE^DIE`) | FHIR resource read/write |
| A13 | `VSLBLD` | `VSL` | KIDS BUILD #9.6 / env-check | packaging |
| A14 | `VWEB` FHIR app | consumer | **A4, A5, A6, A7, A9, A11, A12, A13** | **capstone** — end-to-end smoke |

*Build note.* A1–A6 are the portable layer; **A1–A4 are startable immediately
and parallelizable**, A5 follows A3, A6 follows A1+A2. A7–A13 gate on the
`VistaEngine`. A14 closes the demo (the [§9 smoke test](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#9-part-f--worked-example-bidirectional-http-web-services-vweb-as-the-smoke-test)).

#### Demo B (outbound) — VistA → S3 log egress

| Seq | Module | Tier | Depends on (proposed **bold**) | Notes |
|---|---|---|---|---|
| B1 | `STDSIGV4` | `STD` | STDCRYPTO, STDHEX, STDURL, STDDATE | **zero proposed deps — start here**; fastest full-stack vertical |
| B2 | `STDNET` **(shared)** | `STD` | `$ZF`/engine sockets | leaf — startable now |
| B3 | `STDHTTPMSG` **(shared)** | `STD` | STDURL; STDB64/STDSTR (soft) | request framing (`STDHTTP` optional alt) |
| B4 | `STDS3` | `STD` | **STDSIGV4**, **STDHTTPMSG**, STDJSON, STDXML, STDURL | S3 REST client |
| B5 | `VSLIO` **(shared)** | `VSL` | **STDNET**; `CALL^%ZISTCP` + client TLS | socket+TLS; needs `VistaEngine` |
| B6 | `VSLCFG` **(shared)** | `VSL` | `$$GET^XPAR` | bucket / region / creds |
| B7 | `VSLTASK` **(shared)** | `VSL` | `$$PSET^%ZTLOAD` | background flush job |
| B8 | `VSLS3` | `VSL` | **STDS3, VSLIO, VSLCFG, VSLTASK**; binds `STDLOG` sink | **capstone** — provider-swappable (`VSLGCS`/`VSLAZ`) |

*Build note.* B1 is independent and the **quickest path to a green vertical** —
its portable half can start before anything else in either demo. B2/B3 are the
shared foundation; B4 follows B1+B3; B5–B7 gate on the `VistaEngine`; B8 closes
the demo.

#### Other — no consumer yet (demand-gated)

Real modules, but **nothing drives them today** — promote only when a concrete
consumer appears. Internal gating deps noted; ordered by severity-of-gap, not by
a build sequence (there is no demo to sequence against).

| Module | Tier | Depends on (proposed **bold**) | Why it waits |
|---|---|---|---|
| `STDESCAPE` | `STD` | STDURL (soft) | highest-severity general gap, but `VWEB` is JSON-only (no HTML-serving consumer) |
| `STDRATELIMIT` | `STD` | STDCACHE/STDDATE (soft) | reusable DoS guard; `VWEB` enforces request caps in config instead |
| `STDCOOKIE` | `STD` | STDCRYPTO; STDURL (soft) | no cookie consumer (`VWEB` is stateless Bearer) |
| `STDSESSION` | `STD` | **STDCOOKIE**, STDCRYPTO **AEAD**, STDCSPRNG | browser-session consumers only; blocked on the AEAD ticket |
| `STDTOTP` | `STD` | STDCRYPTO; base32 (STDB64 add) | MFA; no auth consumer adding a second factor yet |
| `STDYAML` | `STD` | STDDATE; STDSTR (soft) | big spec, no driver |
| STDCRYPTO ext — public-key sigs (Ed25519 / RS256) | `STD` ticket | STDCRYPTO | unblocks `STDJWT` RS256/EdDSA + webhook-sig verify (HS256 ships without it) |
| STDCRYPTO ext — AEAD (AES-GCM / ChaCha20) | `STD` ticket | STDCRYPTO | gates `STDSESSION` above |
| STDCRYPTO ext — password KDF (argon2id) | `STD` ticket | STDCRYPTO | no password-storing consumer (Bearer/introspection only) |

> Detail and rationale for every `STD*` row above live in the
> [Active proposals — `STD*` tier](#active-proposals--m-stdlib-std-tier) table;
> the STDCRYPTO tickets are itemized in
> [§ STDCRYPTO in-module extensions](#stdcrypto-in-module-extensions-tracker-tickets-not-new-modules);
> `VSL*` rows are detailed in the [`VSL*` tier](#v-stdlib-vsl-tier--adapter-proposals) section.

---

## Active proposals — m-stdlib (`STD*`) tier

Priority is a single integer 1..N (1 = highest). Priority captures
**when this should be picked up** relative to other proposals,
considering: security gap closure, downstream-module unblock,
adjacent-tooling pressure, breadth of call sites.

Dependency column legend: same as Table 1. **soft** = optional —
module would work without the dep but ships better integration when
the dep is present.

Effort = developer-days, full TDD discipline, all forward estimates
marked **est.**.

This wave of candidates comes from the 2026-06 secure-web-app gap
review (see the [§ Provenance](#provenance--the-secure-web-app-review)
note below) and is **re-ranked around a concrete driving consumer** —
the VistA-native HTTPS stack spec'd in
[`https-stack-spec.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/https-stack-spec.md) (`VWEB`). Because `VWEB`
is a **JSON-first, OAuth2-Bearer, stateless services** stack with
*no HTML rendering and no cookie sessions* (its Non-Goals §1), the
browser-facing security modules (escaping, cookies, sessions, CSRF)
have **no driver yet** and sink below the API-stack modules that
`VWEB` actually blocks on. See
[§ Driving consumer](#driving-consumer--vweb-https-stack) for the
per-row mapping.

| Pri | Candidate | Headline | Dependency | Effort | Rationale |
|---|---|---|---|---|---|
| 1 | `STDNET` | TCP / UDP socket primitives | `$ZF → libc` POSIX sockets (or YDB native), TBD; A6 | 8–14d est. | **Now consumer-driven.** `VWEB`'s pure-M listener (`VWEBL`/`VWEBIO`) and outbound client sit directly on this. Foundational unblock for the entire HTTPS stack; was "defer until a greenfield service drives it" — that service now exists. |
| 2 | `STDHTTPMSG` | Pure-M HTTP/1.1 message codec — request **and** response parse/serialize, header block, chunked transfer | STDURL; STDB64 (soft); STDSTR (soft) | 6–10d est. | **Consumer-driven.** `VWEB`'s portability seam (spec §5) is exactly this, engine-independent and callout-free — which is why it lives in m-stdlib, not `VWEB*`. Distinct from `STDHTTP` (optional, libcurl-backed, client-only): this is the byte-level codec a pure-M *server* needs. **Decision:** extend `STDHTTP`'s pure-M surface and promote it to core, vs. a new core module — resolve at promotion (see Driving-consumer note). |
| 3 | `STDJWT` | JWT / JOSE sign + verify (HS256/384/512 first; RS256 + EdDSA once STDCRYPTO gains signatures) | STDB64 (base64url); STDCRYPTO (HMAC now, sign/verify later); STDJSON | 4–7d est. | **Consumer-driven.** `VWEB`'s local-JWT auth provider (spec §7.1 / decision D6) is deferred *pending in-M crypto* — this module is that dependency. HS256 ships today by pure composition of primitives already in the library; RS/EdDSA gated on the STDCRYPTO signature ticket below. |
| 4 | `STDHTTPD` | Pure-M HTTP **server framework** — accept-loop / per-connection worker model, route-matching engine, middleware chain (the generic server skeleton, no VistA bindings) | STDHTTPMSG; STDNET | 5–8d est. | **Consumer-driven (Option-B extraction).** The generic half of `VWEB` — listener concurrency + router + middleware — is not VistA-specific. Extracting it lets *any* pure-M service (VistA or not) stand up an HTTP server, and shrinks `VWEB` to a thin VistA-binding shell (FileMan handlers + `DUZ` auth + context-option authz + KIDS). VistA-specific bits (TaskMan launch, `^%ZIS`/TLS open, FileMan dispatch) stay in `VWEB*`/`VSL`. |
| 5 | `STDVALID` | Request-input validation — typed/bounded schema over a parsed JSON tree (JSON-Schema subset) | STDJSON; STDREGEX (soft); STDDATE (soft) | 6–10d est. | Untrusted request bodies need shape/type/bound checks before they reach FileMan handlers. `STDJSON` parses but does not validate. Broadly useful beyond `VWEB`; soft-driven by every handler in the stack. |
| 6 | `STDRATELIMIT` | Token-bucket / sliding-window rate limiter over a caller-owned store | STDCACHE (soft); STDDATE (soft) | 3–5d est. | DoS / brute-force guard. `VWEB` enforces request caps in config (spec §4) but a reusable primitive serves auth-endpoint throttling and any service. Small lift on top of `STDCACHE`'s TTL store. |
| 7 | `STDESCAPE` | Context-aware output encoding — HTML-body / attribute / JS-string / CSS / URL contexts (XSS prevention) | STDURL (soft) | 2–4d est. | **Highest-severity gap in the general review, but no driver in `VWEB`** (JSON-only, Non-Goal §1 — no HTML rendering). The library currently ships *zero* output-encoding surface, making the unsafe path the only path. **Promote immediately** the moment any HTML-serving consumer appears. |
| 8 | `STDCOOKIE` | Cookie parse / serialize with security attributes (`HttpOnly`, `Secure`, `SameSite`) + signed cookies | STDCRYPTO (HMAC, for signing); STDURL (soft) | 2–4d est. | No driver in `VWEB` (stateless Bearer auth, no cookies). For a future browser-session consumer. |
| 9 | `STDSESSION` | Server-side session store + signed/encrypted session cookies | STDCOOKIE; STDCRYPTO (AEAD — see ticket below); STDCSPRNG | 4–7d est. | No driver in `VWEB`. Depends on the STDCRYPTO AEAD extension landing first. Browser-session consumers only. |
| 10 | `STDTOTP` | TOTP / HOTP (RFC 6238 / 4226) for MFA | STDCRYPTO (HMAC); **base32** (new — add to STDB64) | 2–3d est. | MFA second factor. Fully buildable from existing HMAC once base32 lands (a small `STDB64` add — RFC 4648 §6). No `VWEB` driver; for any auth consumer adding MFA. |
| 11 | `STDYAML` | YAML 1.2 parser | STDDATE; STDSTR (soft) | 12–18d est. | Config ergonomics; preferred to JSON for human-edited configs. **Big spec, no driver.** Defer until a concrete consumer asks. (Demoted from Pri 1 — the web-stack wave outranks it.) |
| 12 | `STDSIGV4` | AWS Signature Version 4 signer (`AWS4-HMAC-SHA256`) — canonical request, string-to-sign, signing-key chain, `Authorization` header; service-generic | STDCRYPTO (HMAC/SHA — exists); STDHEX; STDURL; STDDATE | 3–5d est. | **Consumer-driven (cloud-egress wave).** Pure math over primitives the library already ships — the raw-byte HMAC chain + hex final signature, byte-mode-exact. First consumer is the VistA→S3 log shipper; reusable for any AWS REST service. Highest-value test is the AWS SigV4 known-answer vectors (no network). See [`m-stdlib-s3-design.md`](../design/m-stdlib-s3-design.md) §6/§9. |
| 13 | `STDS3` | Pure-M Amazon S3 REST client — `putObject`/`getObject`/`headObject`/`listObjectsV2`/`deleteObject` + multipart | STDSIGV4 (Pri 12); STDHTTP/STDHTTPMSG; STDJSON; STDXML; STDURL | 6–10d est. | **Consumer-driven (cloud-egress wave).** The S3 half of the [Standard Library architecture §6.2](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#62-example-application-2--vista-log-streaming-to-aws-s3) outbound worked example — VistA log streaming to S3 with no log ever landing in a global. Portable `STD*`; the VistA-coupled sink (`VSLS3`) + socket/config/task live in v-stdlib. See [`m-stdlib-s3-design.md`](../design/m-stdlib-s3-design.md). |

**Aggregate proposal effort:** ~63–98d est. across all 13 rows if
every one eventually lands. The `VWEB`-driven rows (Pri 1–4 + the
STDCRYPTO signature ticket below) are the critical path for the HTTPS
stack; the rest are demand-gated.

### STDCRYPTO in-module extensions (tracker tickets, not new modules)

Four security primitives belong **inside `STDCRYPTO`** (the `$&stdcrypto`
→ libcrypto plumbing already exists) and are tracked as per-module
follow-up tickets in
[`module-tracker.md`](../module-tracker.md), *not* as rows
above. Listed here so the secure-web picture is complete:

| Extension | Why | Driver / urgency |
|---|---|---|
| `$$ctEquals` — constant-time byte compare | The library ships HMAC but no timing-safe compare, so every caller comparing an HMAC / token / API key uses `=` (timing-attack-prone). **Cheap, pure-M, removes a footgun the library currently invites.** | **Ship now** — needed by `STDJWT`, `VWEB` Bearer/introspection token compare (spec §7.2). Highest-ROI item on this page. |
| Public-key signatures — RS/PS/ES/EdDSA **verify** — **design: [`stdcrypto-asymmetric-verify-v2.md`](stdcrypto-asymmetric-verify-v2.md)** (integrated, sequenced; supersedes the original + its adversarial review in `superseded/`) | Listed "out of scope at v1" in `STDCRYPTO`. Unblocks `STDJWT` RS256/ES256/EdDSA (module-tracker #38 pending leg) and webhook-signature verification. **Gated: Phase 0 must clear G-IRIS (IRIS ES\*/EdDSA probe), G-ERR (error-channel), G-CI (optional-suite gate) before RS\* → ES\* build.** | Co-driven with `STDJWT` (Pri 3) / `VWEB` D6. |
| Password KDF — argon2id (or PBKDF2-HMAC-SHA256 floor) | With only SHA-2 available, callers will hash passwords with a fast digest — a real vuln. | No `VWEB` driver (Bearer/introspection, no local passwords). Demand-gated, but high-severity once any password-storing consumer appears. |
| AEAD — AES-256-GCM / ChaCha20-Poly1305 | Encrypted session cookies, encrypted-at-rest fields, secure tokens. | Blocks `STDSESSION` (Pri 8). No `VWEB` driver. |

### Driving consumer — `VWEB` HTTPS stack

[`https-stack-spec.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/https-stack-spec.md) is the first concrete
consumer that exercises the web/security shelf. Per the architectural
rule (*m-stdlib has priority — implement here first; consumers
import*), the **portable** layers of the spec's module map (§3) should
land in m-stdlib and be imported by `VWEB`, leaving only the
engine-adapter and VistA-specific layers in the `VWEB` project:

The spec's §3 module map already encodes this split (an "imported from
m-stdlib" group + an `VWEB*` group); this table is the per-layer
summary:

| Spec §3 layer | Maps to m-stdlib | Status |
|---|---|---|
| HTTP parse / serialize (§5 portability seam) | **`STDHTTPMSG`** (Pri 2) | propose |
| Server framework — accept-loop / worker / router / middleware (the generic half of the listener + router) | **`STDHTTPD`** (Pri 4) | propose |
| JSON codec (§10, decision D5) | **`STDJSON`** (exists) | adopt + cross-engine conformance test |
| CRLF / percent-decode / base64 / header casing (the old `ZHWSU`) | **`STDURL`** + **`STDB64`** + **`STDSTR`** (exist) | import, don't reimplement |
| Socket open / read / write under listener + outbound (the `VWEBL` / `VWEBIO` / `VWEBCL` adapters wrap this) | **`STDNET`** (Pri 1) | propose |
| Local-JWT provider (§7.1, D6) | **`STDJWT`** (Pri 3) + STDCRYPTO signatures | propose |
| Introspection token-hash + compare (§7.2) | **`STDCRYPTO`** `$$sha256` (exists) + `$$ctEquals` (ticket) | extend |
| Listener / job-off, router, auth, DUZ binding, KIDS, XPAR | — | **stays in the package** (`VWEBL` / `VWEBR` / `VWEBA` / `VWEBCFG` / `VWEBLOG`) |

TLS (spec §9) is operator-provisioned and referenced by name from the
engine's device `OPEN` — it stays out of m-stdlib (engine-adapter
concern), which resolves the "no TLS primitive" item from the review:
m-stdlib does not need one.

### Provenance — the secure-web-app review

Rows 2–9 and the STDCRYPTO extension tickets originate from the
2026-06 review *"gaps for modern secure web-accessible applications."*
The review's two by-omission-dangerous findings — **no output
encoding (XSS)** and **no constant-time compare (timing attacks)** —
land here as `STDESCAPE` (Pri 6) and `$$ctEquals` (ship-now ticket).
The review's headline: m-stdlib has the right *primitives* (CSPRNG,
HMAC, SHA-2, base64url, URL, JSON) but is missing the
*secure-composition* layer; this wave fills it, sequenced by the
`VWEB` consumer rather than by raw severity.

## v-stdlib (`VSL*`) tier — adapter proposals

> **Track note.** `VSL*` is a **separately-tracked sibling library**
> (`v-stdlib`), not part of m-stdlib's own backlog. These rows are
> reproduced here for the full-stack dependency picture (see the
> [per-demo required-libraries lists](#required-libraries-per-demo--prioritized-dependency-ordered) above);
> the **canonical** `VSL*` tracker, contract, and milestones live with the
> coordination effort —
> [`msl-vsl-architecture.md` §4.2](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#42-the-adapter-contract)
> (the adapter contract) and
> [`msl-vsl-coordination-implementation-plan.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md)
> (versioning/pinning, frozen-MSL windows, milestones M0–M5). Do **not**
> promote a `VSL*` row into this repo's `module-tracker.md` — it belongs to the
> v-stdlib track.

Each `VSL*` adapter contains **only** the VistA binding for one `STD*` seam;
any portable logic stays in `STD*` and is *called*, never copied
([architecture R8](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#10-risks)). All `VSL*` rows depend on
the **`VistaEngine`** live-VistA test transport
([architecture §8](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#8-part-e--end-to-end-testing-against-vista-no-mocking))
before they can cross TDD-red.

| `STD*` seam bound | `VSL*` adapter | VistA back end | Demo | Gating proposed dep |
|---|---|---|---|---|
| `STDNET` socket open | `VSLIO` | `^%ZIS` / `CALL^%ZISTCP` (ICR #2118) + named TLS config | A+B | **STDNET** |
| `STDENV` / `STDOS` config | `VSLCFG` | `$$GET^XPAR` / `EN^XPAR` (#8989.5/.51) | A+B | — |
| process / scheduling | `VSLTASK` | `$$PSET^%ZTLOAD` (ICR #10063) persistent task | A+B | — |
| `STDLOG` / `STDPROF` sink | `VSLLOG` | FileMan audit file / MailMan alert | A+B | — |
| `STDCRYPTO` hash / auth | `VSLSEC` | `^XUSHSH`; `DUZ`/#200; `^XUSEC`; OPTION #19 | A | **STDJWT** |
| `STDFS` storage | `VSLFS` | FileMan DBS (`GETS^DIQ` / `UPDATE^DIE` / `FILE^DIE`) | A | — |
| packaging / install | `VSLBLD` | KIDS BUILD #9.6 / INSTALL #9.7 + env-check | A+B | — |
| `STDLOG` → S3 (sink) | `VSLS3` | binds the `STDLOG` sink seam → `STDS3` | B | **STDS3**, **VSLIO**, **VSLCFG**, **VSLTASK** |

`VSLIO` / `VSLCFG` / `VSLTASK` / `VSLLOG` are the **shared adapter shelf** both
demos reuse; `VSLSEC` / `VSLFS` are inbound-specific; `VSLS3` is the outbound
sink (and provider-swappable — `VSLGCS` / `VSLAZ` behind the same seam).

## Promoted out — historical record

Modules that began in this proposal table and have since landed in
[`module-tracker.md`](../module-tracker.md) Table 1. Kept
here as a reference for how each promotion played out (per-module
deep history lives in each module's
[`docs/modules/<m>.md` § History](../modules/) section).

- **STDCSPRNG** — promoted 2026-05-07 to Table 1 as **L15 P4**.
  Implemented with `/dev/urandom` (kernel ChaCha20 CSPRNG via
  single-byte `READ *b` to avoid record-terminator truncation)
  instead of the originally sketched `$ZF → libc` callout — the API
  surface is stable for a future callout-backend swap (T12, since
  closed) once the Phase 3 build harness is exercised by a real
  consumer.
- **STDFS** — promoted 2026-05-07 to Table 1 as **L16 P4**. Shipped
  as text-mode YDB-only v1: read/write/append/exists/remove/size +
  basename/dirname/join. **T13+T14 closed 2026-05-08** —
  `src/callouts/stdfs.c` adds byte-faithful I/O.
- **STDOS** — promoted 2026-05-07 to Table 1 as **L17 P4**. Shipped
  YDB-only v1: env / pid / cmdline / argc / arg / argv / splitArgs /
  cwd / user / hostname / exit. setenv() and quote-aware splitArgs
  deferred to T15.
- **STDSEMVER** — promoted 2026-05-07 to Table 1 as **L18 P4**. SemVer
  2.0.0; range syntax v1 covers comparators, caret, tilde, AND;
  remaining npm range constructs queued at T16.
- **STDSTR** — promoted 2026-05-07 to Table 1 as **L19 P4**. ASCII-
  only string helpers; Unicode whitespace + locale-aware case folding
  deferred to a future STDUNICODE under T17.
- **STDTOML** — promoted 2026-05-07 to Table 1 as **L20 P4**. TOML
  1.0 subset: top-level pairs + `[section]` tables; 4 scalar types;
  `#` comments. Out-of-scope features (arrays, inline tables, dotted
  keys, etc.) queued at T18.
- **STDCACHE** — promoted 2026-05-07 to Table 1 as **L21 P4**. LRU
  + TTL cache. STDCOLL rebase + `prune` queued at T19.
- **STDPROF** — promoted 2026-05-07 to Table 1 as **L22 P4**. Wall-
  clock profiler. T20 (streaming-percentile) closed
  won't-fix-without-consumer-driver.
- **STDSNAP** — promoted 2026-05-07 to Table 1 as **L23 P4**.
  Snapshot testing. T21 closed via C7's update-mode global flag.
- **STDENV** — promoted 2026-05-07 to Table 1 as **L24 P4**. `.env`
  loader + typed accessors. Variable substitution / multi-line / etc.
  queued at T22.
- **STDXML v0** — promoted 2026-05-07 to Table 1 as **L25 P4**.
  XML 1.0 well-formed parser. T23–T27b + T26 all closed; full XML
  1.0 + Namespaces 1.0 + XPath 1.0 + DTD envelope shipped.
- **STDMATH** — promoted 2026-05-08 to Table 1 as **L26 P4**. Numeric
  helpers (clamp / min / max / sum / count / mean).
- **STDXFRM** — promoted 2026-05-08 to Table 1 as **L27 P4**. Higher-
  order array transforms (map / filter / reduce) via XECUTE-evaluated
  lambdas.

## Cross-references

- [`../module-tracker.md`](../module-tracker.md) — current Table 1; promotion target.
- [`../archive/parallel-tracks.md`](../archive/parallel-tracks.md) — dispatch view; track IDs assigned at promotion.
- [`m-stdlib-implementation-plan.md`](../archive/m-stdlib-implementation-plan.md) — per-module specs; spec stubs added at promotion.
- [`m-stdlib-s3-design.md`](../design/m-stdlib-s3-design.md) — design spec driving the `STDSIGV4` (Pri 12) + `STDS3` (Pri 13) cloud-egress rows and **Demonstration B**; the AWS S3 connector + boto3→M mapping + `VSLS3` log-sink interface.
- [`msl-vsl-architecture.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md) — the `STD*`⟷`VSL*` sharp-line architecture; **§6.1** = Demonstration A (FHIR), **§6.2** = Demonstration B (S3 egress); **§4.2** = the `VSL*` adapter contract this file's VSL tier reproduces.
- [`msl-vsl-coordination-implementation-plan.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md) — canonical `VSL*` track: contract surface, MSL/VSL version pinning, milestones M0–M5. The `VSL*` rows here are advisory; that plan is authoritative.
- [`https-stack-spec.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/https-stack-spec.md) — the `VWEB` HTTPS stack: driving consumer for Demonstration A and the `STDNET`/`STDHTTPMSG`/`STDHTTPD`/`STDJWT`/`STDVALID` rows.
- [`../modules/index.md`](../modules/index.md) — canonical released-module index.
