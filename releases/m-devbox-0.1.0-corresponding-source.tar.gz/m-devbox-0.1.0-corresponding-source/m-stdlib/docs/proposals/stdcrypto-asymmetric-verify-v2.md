---
title: "STDCRYPTO asymmetric verify — integrated build proposal (RS/PS/ES/EdDSA), sequenced for the JWT/JWS auth stack"
status: draft
tracker: docs/module-tracker.md
created: 2026-07-09
last_modified: 2026-07-09
revisions: 2
doc_type: [PROPOSAL]
supersedes: docs/proposals/superseded/stdcrypto-asymmetric-verify.md, docs/proposals/superseded/stdcrypto-asymmetric-verify-review.md
---

# STDCRYPTO asymmetric verify — integrated build proposal

> **Status: draft.** This is the consolidated, build-ready proposal for adding
> **public-key signature *verification*** (RS/PS/ES/EdDSA) to `STDCRYPTO`. It
> merges the original design ([`stdcrypto-asymmetric-verify.md`](superseded/stdcrypto-asymmetric-verify.md))
> with the findings of its adversarial technical review
> ([`stdcrypto-asymmetric-verify-review.md`](superseded/stdcrypto-asymmetric-verify-review.md)),
> and — the reason this rev exists — **sequences the dependency chain** so the
> high-risk, must-do-first items are cleared before any dependent component
> (STDJWT asymmetric leg → VSLJWT → `XUS JWT LOGON` RPC → VWEB local-JWT) is built.
>
> It builds nothing above the waterline and needs no VistA. It is the **critical-path
> leaf** the whole asymmetric-JWT auth stack sits on.

---

## Table of Contents

1. [Executive summary](#1-executive-summary)
2. [What the adversarial review changed (new information)](#2-new-information)
3. [Relationship to existing work](#3-relationship)
4. [Scope](#4-scope)
5. [Assumptions register](#5-assumptions)
6. [Dependency sequencing — the critical path](#6-sequencing)
7. [Public API + the security contract](#7-api)
8. [Current STDCRYPTO architecture (grounded)](#8-architecture)
9. [Implementation sketch (with the review's fixes)](#9-implementation)
10. [Algorithm details that bite](#10-algo-details)
11. [Security model — the algorithm-confusion boundary](#11-security)
12. [Test strategy](#12-tests)
13. [Risk & mitigation register (integrated)](#13-risks)
14. [Implementation plan & tracker table](#14-plan)
15. [Packaging & installation](#15-packaging)
16. [Open questions](#16-open-questions)
17. [References](#17-references)

---

## 1. Executive summary <a id="1-executive-summary"></a>

`STDCRYPTO` today has SHA-2 digests and HMAC but **no asymmetric signature
verify**. Every real federated issuer (VA SSOi/IAM, Login.gov, any OIDC IdP) signs
**RS256 / ES256** — not HMAC. Symmetric HS256 needs a shared secret and cannot
federate. `STDJWT` shipped v0.13.0 with the HS256 leg and **rejects non-HS256
loudly** (`STDJWT.m:56`) until this lands. This proposal adds one verb —

```
$$verifySig^STDCRYPTO(alg, pubKey, msg, sig)   ; → 1 valid | 0 invalid
```

— and nothing else. It is verify-only (no private keys, no signing), key-agnostic
(takes a standard SPKI encoding; JWK conversion stays upstream), and JWT-agnostic
(claims/`kid`/JWKS stay in STDJWT).

**The review's headline correction:** this is *not* the "small, symmetric, no-new-.so"
change the first draft claimed. Two items must be **cleared first, as gates**, or the
dependent stack inherits a broken foundation:

- **G-IRIS (was R-4, re-rated High):** IRIS has documented RSA verify but **no
  documented generic ECDSA/EdDSA verify**. ES256 is the *most common* federated alg,
  so "engine-neutral" is unproven for the algorithm that matters most. Resolve the
  IRIS surface (OQ-1) **before** locking the design.
- **G-SEC (new, High):** the module accepts a caller-supplied `alg`. That is the
  correct seam, but it makes STDCRYPTO structurally unable to defend against JWT
  algorithm confusion — the #1 JWS vulnerability class. The contract must say so
  loudly and the dependent STDJWT must own the defense.

The plan below stages **RS\* on both engines first** (highest confidence), then
ES\*/EdDSA/PSS gated on the IRIS probe.

## 2. What the adversarial review changed (new information) <a id="2-new-information"></a>

Everything here is new relative to the original draft and is folded into the plan:

| # | New finding | Where it lands |
|---|---|---|
| N-1 | **Algorithm-confusion is unhandled and unmentioned.** A verb keyed by a caller-supplied `alg` delegates 100% of alg policy upward; the original risk table omitted the entire JWS-confusion class (`alg:none`, RS→HS key confusion, header-chosen `alg`/`kid`/`jwk`). | §7 contract, §11, R-SEC |
| N-2 | **IRIS ES\*/EdDSA is unproven, not "one new arm."** `$SYSTEM.Encryption` exposes `RSASHAVerify` but no documented generic ECDSA/EdDSA verify; a bundled ObjectScript helper is a first-class MSL artifact, not a footnote. Re-rate R-4 → High and gate the design on it. | §6 Phase 0, R-IRIS, OQ-1 |
| N-3 | **Single `ydb_int_t` return can't carry 4 error modes**, and there is a **latent `rc=-1` collision**: the existing `dispatch3/4` `$ETRAP` sets `rc=-1` for callout-missing (`STDCRYPTO.m:331,335`) while the C layer also returns `-1..-5` (`std_crypto.c:36-38`). Verify must use disjoint negative codes. | §9a, R-ERR |
| N-4 | **`STDCRYPTOTST` is an *optional* suite** (`Makefile:111-135`), excluded from the coverage-measured set, and **not run by the default `make test`/CI gate**. New verify code lands *outside* the drift-gated green path unless `test-optional`/`coverage-optional` is wired in. | §6 Phase 0, §12, R-CI |
| N-5 | **"No new .so" hides a deployment step.** `seed-callouts.sh` recompiles the `.c` *inside the engine container*; a new `crypto_verify` symbol needs a re-seed of every engine that runs the suite (or a bump of the pinned `m-test-engine:0.2.0` image). | §9c, R-DEPLOY |
| N-6 | **P-521 half-width is 66 bytes, not 64.** The ES `R‖S`↔DER converter must derive component width from `siglen/2`, not assume 32; reject odd/misized lengths as invalid(0). | §10, R-DER |
| N-7 | **KAT-only negative testing is too thin for an auth primitive.** Add Google Wycheproof ECDSA/RSA/EdDSA vectors (s=0/r=0, `s>n` malleability, non-canonical DER, wrong-curve, Bleichenbacher PKCS#1 padding). | §12, R-DER, R-PARSE |
| N-8 | **Stale-`.so` masking.** `$$available` probes only sha256; an old `.so` (present but pre-`verify`) would report "available" yet every verify raises CALLOUT-MISSING. Add a symbol-specific probe. | §9a, R-STALE |

## 3. Relationship to existing work <a id="3-relationship"></a>

Verified against the repo — this is work already on the books, not a new idea:

- **`STDJWT` exists** — shipped v0.13.0, dual-engine GREEN 28/28
  (`module-tracker.md:125` / #38): `$$verify`/`$$decode`/`$$claim`/`$$sign`/
  `$$lastError`, HS256 + `exp`/`nbf`/`iss`/`aud`. Non-HS256 `alg` is rejected
  loudly (`STDJWT.m:56`) until this lands. This proposal unblocks its
  RS256/ES256/EdDSA leg — nothing more.
- **Listed in `future-modules-plan.md`** as *"STDCRYPTO in-module extensions
  (tracker tickets, not new modules) → Public-key signatures — Ed25519 + RSA (RS256)
  verify … Unblocks STDJWT RS256/EdDSA … Co-driven with STDJWT (Pri 3) / VWEB D6"*
  (`future-modules-plan.md:189`). Track this as a **STDCRYPTO in-module ticket in
  `module-tracker.md`**, not a new module row.
- **`$$ctEquals` (constant-time compare) is separate** — private `cteq` inside
  STDJWT today, promoted to `$$ctEquals^STDCRYPTO` on a second consumer. Orthogonal:
  EVP does the signature compare internally, and **public-key verify has no secret to
  compare** (the signature and public key are both public), so constant-time is *not*
  required on this path. Noted so a reviewer doesn't add timing-safety cargo-cult.
- **Two consumers wait, not one:** `VSLJWT` / VistA bearer auth
  ([`../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`](../../../v-stdlib/docs/proposals/vsl-jwt-auth.md))
  **and** the `VWEB` HTTPS stack's local-JWT provider (D6). Co-driven; that is why it
  earns a design doc.

## 4. Scope <a id="4-scope"></a>

**In scope — public-key signature *verify* for the JWS algorithm families:**

- **RS256 / RS384 / RS512** — RSASSA-PKCS1-v1_5 + SHA-2 (RFC 7518 §3.3, RFC 8017 §8.2)
- **PS256 / PS384 / PS512** — RSASSA-PSS + SHA-2 (RFC 7518 §3.5, RFC 8017 §8.1)
- **ES256 / ES384 / ES512** — ECDSA P-256/384/521 + SHA-2 (RFC 7518 §3.4)
- **EdDSA (Ed25519)** — one-shot EVP (RFC 8037 §3.1)

**Out of scope (deliberately):**

- **Asymmetric *signing* / private keys.** Verify holds no secret; signing puts a
  private key in engine custody — a much larger surface. Deferred to a possible P2
  (only if VistA becomes a token *issuer*; not needed to *accept* tokens). HS256
  minting already works via existing HMAC.
- **JWT structure, claim validation, JWKS, `kid` selection, `alg` policy** — those
  belong to `STDJWT` (engine-neutral) and `VSLJWT` (VistA binding). This module only
  answers: *"is this signature valid for this message under this public key and alg?"*
- **JWK → key-material conversion** (RSA `n`/`e`, EC `crv`/`x`/`y`) — a STDJWT concern.
  STDCRYPTO takes a standard SPKI encoding and stays JWT-agnostic.

## 5. Assumptions register <a id="5-assumptions"></a>

| # | Assumption | Confidence | If false |
|---|---|---|---|
| A-1 | libcrypto (`EVP_DigestVerify`, `EVP_PKEY_CTX` PSS params, `ECDSA_SIG` i2d/d2i) is available on the YDB engine loader path (`libcrypto.so.3`/`.1.1`). | High (digests/HMAC already use it) | RS\* path unbuildable on YDB; whole proposal blocked. |
| A-2 | OpenSSL ≥ 1.1.1 (EdDSA one-shot `EVP_DigestVerify` with NULL md requires it). | High | EdDSA YDB-only-drop or version bump. |
| **A-3** | **IRIS exposes RSA verify (`$SYSTEM.Encryption.RSASHAVerify` or equiv).** | Med — arg order/key form unconfirmed | RS\* on IRIS needs a helper class; G-IRIS widens. |
| **A-4** | **IRIS can verify ECDSA/EdDSA/PSS somehow** (native or via a bundled `%SYS.X509`/ObjectScript helper). | **Low — this is OQ-1, the load-bearing unknown** | ES\*/EdDSA become YDB-only-for-now; "engine-neutral" claim narrows to RS\*. |
| A-5 | The verdict-as-int ABI (no output buffer) works over the `$&stdcrypto.<fn>` callout, as the existing status-returning digests do. | High (existing `.c` returns status via int) | Fall back to an O:buffer verdict byte. |
| A-6 | Issuers/consumers supply keys as **SPKI DER/PEM** (or STDJWT converts JWK→SPKI upstream). | High (standard encoding) | Add a PKCS#1→SPKI shim or reject with `BADKEY`. |
| A-7 | All engine access (dev/test/CI) stays on the `m-driver-sdk → m-ydb/m-iris` stack (org waterline rule 3). | High (org rule) | n/a — non-negotiable. |
| A-8 | Test vectors carried as in-engine `$CHAR` literals are byte-faithful on both engines under `ydb_chset=M` (no >255→`?` transport mangling of binary key/sig bytes). | Med — verify on the IRIS arm | Express vectors as hex + decode in-suite; see R-BYTE. |

## 6. Dependency sequencing — the critical path <a id="6-sequencing"></a>

The whole point of this rev: **do the risky, blocking work first**, so dependent
components build on a proven foundation. Phases are gated — a phase does not start
until its predecessor's **exit gate** is green.

```
        ┌─────────────────────────────────────────────────────────────┐
        │ PHASE 0  MUST-CLEAR BLOCKERS (no code ships until all green) │
        │  ├ G-IRIS   probe $SYSTEM.Encryption on foia-t12 (OQ-1)      │
        │  ├ G-ERR    error-code channel design (disjoint negatives)   │
        │  └ G-CI     wire test-optional/coverage-optional into CI     │
        └───────────────┬─────────────────────────────────────────────┘
                        ▼
        ┌─────────────────────────────────────────────────────────────┐
        │ PHASE 1  RS256/384/512 — BOTH engines (highest confidence)   │
        │  RSASSA-PKCS1-v1_5. YDB EVP + IRIS RSASHAVerify. KAT+Wycheproof│
        │  EXIT: dual-engine GREEN, drift-gated, RS\* row in STDJWT green │
        └───────────────┬─────────────────────────────────────────────┘
                        ▼
        ┌─────────────────────────────────────────────────────────────┐
        │ PHASE 2  ES256/384/521 + EdDSA + PS\* — coverage per G-IRIS   │
        │  R‖S↔DER (P-521=66B halves); PSS explicit params; Ed NULL-md  │
        │  EXIT: YDB GREEN all; IRIS GREEN or explicit tracked skip     │
        └───────────────┬─────────────────────────────────────────────┘
                        ▼   (m-layer leaf complete — waterline holds)
        ┌─────────────────────────────────────────────────────────────┐
        │ DEPENDENT COMPONENTS (unblocked, built in order):            │
        │  D1 STDJWT asymmetric leg (m)  — wire verifySig; alg-pin      │
        │  D2 VSLJWT (v)                 — claim→#200/DUZ trust binding │
        │  D3 XUS JWT LOGON RPC + KIDS   — v pkg install; live vehu+foia │
        │  D4 VWEB local-JWT provider (v)— D6 consumer                  │
        └─────────────────────────────────────────────────────────────┘
```

**Why this order:**

1. **Phase 0 is pure de-risking, zero production code.** The three blockers are the
   findings that, if discovered late, force a redesign: the IRIS engine gap (shape of
   §9b), the error-channel collision (shape of §9a), and the CI gap (whether "GREEN"
   means anything). Cheap to answer now; expensive to retrofit.
2. **RS\* before ES\*** — RSA verify is the one alg with a documented IRIS primitive
   (A-3), so it is the fastest path to a *dual-engine* win and de-risks the ABI, the
   dispatch, the packaging, and the CI wiring on the simplest crypto. ES\*/EdDSA then
   add only crypto complexity (R‖S↔DER, NULL-md) on proven plumbing.
3. **Dependent components are strictly downstream** and each has its own gate; none
   starts before the m-leaf it needs is GREEN. STDJWT's asymmetric leg (D1) needs
   Phase 1 (RS\*) at minimum; VSLJWT (D2) needs D1; the RPC (D3) needs D2 and rides
   `v pkg install` (never a bespoke installer — hard org rule); VWEB (D4) needs D1.

## 7. Public API + the security contract <a id="7-api"></a>

A single generic verb keyed by algorithm (extensible; one dispatch path):

```
$$verifySig^STDCRYPTO(alg, pubKey, msg, sig)   ; → 1 valid | 0 invalid
```

- `alg` — JWS alg name (`"RS256"`, `"ES256"`, `"PS384"`, `"EdDSA"`, …).
- `pubKey` — public key as **SubjectPublicKeyInfo, DER or PEM** (raw bytes).
- `msg` — the exact signing-input bytes (`b64url(header)"."_b64url(payload)` for JWS;
  STDCRYPTO does not know that — it hashes+verifies the bytes it's given).
- `sig` — raw signature bytes. **For ES\* the JWT `R‖S` fixed-width concatenation**
  (RFC 7518 §3.4), converted to/from DER internally (§10).

**Return / error contract:**

- `1` = valid; `0` = **invalid** (a normal, non-exceptional answer — never raise on a
  bad signature, so an attacker's forged token yields `0`, not a trap).
- Raise `$ECODE` only for **malformed inputs**: unparseable key
  (`U-STDCRYPTO-BADKEY`), unsupported `alg` (`U-STDCRYPTO-BADALG`), callout absent
  (`U-STDCRYPTO-CALLOUT-MISSING`), internal EVP error (`U-STDCRYPTO-VERIFY-FAIL`).
  These four are distinct codes over a disjoint C return channel (§9a, N-3).

**Security contract (N-1 — MUST be documented on the verb):**

> `verifySig` trusts the caller to have **pinned the expected `alg` (family) against
> policy** before calling, and to supply a **trusted key** — never a key lifted from
> the token's own `jwk`/`x5c`/`kid` header. STDCRYPTO is alg-agnostic *by design* and
> therefore **cannot and does not defend against algorithm confusion** (`alg:none`,
> RS→HS key confusion, header-chosen alg). That defense lives in the caller (STDJWT
> §2.3 step 2 of the consumer proposal): reject `none`, enforce an alg allowlist, and
> pin alg-family to key-type per `kid`. Within this module an RSA key simply fails to
> verify under ES256 (EVP returns `0`), so asymmetric↔asymmetric confusion is
> self-defending; the dangerous RS-pubkey-as-HMAC-secret case lives in STDJWT's HMAC
> path, not here.

Thin per-alg wrappers (`$$verifyRs256`, `$$verifyEs256`, …) are optional sugar; the
generic verb is canonical.

## 8. Current STDCRYPTO architecture (grounded) <a id="8-architecture"></a>

Read from the repo so the extension follows the established pattern exactly:

- **YottaDB backend** — C callouts in `src/callouts/std_crypto.c` (OpenSSL libcrypto,
  `EVP_*`), mapped by `tools/std_crypto.xc` (M symbol → C signature), built by
  `tools/build-callouts.sh` into `std_crypto.so`, seeded by `scripts/seed-callouts.sh`.
  C entry points are argc-prefixed: `int crypto_sha256(int argc, ydb_string_t *in,
  ydb_string_t *out)` and **guard arity** (`if (argc != 2) return -5;`,
  `std_crypto.c:96`).
- **M-side dispatch** — `dispatch3`/`dispatch4` (private, `STDCRYPTO.m:324-354`) build
  a string `"set rc=$&stdcrypto.<sym>(…)"` and `XECUTE` it (the `$&` callout is not
  parseable M inline; the wrap is mandatory). **Note the reuse hazard (N-3):** these
  helpers treat `rc=0` as *success* (`STDCRYPTO.m:336`) — verify must NOT reuse them,
  because for verify `rc=0` means *invalid signature*, a valid answer.
- **IRIS backend** — no `$&pkg.fn` ABI; digests/HMAC use `$SYSTEM.Encryption.SHAHash`/
  `.HMACSHA`, XECUTE-wrapped, engine-branched on `$zversion["IRIS"` at the top of
  `dispatch3/dispatch4` (`STDCRYPTO.m:329,345`).
- **Error model** — callout missing → `U-STDCRYPTO-CALLOUT-MISSING` (via `$ETRAP` →
  `rc=-1`, `STDCRYPTO.m:331,335`); internal libcrypto failure →
  `U-STDCRYPTO-{DIGEST,HMAC}-FAIL`. `$$available^STDCRYPTO()` gates presence
  (`STDCRYPTO.m:299`) but probes only sha256 (N-8).

## 9. Implementation sketch (with the review's fixes) <a id="9-implementation"></a>

### 9a. YottaDB (C callout — primary path)

Descriptor line added to `tools/std_crypto.xc`:

```
verifySig: ydb_int_t crypto_verify(I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*)
           ; args: alg, pubKey(DER/PEM), msg, sig
           ; return: 1 valid | 0 invalid | negative = distinct error (see below)
```

`src/callouts/std_crypto.c` — one function, OpenSSL EVP one-shot verify:

```c
int crypto_verify(int argc, ydb_string_t *alg, ydb_string_t *key,
                  ydb_string_t *msg, ydb_string_t *sig)
{
    if (argc != 4) return -5;                 /* arity guard (matches existing) */
    /* 1. parse SPKI: PEM_read_bio_PUBKEY / d2i_PUBKEY → EVP_PKEY; NULL → -10 BADKEY   */
    /* 2. pick md + padding from alg; unknown alg → -11 BADALG                          */
    /*      RS*→PKCS1  PS*→PSS+MGF1(saltlen=hlen)  ES*→ECDSA  EdDSA→NULL md             */
    /* 3. ES*: caller passes R‖S; split at siglen/2, build ECDSA_SIG DER (§10);         */
    /*         odd/misized siglen → return 0 (invalid, not error)                       */
    /* 4. EVP_DigestVerifyInit(ctx,&pctx,md,NULL,pkey); set PSS params for PS*          */
    /* 5. rc = EVP_DigestVerify(ctx,sig,siglen,msg,msglen)                              */
    /*      1 → return 1 ;  0 → return 0 ;  <0 → return -12 VERIFY-FAIL                 */
}
```

**Distinct negative codes (N-3), disjoint from the existing `-1..-5`:**
`-10` BADKEY · `-11` BADALG · `-12` VERIFY-FAIL. A new private `dispatchV(sym,a,b,c,d)`
mirrors `dispatch4` **but** reads `rc` directly as the verdict:

```
dispatchV(sym,alg,key,msg,sig):
  if $zversion["IRIS" quit $$irisVerify(sym,alg,key,msg,sig)
  new $etrap,rc,cmd
  set $etrap="set $ecode="""" set rc=-99 quit -99"   ; -99 ≡ callout MISSING (M-error)
  set rc="" , cmd="set rc=$&stdcrypto."_sym_"(alg,key,msg,sig)" , @("xecute cmd")
  if rc=-99  set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
  if rc=-10  set $ecode=",U-STDCRYPTO-BADKEY,"          quit 0
  if rc=-11  set $ecode=",U-STDCRYPTO-BADALG,"          quit 0
  if rc<0    set $ecode=",U-STDCRYPTO-VERIFY-FAIL,"     quit 0
  quit rc   ; 1 valid | 0 invalid — the ONLY non-error returns
```

The `$ETRAP` sentinel is `-99` (distinct from every C code) so **callout-missing is
never confused with a C error** — closing the latent `rc=-1` collision (N-3). Add a
symbol-specific probe (N-8): extend `$$available` (or add `$$verifyAvailable`) that
calls `verifySig` with a known-good self-signed KAT and expects `1`, so a stale `.so`
lacking the symbol is distinguished from a healthy one.

### 9b. IRIS (native / helper — gated on OQ-1, G-IRIS)

**RSA (Phase 1):** `$SYSTEM.Encryption.RSASHAVerify(bits,data,sig,pubKey)` — arg
order/key form **to be confirmed on foia-t12** (A-3). New `irisVerify` arm,
XECUTE-wrapped exactly like `irisDigest`/`irisHmac`.

**ECDSA / EdDSA / PSS (Phase 2):** the open question (OQ-1). `$SYSTEM.Encryption`
coverage is unconfirmed; documented fallbacks in escalating cost:
(a) a native method if one exists; (b) `%SYS.X509Credentials` / `%Net.X509`; (c) a
small **ObjectScript helper class shipped with MSL** (a first-class artifact, not a
footnote — this is why G-IRIS gates the design); (d) last resort — mark ES\*/EdDSA
**YDB-only-for-now** with a *tracked owed item and an explicit test skip*, never a
silent dual-engine gap.

### 9c. Build & packaging (with the deploy step, N-5)

- `tools/build-callouts.sh` rebuilds `std_crypto.so` with `crypto_verify` (same
  library filename — **but a new exported symbol**). `libcrypto.so.3`/`.1.1` already
  on the loader path.
- **Deployment is not free (N-5):** `scripts/seed-callouts.sh` recompiles the `.c`
  *inside* the engine container. Every engine that runs `STDCRYPTOTST` must be
  **re-seeded**; if `m-test-engine` bakes the `.so`, the pinned `m-test-engine:0.2.0`
  image (CLAUDE.md) must be **bumped**. Treat the `.so`/image rollout as a tracked
  step (T-DEPLOY).
- Follow the module's lint carve-outs (`STDCRYPTO.m:3-21`): the M-MOD-020 by-ref
  false-positive and the `dispatch*` XECUTE-wrap are already precedented.

> **The routine-vs-native install split — why v-pkg cannot carry the callout, and
> why this is not a new repo — is [§15](#15-packaging).**

## 10. Algorithm details that bite <a id="10-algo-details"></a>

- **ES\* signature encoding.** JWT carries ECDSA sigs as raw **`R‖S` fixed-width
  concatenation** (RFC 7518 §3.4), but OpenSSL `EVP_DigestVerify` expects **DER
  `SEQUENCE{r,s}`**. Convert `R‖S`→`ECDSA_SIG` before verify. **Derive the component
  width from `siglen/2`, not a constant — P-521 is 66-byte halves (132 total), P-256
  is 32 (64 total), P-384 is 48 (96 total)** (N-6). Odd or wrong `siglen` → return `0`
  (invalid). Getting this wrong = every ES\* token silently fails (or, worse, a
  malleable accept). Test against RFC 7515 §A.3 **and** Wycheproof ECDSA.
- **PS\* (PSS) params.** MGF1 with the same SHA, salt length = hash length. Set
  **explicitly** via `EVP_PKEY_CTX` (`EVP_PKEY_CTX_set_rsa_padding` +
  `_set_rsa_pss_saltlen` + `_set_rsa_mgf1_md`); defaults differ across OpenSSL
  versions (RFC 8017 §8.1, RFC 7518 §3.5).
- **EdDSA** uses `EVP_DigestVerify` with a **NULL md** (Ed25519 is a one-shot over the
  message, no pre-hash — RFC 8037 §3.1). Different code path from RS/ES.
- **Key encoding.** Accept SPKI DER/PEM only; document JWK conversion is upstream.
  Reject a bare PKCS#1 `RSAPublicKey` with `U-STDCRYPTO-BADKEY` (or convert) — pick one
  and test it (A-6).

## 11. Security model — the algorithm-confusion boundary <a id="11-security"></a>

This module is positioned as *the foundation JWT security sits on*, so its trust
boundary must be explicit — the original draft's silence here was the review's
top finding (N-1).

- **The seam:** STDCRYPTO answers one question over bytes; it does **not** interpret a
  token, choose a key, or pick an alg. All algorithm policy is the caller's.
- **What STDCRYPTO guarantees:** a correct EVP verify for the (alg, key, msg, sig) it
  is given; a forged signature → `0`; a malformed key → fail-closed `BADKEY`; no
  private-key custody ever.
- **What STDCRYPTO explicitly does NOT defend (caller MUST):**
  1. `alg:"none"` — STDJWT rejects unconditionally.
  2. **Algorithm downgrade / allowlist** — STDJWT enforces a caller-supplied alg
     allowlist; the token never widens it.
  3. **RS→HS key confusion** — pin alg-*family* to key-*type* per `kid` in the JWKS
     registry; the token's `alg` never selects the key type. (Consumer proposal R-2/R-3.)
  4. **Header-supplied keys** (`jwk`/`x5c`) — never trust a key embedded in the token.
- **Key-strength floor (R-WEAK):** `verifySig` will happily verify a 512-bit RSA or a
  non-approved curve. Any floor (e.g. RSA ≥ 2048 per NIST SP 800-131A) lives upstream
  in STDJWT/VSLJWT; stated here so it is not silently absent.
- **Constant-time is *not* needed on this path:** public-key verify compares no secret
  (§3, `$$ctEquals` note). The HMAC path's timing concern (consumer R-7) is a different
  module.

## 12. Test strategy <a id="12-tests"></a>

Known-answer + adversarial, **no VistA, minimal engine** — but wired into the gated
path (N-4).

- **Positive KATs:** RFC 7515 App A.2 (RS256), A.3 (ES256); RFC 8037 A.1 (Ed25519);
  PS256 via a scripted OpenSSL vector checked into `tests/vectors/`.
- **Negative (adversarial) corpus — Google Wycheproof (N-7):** import the ECDSA / RSA
  PKCS1 / EdDSA vector sets. Must cover ECDSA `s=0`/`r=0`, `s>n` (malleability),
  non-canonical DER / extra leading-zero on the `R‖S`→DER re-encode, wrong-curve
  points, all-zero signatures, and RSA PKCS1-v1_5 Bleichenbacher padding-forgery
  vectors. Plus the basics: wrong key → 0; bit-flipped sig → 0; truncated/oversized
  `R‖S` → 0.
- **Error-path tests:** `alg="none"`/unknown → `U-STDCRYPTO-BADALG`; garbage key →
  `U-STDCRYPTO-BADKEY`; callout absent → `U-STDCRYPTO-CALLOUT-MISSING` (mirrors existing
  digest tests). Assert the four codes are *distinct* (regression guard for N-3).
- **Dual-engine:** run the same vectors on YDB (callout) and IRIS (native/helper)
  through the driver stack. Any alg IRIS can't do yet is an **explicit skip with a
  tracked owed item**, never a silent pass. Verify byte-fidelity of binary key/sig
  vectors on the IRIS arm (A-8 / R-BYTE); if `>255→?` mangling appears, express
  vectors as hex and `$$decode^STDHEX` in-suite.
- **CI wiring (N-4, G-CI):** wire `test-optional` + a `coverage-optional` gate into
  `ci.yml` against a seeded engine, so `STDCRYPTOTST` verify cases are part of the
  drift-gated green path — not a manual-only run.
- **TDD order:** write `tests/STDCRYPTOTST.m` verify cases first (RED — stub returns
  0), implement callout + `dispatchV`, confirm GREEN.

## 13. Risk & mitigation register (integrated) <a id="13-risks"></a>

Module-level risks (this proposal owns) plus the seam-relevant consumer risks it must
not break. Severity is post-review.

| # | Risk | Sev | Owner | Mitigation |
|---|---|---|---|---|
| **R-SEC** | Algorithm/key-type confusion — caller passes untrusted-header `alg`; RS→HS forgery in the sibling HMAC path. (N-1) | **High** | STDCRYPTO doc + STDJWT | §7 contract note; STDJWT rejects `none`, enforces alg allowlist, pins alg-family↔key-type per `kid`; red test that a mismatched alg/key returns 0, not a crash. |
| **R-IRIS** | IRIS lacks native ES\*/EdDSA verify → "engine-neutral" fails for ES256 (the most common federated alg). (N-2) | **High** | STDCRYPTO | **G-IRIS**: probe `$SYSTEM.Encryption` on foia-t12 (OQ-1) *before* locking §9b; RS\* both engines first; decide ES\*/EdDSA-on-IRIS shape (helper class?) explicitly; never silently YDB-only. |
| **R-DER** | ES\* `R‖S`↔DER wrong → all ECDSA fail, or malleable accept; P-521 width bug. (N-6) | **High** | STDCRYPTO | Convert in C, width = `siglen/2`; reject odd/misized as invalid(0); RFC 7515 §A.3 + Wycheproof ECDSA (incl. `s>n`, non-canonical DER). |
| **R-ERR** | Single `ydb_int_t` can't encode 4 error modes; latent `rc=-1` etrap↔C collision. (N-3) | **Med** | STDCRYPTO | Disjoint C negatives `-10/-11/-12`; `$ETRAP` sentinel `-99` owns callout-missing; `dispatchV` maps each; distinct-code regression test. |
| **R-CI** | `STDCRYPTOTST` is optional & excluded from coverage → verify code outside the gated path. (N-4) | **Med** | build/CI | **G-CI**: wire `test-optional`+`coverage-optional` into `ci.yml` against a seeded engine. |
| **R-DEPLOY** | New `.so` symbol needs re-seed / pinned-image bump; "same library" masks it. (N-5) | **Med** | build/ops | Tracked deploy step (T-DEPLOY): re-seed via `seed-callouts.sh` or bump `m-test-engine` image; assert `$$verifyAvailable` on the target engine. |
| **R-PARSE** | Malformed SPKI is attacker-reachable (JWKS/issuer-supplied). | Med | STDCRYPTO | OpenSSL parses; fail-closed `BADKEY`; fuzz with Wycheproof malformed-DER + zero/one RSA sigs. |
| **R-PSS** | PSS params defaulted → cross-OpenSSL-version divergence. | Med | STDCRYPTO | Set md/MGF1/saltlen explicitly; pin a PS256 vector. |
| **R-STALE** | Old `.so` (no `verifySig`) reports "available" yet verify always CALLOUT-MISSING. (N-8) | Low | STDCRYPTO | `$$verifyAvailable` probes the symbol with a KAT, not sha256. |
| **R-WEAK** | Accepts sub-strength keys (RSA<2048, non-approved curve). | Low | STDJWT/VSLJWT | Key-strength floor upstream (NIST SP 800-131A); stated so it isn't silently absent. |
| **R-BYTE** | Binary key/sig vectors mangled on the IRIS driver transport (`>255→?`). (A-8) | Low | tests | Assert byte-exact round-trip on the IRIS arm; hex-encode vectors + in-suite decode if needed. |
| **R-ABI** | Callout ABI drift (argc prefix, `ydb_string_t`, `.var` byref). | Low | STDCRYPTO | Follow existing `crypto_*` signatures verbatim; verify-returns-int avoids the byref-output trap the header warns about; `argc!=4` guard. |
| **R-SCOPE** | Scope creep into signing / JWKS / JWT. | Low | STDCRYPTO | Hard scope line (§4): verify-only, key-agnostic, JWT-agnostic. STDJWT owns the rest. |

## 14. Implementation plan & tracker table <a id="14-plan"></a>

One row per unit of work. **Phase 0 gates everything.** `Depends` names the row(s)
that must be GREEN first. `Exit gate` is the objective done-condition. Update status
in `docs/module-tracker.md` (STDCRYPTO in-module ticket) as each lands.

| ID | Phase | Item | Repo | Depends | Exit gate | Status |
|----|-------|------|------|---------|-----------|--------|
| **G-IRIS** | 0 | Probe `$SYSTEM.Encryption` verify surface on foia-t12 via the m-iris driver (read-only): RSA arg order/key form; ECDSA/EdDSA/PSS presence. | m-stdlib | — | OQ-1 answered; §9b shape decided (native vs helper vs YDB-only) | ☐ |
| **G-ERR** | 0 | Finalize disjoint C error codes + `dispatchV` mapping + `-99` etrap sentinel. | m-stdlib | — | Design note in `docs/design/`; distinct-code test written (RED) | ☐ |
| **G-CI** | 0 | Wire `test-optional` + `coverage-optional` into `ci.yml` against a seeded engine. | m-stdlib | — | CI runs STDCRYPTOTST; green on current suite | ☐ |
| **T-C-RS** | 1 | `crypto_verify` C fn — RSA PKCS1-v1_5 path (RS256/384/512); arity guard; SPKI parse. | m-stdlib | G-ERR | Compiles; RS\* KAT+Wycheproof GREEN on YDB | ☐ |
| **T-IRIS-RS** | 1 | `irisVerify` RSA arm (`RSASHAVerify`, confirmed form). | m-stdlib | G-IRIS, T-C-RS | RS\* KAT GREEN on IRIS (foia-t12) | ☐ |
| **T-M-RS** | 1 | `$$verifySig` + `dispatchV` + `$$verifyAvailable`; RS\* wrappers. | m-stdlib | T-C-RS | `STDCRYPTOTST` RS\* dual-engine GREEN, drift-gated | ☐ |
| **T-DEPLOY** | 1 | Re-seed `.so` / bump `m-test-engine` image for the new symbol. | m-stdlib | T-C-RS | `$$verifyAvailable`=1 on test + CI engines | ☐ |
| **T-C-ES** | 2 | ECDSA path + `R‖S`↔DER (width=`siglen/2`, P-521=66B); EdDSA NULL-md; PS\* PSS params. | m-stdlib | T-M-RS | ES\*/EdDSA/PS\* KAT+Wycheproof GREEN on YDB | ☐ |
| **T-IRIS-ES** | 2 | IRIS ES\*/EdDSA/PSS per G-IRIS outcome (native/helper) OR tracked skip. | m-stdlib | G-IRIS, T-C-ES | IRIS GREEN, or explicit skip + owed-item in tracker | ☐ |
| **D1** | dep | STDJWT asymmetric leg — wire `verifySig`; reject `none`; alg allowlist; alg-family↔key-type pin. | m-stdlib | T-M-RS (RS\*), T-C-ES (ES\*) | STDJWT RS256/ES256 verify GREEN vs RFC 7515 App A | ☐ |
| **D2** | dep | VSLJWT — claim→#200/DUZ trust binding (SecID→UPN precedence; must pre-exist). | v-stdlib | D1 | Unit-tested w/ fabricated #200 + self-signed keys | ☐ |
| **D3** | dep | `XUS JWT LOGON` RPC + KIDS build; install via `v pkg install`. | v-stdlib | D2 | Live signon→DUZ on vehu (YDB) + foia (IRIS) via driver stack | ☐ |
| **D4** | dep | VWEB local-JWT provider (D6 consumer). | v-* | D1 | VWEB bearer path GREEN | ☐ |

*Optional P2 (out of current scope): asymmetric **signing** (`crypto_sign`) — only if
VistA becomes a token issuer (OQ-3). The C descriptor may reserve the slot.*

## 15. Packaging & installation <a id="15-packaging"></a>

**Decision: STDCRYPTO stays in m-stdlib (no new repo); its M routines can ride
`v pkg` into a VistA; its native callout CANNOT — and must not — go through
`v pkg`/KIDS. The native part is a YDB engine-runtime dependency owned by the
m/engine layer.** Rationale below.

### 15.1 One premise corrected: only YDB needs compiled C

The native dependency is **YDB-only**. The YDB arm calls `$&stdcrypto.<fn>` →
`std_crypto.so` (libcrypto), but the **IRIS arm uses `$SYSTEM.Encryption` natively —
no `.so`, no compiled code** (`STDCRYPTO.m:329,345,367-388`). For the asymmetric-verify
ext, IRIS at most needs a bundled **ObjectScript helper class** (per the OQ-1 outcome,
§9b) — that is **routine source**, not a compiled binary, deployable over the existing
`irissync`/Atelier REST path (`m deploy`; memory `m-stdlib-iris-deploy`). So the
"compiled C" concern collapses to **one artifact on one engine: `std_crypto.so` on YDB.**

### 15.2 The install decomposes into two parts with different owners

| Part | What it is | Delivered by |
|---|---|---|
| **M routines** (`STDCRYPTO.m` …) | portable text | Bare engine: routine path (`--routines src`). Into a VistA: the **MSL KIDS build `MSL*0.1*1`** via `v pkg install` (memory `kids-ship-all-routines`; needs `allowLongNames`). Into IRIS: `m deploy` / `irissync`. |
| **Native callout** (`std_crypto.so` + `.xc` descriptor + `ydb_xc_stdcrypto`/`STDLIB_LIB` env + the YDB external call-out table) | host-filesystem binary + process environment | **A YDB engine-provisioning step — NOT `v pkg`/KIDS** (§15.3). Today: `tools/build-callouts.sh` + `scripts/seed-callouts.sh`. |

So **`v pkg` legitimately installs the *routine* half** when the target is a VistA; it
never touches the native half. The two are independent.

### 15.3 Why KIDS / `v pkg` structurally cannot carry the callout

This is a hard technical boundary, not a preference:

- KIDS transports **globals and routines *inside* the M database**. A `.so`, its `.xc`,
  the env vars, and the YDB external call-out table all live **outside** the database —
  on the host filesystem and in the process environment.
- A KIDS pre/post-install routine runs as M code inside an **already-started** process.
  It **cannot `gcc`-compile** a platform-specific `.so`, and it **cannot set
  `ydb_xc_stdcrypto`** — that env var must be present in the process environment *before*
  the M process starts. Even a clever KIDS build cannot wire the callout.
- Shipping a prebuilt binary blob through KIDS would defeat KIDS's purpose
  (platform-independent M transport) and its reversal/audit model.

This is *why* the org already ships all three `@tier optional` callout modules
(STDCRYPTO, STDCOMPRESS, STDHTTP) outside `v pkg` — see §15.5.

### 15.4 The "never a bespoke installer" rule does not apply here

The hard org directive ([[never-use-bespoke-installer]]) — *"install/back-out is
strictly `v pkg install`/`uninstall` of a drift-gated KIDS build"* — governs **VistA M
packages/patches** (the KIDS domain), where a hand-rolled patcher would bypass KIDS's
reversal + audit. A native **shared-library system dependency** (like libz or libcurl)
is categorically outside KIDS's scope — KIDS was never able to carry it, so a
callout-install mechanism is not the "bespoke installer" that rule forbids. The rule's
phrasing is broad ("for any M engine"), so **this interpretation wants an owner nod
before it is codified** (an open governance item, not a build blocker).

### 15.5 The decision is already set by precedent — this ext changes nothing

STDCRYPTO **already ships a native callout today** (SHA/HMAC), as do STDCOMPRESS
(libz/libzstd) and STDHTTP (libcurl). All three are `@tier optional`, share
`tools/build-callouts.sh` (per-platform `so/<plat>/`) + `scripts/seed-callouts.sh`, and
are **not** `v pkg`-installed. **Adding `verifySig` is just a new symbol in the existing
`std_crypto.so`** — no new class of install problem, only a re-seed / engine-image bump
(tracked as R-DEPLOY / T-DEPLOY). So the install method already exists and already isn't
`v pkg`.

### 15.6 Recommendation

1. **Keep STDCRYPTO in m-stdlib.** A separate repo would fragment the three callout
   modules that share one build/seed mechanism and buy nothing — the problem is not
   ownership, it is that a `.so` is not a KIDS artifact.
2. **`v pkg` for the routine half only**, and only when the target is a VistA
   (`MSL*0.1*1`). Bare engines use the routine path; IRIS uses `m deploy`.
3. **Own the native half as a first-class engine-runtime concern, not a per-library
   installer.** Promote the dev-only `seed-callouts.sh` (it SSHes into the vista-meta
   container and hardcodes a dev topology) into either (a) a baked **m-test-engine image**
   layer, or (b) a platform-portable **`m callouts install`** verb in the m toolchain
   (build → place `.so`/`.xc` → configure the engine's call-out table + env), shared by
   all three optional modules. This is the durable form of T-DEPLOY.
4. **IRIS needs no `.so`;** any IRIS asymmetric helper is an ObjectScript class shipped
   as routine source via `m deploy` — so it *can* ride the IRIS routine-deploy path (and,
   for a VistA-IRIS, be packaged into the MSL routine build), unlike the YDB binary.

> **Follow-up (separate from this proposal):** the `m callouts install` verb / engine-image
> mechanism is an **m-toolchain / m-engine** work item, not STDCRYPTO-specific. File it
> against m-cli/m-engine so STDCOMPRESS and STDHTTP inherit it too.

## 16. Open questions <a id="16-open-questions"></a>

1. **OQ-1 (blocking, G-IRIS).** Which `$SYSTEM.Encryption` verify methods exist on
   foia-t12 and their signatures — `RSASHAVerify` arg order/key form; any ECDSA/EdDSA/
   PSS? Drives §9b and whether ES\*/EdDSA are dual-engine at Phase 2.
2. **OQ-2.** Key-encoding contract: SPKI-only, or also accept PKCS#1 `RSAPublicKey`
   and/or JWK? Lean SPKI DER/PEM only; JWK conversion upstream in STDJWT (A-6).
3. **OQ-3.** Is asymmetric *signing* ever in scope (VistA-as-issuer), or verify-only
   forever? Affects whether the C descriptor reserves `crypto_sign`.

## 17. References <a id="17-references"></a>

### 17.1 Industry standards implemented

- **RFC 7515** — JSON Web Signature (JWS): §3 signing-input, App **A.2** (RS256),
  **A.3** (ES256, the `R‖S` KAT).
- **RFC 7517** — JSON Web Key (JWK) — the upstream key format STDJWT converts from.
- **RFC 7518** — JSON Web Algorithms (JWA): **§3.3** RSASSA-PKCS1-v1_5, **§3.4** ECDSA
  `R‖S` fixed-width encoding, **§3.5** RSASSA-PSS; alg identifiers.
- **RFC 7519** — JSON Web Token (JWT).
- **RFC 8037** — CFRG curves in JOSE (EdDSA/Ed25519), App **A.1** vector.
- **RFC 8017** — PKCS #1 v2.2: **§8.1** RSASSA-PSS, **§8.2** RSASSA-PKCS1-v1_5.
- **RFC 9068** — JWT Profile for OAuth 2.0 Access Tokens (the consumer bearer profile).
- **RFC 6749 / RFC 6750** — OAuth 2.0 + Bearer Token Usage (federation context).
- **FIPS 186-5** — Digital Signature Standard (ECDSA, EdDSA); **FIPS 180-4** — SHA-2.
- **NIST SP 800-131A** — key-strength transitions (RSA ≥ 2048; R-WEAK).
- **NIST SP 800-63-3** — Digital Identity / Levels of Assurance (maps to
  `DUZ("LOA")` / SIGN-ON LOG #3.081 LEVEL OF ASSURANCE #101 in the consumer).
- **SEC 1 / ANSI X9.62** — EC signature (`r,s`) DER `SEQUENCE` encoding.
- **Google Wycheproof** — ECDSA / RSA-PKCS1 / EdDSA adversarial test vectors (§12).
- **OpenSSL** — `EVP_DigestVerify`, `EVP_PKEY_CTX` PSS params, `ECDSA_SIG` i2d/d2i.

### 17.2 In-repo grounding (measured/read)

- `src/STDCRYPTO.m` — `dispatch3`/`dispatch4` (`:324-354`), `available` (`:299`),
  `irisDigest`/`irisHmac` (`:367-388`), `zeros`, header ABI + lint carve-out notes
  (`:1-88`).
- `src/callouts/std_crypto.c` — `crypto_*` EVP signatures, argc guards (`:94-128`),
  status-code table (`:32-39`).
- `tools/std_crypto.xc` — descriptor format (I:/O: buffers).
- `tools/build-callouts.sh`, `scripts/seed-callouts.sh` — build + in-container seed
  (the T-DEPLOY step, N-5).
- `src/STDJWT.m` — HS256-only verify, non-HS256 loud reject (`:56`), opts `alg`
  (`:55`); `Makefile:111-135` — optional-suite / coverage-exclusion split (N-4).
- `docs/module-tracker.md` — #38 STDJWT v0.13.0 (`:125`);
  `docs/proposals/future-modules-plan.md:189` — the public-key-sig ticket row.

### 17.3 Live-probed VistA code (measured/probed:) — via the consumer

Engine: WorldVistA **`vehu`**, GT.M V7.0-005, driver `r2.02`; the approved
`m-driver-sdk → m-ydb` docker seam; **reads only**. (Full block:
[`vsl-jwt-auth.md` §B](../../../v-stdlib/docs/proposals/vsl-jwt-auth.md).)

- Routines: `XUSRB` (`SETUP`/`VALIDAV`), `XUS` (`CHECKAV` shape-dispatch), `XUSRB1`
  (`ENCRYP`/`DECRYP` keyless obfuscation), `XUP` (`DUZ(DA)` seam), `XUSBSE1`
  (BSE mint/validate, `^XTMP`), `XUSHSH`/`XUSHSHP` (redacted hash on FOIA build).
- Globals/files: `^XWB(8994,` #8994 REMOTE PROCEDURE, `^XWB(8994.5,` #8994.5 REMOTE
  APPLICATION (42 partners), `^VA(200,` #200 NEW PERSON (auth fields
  #2/#11/#205.1/#501.1), `^XUSEC(0,` #3.081 SIGN-ON LOG, `%ZUA(3.05,` #3.05 FAILED
  ACCESS.
- vista-meta (measured): `code-model/rpcs.tsv`, `data-model/files.tsv`,
  `field-piks.tsv` — VEHU/YottaDB, extracted 2026-07-03.

### 17.4 vdocs GOLD corpus (documented:)

Anchors given as `vdocs://section/...`. The decisive one for this work is the
**documented VistA signature-verification model** the JWS verifier generalizes:

- **`XU/krn_8_0_sm_signon_security_ug/failed-verifications-for-token-ssoi`** — Kernel's
  SSOi-token verification failure modes: **SECID** (no #200 match), **EXPIRED**,
  **CAFILE** (CA chain `cache.cer`), **DIGEST** (token modified), **SIGNATURE**
  (signature verification failed). This is VistA's own *documented* signed-token
  verify — `verifySig` is exactly the SIGNATURE/DIGEST step, generalized from SAML to
  JWS. (Maps to R-SEC / §11.)
- **`XWB/xwb_1_1_dg_r/xwb1165`** (XWB\*1.1\*65) — 2-Factor Auth via IAM STS: PIV cert +
  PIN *"exchanged for a **digitally signed token** … forwarded to VistA to authenticate
  and identify the user."* The existing asymmetric-token precedent JWT joins.
- **`XWB/xwb_1_1_ug_r/txwbssoitoken-component`** — `TXWBSSOiToken` obtains a **SAML
  token** from IAM STS, offered *"separately for … applications that might need to
  obtain a SAML token for authentication into non-RPC-Broker applications"* — the
  federation seam a JWT bearer layer slots beside.
- **`XU/krn_8_0_dg_signon_security_ug/validavxusrb-vistalinkvalidate-user-credentials`**
  — **`VALIDAV^XUSRB`** (ICR **#4054**), *"validates a … credential … returns
  `R(0)=DUZ`"* — the canonical documented credential→DUZ API `LOGON^VSLJWT` mirrors.
- **`XU/krn_8_0_dg_common_services_ug/vpidxups-…`** / **`…/ienxups-…`** — **`$$VPID^XUPS(duz)`**
  and **`$$IEN^XUPS(vpid)`** — the bidirectional external-identifier ↔ #200/DUZ binding
  APIs (D2 claim→DUZ mapping).
- **`XU/krn_8_0_sm_signon_security_ug/2-factor-authentication-2fa`** — 2FA in KERNEL
  SYSTEM PARAMETERS #8989.3; **STRICT TOKEN VALIDATION #220** (XU\*8.0\*701); explicitly
  FileMan-editable *"if VistA is installed in a non-VA environment"* (relevant to the
  engine-neutral posture).
- **`XU/krn_8_0_dg_tls/overview`** — `XUS START TLS` → `INITRPC^XUTLS`, **XU\*8\*787**:
  TLS is the transit security a bearer token must ride (consumer R-1).
- **`XU/krn_8_0_sm_signon_security_ug/print-sign-on-log-option`** — SIGN-ON LOG #3.081
  **LEVEL OF ASSURANCE #101** (NIST SP 800-63) + **CREDENTIAL TYPE #102** (`AVCODES`,
  `SSOI`) — where a `"JWT"` credential type + `DUZ("LOA")` land.
- **`XWB/xwb_1_1_ug_r/kernel-authentication-token`** — Broker token/"handle" format
  `XWBHDL…`, stored in `^XTMP` — the `jti`-denylist / revocation storage pattern (R-4).

> **Not in the vdocs GOLD corpus (corpus-confirmed absent):** a VistA-native
> **OAuth2/OIDC authorization server**, **SMART-on-FHIR** bearer resource server, or
> **"VXSMART"**. VistA's documented bearer precedent is a **SAML assertion from IAM STS,
> signature/digest/expiry/CA-chain-verified by Kernel, SecID→#200**. This work
> introduces the **JWS/JWT variant** of that same verify→map-subject→DUZ shape.

### 17.5 vista-meta (measured:) — consumer identity surface

- `code-model/rpcs.tsv` — signon RPCs: `XUS SIGNON SETUP`→`SETUP^XUSRB` (ien 10),
  `XUS AV CODE`→`VALIDAV^XUSRB` (12), `XUS GET USER INFO`→`USERINFO^XUSRB2` (595);
  token/SSOi: `XUS ESSO VALIDATE`→`ESSO^XUESSO4` (3482), IAM `XUESSO3/4`,
  `XOBV VALIDATE SAML`→`SAML^XOBVSAML` (3998); BSE `XUSBSE1` (SET/GET VISITOR 2344/2345).
- `data-model/field-piks.tsv` `file_number=200` — the claim-binding fields:
  **#205.1 SECID**, **#205.5 ADUPN**, **#501.1 NETWORK USERNAME**,
  **#501.2 SUBJECT ALTERNATIVE NAME**, #9000 VPID, #9 SSN. Provenance: data-v1,
  VEHU/YottaDB, extracted 2026-07-03 (field volumes = demo data; structure = shipped).

### 17.6 Internal / org references

- [`stdcrypto-asymmetric-verify.md`](superseded/stdcrypto-asymmetric-verify.md) — original design
  (superseded by this rev for implementation).
- [`stdcrypto-asymmetric-verify-review.md`](superseded/stdcrypto-asymmetric-verify-review.md) —
  the adversarial review whose findings (N-1…N-8) this rev integrates.
- [`../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`](../../../v-stdlib/docs/proposals/vsl-jwt-auth.md)
  — the VistA consumer (D2/D3); names this as its critical-path prerequisite.
- `../../../docs/background/m-v-waterline-adr.md` — the m/v boundary (this stays
  m-layer; no VistA symbol; consumed upward by STDJWT → VSLJWT).
- Org rule — *never a bespoke installer*: ship/back-out only via `v pkg install` /
  `v pkg uninstall` of a drift-gated KIDS build (D3).
- Org rule — *engine access only through the driver stack* (A-7).
