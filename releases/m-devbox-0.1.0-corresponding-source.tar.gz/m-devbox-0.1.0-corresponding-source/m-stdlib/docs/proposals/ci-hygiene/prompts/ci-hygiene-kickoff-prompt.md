# Kickoff prompt — m-stdlib CI hygiene (release red, examples-live, lint backlog)

> Working scaffolding for a single-repo fix effort; `git mv` to `docs/archive/`
> when the effort lands. Launch the session with **cwd
> `~/vista-forge/m-stdlib`** and paste the prompt below.

---

You are cleaning up the **non-green workflows on m-stdlib** (found during the
doc-accuracy P2 close-out, 2026-07-03). Context: the main `CI` and
`docs-validate` workflows are green as of `217e2e7` (the STDJWTTST detab +
`check-docs-prose` exception for `docs/readme-gen.toml`); what remains is
release/auxiliary hygiene. Work only in this repo; Increment Protocol applies
(gates → commit straight to `main` → push).

**1. `release.yml` — red on the v0.13.0 tag (2026-06-18, run 27747100843).**
"Build distributable" dies in seconds: `tar: CHANGELOG.md: Cannot stat: No
such file or directory`. The repo has **`docs/changelog.md`**, not a root
`CHANGELOG.md` — the tar list and the tree disagree. Decide which side lies
(root-file rules apply: `CHANGELOG.md` = release notes, `CHANGES.md` =
decision journal — never conflate; check inbound links before moving
anything). Then fix and **verify**: a tag-triggered workflow won't re-run
from a `main` fix, so either add `workflow_dispatch` to `release.yml` and
dispatch it, or prove it with the next real release tag — don't call it
fixed on inspection alone. Also confirm the v0.13.0 GitHub Release either
exists correctly or is created/repaired once the build step works.

**2. `examples-live` — last run user-cancelled on the retired `master` ref
(2026-06-24).** The workflow is `workflow_dispatch`-only (no cron), so this
is not silent drift, but its last recorded state is noise. Re-dispatch it on
`main` and get a green run on record, or — if it is being retired — remove
the caller workflow and note why. Don't leave a cancelled run as the latest
word.

**3. Advisory lint backlog (optional, decide-and-record).** `make lint` is
green because the gate counts error-severity only, but the run reports
227 style + 12 warning findings (mostly M-MOD-009 commands-per-line, plus an
M-MOD-008 argument-count). Either burn the backlog down (mechanical, suite
must stay green: core + optional both engines), or record explicitly in the
module tracker that style findings stay advisory — one decision, written
down, not an ambient TODO.

**Exit gates (verify, don't assume):** release build step proven green by an
actual run · examples-live's latest run on `main` is green or the workflow is
deliberately removed · lint-backlog decision recorded · `make check` green ·
central doc-accuracy tracker New-finds updated with SHAs.

**Constraints:** engine work only through `m test --engine ydb --docker
m-test-engine --chset m` / the driver stack (org hard rule). TDD for any new
script logic. Stage only files you touched. No status prose in the README
(the truth gate checks you); status goes in the tracker.
