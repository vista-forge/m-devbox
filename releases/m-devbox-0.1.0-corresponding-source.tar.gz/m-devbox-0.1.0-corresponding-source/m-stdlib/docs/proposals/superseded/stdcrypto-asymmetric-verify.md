---
title: "STDCRYPTO asymmetric signature verify — the foundation for JWT/JWS"
status: superseded
tracker: docs/module-tracker.md
created: 2026-07-09
last_modified: 2026-07-09
revisions: 1
doc_type: [PROPOSAL]
---

# STDCRYPTO asymmetric signature verify (RS/PS/ES/EdDSA)

> **Status: draft.** This proposes a bounded extension to the existing `STDCRYPTO`
> module — **public-key signature *verification*** — as the engine-neutral foundation
> the **already-shipped** `STDJWT` (RFC 7519/7515, HS256 today) needs to complete its
> asymmetric leg, and that the VistA-side `VSLJWT` bearer-token auth depends on. It builds nothing above the waterline and needs no VistA.
>
> **Why now:** `STDCRYPTO` today has HMAC but **no asymmetric verify**, and every real
> federated issuer (VA SSOi/IAM, Login.gov, any OIDC IdP) signs with **RS256 / ES256**,
> not HMAC. Symmetric HS256 needs a shared secret and cannot federate. This is the leaf
> everything asymmetric-JWT sits on.

## 0. Relationship to existing work (read first)

This is **not a new module and not a new idea** — it is the concrete design for work
already on the books, verified against the repo:

- **`STDJWT` already exists** — shipped **v0.13.0**, dual-engine GREEN 28/28
  (`module-tracker.md #38`): `$$verify`/`$$decode`/`$$claim`/`$$sign`/`$$lastError` with
  **HS256** signatures + `exp`/`nbf`/`iss`/`aud`. **Non-HS256 `alg` is rejected loudly
  (never silent-accept)** until this lands. So JWT is *partly built*; this proposal
  unblocks its **RS256/ES256/EdDSA leg**, nothing more.
- **This extension is already listed** in `future-modules-plan.md` → *"STDCRYPTO
  in-module extensions (tracker tickets, not new modules)"* as **"Public-key signatures —
  Ed25519 + RSA (RS256) verify/sign … Unblocks `STDJWT` RS256/EdDSA … Co-driven with
  STDJWT (Pri 3) / `VWEB` D6."** This doc is the design behind that one-line row; it
  should be tracked as a **STDCRYPTO in-module ticket in `module-tracker.md`**, not a new
  module row.
- **`$$ctEquals` (constant-time compare) is separate and already partly landed** — it
  lives as private `cteq` inside `STDJWT` today, to be promoted to public
  `$$ctEquals^STDCRYPTO` on a second consumer. It is orthogonal to this proposal
  (EVP does the signature compare internally); noted only so the two aren't conflated.
- **Two consumers** are waiting, not one: `VSLJWT`/VistA bearer auth
  (`../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`) **and** the `VWEB` HTTPS stack's
  local-JWT provider (D6). This is co-driven, which is why it earns a design doc.

## 1. Motivation & scope

JWT/JWS verification decomposes into primitives `STDCRYPTO` already owns —
base64url-decode (`STDB64`), JSON parse (`STDJSON`), and **signature check** — except
the asymmetric signature check does not exist yet. `STDCRYPTO`'s own header lists
Ed25519 sign/verify as an explicit TODO.

**In scope (this proposal):** public-key signature **verify** for the JWS algorithm
families —
- **RS256 / RS384 / RS512** — RSASSA-PKCS1-v1_5 + SHA-2
- **PS256 / PS384 / PS512** — RSASSA-PSS + SHA-2
- **ES256 / ES384 / ES512** — ECDSA (P-256/384/521) + SHA-2
- **EdDSA (Ed25519)** — one-shot EVP

**Out of scope (deliberately):**
- **Asymmetric *signing* / private keys.** Verify never holds a secret; signing puts a
  private key in engine custody — a much larger security surface. Deferred to a possible
  P2 (only needed if VistA itself becomes a token *issuer*; not needed to *accept*
  tokens). HS256 minting already works via existing HMAC.
- JWT structure, claim validation, JWKS, `kid` selection — those belong to the existing
  `STDJWT` (engine-neutral) and `VSLJWT` (VistA binding). This module only answers:
  *"is this signature valid for this message under this public key and alg?"*

## 2. Current STDCRYPTO architecture (grounded — do not re-derive)

Read from the repo, so the extension follows the established pattern exactly:

- **YottaDB backend** — C callouts in `src/callouts/std_crypto.c` (OpenSSL libcrypto,
  `EVP_*`), mapped by the descriptor **`tools/std_crypto.xc`** (M symbol → C signature),
  built by `tools/build-callouts.sh` into `std_crypto.so`, seeded by
  `scripts/seed-callouts.sh`. C entry points are argc-prefixed:
  `int crypto_sha256(int argc, ydb_string_t *in, ydb_string_t *out)`.
- **M-side dispatch** — `dispatch3` / `dispatch4` (private) build a **string**
  `"set rc=$&stdcrypto.<sym>(…)"` and `XECUTE` it (the `$&` callout is not parseable
  M inline; the wrap is mandatory, per the header's ABI note that YDB r2.02 rejects
  `$ZF` `.var` byref-output). Output buffers are pre-allocated with `zeros(n)`.
- **IRIS backend** — no `$&pkg.fn` ABI; digests/HMAC use `$SYSTEM.Encryption.SHAHash` /
  `.HMACSHA`, also XECUTE-wrapped (`$SYSTEM.<class>.<method>` isn't grammar-parseable),
  engine-branched at the top of `dispatch3/dispatch4` on `$zversion["IRIS"`.
- **Error model** — callout missing → `U-STDCRYPTO-CALLOUT-MISSING`; internal libcrypto
  failure → `U-STDCRYPTO-{DIGEST,HMAC}-FAIL`. `$$available^STDCRYPTO()` gates presence.

**The extension therefore is small and symmetric:** one new C function + one descriptor
line + one new IRIS arm + one new M dispatch helper + the public entry point.

## 3. Proposed public API

A single generic verb keyed by algorithm (extensible; one dispatch path):

```
$$verifySig^STDCRYPTO(alg, pubKey, msg, sig)   ; → 1 valid | 0 invalid
```

- `alg` — JWS alg name (`"RS256"`, `"ES256"`, `"PS384"`, `"EdDSA"`, …).
- `pubKey` — the public key as **SubjectPublicKeyInfo, DER or PEM** (raw bytes). JWK →
  key-material conversion (RSA `n`/`e`, EC `crv`/`x`/`y`) is a **`STDJWT` concern**, not
  this module's — STDCRYPTO takes a standard key encoding and stays JWT-agnostic.
- `msg` — the exact signing input bytes (for JWS: `b64url(header)"."_b64url(payload)`;
  STDCRYPTO does not know that — it just hashes+verifies the bytes it's given).
- `sig` — raw signature bytes. **For ES\* the JWT `R‖S` fixed-width concatenation**
  (RFC 7515 §3.4), which STDCRYPTO converts to/from DER internally (see §5).

**Return / error contract:**
- `1` = signature valid; `0` = signature **invalid** (a normal, non-exceptional answer —
  never raise on a bad signature).
- Raise `$ECODE` for **malformed inputs**: unparseable key
  (`U-STDCRYPTO-BADKEY`), unsupported `alg` (`U-STDCRYPTO-BADALG`), callout absent
  (`U-STDCRYPTO-CALLOUT-MISSING`), internal EVP error (`U-STDCRYPTO-VERIFY-FAIL`).
- Keep the invalid-vs-error split crisp: an attacker's forged token yields `0`, not an
  exception, so callers branch on the boolean without a trap.

Thin per-alg wrappers (`$$verifyRs256`, `$$verifyEs256`, …) are optional sugar over the
generic verb; the generic verb is canonical.

## 4. Implementation sketch

### 4a. YottaDB (C callout — the primary path)

Descriptor line added to `tools/std_crypto.xc`:
```
verifySig: ydb_int_t crypto_verify(I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*, I:ydb_string_t*)
           ; args: alg, pubKey(DER/PEM), msg, sig   → 1 valid | 0 invalid | <0 error
```

`src/callouts/std_crypto.c` — one function, OpenSSL EVP one-shot verify:
```c
int crypto_verify(int argc, ydb_string_t *alg, ydb_string_t *key,
                  ydb_string_t *msg, ydb_string_t *sig)
{
    /* 1. parse SubjectPublicKeyInfo: PEM_read_bio_PUBKEY / d2i_PUBKEY  → EVP_PKEY */
    /* 2. pick md + padding from alg (RS*→PKCS1, PS*→PSS+MGF1, ES*→ECDSA, EdDSA→NULL md) */
    /* 3. EVP_DigestVerifyInit(ctx, &pctx, md, NULL, pkey); set PSS params for PS* */
    /* 4. sig for ES*: caller passes R‖S; convert to ECDSA_SIG DER here (see §5) */
    /* 5. rc = EVP_DigestVerify(ctx, sig, siglen, msg, msglen);  1 ok, 0 bad, <0 err */
    /* return 1 / 0 / negative; no output ydb_string_t needed — the int IS the answer */
}
```
Returns via the int (no `zeros()` output buffer needed — this is verify, not digest).
A new private `dispatchV(sym,a,b,c,d)` mirrors `dispatch4` but reads `rc` directly as
the verdict (`rc<0`→error `$ECODE`; else `rc` is the boolean).

### 4b. IRIS (native, XECUTE-wrapped)

New `irisVerify` arm. **RSA** has a native method
(`$SYSTEM.Encryption.RSASHAVerify(bits,data,sig,pubKey)` — arg order/key form to be
confirmed on foia, §8). **ECDSA / EdDSA / PSS** coverage in `$SYSTEM.Encryption` is the
open question — fallbacks if absent: `%SYS.X509Credentials` / a small `%SQL`-free
ObjectScript helper class shipped with MSL, or (last resort) mark ES\*/EdDSA
YDB-only-for-now and land RS\* on both engines first. This is a real dual-engine gap to
close, not to hand-wave (§8, R-4).

### 4c. Build & packaging

- `tools/build-callouts.sh` rebuilds `std_crypto.so` with the new function (no new .so;
  same library). `libcrypto.so.3`/`.1.1` already required on the loader path.
- MSL KIDS packaging carries the routine; the `.so` ships via the existing callout
  seed/install path (`scripts/seed-callouts.sh`) — same as today's digest/HMAC callouts.
- Follow the module's lint carve-outs: the M-MOD-020 by-ref false-positive pattern and
  the `dispatch*` XECUTE-wrap already precedented in this file.

## 5. Algorithm details that will bite if ignored

- **ES\* signature encoding.** JWT/JWS carries ECDSA signatures as the **raw `R‖S`
  fixed-width concatenation** (64 bytes for ES256), but OpenSSL `EVP_DigestVerify`
  expects **DER `SEQUENCE{ r, s }`**. STDCRYPTO must convert `R‖S` → `ECDSA_SIG` DER
  before verify (and the reverse if signing is ever added). Getting this wrong = every
  ES\* token silently fails. Test against RFC 7515 §A.3.
- **PS\* (PSS) params.** MGF1 with the same SHA, salt length = hash length. Set
  explicitly via `EVP_PKEY_CTX`; defaults differ across OpenSSL versions.
- **EdDSA** uses `EVP_DigestVerify` with a **NULL md** (Ed25519 is a one-shot over the
  message, no pre-hash). Different code path from RS/ES.
- **Key encoding.** Accept SPKI DER/PEM only; document that JWK conversion is upstream.
  Reject a bare RSA `PKCS#1` key (RSAPublicKey) with `U-STDCRYPTO-BADKEY` or convert —
  pick one and test it.

## 6. Test strategy (TDD, engine-light)

Known-answer verification — **no VistA, minimal engine**:
- **RFC 7515 Appendix A** JWS examples: A.2 (RS256), A.3 (ES256) — canonical
  header/payload/sig triples; assert `verifySig`→1, and a bit-flipped sig→0.
- **RFC 8037 A.1** Ed25519 vector.
- **PS256** via an OpenSSL-generated vector (scripted, checked into `tests/vectors/`).
- **Negative cases:** wrong key → 0; truncated sig → 0; `alg="none"`/unknown → raise
  `U-STDCRYPTO-BADALG`; garbage key → raise `U-STDCRYPTO-BADKEY`; callout absent →
  `U-STDCRYPTO-CALLOUT-MISSING` (mirrors existing digest tests).
- **Dual-engine:** run the same vectors on YDB (callout) and IRIS (native) through the
  driver stack; any alg IRIS can't do yet is an explicit skip with a tracked owed item,
  not a silent pass.
- TDD order: write `tests/STDCRYPTOTST.m` verify cases first (RED — stub returns 0),
  implement callout + dispatch, confirm GREEN.

## 7. Risks & mitigations

| # | Risk | Sev | Mitigation |
|---|---|---|---|
| **R-1** | Invalid signature raised as an error → callers mis-handle a *normal* attacker input. | High | Hard contract: bad signature = return `0`; only malformed **inputs** raise. Tested both ways. |
| **R-2** | ES\* `R‖S`↔DER conversion wrong → all ECDSA tokens fail (or, worse, malleable accept). | High | Convert in C against RFC 7515 §A.3 vectors; negative test on truncated/oversized `R‖S`. |
| **R-3** | PSS params defaulted → cross-OpenSSL-version verify divergence. | Med | Set md/MGF1/saltlen explicitly; vector test pinned. |
| **R-4** | IRIS lacks native ES\*/EdDSA verify → dual-engine gap. | Med | Confirm `$SYSTEM.Encryption` coverage on foia first (§8); land RS\* both engines, track ES\*/EdDSA IRIS as an owed item — never silently YDB-only. |
| **R-5** | Callout ABI drift (argc prefix, `ydb_string_t` in/out, `.var` byref). | Med | Follow the existing `crypto_*` signatures verbatim; verify-returns-int avoids the byref-output trap the header warns about. |
| **R-6** | Key-parsing code path is attacker-reachable (malformed SPKI). | Med | OpenSSL does the parse; fail closed to `U-STDCRYPTO-BADKEY`; fuzz a handful of malformed DER blobs in tests. |
| **R-7** | Scope creep into signing / JWKS / JWT. | Low | Hard scope line (§1): verify-only, key-agnostic, JWT-agnostic. STDJWT owns the rest. |

## 8. Open questions (resolve before/while building)

1. **IRIS asymmetric-verify surface.** Confirm on **foia-t12** (through the m-iris driver
   stack, read-only) exactly which `$SYSTEM.Encryption` verify methods exist and their
   signatures (RSASHAVerify arg order/key form; any ECDSA/EdDSA/PSS). Drives §4b.
2. **Key encoding contract.** SPKI-only, or also accept PKCS#1 RSAPublicKey and JWK? Lean
   SPKI DER/PEM only; JWK conversion upstream in STDJWT.
3. **P2 signing?** Decide whether asymmetric *sign* is ever in-scope (VistA-as-issuer) or
   permanently out (verify-only forever). Affects whether the C descriptor reserves a
   `crypto_sign`.

## 9. References

- **`../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`** — the consumer proposal that
  names this as the critical-path prerequisite (§2.2, build step 1).
- **Grounded in-repo (read for §2):** `src/STDCRYPTO.m` (`dispatch3`/`dispatch4`/
  `irisDigest`/`irisHmac`/`zeros`, header ABI notes), `tools/std_crypto.xc` (descriptor
  format), `src/callouts/std_crypto.c` (`crypto_*` EVP signatures),
  `tools/build-callouts.sh`, `scripts/seed-callouts.sh`.
- **Standards:** RFC 7515 (JWS) §3.3–3.5 + Appendix A.2/A.3; RFC 7518 (JWA) alg
  identifiers; RFC 8037 (EdDSA in JOSE) A.1; RFC 8017 (PKCS#1: PKCS1-v1_5 + PSS).
- **OpenSSL:** `EVP_DigestVerify`, `EVP_PKEY_CTX` PSS params, `ECDSA_SIG`
  i2d/d2i (the `R‖S`↔DER bridge).
- **Waterline:** `../../../docs/background/m-v-waterline-adr.md` — this stays m-layer;
  no VistA symbol, consumed upward by `VSLJWT`.
