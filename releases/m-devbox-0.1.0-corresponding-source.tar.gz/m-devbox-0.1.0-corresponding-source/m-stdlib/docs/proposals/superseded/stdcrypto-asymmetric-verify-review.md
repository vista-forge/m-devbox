---
title: "Adversarial review — STDCRYPTO asymmetric signature verify"
status: superseded
tracker: docs/module-tracker.md
created: 2026-07-09
last_modified: 2026-07-09
revisions: 1
doc_type: [REVIEW]
reviews: docs/proposals/superseded/stdcrypto-asymmetric-verify.md
---

# Adversarial review — STDCRYPTO asymmetric signature verify

> **Status: draft.** Peer adversarial technical review of
> [`stdcrypto-asymmetric-verify.md`](stdcrypto-asymmetric-verify.md). Every claim
> below was validated against the repo: `src/STDCRYPTO.m`,
> `src/callouts/std_crypto.c`, `tools/std_crypto.xc`, `src/STDJWT.m`,
> `docs/module-tracker.md`, and the `Makefile` / `scripts/seed-callouts.sh` /
> CI wiring. Findings are ranked; the proposal's own R-1…R-7 are folded into §5.

## Table of Contents

1. [Verdict at a glance](#1-verdict)
2. [Assumptions — validated against the repo](#2-assumptions-validated)
3. [Assumptions that are shaky or unstated](#3-assumptions-shaky)
4. [Proposed solutions — where they hold and where they don't](#4-solutions)
5. [Risks & mitigations (recomputed)](#5-risks)
6. [Recommendations & sequencing](#6-recommendations)

---

## 1. Verdict at a glance <a id="1-verdict"></a>

The proposal is **well-grounded and correctly scoped**. Its §2 architecture
description matches the code line-for-line, its layering (verify-only,
key-agnostic, JWT-agnostic) is consistent with the m/v waterline, and §5
correctly names the three real cryptographic traps (ES `R‖S`↔DER, PSS params,
EdDSA NULL-md). It is a genuine design, not a stub.

Four weaknesses undercut it, none fatal:

- **S1 (High) — the #1 JWS vulnerability class is absent from the risk table.**
  A doc that bills itself as "the foundation JWT security sits on" never mentions
  algorithm/key-type confusion or the untrusted-header `alg`.
- **S2 (High, mis-rated Med as R-4) — the IRIS non-RSA gap guts the
  "engine-neutral" claim** for the single most common federated algorithm (ES256).
- **S3 (Med) — the error-code channel is under-specified** and inherits a latent
  `rc=-1` ambiguity from the existing dispatch code.
- **S4 (Med) — "small and symmetric" (§2) and "no new .so" (§4c) understate real
  complexity and a CI-gating gap.**

## 2. Assumptions — validated against the repo <a id="2-assumptions-validated"></a>

Credit where due; these all check out:

| Claim | Status | Evidence |
|---|---|---|
| STDCRYPTO has HMAC but no asymmetric verify | ✅ True | `STDCRYPTO.m:79-85` lists Ed25519 sign/verify explicitly *out of scope at v1* |
| STDJWT shipped, HS256-only, **rejects non-HS256 loudly** | ✅ True | `STDJWT.m:56` — `if alg'="HS256" do setErr(...) quit 0` |
| Tracker #38: STDJWT v0.13.0, RS256/ES256 gated on STDCRYPTO public-key sigs, 28/28 dual-engine | ✅ True | `module-tracker.md:125` verbatim |
| argc-prefixed C ABI; `$&` not inline-parseable → XECUTE-wrap mandatory; IRIS branches on `$zversion["IRIS"` | ✅ True | `STDCRYPTO.m:324-354`, `std_crypto.c:94-97` |
| Verdict-as-int return (no output buffer) is the right ABI and dodges the byref-output trap | ✅ Correct | consistent with `.c` returning status via `int`, `dispatch3` reading `rc` |
| Verify holds no secret → smaller surface than signing | ✅ Correct | sound scoping; deferring signing to a possible P2 is right |
| JWK→key-material and claim validation belong upstream in STDJWT | ✅ Correct layering | keeps STDCRYPTO JWT-agnostic; waterline-clean |

**§5 "will bite" items are the right ones.** ES `R‖S`↔DER, explicit PSS
MGF1/saltlen, EdDSA one-shot NULL-md — these are exactly where naïve
implementations fail. The proposal identifies them unprompted.

## 3. Assumptions that are shaky or unstated <a id="3-assumptions-shaky"></a>

**A. The "engine-neutral foundation" assumption depends on an unresolved IRIS
question.** §1 motivates the work with "every real federated issuer signs with
RS256/**ES256**." But §4b admits ES*/EdDSA/PSS on IRIS is an *open question* with
heavyweight fallbacks (`%SYS.X509Credentials` or a bespoke ObjectScript helper
class shipped with MSL). `$SYSTEM.Encryption` exposes `RSASHAVerify` but has **no
documented generic ECDSA/EdDSA verify**. So the honest current state is: RS*
plausibly dual-engine; **ES256 — the most common federated alg (Login.gov, Apple,
modern OIDC) — is YDB-only until proven otherwise.** The headline promise and
§4b's uncertainty are in tension. This is the load-bearing assumption and it is
unvalidated (OQ-1).

**B. "Small and symmetric" (§2) assumes the delta equals the digest delta.** It
doesn't. `crypto_sha256` is ~4 lines; `crypto_verify` must carry the
alg→md/padding table, `R‖S`→`ECDSA_SIG` DER conversion (with per-curve
half-widths — **P-521 is 66-byte halves, not 64**), explicit PSS plumbing, the
EdDSA NULL-md path, SPKI-vs-PKCS#1 key policy, and a multi-valued error channel.
This is a substantially larger and more error-prone function.

**C. The error-model assumes a single `ydb_int_t` can carry four distinct failure
modes.** §3 promises `BADKEY` / `BADALG` / `CALLOUT-MISSING` / `VERIFY-FAIL` as
separate raises, but §4a collapses to "`rc<0` → error." One return channel cannot
distinguish them without a disjoint code convention — and there is a **latent
collision**: the existing `dispatch3/4` `$ETRAP` sets `rc=-1` for callout-missing
(`STDCRYPTO.m:331,335`), while the C layer *also* returns `-1..-5`
(`std_crypto.c:36-38`). Benign for digests (masked because libcrypto never fails
on valid input); **not benign for verify**, where you actually want to tell "no
.so" apart from "malformed key" apart from "internal EVP error."

**D. §4c assumes the `.so` change is free ("no new .so; same library").** It adds
a **new exported symbol** and lands the suite **outside the default CI gate** (see
§4-F). Both are real costs, not zero.

## 4. Proposed solutions — where they hold and where they don't <a id="4-solutions"></a>

**§3 API (`$$verifySig^STDCRYPTO(alg,pubKey,msg,sig)`) — sound, with one security
caveat.** The generic-verb shape is right and the `1/0` = valid/invalid vs
*raise-on-malformed-input* split is the correct contract (R-1). **But making
`alg` a caller-supplied parameter delegates 100% of algorithm policy to STDJWT and
says nothing about it.** The canonical JWT attacks are: (1) `alg:"none"`;
(2) **RS→HS confusion** (attacker sets `alg:HS256` and signs with the RSA *public*
key as the HMAC secret); (3) trusting an `alg`/`kid`/`jwk` from the *untrusted
header*. Within this module the asymmetric-vs-asymmetric case is self-defending
(an RSA key won't verify under ES256 — EVP returns 0), and the dangerous RS→HS
case lives in STDJWT's HMAC path, not here. **That's a defensible seam — but the
proposal must state the contract loudly**, because it is positioning itself as the
security foundation:

> `verifySig` trusts the caller to have **pinned the expected `alg` (family)
> against policy** and to supply a **trusted key** — never a key lifted from the
> token's own `jwk`/`x5c` header. STDCRYPTO cannot and does not defend against
> algorithm confusion; STDJWT must.

This belongs in §3 **and** as a High row in §7.

**§4a (YDB callout) — mostly right; specify the error channel and add the arity
guard.**

- The new `dispatchV` reading `rc` directly as verdict is the correct fix for the
  fact that existing `dispatch3/4` treat `rc=0` as *success* (`STDCRYPTO.m:336`).
  Reusing them would read an invalid signature (`rc=0`) as "ok" — catastrophic.
  ✅ The proposal caught this.
- **Under-specified:** define C negatives **disjoint from the existing `-1..-5`**
  (e.g. `-10 BADKEY`, `-11 BADALG`, `-12 VERIFYFAIL`) and detect true
  callout-missing via the `$ETRAP` path *only*, mapping each distinct negative to
  its `$ECODE`. Otherwise §6's "callout absent → `CALLOUT-MISSING`, garbage key →
  `BADKEY`" cannot both be delivered.
- The C sketch **omits `if (argc != 4) return -5;`** — every existing entry point
  carries it (`std_crypto.c:96,101,107,113,…`).

**§4b (IRIS) — honest but this is the crux, not a footnote.** "Land RS* both
engines, track ES*/EdDSA IRIS as an owed item" is a reasonable *fallback*, but it
must be a **staging decision made up front**, because if IRIS needs a bundled
ObjectScript helper class, that is a first-class MSL artifact — far more than "one
new IRIS arm," and it changes the §2 estimate.

**§5 (algorithm details) — the strongest section.** Correct on all three. One
precision nit: cite **RFC 7518 §3.4** for the ECDSA `R‖S` fixed-width formatting
(the alg definition), alongside RFC 7515 §A.3 (the KAT).

**§6 (test strategy) — correct KATs, but the negative corpus is too thin for an
auth primitive.** RFC 7515 A.2/A.3, RFC 8037 A.1, a bit-flipped sig, truncated
`R‖S` — necessary, not sufficient. **Missing the Wycheproof-class cases that are
the entire reason a verify primitive is hard:** ECDSA `s=0`/`r=0`, `s>n`
(malleability), non-canonical DER / extra leading-zero padding on the
`R‖S`→DER re-encode, wrong-curve points, all-zero signatures, and for RS*
PKCS1-v1_5 the Bleichenbacher-style padding-forgery vectors. **Recommend importing
Google Wycheproof's ECDSA/RSA/EdDSA vector sets** as the negative corpus.

**§6 gating gap (verified against the Makefile):** `STDCRYPTOTST` is an
**optional** suite — `Makefile:111-135`. It runs only under `make test-optional`
with a seeded callout lib; the default CI gate runs `make test`/`make coverage`,
and `OPTIONAL_SRC` is **excluded from the coverage-measured set**
(`Makefile:125`). So as written, the new verify code lands **outside the
drift-gated green path** unless `test-optional`/`coverage-optional` is explicitly
wired into CI against a seeded engine. The proposal's TDD "confirm GREEN" happens
only on a manually-seeded run.

**§4c deployment (verified):** `scripts/seed-callouts.sh` **recompiles the `.c`
inside the engine container** and appends the `ydb_xc_*` exports. A new
`crypto_verify` symbol therefore requires a **re-seed of every engine that runs
the suite** (or, if `m-test-engine` bakes the `.so`, a **pinned-image bump** —
CLAUDE.md pins `m-test-engine:0.2.0`). "No new .so; same library" is true of the
*filename* and false of the *deployment*.

## 5. Risks & mitigations (recomputed) <a id="5-risks"></a>

Re-rated, with the proposal's own R-1…R-7 folded in and the gaps added:

| # | Risk | Sev | Mitigation |
|---|---|---|---|
| **S1** | **Algorithm/key-type confusion** — caller passes untrusted-header `alg`; RS→HS forgery in the sibling HMAC path. Absent from proposal §7 entirely. | **High** | Add the §3 contract note (caller pins `alg` against policy, supplies trusted key, never a header-embedded key). State that this module is *not* the confusion defense; STDJWT is. Add a red test proving a mismatched alg/key returns 0, not a crash. |
| **S2** | **IRIS lacks native ES*/EdDSA verify** → the "engine-neutral asymmetric JWT" promise doesn't hold for **ES256**, the most common federated alg. (Proposal's R-4, Med.) | **High** | **Resolve OQ-1 (probe `$SYSTEM.Encryption` on foia-t12) BEFORE locking the design.** Stage: RS* both engines first; decide ES*/EdDSA-on-IRIS shape (bundled ObjectScript helper?) explicitly. Never silently YDB-only. |
| **S3** | **Single `ydb_int_t` can't encode 4 error modes**; latent `rc=-1` collision (etrap vs C `-1`). | **Med** | Disjoint C negatives (`-10/-11/-12`), etrap owns callout-missing only; map each in `dispatchV`. |
| **S4** | **Optional-suite CI gap + `.so` symbol rollout** — verify code lands outside the drift-gated path; new symbol needs re-seed / image bump. | **Med** | Wire `test-optional`+`coverage-optional` into CI against a seeded engine; treat the `.so`/image bump as a tracked deployment step. |
| R-2 | ES* `R‖S`↔DER wrong → all ECDSA fail or malleable-accept. | **High** | (Proposal's, kept.) **+ P-521 half-width = 66 bytes**; split `sig` in half by length, reject odd/misized length as invalid(0). Add Wycheproof ECDSA vectors. |
| R-3 | PSS params defaulted → cross-OpenSSL divergence. | Med | (Kept.) Set md/MGF1/saltlen explicitly; pin vector. |
| R-6 | Malformed SPKI is attacker-reachable. | Med | (Kept.) OpenSSL parses; fail closed to `BADKEY`; **fuzz with Wycheproof malformed-DER + zero/one RSA sigs**. |
| S5 | **Stale `.so` (present but pre-`verify`)** reports "available" yet every verify raises CALLOUT-MISSING. | Low | Extend `available()` (or add `verifyAvailable()`) to probe that the `crypto_verify` **symbol** resolves, not just sha256. |
| S6 | **No key-strength floor** — accepts 512-bit RSA / non-approved curves. | Low | Decide owner (likely STDJWT/VSLJWT), state it; don't leave silently absent. |
| S7 | **IRIS byte-transport fidelity** for binary DER keys/sigs through the m-iris driver (known >255→`?`, request-size ceilings per the stack review). | Low | §6's "same vectors on IRIS through the driver stack" must assert byte-exact round-trip; likely fine (vectors are in-engine `$CHAR` literals) but verify. |
| R-7 | Scope creep into signing/JWKS. | Low | (Kept.) Hard scope line is good. |

*Dropped R-5 as a standalone: the argc/byref concern is real but reduces to "add
the `argc!=4` guard + use disjoint error codes" — folded into S3.*

## 6. Recommendations & sequencing <a id="6-recommendations"></a>

1. **Resolve OQ-1 (IRIS surface) before accepting the design.** It's the
   difference between "one new IRIS arm" and "ship a bundled ObjectScript crypto
   helper as an MSL artifact." This gates the whole shape and the §2 estimate.
2. **Stage explicitly:** *Phase 1* — RS256/384/512 on **both** engines (highest
   confidence, `RSASHAVerify` exists on IRIS). *Phase 2* — ES*/EdDSA/PSS, engine
   coverage per OQ-1 outcome. Land Phase 1 fully gated before Phase 2.
3. **Add the algorithm-confusion contract** to §3 and a High row to §7.
   Non-negotiable for a doc framed as the JWT security foundation.
4. **Specify the error channel** (disjoint C negatives; etrap owns
   callout-missing) and add the `argc!=4` guard to the C sketch.
5. **Import Wycheproof vectors** as the negative corpus; add P-521 half-width
   handling.
6. **State the CI wiring**: how `STDCRYPTOTST` (optional) enters the gated path,
   and the `.so`/engine-image rollout step. Reclassify §4c from "trivial" to
   "tracked deployment."
7. **Re-title the estimate** in §2 from "small and symmetric" to an honest scope;
   retag as the STDCRYPTO in-module ticket in `module-tracker.md` as the proposal
   itself requests (§0).

**Bottom line:** accept the *direction* (verify-only, key-agnostic,
waterline-clean is right), but **do not accept "small/symmetric/no-new-.so" or the
Med rating on the IRIS gap.** Gate on the IRIS probe, stage RS*-first, and close
the algorithm-confusion and error-channel gaps before writing the C.

## References

- Reviewed: [`stdcrypto-asymmetric-verify.md`](stdcrypto-asymmetric-verify.md)
- Grounded in-repo: `src/STDCRYPTO.m`, `src/callouts/std_crypto.c`,
  `tools/std_crypto.xc`, `src/STDJWT.m`, `docs/module-tracker.md` (#38),
  `Makefile` (optional-suite + coverage split), `scripts/seed-callouts.sh`.
- Standards: RFC 7515 (JWS) §A.2/A.3, RFC 7518 (JWA) §3.4 ECDSA `R‖S`,
  RFC 8037 (EdDSA in JOSE) §A.1, RFC 8017 (PKCS#1 v1_5 + PSS).
- External test corpus (recommended): Google Wycheproof ECDSA/RSA/EdDSA vectors.
