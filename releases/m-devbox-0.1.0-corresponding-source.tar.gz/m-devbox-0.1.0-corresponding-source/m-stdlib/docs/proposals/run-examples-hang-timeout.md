---
title: "run-examples.py — per-batch subprocess timeout (turn a hung example suite into a fast, attributed failure)"
status: accepted
tracker: docs/module-tracker.md
created: 2026-07-12
last_modified: 2026-07-12
revisions: 2
doc_type: [PROPOSAL]
---

# run-examples.py — per-batch subprocess timeout

**One-line:** give `tools/run-examples.py`'s `m test` subprocess a bounded
timeout so a hung example suite fails **fast, loud, and attributed** instead of
consuming the whole CI engine-step budget (and hanging forever locally).

## 1. Problem

`run-examples.py` runs every example program for an arm through **one**
`m test … <all programs>` invocation:

```python
proc = subprocess.run(cmd, capture_output=True, text=True)   # no timeout
```

There is **no timeout**. If any single example suite blocks, the whole batch
hangs indefinitely. The only backstops are coarse and asymmetric:

- **CI:** the reusable `m-ci.yml` `engine-step-timeout-minutes` (default 25) —
  it kills the *whole* Engine-bound step, names only the `::group::make <target>`
  (`examples-run-ydb`), and burns the entire 25-minute budget first.
- **Locally:** **nothing.** A developer running `make examples-run-ydb` on a
  broken engine hangs with no bound at all.

Neither tells you *which suite* hung, and both are slow.

## 2. Evidence (EIP-1f, 2026-07-12)

`examples-run-ydb` ran `STDCRYPTOEX` against the stock `m-test-engine:0.2.0`
image before the crypto callout was seeded. An **unseeded `$&stdcrypto` external
call blocks the YDB process** (the block is inside the `$&` resolution — no M
`$ETRAP` can catch it; `dispatch3^STDCRYPTO`'s guards only handle a *raising* or
*silently-no-op* callout). Result: `make examples-run-ydb` hung the CI runner
for the full ~25 minutes before the step timeout fired. The root cause was fixed
by re-ordering `seed-engine-callouts` ahead of `examples-run-ydb`
(`ci.yml`, commit `1af52b0`), and the durable fix is a baked engine image
(m-cli/m-engine proposal). **But the *hang itself* — any future unseeded or
broken callout, or a genuinely wedged suite — will recur**, and the tool has no
defense of its own. A net that hangs is not a truthful alarm.

## 3. Proposal

Add a **bounded, configurable timeout** to the `m test` subprocess in
`run_m_test()`, and turn `subprocess.TimeoutExpired` into a hard, attributed
arm failure:

```python
try:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
except subprocess.TimeoutExpired:
    print(f"  ! {arm.name}: TIMED OUT after {timeout_s}s "
          f"(a suite is hung — likely a blocking callout on an unseeded engine)",
          file=sys.stderr)
    return []   # empty results → the arm gate reds (0/0 is already "not green")
```

- **Budget.** Configurable via `--timeout` (and/or an env knob), default generous
  relative to observed wall-clock: the bare-tier batch is ~30 s, so a default of
  **300 s** catches true hangs without flaking on a slow-but-valid run. The live
  tier (three invocations, network) may warrant a larger default or a per-tier
  value.
- **Attribution.** At minimum name the *arm*. Better: since suites run in one
  invocation, a hung batch can't self-report which suite — so pair this with an
  optional **`--isolate-on-timeout`** retry that re-runs the arm one program at a
  time (bounded, only after a timeout) to name the culprit. (Optional; the
  arm-level fast-fail is the MVP.)
- **`.green` already handles it.** An empty `results` list makes the arm red via
  the existing `SuiteResult`/`gate_summary` path (`0/0` is already "not green"),
  so no verdict-logic change is needed.

## 4. Design wrinkles (call out, don't hand-wave)

1. **Child-process cleanup.** `subprocess.run(timeout=…)` kills the *Python*
   child (`m`), but `m test --docker` has already `docker exec`'d into the engine;
   the exec'd process may outlive the killed parent. Options: launch with
   `start_new_session=True` and kill the process group; or rely on `--ephemeral`
   staging teardown; or document that a timeout may leave one orphaned
   `docker exec` (the engine container itself is unaffected and reused). **Pick
   one and verify** — a timeout that leaks a wedged exec into the next arm is
   worse than the hang.
2. **Byte-identical sibling.** `run-examples.py` is a byte-identical sibling with
   `v-stdlib` (auto-discovers `stdlib`/`vsl`-manifest via `manifest_path()`). The
   change ports verbatim; land in m-stdlib (priority), then `cp` to v-stdlib.
3. **Interaction with the CI step timeout.** This is defense-in-depth *below* the
   m-ci 25-min step timeout, not a replacement — the step timeout stays as the
   coarse backstop for hangs outside `run-examples` (driver build, engine boot).

## 5. Alternatives considered

- **Status quo (rely on the m-ci step timeout).** Rejected: coarse (whole 25-min
  budget), no per-suite attribution, and **zero local backstop**.
- **Fix only the specific callout-ordering trigger.** Already done (`1af52b0`);
  this proposal is the *general* defense so the next hang trigger fails fast too.

## 6. Acceptance

- A deliberately-hung example suite (e.g. an unseeded-callout arm) makes
  `run-examples.py` fail within the configured budget with a message naming the
  arm — verified locally by pointing an arm at an unseeded engine.
- The bare-tier happy path (`examples-run-ydb`, ~30 s) is unaffected — no false
  timeouts.
- Child-process cleanup wrinkle (§4.1) resolved and verified (no orphaned
  `docker exec` bleeding into the next arm).
- Ports byte-identically to v-stdlib's `run-examples.py`.

## 7. Relationship to the engine-image proposal

This is the **tool-side** half of the EIP-1f hardening. The **engine-side** half
— baking `std_crypto` into the pinned `m-test-engine` image (or a
`m callouts install` verb) so the callout is never absent in the first place — is
filed separately against **m-cli/m-engine** (`m-cli/docs/proposals/`, graduating
`stdcrypto-asymmetric-verify-v2.md` §15.6). Both are wanted: remove the trigger
*and* make the tool fail fast if any future trigger appears.
