# STDCRYPTO asymmetric-verify kickoff — Phase 2 (ES\* / EdDSA / PS\*, both engines)

> Paste the block below into a fresh **`m-stdlib`-cwd** session. It continues the
> v2 proposal
> [`../stdcrypto-asymmetric-verify-v2.md`](../stdcrypto-asymmetric-verify-v2.md)
> where the Phase-0+1 session left off.
>
> **Prerequisite (DONE, committed `418149a` on `main`):** Phase 0 blockers cleared
> and **RS256/384/512 verify is dual-engine GREEN 37/37** — `$$verifySig^STDCRYPTO`
> works on YDB (`crypto_verify` libcrypto callout) and IRIS (native
> `RSASHAVerify`), CI-wired via `test-optional` + `coverage-optional` +
> `seed-engine-callouts`.
>
> **This session's target = the Phase-2 exit gate:** `$$verifySig` also verifying
> **ES256/384/521 + EdDSA (Ed25519) + PS256/384/512**, dual-engine, drift-gated,
> CI-green. **D1 (STDJWT asymmetric leg) is the NEXT session, not this one** — stop
> when Phase 2 is GREEN and hand off. One session ↔ one repo (m-stdlib).

---

## The prompt

```
You are implementing PHASE 2 of the STDCRYPTO asymmetric-signature-verify extension
in m-stdlib (cwd ~/vista-forge/m-stdlib). Phase 0 (de-risk) and Phase 1 (RS*) are
DONE and on main (commit 418149a): $$verifySig^STDCRYPTO verifies RS256/384/512
dual-engine GREEN 37/37, CI-wired. Layer = m (engine-neutral; NO VistA symbol,
consumed upward). Trunk-based: commit each verified increment straight to main per
the org Increment Protocol; gates run BEFORE commit. TDD is a HARD RULE.

SCOPE OF THIS SESSION — Phase 2 only: add ES256/384/521 (ECDSA), EdDSA (Ed25519),
and PS256/384/512 (RSASSA-PSS) to the SAME $$verifySig verb, landing at the Phase-2
exit gate. Do NOT build D1 (STDJWT's asymmetric leg) here — stop when ES*/EdDSA/PS*
are GREEN (YDB all; IRIS ES*/PS* green + EdDSA an explicit tracked skip) and CI
stays green, then hand off D1.

READ FIRST (in this order):
- docs/proposals/stdcrypto-asymmetric-verify-v2.md — especially §6 (sequencing:
  Phase 2 gated on Phase 1, now met), §10 (algorithm details that bite — the
  R‖S↔DER converter, PSS params, EdDSA NULL-md), §12 (test strategy incl.
  Wycheproof), §13 (R-DER/R-PSS/R-BYTE), §14 (rows T-C-ES, T-IRIS-ES).
- docs/design/stdcrypto-asymmetric-verify-design.md — the G-IRIS measured findings
  you build the IRIS arm on (see "ALREADY ESTABLISHED" below — do NOT re-probe what
  is already recorded there).
- docs/discoveries.md (2026-07-09 rows) — the IRIS PEM-only/DER→0 gotcha, the
  $ETRAP-swallow gotcha, the re-seed requirement.
- src/callouts/std_crypto.c — the RS* crypto_verify you EXTEND: md_for_alg() is the
  single alg→md switch; add the ES*/PS*/EdDSA branches there. parse_pubkey() already
  handles PEM+DER SPKI.
- src/STDCRYPTO.m — dispatchV (disjoint codes, -99 etrap sentinel, the
  set $etrap="" disarm), irisVerify + toPem/rsaBits/rsaErr/isKeyErr (extend for the
  ES*/PS* IRIS arms), verifyRs* wrappers (add verifyEs256/384/512, verifyPs*,
  verifyEdDSA sugar), verifyAvailable (still an RS256 KAT — fine).
- tests/STDCRYPTOTST.m — the RS* test pattern + hex-vector helpers to mirror.
- The m-stdlib skills: m-unit-testing + mumps-modern-style.

ALREADY ESTABLISHED (measured last session — do NOT re-derive):
- IRIS (foia-t12, IRIS 2026.1) exposes NATIVE, dual-engine-capable verify methods:
  * ECSHAVerify(shaBits, data, DERsig, pemKey)  → ES*  (sig is DER SEQUENCE{r,s},
    NOT the JWT R‖S — same R‖S→DER conversion the C path needs, then pass DER).
  * RSASSAPSSVerify(...)                          → PS*  (confirm its exact arg
    shape on foia the same read-only way — m vista exec --engine iris
    --transport docker — before wiring; arg order likely mirrors RSASHAVerify).
  * NO Ed25519/CFRG method → EdDSA is YDB-ONLY on IRIS: ship it on YDB, add an
    explicit tracked skip on the IRIS arm (never a silent dual-engine gap; §9b(d)).
- IRIS keys are PEM-only; the DER→PEM shim ($$toPem) already exists — reuse it for
  ES*/PS* keys too.
- The dispatchV disjoint-code channel (-10 BADKEY / -11 BADALG / -12 VERIFY-FAIL,
  -99 callout-missing) and the "set $etrap="" after xecute" disarm are in place —
  extend, don't reinvent. Adding algs only touches md_for_alg (C) + rsaBits/alg
  branches (M) + new C crypto for R‖S↔DER / PSS / EdDSA.

ALGORITHM DETAILS THAT BITE (proposal §10 — get these exactly right):
- ES* R‖S↔DER: JWT carries the sig as fixed-width R‖S concatenation; OpenSSL
  EVP_DigestVerify (and IRIS ECSHAVerify) want DER SEQUENCE{r,s}. DERIVE the
  component width from siglen/2, NOT a constant — P-256=32B halves (64 total),
  P-384=48 (96), P-521=66 (132, NOT 64). Odd/misized siglen → return 0 (invalid,
  not an error). Build ECDSA_SIG via BN_bin2bn + i2d_ECDSA_SIG. Test against RFC
  7515 §A.3 AND Wycheproof ECDSA (s=0/r=0, s>n malleability, non-canonical DER,
  wrong-curve, all-zero) — a width bug is a silent malleable-accept, the worst case.
- PS*: set params EXPLICITLY on the EVP_PKEY_CTX — EVP_PKEY_CTX_set_rsa_padding
  (RSA_PKCS1_PSS_PADDING) + _set_rsa_pss_saltlen(RSA_PSS_SALTLEN_DIGEST) +
  _set_rsa_mgf1_md(md). Defaults differ across OpenSSL versions. Pin a PS256 vector.
- EdDSA: EVP_DigestVerify with a NULL md (Ed25519 is one-shot over the message, no
  pre-hash — RFC 8037 §3.1); different code path from RS/ES. OpenSSL ≥1.1.1.

PHASE 2 STEPS (TDD throughout; hex vectors decoded in-suite via $$decode^STDHEX for
byte-fidelity, per R-BYTE):
1. tests/STDCRYPTOTST.m: write ES*/EdDSA/PS* cases FIRST (RED). Positive KATs: RFC
   7515 §A.3 (ES256), RFC 8037 §A.1 (Ed25519), a scripted PS256 vector (OpenSSL
   into tests, checked as hex). Negatives: Wycheproof ECDSA + EdDSA + RSA-PSS
   subsets (import the relevant vectors as hex helpers; log any curation/cap). Error
   paths reuse the RS* BADKEY/BADALG asserts. Confirm RED.
2. src/callouts/std_crypto.c: extend md_for_alg for ES256/384/512, PS256/384/512;
   add the R‖S→DER converter (width=siglen/2) for ES*, the PSS param block for PS*,
   and the EdDSA NULL-md branch. Rebuild via tools/build-callouts.sh (host build)
   AND re-seed the engine (make seed-engine-callouts) so the container gets the new
   crypto — the symbol name is unchanged (still crypto_verify) but the code is new,
   so a re-seed is still required.
3. src/STDCRYPTO.m: extend rsaBits→(a generic alg→shaBits/family map), add the
   ES*/PS* IRIS arms in irisVerify (ECSHAVerify / RSASSAPSSVerify, R‖S→DER on M
   side or reuse the C path — decide and document), add the EdDSA YDB-only guard
   (IRIS → tracked skip, not a crash), add verifyEs*/verifyPs*/verifyEdDSA wrappers.
4. Run the suite on YDB (m-test-engine) AND IRIS (foia-t12 + m-test-iris) through
   the driver stack. EdDSA: green on YDB, explicit skip on IRIS (assert the skip is
   visible, not a silent pass).
5. Regenerate dist/ (make manifest skill examples frontmatter docs-bodies), run the
   full gate (make check + test-optional + coverage-optional), confirm drift-gated
   GREEN. coverage-optional's 60% floor may rise — bump it if the measured set climbs.

INCREMENT PROTOCOL (per verified increment, in order, unprompted):
- Persist the durable lesson to docs/memory/ (update iris-native-backends.md's
  asymmetric-verify section + durable-gotchas — the R‖S↔DER width rule, the PSS
  param requirement, the EdDSA-YDB-only decision). Keep-test; update, don't dupe.
- Update docs/module-tracker.md T32 §14 rows (T-C-ES, T-IRIS-ES) in the SAME commit
  as the code; changelog.md only if a release is tagged.
- Run gates BEFORE committing; commit each gate-green increment straight to main.

HARD RULES (org): STOP-THE-LINE on any MSL/toolchain/driver defect (fix the root
cause in the owning repo, no hacks); engine access ONLY through the driver stack
(m test --docker / m vista exec — never raw docker exec/iris session); do NOT
hand-edit generated dist/; the .so is a YDB engine-runtime dependency, not a
v-pkg/KIDS artifact.

SESSION EXIT (done-condition): $$verifySig verifies ES256/384/521 + PS256/384/512
on YDB AND IRIS, and EdDSA on YDB (IRIS = tracked skip); STDCRYPTOTST GREEN and
drift-gated; CI stays green. Then STOP and report the D1 handoff (STDJWT asymmetric
leg — wire $$verifySig, lift the non-HS256 reject, enforce the alg allowlist +
alg-family↔key-type pin; still m-stdlib, engine-neutral).

If anything proves wrong against the live repo/engine (an OpenSSL API shape, an IRIS
arg order, a §10 assumption), treat the discrepancy as the finding: fix the root
cause or update the proposal, and say so — do not paper over it.
```

---

## Notes for the operator

- **Same repo as Phase 0/1 — m-stdlib.** Phase 2 is STDCRYPTO in-module; D1 (next
  session) is STDJWT, also engine-neutral m-stdlib. The `v`-layer consumers
  (D2 VSLJWT / D3 `XUS JWT LOGON` / D4 VWEB) are separate v-stdlib / v-\* sessions.
- **Model tier — consider Fable 5.** The `R‖S`↔DER converter (P-521 width, malleable-
  accept failure mode) and the PSS param block are reasoning-bound and security-
  critical; this is the "ES\*→DER work" the P0 prompt flagged for Fable 5. RS\* was
  mechanical; Phase 2 is not.
- **Biggest de-risk already banked:** last session's G-IRIS probe proved IRIS has
  native `ECSHAVerify` + `RSASSAPSSVerify`, so ES\*/PS\* are dual-engine on proven
  rails — Phase 2 adds crypto complexity, not new plumbing/CI/packaging risk. Only
  EdDSA is YDB-only (no IRIS CFRG method).
- **After Phase 2:** D1 STDJWT asymmetric leg → then D2/D3/D4 in v-stdlib / v-\*
  (`../../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`).
