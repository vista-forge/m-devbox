# STDJWT asymmetric-leg kickoff — D1 (wire `$$verifySig`, own the alg-confusion defense)

> Paste the block below into a fresh **`m-stdlib`-cwd** session. It continues the
> v2 proposal
> [`../stdcrypto-asymmetric-verify-v2.md`](../stdcrypto-asymmetric-verify-v2.md)
> at its **D1** dependent step, now that the STDCRYPTO leaf (Phases 0–2) is GREEN.
>
> **Prerequisite (DONE, committed `9e56190` on `main`):** `$$verifySig^STDCRYPTO`
> verifies **RS/PS/ES256/384/512 + EdDSA**, dual-engine GREEN 53/53 (m-test-engine
> YDB, m-test-iris, foia-t12), drift-gated + CI-wired. EdDSA is YDB-only (IRIS
> raises `U-STDCRYPTO-BADALG` — a tracked skip). The m-layer critical-path leaf is
> complete; D1 is the first consumer.
>
> **This session's target = the D1 exit gate:** `$$verify^STDJWT` verifies **RS256
> and ES256** (min) tokens against RFC 7515 App A, with the algorithm-confusion
> defense (N-1) STDCRYPTO deliberately does NOT own — reject `none`, enforce a
> caller-supplied alg allowlist, pin alg-family↔key-type. **D2 (VSLJWT, v-stdlib)
> is the NEXT session, not this one** — stop when the STDJWT asymmetric leg is GREEN
> dual-engine and hand off. One session ↔ one repo (m-stdlib).

---

## The prompt

```
You are implementing D1 of the STDCRYPTO/STDJWT asymmetric-JWT auth stack in
m-stdlib (cwd ~/vista-forge/m-stdlib): the STDJWT ASYMMETRIC LEG. The m-layer leaf
$$verifySig^STDCRYPTO (RS/PS/ES256/384/512 + EdDSA) is DONE and on main (commit
9e56190), dual-engine GREEN 53/53. STDJWT today (v0.13.0) does HS256 only and
REJECTS every non-HS256 alg loudly (src/STDJWT.m:55-56). Your job: lift that
rejection for the vetted asymmetric algs by wiring $$verifySig, and — the whole
point of D1 — OWN the algorithm-confusion defense that STDCRYPTO is alg-agnostic-
by-design and therefore cannot provide. Layer = m (engine-neutral; NO VistA symbol;
consumed upward by VSLJWT). Trunk-based: commit each verified increment straight to
main per the org Increment Protocol; gates run BEFORE commit. TDD is a HARD RULE.

SCOPE OF THIS SESSION — D1 only: STDJWT's asymmetric verify leg. Do NOT build D2
(VSLJWT's claim→#200/DUZ binding — that's v-stdlib, a separate session), and do NOT
build JWKS fetching / `kid` selection / JWK→SPKI conversion unless a step below is
blocked without it (see DELIBERATELY DEFERRED). Stop when RS256/ES256 (min) verify
GREEN vs RFC 7515 App A, the alg-confusion red tests pass, and STDJWTTST is
dual-engine GREEN + drift-gated, then hand off D2.

READ FIRST (in this order):
- docs/proposals/stdcrypto-asymmetric-verify-v2.md — §7 (the security CONTRACT +
  the caller's duties), §11 (the algorithm-confusion boundary — THIS is D1's core),
  §4 (scope: JWK conversion is a STDJWT concern), §14 row D1 (exit gate: "STDJWT
  RS256/ES256 verify GREEN vs RFC 7515 App A").
- src/STDJWT.m — the verb you extend: $$verify(token,key,.claims,.opts) at :39;
  the non-HS256 reject at :55-56; si=header.payload signing input; the signature is
  the base64url 3rd segment; HS256 recomputes+cteq; opts already carries
  `alg`=expected alg (the seed of the allowlist). $$decode/$$claim/$$sign/$$lastError.
- src/STDCRYPTO.m — the leaf you call: $$verifySig^STDCRYPTO(alg,pubKey,msg,sig) →
  1|0; msg = the exact signing-input bytes (header.payload); sig = the RAW signature
  bytes (base64url-decode the 3rd segment — for ES* that IS the JWT R‖S the leaf
  expects, RFC 7518 §3.4; STDCRYPTO does R‖S→DER internally, so STDJWT passes it
  straight through). pubKey = SPKI DER or PEM. EdDSA raises BADALG on IRIS.
- tests/STDJWTTST.m + tests/STDCRYPTOTST.m — the HS256 test pattern to mirror; the
  RS256/ES256 App-A SPKI keys + vectors already live in STDCRYPTOTST (vRs256PubDer/
  vRs256Msg/vRs256Sig, vEs256PubDer/vEs256Msg/vEs256Sig) — reuse the same hex,
  decoded in-suite via $$decode^STDHEX, for byte fidelity.
- docs/memory/durable-gotchas.md "Auth architecture (STDJWT)" — the alg-confusion
  facts (RS→HS key confusion is the dangerous one), the injected clock, the STDJSON
  typed-node convention. And iris-native-backends (EdDSA YDB-only inheritance).
- The m-stdlib skills: m-unit-testing + mumps-modern-style.

THE SECURITY MODEL — D1's REASON TO EXIST (proposal §11, finding N-1). STDCRYPTO
answers one question over bytes and delegates 100% of alg policy upward. STDJWT MUST,
before/while verifying, enforce all of:
  1. Reject alg:"none" (and empty/absent alg) UNCONDITIONALLY — never a code path
     that skips signature verification.
  2. Enforce a CALLER-SUPPLIED alg allowlist — the verification alg comes from the
     caller's expectation, NOT solely from the token's header. The token can never
     WIDEN the allowlist. (Design the opts shape: a strict single expected `alg`, or
     an `algs` list; decide + document. `opts("alg")` already exists as the seed.)
  3. Pin alg-FAMILY to key-TYPE. The dangerous confusion is RS→HS: an RSA PUBLIC key
     used as an HMAC secret lets an attacker forge (they know the public key). So an
     HS* token MUST NOT be verifiable when the caller expects/passes an asymmetric
     key, and vice-versa. Because STDJWT selects the verify PATH from the vetted alg
     (allowlist), not from the attacker-controlled header alone, this is structurally
     closed — build it that way and RED-TEST it (an RS-key + HS256-token forgery
     attempt returns 0, never 1).
  4. Never trust a key embedded in the token's own jwk/x5c/kid header — STDJWT takes
     the trusted key from the CALLER (the `key` param), never from the token.
  5. (Stated, enforced upstream) key-strength floor (RSA≥2048) lives in VSLJWT; note
     it so it isn't silently assumed here.

D1 STEPS (TDD throughout; App-A vectors decoded in-suite via $$decode^STDHEX):
1. tests/STDJWTTST.m: write the asymmetric cases FIRST (RED). Positive: an RS256
   token (RFC 7515 App A.2 header.payload.sig, SPKI key) and an ES256 token (App A.3)
   verify=1 with a matching alg allowlist. Confusion RED tests: alg:"none"→0;
   RS-public-key + HS256-token forgery→0; header alg NOT in the caller allowlist→0;
   tampered payload→0; wrong key→0. Inherit the HS256 tests (must stay green — the
   HS path is unchanged). Confirm RED.
2. src/STDJWT.m: extend $$verify — after $$decode, read header alg; reject none;
   check alg against the caller allowlist; for an asymmetric alg, base64url-decode
   the 3rd segment to raw sig bytes and call $$verifySig^STDCRYPTO(alg,key,si,sig)
   (key = the caller's SPKI public key); keep HS256 on the existing recompute+cteq
   path (do NOT route HS through verifySig). Map a STDCRYPTO BADKEY/BADALG raise to a
   clean verify=0 + $$lastError (wrap with $ETRAP — never let a forged/oddball token
   raise out of $$verify). Update the module header + verb doc-comment + opts doc.
3. Dual-engine: run STDJWTTST on YDB (m-test-engine) AND IRIS (m-test-iris + foia).
   EdDSA in STDJWT inherits STDCRYPTO's YDB-only: an EdDSA token verifies on YDB and,
   on IRIS, STDCRYPTO raises BADALG → $$verify returns 0 with a clear lastError — assert
   that visibly (a tracked skip, not a silent pass), same discipline as STDCRYPTOTST's
   edDsaSkip. (Scope RS256+ES256 as the required gate; PS*/EdDSA are welcome if cheap.)
4. Regenerate dist/ (make manifest skill examples frontmatter docs-bodies) + run the
   full gate (make check + test-optional + coverage-optional; STDJWT is already in
   OPTIONAL_SUITES). Confirm drift-gated GREEN. Bump coverage-optional's floor only if
   the measured aggregate climbs past it.

DELIBERATELY DEFERRED (out of D1 — do NOT build unless a step is blocked): JWKS
fetching over HTTP, `kid`→key selection, and JWK(n/e, crv/x/y)→SPKI conversion. D1
takes a CALLER-SUPPLIED SPKI public key (STDCRYPTO's native contract). The App-A gate
is met with App A's key in SPKI form (already in STDCRYPTOTST). If verifying App A
truly requires JWK→SPKI, add the MINIMAL converter and log it as a discovery; else
leave it for a later step. This keeps D1 on the security-critical alg-confusion work,
not plumbing.

INCREMENT PROTOCOL (per verified increment, in order, unprompted):
- Persist the durable lesson to docs/memory/ (update durable-gotchas' "Auth
  architecture (STDJWT)" section — the alg-confusion enforcement shape, the opts
  allowlist decision, the HS-stays-off-verifySig split, the EdDSA-YDB-only inheritance).
  Keep-test; update, don't dupe.
- Update docs/module-tracker.md — the STDJWT row (#38) + the T32 §14 D1 row — in the
  SAME commit as the code; changelog.md only if a release is tagged.
- Run gates BEFORE committing; commit each gate-green increment straight to main.

HARD RULES (org): STOP-THE-LINE on any MSL/toolchain/driver defect (fix the root
cause in the owning repo, no hacks); engine access ONLY through the driver stack
(m test --docker / m vista exec — never raw docker exec/iris session); do NOT
hand-edit generated dist/; STDCRYPTO has architectural priority (STDJWT consumes it,
never duplicates crypto up); a forged/malformed token is a NORMAL 0, never a raise.

SESSION EXIT (done-condition): $$verify^STDJWT verifies RS256 + ES256 (min) tokens
vs RFC 7515 App A; alg:"none", RS→HS confusion, and out-of-allowlist algs all return
0; HS256 unchanged/green; STDJWTTST dual-engine GREEN + drift-gated; CI stays green.
Then STOP and report the D2 handoff (VSLJWT in v-stdlib — claim→NEW PERSON #200/DUZ
trust binding, SecID→UPN precedence; ABOVE the waterline, a separate v-stdlib session;
see ../../../../v-stdlib/docs/proposals/vsl-jwt-auth.md).

If anything proves wrong against the live repo/engine (an STDJWT shape, a STDCRYPTO
contract detail, an App-A assumption), treat the discrepancy as the finding: fix the
root cause or update the proposal, and say so — do not paper over it.
```

---

## Notes for the operator

- **Same repo — m-stdlib.** D1 is the STDJWT (m-layer) asymmetric leg; it consumes
  the now-GREEN `$$verifySig^STDCRYPTO`. D2 (VSLJWT), D3 (`XUS JWT LOGON` RPC), and
  D4 (VWEB) are separate **v-stdlib / v-\*** sessions above the waterline.
- **Model tier — worth Fable 5.** D1's core is the algorithm-confusion defense
  (RS→HS key confusion, `alg:none`, header-chosen alg) — a security boundary where a
  subtle gap is a full auth bypass. It's a well-understood checklist, but it is
  reasoning-bound and adversarial; consider `/model` to Fable 5 for the design of the
  allowlist/family-pin, as the P0/P2 prompts flagged for the crypto itself.
- **The clean seam already banked:** an ES\* JWS signature IS the JWT `R‖S` that
  `$$verifySig` expects (RFC 7518 §3.4), and STDCRYPTO does the `R‖S`→DER conversion
  internally — so STDJWT just base64url-decodes the 3rd segment and passes bytes. No
  crypto in STDJWT; it owns POLICY (which alg, which key, reject none), STDCRYPTO owns
  the MATH. That split is the whole architecture.
- **After D1:** D2 VSLJWT → D3 `XUS JWT LOGON` + KIDS (`v pkg install`) → D4 VWEB
  local-JWT provider — all in v-stdlib / v-\* (`../../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`).
