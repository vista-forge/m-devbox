# STDCRYPTO asymmetric-verify kickoff — Phase 0 (de-risk) → Phase 1 (RS\* both engines)

> Paste the block below into a fresh **`m-stdlib`-cwd** session. It starts
> implementation of the v2 proposal
> [`../stdcrypto-asymmetric-verify-v2.md`](../stdcrypto-asymmetric-verify-v2.md)
> (from this folder: `docs/proposals/stdcrypto-asymmetric-verify-v2.md`).
>
> **This session's target = the Phase 1 exit gate:** `$$verifySig^STDCRYPTO` verifying
> **RS256/384/512 on BOTH engines**, drift-gated and wired into CI. It first clears the
> three Phase-0 blockers (which *gate* everything), then builds RS\*. **ES\*/EdDSA/PS\*
> (Phase 2) and STDJWT's asymmetric leg (D1) are explicitly OUT of this session** — they
> are the next milestone once RS\* is GREEN. One session ↔ one repo.

---

## The prompt

```
You are implementing the STDCRYPTO asymmetric-signature-verify extension in m-stdlib
(cwd ~/vista-forge/m-stdlib). This is the engine-neutral CRITICAL-PATH LEAF the whole
asymmetric-JWT auth stack (STDJWT asym leg → VSLJWT → XUS JWT LOGON → VWEB) sits on.
Layer = m (engine-neutral; NO VistA symbol, consumed upward). Trunk-based: commit each
verified increment straight to main per the org Increment Protocol; gates run BEFORE
commit. TDD is a HARD RULE.

SCOPE OF THIS SESSION — Phase 0 then Phase 1 (RS* only), landing at the Phase-1 exit
gate. Do NOT build ES*/EdDSA/PS* (Phase 2) or STDJWT's asym leg (D1) here — stop when
RS* is dual-engine GREEN and CI-wired, then hand off.

READ FIRST (in this order):
- docs/proposals/stdcrypto-asymmetric-verify-v2.md — the whole proposal, but especially
  §6 (sequencing/phases), §7 (API + the security contract), §8 (grounded architecture
  with exact file:line anchors), §9 (impl sketch: 9a error channel, 9b IRIS, 9c deploy),
  §12 (test strategy), §13 (risk register), §14 (the tracker table you execute row-by-row),
  §15 (packaging — why the .so is NOT a v-pkg/KIDS artifact).
- CLAUDE.md — toolchain (Go `m` from m-cli; M_ENGINE_FLAGS; make targets), the
  optional-suite / callout facts (STDCRYPTOTST is @tier optional and EXCLUDED from the
  default gate — that is blocker G-CI), the "trackers update in the same commit" rule,
  and the m-test-engine:0.2.0 pin.
- src/STDCRYPTO.m (dispatch3/4 :324-354, available :299, irisDigest/Hmac :367-388,
  header ABI/lint notes :1-88), src/callouts/std_crypto.c (crypto_* EVP sigs, argc
  guards :94-128, status codes :32-39), tools/std_crypto.xc, tools/build-callouts.sh,
  scripts/seed-callouts.sh, tests/STDCRYPTOTST.m, Makefile (:111-135 optional split).
- The m-stdlib skills: `m-unit-testing` (STDASSERT + `m test`) and `mumps-modern-style`.

HARD RULES (org):
- STOP-THE-LINE: if you hit an MSL/toolchain/driver defect, HALT and fix the ROOT CAUSE
  in the owning repo — no hacks/mocks/workarounds/"park it" (memory
  stop-the-line-on-infrastructure). Cross-repo same-session fixes are authorized.
- Engine access ONLY through the m-driver-sdk → m-ydb/m-iris stack (never raw docker
  exec/mumps/iris session). YDB test engine = m-test-engine (or M_ENGINE_FLAGS); IRIS
  probe target = foia-t12 via the m-iris driver, READ-ONLY.
- Do NOT hand-edit generated dist/ artifacts; regenerate via the make targets.
- The .so is NOT a v-pkg/KIDS artifact (proposal §15) — do not try to package the native
  callout through v pkg; it is a YDB engine-runtime dependency (re-seed / image bump).

STEP 0 — register the ticket. Add a STDCRYPTO in-module row to docs/module-tracker.md
for this extension (not a new module row) — see proposal §3/§14. Keep it and the §14
table statuses in sync as you land each increment (same-commit rule).

PHASE 0 — MUST-CLEAR BLOCKERS (de-risking; zero production code ships until all green):
  G-IRIS: probe $SYSTEM.Encryption verify surface on foia-t12 via the m-iris driver,
          read-only (OQ-1): confirm RSASHAVerify's exact arg order + key form (needed for
          the Phase-1 IRIS arm), and RECORD whether any generic ECDSA/EdDSA/PSS verify
          exists (shapes Phase 2, not this session). Write the finding into docs/design/
          and the tracker. EXIT: RSA arg/key form confirmed; ES*/EdDSA IRIS answer noted.
  G-ERR:  finalize the disjoint C error channel + dispatchV mapping (proposal §9a):
          C returns 1 valid / 0 invalid / -10 BADKEY / -11 BADALG / -12 VERIFY-FAIL;
          the M $ETRAP sentinel is -99 (callout MISSING) — DISTINCT from every C code so
          callout-missing is never confused with a C error (closes the latent rc=-1
          collision, N-3). CRITICAL: dispatchV must NOT reuse dispatch3/dispatch4 — those
          treat rc=0 as SUCCESS, but for verify rc=0 means INVALID SIGNATURE (a valid
          answer). Write a short design note; write the distinct-code test RED.
  G-CI:   wire `test-optional` + a `coverage-optional` gate into .github/workflows/ci.yml
          against a seeded engine, so STDCRYPTOTST verify cases join the drift-gated green
          path (N-4). EXIT: CI runs STDCRYPTOTST and is green on the current suite.

PHASE 1 — RS256/384/512 on BOTH engines (highest-confidence path; TDD throughout):
  1. tests/STDCRYPTOTST.m: write RS* verify cases FIRST (RED — stub $$verifySig quits 0):
     positive KAT = RFC 7515 App A.2 (RS256); import Google Wycheproof RSA PKCS1 vectors
     (incl. Bleichenbacher padding-forgery, zero/one sigs); wrong-key→0, bit-flip→0;
     error-path: garbage key→U-STDCRYPTO-BADKEY, unknown alg→U-STDCRYPTO-BADALG, callout
     absent→U-STDCRYPTO-CALLOUT-MISSING; assert the four codes are DISTINCT. Confirm RED.
  2. src/callouts/std_crypto.c: add crypto_verify (argc!=4 → -5; SPKI parse via
     PEM_read_bio_PUBKEY/d2i_PUBKEY, NULL→-10; RS*→PKCS1 md from alg, unknown→-11;
     EVP_DigestVerify → 1/0; internal err→-12). Add the descriptor line to
     tools/std_crypto.xc. Rebuild via tools/build-callouts.sh.
  3. src/STDCRYPTO.m: add private dispatchV (per §9a, -99 etrap sentinel, maps
     -10/-11/-12), public $$verifySig(alg,pubKey,msg,sig), RS* thin wrappers, and
     $$verifyAvailable — a SYMBOL-SPECIFIC probe that calls verifySig with a known-good
     self-signed KAT and expects 1 (so a stale .so lacking the symbol is caught, N-8;
     $$available only probes sha256). Document the §7 security contract on the verb
     (STDCRYPTO is alg-agnostic BY DESIGN and does NOT defend against algorithm
     confusion — that is STDJWT's job). Confirm the suite goes GREEN on YDB.
  4. src/STDCRYPTO.m irisVerify arm: RSA via RSASHAVerify (the form G-IRIS confirmed),
     XECUTE-wrapped like irisDigest/irisHmac, branched on $zversion["IRIS". Run the same
     RS* KAT on foia-t12 through the driver stack. Verify binary key/sig byte-fidelity on
     the IRIS transport (A-8/R-BYTE); if >255→? mangling appears, hex-encode vectors +
     $$decode^STDHEX in-suite.
  5. T-DEPLOY: re-seed std_crypto.so for the new symbol (scripts/seed-callouts.sh) or bump
     the pinned m-test-engine image; assert $$verifyAvailable=1 on the test + CI engines
     (proposal §9c/§15, R-DEPLOY). This is real — "same library filename, new symbol" still
     needs a re-seed.
  6. Regenerate dist/ (make manifest etc.), run the full gate (make check + the wired
     optional suite/coverage), confirm drift-gated GREEN.

INCREMENT PROTOCOL (per verified increment, in order, unprompted):
  - Persist the durable, non-obvious lesson to docs/memory/ (keep-test; update an existing
    file over a new one). Candidates: the G-IRIS RSASHAVerify form; the dispatchV rc=0
    inversion gotcha; the re-seed requirement.
  - Update docs/module-tracker.md (the STDCRYPTO in-module ticket + the proposal §14 row
    statuses) in the SAME commit as the code (org same-commit rule); changelog.md only if
    a release is tagged.
  - Run gates BEFORE committing; commit each coherent gate-green increment straight to
    main and push. Do NOT branch-per-increment. If a gate is red, the increment isn't done.

SESSION EXIT (done-condition): $$verifySig verifies RS256/384/512 on YDB AND IRIS
(foia-t12), STDCRYPTOTST RS* cases GREEN and drift-gated, G-CI wired so it stays green,
tracker updated. Then STOP and report the Phase-2 (ES*/EdDSA/PS*) and D1 (STDJWT asym
leg) handoff — those are the next session, gated on this one.

If anything in the proposal proves wrong against the live repo/engine (an API shape, a
file:line anchor, an assumption in §5), treat the discrepancy as the finding: fix the
root cause or update the proposal, and say so — do not paper over it.
```

---

## Notes for the operator

- **Why start with Phase 0, not code:** the three blockers are the findings that force a
  redesign if discovered late — the IRIS engine gap (`G-IRIS`/OQ-1 shapes the IRIS arm),
  the error-channel collision (`G-ERR` shapes `dispatchV`), and the CI gap (`G-CI` decides
  whether "GREEN" means anything). All cheap now, expensive to retrofit (proposal §6).
- **Why RS\* before ES\*:** RSA is the one alg with a documented IRIS primitive, so it is
  the fastest *dual-engine* win and de-risks the ABI/dispatch/packaging/CI plumbing on the
  simplest crypto. ES\*/EdDSA then add only crypto complexity (`R‖S`↔DER, NULL-md) on
  proven rails.
- **Model tier:** the C error-channel design and the ES\*→DER work (next session) are
  reasoning-bound; consider Fable 5 for those. RS\* Phase-1 build is mostly mechanical on
  Opus 4.8.
- **Downstream, not this session:** D1 STDJWT asym leg (m), then D2 VSLJWT / D3 `XUS JWT
  LOGON` RPC / D4 VWEB (v-stdlib / v-\*, separate sessions — see
  `../../../../v-stdlib/docs/proposals/vsl-jwt-auth.md`).
