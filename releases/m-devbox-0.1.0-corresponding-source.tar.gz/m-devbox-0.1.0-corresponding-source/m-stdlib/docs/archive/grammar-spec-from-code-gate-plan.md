---
title: m-stdlib — spec-from-code gate for the M-doc tag grammar
status: implemented
tracker: docs/tracking/module-tracker.md
created: 2026-06-24
last_modified: 2026-06-24
revisions: 2
doc_type: [PLAN]
---

# Spec-from-code gate for the M-doc tag grammar

> **Status: IMPLEMENTED 2026-06-24.** G1–G4 built and green. Registry
> `tools/mdoc_tags.py` (11 tags) is the single source of truth; `gen-manifest.py`
> derives `KNOWN_TAGS` from it (manifest byte-unchanged — behaviour-preserving);
> `gen-grammar.py` generates the §5 table + the `grammar-check` gate
> (`make grammar-check`, in `gates` + `ci.yml`); the registry is a byte-identical
> sibling in v-stdlib (whose generator also derives from it). §6 defaults adopted:
> the source-tag typo warning is wired (non-gating); shipped standalone.

## 1. Motivation

The canonical M-doc tag grammar ([`../guides/m-doc-grammar.md`](../guides/m-doc-grammar.md))
is the normative spec the documentation generators implement. On 2026-06-23 it was
found **drifted from the generator** (`tools/gen-manifest.py`): the spec said "Nine
tags" while the generator parsed **eleven** (it had silently gained `@seam` and
`@tier`), and it named a tool — `gen-manifest.m` — that was never built. The spec was
hand-reconciled (grammar v1.1), but nothing **prevents the next drift**.

This is the exact failure mode the org-knowledge-canonicalization effort targets: a
"canonical" doc hand-maintained beside the code it describes. The grammar is a
**Regime-B (published, machine-generated reference)** artifact
(docs-governance-two-regimes ADR), yet its tag reference is the one part of Regime B
still hand-written and ungated. This plan closes that loop: the tag reference becomes
**generated from a single registry that the generator also consumes**, drift-gated.

**Goal.** Make tag-grammar doc↔code drift structurally impossible — a tag cannot exist
in the generator without appearing in the spec, or vice versa.

## 2. Design

### 2.1 The single source of truth — a tag registry

A Python module **`tools/mdoc_tags.py`** declaring one entry per doc-manifest tag
(the 11 today). A **byte-identical sibling** in m-stdlib and v-stdlib (both
`gen-manifest.py` copies import it; the grammar is engine-neutral so the registry is
identical). Shape (illustrative):

```python
# tools/mdoc_tags.py — the single source of truth for the M-doc tag grammar.
TAGS = [
    Tag(name="@param",  level="label",  multiplicity="0-N",
        body_syntax="NAME [TYPE] BODY", manifest_field="params",
        synopsis="Parameter declaration.", example="@param text string  the JSON doc",
        status="stable"),
    Tag(name="@seam",   level="label",  multiplicity="0-1",
        body_syntax="NAME [vN]", manifest_field="seams",
        synopsis="Marks a side-effecting seam entry point (versioned contract).",
        example="@seam STDENV v2", status="stable"),
    Tag(name="@tier",   level="module", multiplicity="0-1",
        body_syntax="core|optional", manifest_field="tier",
        synopsis="Classifies the whole module (header tag).",
        example="@tier optional", status="stable"),
    # … the remaining 8 label tags …
]
```

Format decision: **Python module** (not JSON) — the immediate consumers are all
Python; a future Go `m doc` CLI can read it via a one-line exporter
(`python3 -c "import mdoc_tags,json; print(mdoc_tags.as_json())"`) if/when it lands.

### 2.2 Three consumers, one source — no drift by construction

1. **`gen-manifest.py` derives its tag set from the registry.** Replace the hardcoded
   `KNOWN_TAGS = {...}` literal (line ~43) with
   `KNOWN_TAGS = {t.name for t in mdoc_tags.TAGS if t.level == "label"}`, and read the
   `@tier` value from the registry's module-level entry. The per-tag **body parsers
   stay hand-coded** (genuinely tag-specific — `SEAM_BODY_RE`, the `@param`
   "NAME TYPE BODY" split, etc.); only the *set* is data-driven. ⇒ the generator can't
   recognize a tag absent from the registry or miss one present: **registry ≡ generator
   by construction.**

2. **`tools/gen-grammar.py` (new) generates the §5 tag table** into the grammar from
   the registry, between markers (the `gen-bodies.py` pattern):
   `<!-- BEGIN GENERATED TAG TABLE -->` … `<!-- END GENERATED TAG TABLE -->`. The block
   is a canonical table (tag · level · multiplicity · body-syntax · manifest field ·
   synopsis · example). The rich per-tag prose (§5.1–5.N) stays **hand-written** and is
   preserved (lossless/additive, exactly like `gen-bodies`).

3. **`check-grammar` (new gate, `make grammar-check`)** red-gates any of:
   - **(a)** the generated table block is stale vs the registry (regenerate + diff);
   - **(b)** set mismatch between the registry and the §5.N hand-prose subsection
     headers (a removed tag whose prose lingers, or a new tag with no prose);
   - **(c)** belt-and-suspenders: at runtime `gen_manifest.KNOWN_TAGS` (+ the `@tier`
     handling) equals the registry's tag set — guards against a future refactor that
     re-hardcodes the set.

### 2.3 Homes (canonical/pointer split preserved)

| Artifact | m-stdlib | v-stdlib |
|---|---|---|
| `tools/mdoc_tags.py` (registry) | ✅ canonical | ✅ byte-identical sibling (its generator imports it) |
| `gen-manifest.py` set-from-registry refactor | ✅ | ✅ (sibling) |
| `tools/gen-grammar.py` + `check-grammar` | ✅ | — (v-stdlib keeps its grammar **pointer**) |
| generated table block in `m-doc-grammar.md` | ✅ | — |

`check-grammar` wires into `make gates` + `ci.yml` engine-free-targets (m-stdlib).
The generator refactor is protected by the existing `manifest-golden` +
`manifest-check` gates (a wrong derived set changes the manifest → caught).

## 3. Scope fences (non-goals)

- **Per-tag body parsers are NOT data-driven** — the gate governs the tag *set* + the
  *doc*, not the parsing logic. (A later extension could carry body-grammar regexes in
  the registry and data-drive parsing; explicitly deferred.)
- **Registry tags `@icr/@source/@call/@status/@custodian` are out of scope** — a
  separate concern (`gen-icr` / `check_citations`); the grammar already documents that
  boundary. The registry covers only the doc-manifest grammar's tags.
- **No auto-generated teaching prose** — §5.1–5.N stay hand-written; only the canonical
  table is generated.

## 4. Phasing & effort (S–M)

| # | Step | Repo(s) | Notes |
|---|---|---|---|
| G1 | Author `tools/mdoc_tags.py` (11 tags + metadata) | both | the registry; TDD a tiny `--self-test`/assert on shape |
| G2 | Refactor `gen-manifest.py` to derive `KNOWN_TAGS` + `@tier` from the registry | both | ~10 lines; verify `manifest-golden` + `manifest-check` unchanged (the proof it's behaviour-preserving) |
| G3 | `gen-grammar.py` + the generated §5 table block | m-stdlib | mirrors `gen-bodies.py`; `--check` + `--self-test` (insert/replace/idempotent) |
| G4 | `check-grammar` gate (a/b/c) + Makefile/CI wiring | m-stdlib | into `make gates` + `ci.yml` engine-free-targets |

## 5. Acceptance criteria

- **AC-G:** changing the tag set requires editing **only** `mdoc_tags.py`; the
  generator recognizes the change, the §5 table regenerates, and `check-grammar`
  **forces a §5.N prose subsection** for any new tag (and forbids prose for a removed
  one). A planted drift (add a tag to the registry but not the prose; or vice versa;
  or hand-edit the generated block) turns `check-grammar` red. `make gates` green on a
  clean tree; `docs-validate` clean.

## 6. Open items

- Whether `check-grammar` also **warns on `@unknowntag` used in any `src/*.m`** that is
  neither a registry tag nor a known registry-tag exception (catches typo'd tags at the
  source). Recommend: yes, as a warning (non-gating).
- Whether to fold this under the org-knowledge-canonicalization umbrella as its lead
  worked example, or ship standalone. Recommend: ship standalone; reference it from the
  umbrella.
