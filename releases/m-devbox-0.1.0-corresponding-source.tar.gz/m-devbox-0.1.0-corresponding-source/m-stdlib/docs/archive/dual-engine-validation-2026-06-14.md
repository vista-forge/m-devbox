---
title: Comprehensive dual-engine validation — m-cli + m-stdlib (YDB + IRIS) + CI + waterline
created: 2026-06-14
doc_type: [NOTES]
status: complete
scope: m-stdlib (33 modules / 49 suites), m-cli (every subcommand), CI across vista-forge, m/v waterline
engines: YottaDB (m-test-engine, byte mode) + IRIS (m-test-iris, namespace USER)
binary: /tmp/m built fresh from m-cli @ vsl-docs-relocation (go1.26.3, grammar sha256:065b48f2…)
---

# Comprehensive dual-engine validation — 2026-06-14

A read-only / test-execution health sweep across the `m-*` toolchain. Exercises
every m-stdlib module and every m-cli command on **both** engines, validates CI,
confirms the m/v waterline, and emits a prioritized backlog. No code was fixed
inline; no PRs opened. The one committed artifact is this report (+ a discoveries
row + a memory note).

## 0. Executive summary

| Dimension | Verdict |
|---|---|
| m-stdlib on **YDB** (byte mode) | **49/49 suites green — 2585 assertions, 0 failures** |
| m-stdlib on **IRIS** | **45/49 green**; 4 non-pass — STDCOMPRESS/STDCRYPTO/STDCRYPTODOC hang, STDCSPRNG aborts 0/0 — all because the IRIS-native backends (B2 PR) aren't on this branch (B-6) |
| m-stdlib coverage (YDB) | aggregate **91.1%** PASS; **gate is aggregate, not per-module** — 4 modules under 85% (finding B-2) |
| m-stdlib drift gates | all clean (manifest, check-manifest, skill, doctest, docs-prose) |
| m-cli Go gate | `go vet` ✓ · `go test -race ./...` ✓ (all pkgs) · `golangci-lint` ✓ · `arch` ✓ (layer m) |
| m-cli lint on m-stdlib | **0 error-severity** (128 style + 8 warning) → `--error-on=error` gate passes |
| CI (all repos) | default branch **green** everywhere; gating shapes correct (§3) |
| m/v waterline | **clean** — all `m-*`=m, all `v-*`=v, violations null, 0 VSL leaks in m-layer (§4) |

**Two P1 headlines:**
1. **Runner (B-1):** the IRIS test path has **no per-suite timeout**. A hung suite
   blocks indefinitely; killing the hung `docker exec` then **corrupts IRIS staging
   so every later suite returns a false 0/0** until the container is restarted
   (reproduced cold). A failed run also writes a contradictory `ok:true` to stdout
   while `ok:false,exit:3` goes to stderr. This invalidated a first naive sweep; the
   IRIS numbers here come from a restart-on-timeout harness + per-suite isolation.
2. **m-stdlib (B-6):** on this branch (`vsl-docs-relocation`) STDCRYPTO, STDCOMPRESS
   and STDCSPRNG carry only their YDB `$&` callout path — the **B2 IRIS-native
   backends PR is not merged** — so on IRIS they hang (3) or abort 0/0 (1). This
   **contradicts the kickoff's claim that the STDCRYPTO IRIS arm works.**

## 1. m-stdlib — module × engine matrix

Invocation (per suite):
- YDB:  `m test tests/X.m --engine=ydb  --docker=m-test-engine --routines src --chset m`
- IRIS: `m test tests/X.m --engine=iris --docker=m-test-iris   --routines src --namespace USER`

`--chset m` (byte mode) is mandatory on YDB; `--routines src` is mandatory on both
(stages ^STDASSERT + modules under test). Counts are passing assertions / total.

| Suite | YDB | IRIS |
|---|---|---|
| STDARGSTST | PASS 37/37 | PASS 37/37 |
| STDASSERTTST | PASS 40/40 | PASS 40/40 |
| STDB64DOCTST | PASS 4/4 | PASS 4/4 |
| STDB64TST | PASS 55/55 | PASS 55/55 |
| STDCACHETST | PASS 48/48 | PASS 48/48 |
| STDCOLLTST | PASS 116/116 | PASS 116/116 |
| STDCOMPRESSTST | PASS 59/59 | **TIMEOUT** (hang — no IRIS backend on this branch; B-6) |
| STDCRYPTODOCTST | PASS 1/1 | **TIMEOUT** (hang — B-6) |
| STDCRYPTOTST | PASS 23/23 | **TIMEOUT** (hang — B-6) |
| STDCSPRNGTST | PASS 406/406 | **FAIL 0/0** (suite aborts, 0 tests run — B-6) |
| STDCSVTST | PASS 59/59 | PASS 59/59 |
| STDDATEDOCTST | PASS 7/7 | PASS 7/7 |
| STDDATETST | PASS 66/66 | PASS 66/66 |
| STDENVTST | PASS 46/46 | PASS 46/46 |
| STDFIXDOCTST | PASS 1/1 | PASS 1/1 |
| STDFIXTST | PASS 28/28 | PASS 28/28 |
| STDFMTDOCTST | PASS 1/1 | PASS 1/1 |
| STDFMTTST | PASS 62/62 | PASS 62/62 |
| STDFSDOCTST | PASS 4/4 | PASS 4/4 |
| STDFSTST | PASS 50/50 | PASS 50/50 |
| STDHARNTST | PASS 15/15 | PASS 16/16 |
| STDHEXDOCTST | PASS 3/3 | PASS 3/3 |
| STDHEXTST | PASS 49/49 | PASS 49/49 |
| STDHTTPTST | PASS 68/68 | PASS 68/68 |
| STDJSONDOCTST | PASS 1/1 | PASS 1/1 |
| STDJSONTST | PASS 209/209 | PASS 209/209 |
| STDLOGTST | PASS 62/62 | PASS 62/62 |
| STDMATHDOCTST | PASS 1/1 | PASS 1/1 |
| STDMATHTST | PASS 36/36 | PASS 36/36 |
| STDMOCKDOCTST | PASS 2/2 | PASS 2/2 |
| STDMOCKTST | PASS 26/26 | PASS 26/26 |
| STDOSTST | PASS 30/30 | PASS 30/30 |
| STDPROFTST | PASS 25/25 | PASS 25/25 |
| STDREGEXDOCTST | PASS 1/1 | PASS 1/1 |
| STDREGEXTST | PASS 102/102 | PASS 102/102 |
| STDSEEDTST | PASS 35/35 | PASS 35/35 |
| STDSEMVERDOCTST | PASS 8/8 | PASS 8/8 |
| STDSEMVERTST | PASS 99/99 | PASS 99/99 |
| STDSNAPTST | PASS 30/30 | PASS 30/30 |
| STDSTRDOCTST | PASS 12/12 | PASS 12/12 |
| STDSTRTST | PASS 63/63 | PASS 63/63 |
| STDTOMLDOCTST | PASS 1/1 | PASS 1/1 |
| STDTOMLTST | PASS 59/59 | PASS 59/59 |
| STDURLDOCTST | PASS 5/5 | PASS 5/5 |
| STDURLTST | PASS 150/150 | PASS 150/150 |
| STDUUIDDOCTST | PASS 2/2 | PASS 2/2 |
| STDUUIDTST | PASS 131/131 | PASS 131/131 |
| STDXFRMTST | PASS 38/38 | PASS 38/38 |
| STDXMLTST | PASS 209/209 | PASS 209/209 |

**YDB totals: 49 suites, 2585 assertions, 0 failed.** (STDHARN reports 15 on YDB /
16 on IRIS — one extra resident-tier assertion on IRIS; both green.)

### Coverage (YDB, `m coverage --min-percent=85`)

Overall **91.10%** (4174 / 4582 lines) → gate **PASS (exit 0)**. But the gate is on
the *aggregate*, so per-module shortfalls pass silently. Per-module, ascending:

| Module | Coverage | Note |
|---|---|---|
| STDARGS | 66.22% (98/148) | **under 85** |
| STDFS | 69.28% (115/166) | **under 85** |
| STDHARN | 76.67% (69/90) | **under 85** |
| STDCSPRNG | 81.08% (60/74) | **under 85** (probabilistic paths) |
| STDOS | 85.11% | borderline |
| (all others) | ≥ 86% | up to STDCOLL 99.54% |

Two non-module files are pulled into the measurement and read 0%: `tests/STDJSONSMOKE.m`
(0/4) and `examples/stdargs-demo.m` (0/25) — they dilute the aggregate and shouldn't
be counted. See B-2.

### Drift gates (engine-free) — all clean
`make manifest-check` ✓ (33 modules, 290 public labels, 43 error codes) ·
`make check-manifest` ✓ · `make skill-check` ✓ · `make doctest-check` ✓ ·
`make check-docs-prose` ✓.

## 2. m-cli — command × engine matrix

Go gate (built fresh, `GOFLAGS=-mod=mod` airgapped):
- `go vet ./...` → exit 0
- `go test -race ./...` → **all packages ok** (flow 143s, lint 235s, lsp/mcov/mfmt/mtest/workspace all green)
- `golangci-lint run ./...` → exit 0 (first run hit a stale parallel-lock; clean on retry)
- `m arch check .` → ok, layer m, violations null

| Command | Result | Notes |
|---|---|---|
| `fmt --check` | ✓ both | 33 files scanned, no drift |
| `lint` | ✓ | Go `m` uses `--check` (exit 3 on any finding); **`--error-on` is a Python-m-cli flag, not in Go `m`** (B-3). On m-stdlib: 128 style + 8 warning, **0 error** → `--error-on=error` gate green |
| `test` | ✓ both | validated across 49 suites × 2 engines |
| `coverage` | ✓ YDB | aggregate gate (B-2) |
| `arch check` | ✓ | every m-layer repo |
| `watch` | exists | `--run` flag present; daemon — not run |
| `lsp` | exists | daemon — `--help` only |
| `vista status` / `vista exec` | exists | driver-probe; needs `--engine`/`--transport` + container config; not exercised against live VistA this sweep |
| `list`/`pull`/`status`/`verify`/`push` (irissync) | **SIBLING_NOT_FOUND** | `irissync` binary not on PATH locally (B-4) |
| `kids` | **SIBLING_NOT_FOUND** | `kids-vc` binary not on PATH locally (B-4) |
| `version` / `schema` / `install-completions` | ✓ | `m version` (not `--version`, which errors USAGE) |

## 3. CI — multi-repo

Latest default-branch run per repo (`gh run list`):

| Repo | Default branch CI | Workflow shape |
|---|---|---|
| m-stdlib | green (master/PRs) | **gating:** `m-stdlib (latest-master)` (YDB: drift + fmt + lint + TAP + coverage) · `arch / arch` (reusable `vista-forge/.github/.github/workflows/arch-waterline.yml@main`). **fail-soft:** `iris-portability-check` (`continue-on-error: true`, `if: pull_request` only) |
| m-cli | green (main) | `ci` |
| m-driver-sdk | green (main) | `ci` |
| m-iris | green (main) | `ci` |
| m-ydb | green (main) | `ci` |
| m-parse | green (main) | `ci` |
| v-stdlib | green (main) | `ci` + reusable arch-waterline G1 caller |
| v-cli | green (main) | `ci` |
| v-pkg | green (main) | `ci` |
| m-dev-tools-mcp | green (main) | `ci` |

Notes: m-stdlib had a transient PR-run failure (`27502186242`) immediately followed
by a green re-run (`27502325327`) on `iris-native-backends-reconciled`; not a
standing red. The m-stdlib `iris-portability-check` being fail-soft is **correct**
given B-1 (a hung/blocked IRIS arm must never gate the YDB pipeline). No false-green
detected: the gating YDB job runs 2585 real assertions.

## 4. m/v waterline (MSL/VSL)

`m arch check .` per repo + independent grep for `VSL*` leaks in `m`-layer `src/`.

| Repo | Layer tag | `arch check` | VSL leak in m src |
|---|---|---|---|
| m-stdlib | m | ✓ violations null | 0 |
| m-cli | m | ✓ violations null (Go+M checked) | 0 |
| m-driver-sdk | m | ✓ | 0 |
| m-iris | m | ✓ | 0 |
| m-ydb | m | ✓ | 0 |
| m-parse | m | ✓ | 0 |
| m-dev-tools-mcp | m | ✓ | 0 |
| v-stdlib | v | ✓ | n/a (carries VSL by design — 1 file) |
| v-cli | v | ✓ | n/a |
| v-pkg | v | ✓ | n/a |

Repos with **no layer declared** (exit 2, `ARCH_LAYER` "no layer declared") — all
non-toolchain, expected: `docs`, `doc-framework`, `go-cli-template`, `workspace`,
`vdocs-cli`, `vdocs-tui`, `vdocs-web` (Python), `vista-info-hub`, `vista-iris`.
(`vista-iris`/`vista-info-hub` are VistA-specific apps; if they ever host M routines
governed by the waterline they should adopt `layer: v` — informational only, W-1.)

**Waterline verdict: clean.** G1 dependency direction holds everywhere; no
m→v import; no `^VSL*` symbol in any m-layer routine; v-layer correctly isolated.

## 5. Prioritized cleanup backlog

Severity: P1 blocks a phase / reliability · P2 recurring nuisance · P3 minor ·
docs = documented constraint.

| # | Sev | Repo | Symptom (actual) | Root-cause hypothesis | Suggested fix | Dedicated session? |
|---|---|---|---|---|---|---|
| **B-1** | **P1** | m-cli (runner) | On IRIS, a hung suite (`m test tests/STDCOMPRESSTST.m`) never returns — `iris session` blocks; only an external `timeout` kill stops it (shell exit 124). Killing the hung `docker exec` then makes **every subsequent** suite return `passed:0 total:0`, until `docker restart m-test-iris`. Reproduced cold: STDB64 55/55 → 0/0 after a kill → 55/55 again after restart. Worse, a failed/0-test run emits a **contradictory dual-stream JSON**: stdout `{"ok":true,"exit":0,"passed":0}` while stderr `{"ok":false,"exit":3,"TESTS_FAILED"}` — a tool reading stdout sees success. | `m test --engine=iris` has **no per-suite timeout** and no post-kill staging recovery, so a killed/hung session leaves IRIS unable to stage routines → silent 0/0; and the success-shaped stdout is written even when the run failed. | (1) Add a per-suite timeout to the IRIS engine path (default ~120s) recording a real TIMEOUT result, not 0/0. (2) Make stdout reflect failure (don't emit `ok:true,exit:0` when exit 3 on stderr). (3) Treat a 0/0 (zero tests executed) as a hard error with the underlying M abort surfaced, not a silent passed:0. | **Yes — m-cli runner** |
| **B-6** | **P1** | m-stdlib | On `vsl-docs-relocation`, 4 IRIS suites fail (each verified in isolation after a container restart + a known-good STDB64 55/55 sanity, so not B-1 cascade): **STDCOMPRESSTST** hang/x124, **STDCRYPTOTST** hang/x124, **STDCRYPTODOCTST** hang/x124, **STDCSPRNGTST** aborts → 0/0 exit 3. Same suites are 59/59, 23/23, 1/1, 406/406 on YDB. **Contradicts the kickoff's known-blocker note** ("STDCRYPTO + STDHTTP IRIS arms work") — STDCRYPTO now hangs on IRIS; only STDHTTP (68/68) works. | These modules carry only the YDB `$&`/`$ZF` callout path on this branch (`STDCRYPTO`→`$&stdcrypto`, `STDCSPRNG`→`$&` cs_random, `STDCOMPRESS`→`$&stdcompress`). The **IRIS-native backends (B2 PR, branch `iris-native-backends-reconciled`, CI green)** that add the IRIS arms are **not merged into this branch**, so on IRIS the `$&` external-call either hangs or aborts the suite before `report^STDASSERT`. STDHTTP works because its tested paths are pure-M. | Merge the B2 IRIS-native-backends PR (or rebase this branch onto it). Re-run STDCRYPTO/STDCOMPRESS/STDCSPRNG on IRIS to confirm green. Until then STDCSPRNG should soft-fall-back to its `/dev/urandom` READ loop on IRIS rather than aborting. | **Yes — m-stdlib** (merge B2 + re-validate IRIS) |
| **B-2** | P2 | m-stdlib | `m coverage --min-percent=85` exits 0 at 91.1% aggregate while STDARGS 66%, STDFS 69%, STDHARN 77%, STDCSPRNG 81% are **under 85** — the per-module guarantee in CLAUDE.md/README is **not enforced**. `tests/STDJSONSMOKE.m` (0/4) + `examples/stdargs-demo.m` (0/25) are counted, diluting the number. | Coverage gate aggregates all staged lines rather than gating per source module; non-`src/` files leak into the staged set. | Either make the gate per-module (`--min-percent` applied per module, matching the docs) or update the docs to say "aggregate". Exclude `tests/` + `examples/` from the coverage denominator. Then raise STDARGS/STDFS/STDHARN coverage. | m-stdlib (coverage gate + tests) |
| **B-3** | P3/docs | m-cli ⟷ docs | Go `m lint` rejects `--error-on` (`USAGE: unknown flag`); it uses `--check`. But `make lint` / org CLAUDE.md specify `m lint --error-on=error`. Also Go `m` has **no `m engine` command** (USAGE error), though the `m-engine` skill documents `m engine <verb>`. | Go `m` and Python `m-cli` have diverged flag/command surfaces; CI installs Python `m-cli` so `make lint` works in CI but not against local Go `m`. | Reconcile: either add `--error-on` + `engine` to Go `m`, or update CLAUDE.md / m-engine skill to note these are Python-m-cli-only. | No — doc/flag reconciliation |
| **B-4** | P3 | m-cli (local env) | `m kids …` → `SIBLING_NOT_FOUND` (kids-vc); `m list/pull/status/verify/push` → `SIBLING_NOT_FOUND` (irissync). Neither sibling binary is on PATH locally. | These commands delegate to sibling binaries not installed in this workspace. | Document the sibling-binary dependency (install/build step) so kids + irissync can be exercised locally; or have `m` print an actionable "install kids-vc" hint. | No — env/setup doc |
| **B-5** | P3 | infra (m-test-iris) | 3 orphaned `docker exec -i m-test-iris … iris session` processes from Jun 12 found on the host. | Earlier killed/abandoned test runs leaked their `docker exec` children. | Runner should reap its `docker exec` child on exit; periodic host cleanup. (Cleared by the container restarts during this sweep.) | No |
| **W-1** | info | vista-iris / vista-info-hub | No `layer` declared (`arch check` exit 2). | They predate / are outside waterline governance; not `m-*`/`v-*` prefixed. | If they host waterline-governed M, add `layer: v`. Informational. | No |

### IRIS crypto/CSPRNG cluster — verified (isolation)
Each suspect was re-run alone after `docker restart m-test-iris` + 20s settle + a
known-good STDB64 sanity (all four sanities = 55/55), proving the container was warm
and staging worked — so the failures below are **real**, not B-1 cascade:

| Suite | Sanity (STDB64) | Verdict |
|---|---|---|
| STDCSPRNGTST | 55/55 | aborts → 0/0, exit 3 (suite never runs) |
| STDCRYPTOTST | 55/55 | hang → timeout x124 |
| STDCRYPTODOCTST | 55/55 | hang → timeout x124 |
| STDCOMPRESSTST | 55/55 | hang → timeout x124 |

Root cause + fix: **B-6** (B2 IRIS-native backends not merged into this branch).

## 6. Verification of the sweep itself

- Every `src/STD*.m` has a YDB result **and** an IRIS result recorded in §1.
- Every m-cli subcommand has a result in §2.
- Every `~/vista-forge` repo has an arch verdict in §4.
- The IRIS numbers come from a **restart-on-timeout** harness after the naive sweep
  was shown to self-contaminate (B-1); the 4 crypto-cluster suspects are re-verified
  in isolation (§5 tail) so no cell is left "unknown" — each is a number, a
  TIMEOUT(x124), or an explicit "blocked by embedded-Python".

_Method: `/tmp/m` built from m-cli @ vsl-docs-relocation; per-suite JSON captured
under `/tmp/val/{ydb,iris3,verify}`; aggregated by `/tmp/agg2.py` keying on shell
exit codes (the stdout JSON reports `ok:true` even on a 0/0 non-run, so exit codes
are authoritative)._
