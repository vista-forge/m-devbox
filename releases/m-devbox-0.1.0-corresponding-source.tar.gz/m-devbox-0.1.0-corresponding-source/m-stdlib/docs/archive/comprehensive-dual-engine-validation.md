---
title: Comprehensive dual-engine validation — m-cli + m-stdlib (YDB + IRIS) + CI + MSL/VSL waterline
status: ready
created: 2026-06-14
doc_type: [PROMPT]
for: a fresh validation session (read-only sweep across repos; report-producing)
repos: [m-cli, m-stdlib, "+ waterline arch-check across all ~/vista-forge repos"]
---

# Comprehensive dual-engine validation

A full top-to-bottom health check: exercise **every m-stdlib module** and **every
m-cli command** on **both** M engines (YottaDB + IRIS), validate CI across the
multi-repo project, confirm the **m/v (MSL/VSL) waterline** is clean, and emit a
**data-driven** cleanup backlog. This is primarily a **read-only / test-execution**
sweep — it does not fix code inline; it captures findings (with real numbers) and
spins fixes out as per-repo follow-up sessions. It commits one artifact: the
validation report + backlog.

Paste the fenced block into a fresh session.

```
You are running a COMPREHENSIVE DUAL-ENGINE VALIDATION of the m-* toolchain. Goal:
a data-driven health report + a PRIORITIZED cleanup backlog. This is a READ-ONLY /
test-execution sweep across repos — do NOT fix code inline and do NOT open/merge PRs.
Capture findings; spin fixes out as per-repo follow-up sessions (one session ↔ one repo
for edits). The ONLY thing you commit is the validation report + a memory/tracker note.

WORKSPACE: ~/vista-forge/ (sibling repos: m-cli, m-stdlib, m-driver-sdk, m-iris,
m-ydb, v-stdlib, v-pkg, …). Read ~/vista-forge/CLAUDE.md (Increment Protocol + the
m/v waterline section) and each repo's own CLAUDE.md before running anything.

ENGINES — both must be exercised (confirm up with `docker ps`):
  • YDB:  container `m-test-engine` (m-test-engine:latest). The optional-module callout
          libs are deployed at /opt/stdlib (STDLIB_LIB; ydb_xc_{stdcrypto,stdcompress,
          stdhttp} are set inside the container).
  • IRIS: container `m-test-iris` (intersystemsdc/iris-community:latest), namespace USER.
  • VistA: container `vehu` — only if you exercise v-* / VistA-dependent paths.

THE `m` BINARY — build fresh; do NOT trust the committed one:
  cd ~/vista-forge/m-cli && GOPROXY=file://$HOME/go/pkg/mod/cache/download \
      GOSUMDB=off GOFLAGS=-mod=mod go build -o /tmp/m .
  (m-cli/dist/m can be STALE — last session it predated the --chset flag. Build from
  source for the whole sweep and invoke /tmp/m.)

CRITICAL ENGINE-INVOCATION IDIOMS (bake into every run — these cost hours to rediscover):
  • YDB byte mode is MANDATORY for byte/binary suites:
      /tmp/m test tests/X.m --engine=ydb --docker=m-test-engine --routines src --chset m
    m-test-engine defaults to ydb_chset=UTF-8; WITHOUT `--chset m`, byte modules
    (STDCSPRNG / STDB64 / STDHEX / STDJSON-UTF8 / STDCRYPTO / STDCOMPRESS) fail with
    %YDB-E-BADCHAR (bytes >127 re-encode). Symptom: suite reports 0/0 and "FAIL".
  • IRIS:
      /tmp/m test tests/X.m --engine=iris --docker=m-test-iris --routines src --namespace USER
    (byte mode is inherent on IRIS; no --chset.)
  • `--routines src` is REQUIRED so ^STDASSERT and the modules under test are staged
    (omitting it also yields a misleading 0/0).

KNOWN BLOCKER (verify still true; do NOT re-chase): m-test-iris (iris-community) has a
NON-FUNCTIONAL embedded Python — `##class(%SYS.Python).Import("sys").version` returns 0.
So STDCOMPRESS's IRIS arm (embedded-Python zlib/zstd) ABORTS non-trappably (0/0) there.
STDCRYPTO + STDHTTP IRIS arms work (built-in $SYSTEM.Encryption / %Net.HttpRequest).
Validating STDCOMPRESS-IRIS needs a working-embedded-Python IRIS (e.g. vista-iris). See
m-stdlib/docs/tracking/discoveries.md (2026-06-14).

PART A — m-stdlib: every module, both engines (cd ~/vista-forge/m-stdlib).
  • Authoritative module list: dist/stdlib-manifest.json (33 modules / public labels) +
    every src/STD*.m and tests/*TST.m (incl. generated STD*DOCTST.m).
  • Run EVERY *TST.m suite on YDB (--chset m) AND IRIS. Per suite record: engine,
    pass/fail counts, and (for any non-green) the failure MODE — byte-mode, $ZCHAR-on-IRIS,
    null/empty subscript, `@cb@(args)` argument-indirection, embedded-Python, wide-char
    capture, network, or missing callout. Build a module × engine matrix.
  • Optional tier (STDCRYPTO/STDCOMPRESS/STDHTTP + STDCRYPTODOCTST): needs the callout
    libs (present in m-test-engine). Expect STDCOMPRESS-IRIS = blocked (see above).
  • Coverage: `m coverage --min-percent=85` per module on YDB; flag any under-85.
  • Drift gates (engine-free): make manifest-check, check-manifest, skill-check,
    doctest-check, check-docs-prose — all must be clean.

PART B — m-cli: every command, both engines (cd ~/vista-forge/m-cli).
  • Gate: `make all` (or the repo's: lint + race-test + build + arch). Capture `go test ./...`.
  • Functionally exercise EVERY subcommand from `m --help`: fmt (--check), lint
    (--check / --error-on), test, coverage, watch --run, arch check, kids
    (decompose/assemble/roundtrip/lint), list/status/verify (irissync), engine. Run each
    against BOTH engines where engine-bound; note any command that errors, is half-
    implemented, or diverges per engine.
  • TOOLCHAIN SPLIT to watch: CI installs the PYTHON m-cli (m-dev-tools/m-cli) + a PINNED
    tree-sitter-m for fmt/lint; locally you may run the GO m. They can DISAGREE — e.g. the
    pinned tree-sitter-m can't parse `^||` process-private globals (2 ERROR nodes →
    `m fmt --check` red) while the newer Go grammar parses them fine. When a fmt/lint
    finding appears, record WHICH toolchain produced it. (discoveries 2026-06-14, tree-sitter-m lane.)

PART C — CI validation, multi-repo.
  • For m-stdlib + m-cli (+ the other active repos): `gh run list` / `gh run view` the
    latest runs. Map each workflow's jobs as GATING vs fail-soft (continue-on-error).
    Reference shape for m-stdlib: YDB job (gating) + `arch / arch` + iris-portability-check
    (PR-only, continue-on-error). Confirm the reusable org arch-waterline workflow runs in
    each repo.
  • Flag: any repo with red CI; any gating set that's wrong (a fail-soft job that should
    gate, or vice-versa); any job that passes on 0 tests / 0 assertions (false green).

PART D — MSL/VSL waterline (the m/v division).
  • For EVERY repo under ~/vista-forge/: `/tmp/m arch check .` (or the repo's arch
    target). Confirm: the committed layer tag (m|v — in dist/repo.meta.json or root
    repo.meta.json), G1 dependency direction (v→m only; NO m→v import), NO ^VSL*
    references in any m-layer routine, and the seam-pin rules (ADR:
    m-stdlib/docs/background/m-v-waterline-adr.md if present, else ~/vista-forge/CLAUDE.md).
  • Confirm v-stdlib exists / is scaffolded and is layer v; m-stdlib / m-cli /
    m-driver-sdk are layer m. Flag any cross-layer leak or missing/!=expected layer tag.

DELIVERABLE — data-driven, committed (one artifact):
  • Write a report to m-stdlib/docs/tracking/dual-engine-validation-2026-06-14.md
    (adjust date to today) containing:
      (1) module × engine pass/fail matrix (m-stdlib);
      (2) m-cli command × engine matrix;
      (3) CI job map per repo (gating vs fail-soft, last run status);
      (4) waterline arch-check verdict per repo;
      (5) a PRIORITIZED cleanup backlog — each item: severity · repo · symptom (with the
          ACTUAL error text / counts / exit code) · root-cause hypothesis · suggested fix ·
          whether it needs a dedicated per-repo session.
    Cite concrete numbers (assertion counts, coverage %, exit codes) — no vibes.
  • Add a discoveries.md row (m-stdlib) / the relevant repo's tracker for any NEW finding.
  • Increment Protocol: commit the report + a memory note, push the branch. Do NOT fix
    code inline and do NOT open/merge PRs — the backlog drives per-repo follow-up sessions.

VERIFY (the sweep itself is complete): every src/STD*.m has BOTH a YDB result and an IRIS
result recorded (pass / fail-with-mode / N-A-with-reason); every m-cli subcommand has a
result on each applicable engine; every ~/vista-forge repo has an arch-check verdict;
the backlog has zero "TODO/unknown" cells — every gap is a number or an explicit "blocked by X".
```
