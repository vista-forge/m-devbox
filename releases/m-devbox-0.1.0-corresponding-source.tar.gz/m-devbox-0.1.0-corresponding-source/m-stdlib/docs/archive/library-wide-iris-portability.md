# Fresh-session prompt — library-wide IRIS portability (the last 4 pure-M modules)

Drive the **4 remaining non-base pure-M modules** to dual-engine (YDB + IRIS)
green, bringing the **entire pure-M m-stdlib stack** to IRIS parity. This is the
direct follow-on to VSL **T0b.2** (which certified the 17-module MSL KIDS base on
both engines, merged to `master` 2026-06-13). The 4 modules each fail on IRIS for a
portability class **already solved in the base** — so this is a focused, de-risked
pass that *applies established idioms*, not a research effort.

Repo/branch: `~/vista-forge/m-stdlib`, branch a fresh `iris-portability-nonbase`
**off `master`** (T0b.2 is merged; master is the truth). One session ↔ this repo ↔
this branch. Skills: `m-unit-testing`, `mumps-modern-style`, `m-stdlib`, `m-engine`.

## The 4 targets (from the 2026-06-13 dual-engine sweep — discoveries.md)

The post-T0b.2 sweep ran the full stack on both engines. **YDB: 33 suites 2043/0.**
**IRIS (foia/remote): 25 of 29 green** — the base-17 plus 6 non-base already clean
(STDCACHE/STDENV/STDLOG/STDSEMVER/STDSNAP/STDXFRM). These 4 still crash, each a
known class:

| Module | IRIS failure (sweep) | Apply this established fix (template in the merged code) |
|---|---|---|
| **STDSEED** | crash early; `do @callback@(args)` ×3 + reads files | `xecute`-built dispatch — see `parseFile^STDCSV` (`xecute "do "_cb_"(args)"`). Likely also needs the STDFS facade / the `readLn` `$ECODE`-on-EOF lesson if it hand-rolls file reads. |
| **STDMOCK** | crash mid-suite; `do @callback@(args)` ×1 | same `xecute`-dispatch idiom as STDCSV |
| **STDFIX** | runner crash; `set $etrap` ×2 (transaction/fixture unwind) | IRIS `try/catch` arm guarded by `if $zversion["IRIS"` — see `irisRaises^STDASSERT` and `suite^STDHARN`. **Caveat:** STDFIX wraps `tstart`/`trollback`; check IRIS transaction semantics too, not just the `$etrap` unwind. |
| **STDPROF** | crash early; `$ZHOROLOG` ×1 (timing) | `$ZTIMESTAMP` IRIS arm (xecute-hidden) — copy `now^STDDATE` / `unixMs^STDUUID` verbatim in shape. |

Callout modules (`STDCSPRNG`/`STDCRYPTO`/`STDCOMPRESS`/`STDHTTP`) are
**YDB-byte-mode-only by design** — out of scope (they need their `$ZF` `.so` +
`ydb_chset=M`; `make test-optional`).

**Scope note:** this is about library-wide IRIS *parity*, NOT MSL-KIDS-base
membership. Do **not** add these 4 to `kids/std.build.json` — the base stays the
cert'd 17. (STDSEED/STDFIX have >8-char-name or callout-ish concerns anyway.)

## Read first (don't rediscover — this session has the idioms + gotchas)

- `docs/tracking/discoveries.md` — the **2026-06-13 dual-engine-sweep row** (this
  target list) + the T0b.2 portability rows (the established fixes) + the P3 m-iris
  docker-truncation row.
- `docs/memory/t0b2-msl-kids-base.md` — the full idiom catalogue + hard-won M
  gotchas (operator precedence, `$ECODE`-after-try/catch, `'$zversion["IRIS"`
  parse trap, xecute-hiding off-engine syntax, M-MOD-024 false positives).
- The **template fixes in the merged source**: `parseFile^STDCSV` (xecute
  dispatch), `irisRaises^STDASSERT` + `parse^STDJSON`/`irisParse` (try/catch arm +
  `$ecode` clear), `now^STDDATE` / `unixMs^STDUUID` (`$ZTIMESTAMP` arm),
  `readLn^STDFS` (`$ECODE`-on-EOF clear), `cwd^STDOS` (`$ZDIRECTORY`).

## Load-bearing gotchas (all cost real time this session)

1. **M has NO operator precedence** (strict left-to-right). `192+cp\64` is
   `(192+cp)\64`. Parenthesise every `\`/`#`/`*` subexpression. (Two latent UTF-8
   bugs hid here for months because no test exercised them.)
2. **IRIS `try/catch` leaves `$ECODE` set** to the caught code. If the path is a
   *normal* return (EOF, a failed-parse that returns 0/"" with the diagnostic
   elsewhere), the catch must `set $ecode=""` or it poisons the next call.
3. **`'$zversion["IRIS"` parses as `('$zversion)["IRIS"`** (unary `'` binds first) —
   always false on YDB → wrong arm. Use the **positive** `if $zversion["IRIS" … quit`
   form (what STDHARN/STDASSERT use).
4. **Off-engine syntax must be `xecute`-hidden** so the *other* engine's compiler
   never parses it — `$system.*`, `$username`, `close path:"D"`, `try{}`. (YDB
   intrinsics like `$ztrnlnm`/`$zhorolog`/`$zcmdline` DO compile on IRIS, just fail
   at runtime, so guard-before is enough for those.)
5. IRIS prohibits **null local subscripts** (`x("")`) unconditionally — even on the
   VistA-on-IRIS target. No `$ZCHAR`/`$ZASCII` on IRIS (use `$CHAR`, byte-equiv for
   0–255). `$ZDIRECTORY` (not `$PWD`) for cwd.
6. **M-MOD-024 false-positives** on a var set via an xecute-hidden line → add
   `; m-lint: disable-next-line=M-MOD-024` on the read.

## Engines + methodology

Both up: YDB `m-test-engine`, IRIS `m-test-iris` (USER, `_SYSTEM`/`testsys`, :52774).
**foia** = the real IRIS target (remote/Atelier, ground truth — the GetOut path has
the wide-char fix). IRIS infra recipe: stop vehu → start foia → kill the TaskMan
tree (`ps … ZTM|XWBTCPM|XOBVTCPL` → kill) → `meta doctor --transport remote` →
`export M_IRIS_PASSWORD=vista123` (the `_SYSTEM` password persists across restarts;
namespace VISTA, base URL `http://127.0.0.1:52773/api/atelier/v1/`).

Per-suite probing: `M=~/vista-forge/m-cli/dist/m`.
- **YDB:** `$M test tests/X.m --docker=m-test-engine --engine=ydb --routines=src`
- **IRIS quick probe** (compile/error): `--docker=m-test-iris --engine=iris
  --routines=src` — BUT the docker session transport **truncates frames >~84
  assertions** (discoveries P3), so for whole-suite IRIS truth use the **foia/remote
  `run^STDHARN`** path: `$DRV exec load <src+STDASSERT+STDHARN+suite> --transport
  remote`; `$DRV exec eval 'do run^STDHARN("XTST")' --transport remote`
  (`$DRV=~/vista-forge/m-iris/dist/m-iris`; m-cli has no remote-IRIS `m test`).
- **Ad-hoc single-line `exec eval` probes** that use `$get($ecode)`, multi-statement
  lines, or literal multibyte mislead (`<SYNTAX> 3` wrapper artifacts, byte-vs-Unicode
  stdin). Trust the real runner; build `\u`/backslash via `$char(92)`.

## Per module (TDD, both engines)

1. **RED first** — confirm the suite crashes on IRIS (it does; the sweep is your RED)
   and is green on YDB. Diagnose the *exact* failing op via the foia/remote runner
   (not an irissession hand-load — IRIS rejects `.m`/`.mac` hand-loads).
2. Apply the matching established idiom; keep the **YDB path byte-identical** (guard
   the IRIS arm `false` on YDB).
3. **GREEN** — suite passes on BOTH engines (YDB via m-test-engine, IRIS via
   foia/remote `run^STDHARN`). Full YDB stack stays **2043/0**.
4. Gates: `fmt` clean, `m lint` errors=0, coverage ≥85 per module unless documented
   (dual-engine xecute-hidden arms lower per-file coverage — document like
   STDFS 69.3%/STDHARN 76.7% if needed; aggregate gate is what counts). Regenerate
   `make manifest`/`skill`/`doctest` if any `; doc:` block changes (drift-gated).
5. **Increment Protocol per module** (org `CLAUDE.md`): persist memory (the
   workstream file) + update `discoveries.md` (close that module's line) +
   `module-tracker.md`; commit + push the branch. Checkpoint each module as its own
   commit — don't batch.

## Close

- Re-run the **dual-engine sweep** → all **29 non-callout suites green on IRIS**
  (YDB stays 2043/0). Update the discoveries sweep row to closed.
- Consider whether the now-fully-portable library warrants a **changelog entry /
  version bump** (ask the user; tagging stays a user action).
- Restore engines (vehu up, foia stopped). Clean any source-loaded routines off foia.

## Starting context (branch `docs/iris-stack-sweep`)

The sweep that produced this target list is recorded in `docs/tracking/discoveries.md`
on branch `docs/iris-stack-sweep` (and this prompt rides with it). If that branch
isn't merged to `master` yet, either merge it first or branch the portability work
off it so the sweep row + this prompt are present.
