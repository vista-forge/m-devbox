---
title: Remediate the dual-engine validation backlog (B-1…B-6)
status: ready
created: 2026-06-14
doc_type: [PROMPT]
for: per-repo fix sessions (TDD; code-changing — NOT read-only)
source_report: m-stdlib/docs/tracking/dual-engine-validation-2026-06-14.md
repos: [m-cli, m-stdlib]
---

# Remediate the dual-engine validation backlog

The 2026-06-14 comprehensive dual-engine validation
([`docs/tracking/dual-engine-validation-2026-06-14.md`](../tracking/dual-engine-validation-2026-06-14.md))
produced a prioritized backlog **B-1…B-6**. This file turns it into **per-repo fix
sessions**. Each session is **code-changing and TDD-driven** (the opposite of the
read-only validation sweep), follows the org **Increment Protocol**, and edits **one
repo only** (one session ↔ one repo ↔ one branch).

**Run order / parallelism.** Session A (m-cli) and Session B (m-stdlib) touch
different repos and can run **in parallel**. If serializing, do **A first** — the
m-cli IRIS-runner fix (B-1) makes the m-stdlib IRIS re-validation in B trustworthy.

**State note (verified on `master` 2026-06-14, after PR #11 landed):** the B2
IRIS-native-backends PR is now merged, so **B-6 is mostly resolved** — STDCRYPTOTST
(23/23) and STDCRYPTODOCTST (1/1) now PASS on IRIS. What remains under B-6 is
**STDCSPRNG** (no IRIS arm → aborts 0/0) and the **STDCOMPRESS-IRIS** test-infra
block (embedded-Python non-functional on `m-test-iris`). Re-verify before fixing.

Engines (confirm `docker ps`): YDB `m-test-engine` (byte mode — `--chset m`), IRIS
`m-test-iris` (namespace USER). Build a fresh binary each session:
`cd m-cli && GOPROXY=file://$HOME/go/pkg/mod/cache/download GOSUMDB=off GOFLAGS=-mod=mod go build -o /tmp/m .`

> ⚠️ **IRIS test hygiene (until B-1 is fixed):** never `pkill` a hung
> `docker exec … m-test-iris` session — it corrupts staging so every later suite
> returns a false `0/0`. Recover with `docker restart m-test-iris` + wait healthy +
> ~15s settle. Wrap every IRIS `m test` in `timeout`. Trust the **shell exit code**,
> not stdout `ok` (a failed run still prints `ok:true` on stdout).

---

## Session A — repo: **`m-cli`** (START HERE: `cd ~/vista-forge/m-cli`)

Paste the fenced block into a fresh session.

```
You are fixing the m-cli IRIS-test-runner backlog from the 2026-06-14 dual-engine
validation. START in ~/vista-forge/m-cli. Read ~/vista-forge/CLAUDE.md
(Increment Protocol + m/v waterline) and m-cli/CLAUDE.md first. This is a Go repo:
TDD hard rule (write the failing test first), `make all` (lint + race-test + build +
arch) green before every commit, Increment Protocol per increment (memory in
m-cli/docs/memory or its convention; tracker; commit + push the working branch —
branch off main first, never commit the increment onto main). Do NOT merge to main.

Full evidence: m-stdlib/docs/tracking/dual-engine-validation-2026-06-14.md §5.

FIX B-1 (P1 — the IRIS test runner). Three concrete defects, all reproducible:
  (1) No per-suite timeout on the IRIS engine path. A suite that hangs in an
      `iris session` (e.g. embedded-Python paths) blocks `m test` forever. Add a
      configurable per-suite timeout (default ~120s) to the IRIS exec path that
      records a real TIMEOUT result (distinct exit/status), and on timeout reaps its
      own `docker exec` child AND leaves the engine usable for the next suite (the
      current failure mode is that a killed session corrupts IRIS staging → all later
      suites return 0/0; if a clean kill can't avoid that, the runner should
      restart/re-handshake the session before the next suite).
  (2) Contradictory dual-stream output. On a failed/0-test run the CLI writes
      `{"ok":true,"exit":0,"passed":0}` to STDOUT while writing
      `{"ok":false,"exit":3,"TESTS_FAILED"}` to STDERR. Make stdout reflect the real
      outcome — a tool parsing stdout must not see ok:true for a failed run.
  (3) `0/0` (zero tests executed) is reported as a `passed:0` success-shape. Treat
      "suite staged but executed 0 tests / aborted before report^STDASSERT" as a HARD
      ERROR that surfaces the underlying M abort text, not a silent passed:0.
  Reproduce first (write tests against the engine/runner package — internal/mtest /
  internal/engine): on IRIS, `STDCSPRNGTST` aborts → 0/0, and `STDCOMPRESSTST` aborts
  on m-test-iris (embedded Python). Use these as live fixtures, or fake the engine
  transport to return a 0-test / hung result and assert the runner classifies it
  correctly. Confirm red → green.

ALSO ADDRESS (smaller, same repo):
  • B-3 (P3, flag/command divergence): Go `m lint` rejects `--error-on` (uses
    `--check`); Go `m` has no `m engine` command — but m-stdlib's `make lint` and the
    org CLAUDE.md / m-engine skill use `m lint --error-on=error` and `m engine <verb>`
    (Python-m-cli surface). Either add `--error-on` (+ `engine`) to Go `m`, or, if the
    Python m-cli is the supported CI toolchain and Go `m` is intentionally narrower,
    update the docs (m-engine skill, org CLAUDE.md gate wording) to say so. Pick one
    and make local Go `m` and CI agree; record the decision in the tracker.
  • B-4 (P3): `m kids` → SIBLING_NOT_FOUND (kids-vc), `m list/pull/status/verify/push`
    → SIBLING_NOT_FOUND (irissync). Add an actionable hint ("install kids-vc / irissync
    — see <doc>") and document the sibling-binary dependency so these can be exercised
    locally.
  • B-5 (P3): leaked `docker exec -i m-test-iris … iris session` processes were found
    orphaned (from earlier killed runs). Ensure the runner reaps its docker exec child
    on exit/timeout (overlaps B-1(1)).

VERIFY: `make all` green; new tests cover each B-1 defect (red→green); on IRIS a
hung/0-test suite now yields a clear TIMEOUT/ERROR (not 0/0, not a false stdout ok).
Then Increment Protocol (memory + tracker + commit + push the working branch).
```

---

## Session B — repo: **`m-stdlib`** (START HERE: `cd ~/vista-forge/m-stdlib`)

Paste the fenced block into a fresh session.

```
You are fixing the m-stdlib backlog from the 2026-06-14 dual-engine validation.
START in ~/vista-forge/m-stdlib. Read ~/vista-forge/CLAUDE.md (Increment
Protocol + m/v waterline) and m-stdlib/CLAUDE.md first. M repo: TDD hard rule (write
the *TST.m test first, confirm it fails, implement, confirm green; TDD-red stubs
return safe defaults, never $ECODE), engine in byte mode (YDB `--chset m`), gates
before commit (`m lint --error-on=error` zero findings, coverage gate, drift gates,
make check-manifest). Trackers update in the SAME commit (module-tracker +
discoveries). Increment Protocol per increment; commit + push the working branch
(branch off master first); do NOT merge to master.

Full evidence: docs/tracking/dual-engine-validation-2026-06-14.md (§1 matrix, §5 B-6,
B-2). NOTE the state has moved since that report: B2 (PR #11) is now on master, so
STDCRYPTOTST (23/23) and STDCRYPTODOCTST (1/1) already PASS on IRIS. Re-verify the
current IRIS matrix on master before changing anything.

FIX B-6 remainder (P1 — STDCSPRNG on IRIS). On IRIS, STDCSPRNGTST aborts and runs
0 tests (0/0, exit 3) while it is 406/406 on YDB. src/STDCSPRNG.m has 0 IRIS-engine
probe lines (STDCRYPTO/STDCOMPRESS got a `$zversion["IRIS"` dispatch arm in B2;
STDCSPRNG did not). It already documents a pure-M `/dev/urandom` READ *b fallback —
the abort is almost certainly the YDB `$&`/`$ZF` callout (or its availability probe)
hard-erroring on IRIS before the fallback is reached. Fix: give STDCSPRNG the same
engine-aware dispatch as the B2 modules — on IRIS, skip the YDB `$&` path and use the
portable `/dev/urandom` backend (or an IRIS-native CSPRNG) directly. TDD: add the
IRIS leg to STDCSPRNGTST (or confirm the existing suite runs on IRIS), confirm it
fails (0/0 today), implement the IRIS arm, confirm green on BOTH engines (YDB stays
406/406 byte-exact; IRIS produces n random bytes). Keep byte-faithfulness.

  • STDCOMPRESS-IRIS is NOT in scope here: its IRIS arm exists (B2) but m-test-iris's
    embedded Python is non-functional, so it aborts 0/0 LOCALLY only. Note it as
    "blocked by test-infra — verify on a working-embedded-Python IRIS (vista-iris)",
    do not try to "fix" STDCOMPRESS for the m-test-iris container.

ALSO FIX B-2 (P2 — coverage gate). `m coverage --min-percent=85` passes at 91.1%
AGGREGATE while STDARGS (66%), STDFS (69%), STDHARN (77%), STDCSPRNG (81%) are under
85 — the per-module guarantee in CLAUDE.md/README is not enforced. Also
tests/STDJSONSMOKE.m (0/4) and examples/stdargs-demo.m (0/25) are counted, diluting
the number. Decide + implement: either make the gate per-source-module (matching the
docs) or change the docs to say "aggregate"; and exclude tests/ + examples/ from the
coverage denominator. If you make it per-module, then raise STDARGS/STDFS/STDHARN
coverage (new *TST.m cases, TDD) to clear the gate — or document the exemptions.

VERIFY: STDCSPRNGTST green on BOTH engines; coverage gate behaves per the decision
(no false pass); `m lint --error-on=error` zero, drift gates + check-manifest clean.
Then Increment Protocol (memory + module-tracker + discoveries row + commit + push).
```

---

## Backlog → session map

| Item | Sev | Repo / session | Status now (master, 2026-06-14) |
|---|---|---|---|
| B-1 | P1 | m-cli (A) | open — IRIS runner: no timeout, 0/0 masking, contradictory stdout |
| B-6 | P1 | m-stdlib (B) | **partly resolved by B2 (#11)**: STDCRYPTO/STDCRYPTODOC now green on IRIS; **STDCSPRNG still aborts 0/0** (fix target); STDCOMPRESS-IRIS = test-infra block (out of scope) |
| B-2 | P2 | m-stdlib (B) | open — coverage gate aggregate, not per-module; non-module files counted |
| B-3 | P3 | m-cli (A) | open — `--error-on` vs `--check`; no `m engine` in Go `m` |
| B-4 | P3 | m-cli (A) | open — kids-vc / irissync SIBLING_NOT_FOUND locally |
| B-5 | P3 | m-cli (A) | open — leaked docker-exec iris sessions (reap on exit) |
