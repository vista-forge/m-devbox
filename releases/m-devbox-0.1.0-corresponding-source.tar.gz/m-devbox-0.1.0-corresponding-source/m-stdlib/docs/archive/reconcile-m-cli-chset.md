---
title: Reconcile m-cli #2 — `--chset` byte (M) mode
status: ready
created: 2026-06-14
doc_type: [PROMPT]
for: a fresh single-repo session (m-cli)
repo: m-cli
pr: https://github.com/vista-forge/m-cli/pull/2
branch: engine-chset-byte-mode
---

# Reconcile m-cli #2 — `--chset` byte (M) mode

A stale, **CONFLICTING** feature PR from 2026-05-30 that predates the
VistaEngine/driver work which rewrote `internal/engine`. It is **not** part of
any stabilization sweep — reconcile it on its own, decide if it's still wanted,
rebase, and land (or close) it. Paste the fenced block into a fresh session.

```
Reconcile and land (or close) m-cli PR #2 "engine: add --chset flag for byte (M)
mode on m test/coverage/watch" (branch engine-chset-byte-mode). It is CONFLICTING.

cd ~/vista-forge/m-cli. One session ↔ this one repo ↔ one branch.

READ FIRST:
  • ~/vista-forge/CLAUDE.md (Increment Protocol; the m/v waterline) and m-cli's own README/CLAUDE.
  • m-stdlib/docs/plans/msl-vsl-orchestration-kickoff.md (the orchestration runbook — session/handoff rules).
  • The PR: `gh pr view 2 --repo vista-forge/m-cli` and `gh pr diff 2 --repo vista-forge/m-cli`.

WHAT THE PR DOES:
  Adds an engine-neutral `--chset m|utf-8` flag to `m test`, `m coverage`, and
  `m watch --run`, threaded through `engine.Options.Chset`. Purpose: run byte-
  oriented m-stdlib suites (STDCSPRNG, STDB64, STDHEX, STDJSON UTF-8 decode) under
  `ydb_chset=M`, where one M char == one byte. The shared m-test-engine defaults
  to ydb_chset=UTF-8, which re-encodes byte values >127 and aborts STDCSPRNGTST.

WHY IT CONFLICTS:
  It touches internal/engine/{engine,iris,ydb}.go (+ engine_test.go), which the
  T0.1 VistaEngine + SDK-client-dedupe work rewrote (engine.Options changed, the
  driver-backed transport landed). `engine.Options.Chset` must be re-threaded onto
  the current Options shape and the current ydb/iris runners.

DECISION FIRST (don't blindly rebase):
  1. Is byte-mode still needed, or was the STDCSPRNG/byte issue solved another way
     since 2026-05-30? Check m-stdlib's current STDCSPRNG handling + the CI charset
     story (m-stdlib CLAUDE.md "Engine charset & module tiers" says run ydb_chset=M).
     If the need stands (it likely does — m-stdlib is byte-oriented by design), keep it.
  2. If superseded/obsolete, close the PR with a one-line why. Otherwise → reconcile.

PROCESS (if keeping):
  • Rebase engine-chset-byte-mode onto current main; resolve the internal/engine
    conflicts against the new Options/runner shape (TDD: make the engine_test.go
    assertions pass on the new shape first).
  • TDD-red-first for any new behavior. `make all` green (lint + race-test + build + arch).
  • The arch gate now runs (`m arch check .` / the arch CI job); m-cli is layer m — keep it clean.
  • Increment Protocol: update memory + any tracker note, commit, push the branch; then
    merge the PR (CI green). NOTE: if the m-cli release tag for VSL Phase B hasn't been
    cut yet, landing this BEFORE that tag means the release captures --chset.

VERIFY: `make all` green; ideally a live `m test --chset m --docker m-test-engine`
run shows a byte-oriented suite (e.g. STDB64TST/STDCSPRNGTST) passing under M mode.
```
