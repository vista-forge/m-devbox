---
title: The `v` CLI Platform — MOVED
status: moved
last_modified: 2026-06-25
---

# The `v` CLI — VistA Developer Tools Platform — **MOVED**

> **This spec has graduated to the `v` CLI repo.** Its canonical home is now:
>
> **[`v-cli/docs/v-cli-platform.md`](https://github.com/vista-forge/v-cli/blob/main/docs/v-cli-platform.md)**
>
> It lived here during planning, beside the MSL⟷VSL coordination plan that
> consumed its first domain (`v pkg`). Now that the `v-cli` repo exists and the
> platform foundation is built, the spec lives with the code. This stub remains so
> existing links keep resolving — update references to point at the v-cli repo.

The short governing form of the `m-*`/`v-*` naming scheme and the registry-driven
discipline lives in the org-level [`CLAUDE.md`](../../../CLAUDE.md)
§ *Naming & registry conventions*.
