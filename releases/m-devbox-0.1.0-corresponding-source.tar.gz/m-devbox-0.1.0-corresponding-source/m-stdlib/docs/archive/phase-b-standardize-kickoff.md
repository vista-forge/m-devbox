---
title: Phase B — Standardize the Substrate (kickoff)
status: ready
created: 2026-06-14
doc_type: [PROMPT]
for: a fresh session (starts in m-cli; spans m-cli + .github + a cross-repo sweep)
runbook: m-stdlib/docs/plans/msl-vsl-orchestration-kickoff.md
tracker: m-stdlib/docs/tracking/vsl-implementation-tracker.md
---

# Phase B — Standardize the Substrate (kickoff)

Phase A is complete (all 8 repos' mains canonical, the waterline **G1** gate
enforcing in CI). Phase B makes the org discipline `source-tag → generate →
registry → red-gate` concrete and **self-enforcing**. Paste the fenced block
into a fresh session. The G2 design + the STDSEED decision below were already
scouted (2026-06-14) — don't re-discover them.

```
Execute Phase B (standardize the substrate) of the MSL⟷VSL effort.

READ FIRST:
  • m-stdlib/docs/plans/msl-vsl-orchestration-kickoff.md  — the runbook (Phase B §1; session/handoff rules)
  • m-stdlib/docs/tracking/vsl-implementation-tracker.md  — status (Phase A complete; Phase B next)
  • ~/vista-forge/docs/background/m-v-waterline-adr.md — §3.2 (G1–G5), §3.3 (enforcement/meta-gate)
  • m-cli/internal/arch/arch.go                           — the existing G1 gate you extend
  • ~/vista-forge/CLAUDE.md                            — Increment Protocol + waterline

One session ↔ one repo ↔ one branch. Most work is in m-cli (the gate) + .github (CI). TDD-red-first.

THE 5 PHASE B ITEMS (runbook order):
  1. ONE meta artifact, one location. Standardize on root `repo.meta.json` everywhere.
     m-cli's ResolveLayer already reads it (+ dist/ fallbacks); migrate m-stdlib + v-pkg
     off dist/repo.meta.json / dist/v-contract.json to root, then drop the dist fallbacks
     and have `m arch check` validate the meta's presence/shape.
  2. FINISH THE GATE SUITE in m-cli/internal/arch (+ the same arch-waterline.yml job):
     • G2 — no VistA symbols below the waterline. SCOUTED — build it carefully:
       - MUST be comment-aware: skip M comment content (after `;`), or it false-positives
         on doc examples like STDMOCK/STDFIX's `; doc: @example do …^DIE/^DDL`. (Confirmed:
         a naive grep over m-stdlib/src flags those comments.)
       - The ONE real below-waterline reference in m-stdlib today is STDSEED line ~218
         `do FILE^DIE(...)` (its default filer `fileViaDie`), already carrying
         `; m-lint: disable-next-line=M-MOD-036`. **DECISION REQUIRED before wiring G2**
         (else m-stdlib CI goes red): either (A) ALLOW it — STDSEED's filer is pluggable/
         injectable and FILE^DIE is just the opt-in default; honor a G2 suppression pragma
         or allow-list entry (mirror the existing M-MOD-036 disable); or (B) MOVE the
         default filer to v-stdlib so m-stdlib STDSEED stays pure. Note m-cli already has a
         lint rule M-MOD-036 that detects FileMan calls — consider G2 reusing/aligning with
         it rather than a fresh deny-list.
       - Deny-list seed: ^DIC ^DD( ^DPT( ^VA( ^XUSEC ^DIE ^DIK ^DIQ ^DGPM EN^XPD* ^XUS*.
     • G3 — transport-monopoly: only m-driver-sdk may run a driver binary / build the
       envelope. Forbidden-pattern lint: outside the SDK, no exec.Command(…, "m-ydb"/"m-iris")
       and no hand-rolled envelope; consumers import mdriver.Client.
     • G4 — seam-pin: every engine-reaching repo pins a TAGGED m-driver-sdk (no replace).
       Gate by inspecting go.mod. (v-cli already complies — pins v-pkg v0.1.0, no replace.)
  3. THE META-GATE (the keystone — ADR §3.3.4). A scheduled org job (cron over the GitHub
     API, in .github) that walks every vista-forge repo and asserts each: declares a
     valid `layer`, calls arch-waterline.yml, is present in an ecosystem registry. A repo
     missing any → red. This is what turns the standard from convention into a gate.
  4. ONE reusable CI per language: add .github `m-ci.yml` (fmt/lint/test/coverage + arch,
     modeled on m-stdlib's hand-rolled CI) so every M repo (m-stdlib, v-stdlib, future)
     gets an identical pipeline from one line. Also FINISH the Phase-A finding: the go-ci
     schema-check assumes m-cli's `schema` command — either every Go caller declares
     `schema-check: false` where appropriate (m-driver-sdk/m-ydb/m-iris already do), or the
     drivers grow a real `schema` verb (preferred for consistency).
  5. PIN THE SEAM DETERMINISTICALLY: tag an m-cli release; set arch-waterline.yml's
     `m-cli-ref` default to that tag (not floating main), so CI stops drifting under m-cli's
     main. If m-cli #2 (--chset) is still wanted (see reconcile-m-cli-chset.md), land it
     BEFORE this tag so the release captures it.

RULES: TDD-red-first (internal/arch tests like the G1 ones); `make all` green incl. arch;
each gate must be red-on-a-planted-violation AND green otherwise; reusable workflows live on
.github main (branch→PR→merge); run the Increment Protocol per repo (memory + tracker, commit,
push). The meta artifact change + each new gate updates the tracker in the same commit.

THEN: Phase C = T0b.3 (the four drift gates + `seams` block) on the standardized substrate.
```
