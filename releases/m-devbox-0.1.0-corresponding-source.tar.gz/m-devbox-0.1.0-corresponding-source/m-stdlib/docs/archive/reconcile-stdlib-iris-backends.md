---
title: Reconcile m-stdlib #1 — IRIS-native backends (STDCRYPTO/STDCOMPRESS/STDHTTP)
status: ready
created: 2026-06-14
doc_type: [PROMPT]
for: a fresh single-repo session (m-stdlib)
repo: m-stdlib
pr: https://github.com/vista-forge/m-stdlib/pull/1
branch: iris-native-backends
---

# Reconcile m-stdlib #1 — IRIS-native backends

A stale, **CONFLICTING** feature PR from 2026-05-31 that predates the entire
s9–s12 IRIS-portability sweep now on master. It is **partially superseded** (its
STDOS engine-detect seam collides with master's STDOS IRIS port) but its core
payload — IRIS-native backends for the three optional modules — is **still novel
and wanted**. Reconcile against the landed work; don't blindly merge. Paste the
fenced block into a fresh session.

```
Reconcile and land m-stdlib PR #1 "B2: IRIS-native backends for STDCRYPTO /
STDCOMPRESS / STDHTTP" (branch iris-native-backends). It is CONFLICTING and
PARTIALLY SUPERSEDED — reconcile it against the IRIS work already on master.

cd ~/vista-forge/m-stdlib. One session ↔ this one repo ↔ one branch.

READ FIRST:
  • m-stdlib/CLAUDE.md — esp. "Engine charset & module tiers" (the 3 OPTIONAL modules
    STDCOMPRESS/STDCRYPTO/STDHTTP need compiled call-out libs; `make test-optional`
    runs their suites) and the dist/ Guardrails (regenerate, NEVER hand-edit).
  • docs/tracking/vsl-implementation-tracker.md progress log (s9–s12) + docs/memory/
    — how IRIS portability was actually done on master: `$ZVERSION["IRIS"` arms,
    try/catch (irisRaises), xecute-built dispatch (no arg indirection), $ZTIMESTAMP
    clock, STDFS facade, the full STDOS IRIS port. The PR must FOLLOW these idioms.
  • The PR: `gh pr view 1 --repo vista-forge/m-stdlib` and `gh pr diff 1`.

WHAT'S STILL NOVEL vs SUPERSEDED (verify against current master, don't assume):
  • SUPERSEDED: the PR adds its own `$$engine^STDOS()` engine-detect seam, but master
    ALREADY has STDOS fully IRIS-ported (s12) with its own engine detection. DROP the
    PR's duplicate seam; use master's existing STDOS engine helper.
  • STILL NOVEL/WANTED: master's STDCRYPTO has NO IRIS arm (`grep -i iris src/STDCRYPTO.m`
    → none); same for STDCOMPRESS/STDHTTP. The PR's actual value is the IRIS-native
    backends for these three (e.g. STDCRYPTO → $SYSTEM.Encryption.SHAHash/.HMACSHA;
    STDCOMPRESS/STDHTTP IRIS arms). KEEP these, rebased onto master's engine seam.

ARCHITECTURE INVARIANT (do not violate):
  One .m per module — the IRIS arm is an else-branch in the existing dispatch helper,
  NEVER a second source file. The YDB `$&pkg.fn` path stays first; the IRIS branch is
  added ahead of it behind the engine seam.

PROCESS:
  • Rebase iris-native-backends onto current master; resolve src/STD*.m conflicts by
    KEEPING the 3 backends and DROPPING anything master already provides (the STDOS
    seam, any STDASSERT change s9 already landed).
  • Do NOT resolve conflicts in generated artifacts by hand — after the src/ is right,
    REGENERATE: `make manifest` (→ dist/stdlib-manifest.json, errors.json), `make skill`
    (→ dist/skill/*), `make doctest`. Then the dist/ conflicts are moot. (dist/ guardrail.)
  • TDD: the *TST.m suites must pass on BOTH engines. These are OPTIONAL modules →
    `make test-optional` (needs libz/libcrypto/HTTP backend); run on YDB (m-test-engine)
    AND IRIS (m-test-iris). Byte-exactness matters (STDCRYPTO digests are raw bytes).
  • Trackers update in the same commit (module-tracker row + discoveries if anything new).
  • `make check` green; `m arch check .` clean (layer m — no ^VSL* refs). The arch CI job runs.
  • Increment Protocol: memory + tracker, commit, push; then merge the PR (CI green).

VERIFY: STDCRYPTOTST/STDCOMPRESSTST/STDHTTPTST green on BOTH engines via
`make test-optional` (+ the docker IRIS path); dist/ regenerated + drift-gated clean.
```
