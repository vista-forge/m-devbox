---
name: stdjson-iris-ecode-entry-clear
description: STDJSON parse() now entry-clears $ECODE (P1 IRIS stale-$ECODE poison fix) + the IRIS-only test-poison gotcha
metadata:
  type: project
---

P1 STDJSON-on-IRIS `$ECODE`-poisoning bug (discoveries.md 2026-06-21) is
**resolved** on branch `stdjson-iris-ecode-discovery`.

**Root cause:** `parseObject`/`parseArray` drive their member loops with
`for  quit:done!($ecode'="")  do`. A *caller's* stale non-empty `$ECODE` on
entry to `$$parse^STDJSON` made the loop bail right after the opening `{`/`[`,
so a valid document parsed as empty or as "trailing garbage" on IRIS. Stale
`$ECODE` leaks across calls in a long-lived process (a prior fenced/trapped op).

**Fix (entry-clear, minimal diff):** `set $ecode=""` as the first action in
`parse(text,root)` — ahead of the `if $zversion["IRIS" quit $$irisParse(...)`
branch and the YDB `$etrap` setup — plus the same at `parseFile()` entry (it
reads `$ECODE` after `readFile` to detect a read failure, which a stale inbound
value would falsely trip). In-parse semantics preserved: `raise()` still sets
`$ECODE` mid-parse to unwind the loops. `valid()`/`validate()` route through
`parse()`, so they inherit the fix for free.

**Test gotcha — the IRIS poison must be `$zversion`-guarded.** The deterministic
poison is `xecute "try { set zz=1/0 } catch e { }"` (ObjectScript try/catch that
swallows the error WITHOUT clearing `$ECODE`, exactly how the bug arises). It is
**NOT a no-op on YDB** — `try` is not valid M there, so an unguarded xecute
raises `<SYNTAX>` and **aborts the whole suite (runner shows 0/0)**. Guard it
`if $zversion["IRIS" xecute "..."`. There is no trap-free way to leave `$ECODE`
set on YDB (setting it non-empty fires the trap), so on YDB the regression test
(`tParseClearsStaleEcode`, 7 assertions) just verifies the happy path; the YDB
`parse()` path is less exposed but the same entry-clear protects it. Confirmed
RED on IRIS (7 fail) pre-fix, GREEN dual-engine (216/216) post-fix.

**Manifest drift is expected here:** the comment lines added to `src/STDJSON.m`
shifted `source.line` numbers in `dist/stdlib-manifest.json`, so `make manifest`
legitimately regenerates it even though no `; doc:` content changed — commit the
regenerated artifact (`make check-manifest` is just `git diff --exit-code`).

**Cross-repo follow-up (NOT done here):** once this merges, v-web can drop its
defensive `set $ecode=""` in `VWEBT.fidelity()` (branch `phase4-traffic-console`)
— harmless until then.
