---
name: go-m-runner-and-live-cadence
description: The Go `m` test runner is a LEAN suite-runner (no Python-m-cli auto-wiring — no --seed/--env/--timings/--update-snapshots/--changed/--filter/--no-isolation/FILE::tLabel); helper modules are called in-suite. Plus the post-E4 operational facts the docs now reflect — the iris-portability CI target, the LOCAL nightly live-examples cron, and the greenfield-rewritten docs/guides.
metadata:
  type: project
---

# Go `m` test runner reality + post-E4 operations (2026-06-24)

Captured while greenfield-rewriting `docs/guides/` (quick-start, m-tdd-guide,
users-guide, m-doc-grammar, comprehensive-testing) to a clean current-state slate
(history only in a bottom section). The durable, non-obvious facts:

## The Go `m` test runner is LEAN — not the Python m-cli

`m test` is a thin suite-runner over the driver stack. Verified against
`m test`/`m coverage --help` AND the m-cli Go source (no grep hits for
STDFIX/clear^STDMOCK/STDSEED/seed/env/timings/snapshots/changed). It does **NOT**
auto-wire per-test isolation, mock-clearing, seeding, env, snapshots, or timings —
those `--seed` / `--env` / `--timings` / `--update-snapshots` / `--changed` /
`--filter` / `--no-isolation` / `FILE::tLabel` flags were the **Python m-cli** and
are GONE. The actual `m test` flags: `-o`, `--engine`, `--docker`, `--routines`,
`--namespace`, `--chset`, `--resident`, `-v`. `m coverage` adds `--min-percent`
(aggregate line, exit 3) + `--lcov`.

**Implication for tests + docs:** a suite does its OWN setup/teardown — bracket
mutations in `tstart`/`trollback` (or `invoke^STDFIX`), call `clear^STDMOCK`
between tests, `load^STDSEED` / `parseFile^STDENV` in setup — the helper modules
(STDFIX/STDMOCK/STDSEED/STDSNAP/STDPROF/STDENV) are ordinary in-suite library
calls, not runner magic. Run a subset by passing the suite path. The old guides
documented the Python runner's richer surface; that was the bulk of the rewrite.

## iris-portability CI runs `make examples-run-iris`, NOT `make test`

`make test` (full core suite) reds on **any** IRIS — curated `m-test-iris` AND a
fresh `iris-community` (both exit 3) — because `STDCSPRNGTST` aborts `0/0`:
**STDCSPRNG is YDB-only** (entropy via a YDB `$ZF` getrandom call-out + YDB
`/dev/urandom` device I/O; no IRIS backend). So the fail-soft IRIS job targets the
`@exrun`-scoped, IRIS-safe `examples-run-iris` (which skips the YDB-only modules)
→ a meaningful green instead of a known-red. (m-stdlib ci.yml `iris-targets`.)

## The nightly LIVE examples cadence runs from a LOCAL cron, not GitHub

`vehu`/`foia` are local to minty, reachable only through the driver stack, so the
`.github` `examples-live.yml` needs a self-hosted runner (none registered) — it is
**`workflow_dispatch`-only**. The actual nightly cadence is a system cron at
**04:00**: `~/scripts/bin/examples-live-cron.sh` loops both repos, runs
`make examples-run-live` (live tier + the §8 residue check), and commits+pushes
`examples/REPORT.md`. Headless push works **without a PAT** — gh's keyring token is
readable on minty even under a bare/no-D-Bus environment (verified); the wrapper
still supports a `GH_TOKEN` in `~/.config/examples-live.env` as a fallback.
The main CI (`ci.yml`, both repos) gained `workflow_dispatch` for manual reruns.

## The live MSL *suite* tier (QC-B) — engine VERSION is a real axis (2026-07-07)

The nightly live cadence originally ran only *examples* (`REPORT.md`), so the
`tests/STD*TST.m` **suites** were exercised only on the BARE engines
(`m-test-engine` + `m-test-iris`) in CI. That is a coverage hole: a suite can be
green on bare YDB (r2.07) and IRIS yet **red on live vehu (YDB r2.02)** —
STDJSONTST fails 2 assertions there (`parse ok`, `empty key -> v`). Engine
*version* is a genuine behavioural axis; nothing that ran on bare-only could
catch it.

**QC-B closes it.** `make live-qc` (`tools/run-live-qc.py`) runs the suites on the
live engines through the driver stack and writes `examples/LIVE-QC.md`. Durable
facts that will still be true next increment:

- **Record engine identity in the artifact.** Captured via
  `M_<ENGINE>_CONTAINER=… m vista exec --engine … --transport docker` — `write
  $zyrelease` (YDB) / `write $zversion` (IRIS). `m vista exec` reads the
  container/namespace from `M_<ENGINE>_*` **env**, NOT `--docker`/`--namespace`
  flags (unlike `m test`). A silent engine upgrade must show up as a **diff in
  the committed identity table**, not a mystery red — that pairing is the first
  diagnostic when a new red appears.
- **vehu optional-tier is a DECLARED WAIVER (F5), never a silent skip.** The
  callout `.so`s (libz/libzstd/libcrypto) aren't deployed on the live YDB-VistA
  engine, so the optional suites are listed + counted as waived on `ydb-live`.
  foia (IRIS) runs the **full** optional tier green (IRIS-native backends — see
  [[iris-native-backends]]); STDCSPRNGTST/STDHARNTST run green on **live** foia
  even though STDCSPRNG is "YDB-only" (the 0/0 abort is a *bare* `m-test-iris`
  limitation, not live foia — do not pre-waive them on iris-live).
- **Fail-soft; the Makefile owns the CORE/OPTIONAL split.** `make live-qc` always
  exits 0 (a red is a committed diff in LIVE-QC.md; the bare CI tier stays the
  hard gate). The tool takes `--core-suites`/`--optional-suites` from the
  Makefile (same lists `make test` uses) so the tier split can't drift.
- Wired into `examples-live-cron.sh` before the examples step (guarded by
  `make -n live-qc` so v-stdlib, which lacks the target, skips it). Proposal:
  central `docs` repo `proposals/continuous-live-qc-harness.md` §Design 2.

See [[durable-gotchas]] (the runner + @exrun/@exsafe + residue design) and
[[engine-access-through-driver-stack]].
