---
name: grammar-spec-from-code-gate
description: The M-doc tag grammar is now generated from a single registry (mdoc_tags.py) the generator also derives KNOWN_TAGS from — drift-gated by check-grammar. Closes the doc-vs-code drift loop.
metadata:
  type: project
---

# Grammar spec-from-code gate (DONE)

> **Registry home moved (stdlib-doc-accuracy Phase 7, 2026-07-19):** the
> `tools/mdoc_tags.py` this note describes is retired — the registry is now the
> shared `tools/mdoc/tags.py` (16 common tags) + each repo's
> `tools/mdoc_config.py` `extra_tags` (m: `@tag`/`@phase`; v:
> `@mutates`/`@dispatch`/`@file`), merged by `mdoc.core.configure()`. The gate
> architecture below is otherwise unchanged (gen-grammar renders the merged m
> view; registry ≡ generator still holds by construction).

**DONE 2026-06-24**, m-stdlib `master` + v-stdlib `main`. Plan:
`docs/archive/grammar-spec-from-code-gate-plan.md`. Closes the doc-vs-code drift
that [[docs-governance-regime-b]] surfaced (the grammar's "Nine tags" had drifted
to eleven in `gen-manifest.py`).

**What.** The M-doc tag grammar's §5 tag reference is now **generated from a
single registry the generator also consumes**, so the spec can't drift from the
code.

**Architecture (registry-as-single-source-of-truth):**
- **`tools/mdoc_tags.py`** — the registry: **16** `Tag` dataclasses (name, level
  label|module, multiplicity, body_syntax, manifest_field, synopsis, example) as
  of 2026-06-24 — 9 JSDoc-shaped label tags + 7 org extensions (`@seam`, `@tier`,
  `@fixture`, `@illustrative`, `@raisesnodemo`, `@exrun`, `@exsafe`; the
  living-examples set grew it from the original 11).
  A **byte-identical sibling** in both stdlibs (the grammar is engine-neutral).
- **`gen-manifest.py` derives `KNOWN_TAGS` from it** (`mdoc_tags.label_tags()`),
  replacing the hardcoded literal set → registry ≡ generator by construction. The
  refactor is **behaviour-preserving**: the manifest + golden + `manifest-check`
  are byte-unchanged in both repos (the proof). Per-tag body parsers stay
  hand-coded (registry owns the SET + doc metadata, not the parsing).
- **`gen-grammar.py`** (m-stdlib only) renders a delimited
  `<!-- BEGIN GENERATED TAG TABLE -->` block in §5 of `m-doc-grammar.md` from the
  registry (gen-bodies pattern; hand prose §5.1–5.N preserved). `make grammar`
  regenerates; **`grammar-check`** (`make grammar-check`, in `gates` + `ci.yml`)
  red-gates: (a) stale table, (b) registry tags ≠ the §5.N prose-subsection
  headers, (c) registry label-tags ≠ `gen-manifest.KNOWN_TAGS`; and WARNS
  (non-gating) on an unknown `@tag` in `src/*.m` (typo catch).

**Homes:** registry + the gen-manifest refactor in BOTH repos; gen-grammar + the
gate + the grammar doc in m-stdlib only (v-stdlib keeps its grammar pointer).

**Non-obvious:**
- gen-manifest.py is loaded both directly and via `importlib` (golden test,
  gen-grammar); `sys.path.insert(0, <tools dir>)` before `import mdoc_tags` makes
  the registry importable in every load path.
- The gate's (c) check `importlib`-loads gen-manifest.py to read its live
  `KNOWN_TAGS` — guards against a future refactor re-hardcoding the set.
- RED-proof verified: adding a tag to the registry without a §5.N prose
  subsection → `grammar-check` red on (a)+(b).
- `@tier` is module-level (registry `level="module"`); `@icr/@source/@call/
  @status/@custodian` are deliberately NOT in the registry (a separate concern —
  gen-icr / check_citations) and listed in the gate's exception set.
- **GOTCHA — the gate does NOT cover the §5 *intro* narrative count.** It gates
  the generated table (a), the §5.N prose-subsection headers (b), and KNOWN_TAGS
  (c) — but the prose sentence "Sixteen tags: nine ... plus seven extensions" at
  the top of §5 is hand-written and ungated, so it silently drifted to "Fourteen
  ... five" after `@exrun`/`@exsafe` landed while `grammar-check` stayed green
  (fixed 2026-06-24, commit on `master`). When adding/removing a tag, update that
  intro sentence (and the §1.2 + scope-note counts) by hand — the gate won't
  catch them.

**Gates:** grammar-check, manifest-check, frontmatter-check, docs-bodies-check,
docs-check all green; docs-validate 0 errors; idempotent.

This is the durable fix for [[docs-governance-regime-b]]'s "Lesson" (a canonical
spec hand-maintained beside its generator drifts) — a concrete instance of
generated, drift-gated canon.
