---
name: m2-stdnet-socket-seam
description: VSL/MSL M2 Lane A — STDNET, the portable raw-TCP socket leaf (S4 seam). Loopback echo GREEN 22/22 on BOTH engines; @seam STDNET (6 entry points, bump-forcer green); optional tier. IRIS leg DONE (M2.T1, v0.12.0, master 2026-06-17). IRIS RAW-READ CRLF FIX DONE (v0.12.1, master e0e6192/tag v0.12.1, 2026-06-17): readIris byte-at-a-time read *c:t (was CR-terminated read x#n:t which stripped CRLF → broke HTTP framing on IRIS). IRIS PEER-CLOSED READ FIX DONE (v0.12.2, branch stdnet-iris-peerclosed-read, 2026-06-17): readIris drain loop now runs under an ObjectScript try/catch so a read on a peer-closed socket drains buffered bytes then EOFs instead of an uncatchable <DSCON> killing the job; YDB unchanged. Seam unchanged both. VSLIO binds it; tag v0.12.2 owed (USER action); unblocks v-web M6.3 IRIS read-back.
metadata:
  type: project
---

# STDNET — the portable socket leaf (VSL/MSL M2 Lane A, 2026-06-16)

The leaf-first MSL half of **M2** (the `VSLIO` socket/TLS seam, S4) — the most
engine-sensitive module in the effort (R1). Branch `m2-stdnet` off `master`.
`STDNET` is a thin, handle-based, **raw-byte** TCP API over each engine's
**native socket device** (no C call-outs), which `VSLIO` (v-stdlib) will bind to
`^%ZIS`/`CALL^%ZISTCP` above the waterline. **Loopback echo GREEN 9/9 on BOTH
engines** — the YDB leg (2026-06-16) and the IRIS leg (M2.T1, landed to `master`
2026-06-17, see below).

## API (the `@seam STDNET` contract — 6 verbs + 2 helpers)
`$$available()` (1/0 capability) · `$$listen(port)`→handle · `$$boundport(id)` ·
`$$accept(id,timeout)`→conn · `$$connect(host,port,timeout)`→handle ·
`$$read(id,maxlen,timeout,.buf)`→count · `$$write(id,buf)`→1/0 · `$$close(id)`→1.
Per-handle state in `^STDLIB($job,"stdnet",id,*)` (no null subscripts). The six
side-effecting verbs carry `; doc: @seam STDNET` → `seams.STDNET` in
stdlib-manifest.json + seam-snapshot.json; **bump-forcer green** (NEW seam).

## The YottaDB socket idiom (hard-won — these were the bugs)
- **`accept` = `WRITE /WAIT`, which AUTO-ACCEPTS.** There is NO separate
  `WRITE /ACCEPT` — calling it raises **`%YDB-E-LOCALSOCKREQ, LOCAL socket
  required`**. After `/wait`, the new connected socket's handle is
  **`$PIECE($KEY,"|",2)`** (`$KEY`=`CONNECT|h…|::ffff:127.0.0.1`).
- **Single-process loopback works on YDB** because the GT.M/YDB `SOCKET` device
  is a *collection of sockets*: the listener device holds the listening socket
  AND (after `/wait`) the accepted one; `USE dev:(socket=h)` switches between
  them. Listener + client are two devices in one process; no `JOB` needed.
- `listen`: `OPEN dev:(listen="0:TCP":delimiter=""):2:"SOCKET"`, `WRITE /listen(1)`,
  bound port = `$PIECE($KEY,"|",3)` (`LISTENING|h|port`). `delimiter=""` = raw bytes.
- Every verb saves/restores `$IO` (`set pio=$io … use pio`) so it never disturbs
  the caller's device — **critical** or the test runner's output capture breaks.
- `write`/`close` are **functions** (`quit 1`) → callers MUST use `$$`, not `do`
  (a `do write^STDNET(…)` raises `NOTEXTRINSIC … argument not allowed`).

## Debugging the test runner (reusable technique)
`m test --docker` **swallows engine errors AND assertion messages** → a raised
error shows as a bare **`0/0` abort** (`tier:"pure-logic"`, `ok:false`), not a
diagnostic. To see the real `$ZSTATUS`: the m-test-engine container mounts
**`~/m-work → /m-work`**, so a suite can `OPEN "/m-work/x.txt":(newversion) … WRITE
$zstatus` and you read it on the host. CAVEAT: an `$ETRAP` that `goto`s a label in
the *test* routine fails when the error fires inside a *called* routine
(`LABELMISSING` / `QUITARGREQD` / `NOTEXTRINSIC`) — **qualify the goto**
(`goto le^STDNETTST`) and beware it masks the original error if it unwinds an
extrinsic. (A `0/0` is also produced by a plain compile error — e.g. a missing
label referenced in a sibling `@TEST` body fails the WHOLE routine to load.)

## Tiering, gates, lint
- **`@tier optional`** (Makefile `OPTIONAL_MODULES`/`OPTIONAL_SUITES` += STDNET/
  STDNETTST): engine-sensitive + partial-engine, so excluded from core
  `make test`/aggregate coverage; runs under `make test-optional`. IRIS soft-skip
  keeps it green dual-engine without faking.
- **`; m-lint: disable-file=M-MOD-024`** in the header — the analyser reads the
  SOCKET-device OPEN/USE deviceparameters (`listen=`/`connect=`/`delimiter=`/
  `socket=`) as local-var reads-before-def (same false positive STDJSON/STDHTTP
  suppress). Avoid 4-commands-on-a-line (M-MOD-009).
- `m arch check` layer **m** clean (**G2: no VistA symbols** — STDNET is
  engine-neutral, the whole point). All regenerated: manifest/skill/doctest/
  seams/namespaces/frontmatter + `docs/modules/stdnet.md` + module-tracker row 34.

## IRIS leg — DONE (M2.T1; landed to `master` 2026-06-17)
(Counts here were 9/9 at M2.T1; the v0.12.1 CRLF regression brings the suite to
**16/16 dual-engine** — see the v0.12.1 section below.)
`$$available^STDNET()` now returns **1 on both engines** and `STDNETTST` runs the
full loopback **9/9 on m-test-iris** (was a 2/2 soft-skip); YDB still 9/9.
Implemented on branch `m2t1-stdnet-iris` (2026-06-16), landed onto current
`master` (post-M6.1/M6.2) by taking `src/STDNET.m` + `docs/modules/stdnet.md`
and re-authoring the v0.12.0 bookkeeping (the branch predated M6.1/M6.2, so a
straight merge would have conflicted on the doc files — `git merge` is also
permission-gated here). Hard-won IRIS TCP facts (behind the `$ZVERSION["IRIS"`
fork; no change to the YDB path):
- **Each handle is its own `|TCP|n` device** (IRIS has no collection-of-sockets
  device); `dev(id)` = `"|TCP|"_id` on IRIS vs `"stdnetsk"_id` on YDB.
- **Listener** = `OPEN dev:(:port:"AM"):2` — empty host, port (0 ⇒ ephemeral),
  mode **`A`** (accept, non-blocking) + **`M`** (stream). The `JOB`'d connector
  turned out **not needed** — single-process loopback works because accept mode
  is non-blocking.
- **`accept`** = one `READ` on the listener (returns `""` the instant a client
  connects); the **listener device then IS the connection**. `WRITE *-3` flushes;
  the `LocalPort()` query is `xecute`-hidden so the YDB compiler never sees the
  IRIS-only intrinsic.

## IRIS raw-read CRLF fix — DONE (v0.12.1; branch `stdnet-iris-rawread-crlf` `0e501fe`, 2026-06-17)
The IRIS M2.T1 leg shipped a **latent CR-termination defect** in `readIris`,
caught by v-web M6.3 the first time real HTTP went over an IRIS socket (the
loopback suite only sent terminator-free "ping").
- **Root cause:** `read x#maxlen:timeout` on a `|TCP|` device is **CR-terminated**
  — it stops at the first CR (char 13) and **strips the CRLF**. So binary/HTTP
  data carrying `\r\n` was corrupted; `$$serve^STDHTTPD` never found the
  `\r\n\r\n` request terminator and returned **400** over an IRIS socket. (Probe:
  write a 16-byte `GET /x\r\nH: y\r\n\r\n`, `$$read` returned only the 6 bytes
  `GET /x`.) **YDB's `read x#n:t` is already raw** — no YDB change.
- **Fix (IRIS arm only, behind `$ZVERSION["IRIS"`):** `readIris` now reads
  **one byte at a time** with `read *c:t` (a single-character read that **never
  interprets a terminator**; returns the byte code or **-1** on timeout/EOF) and
  accumulates into `buf` up to `maxlen`. First byte waits up to `timeout`;
  follow-on bytes use a **zero timeout** so it drains only currently-available
  bytes (matches the raw-bytes "return what's available up to maxlen" contract).
  Considered open/parameterizing the device for no-terminator fixed-length reads,
  but byte-at-a-time is the simplest exact round-trip incl. CR/LF/NUL.
- **`acceptIris` left as-is:** its `read x#256:timeout` on the listener returns
  `""` the instant the connection is accepted (before any data), so it's an
  accept-signal read, not a data read — no CR-termination exposure there.
- **No contract change** — same six `@seam STDNET` verbs/signatures; bump-forcer
  & `make check-seams` green (5 seams, no `contract_version` bump). Behavior fix.
- **Regression:** new `tCrlfByteExact` in `STDNETTST` — writes
  `GET /x\r\nH: y\r\n\r\n` + a lone CR + a lone LF, reads in an accumulate-loop
  (`for quit:('n)!(len reached) do … read`), asserts byte count + full string +
  `$ascii` per position. **Red-first: FAILED on IRIS 13/16, passed YDB 16/16
  before the fix; now GREEN 16/16 on BOTH** (`m-test-engine` YDB byte-mode +
  `m-test-iris`). The accumulate-loop avoids the M-MOD-024 read-before-def lint
  error (pre-init `n=1`, single `quit:` condition avoids M-MOD-009).

## IRIS peer-closed read fix — DONE (v0.12.2; branch `stdnet-iris-peerclosed-read`, 2026-06-17)
The SECOND IRIS socket gap, unmasked once v0.12.1 let v-web's IRIS serve tests
run (GAP 2 in `v-web/docs/memory/stdnet-iris-crlf-rawread-gap.md`).
- **Root cause:** on IRIS, `$$read^STDNET` against a socket whose **peer has
  already `$$close`d** raises an IRIS `<DSCON>`-class **disconnect that KILLS the
  job** — it is NOT a flag-`$ETRAP`-catchable M error (flag-`$ETRAP`/`$zstatus`
  do not catch IRIS disconnects), so the whole suite aborts to **0/0** — instead
  of yielding the buffered bytes then EOF. **YDB already drains + EOFs — no YDB
  change.** Breaks the normal HTTP-client read-back (after the server's
  `Connection: close`, the client read hits a peer-closed socket).
- **Fix (IRIS arm only, behind `$ZVERSION["IRIS"`):** `readIris` now runs its
  byte-at-a-time `read *c:t` drain loop **under an ObjectScript `try { … } catch
  { }`** — the SAME disconnect-trap idiom `invoke^STDHTTPD` uses for IRIS faults
  (`xecute "try { … } catch ex { … }"`). On `<DSCON>` the catch swallows the
  fault, the loop exits, and the call returns whatever was already buffered then
  `0`/EOF. The loop body is byte-identical to v0.12.1 (CRLF-safe); only the trap
  is added, and the whole loop is `xecute`-hidden so the YDB compiler never sees
  the ObjectScript braces (YDB reaches `read()`'s own arm, never `readIris`).
  **Drain-then-EOF confirmed empirically:** the buffered "bye" is read
  byte-by-byte (each `read *c` succeeds) and only the post-drain read faults →
  caught → bytes preserved.
- **No contract change** — same six `@seam STDNET` verbs/signatures;
  `make check-seams` green (5 seams, no `contract_version` bump). `dist/`
  unchanged by the regenerate (no new `@doc` tags). Behavior fix.
- **Regression:** new `tPeerClosedDrainsThenEof` in `STDNETTST` — peer writes
  "bye" then `$$close`s; the read side accumulates until a read returns 0, asserts
  it got "bye" then a further read returns 0 (EOF) **without aborting**.
  **Red-first: ABORTED to 0/0 on IRIS, passed YDB 22/22 before the fix; now GREEN
  22/22 on BOTH** (`m-test-engine` YDB byte-mode + `m-test-iris`).

## What's owed (release)
- **Tag MSL `v0.12.2`** (USER action) — a **patch** bump on v0.12.1 (pure bugfix,
  no API change). `v0.12.1` is git-tagged at `e0e6192` (PR #18 merge, the CRLF
  fix), so this peer-closed fix lands on top → patch. After the tag, **v-web
  repins MSL `@v0.12.2`** and drops the `'$zversion["IRIS"` arm of its static
  `readbackSafe()` gate in `tests/VWEBLTST.m` (a separate v-web action, NOT this
  session) → `tServeHealthOverSocket` read-back goes GREEN on IRIS → M6.3 serve
  vertical fully dual-engine.
- (v0.12.1 — the CRLF fix — already tagged `e0e6192`; v-web already repinned to it.)
- Real TLS sockets stay infra-blocked (M2.T2 — no cert/XU*8.0*787; IRIS-only);
  the `DEFAULT TLS SERVER CONFIG` param def is provisioned on vehu+foia-t12
  (docs `vsl-msl/testinfra/`).

Next: user tags v0.12.2 → v-web drops the static read-back gate + repins → M6.3
IRIS read-back (and the whole serve vertical) goes green dual-engine.
