---
name: waterline-g1-gate
description: The m/v waterline G1 dependency-direction gate (`m arch check`) — how layer is declared, the dist/-gitignore gotcha, and the v-cli registry-regen dependency.
metadata:
  type: project
---

The m/v waterline **G1 gate** (ADR `docs/background/m-v-waterline-adr.md` §3.2,
the "land first" gate) was built 2026-06-13 (s12): `m arch check` in m-cli
(`internal/arch`, branch `arch-waterline-g1`). G1 = dependency-direction:
`v → m` allowed, `m → v` forbidden. For an `m`-layer repo it runs two arms —
Go dep closure (`go list -deps -json` → fail on any `vista-forge/v-*`
module) and an M-source scan (`.m` files for `^VSL*` references). A `v`-layer
repo passes trivially. Exit 3 + violation list on any m → v edge.

**Non-obvious — where the `layer` tag lives differs per repo (heterogeneous).**
`ResolveLayer` looks in priority order: `dist/repo.meta.json`,
`dist/v-contract.json`, then **root `repo.meta.json`**, then a `--layer`
override.
- m-stdlib + v-pkg **commit `dist/`** (drift-gated artifacts) → tag lives in
  `dist/repo.meta.json` / `dist/v-contract.json`.
- **m-cli's `dist/` is gitignored** (`/dist/`), so its layer tag had to live in
  a NEW **root** `repo.meta.json` (m-cli had no committed meta artifact at all
  before this). Any future Go tool repo with a gitignored `dist/` needs the same
  root-level meta.

**m-stdlib `make check-manifest` does NOT schema-validate `repo.meta.json`** — it
only asserts the file is tracked + clean. So adding `"layer": "m"` was safe;
remember to bump `verified_on` (guardrail).

**v-cli registry regen has a hidden dep.** `dist/v-registry.json` aggregates
v-pkg's contract via a dev `replace => ../v-pkg`. When v-pkg's `pkgcli` gained
the lifecycle verbs (install/verify/uninstall) it started importing
`mdriver.Client` from `m-driver-sdk` — so regenerating the registry in v-cli
first needs `go mod tidy` (airgapped: `GOPROXY=file://…`) to pull
`m-driver-sdk v0.3.0` into v-cli's module graph, else `make registry` fails
`missing go.sum entry`.

**All 8 ecosystem repos are now tagged (s12):** m-cli/m-stdlib/m-driver-sdk/
m-ydb/m-iris = `m`; v-pkg/v-cli/v-stdlib = `v`. The 5 later ones each got a
**root `repo.meta.json`** (the layer is a repo property — deliberately NOT in
v-pkg's generated `dist/v-contract.json` or v-cli's aggregate
`dist/v-registry.json`; `ResolveLayer` falls through to root). The 3 `m` repos
gate clean on the Go arm; the `v` repos pass trivially. **CI enforcement WIRED (s12):** the reusable
`.github/.github/workflows/arch-waterline.yml` (ADR §3.3.2) runs `m arch check`
in any repo (one-line `arch:` caller). All 8 repos call it; verified green on
real CI (v-stdlib v-layer + m-cli Go-arm). **Two CI gotchas:** the workflow
must build `m` via `git clone --branch ${ref}` + `go build` — NOT
`go install …@main`, because the Go proxy caches the `@main` branch→commit
resolution and lags a fresh m-cli merge ~30 min (would build a stale `m`
without `arch check`). And v-cli's dev `replace => ../v-pkg` would break the
Go-arm's `go list` in CI — harmless only because v-cli is layer v (arch skips
the Go arm). v-stdlib scaffold (T0b.1) is done. See
[[msl-vsl-coordination-plan]] and the VSL tracker
(`docs/tracking/vsl-implementation-tracker.md` § s12).
