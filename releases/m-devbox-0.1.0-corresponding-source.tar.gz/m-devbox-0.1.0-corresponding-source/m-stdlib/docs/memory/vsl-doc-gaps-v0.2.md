---
name: vsl-doc-gaps-v0.2
description: How the VistA Standard Library architecture doc's §12 VDL gaps resolved in v0.2, and the vdocs defect blocking gold-promotion of the Kernel feature guides
metadata:
  type: project
---

The VistA Standard Library architecture plan
(`docs/plans/msl-vsl-architecture.md`) was taken to **v0.2**
on 2026-06-07 by working its §12 documentation gaps against the vdocs gold corpus.
Outcome of the seven proposed VDL fetches:

- **KIDS / Device Handler / TaskMan dedicated guides — exist and were fetched.**
  The VDL has per-feature Kernel 8.0 guides (`krn_8_0_dg_kids_ug`,
  `krn_8_0_sm_kids_ug`, `..._device_handler_ug`, `..._taskman_ug`) — the doc
  previously assumed only the Kernel TM/SM summaries existed. They yielded
  DBIA/ICR-cited primitives now grounding §3: `CALL^%ZISTCP` (ICR #2118, IPv6
  outbound TCP), `OPEN/USE/CLOSE^%ZISUTL` (handle-based devices),
  `$$PSET^%ZTLOAD` (ICR #10063, persistent self-restarting task — the listener
  mechanism), Required Builds = `REQUIRED BUILD` #11 Multiple on BUILD #9.6 with
  three install actions, env-check run-twice / `XPDENV`.
- **TLS gap was already closed in gold, not missing.** `XU/krn_8_0_tm` §"Install
  VistA Patch XU\*8\*787" documents the `DEFAULT TLS SERVER CONFIG` Kernel System
  Parameter → named IRIS `Security.SSLConfigs`, IRIS-for-Health ≥ 2024.1.2
  prereq, no-restart cert rotation. v0.1's "XU*8*787 not in the index" was wrong.
  HWSC SM guide `XOBW/xobw1_0sg` corroborates cert-based auth.
- **IAM / OAuth 2.0 / SMART-on-FHIR / FHIR — confirmed absent from the entire
  3,692-doc VDL inventory** (0 matches). Not unfetched — the VA does not publish
  these in the VDL. `VWEB`'s introspection-AS contract must be sourced outside
  the VDL and stays an open interface.
- **Parameter Tools** has no consolidated reference on the VDL; `XT/ktk7_3p26sp`
  (already cited) is the only source.
- **VIA** has no architecture guide on the VDL; `VIAB/via_vip_user_guide` was
  fetched as the closest substitute.

**vdocs defect blocking "make gold" (logged in [[discoveries.md]] 2026-06-07,
open upstream).** All ~41 distinct Kernel-8.0 `krn_8_0_{dg,sm}_*_ug` feature
guides get the **same `XU:XU:UG` anchor key** from the catalog/identity stage, so
`consolidate` keeps one winner and demotes the rest to `is_latest=0` — fetched +
in `index.db` but excluded from the `vdocs ask` FTS surface and the gold anchor
set. Same defect stuck `via_vip_user_guide` at convert. **The v0.2 findings were
read directly from the normalized silver bodies**
(`~/data/vdocs/documents/silver/text/03-normalized/XU/<slug>/body.md`), so the
doc doesn't depend on the fix. Fix lives in `~/projects/vdocs` (derive a
per-document anchor key for granular feature guides, then re-run
consolidate→index→manifest), not m-stdlib.
