---
name: m3-stdkv-storage-seam
description: VSL/MSL M3 Lane A — STDKV, the portable keyed record-store leaf (S1 storage seam). New minimal MSL module ($$set/$$get/$$exists/$$kill over (coll,key,field)), global-backed reference impl, dual-engine GREEN 12/12 (YDB+IRIS), @seam STDKV emitted (4 verbs, bump-forcer green NEW seam). VSLFS (v-stdlib) binds it to FileMan DBS. Tag v0.9.0 owed.
metadata:
  type: project
---

# STDKV — the portable storage leaf (VSL/MSL M3 Lane A, 2026-06-16)

The leaf-first MSL half of **M3** (the `VSLFS` storage seam, S1). Branch
`m3-stdkv` off `master` (v0.8.0). **Resolved design Q3:** the storage seam is a
**new minimal MSL module**, NOT a sub-API of `STDFS` — a record store is
conceptually distinct from filesystem path/byte I/O, and overloading `STDFS`
would muddy its seam. STDFS stays filesystem-only.

## The seam (`@seam STDKV` — 4 verbs, contract_version 1)
A record store addressed by **(collection, key, field)** — all four verbs are
extrinsic functions (call with `$$`, never `do`):
- `$$set^STDKV(coll,key,field,value)` → 1 (store)
- `$$get^STDKV(coll,key,field,default)` → value or default
- `$$exists^STDKV(coll,key)` → 1/0 (record has any field)
- `$$kill^STDKV(coll,key)` → 1 (remove whole record, idempotent)

Reference back end = process-private `^STDLIB($job,"kv",coll,key,field)=value`
(no VistA, no cross-run bleed, byte-faithful). The kickoff only needs the seam
"real and testable on a bare engine"; persistence/FileMan is VSLFS's job. The
four verbs all carry `; doc: @seam STDKV` → `seams.STDKV` in
stdlib-manifest.json + dist/seam-snapshot.json; **bump-forcer green (NEW seam,
no bump)**. The doc-comment maps the generic names to FileMan for the adapter:
coll→file number, key→IENS, field→field number (so VSLFS mirrors the signature).

## Why all four verbs are `$$` (and the test consequence)
The plan's notation is `$$get/$$set/$$exists/$$kill`, and a `quit <value>` label
(set/kill return 1) **cannot be invoked with `do`** (raises in M, same trap STDNET
hit with `write`/`close`). So STDKVTST consumes every return:
`set x=$$set^STDKV(...)` / `set x=$$kill^STDKV(...)`, never `do set^STDKV(...)`.

## Acceptance — dual-engine GREEN 12/12
7 tests / 12 assertions: set→get round-trip, default-when-unset (absent
record + absent field), exists lifecycle, kill removes record, multi-field
independence, **byte fidelity** (`$char(0)`/`$char(9)`/`$char(200)`/`$char(255)`
round-trips exact), set-returns-1. GREEN on BOTH `m test --engine ydb --docker
m-test-engine --chset m` AND `--engine iris --docker foia-t12 --namespace VISTA`,
`--routines src tests/STDKVTST.m`. **No `$ZVERSION` arm** — pure global I/O is
portable as-is (unlike STDNET's socket device). It's a CORE suite (deterministic,
no callouts) — in `make test` (46 suites, 2448/2448, no regression).

## Gates / packaging
- `make manifest seams skill doctest namespaces frontmatter` regenerated; no
  STDKVDOCTST (the `set`-style @examples are not Pattern-A `write … ; "…"`, so
  doctest gen skips them — intentional, keeps the side-effecting seam out of
  doctests).
- All engine-free gates exit 0: fmt/lint (0 error-severity) · check-manifest ·
  check-seams (3 seams) · check-namespaces (35 routines) · check-icr (0 — STDKV
  is engine-neutral, no L4 calls) · check-citations · check-docs-prose ·
  **check-kids** · `m arch check .` layer **m**, G2 clean (no VistA symbols — the
  whole point of the leaf).
- **NOT added to the MSL KIDS base** (`kids/std.build.json`, 17 curated
  routines) — STDNET isn't either; whether STDKV ships in the VistA base is an
  M5/VSLBLD packaging decision, not this leaf's scope.
- module-tracker row 35 added; docs/modules/stdkv.md added.

## What's owed (Lane B + release)
- **Tag MSL `v0.9.0`** (user action) carrying `seams.STDKV` so v-stdlib's
  `VSLFS` (Lane B) can re-pin `msl_ref` v0.8.0→v0.9.0 and bind it over FileMan
  DBS (`GETS^DIQ`/`$$GET1^DIQ`/`UPDATE^DIE`/`FILE^DIE`/`FIND1^DIC`).
- Branch `m3-stdkv` unmerged; merge + tag stay user actions. Companion to
  [[m2-stdnet-socket-seam]] (the S4 leaf-first rhythm this copies).
