---
name: kids-ship-all-routines
description: The MSL KIDS build (kids/std.build.json) now ships all 40 STD* routines via allowLongNames; was a stale 17-routine subset.
metadata:
  type: project
---

`kids/std.build.json` (`MSL*0.1*1`) was a **stale 17-routine subset**. As of 2026-06-20 it
ships **all 40 `STD*` production routines** (`src/STD*.m`) so MSL installs in its entirety.

Required the org routine-name-length policy: 6 STD names exceed the legacy 8-char cap —
`STDASSERT STDCRYPTO STDCSPRNG STDSEMVER STDHTTPMSG STDCOMPRESS` — so the spec sets
**`"allowLongNames": true`** (raises the cap to the engine limit 31; see ADR
`docs/background/routine-name-length-policy-adr.md` in the `docs` repo and v-pkg's
`AllowLongNames` field). `dist/kids/MSL.kids` rebuilt via `make kids` (471→880 KB);
`make check-kids` (deterministic-build drift gate) green; `check-manifest`/`check-namespaces`
unaffected (those derive from `src/`, already 40 modules).

Branch `ship-all-routines`, unmerged. Shared note: [[routine-name-length-policy]] (docs repo).
