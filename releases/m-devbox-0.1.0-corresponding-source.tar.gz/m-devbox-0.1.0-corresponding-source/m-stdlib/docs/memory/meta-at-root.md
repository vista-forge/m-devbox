---
name: meta-at-root
description: m-stdlib's repo meta moved from dist/repo.meta.json to root repo.meta.json (Phase B item 1)
metadata:
  type: project
---

The hand-edited repo meta moved **`dist/repo.meta.json` → root `repo.meta.json`**
(Phase B item 1, 2026-06-15) — the standardized "one meta artifact, one
location", now that `m arch check` reads the meta **root-first** and validates
its shape (id/layer/language/verification_commands; `Gate:"META"`).

- `make check-manifest` now asserts the **root** `repo.meta.json` is tracked +
  clean (Makefile updated); the rest of `dist/` stays generated/drift-gated.
- The "org catalog generator fetches `dist/repo.meta.json` by raw URL" note in
  the old Makefile comment was **stale** — no catalog generator exists in the
  `.github` repo (only `go-ci.yml` + `arch-waterline.yml`); the future scheduled
  **meta-gate** reads root metas. Comment removed.
- Landed on the `stdseed-engine-neutral-g2` branch (same m-stdlib Phase B PR as
  the STDSEED G2 fix — keeps the branch fully waterline-clean). `verified_on`
  stays today. Verified: `m arch check` 0 violations; `make check-manifest` clean.

Supersedes the "dist/ meta" half of [[waterline-g1-gate]]. See [[stdseed-g2-engine-neutral]].
