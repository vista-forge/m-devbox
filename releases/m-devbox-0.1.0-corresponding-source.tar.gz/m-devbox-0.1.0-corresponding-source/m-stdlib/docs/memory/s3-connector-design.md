---
name: s3-connector-design
description: The m-stdlib S3 connector — STDS3/STDSIGV4 (BUILT v0.14.0, dual-engine green) + VSLS3 (VistA log sink, still v-stdlib); how SigV4 maps onto STDCRYPTO; the two engine-HTTP-egress blockers.
metadata:
  type: project
---

**BUILD STATUS (2026-06-19, branch `phase1-s3-sigv4`, S3-tap Phase 1):** `STDSIGV4`
+ `STDS3` are **BUILT and dual-engine GREEN** (`@tier optional`, `@since v0.14.0`).
- `STDSIGV4TST` **16/16** + `STDSIGV4DOCTST` **2/2** + `STDS3TST` **18/18** on bare
  YDB (m-test-engine) + bare IRIS (m-test-iris), `--chset m`. Vectors from an
  independent Python (hmac/hashlib) oracle whose S3-GET signature + canonical-request
  hash match AWS's published S3 example byte-for-byte (the G-SIGV4 gate).
- `STDS3` design realized as built: `host`/`url`/`canonUri`/`buildRequest`/`parseError`/
  `parseList` are **testable without a network**; `parseList`/`parseError` use STDXML
  `//`-xpath. **Path-style `endpoint` override** = the MinIO/LocalStack hook.
- **MinIO testbed:** `scripts/s3-testbed.sh {up|down|status}` (a dedicated user-defined
  docker network both engine containers join → reach the sink as `m-s3-minio:9000`;
  bucket pre-created as a dir under the data mount, no `mc` needed). Round-trip suite
  `STDS3MINIOTST` runs via `make test-s3` (carved out of core/optional as
  `INTEGRATION_SUITES`).
- **Live signed PUT→MinIO returns 200 on IRIS** — real egress proven end-to-end.

**KEY BUILD GOTCHAS (also in discoveries.md 2026-06-19):**
1. **Host is signed but NEVER sent.** SigV4 signs the `host` canonical header, but
   `buildRequest` does `kill req("header","host")` before handing to STDHTTP — both
   libcurl (YDB) and `%Net.HttpRequest` (IRIS) add Host from the URL, and IRIS
   **fails `Send()` if Host is set by hand**. (This fix flipped the IRIS PUT 0→200.)
2. **Round-trip read-back is BLOCKED on engine HTTP egress** (two distinct P1s):
   - **YDB:** `m-test-engine` lacks the `stdhttp.so`/libcurl callout + `ydb_xc_stdhttp`
     (`$$available^STDHTTP()=0`). Infra: bake it into the image like B1 did for crypto.
   - **IRIS:** STDHTTP `irisPerform` (`%Net.HttpRequest`) fails `Send()` (rc=7, sc=0)
     for signed **bodyless** requests (GET/HEAD/DELETE) with custom headers — while
     signed PUT (has a body) and unauthenticated bodyless GET both work; a failed
     Send also poisons the process. Open STDHTTP IRIS fix. The proposal's egress
     (PUT) works; only the harness read-back (GET/LIST) is blocked.
3. **Reading IRIS diagnostics with no host-mount:** encode a value into the STDASSERT
   **pass-count** (`for i=1:1:sc do true^STDASSERT(...)`), or PUT it as a MinIO object
   and read MinIO's on-disk `xl.meta` (small objects are inlined, greppable via
   `strings`). `m-test-iris` has no writable host mount; `m-test-engine` mounts
   `~/m-work`→`/m-work`.

`docs/design/m-stdlib-s3-design.md` (DRAFT v0.1, created 2026-06-07) specs the AWS
S3 connector that realizes the [[vsl-doc-gaps-v0.2]] architecture's §6.2
outbound worked example (VistA log streaming to S3, "no log ever lands in a global").

**The split (obeys the Standard Library sharp line):**
- `STDSIGV4` (portable, m-stdlib) — AWS Signature V4 signer. Maps 1:1 onto existing
  primitives: signing-key chain is `$$hmacSha256Bytes^STDCRYPTO` (RAW bytes, keyed
  each step), final signature is `$$hmacSha256^STDCRYPTO` (HEX), payload/canonical
  hash is `$$sha256^STDCRYPTO`. The raw-byte-vs-hex asymmetry is the #1 SigV4 bug;
  byte mode (`ydb_chset=M`) makes the chain exact. No new crypto code needed.
- `STDS3` (portable) — S3 REST client (put/get/head/list/delete + multipart),
  builds request → calls STDSIGV4 → hands to STDHTTP. Registered as future-modules
  Pri 12 (STDSIGV4) + Pri 13 (STDS3), "cloud-egress wave."
- `VSLS3` + shared `VSLIO`/`VSLCFG`/`VSLTASK` (VistA-coupled, v-stdlib) —
  the STDLOG sink: batch→spool→NDJSON→sign→ship. Socket = `CALL^%ZISTCP` (ICR
  #2118); flush = persistent TaskMan task `$$PSET^%ZTLOAD` (ICR #10063); config =
  XPAR. All four VSL adapters already defined by the Standard Library architecture; only the
  sink is S3-specific (provider-swappable: VSLGCS/VSLAZ behind the same STDLOG seam).

**Why:** VistA barely logs because the only durable pure-M write target is a global
in the live clinical DB (journaling/backup/disk pressure). S3 egress moves logs off
the database entirely → lifecycle/immutability/Athena/SIEM for free.

**Grounded in:** AWS S3 REST API + SigV4 Authorization-header docs (fetched/verified
2026-06-07, full ref list in the doc §16–17, incl. boto3 + botocore SigV4) and the
VDL gold corpus for the VistA primitives (Device Handler / TaskMan / XPAR / Kernel
TLS guides — same set the Standard Library architecture cites). The VDL has ZERO AWS/object-
storage/cloud-egress docs — this connector is greenfield relative to VistA docs.

**How to apply:** STDSIGV4 + STDS3 are DONE (above). To finish the round-trip gate,
wire engine HTTP egress (the two blockers above). `VSLS3` (the STDLOG sink) + the
`VSLTAP`/`VSLRPCTAP`/`VSLHL7TAP` traffic-tap core are **Phase 2/3** in v-stdlib and
bind `STDS3` under VistA — see the implementation plan/tracker in the `docs` repo
(`docs/proposals/implemented/rpc-traffic-s3-streaming-implementation-plan.md`). MSL tag for
STDSIGV4/STDS3 is **v0.14.0** (a user action: tag → v-stdlib repins when VSLS3 lands).
