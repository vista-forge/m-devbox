# The W1 tag↔code verifier — durable lessons (stdlib-doc-accuracy Phase 1, 2026-07-18)

Effort home: docs repo `proposals/completed/stdlib-doc-accuracy/` (tracker rows 1a/1b/1c; effort COMPLETE + archived 2026-07-19).
`tools/gen-manifest.py` is now a STRICT verifier (hard-errors, exit 2, nothing
written) — this file keeps only what the code/history can't say.

## m-stdlib HAS a helper-raise idiom (the review's "unused in m" was wrong)

`STDARGS`/`STDFMT`/`STDREGEX` raise via `do raise("SUFFIX")` backed by
`set $ecode=",U-<MODULE>-"_err_","` (the L12 Pass B fresh-frame pattern) —
zero literal `",U-…,"` sites for 12 documented codes. The verifier's
`HELPER_RAISE_RES` recognizes the call sites (`suffix` group →
`U-<MODULE>-<suffix>`; a `code` group is taken verbatim — the v-stdlib port's
shape). `STDJSON.raise(.ctx,msg)` takes a MESSAGE, not a code — deliberately
unmatched (its fixed code is a literal inside the helper). **Phase 2 (v port)
and Phase 7 (de-fork) must treat the helper-regex list as per-repo config with
BOTH group shapes.**

## Two codes are raised through DATA FLOW — standing printed exemptions

`U-STDREGEX-BAD-PATTERN` / `U-STDREGEX-UNSUPPORTED` travel as
`st("err")="BAD-PATTERN"` … later `do raise(err)` — no static site can carry
the code. They are `RAISE_EXEMPT` entries (printed every run), backed by live
`raises^STDASSERT` examples. `U-STDCRYPTO-BAD-ALGO` is exempt for the opposite
reason: a defensive guard in `@internal shaLen` that every caller feeds a
literal valid name — documenting it as a public `@raises` would be false.

## The seam bump-forcer cannot distinguish a RECORD REPAIR from a contract change

Fixing the classifier corrected `dist/seam-snapshot.json`'s STDHTTPD
`route`/`use` entries `do …` → `$$…` and the bump-forcer red-fired
("signature changed without a contract_version bump"). Ruling (2026-07-18):
**record repair, no bump** — the M code never changed, both call forms stay
valid (`$quit`-guarded dual entry), and a bump would falsely signal an
incompatible change. The red is HEAD-relative and clears at commit. If a
repair like this recurs, consider a sanctioned-repair annotation for
`seam_contract.py` rather than bumping through it.

## Consumer residue: v-web's MSL seam pin still records the wrong forms

`v-web/dist/msl-seam-pin.json` pins `msl_ref: v0.13.0`, whose snapshot carries
the buggy `do route^STDHTTPD` / `do use^STDHTTPD` — tag-anchored, so it stays
green and WRONG until v-web next bumps its pin (carried to Phase 2b in the
effort tracker).

## Version truth: tags stopped at v0.13.0

Six changelog headings said "— pending" for RELEASED (tagged) versions, and
v0.14/v0.15 shipped on `main` untagged; the manifest claimed `v0.15.0`. The
pending-heading hard error + the `[Unreleased]` restructure anchor
`stdlib_version` to the last SHIPPED tag (v0.13.0). If a release is cut,
tag it AND date its heading — the generator reds otherwise.

## W2 (Phase 3): the "gate the remainder" offender count is CODE-derived, not the plan's headline

The plan/proposal framed W2 as "748-vs-359" and estimated **~389** offenders to
sweep — but that headline is `col-1 − manifest`, and **341 of those 389 labels
ALREADY carried `; doc: @internal`**. The real offender set (neither doc block
NOR `@internal`) was **48**, not 389. Red-proof a "gate the remainder" check by
running the new gate and reading its printed count — never trust the plan's
subtraction, which double-counts labels that are already explicitly marked.
(Same shape as the shared-memory `proposal-status-lags-the-repo` lesson — the
CODE breaks the tie.) The v-stdlib port's "~25 VSL" estimate deserves the same
re-derivation. All 48 m-stdlib offenders were genuinely module-private
(no cross-module callers) → flagged-to-owner queue empty; the sweep was pure
`@internal` annotation, manifest content unchanged (only `source.line` shifted).

The invariant `col-1 = documented + @internal + unaccounted` prints every run
and red-gates on `unaccounted > 0`. `collect_doc_lines` now hard-errors on a
stray non-`doc:` comment between a label and its doc block (was a silent drop).
**The parser self-test is now GATED** (`make manifest-check` runs
`gen-manifest.py --self-test`) — Phase 1 built those fixtures but never wired
them, so they protected nothing; an unobserved gate is not a gate.

## W6 (Phase 4): module tag/phase own the frontmatter AND the index catalogue

The F8 ownership inversion (RC-5). A module's `tag` (first-shipped release) and
`phase` (delivery wave) now live as `; doc: @tag` / `; doc: @phase` **module-header**
tags in `src/STD*.m` (parsed by `gen-manifest.py` exactly like `@tier`) — the
single owner. `write-module-frontmatter.py` derives the per-module `tag`/`phase`/
`since` frontmatter from the manifest, and REGENERATES the `docs/modules/index.md`
module-catalogue table (between `<!-- BEGIN/END GENERATED: module-catalogue -->`
markers) as a projection. **No new gate was needed**: `frontmatter-check` already
diffs all of `docs/modules/` (index.md included), so it red-gates catalogue drift
too. The old per-phase hand tables in index.md were the input feeding empty
frontmatter for any module they omitted (STDHARN/STDKV/STDNET shipped blank
`tag`/`phase`) — they are deleted; the release narrative moved to the changelog.

**Gotcha — `; doc:` structured tags leak into the manifest module `description`.**
`parse_module_file` builds `description` from the whole header comment block, so
every `doc: @tier`/`@exrun`/... line was already dumped raw into `description`
(unused output, but pollution). Adding `@tag`/`@phase` to every module would have
prepended `doc: @tag …\ndoc: @phase …` to all 40 descriptions. Fix: the
description is built from header lines whose stripped body does NOT start with
`doc:` (the full list is still used for tag extraction). `dist/skill/` and
`errors.json` were byte-unchanged — confirms nothing user-facing reads the module
`description`.

**Adding a registry tag needs a hand `### 5.N` prose subsection** in
`docs/guides/m-doc-grammar.md` or `grammar-check` reds (registry tag with no
subsection) — the §5 table is generated, the per-tag prose is hand-written.
(Since the Phase-7 de-fork the registry is shared `tools/mdoc/tags.py` + this
repo's `tools/mdoc_config.py` `extra_tags` — the old `mdoc_tags.py` is retired.)
