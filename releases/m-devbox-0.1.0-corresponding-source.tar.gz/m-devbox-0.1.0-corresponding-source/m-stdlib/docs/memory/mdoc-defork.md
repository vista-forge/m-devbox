---
name: mdoc-defork
description: tools/mdoc/ is the SINGLE parser/verifier core for all three doc toolchains (m-stdlib canonical home; v-stdlib + v-web consume via sibling path) — parser fixes land once here, per-repo knowledge only in mdoc_config.py.
metadata:
  type: project
---

# mdoc de-fork — this repo hosts the canonical doc-parser core

**Since stdlib-doc-accuracy Phase 7 (2026-07-19):** `tools/mdoc/` (tags.py /
config.py / core.py / selftest.py) is the ONE M-doc parser/verifier, consumed
by m-stdlib (in-repo), v-stdlib and v-web (sibling path, `MSTDLIB` env
override, org-layout default; absence is a HARD red in their shells). Each
repo's `tools/gen-manifest.py` is a thin shell; per-repo knowledge (extra
tags, raise idioms, exemptions, hooks) lives ONLY in that repo's
`tools/mdoc_config.py`.

**Why:** RC-8 — every parser fix was a hand-ported multi-repo change that
could land in one repo only (the RC-2 classifier fix took a 3-repo sweep).
Design record: docs repo
`proposals/completed/stdlib-doc-accuracy/stdlib-doc-accuracy-phase7-defork-design.md`.

**How to apply:**
- A parser/verifier fix goes in `mdoc/core.py` — never pasted into a shell;
  all three consumers' gates pick it up (their `--self-test` runs the shared
  `mdoc.selftest` corpus).
- **Changing `mdoc/` is a CROSS-REPO seam change:** after editing, regenerate
  + gate v-stdlib and v-web too (their manifests parse through this copy) —
  writers-sweep discipline, same session or a recorded hand-off.
- A new shared tag → `mdoc/tags.py` (+ hand §5.N prose here, grammar-check
  reds otherwise); a repo-only tag → that repo's `extra_tags`.
- The label/manifest hooks may RE-ORDER dict keys (manifest key order is part
  of the committed artifact) — a hook returns the entry/manifest to use.
- `gen-examples.py` / `gen-bodies.py` / `check-docs.py` stay deliberately
  vendored byte-identical siblings (NOT part of the core) — see
  [[durable-gotchas]].
