---
name: iris-native-backends
description: PR #1 reconciliation — the 3 optional modules' IRIS dispatch arm uses the inlined `$zversion["IRIS"` probe (not a public engine helper); dual-engine local-test runbook; m-test-iris embedded-Python gap; how a stale PR was landed without merge/rebase/force-push.
metadata:
  type: project
---

**IRIS-native backends for the 3 optional modules** (STDCRYPTO / STDCOMPRESS /
STDHTTP) landed via **PR #1** ("B2"), reconciled onto the s9–s12 IRIS sweep on
2026-06-14. The stale PR predated that sweep and was CONFLICTING + partially
superseded; reconciliation kept only the novel payload.

**The engine seam is the inlined `$zversion["IRIS"` probe — the house idiom
for runtime modules.** Each module's dispatch helper gets an
`if $zversion["IRIS" quit $$iris…(…)` arm ahead of the YDB `$&pkg.fn` path
(STDCRYPTO → `$SYSTEM.Encryption.SHAHash/.HMACSHA`; STDHTTP →
`%Net.HttpRequest`; STDCOMPRESS → embedded-Python zlib + ctypes/zstd). The
PR's own `$$engine^STDOS()` helper was **dropped as superseded** — master's
STDOS is already IRIS-ported by inlining the same probe, STDASSERT already has
its `irisRaises` try/catch arm (s9), and `$$engine^STDHARN()` (internal) exists
if a helper is ever wanted. **Future IRIS arms in m-stdlib runtime code: inline
`$zversion["IRIS"`, do not add a cross-module engine helper.** See
[[durable-gotchas]] for the IRIS portability idioms ($ZTIMESTAMP clock,
xecute-built dispatch, STDFS facade).

**Dual-engine local-test runbook** (the canonical invocations — the Makefile
targets omit these flags because they target host-YDB CI / the Python m-cli):
- Build a current `m`: the committed `m-cli/dist/m` can be stale; rebuild with
  `cd m-cli && GOPROXY=file://$HOME/go/pkg/mod/cache/download GOSUMDB=off GOFLAGS=-mod=mod go build -o /tmp/m .`
  (the `--chset` flag was missing from the committed binary).
- **YDB:** `m test tests/X.m --engine=ydb --docker=m-test-engine --routines src --chset m`
  — **`--chset m` is mandatory**: the m-test-engine container defaults to
  `ydb_chset=UTF-8`, but the byte/binary modules need byte mode (else
  `%YDB-E-BADCHAR` on raw digest/compress bytes).
- **IRIS:** `m test tests/X.m --engine=iris --docker=m-test-iris --routines src --namespace USER`
  (byte mode is inherent on IRIS).
- Results: STDCRYPTOTST 23/23, STDHTTPTST 68(YDB)/67(IRIS), STDCRYPTODOCTST 1/1,
  STDCOMPRESSTST 59/59 (YDB) all green.

**Gap — `m-test-iris` (iris-community image) has non-functional embedded
Python**: `%SYS.Python` class exists but `Import("sys").version`→0, and the
STDCOMPRESS IRIS path aborts non-trappably (0/0). So **STDCOMPRESS-IRIS can't
be verified locally on the bare tier**; the PR validated it on `vista-iris`
(working embedded Python). The reconciled code is the PR's vista-iris-validated
logic with only the (proven-correct) seam changed. Discoveries register has the
detail. **UPDATE 2026-07-16 (caps-limits W4 probe): foia-t12's embedded Python
WORKS** — `$$available^STDCOMPRESS()`="" and a **>1 MiB (1,310,720 B) gzip
round-trip is byte-exact** on it (`m test --engine iris --docker foia-t12`,
7/7). So foia is a live gate host for STDCOMPRESS-IRIS; m-test-iris remains
bare-tier-blind for it (and the examples manifest still tags the module
`engine: ydb` — contradiction filed as a caps-limits W4 residual).

**`m test` lane limits (learned the hard way, same probe):** `m test` is
**docker/local only — it has NO remote/Atelier transport** (the
iris-transport-standardization's known "work left = m-cli" gap). Wrapping it in
`m runlock hold --transport remote` does NOT work: the child keys to
`iris.local.IRIS` (no `--docker` ⇒ local lane) while the bracket holds
`iris.docker.foia-t12`, and the mismatch surfaces as the misleading
`RUN_LOCK_NOT_HELD` "the bracket died under its own children". Use
`--docker foia-t12` (the docker lane auto-brackets). Diagnosis detail in the
shared [[run-lock-seam]] memory.

**Asymmetric verify (STDCRYPTO T32) — Phases 0+1+2 DONE, dual-engine GREEN 53/53**
(2026-07-09). `$$verifySig^STDCRYPTO(alg,pubKey,msg,sig)` verifies **RS/PS/ES256/384/512
+ EdDSA** on YDB (`crypto_verify` libcrypto callout) AND IRIS (native
`$SYSTEM.Encryption` `RSASHAVerify`/`RSASSAPSSVerify`/`ECSHAVerify`), proven on
m-test-engine, m-test-iris, and foia-t12. **EdDSA is YDB-only** (IRIS has no
CFRG/Ed25519 method — the IRIS arm raises BADALG, a visible fail-closed *tracked
skip* asserted in-suite via `edDsaSkip`, never a silent gap). G-IRIS findings
(all measured on foia, design note `docs/design/stdcrypto-asymmetric-verify-design.md`):
- **All three IRIS verify methods share the arg shape `(shaBits, data, sig, pubKey)`**
  — SHA size FIRST (256/384/512), key LAST (differs from the digest/HMAC
  `(bits,data,key)` order). `RSASSAPSSVerify` mirrors `RSASHAVerify` (confirmed
  read-only on foia 2026-07-09); its PSS defaults already match RFC (saltlen=hlen,
  MGF1=same digest), so a host-OpenSSL PS256 vector verifies unchanged.
- **PEM-only key:** a bare SPKI **DER key silently returns 0 (not an error)** on
  IRIS. `irisVerify` wraps DER→PEM (`$$toPem`) for all families to keep the public
  "DER or PEM" contract engine-neutral. YDB accepts both natively.
- **ES\* sig is the JWT `R‖S`, but IRIS `ECSHAVerify` (like OpenSSL) wants DER
  `SEQUENCE{r,s}`** — so the IRIS ES\* arm converts M-side first (`$$rsToDer`), then
  calls `ECSHAVerify(bits,data,DERsig,pemKey)`. Width = `$L(sig)\2` (P-521 halves
  are 66 bytes, not 64); minimal-DER integers with a leading `$c(0)` when the high
  bit is set. See [[durable-gotchas]] for the width + `isKeyErr` rules.
Three implementation gotchas that were live (not just review notes):
- **verify does NOT reuse `dispatch3/4`** — they read `rc=0` as *success*, but for
  verify `rc=0` is the valid "signature invalid" answer. `dispatchV` reads rc
  directly; C codes are disjoint `-10 BADKEY / -11 BADALG / -12 VERIFY-FAIL`; the
  `$ETRAP` callout-missing sentinel is `-99` (distinct from every C code, N-3).
- **A still-armed `$ETRAP` swallows a post-`xecute` `set $ecode`** — `dispatchV`
  and `irisVerify` must `set $etrap=""` right after the xecute or the mapped
  BADKEY/BADALG error is eaten by the callout-missing trap (this kept the RED
  error-path tests red until fixed; dispatch3/4 carry the same latent shape but
  only on never-asserted callout-missing paths). See [[durable-gotchas]].
- **The `RSAGetLastError`→BADKEY disambiguation is RSA-ONLY — gate it to `fam="RS"`.**
  `irisVerify` maps a bad KEY to BADKEY (engine-neutral parity with YDB's C `-10`)
  by inspecting `$SYSTEM.Encryption.RSAGetLastError()` on an `r=0` result. That
  channel is RSA-specific: for a *failed* ES\*/PS\* verify it can return a stale/
  misleading "decode"-class string, so `$$isKeyErr` fires and `set $ecode=BADKEY`
  **raises uncaught inside a plain `eq`/`true` assert → the whole suite aborts**
  (`<ECODETRAP> irisVerify+…`, 0/0). Fix: only RS\* consults `RSAGetLastError`; a
  failed ES\*/PS\* verify just reports invalid (0). Cost: an ES\*/PS\* *garbage key*
  returns 0 on IRIS instead of BADKEY — benign (both fail-closed; BADKEY-raise is
  only asserted with RS256).
**CI/deploy:** `STDCRYPTOTST` (optional suite) is now wired into CI via
`test-optional` + `coverage-optional` (gate 60% — optional set has xecute-hidden
IRIS arms); `scripts/seed-engine-callouts.sh` (`make seed-engine-callouts`,
docker-cp not exec) re-seeds `std_crypto.so`'s new `crypto_verify` symbol into the
provisioned engine (the pinned image predates it) — durable fix is an image bump /
`m callouts install` (m-engine follow-up). Design/plan:
`docs/proposals/stdcrypto-asymmetric-verify-v2.md`; Phase-0 note:
`docs/design/stdcrypto-asymmetric-verify-design.md`.

**Asymmetric SIGN (STDCRYPTO, VSL-JWT issuer) — DONE, dual-engine GREEN 53/53**
(2026-07-09). `$$signSig^STDCRYPTO(alg,privKey,msg)` is the private-key mirror of
`$$verifySig`; `$$signRs256`/`$$signEs256` are the shipped thin wrappers (other algs
reach through `$$signSig`). YDB: new `crypto_sign` libcrypto callout (`EVP_DigestSign`
+ `der_to_rs` for ECDSA) via `dispatchS` (mirror of `dispatchV`, -99 callout-missing
sentinel; new codes `SIGN-FAIL`/`SIGN-BUF`). IRIS: **`$SYSTEM.Encryption.RSASHASign` /
`RSASSAPSSSign` / `ECSHASign` all EXIST** (`%ExistsId` on `%SYSTEM.Encryption` → 1),
same `(shaBits,data,key)`-ish shape but key = **PEM PRIVATE key** (`$$toPemPriv` wraps
DER as `BEGIN PRIVATE KEY`; the verify-side `$$toPem` is public-only). **`ECSHASign`
returns a DER `SEQUENCE{r,s}`, NOT the JWT `R‖S`** — the IRIS ES\* arm converts with a
new `$$derToRs` (inverse of the verify-side `$$rsToDer`; strip DER sign-pad + left-pad
each half to `esHalf(alg)` = 32/48/66). EdDSA sign is YDB-only (no IRIS CFRG), same as
verify. The private key is the issuer crown jewel — the module never persists/logs it.
KATs: RS256 gets an **exact-byte** KAT (deterministic PKCS#1 v1.5, openssl reference);
ES256 is a **sign→verify round-trip** (non-deterministic k) — sound because verify is
independently pinned by the RFC 7515 A.3 external KAT. The seed script now asserts BOTH
`crypto_verify` and `crypto_sign` symbols.

**Install-method boundary (durable, applies to all 3 optional callout modules):**
the native `.so` half installs **outside `v pkg`/KIDS** — KIDS transports globals+
routines *inside* the M database, but the `.so` + `ydb_xc_*` env + YDB call-out table
live *outside* it, and a KIDS post-install M routine can neither `gcc` nor set the
parent process env. So `v pkg` installs only the **routine** half (into a VistA, via
the `MSL*0.1*1` KIDS build); the native half is a **YDB engine-runtime dependency**
(only YDB — IRIS is native `$SYSTEM.Encryption`, no `.so`). The "never a bespoke
installer" org rule governs KIDS/VistA *packages*, not OS-level lib deps, so it does
not forbid a callout-install mechanism (owner-nod pending). Recommendation: promote
the dev-only `scripts/seed-callouts.sh` into a baked engine-image layer or an
`m callouts install` verb (m-toolchain/m-engine work item), shared by all 3 modules.
Full rationale: `stdcrypto-asymmetric-verify-v2.md` §15.

**Landing a stale PR under this sandbox** (`git merge`, `git rebase`,
`git clean`, `rm`, and force-push are all denied): don't rebase. Make a
**forward commit on the branch** whose tree equals `master + additive
backends` — `git checkout origin/master -- .` (sync whole tree to master),
re-`git rm` master's deletions, `git checkout HEAD -- <the backend files>` to
restore the wanted changes, regenerate `dist/`. GitHub's 3-way merge is then
clean (master's changes appear identically on both sides; backends are purely
additive in files master never touched) and the PR diff is minimal. Verify
with `git diff --cached --stat origin/master` before committing.
