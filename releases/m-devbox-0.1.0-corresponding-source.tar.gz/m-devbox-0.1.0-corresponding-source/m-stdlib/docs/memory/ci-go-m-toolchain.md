---
name: ci-go-m-toolchain
description: m-stdlib CI now runs the Go `m` (not the legacy Python m-cli); engine via --docker m-test-engine; lint/coverage reconciliations
metadata:
  type: project
---

# m-stdlib CI standardized onto the Go `m` (2026-06-15)

m-stdlib's `.github/workflows/ci.yml` was rewritten to run the **Go `m`**
(github.com/vista-forge/m-cli — fmt/lint/test/coverage in one binary),
replacing the **legacy Python m-cli** (github.com/m-dev-tools/m-cli, pip-installed
inside a `yottadb/yottadb-base` container). This unblocks VSL/MSL **Phase B item 4**
(the reusable `m-ci.yml` could not generalize across two M toolchains). Branch
`mstdlib-ci-go-m`, **PR #12**; **proven GREEN on a real Actions run**
(run 27541967332: arch ✓, m-stdlib ✓; iris fail-soft).

**Why:** the org standardized on the Go `m` (the waterline `arch` gate already
builds + runs it); m-stdlib was the last repo on the Python toolchain.

**How to apply (the non-obvious bits):**

- **Engine transport = `--docker m-test-engine`, NOT LocalEngine.** There is no
  host YDB on the dev box (or in CI) — the engine is the `m-test-engine` Docker
  container. CI runs on a plain `ubuntu-latest`, `docker run -d --name
  m-test-engine ghcr.io/m-dev-tools/m-test-engine:0.2.0`, waits for the
  healthcheck, then `m test/coverage --engine ydb --docker m-test-engine`. This
  is the locally-proven path (Option 2 in the spike). Option 1 (run INSIDE
  yottadb/yottadb-base + Go-m LocalEngine) was NOT used — unproven with the Go m.
- **`m` is built in-workflow** via `git clone --depth 1 --branch $M_CLI_REF
  vista-forge/m-cli && CGO_ENABLED=0 go build` (same proxy-lag-immune pattern
  as `arch-waterline.yml`; do NOT `go install …@main`). `M_CLI_REF` defaults to
  `main` — pin to a tag at Phase B item 5.
- **Byte mode is mandatory:** `--chset m` on YDB (STDB64/STDHEX/STDCSPRNG are
  byte-exact); no-op on IRIS. Without it those suites silently report 0/0.
- **Routines must be staged:** `m test` only stages the suite files — pass
  `--routines src` so `^STDASSERT` + the module-under-test resolve.
- **Lint severity gap.** The Go `m` has NO `--error-on=<severity>` flag; its
  `--check` fails on ANY finding. The house gate (zero **error**-severity;
  style/warning advisory) is reproduced by `scripts/m-lint-gate.sh` (reads
  `m lint -o json`, exits non-zero only on error-severity). m-stdlib is clean:
  ~140 findings, all style/warning, 0 error. → residual `needs:` for m-cli: a
  native `--error-on`/`--fail-on` flag would let the wrapper go away.
- **Aggregate, not per-module, coverage.** `m coverage --min-percent` gates the
  AGGREGATE line % across the measured set (the legacy "per module" comment was
  stale — sub-85% modules like STDFS/STDHARN were already documented exceptions).
  `make coverage` measures `CORE_SRC` (src minus the 3 optional modules
  STDCOMPRESS/STDCRYPTO/STDHTTP, which have no core suites and would tank the
  aggregate) and is green at **~92.8%**. `--lcov <path>` replaces `--format=lcov`;
  `-o json` replaces `--format=tap`/`--format=json` (the Go m has no TAP writer).
- **Drift gates stay Python.** `tools/gen-manifest.py` / `gen-skill.py` /
  `gen-doctests.py` are pure-stdlib (argparse/json/re/pathlib) — system `python3`
  on the runner suffices, no pip, no container.
- **Makefile knobs:** `M` (binary, default `m` on PATH) and `M_ENGINE_FLAGS`
  (default `--engine ydb --docker m-test-engine --chset m`). New `ci-json` target
  writes the JSON artifacts without re-running the gate.

**IRIS job:** ported to the Go `m` (ubuntu + `docker run intersystemsdc/iris-
community` + `m test --engine iris --docker m-test-iris`), kept fail-soft
(`continue-on-error`). First real IRIS-in-CI run = **44/45 suites pass** (1
portability failure surfaced — the intended signal). Far better than the legacy
Python IRIS runner. See [[durable-gotchas]] for IRIS-runner
gotchas; [[iris-native-backends]] for the `--chset m` rebuild note.

**Now a thin caller of the reusable `m-ci.yml`** (2026-06-15, same PR #12):
`.github/workflows/ci.yml` was refactored from an inline job to a one-block
caller of `vista-forge/.github` **`m-ci.yml`** (VSL Phase B item 4) — that
reusable workflow provisions `m` + the engine container and runs THIS repo's
Makefile targets (`engine-free-targets` = check-manifest/skill-check/doctest-check/
check-docs-prose/fmt-check/lint; `engine-targets` = test/coverage/ci-json;
`run-iris: true`). All the reconciliations above stay in the Makefile (that's the
point — the workflow is repo-agnostic). Pinned `@m-ci-reusable` to prove it;
**flip → `@main` after the `.github` PR merges.** Detail → shared memory
`m-ci-reusable-workflow` (docs repo).

**Branch-base note:** built off `master`, so it carries the `dist/repo.meta.json`
(pre-Phase-B-item-1) location and `make check-manifest` form. The
`stdseed-engine-neutral-g2` branch (meta-to-root move + STDSEED G2) is a SEPARATE
unmerged PR; both touch `Makefile` + `AGENTS.md` in different regions — expect a
trivial rebase when one lands first.
