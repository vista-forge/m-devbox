---
name: stdseed-g2-engine-neutral
description: STDSEED made strictly engine-neutral for the m/v waterline G2 gate — the FileMan default filer removed; filer now required
metadata:
  type: project
---

The m/v waterline **G2** gate (no VistA symbols below the line) had exactly
one real below-waterline reference across m-stdlib: STDSEED's bundled default
filer `fileViaDie` → `do FILE^DIE` (FileMan). Everything else STDSEED does is
already engine-neutral — the filer is injected by string (`xecute "do "_filer_"(...)"`),
so the loader core never names FileMan.

**Decision (2026-06-14, user, Option B):** remove the FileMan default from the
`m` layer rather than allow it as an annotated G2 exception — so **G2 stays a
pure deny-list with no escape-hatch/pragma mechanism** (avoids the first
documented below-waterline exception becoming precedent). Rationale was
strengthened by a caller audit: **no real caller used the no-filer default** —
every STDSEEDTST test injects a stub filer; the only no-filer usage was a quoted
example inside the `m-vista-test-suite` template (itself a v-flavored artifact).

**What changed in m-stdlib (branch `stdseed-engine-neutral-g2`, off master):**
- `src/STDSEED.m`: deleted `fileViaDie`; `load`/`loadJson` now raise the new
  `,U-STDSEED-NO-FILER,` when `filer=""` (checked *first*, before file read /
  JSON parse). Header + `@param`/`@raises`/`@example` doc updated; the orphan
  `U-STDSEED-FILER-DIE-ERROR` code is gone.
- `tests/STDSEEDTST.m`: added `tLoadWithoutFilerRaises` + `tLoadJsonWithoutFilerRaises`
  (TDD-red first). **Gotcha:** three pre-existing loadJson error-path tests
  (`tLoadJsonInvalidJsonRaises` / `NonArrayRoot` / `MissingFileKey`) had relied
  on the default to reach the parse logic — they now must inject a filer
  (`capture^STDSEEDTST`) or they red on NO-FILER before validating. FileMan
  mentions scrubbed from the test comments too (keep the m-layer `.m` clean).
- dist/ regenerated (manifest/errors/skill — `U-STDSEED-NO-FILER` registered);
  `docs/modules/stdseed.md` History + `docs/module-tracker.md` row updated.

**Verified:** STDSEEDTST 37/37 on **both** engines (YDB m-test-engine + IRIS
m-test-iris); full core suite 49 suites / 2098 / 0 on YDB; lint 0 errors; fmt
clean; STDSEED coverage 98.8% (up — dead untested filer gone); generators idempotent.

**Owed (v-stdlib, next increment):** re-home the FileMan filer as
**`fileViaDie^VSLSEED`** (layer v) — the module doc + this design already commit
to that name. **Do NOT name `^VSL*` in any m-stdlib `.m` comment** — the G1
M-ref scan (`\^VSL...`) is comment-unaware and would flag m-stdlib; the m-layer
example uses the neutral placeholder `myFiler^MYAPP`.

Part of Phase B (standardize the substrate) — the prerequisite that lets G2 be
wired clean. See [[waterline-g1-gate]] and [[durable-gotchas]].
