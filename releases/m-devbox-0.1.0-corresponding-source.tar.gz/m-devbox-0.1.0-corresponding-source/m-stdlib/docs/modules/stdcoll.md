---
module: STDCOLL
tag: v0.2.0
phase: Phase 2
stable: stable
since: v0.2.0
synopsis: 'collections (Set, Map, Stack, Queue, Deque, Heap, OrderedDict)'
labels: ['dequeClear', 'dequePeekBack', 'dequePeekFront', 'dequePopBack', 'dequePopFront', 'dequePushBack', 'dequePushFront', 'dequeSize', 'heapClear', 'heapPeek', 'heapPeekKey', 'heapPop', 'heapPopKey', 'heapPush', 'heapSize', 'mapClear', 'mapGet', 'mapHas', 'mapNext', 'mapPut', 'mapRemove', 'mapSize', 'odictClear', 'odictFirst', 'odictGet', 'odictHas', 'odictLast', 'odictNext', 'odictPrev', 'odictPut', 'odictRemove', 'odictSize', 'queueClear', 'queuePeek', 'queuePop', 'queuePush', 'queueSize', 'setAdd', 'setClear', 'setHas', 'setNext', 'setRemove', 'setSize', 'stackClear', 'stackPeek', 'stackPop', 'stackPush', 'stackSize']
errors: []
conformance: []
see_also: []
---

# `STDCOLL` — collections

Pure-M collections for working code that needs the everyday data
structures M's built-ins do not directly model: `Set`, `Map`, `Stack`,
`Queue`, `Deque`, `Heap` (min-heap with optional payload), and an
insertion-ordered `OrderedDict`.

Every collection is a **by-reference local array** owned by the
caller. Killing the variable disposes of everything; no
process-globals are touched. This means multiple instances of the
same type coexist without fuss — they're just separate locals.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `dequeClear` | `do dequeClear^STDCOLL(d)` | Drop every entry. |
| `dequePeekBack` | `$$dequePeekBack^STDCOLL(d)` | Return back without removal; "" when empty. |
| `dequePeekFront` | `$$dequePeekFront^STDCOLL(d)` | Return front without removal; "" when empty. |
| `dequePopBack` | `$$dequePopBack^STDCOLL(d)` | Pop and return the back; "" when empty. |
| `dequePopFront` | `$$dequePopFront^STDCOLL(d)` | Pop and return the front; "" when empty. |
| `dequePushBack` | `do dequePushBack^STDCOLL(d, value)` | Push value at the back. |
| `dequePushFront` | `do dequePushFront^STDCOLL(d, value)` | Push value at the front. |
| `dequeSize` | `$$dequeSize^STDCOLL(d)` | Return deque length. |
| `heapClear` | `do heapClear^STDCOLL(h)` | Drop every entry. |
| `heapPeek` | `$$heapPeek^STDCOLL(h)` | Return value at min key without removal; "" when empty. |
| `heapPeekKey` | `$$heapPeekKey^STDCOLL(h)` | Return min key without removal; "" when empty. |
| `heapPop` | `$$heapPop^STDCOLL(h)` | Pop value at the min key; "" when empty. |
| `heapPopKey` | `$$heapPopKey^STDCOLL(h)` | Pop and return the min key; "" when empty. |
| `heapPush` | `do heapPush^STDCOLL(h, key, value)` | Push (key, value) onto the heap. |
| `heapSize` | `$$heapSize^STDCOLL(h)` | Return heap size. |
| `mapClear` | `do mapClear^STDCOLL(m)` | Drop every entry. |
| `mapGet` | `$$mapGet^STDCOLL(m, key, default)` | Return value at key; default if absent. |
| `mapHas` | `$$mapHas^STDCOLL(m, key)` | Return 1 iff key is set. |
| `mapNext` | `$$mapNext^STDCOLL(m, prev)` | Return next key after prev in $order; "" at end. |
| `mapPut` | `do mapPut^STDCOLL(m, key, value)` | Store value at key (overwrites). |
| `mapRemove` | `do mapRemove^STDCOLL(m, key)` | Drop key (no-op when absent). |
| `mapSize` | `$$mapSize^STDCOLL(m)` | Return number of keys. |
| `odictClear` | `do odictClear^STDCOLL(o)` | Drop every entry. |
| `odictFirst` | `$$odictFirst^STDCOLL(o)` | Return first key in insertion order; "" when empty. |
| `odictGet` | `$$odictGet^STDCOLL(o, key, default)` | Return value at key; default if absent. |
| `odictHas` | `$$odictHas^STDCOLL(o, key)` | Return 1 iff key is set. |
| `odictLast` | `$$odictLast^STDCOLL(o)` | Return last key in insertion order; "" when empty. |
| `odictNext` | `$$odictNext^STDCOLL(o, prev)` | Return next key (insertion order) after prev; "" at end. |
| `odictPrev` | `$$odictPrev^STDCOLL(o, next)` | Return previous key (insertion order) before next; "" at start. |
| `odictPut` | `do odictPut^STDCOLL(o, key, value)` | Store value at key; create-or-update preserving position. |
| `odictRemove` | `do odictRemove^STDCOLL(o, key)` | Drop key (no-op when absent). |
| `odictSize` | `$$odictSize^STDCOLL(o)` | Return number of keys. |
| `queueClear` | `do queueClear^STDCOLL(q)` | Drop every entry. |
| `queuePeek` | `$$queuePeek^STDCOLL(q)` | Return front without removal; "" when empty. |
| `queuePop` | `$$queuePop^STDCOLL(q)` | Dequeue at front; "" when empty. |
| `queuePush` | `do queuePush^STDCOLL(q, value)` | Enqueue at back. |
| `queueSize` | `$$queueSize^STDCOLL(q)` | Return queue length. |
| `setAdd` | `do setAdd^STDCOLL(s, value)` | Add value to set s (idempotent). |
| `setClear` | `do setClear^STDCOLL(s)` | Drop every member. |
| `setHas` | `$$setHas^STDCOLL(s, value)` | Return 1 iff value is a member of set s. |
| `setNext` | `$$setNext^STDCOLL(s, prev)` | Return the next member after prev in $order; "" at end. |
| `setRemove` | `do setRemove^STDCOLL(s, value)` | Remove value from set s; absent values are no-ops. |
| `setSize` | `$$setSize^STDCOLL(s)` | Return cardinality. |
| `stackClear` | `do stackClear^STDCOLL(s)` | Drop every entry. |
| `stackPeek` | `$$stackPeek^STDCOLL(s)` | Return the top without removal; "" when empty. |
| `stackPop` | `$$stackPop^STDCOLL(s)` | Remove and return the top; "" when empty. |
| `stackPush` | `do stackPush^STDCOLL(s, value)` | Push value on top of the stack. |
| `stackSize` | `$$stackSize^STDCOLL(s)` | Return depth. |

### `do dequeClear^STDCOLL(d)`

Drop every entry.

**Parameters**

- `d` _(array)_ — by-ref local

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"a") do dequeClear^STDCOLL(.d) do eq^STDASSERT(.pass,.fail,$$dequeSize^STDCOLL(.d),0,"dequeClear")
```

### `$$dequePeekBack^STDCOLL(d)`

Return back without removal; "" when empty.

**Parameters**

- `d` _(array)_ — by-ref local

**Returns** _string_ — back value; "" when empty

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"omega") do eq^STDASSERT(.pass,.fail,$$dequePeekBack^STDCOLL(.d),"omega","dequePeekBack")
```

### `$$dequePeekFront^STDCOLL(d)`

Return front without removal; "" when empty.

**Parameters**

- `d` _(array)_ — by-ref local

**Returns** _string_ — front value; "" when empty

**Example**

```m
new d do dequePushFront^STDCOLL(.d,"alpha") do eq^STDASSERT(.pass,.fail,$$dequePeekFront^STDCOLL(.d),"alpha","dequePeekFront")
```

### `$$dequePopBack^STDCOLL(d)`

Pop and return the back; "" when empty.

**Parameters**

- `d` _(array)_ — by-ref local

**Returns** _string_ — back value; "" when empty

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"a") do dequePushBack^STDCOLL(.d,"b") do eq^STDASSERT(.pass,.fail,$$dequePopBack^STDCOLL(.d),"b","dequePopBack")
```

### `$$dequePopFront^STDCOLL(d)`

Pop and return the front; "" when empty.

**Parameters**

- `d` _(array)_ — by-ref local

**Returns** _string_ — front value; "" when empty

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"a") do dequePushFront^STDCOLL(.d,"z") do eq^STDASSERT(.pass,.fail,$$dequePopFront^STDCOLL(.d),"z","dequePopFront")
```

### `do dequePushBack^STDCOLL(d, value)`

Push value at the back.

**Parameters**

- `d` _(array)_ — by-ref local
- `value` _(string)_ — value to push

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"omega") do eq^STDASSERT(.pass,.fail,$$dequePeekBack^STDCOLL(.d),"omega","dequePushBack")
```

### `do dequePushFront^STDCOLL(d, value)`

Push value at the front.

**Parameters**

- `d` _(array)_ — by-ref local; the deque
- `value` _(string)_ — value to push

**Example**

```m
new d do dequePushFront^STDCOLL(.d,"alpha") do eq^STDASSERT(.pass,.fail,$$dequePeekFront^STDCOLL(.d),"alpha","dequePushFront")
```

### `$$dequeSize^STDCOLL(d)`

Return deque length.

**Parameters**

- `d` _(array)_ — by-ref local

**Returns** _int_ — deque length

**Example**

```m
new d do dequePushBack^STDCOLL(.d,"a") do dequePushFront^STDCOLL(.d,"z") do eq^STDASSERT(.pass,.fail,$$dequeSize^STDCOLL(.d),2,"dequeSize")
```

### `do heapClear^STDCOLL(h)`

Drop every entry.

**Parameters**

- `h` _(array)_ — by-ref local

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"a") do heapClear^STDCOLL(.h) do eq^STDASSERT(.pass,.fail,$$heapSize^STDCOLL(.h),0,"heapClear")
```

### `$$heapPeek^STDCOLL(h)`

Return value at min key without removal; "" when empty.

**Parameters**

- `h` _(array)_ — by-ref local

**Returns** _string_ — payload at min key; "" when empty

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"low") do heapPush^STDCOLL(.h,1,"high") do eq^STDASSERT(.pass,.fail,$$heapPeek^STDCOLL(.h),"high","heapPeek")
```

### `$$heapPeekKey^STDCOLL(h)`

Return min key without removal; "" when empty.

**Parameters**

- `h` _(array)_ — by-ref local

**Returns** _num_ — min key; "" when empty

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"low") do heapPush^STDCOLL(.h,1,"high") do eq^STDASSERT(.pass,.fail,$$heapPeekKey^STDCOLL(.h),1,"heapPeekKey")
```

### `$$heapPop^STDCOLL(h)`

Pop value at the min key; "" when empty.

**Parameters**

- `h` _(array)_ — by-ref local

**Returns** _string_ — payload at the min key; "" when empty

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"low") do heapPush^STDCOLL(.h,1,"high") do eq^STDASSERT(.pass,.fail,$$heapPop^STDCOLL(.h),"high","heapPop")
```

### `$$heapPopKey^STDCOLL(h)`

Pop and return the min key; "" when empty.

**Parameters**

- `h` _(array)_ — by-ref local

**Returns** _num_ — min key; "" when empty

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"low") do heapPush^STDCOLL(.h,1,"high") do eq^STDASSERT(.pass,.fail,$$heapPopKey^STDCOLL(.h),1,"heapPopKey")
```

### `do heapPush^STDCOLL(h, key, value)`

Push (key, value) onto the heap.

**Parameters**

- `h` _(array)_ — by-ref local; the heap
- `key` _(num)_ — numeric priority (smaller = higher priority in min-heap)
- `value` _(string)_ — payload; defaults to key if omitted

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"task A") do eq^STDASSERT(.pass,.fail,$$heapPeek^STDCOLL(.h),"task A","heapPush")
```

### `$$heapSize^STDCOLL(h)`

Return heap size.

**Parameters**

- `h` _(array)_ — by-ref local

**Returns** _int_ — heap size

**Example**

```m
new h do heapPush^STDCOLL(.h,3,"a") do heapPush^STDCOLL(.h,1,"b") do eq^STDASSERT(.pass,.fail,$$heapSize^STDCOLL(.h),2,"heapSize")
```

### `do mapClear^STDCOLL(m)`

Drop every entry.

**Parameters**

- `m` _(array)_ — by-ref local

**Example**

```m
new m do mapPut^STDCOLL(.m,"a",1) do mapClear^STDCOLL(.m) do eq^STDASSERT(.pass,.fail,$$mapSize^STDCOLL(.m),0,"mapClear")
```

### `$$mapGet^STDCOLL(m, key, default)`

Return value at key; default if absent.

**Parameters**

- `m` _(array)_ — by-ref local
- `key` _(string)_ — map key
- `default` _(string)_ — fallback if key absent

**Returns** _string_ — stored value or default

**Example**

```m
new m do mapPut^STDCOLL(.m,"name","Alice") do eq^STDASSERT(.pass,.fail,$$mapGet^STDCOLL(.m,"name","none"),"Alice","mapGet")
new m do eq^STDASSERT(.pass,.fail,$$mapGet^STDCOLL(.m,"missing","none"),"none","mapGet default")
```

### `$$mapHas^STDCOLL(m, key)`

Return 1 iff key is set.

**Parameters**

- `m` _(array)_ — by-ref local
- `key` _(string)_ — candidate key

**Returns** _bool_ — 1 iff present; 0 otherwise

**Example**

```m
new m do mapPut^STDCOLL(.m,"name","Alice") do eq^STDASSERT(.pass,.fail,$$mapHas^STDCOLL(.m,"name"),1,"mapHas")
```

### `$$mapNext^STDCOLL(m, prev)`

Return next key after prev in $order; "" at end.

**Parameters**

- `m` _(array)_ — by-ref local
- `prev` _(string)_ — previous key ("" for first call)

**Returns** _string_ — next key; "" at end

**Example**

```m
new m do mapPut^STDCOLL(.m,"a",1) do eq^STDASSERT(.pass,.fail,$$mapNext^STDCOLL(.m,""),"a","mapNext")
```

### `do mapPut^STDCOLL(m, key, value)`

Store value at key (overwrites).

**Parameters**

- `m` _(array)_ — by-ref local; the map
- `key` _(string)_ — map key (empty silently ignored)
- `value` _(string)_ — value to store

**Example**

```m
new m do mapPut^STDCOLL(.m,"name","Alice") do eq^STDASSERT(.pass,.fail,$$mapGet^STDCOLL(.m,"name",""),"Alice","mapPut")
```

### `do mapRemove^STDCOLL(m, key)`

Drop key (no-op when absent).

**Parameters**

- `m` _(array)_ — by-ref local
- `key` _(string)_ — key to remove

**Example**

```m
new m do mapPut^STDCOLL(.m,"name","Alice") do mapRemove^STDCOLL(.m,"name") do eq^STDASSERT(.pass,.fail,$$mapHas^STDCOLL(.m,"name"),0,"mapRemove")
```

### `$$mapSize^STDCOLL(m)`

Return number of keys.

**Parameters**

- `m` _(array)_ — by-ref local

**Returns** _int_ — number of keys

**Example**

```m
new m do mapPut^STDCOLL(.m,"a",1) do mapPut^STDCOLL(.m,"b",2) do eq^STDASSERT(.pass,.fail,$$mapSize^STDCOLL(.m),2,"mapSize")
```

### `do odictClear^STDCOLL(o)`

Drop every entry.

**Parameters**

- `o` _(array)_ — by-ref local

**Example**

```m
new o do odictPut^STDCOLL(.o,"a",1) do odictClear^STDCOLL(.o) do eq^STDASSERT(.pass,.fail,$$odictSize^STDCOLL(.o),0,"odictClear")
```

### `$$odictFirst^STDCOLL(o)`

Return first key in insertion order; "" when empty.

**Parameters**

- `o` _(array)_ — by-ref local

**Returns** _string_ — first key; "" when empty

**Example**

```m
new o do odictPut^STDCOLL(.o,"first","1") do odictPut^STDCOLL(.o,"second","2") do eq^STDASSERT(.pass,.fail,$$odictFirst^STDCOLL(.o),"first","odictFirst")
```

### `$$odictGet^STDCOLL(o, key, default)`

Return value at key; default if absent.

**Parameters**

- `o` _(array)_ — by-ref local
- `key` _(string)_ — dict key
- `default` _(string)_ — fallback if key absent

**Returns** _string_ — stored value or default

**Example**

```m
new o do odictPut^STDCOLL(.o,"name","Alice") do eq^STDASSERT(.pass,.fail,$$odictGet^STDCOLL(.o,"name","none"),"Alice","odictGet")
```

### `$$odictHas^STDCOLL(o, key)`

Return 1 iff key is set.

**Parameters**

- `o` _(array)_ — by-ref local
- `key` _(string)_ — candidate key

**Returns** _bool_ — 1 iff present

**Example**

```m
new o do odictPut^STDCOLL(.o,"name","Alice") do eq^STDASSERT(.pass,.fail,$$odictHas^STDCOLL(.o,"name"),1,"odictHas")
```

### `$$odictLast^STDCOLL(o)`

Return last key in insertion order; "" when empty.

**Parameters**

- `o` _(array)_ — by-ref local

**Returns** _string_ — last key; "" when empty

**Example**

```m
new o do odictPut^STDCOLL(.o,"first","1") do odictPut^STDCOLL(.o,"second","2") do eq^STDASSERT(.pass,.fail,$$odictLast^STDCOLL(.o),"second","odictLast")
```

### `$$odictNext^STDCOLL(o, prev)`

Return next key (insertion order) after prev; "" at end.

**Parameters**

- `o` _(array)_ — by-ref local
- `prev` _(string)_ — previous key ("" for first call)

**Returns** _string_ — next key; "" at end

**Example**

```m
new o do odictPut^STDCOLL(.o,"first","1") do odictPut^STDCOLL(.o,"second","2") do eq^STDASSERT(.pass,.fail,$$odictNext^STDCOLL(.o,"first"),"second","odictNext")
```

### `$$odictPrev^STDCOLL(o, next)`

Return previous key (insertion order) before next; "" at start.

**Parameters**

- `o` _(array)_ — by-ref local
- `next` _(string)_ — next key ("" for last call)

**Returns** _string_ — previous key; "" at start

**Example**

```m
new o do odictPut^STDCOLL(.o,"first","1") do odictPut^STDCOLL(.o,"second","2") do eq^STDASSERT(.pass,.fail,$$odictPrev^STDCOLL(.o,"second"),"first","odictPrev")
```

### `do odictPut^STDCOLL(o, key, value)`

Store value at key; create-or-update preserving position.

**Parameters**

- `o` _(array)_ — by-ref local; the ordered dict
- `key` _(string)_ — dict key (empty silently ignored)
- `value` _(string)_ — value to store

**Example**

```m
new o do odictPut^STDCOLL(.o,"name","Alice") do eq^STDASSERT(.pass,.fail,$$odictGet^STDCOLL(.o,"name",""),"Alice","odictPut")
```

### `do odictRemove^STDCOLL(o, key)`

Drop key (no-op when absent).

**Parameters**

- `o` _(array)_ — by-ref local
- `key` _(string)_ — key to remove

**Example**

```m
new o do odictPut^STDCOLL(.o,"name","Alice") do odictRemove^STDCOLL(.o,"name") do eq^STDASSERT(.pass,.fail,$$odictHas^STDCOLL(.o,"name"),0,"odictRemove")
```

### `$$odictSize^STDCOLL(o)`

Return number of keys.

**Parameters**

- `o` _(array)_ — by-ref local

**Returns** _int_ — number of keys

**Example**

```m
new o do odictPut^STDCOLL(.o,"a",1) do odictPut^STDCOLL(.o,"b",2) do eq^STDASSERT(.pass,.fail,$$odictSize^STDCOLL(.o),2,"odictSize")
```

### `do queueClear^STDCOLL(q)`

Drop every entry.

**Parameters**

- `q` _(array)_ — by-ref local

**Example**

```m
new q do queuePush^STDCOLL(.q,"a") do queueClear^STDCOLL(.q) do eq^STDASSERT(.pass,.fail,$$queueSize^STDCOLL(.q),0,"queueClear")
```

### `$$queuePeek^STDCOLL(q)`

Return front without removal; "" when empty.

**Parameters**

- `q` _(array)_ — by-ref local

**Returns** _string_ — front value; "" when empty

**Example**

```m
new q do queuePush^STDCOLL(.q,"alpha") do eq^STDASSERT(.pass,.fail,$$queuePeek^STDCOLL(.q),"alpha","queuePeek")
```

### `$$queuePop^STDCOLL(q)`

Dequeue at front; "" when empty.

**Parameters**

- `q` _(array)_ — by-ref local

**Returns** _string_ — front value; "" when empty

**Example**

```m
new q do queuePush^STDCOLL(.q,"alpha") do queuePush^STDCOLL(.q,"beta") do eq^STDASSERT(.pass,.fail,$$queuePop^STDCOLL(.q),"alpha","queuePop")
```

### `do queuePush^STDCOLL(q, value)`

Enqueue at back.

**Parameters**

- `q` _(array)_ — by-ref local; the queue
- `value` _(string)_ — value to enqueue

**Example**

```m
new q do queuePush^STDCOLL(.q,"alpha") do eq^STDASSERT(.pass,.fail,$$queuePeek^STDCOLL(.q),"alpha","queuePush")
```

### `$$queueSize^STDCOLL(q)`

Return queue length.

**Parameters**

- `q` _(array)_ — by-ref local

**Returns** _int_ — queue length

**Example**

```m
new q do queuePush^STDCOLL(.q,"a") do queuePush^STDCOLL(.q,"b") do eq^STDASSERT(.pass,.fail,$$queueSize^STDCOLL(.q),2,"queueSize")
```

### `do setAdd^STDCOLL(s, value)`

Add value to set s (idempotent).

**Parameters**

- `s` _(array)_ — by-ref local; the set
- `value` _(string)_ — member to add (empty string is silently ignored)

**Example**

```m
new s do setAdd^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$setHas^STDCOLL(.s,"alpha"),1,"setAdd")
```

### `do setClear^STDCOLL(s)`

Drop every member.

**Parameters**

- `s` _(array)_ — by-ref local

**Example**

```m
new s do setAdd^STDCOLL(.s,"a") do setClear^STDCOLL(.s) do eq^STDASSERT(.pass,.fail,$$setSize^STDCOLL(.s),0,"setClear")
```

### `$$setHas^STDCOLL(s, value)`

Return 1 iff value is a member of set s.

**Parameters**

- `s` _(array)_ — by-ref local; the set
- `value` _(string)_ — candidate member

**Returns** _bool_ — 1 iff value is a member; 0 otherwise

**Example**

```m
new s do setAdd^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$setHas^STDCOLL(.s,"alpha"),1,"setHas")
```

### `$$setNext^STDCOLL(s, prev)`

Return the next member after prev in $order; "" at end.

**Parameters**

- `s` _(array)_ — by-ref local
- `prev` _(string)_ — previous member ("" for first call)

**Returns** _string_ — next member; "" at end

**Example**

```m
new s do setAdd^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$setNext^STDCOLL(.s,""),"alpha","setNext")
```

### `do setRemove^STDCOLL(s, value)`

Remove value from set s; absent values are no-ops.

**Parameters**

- `s` _(array)_ — by-ref local; the set
- `value` _(string)_ — member to remove

**Example**

```m
new s do setAdd^STDCOLL(.s,"alpha") do setRemove^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$setHas^STDCOLL(.s,"alpha"),0,"setRemove")
```

### `$$setSize^STDCOLL(s)`

Return cardinality.

**Parameters**

- `s` _(array)_ — by-ref local

**Returns** _int_ — cardinality

**Example**

```m
new s do setAdd^STDCOLL(.s,"a") do setAdd^STDCOLL(.s,"b") do eq^STDASSERT(.pass,.fail,$$setSize^STDCOLL(.s),2,"setSize")
```

### `do stackClear^STDCOLL(s)`

Drop every entry.

**Parameters**

- `s` _(array)_ — by-ref local

**Example**

```m
new s do stackPush^STDCOLL(.s,"a") do stackClear^STDCOLL(.s) do eq^STDASSERT(.pass,.fail,$$stackSize^STDCOLL(.s),0,"stackClear")
```

### `$$stackPeek^STDCOLL(s)`

Return the top without removal; "" when empty.

**Parameters**

- `s` _(array)_ — by-ref local

**Returns** _string_ — top value; "" when empty

**Example**

```m
new s do stackPush^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$stackPeek^STDCOLL(.s),"alpha","stackPeek")
```

### `$$stackPop^STDCOLL(s)`

Remove and return the top; "" when empty.

**Parameters**

- `s` _(array)_ — by-ref local

**Returns** _string_ — top value; "" when empty

**Example**

```m
new s do stackPush^STDCOLL(.s,"alpha") do stackPush^STDCOLL(.s,"beta") do eq^STDASSERT(.pass,.fail,$$stackPop^STDCOLL(.s),"beta","stackPop")
```

### `do stackPush^STDCOLL(s, value)`

Push value on top of the stack.

**Parameters**

- `s` _(array)_ — by-ref local; the stack
- `value` _(string)_ — value to push

**Example**

```m
new s do stackPush^STDCOLL(.s,"alpha") do eq^STDASSERT(.pass,.fail,$$stackPeek^STDCOLL(.s),"alpha","stackPush")
```

### `$$stackSize^STDCOLL(s)`

Return depth.

**Parameters**

- `s` _(array)_ — by-ref local

**Returns** _int_ — stack depth

**Example**

```m
new s do stackPush^STDCOLL(.s,"a") do stackPush^STDCOLL(.s,"b") do eq^STDASSERT(.pass,.fail,$$stackSize^STDCOLL(.s),2,"stackSize")
```

<!-- END GENERATED API REFERENCE -->

## Public API

| Type | Operations | Empty-pop / -peek |
|---|---|---|
| Set | `setAdd` `setHas` `setRemove` `setSize` `setClear` `setNext` | n/a |
| Map | `mapPut` `mapGet` `mapHas` `mapRemove` `mapSize` `mapClear` `mapNext` | n/a |
| Stack | `stackPush` `stackPop` `stackPeek` `stackSize` `stackClear` | returns `""` |
| Queue | `queuePush` `queuePop` `queuePeek` `queueSize` `queueClear` | returns `""` |
| Deque | `dequePushFront` `dequePushBack` `dequePopFront` `dequePopBack` `dequePeekFront` `dequePeekBack` `dequeSize` `dequeClear` | returns `""` |
| Heap | `heapPush` `heapPop` `heapPopKey` `heapPeek` `heapPeekKey` `heapSize` `heapClear` | returns `""` |
| OrderedDict | `odictPut` `odictGet` `odictHas` `odictRemove` `odictSize` `odictClear` `odictFirst` `odictLast` `odictNext` `odictPrev` | n/a |

Side-effect calls (push/put/add/remove/clear) are procedure-form
(`do …`). Read-form calls (get/has/peek/size/next/pop) are extrinsic
(`$$ …`). `pop` is the only side-effect call that is also extrinsic
because the value being removed is its return.

## Examples

```m
; Set — membership over an unordered collection.
NEW seen
DO setAdd^STDCOLL(.seen,"alpha")
DO setAdd^STDCOLL(.seen,"beta")
WRITE $$setHas^STDCOLL(.seen,"alpha"),!     ; 1
WRITE $$setSize^STDCOLL(.seen),!            ; 2

; Map — string-keyed dictionary with default fallback.
NEW cfg
DO mapPut^STDCOLL(.cfg,"host","localhost")
WRITE $$mapGet^STDCOLL(.cfg,"host","unset"),!   ; localhost
WRITE $$mapGet^STDCOLL(.cfg,"port","8080"),!    ; 8080  (default)

; Stack — depth-first traversal scratchpad.
NEW todo
DO stackPush^STDCOLL(.todo,"A")
DO stackPush^STDCOLL(.todo,"B")
WRITE $$stackPop^STDCOLL(.todo),!           ; B
WRITE $$stackPop^STDCOLL(.todo),!           ; A

; Queue — work pipeline.
NEW work
DO queuePush^STDCOLL(.work,"first")
DO queuePush^STDCOLL(.work,"second")
WRITE $$queuePop^STDCOLL(.work),!           ; first
WRITE $$queuePop^STDCOLL(.work),!           ; second

; Deque — sliding window with both-ends churn.
NEW win
DO dequePushBack^STDCOLL(.win,1)
DO dequePushBack^STDCOLL(.win,2)
DO dequePushBack^STDCOLL(.win,3)
DO dequePopFront^STDCOLL(.win)              ; drop oldest
WRITE $$dequePeekFront^STDCOLL(.win),!      ; 2

; Heap — priority queue (smallest key first).
NEW pq
DO heapPush^STDCOLL(.pq,3,"task A")
DO heapPush^STDCOLL(.pq,1,"task B")
DO heapPush^STDCOLL(.pq,2,"task C")
WRITE $$heapPop^STDCOLL(.pq),!              ; task B  (key 1)
WRITE $$heapPop^STDCOLL(.pq),!              ; task C  (key 2)
WRITE $$heapPop^STDCOLL(.pq),!              ; task A  (key 3)

; OrderedDict — insertion order preserved across updates.
NEW od,k
DO odictPut^STDCOLL(.od,"name","Alice")
DO odictPut^STDCOLL(.od,"role","admin")
DO odictPut^STDCOLL(.od,"name","Alice S.")  ; update — keeps slot
SET k=$$odictFirst^STDCOLL(.od)
FOR  QUIT:k=""  WRITE k,"=",$$odictGet^STDCOLL(.od,k,""),!  SET k=$$odictNext^STDCOLL(.od,k)
;   name=Alice S.
;   role=admin
```

## Behaviour

| Detail | Behaviour |
|---|---|
| Storage | By-reference local; reserved subscripts under each variable: `("v",…)`, `("n")`, `("h")`, `("t")`, `("k",…)`, `("seq",…)`, `("ord",…)`, `("nseq")`. |
| Idempotence | `setAdd` of an existing member, `mapPut` / `odictPut` of an existing key are silent updates; size does not change. `setRemove` / `mapRemove` / `odictRemove` of an absent key is a no-op. |
| Empty-string keys | `setAdd("")`, `mapPut("",…)`, `odictPut("",…)` are silent no-ops — M's `$order` cannot enumerate the empty subscript so the API would not be able to round-trip them. |
| Empty pop / peek | `stackPop` / `stackPeek`, `queuePop` / `queuePeek`, `dequePop*` / `dequePeek*`, `heapPop` / `heapPopKey` / `heapPeek` / `heapPeekKey` return `""` when the collection is empty rather than raising. Callers gate on `*Size` when they need to distinguish empty from a stored `""`. |
| Heap ordering | Min-heap on numeric keys (M's `<` operator). The optional `value` defaults to the key, so the heap-of-numbers and priority-queue-with-payload forms share one entry point. |
| OrderedDict ordering | Insertion order. Updating an existing key keeps its slot; removing skips its slot in subsequent walks. Sequence numbers (`("nseq")`) are monotonic and never reused. |
| Reset | `kill <var>` is equivalent to `*Clear`. Every entry point reads counters via `$get(…,0)` so a fresh / killed variable is indistinguishable from a `*Clear`-ed one. |

## Complexity

| Operation | Cost |
|---|---|
| Set / Map / OrderedDict by key | `O(log n)` (M B-tree subscript lookup) |
| Set / Map iteration step | `O(log n)` per `*Next` call |
| Stack push / pop / peek | `O(1)` |
| Queue / Deque push / pop / peek | `O(1)` (head/tail indices, no shifting) |
| Heap push / pop | `O(log n)` (sift-up / sift-down) |
| Heap peek / peekKey | `O(1)` |
| OrderedDict put (new) / remove | `O(log n)` |
| OrderedDict put (existing key) | `O(log n)` — value updated in place, slot retained |
| OrderedDict first / last | `O(log n)` (`$order` of the sequence index) |

## Edge cases

- **Empty input.** All `*Size` calls return 0 for an undefined,
  freshly-`new`'d, or just-`*Clear`-ed variable.
- **Heap value defaulting.** `heapPush(.h, 5)` and
  `heapPush(.h, 5, "")` are different: the first stores the key as
  the value (so `heapPop` returns `5`); the second stores `""`
  explicitly (so `heapPop` returns `""`). The default fires only
  when `value` is undefined per `$data`.
- **Heap with non-numeric keys.** `<` coerces operands to numeric;
  non-numeric strings collapse to `0`. Pass numeric keys.
- **Queue / Deque index drift.** Head and tail indices grow
  monotonically across pushes and pops. They reset to `(1, 0)`
  whenever the collection drains (the last pop kills the variable),
  so long-running queues do not accumulate state.
- **OrderedDict update vs. re-insert.** To move an existing key to
  the back, call `odictRemove` then `odictPut`. A bare `odictPut`
  preserves the original slot.
- **Stale subscripts.** `*Clear` always uses `kill <var>`, dropping
  every reserved subscript. Callers may safely re-use the same
  variable for a different collection type after a clear.

## See also

- `STDARGS` for parsed argument storage that pairs naturally with
  `mapGet` / `odictPut` for sub-command dispatch tables.
- `STDJSON` (Phase 2) for serialising / deserialising these
  collections to and from on-disk JSON once the parser ships.
