---
module: STDHTTPD
tag: v0.11.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.11.0
synopsis: 'portable HTTP server framework (router + middleware + worker loop)'
labels: ['dispatch', 'match', 'noop', 'requestId', 'route', 'serve', 'use']
errors: []
conformance: []
see_also: ['STDHTTPMSG']
---

# `STDHTTPD` — portable HTTP server framework (router + middleware + worker loop)

The engine-agnostic half of m-stdlib's VistA-native HTTPS stack (the VWEB
capstone). `STDHTTPD` is the §6 route-match engine, the §6/§7 middleware
chain, and the §4 per-connection worker request/response loop — all pure-M.
It sits directly on the M6.1 `STDHTTPMSG` codec (parse/serialize) and *below*
the VistA-specific `vweb` listener (`VWEBL`/`VWEBIO`, M6.3+). There are no
sockets, no TLS, no VistA, no FileMan, no XPAR, and no `$ZF` in this module:
the transport, the route table, the worker limits, and the log hook are all
**injected** by the caller, so the engine-sensitive socket handoff stays one
layer up in `VWEBL`.

Three design seams keep it portable:

- **Transport is injected.** `$$serve` never touches a socket. The caller
  passes a transport descriptor `TR` whose `TR("read")` / `TR("write")` hold
  entry-refs, plus an opaque `conn` handle. STDHTTPD reaches the wire only via
  `set n=$$@TR("read")(conn,max,timeout,.buf)` and `$$@TR("write")(conn,bytes)`
  — the same signatures `STDNET`'s `$$read`/`$$write` use, so `VWEBL` can hand
  a real socket transport down unchanged; tests drive an in-memory fake.
- **Handlers and middleware are `TAG^ROUTINE` refs** invoked by M indirection
  with a fixed by-ref signature — handler `do @ref(.REQ,.RSP)`, middleware
  `do @ref(.REQ,.RSP,.CTX)` (may set `CTX("stop")=1` to short-circuit).
- **The route table is caller-owned data** (the `SRV` local array), never
  FileMan — `VWEBR` sources routes from a FileMan file and registers them into
  this same array.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `dispatch` | `$$dispatch^STDHTTPD(SRV, REQ, RSP, opts)` | Run one parsed request through middleware -> route -> handler. |
| `match` | `$$match^STDHTTPD(SRV, method, path, route, params)` | Match a method+path against the route table. |
| `noop` | `do noop^STDHTTPD(REQ, RSP, CTX)` | Built-in no-op middleware (a placeholder / chain probe). |
| `requestId` | `do requestId^STDHTTPD(REQ, RSP, CTX)` | Built-in middleware: stamp a per-request correlation id into CTX. |
| `route` | `$$route^STDHTTPD(SRV, method, pattern, handler, opts)` | Register a route into the caller-owned SRV table. |
| `serve` | `$$serve^STDHTTPD(SRV, TR, conn, opts)` | Run the full HTTP exchange for one connection over the injected transport. |
| `use` | `$$use^STDHTTPD(SRV, mwref, opts)` | Register a middleware ref (run in registration order before the handler). |

### `$$dispatch^STDHTTPD(SRV, REQ, RSP, opts)`

Run one parsed request through middleware -> route -> handler.

**Parameters**

- `SRV` _(array)_ — by-ref route table + middleware chain
- `REQ` _(array)_ — by-ref parsed request (spec §5.1)
- `RSP` _(array)_ — by-ref; populated with the response (spec §5.2)
- `opts` _(array)_ — by-ref; opts("logref") = injected log hook ref do @ref(.EV); optional

**Returns** _numeric_ — the final HTTP status (200 handler-ok / 404 / 405 / 401.. / 500)

**Example**

```m
new SRV,REQ,RSP do route^STDHTTPD(.SRV,"GET","/healthz","noop^STDHTTPD") set REQ("method")="GET",REQ("path")="/healthz" do eq^STDASSERT(.pass,.fail,$$dispatch^STDHTTPD(.SRV,.REQ,.RSP),200,"matched route, handler returned cleanly -> 200")
new SRV,REQ,RSP do route^STDHTTPD(.SRV,"GET","/healthz","noop^STDHTTPD") set REQ("method")="GET",REQ("path")="/nope" do eq^STDASSERT(.pass,.fail,$$dispatch^STDHTTPD(.SRV,.REQ,.RSP),404,"no matching route -> 404 sanitized")
```

### `$$match^STDHTTPD(SRV, method, path, route, params)`

Match a method+path against the route table.

**Parameters**

- `SRV` _(array)_ — by-ref route table populated by $$route
- `method` _(string)_ — request verb
- `path` _(string)_ — decoded request path (REQ("path"))
- `route` _(array)_ — by-ref; on 200 filled with method/pattern/handler/idx/opt; on 405 filled with allow
- `params` _(array)_ — by-ref; on 200 filled with the captured :named segments (+ "*")

**Returns** _numeric_ — 200 match; 404 no path matched; 405 path matched but method did not

**Example**

```m
new SRV,route,params do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") do eq^STDASSERT(.pass,.fail,$$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params),200,"method+path hit -> 200")
new SRV,route,params,st do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") set st=$$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params) do eq^STDASSERT(.pass,.fail,params("id"),"123","named :id segment captured into params")
new SRV,route,params do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") do eq^STDASSERT(.pass,.fail,$$match^STDHTTPD(.SRV,"GET","/nope",.route,.params),404,"no path matched -> 404")
new SRV,route,params,st do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP") set st=$$match^STDHTTPD(.SRV,"POST","/Patient/123",.route,.params) do eq^STDASSERT(.pass,.fail,route("allow"),"GET","path matched but method did not -> 405 fills Allow")
```

### `do noop^STDHTTPD(REQ, RSP, CTX)`

Built-in no-op middleware (a placeholder / chain probe).

**Parameters**

- `REQ` _(array)_ — by-ref request
- `RSP` _(array)_ — by-ref response
- `CTX` _(array)_ — by-ref pipeline context (untouched)

**Example**

```m
new REQ,RSP,CTX do noop^STDHTTPD(.REQ,.RSP,.CTX) do false^STDASSERT(.pass,.fail,$data(CTX),"no-op leaves CTX untouched")
```

### `do requestId^STDHTTPD(REQ, RSP, CTX)`

Built-in middleware: stamp a per-request correlation id into CTX.

**Parameters**

- `REQ` _(array)_ — by-ref request
- `RSP` _(array)_ — by-ref response
- `CTX` _(array)_ — by-ref pipeline context; sets CTX("requestid")

**Example**

```m
new REQ,RSP,CTX do requestId^STDHTTPD(.REQ,.RSP,.CTX) do true^STDASSERT(.pass,.fail,$get(CTX("requestid"))'="","stamps a non-empty correlation id (value varies per run)")
```

### `$$route^STDHTTPD(SRV, method, pattern, handler, opts)`

Register a route into the caller-owned SRV table.

**Parameters**

- `SRV` _(array)_ — by-ref route table (caller-owned; VWEBR sources it from FileMan later)
- `method` _(string)_ — HTTP verb, or "*" to match any verb
- `pattern` _(string)_ — path pattern: literal + :named segments + optional trailing *
- `handler` _(string)_ — TAG^ROUTINE handler ref, invoked do @handler(.REQ,.RSP)
- `opts` _(array)_ — by-ref per-route opts (e.g. auth/scope — consumed by middleware); optional

**Returns** _numeric_ — the new route's index

**Example**

```m
new SRV do eq^STDASSERT(.pass,.fail,$$route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP"),1,"first route registered -> index 1")
```

### `$$serve^STDHTTPD(SRV, TR, conn, opts)`

Run the full HTTP exchange for one connection over the injected transport.

**Parameters**

- `SRV` _(array)_ — by-ref route table + middleware chain
- `TR` _(array)_ — by-ref transport descriptor: TR("read")/TR("write") entry-refs
- `conn` _(string)_ — opaque connection handle passed to the transport refs
- `opts` _(array)_ — by-ref injected limits + logref (maxhdrbytes/maxbody/maxrequests/idletimeout/logref); optional

**Returns** _numeric_ — the number of requests served on this connection

**Example**

```m
set n=$$serve^STDHTTPD(.SRV,.TR,conn,.opts)
```

### `$$use^STDHTTPD(SRV, mwref, opts)`

Register a middleware ref (run in registration order before the handler).

**Parameters**

- `SRV` _(array)_ — by-ref route table / server config
- `mwref` _(string)_ — TAG^ROUTINE middleware ref, invoked do @mwref(.REQ,.RSP,.CTX)
- `opts` _(array)_ — by-ref per-middleware opts; optional

**Returns** _numeric_ — the new middleware's index (its run order)

**Example**

```m
new SRV do eq^STDASSERT(.pass,.fail,$$use^STDHTTPD(.SRV,"requestId^STDHTTPD"),1,"first middleware registered -> run order 1")
```

<!-- END GENERATED API REFERENCE -->

## Status

Shipped in **v0.11.0** (VSL/MSL M6.2). **Pure-M and dual-engine GREEN** — bare
YottaDB (`m-test-engine`) and bare IRIS (`m-test-iris`), 39/39. It carries the
`@seam STDHTTPD` contract (`contract_version` 1). The `STDHTTPMSG` codec below
it (`$$parseReq` / `$$serializeRsp`) is the M6.1 portability seam this module
binds to.

## Public API

### `$$route` / `route` — register a route

```m
set i=$$route^STDHTTPD(.SRV,method,pattern,handler,.opts)
do route^STDHTTPD(.SRV,method,pattern,handler,.opts)
```

Registers a route into the caller-owned `SRV` table and returns the new
route's index. Usable as an extrinsic (returns the index) or as a `do`
side-effect (the `$quit` guard handles both).

- **`SRV`** *(array, by-ref)* — the route table (caller-owned; `VWEBR` sources
  it from FileMan later).
- **`method`** *(string)* — HTTP verb, or `"*"` to match any verb.
- **`pattern`** *(string)* — path pattern: literal + `:named` segments + an
  optional trailing `*` wildcard. Trailing slashes are insignificant.
- **`handler`** *(string)* — `TAG^ROUTINE` handler ref, invoked
  `do @handler(.REQ,.RSP)`.
- **`opts`** *(array, by-ref, optional)* — per-route opts (e.g. auth/scope,
  consumed by middleware); merged under `SRV("route",n,"opt")` and surfaced
  back through `$$match` as `route("opt")`.
- **Returns** *(numeric)* — the new route's index. First-registered route wins
  on overlap.

```m
new SRV
do route^STDHTTPD(.SRV,"GET","/Patient/:id","get^MYAPP")
do route^STDHTTPD(.SRV,"POST","/Patient","create^MYAPP")
```

### `$$match` — match a method + path against the table

```m
set st=$$match^STDHTTPD(.SRV,method,path,.route,.params)
```

- **`SRV`** *(array, by-ref)* — route table populated by `$$route`.
- **`method`** *(string)* — request verb.
- **`path`** *(string)* — decoded request path (`REQ("path")`).
- **`route`** *(array, by-ref)* — on 200, filled with `idx` / `method` /
  `pattern` / `handler` / `opt`; on 405, filled with `allow` (a comma-joined
  `Allow` list).
- **`params`** *(array, by-ref)* — on 200, filled with the captured `:named`
  segments (and `"*"` for a trailing-wildcard remainder).
- **Returns** *(numeric)* — `200` match, `404` no path matched, `405` path
  matched but the method did not.

```m
new route,params
if $$match^STDHTTPD(.SRV,"GET","/Patient/123",.route,.params)=200 do
. write route("handler"),! ; get^MYAPP
. write params("id"),!     ; 123
```

### `$$use` / `use` — register a middleware

```m
set i=$$use^STDHTTPD(.SRV,mwref,.opts)
do use^STDHTTPD(.SRV,mwref,.opts)
```

Registers a middleware ref that runs in registration order *before* the
handler, and returns its index (its run order). Like `$$route`, usable as `$$`
or `do`.

- **`SRV`** *(array, by-ref)* — route table / server config.
- **`mwref`** *(string)* — `TAG^ROUTINE` middleware ref, invoked
  `do @mwref(.REQ,.RSP,.CTX)`.
- **`opts`** *(array, by-ref, optional)* — per-middleware opts.
- **Returns** *(numeric)* — the new middleware's index.

```m
do use^STDHTTPD(.SRV,"requestId^STDHTTPD")
do use^STDHTTPD(.SRV,"authn^MYAPP")
```

### `$$dispatch` — run one parsed request

```m
set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP,.opts)
```

Runs one already-parsed request through the pipeline:
**middleware → match → handler → RSP**. Middleware run in registration order;
any may short-circuit by setting `CTX("stop")=1` (and populating `RSP`) so the
handler never runs. A non-200 middleware return, or an uncaught
middleware/handler fault, becomes a sanitized **500** (detail goes only to the
log hook). An unmatched route is **404**; a method mismatch is **405** with an
`Allow` header.

- **`SRV`** *(array, by-ref)* — route table + middleware chain.
- **`REQ`** *(array, by-ref)* — parsed request (the `STDHTTPMSG` §5.1 shape).
- **`RSP`** *(array, by-ref)* — populated with the response (§5.2 shape).
- **`opts`** *(array, by-ref, optional)* — `opts("logref")` is an injected log
  hook ref, invoked `do @ref(.EV)` on a fault (default: no-op).
- **Returns** *(numeric)* — the final HTTP status (`200` handler-ok, or `404` /
  `405` / a middleware-set status / `500`).

```m
new RSP
set st=$$dispatch^STDHTTPD(.SRV,.REQ,.RSP,.opts)
write "status: ",st,!
```

### `$$serve` — the worker request/response loop

```m
set n=$$serve^STDHTTPD(.SRV,.TR,conn,.opts)
```

Runs the full HTTP exchange for one connection over the injected transport and
returns the number of requests served. It reads a complete request over `TR`
(honoring `Content-Length` / chunked framing), parses it with
`$$parseReq^STDHTTPMSG`, dispatches it, serializes the response with
`$$serializeRsp^STDHTTPMSG`, writes it back via `TR`, then loops the cycle
until `Connection: close`, a clean peer close, an idle timeout, or the
max-requests-per-connection cap. A parse/framing error yields the matching 4xx
response, then closes.

- **`SRV`** *(array, by-ref)* — route table + middleware chain.
- **`TR`** *(array, by-ref)* — transport descriptor: `TR("read")` and
  `TR("write")` entry-refs.
- **`conn`** *(string)* — opaque connection handle, passed to the transport
  refs.
- **`opts`** *(array, by-ref, optional)* — injected limits + log hook:
  `maxhdrbytes` (default 16384), `maxbody` (default 1048576), `maxrequests`
  (default 100), `idletimeout` (default 30), `logref`.
- **Returns** *(numeric)* — the number of requests served on this connection.

```m
new SRV,TR
do route^STDHTTPD(.SRV,"GET","/health","health^MYAPP")
set TR("read")="read^MYXPORT",TR("write")="write^MYXPORT"
set n=$$serve^STDHTTPD(.SRV,.TR,conn) ; conn served n requests
```

### `requestId` — built-in middleware

```m
do requestId^STDHTTPD(.REQ,.RSP,.CTX)
```

Stamps a per-request correlation id into `CTX("requestid")` (built from `$JOB`,
the seconds field of `$HOROLOG`, and an `$INCREMENT` sequence counter under
`^STDLIB($job,"httpd","seq")`). Register it with `do use^STDHTTPD(.SRV,"requestId^STDHTTPD")`.

### `noop` — built-in no-op middleware

```m
do noop^STDHTTPD(.REQ,.RSP,.CTX)
```

A placeholder / chain probe that returns immediately, leaving `CTX` untouched.
Useful as a registration-order or middleware-wiring test.

## Request flow

`$$serve` drives one connection; `$$dispatch` runs one request inside it:

1. **Read + frame** — `$$serve` accumulates bytes over `TR("read")` until a
   complete request is framed (header terminator + `Content-Length` or chunked
   body), capped by `maxhdrbytes` / `maxbody`. A clean close ends the loop; a
   framing/cap error closes with `400` / `413` / `431`.
2. **Parse** — `$$parseReq^STDHTTPMSG` turns the framed bytes into `REQ`. A
   parse status (`400`/`413`/`414`/`431`) closes with the matching error.
3. **Middleware** — each registered `mwref` runs in order; any may set
   `CTX("stop")=1` (and `RSP`) to short-circuit, or fault → sanitized `500`.
4. **Match** — `$$match` resolves `method`+`path` → handler (`200`), or `404` /
   `405`+`Allow`. Captured `:named` segments are merged into `REQ("param")`.
5. **Handler** — `do @handler(.REQ,.RSP)`, run under the fault trap; a fault →
   sanitized `500`.
6. **Serialize + write** — `$$serializeRsp^STDHTTPMSG` builds the wire bytes,
   written via `TR("write")`.
7. **Keep-alive** — the loop continues unless the request asked to close, the
   handler forced a close (`Connection: close` or `RSP("keepalive")=0`), or the
   `maxrequests` cap is hit.

## Notes & gotchas

- **Faults never leak detail into the body.** A middleware/handler fault
  produces a `500` with a sanitized JSON body (`{"error": "Internal Server
  Error"}`); the internal `$zstatus`/`$zerror` detail goes *only* to the
  injected `opts("logref")` hook, never to the HTTP response.
- **Per-engine fault trapping.** Handler/middleware faults are caught with a
  flag-based `$ETRAP` on YottaDB (**never** `zgoto` — the M4 harness-abort
  gotcha). On **IRIS the worker uses an ObjectScript `try`/`catch` reading
  `$zerror`** instead, forked on `$zversion["IRIS"`: a flag-`$ETRAP`/`$zstatus`
  arm does not catch IRIS faults, and referencing `$zstatus` inside an IRIS
  catch would itself raise and re-abort the trap. The trapped call is run via
  full-command indirection because YDB rejects `do @ref(args)`; by-ref args
  (`REQ`/`RSP`/`CTX`) are kept top-level so they survive the IRIS `xecute`
  boundary.
- **Pattern matching.** Patterns are literal segments + `:named` captures + an
  optional trailing `*` wildcard (which captures the path remainder under
  `params("*")`). Trailing slashes are insignificant (paths and patterns are
  normalized), and the **first-registered** route wins on overlap.
- **Method `"*"`.** A route registered with method `"*"` matches any verb; a
  path that matches some route but not the requested verb returns `405` with a
  comma-joined `Allow` header listing the methods that *would* match.
- **All limits are injected, never XPAR.** `maxhdrbytes` / `maxbody` /
  `maxrequests` / `idletimeout` come from `opts` with safe defaults — STDHTTPD
  reads no configuration files and no VistA parameters.
- **Bodies are byte strings.** Framing is byte-exact and CRLF-faithful; the
  codec below (`STDHTTPMSG`) and the engine should be run in byte (M) mode so
  `\r\n\r\n` terminators and binary payloads are not transcoded.

## See also

- [`STDHTTPMSG`](stdhttpmsg.md) — the HTTP/1.1 parse/serialize codec
  (`$$parseReq` / `$$serializeRsp`) this framework sits on.
- [`STDNET`](stdnet.md) — the raw socket transport whose `$$read`/`$$write`
  signatures the injected `TR` descriptor mirrors.
- [`STDHTTP`](stdhttp.md) — the HTTP/1.1 *client* (the request-side companion).
