---
module: STDPROF
tag: v0.3.0
phase: P4 wave
stable: stable
since: v0.3.0
synopsis: 'Wall-clock profiler with per-tag aggregates + percentiles'
labels: ['clear', 'count', 'max', 'mean', 'min', 'new', 'percentile', 'start', 'stop', 'tags', 'total']
errors: []
conformance: []
see_also: []
---

# `STDPROF` — Wall-clock profiler

A small, caller-owned profiler: per-tag start/stop timers,
aggregate count / total / mean / min / max, and percentiles
computed from a sorted-by-value sample tree. Drop into any code
path you want to instrument; pass the profiler array by reference;
inspect on demand.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `clear` | `do clear^STDPROF(prof)` | Drop every tag's data; preserves nothing. |
| `count` | `$$count^STDPROF(prof, tag)` | Return number of completed cycles for tag; 0 if untracked. |
| `max` | `$$max^STDPROF(prof, tag)` | Return slowest sample; 0 if no cycles. |
| `mean` | `$$mean^STDPROF(prof, tag)` | Return total\count (integer floor); 0 if no cycles. |
| `min` | `$$min^STDPROF(prof, tag)` | Return fastest sample; 0 if no cycles. |
| `new` | `do new^STDPROF(prof)` | Initialise / wipe the profiler. |
| `percentile` | `$$percentile^STDPROF(prof, tag, p)` | Return the p-th percentile sample (0..100). |
| `start` | `do start^STDPROF(prof, tag)` | Open a timer for tag. Stamps prof("active",tag) with $ZHOROLOG. |
| `stop` | `do stop^STDPROF(prof, tag)` | Close the timer; record one sample. No-op if no matching start. |
| `tags` | `$$tags^STDPROF(prof, out)` | Populate out(1..N) with tag names that have at least one cycle. |
| `total` | `$$total^STDPROF(prof, tag)` | Return sum of elapsed microseconds across all cycles; 0 if untracked. |

### `do clear^STDPROF(prof)`

Drop every tag's data; preserves nothing.

**Parameters**

- `prof` _(array)_ — by-ref local

**Example**

```m
new p set p("count","x")=5 do clear^STDPROF(.p) do false^STDASSERT(.pass,.fail,$data(p),"clear drops all data")
```

### `$$count^STDPROF(prof, tag)`

Return number of completed cycles for tag; 0 if untracked.

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier

**Returns** _int_ — completed cycles; 0 if tag is untracked

**Example**

```m
new p set p("count","db.query")=3 do eq^STDASSERT(.pass,.fail,$$count^STDPROF(.p,"db.query"),3,"count returns completed cycles")
new p do eq^STDASSERT(.pass,.fail,$$count^STDPROF(.p,"nope"),0,"count is 0 if untracked")
```

### `$$max^STDPROF(prof, tag)`

Return slowest sample; 0 if no cycles.

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier

**Returns** _int_ — slowest sample (microseconds); 0 if no cycles

**Example**

```m
new p set p("max","db.query")=900 do eq^STDASSERT(.pass,.fail,$$max^STDPROF(.p,"db.query"),900,"max returns slowest sample")
```

### `$$mean^STDPROF(prof, tag)`

Return total\count (integer floor); 0 if no cycles.

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier

**Returns** _int_ — average elapsed microseconds; 0 if no cycles

**Example**

```m
new p set p("count","db.query")=4,p("total","db.query")=1000 do eq^STDASSERT(.pass,.fail,$$mean^STDPROF(.p,"db.query"),250,"mean is total floor-div count")
new p do eq^STDASSERT(.pass,.fail,$$mean^STDPROF(.p,"nope"),0,"mean is 0 with no cycles")
```

### `$$min^STDPROF(prof, tag)`

Return fastest sample; 0 if no cycles.

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier

**Returns** _int_ — fastest sample (microseconds); 0 if no cycles

**Example**

```m
new p set p("min","db.query")=42 do eq^STDASSERT(.pass,.fail,$$min^STDPROF(.p,"db.query"),42,"min returns fastest sample")
```

### `do new^STDPROF(prof)`

Initialise / wipe the profiler.

**Parameters**

- `prof` _(array)_ — by-ref local; killed

**Example**

```m
new p set p("count","x")=5 do new^STDPROF(.p) do false^STDASSERT(.pass,.fail,$data(p),"new wipes profiler")
```

### `$$percentile^STDPROF(prof, tag, p)`

Return the p-th percentile sample (0..100).

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier
- `p` _(int)_ — percentile in [0,100]

**Returns** _int_ — p-th percentile sample (microseconds); 0 if no cycles

**Example**

```m
new p set p("count","t")=4,p("samples","t",10,1)="",p("samples","t",20,2)="",p("samples","t",30,3)="",p("samples","t",40,4)="" do eq^STDASSERT(.pass,.fail,$$percentile^STDPROF(.p,"t",50),20,"p50 nearest-rank into sorted samples")
```

### `do start^STDPROF(prof, tag)`

Open a timer for tag. Stamps prof("active",tag) with $ZHOROLOG.

**Parameters**

- `prof` _(array)_ — by-ref local from new^STDPROF
- `tag` _(string)_ — per-tag identifier (e.g. "db.query")

**Example**

```m
new p do new^STDPROF(.p) do start^STDPROF(.p,"db.query") do true^STDASSERT(.pass,.fail,$data(p("active","db.query")),"start stamps active timer")
```

### `do stop^STDPROF(prof, tag)`

Close the timer; record one sample. No-op if no matching start.

**Parameters**

- `prof` _(array)_ — by-ref local from new^STDPROF
- `tag` _(string)_ — per-tag identifier matching a prior start()

**Example**

```m
new p do new^STDPROF(.p) do start^STDPROF(.p,"db.query") do stop^STDPROF(.p,"db.query") do eq^STDASSERT(.pass,.fail,$$count^STDPROF(.p,"db.query"),1,"stop records one sample")
```

### `$$tags^STDPROF(prof, out)`

Populate out(1..N) with tag names that have at least one cycle.

**Parameters**

- `prof` _(array)_ — by-ref local
- `out` _(array)_ — by-ref local; killed then populated as out(1..N)

**Returns** _int_ — count of tags

**Example**

```m
new p,list,n set p("count","alpha")=1,p("count","beta")=1 set n=$$tags^STDPROF(.p,.list) do eq^STDASSERT(.pass,.fail,n_"|"_list(1)_"|"_list(2),"2|alpha|beta","tags lists names in order")
```

### `$$total^STDPROF(prof, tag)`

Return sum of elapsed microseconds across all cycles; 0 if untracked.

**Parameters**

- `prof` _(array)_ — by-ref local
- `tag` _(string)_ — per-tag identifier

**Returns** _int_ — sum of elapsed microseconds; 0 if untracked

**Example**

```m
new p set p("total","db.query")=1500 do eq^STDASSERT(.pass,.fail,$$total^STDPROF(.p,"db.query"),1500,"total returns sum of elapsed")
```

<!-- END GENERATED API REFERENCE -->

## Public API

| Extrinsic | Signature | Action / Returns |
|---|---|---|
| `new` | `do new^STDPROF(.prof)` | Initialise / wipe. |
| `start` | `do start^STDPROF(.prof, tag)` | Open a timer for tag. No-op if already active. |
| `stop` | `do stop^STDPROF(.prof, tag)` | Close the timer; record one sample. No-op if no matching start. |
| `count` | `$$count^STDPROF(.prof, tag)` | Completed cycles for tag; `0` if untracked. |
| `total` | `$$total^STDPROF(.prof, tag)` | Sum of elapsed microseconds. |
| `mean` | `$$mean^STDPROF(.prof, tag)` | `total \ count` (integer floor). |
| `min` | `$$min^STDPROF(.prof, tag)` | Fastest sample. |
| `max` | `$$max^STDPROF(.prof, tag)` | Slowest sample. |
| `percentile` | `$$percentile^STDPROF(.prof, tag, p)` | p-th percentile sample (`0..100`). |
| `tags` | `$$tags^STDPROF(.prof, .out)` | Populates `out(1..N)` with tag names; returns N. |
| `clear` | `do clear^STDPROF(.prof)` | Drop everything (alias for `new`). |

## Examples

```m
NEW prof
DO new^STDPROF(.prof)

; Time a database call
DO start^STDPROF(.prof,"db.query")
DO ^DBCALL
DO stop^STDPROF(.prof,"db.query")

; Aggregate after many calls
WRITE "count: ",$$count^STDPROF(.prof,"db.query"),!
WRITE "mean:  ",$$mean^STDPROF(.prof,"db.query")," us",!
WRITE "p50:   ",$$percentile^STDPROF(.prof,"db.query",50)," us",!
WRITE "p95:   ",$$percentile^STDPROF(.prof,"db.query",95)," us",!
WRITE "p99:   ",$$percentile^STDPROF(.prof,"db.query",99)," us",!
WRITE "max:   ",$$max^STDPROF(.prof,"db.query")," us",!

; Enumerate tracked tags
DO  SET n=$$tags^STDPROF(.prof,.tags)
FOR i=1:1:n  WRITE tags(i)," ",$$count^STDPROF(.prof,tags(i)),!
```

## Time source

`$ZHOROLOG = "DDDDD,SSSSS,US,TZ"` — days since 1840-12-31, seconds
into day, **microseconds into second**, and timezone offset.
`nowMicros()` collapses this into a single integer microsecond
count; `stop` subtracts the start-time stamp to get elapsed.

The underlying clock resolution depends on the host:

| Environment | Typical resolution |
|---|---|
| Bare-metal Linux | ~1–10 µs |
| Container hosts | ~100–1000 µs |
| Virtualised guests | ~1 ms |

Samples below the host's resolution are recorded as `0` µs.
Aggregates are unaffected; percentiles still rank correctly.

## Tree shape

The profiler lives entirely in the caller's array. A typical
post-population snapshot for one tag:

```
prof("count","db.query")               = 4203
prof("total","db.query")               = 8412345
prof("min","db.query")                 = 412
prof("max","db.query")                 = 18234
prof("seq","db.query")                 = 4203
prof("samples","db.query",412,1)       = ""
prof("samples","db.query",412,2)       = ""
prof("samples","db.query",413,3)       = ""
...
prof("samples","db.query",18234,4203)  = ""
```

Multiple tags share the top-level subscripts; samples are
interleaved by tag at the second subscript. `prof("active",tag)`
holds the start-time stamp while a cycle is in progress and is
killed on `stop`.

## Percentile semantics

**Nearest-rank** computation. For N samples and percentile p:

```
target = ceil(p * N / 100)        (1-based index into sorted samples)
```

- `p=0` returns `min` (fast path; no walk).
- `p=100` returns `max` (fast path; no walk).
- Intermediate values walk `prof("samples", tag, value, seq)` in
  natural numeric `$ORDER` until the cumulative count reaches
  `target`, returning the value at that position.

Ties (multiple samples with the same elapsed) are resolved by the
seq subscript — the order doesn't matter for percentile lookup,
since they all share the same value.

The walk is `O(N)` worst case but typically much less because
percentile lookups are clustered near the tail. For one-shot
reports (call `percentile` once per tag at the end of a run), the
cost is negligible. A streaming-percentile variant (CKMS sketch
backed by `STDCOLL` Heap) was reserved under T20 and closed 2026-
05-07 as won't-fix-without-consumer-driver — the only caller
today, m-cli `--timings`, is a one-shot end-of-run report, exactly
the case the v1 walk is sized for. If a continuous-monitoring
caller emerges that calls `percentile` inside a hot path, T20 can
be reopened and implemented behind a `newStreaming^STDPROF(.prof,
epsilon)` constructor without disturbing the v1 surface.

## Edge cases

- **`stop()` without a matching `start()` is a no-op.** `count`
  stays at zero; no sample is recorded.
- **`start()` on an already-active tag is a no-op.** The original
  start time is preserved. This matches the convention that you
  can't "double-start" a single timer; if you need nested timing,
  use distinct tags.
- **Negative elapsed (clock skew).** If `$ZHOROLOG` reports an
  earlier time on `stop` than on `start` — typically only possible
  during a clock adjustment — the elapsed is clamped to `0` rather
  than recorded as a negative sample.
- **`count` / `total` / `min` / `max` of an untracked tag** all
  return `0`.
- **`percentile` of an untracked tag** returns `0`.
- **`tags()` walks `prof("count", ...)`** in `$ORDER` — alphabetical
  for plain string tags, numeric for numeric tags. The walk does
  not include in-progress timers (those have a `prof("active", tag)`
  entry but no `prof("count", tag)` until the first `stop`).

## Engine portability

`$ZHOROLOG` is a YDB extension (also IRIS-supported); listed in
the file-wide `M-MOD-022` directive at the top of the source. The
ANSI-standard `$HOROLOG` is too coarse (1-second resolution) to be
useful for profiling. An IRIS-compatible time source via
`$ZTIMESTAMP` is queued alongside STDDATE's IRIS pass. The rest
of the module — `$ORDER`, `$DATA`, `$GET`, integer arithmetic — is
ANSI-standard.

## See also

- [`STDDATE`](stddate.md) — same `$ZHOROLOG` precedent; STDDATE
  has the canonical wall-clock helpers but at second / millisecond
  resolution.
- [`STDCOLL`](stdcoll.md) — provides Heap; was reserved as the
  backing for a T20 streaming-percentile variant. T20 closed 2026-
  05-07 as won't-fix-without-consumer-driver; the soft dep is no
  longer load-bearing for STDPROF v1.
- [`STDCACHE`](stdcache.md) — same caller-owned array convention;
  multiple profilers in one process are independent variables.

## History

Caller-owned profiler tree: start / stop per tag, count / total /
mean / min / max / percentile aggregates, tags() enumerator. Time
source `$ZHOROLOG` collapsed to microseconds since 1840-12-31 (ANSI
`$HOROLOG` is 1-second-resolution, too coarse). Percentile via
nearest-rank over a sorted-by-value sample tree (`prof("samples",
tag, value, seq) = ""`); O(N) worst case but typically a small walk.
Edge cases: negative-elapsed clamps to 0, double-`start()` is a
no-op, `stop()` without matching `start()` is a no-op.

T20 (streaming-percentile via STDCOLL Heap CKMS sketch) closed
2026-05-07 as **won't-fix-without-consumer-driver**. The only consumer
today is m-cli `m test --timings` (companion track C6), which calls
`percentile()` once per tag at end-of-run — the exact one-shot report
the v1 walk is sized for. Reopen criteria: a caller emerges that calls
`percentile()` inside a hot path, or a long-running service
instruments itself with STDPROF and observes the linear-walk cost.
