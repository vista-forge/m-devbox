---
module: STDHTTP
tag: v0.4.0
phase: Phase 3 + post-P4 wave
stable: stable
since: v0.4.0
synopsis: 'HTTP/1.1 client (track H3, target tag v0.4.0)'
labels: ['available', 'buildRequest', 'formatHeaders', 'get', 'parseHeader', 'parseResponse', 'parseStatusLine', 'post', 'request']
errors: []
conformance: []
see_also: ['STDS3', 'STDURL']
---

# `STDHTTP` — HTTP/1.1 client (libcurl callout)

HTTP/1.1 + HTTPS client for m-stdlib. Track **H3**, target tag `v0.4.0`
(Phase 3 lead). Two layers:

1. **Pure-M wire-format helpers** — parse/build HTTP/1.1 status lines,
   header blocks, and full responses. Testable without a network or a
   compiled callout.
2. **`$ZF → libcurl` integration** — `src/callouts/http.c` exposes a
   single `http_perform` entry point plus an `http_available` probe;
   `$$get` / `$$post` / `$$request` public extrinsics call into it.

The IRIS arm uses `$CLASSMETHOD` against `%Net.HttpRequest` and shares
the same M-side request/response array shape (Iteration 3, queued).

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `available` | `$$available^STDHTTP()` | 1 iff the libcurl callout is loaded and curl_easy_init() works. |
| `buildRequest` | `$$buildRequest^STDHTTP(req)` | Assemble an HTTP/1.1 request message from req array. |
| `formatHeaders` | `$$formatHeaders^STDHTTP(headers)` | Join headers(name)=value into a CRLF-terminated header block. |
| `get` | `$$get^STDHTTP(url, resp)` | HTTP GET shortcut. Returns numeric status code, or 0 on error. |
| `parseHeader` | `do parseHeader^STDHTTP(line, name, value)` | Split "Name: value" into (name, value). |
| `parseResponse` | `do parseResponse^STDHTTP(raw, resp)` | Parse a complete HTTP/1.1 response message. |
| `parseStatusLine` | `do parseStatusLine^STDHTTP(line, s)` | Split an HTTP/1.1 status line into version/code/reason. |
| `post` | `$$post^STDHTTP(url, body, resp, contentType)` | HTTP POST shortcut. Defaults Content-Type to application/octet-stream. |
| `request` | `$$request^STDHTTP(req, resp)` | Generic HTTP request. Returns numeric status code, or 0 on error. |

### `$$available^STDHTTP()`

1 iff the libcurl callout is loaded and curl_easy_init() works.

**Returns** _bool_ — 1 iff stdhttp.so is loaded and libcurl resolves

**Example**

```m
if '$$available^STDHTTP() do warn^MYAPP("HTTP unavailable")
```

### `$$buildRequest^STDHTTP(req)`

Assemble an HTTP/1.1 request message from req array.

**Parameters**

- `req` _(array)_ — by-ref local with method/url/header/body subscripts

**Returns** _byte-string_ — full wire-format request (line + headers + CRLF + body)

**Example**

```m
new req set req("method")="GET",req("url")="http://x.com/a" do contains^STDASSERT(.pass,.fail,$$buildRequest^STDHTTP(.req),"GET /a HTTP/1.1","request line")
new req set req("method")="GET",req("url")="http://x.com/a" do contains^STDASSERT(.pass,.fail,$$buildRequest^STDHTTP(.req),"GET /a HTTP/1.1"_$char(13,10)_"Host: x.com","Host synthesised from URL")
```

### `$$formatHeaders^STDHTTP(headers)`

Join headers(name)=value into a CRLF-terminated header block.

**Parameters**

- `headers` _(array)_ — by-ref local subscripted as headers(name)=value

**Returns** _string_ — CRLF-terminated header block

**Example**

```m
new h set h("X-Test")="1" do eq^STDASSERT(.pass,.fail,$$formatHeaders^STDHTTP(.h),"X-Test: 1"_$char(13,10),"one header, CRLF-terminated")
```

### `$$get^STDHTTP(url, resp)`

HTTP GET shortcut. Returns numeric status code, or 0 on error.

**Parameters**

- `url` _(string)_ — absolute URL
- `resp` _(array)_ — by-ref local; populated on return

**Returns** _int_ — HTTP status code; 0 on transport / TLS / not-wired error

**Example**

```m
set sc=$$get^STDHTTP("https://example.com",.r)
```

### `do parseHeader^STDHTTP(line, name, value)`

Split "Name: value" into (name, value).

**Parameters**

- `line` _(string)_ — header line
- `name` _(string)_ — by-ref out; header name (or "" if no colon)
- `value` _(string)_ — by-ref out; header value (or "" if no colon)

**Example**

```m
new n,v do parseHeader^STDHTTP("Content-Type: text/plain",.n,.v) do eq^STDASSERT(.pass,.fail,n,"Content-Type","header name split")
new n,v do parseHeader^STDHTTP("Content-Type: text/plain",.n,.v) do eq^STDASSERT(.pass,.fail,v,"text/plain","header value trimmed")
```

### `do parseResponse^STDHTTP(raw, resp)`

Parse a complete HTTP/1.1 response message.

**Parameters**

- `raw` _(byte-string)_ — full HTTP/1.1 response (headers + body)
- `resp` _(array)_ — by-ref local; killed then populated (status/reason/version/header/body)

**Example**

```m
new resp do parseResponse^STDHTTP("HTTP/1.1 200 OK"_$char(13,10)_"Content-Type: text/plain"_$char(13,10,13,10)_"hello",.resp) do eq^STDASSERT(.pass,.fail,resp("status"),200,"status code")
new resp do parseResponse^STDHTTP("HTTP/1.1 200 OK"_$char(13,10)_"Content-Type: text/plain"_$char(13,10,13,10)_"hello",.resp) do eq^STDASSERT(.pass,.fail,resp("body"),"hello","body after CRLF-CRLF")
new resp do parseResponse^STDHTTP("HTTP/1.1 200 OK"_$char(13,10)_"Content-Type: text/plain"_$char(13,10,13,10)_"hello",.resp) do eq^STDASSERT(.pass,.fail,resp("header","content-type"),"text/plain","header key lowercased")
```

### `do parseStatusLine^STDHTTP(line, s)`

Split an HTTP/1.1 status line into version/code/reason.

**Parameters**

- `line` _(string)_ — HTTP/1.1 status line (e.g. "HTTP/1.1 200 OK")
- `s` _(array)_ — by-ref local; killed then populated with version/code/reason/ok

**Example**

```m
new s do parseStatusLine^STDHTTP("HTTP/1.1 200 OK",.s) do eq^STDASSERT(.pass,.fail,s("code"),200,"status code parsed")
new s do parseStatusLine^STDHTTP("HTTP/1.1 404 Not Found",.s) do eq^STDASSERT(.pass,.fail,s("reason"),"Not Found","reason phrase parsed")
new s do parseStatusLine^STDHTTP("garbage",.s) do eq^STDASSERT(.pass,.fail,s("ok"),0,"malformed line flags ok=0")
```

### `$$post^STDHTTP(url, body, resp, contentType)`

HTTP POST shortcut. Defaults Content-Type to application/octet-stream.

**Parameters**

- `url` _(string)_ — absolute URL
- `body` _(byte-string)_ — request body
- `resp` _(array)_ — by-ref local; populated on return
- `contentType` _(string)_ — Content-Type header (default "application/octet-stream")

**Returns** _int_ — HTTP status code; 0 on transport / TLS / not-wired error

**Example**

```m
set sc=$$post^STDHTTP("https://example.com/api","payload",.r,"application/json")
```

### `$$request^STDHTTP(req, resp)`

Generic HTTP request. Returns numeric status code, or 0 on error.

**Parameters**

- `req` _(array)_ — by-ref local with method/url/header/body/timeout/followRedirects/verifyTls
- `resp` _(array)_ — by-ref local; populated as documented in the routine header

**Returns** _int_ — HTTP status code; 0 on transport / TLS / DNS failure or callout missing

**Example**

```m
set req("method")="DELETE",req("url")="https://x.com/y"  set sc=$$request^STDHTTP(.req,.r)
```

<!-- END GENERATED API REFERENCE -->

## Status

**Iteration 1 + 2 landed (2026-05-07).** Pure-M helpers and the
libcurl-backed network extrinsics are wired. `$$available^STDHTTP()`
returns 1 when the callout is loaded, 0 otherwise; when 0, network
calls soft-fail with `resp("error")="STDHTTP-NOT-WIRED"` and return 0
so callers can degrade gracefully without `$ETRAP`.

### Deployment

```
tools/build-callouts.sh                # produces so/<plat>/http.so
export STDLIB_LIB=$PWD/so/<plat>
export ydb_xc_stdhttp=$PWD/tools/std_http.xc
# libcurl must be on the loader path (libcurl.so.4 on linux,
# libcurl.4.dylib on macOS).
```

For the shared vista-meta engine, `scripts/seed-callouts.sh` does all
four steps in one shot — builds inside the container against the
runtime YDB headers, stages the .so + .xc files, and idempotently
appends the env-var exports to `/etc/profile.d/ydb_env.sh` so every
`m test` SSH session inherits them. `make seed` calls it
automatically when `src/callouts/*.c` is present.

## Public API

### Pure-M helpers (iteration 1 — green)

| Entry point | Signature | Behaviour |
|---|---|---|
| `parseStatusLine` | `do parseStatusLine^STDHTTP(line,.s)` | Splits `"HTTP/1.1 200 OK"` → `s("version")`, `s("code")` (numeric), `s("reason")`. Tolerates a missing reason phrase (returns `""`). Sets `s("ok")=0` on a malformed status line. |
| `parseHeader` | `do parseHeader^STDHTTP(line,.name,.value)` | Splits `"Content-Type: text/plain"` on the first `:`. Trims leading SP/HT from value. Header name preserved as-given; lookup tables should lowercase before storing. |
| `parseResponse` | `do parseResponse^STDHTTP(raw,.resp)` | Full response: splits on the first CRLF-CRLF boundary, walks headers, fills `resp("status")`, `resp("reason")`, `resp("version")`, `resp("header",lowerName)`, `resp("body")`. Multi-value headers join with `", "` per RFC 7230 §3.2.2. |
| `buildRequest` | `$$buildRequest^STDHTTP(.req)` | Assembles a wire-format HTTP/1.1 request from `req("method")`, `req("url")`, `req("header",name)`, `req("body")`. Adds `Host:` from STDURL parse if absent. Adds `Content-Length:` if a body is present and the header is absent. |
| `formatHeaders` | `$$formatHeaders^STDHTTP(.headers)` | Joins `headers(name)=value` into a CRLF-terminated header block (each line `Name: value\r\n`, no trailing blank line — caller adds the boundary). |

### Network extrinsics (iteration 2 — green)

| Entry point | Signature | Behaviour |
|---|---|---|
| `get` | `$$get^STDHTTP(url,.resp)` | GET shortcut. Returns the numeric status code; `resp` populated as below. |
| `post` | `$$post^STDHTTP(url,body,.resp,contentType)` | POST shortcut. `contentType` defaults to `application/octet-stream`. |
| `request` | `$$request^STDHTTP(.req,.resp)` | Full request: `req("method")`, `req("url")`, `req("header",name)`, `req("body")`, `req("timeout")` (seconds, default 30), `req("followRedirects")` (0/1, default 1), `req("verifyTls")` (0/1, default 1). |
| `available` | `$$available^STDHTTP()` | `1` iff the libcurl callout is loaded and `curl_easy_init()` works; `0` otherwise. Never raises. |

### Array shapes

**Request (`req`)** — caller-built before `request`:

```
req("method")             ; "GET" / "POST" / "PUT" / ...
req("url")                ; full absolute URL
req("header", name)       ; header value; name as-given (case preserved)
req("body")               ; request body bytes
req("timeout")            ; seconds; default 30
req("followRedirects")    ; 0/1; default 1
req("verifyTls")          ; 0/1; default 1
```

**Response (`resp`)** — populated by `request` / `get` / `post`:

```
resp("status")            ; numeric status code (200, 404, ...) or "" on error
resp("reason")            ; reason phrase ("OK", "Not Found", ...)
resp("version")           ; "HTTP/1.1"
resp("header", lowerName) ; header value (name lowercased for lookup)
resp("body")              ; response body bytes
resp("error")             ; "" on success; libcurl error string otherwise
```

Header lookup is case-insensitive: keys are lowercased on insertion so
`resp("header","content-type")` works regardless of what the server
sent. The original casing is not preserved (server casing is not
semantically significant per RFC 7230 §3.2).

## Examples

```m
; iteration 1 — parse a captured response
new resp,raw
set raw="HTTP/1.1 200 OK"_$char(13,10)
set raw=raw_"Content-Type: text/plain"_$char(13,10)
set raw=raw_"Content-Length: 5"_$char(13,10,13,10)
set raw=raw_"hello"
do parseResponse^STDHTTP(raw,.resp)
write resp("status"),!                       ; 200
write resp("header","content-type"),!        ; "text/plain"
write resp("body"),!                         ; "hello"

; iteration 1 — build a request line + header block
new req
set req("method")="GET"
set req("url")="https://example.com/api/v1/things?x=1"
set req("header","Accept")="application/json"
write $$buildRequest^STDHTTP(.req)
; GET /api/v1/things?x=1 HTTP/1.1
; Host: example.com
; Accept: application/json
; (blank line)
```

```m
; iteration 2 — convenience GET
new resp
if '$$available^STDHTTP() do  quit  ; degrade gracefully if SO missing
. write "http callout unavailable; skipping fetch",!
if '$$get^STDHTTP("https://example.com/health",.resp) do
. write "fetch failed: ",resp("error"),!
. quit
write resp("status")," ",resp("reason"),!
write resp("body"),!
```

## Dependencies

- **STDURL** (`v0.2.0`) — `parse^STDURL` extracts host/path/port for
  request-line and Host-header construction.
- **`tools/build-callouts.sh`** — compiles `src/callouts/http.c`
  into `so/<platform>/http.so`.
- **libcurl** — runtime dep on iteration 2; the M side soft-fails
  with `resp("error")="STDHTTP-NOT-WIRED"` when the SO is missing
  rather than aborting. `$$available^STDHTTP()` is the cheap probe.

## Edge cases

- **CRLF tolerance.** `parseResponse` accepts both bare LF and CRLF
  for line endings; emit-side `buildRequest` and `formatHeaders`
  always use CRLF (RFC 7230 §3 requires CRLF for compliant servers).
- **Status without reason.** `"HTTP/1.1 204"` (no reason phrase) is
  accepted; `s("reason")` becomes `""`. RFC 7230 §3.1.2 allows this.
- **Multiple headers with same name.** Joined with `", "` per RFC
  7230 §3.2.2 — `Set-Cookie` is the documented exception, but for v1
  STDHTTP applies the comma-join rule uniformly. `Set-Cookie` parsing
  belongs in a future `STDCOOKIE` module.
- **Body byte semantics.** Bodies are M strings of bytes (0..255 via
  `$ASCII` / `$CHAR`); STDHTTP performs no transcoding. Callers
  decode as appropriate.
- **No transfer-decoding by `parseResponse`.** It returns the body as
  the server sent it. `Transfer-Encoding: chunked` is handled inside
  libcurl in iteration 2 — by the time the body reaches `$$request`
  via the callout it has already been de-chunked.
- **Redirect headers.** When `req("followRedirects")=1` (default),
  libcurl emits the headers from every response in the redirect chain
  to the M side. `$$request` keeps only the **final** response's
  status line + header block (split on `\r\n\r\n`, take the last
  non-empty piece) — intermediate 3xx responses are not surfaced.
- **Output budgets.** Response headers and body are each captured into
  a 1 MiB pre-allocated buffer; oversize responses are silently
  truncated by the C-side capture callback. Callers needing exact-size
  enforcement should validate `Content-Length` themselves.
- **`$$buildRequest` does not encode the URL.** It uses the URL as
  given. Callers needing percent-encoding apply `STDURL.encode` first.

## Errors

Pure-M helpers do not set `$ECODE`. Malformed input degrades to a
flag in the output array (`s("ok")=0`, etc.) so callers can branch
without `$ETRAP`. The libcurl callout (iteration 2) translates curl
error codes into `resp("error")` strings; `$ECODE` stays clean.

## See also

- [`STDURL`](stdurl.md) — RFC 3986 URL parser; consumed by
  `buildRequest` for `Host:` synthesis.
- [`STDB64`](stdb64.md) — Base64 (used for `Authorization: Basic`
  headers).
- `STDCRYPTO` (H1, queued) — paired with STDHTTP via the
  `examples/jwt-verify.m` end-to-end Phase 3 demo.

## History

HTTP/1.1 client. Two layers, shipped iteratively.

**Iter 1** (`9622bbe`, bundled with STDCRYPTO + STDCOMPRESS scaffolds):
pure-M wire-format helpers — `parseStatusLine` / `parseHeader` /
`parseResponse` / `buildRequest` / `formatHeaders`. Parses CRLF or
bare-LF line endings, lowercases header keys for case-insensitive
lookup, joins duplicate headers with `", "` per RFC 7230 §3.2.2,
preserves arbitrary body bytes.

**Iter 2** (`940f8ce` + post-T28 namespace migration, T29 close via
commit `ea373fa` + `scripts/seed-callouts.sh`): `src/callouts/http.c`
(251 LOC libcurl shim — `http_perform` + `http_available`),
`tools/std_http.xc`. M side drives `$&stdhttp.http_perform(...)`
through an XECUTE-wrapped literal template (same anti-fmt-mangling
pattern as STDCRYPTO). Response header stream split on `\r\n\r\n` to
keep the **final** response after redirects; body installed
afterwards. libcurl error string flows into `resp("error")`. Both
`$$available^STDHTTP` and the internal `dispatchPerform` short-circuit
on `$$env^STDOS("ydb_xc_stdhttp")=""` so engines without the
descriptor exported soft-fail to `resp("error")="STDHTTP-NOT-WIRED"`
without paying the XECUTE compile cost. STDHTTPTST 68/68 green; 94.1%
label coverage.

**Optional add-on:** Iter 3 IRIS arm via `%Net.HttpRequest`
`$CLASSMETHOD`. Shares the same M-side req/resp shape. Activates when
the IRIS portability spike unblocks behind T28's deployment machinery.
