---
module: STDARGS
tag: v0.0.7
phase: Phase 1
stable: stable
since: v0.0.7
synopsis: 'argparse (v0.0.7)'
labels: ['addflag', 'addpos', 'addsub', 'free', 'help', 'new', 'parse']
errors: ['U-STDARGS-MISSING-POSITIONAL', 'U-STDARGS-MISSING-VALUE', 'U-STDARGS-UNKNOWN-ACTION', 'U-STDARGS-UNKNOWN-FLAG', 'U-STDARGS-UNKNOWN-SUBCOMMAND']
conformance: []
see_also: []
---

# `STDARGS` — argparse

A small argument parser for M command-line scripts. Long flags
(`--verbose`), short flags (`-v`), grouped count flags (`-vvv`),
positionals, sub-commands, and the `--` end-of-flags terminator. Args
arrive as a single string — `$ZCMDLINE` on YDB, or any explicit
string elsewhere.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `addflag` | `do addflag^STDARGS(p, long, short, action, dest)` | Register a flag. |
| `addpos` | `do addpos^STDARGS(p, name, dest)` | Register a positional argument. |
| `addsub` | `do addsub^STDARGS(p, name, sub)` | Register a sub-command -> sub-parser handle. |
| `free` | `do free^STDARGS(p)` | Release a parser's state. |
| `help` | `$$help^STDARGS(p)` | Return formatted help text. |
| `new` | `$$new^STDARGS(prog, desc)` | Allocate a fresh parser handle. |
| `parse` | `do parse^STDARGS(p, argline, ns)` | Parse argline; populate ns(dest)=value. |

### `do addflag^STDARGS(p, long, short, action, dest)`

Register a flag.

**Parameters**

- `p` _(int)_ — parser handle from new()
- `long` _(string)_ — long form including "--" prefix (e.g. "--verbose")
- `short` _(string)_ — short form including "-" prefix; "" if no short
- `action` _(string)_ — one of: store_true, store, count, append
- `dest` _(string)_ — ns(dest) subscript that the parsed value lands in

**Raises**

- `U-STDARGS-UNKNOWN-ACTION` — `action` is not one of the four documented values

**Example**

```m
new p,ns set p=$$new^STDARGS("w","d") do addflag^STDARGS(p,"--verbose","-v","store_true","verbose") do parse^STDARGS(p,"--verbose",.ns) do eq^STDASSERT(.pass,.fail,ns("verbose"),1,"store_true flag sets dest to 1")
do raises^STDASSERT(.pass,.fail,"new p set p=$$new^STDARGS(""w"",""d"") do addflag^STDARGS(p,""--x"",""-x"",""bogus"",""x"")","U-STDARGS-UNKNOWN-ACTION","unknown action raises")
```

### `do addpos^STDARGS(p, name, dest)`

Register a positional argument.

**Parameters**

- `p` _(int)_ — parser handle from new()
- `name` _(string)_ — positional's display name (rendered into help)
- `dest` _(string)_ — ns(dest) subscript that the value lands in

**Example**

```m
new p,ns set p=$$new^STDARGS("w","d") do addpos^STDARGS(p,"path","path") do parse^STDARGS(p,"/tmp/x",.ns) do eq^STDASSERT(.pass,.fail,ns("path"),"/tmp/x","positional value lands in ns(dest)")
```

### `do addsub^STDARGS(p, name, sub)`

Register a sub-command -> sub-parser handle.

**Parameters**

- `p` _(int)_ — parser handle from new()
- `name` _(string)_ — sub-command name (matched against the first non-flag token)
- `sub` _(int)_ — parser handle from a separate new() call — the sub-parser

**Example**

```m
new p,sub,ns set p=$$new^STDARGS("w","d"),sub=$$new^STDARGS("a","s") do addsub^STDARGS(p,"add",sub) do parse^STDARGS(p,"add",.ns) do eq^STDASSERT(.pass,.fail,ns("__sub__"),"add","matched sub recorded in ns(""__sub__"")")
```

### `do free^STDARGS(p)`

Release a parser's state.

**Parameters**

- `p` _(int)_ — parser handle from new()

**Example**

```m
new p set p=$$new^STDARGS("w","d") do free^STDARGS(p) do false^STDASSERT(.pass,.fail,$data(^STDLIB($job,"stdargs",p)),"free drops handle state")
```

### `$$help^STDARGS(p)`

Return formatted help text.

**Parameters**

- `p` _(int)_ — parser handle from new()

**Returns** _string_ — multi-line help banner — usage line, description, flags, positionals, commands

**Example**

```m
new p set p=$$new^STDARGS("widget","frob the widget") do contains^STDASSERT(.pass,.fail,$$help^STDARGS(p),"usage: widget","help banner opens with the usage line")
```

### `$$new^STDARGS(prog, desc)`

Allocate a fresh parser handle.

**Parameters**

- `prog` _(string)_ — program name (rendered into the help banner)
- `desc` _(string)_ — one-line description (rendered into the help banner)

**Returns** _int_ — positive parser handle; pass to addflag / addpos / addsub / parse / help / free

**Example**

```m
write $$new^STDARGS("widget","frob the widget")>0  ; 1
```

### `do parse^STDARGS(p, argline, ns)`

Parse argline; populate ns(dest)=value.

**Parameters**

- `p` _(int)_ — parser handle from new()
- `argline` _(string)_ — the raw command line (e.g. $ZCMDLINE on YDB)
- `ns` _(array)_ — by-ref local; populated as ns(dest)=value

**Raises**

- `U-STDARGS-UNKNOWN-FLAG` — token starts with "-" but isn't a registered flag
- `U-STDARGS-UNKNOWN-SUBCOMMAND` — first non-flag token doesn't match any addsub() name
- `U-STDARGS-MISSING-VALUE` — a `store` / `append` flag has no value token after it
- `U-STDARGS-MISSING-POSITIONAL` — a registered positional was not supplied

**Example**

```m
new p,ns set p=$$new^STDARGS("w","d") do addflag^STDARGS(p,"--name","-n","store","name") do parse^STDARGS(p,"--name bob",.ns) do eq^STDASSERT(.pass,.fail,ns("name"),"bob","store flag consumes the next token")
new p,ns set p=$$new^STDARGS("w","d") do addflag^STDARGS(p,"--verbose","-v","count","v") do parse^STDARGS(p,"-vvv",.ns) do eq^STDASSERT(.pass,.fail,ns("v"),3,"grouped -vvv counts to 3")
do raises^STDASSERT(.pass,.fail,"new p,ns set p=$$new^STDARGS(""w"",""d"") do parse^STDARGS(p,""--bogus"",.ns)","U-STDARGS-UNKNOWN-FLAG","unregistered flag raises")
do raises^STDASSERT(.pass,.fail,"new p,sub,ns set p=$$new^STDARGS(""w"",""d""),sub=$$new^STDARGS(""a"",""s"") do addsub^STDARGS(p,""add"",sub) do parse^STDARGS(p,""nope"",.ns)","U-STDARGS-UNKNOWN-SUBCOMMAND","non-matching sub token raises")
do raises^STDASSERT(.pass,.fail,"new p,ns set p=$$new^STDARGS(""w"",""d"") do addflag^STDARGS(p,""--name"",""-n"",""store"",""name"") do parse^STDARGS(p,""--name"",.ns)","U-STDARGS-MISSING-VALUE","store flag with no value raises")
do raises^STDASSERT(.pass,.fail,"new p,ns set p=$$new^STDARGS(""w"",""d"") do addpos^STDARGS(p,""path"",""path"") do parse^STDARGS(p,"""",.ns)","U-STDARGS-MISSING-POSITIONAL","unfilled positional raises")
```

<!-- END GENERATED API REFERENCE -->

## Public API

| Label | Signature | Returns |
|---|---|---|
| `new` | `$$new^STDARGS(prog,desc)` | A positive integer parser handle. |
| `addflag` | `do addflag^STDARGS(p,long,short,action,dest)` | — (mutates `p`). |
| `addpos` | `do addpos^STDARGS(p,name,dest)` | — (mutates `p`). |
| `addsub` | `do addsub^STDARGS(p,name,subParserHandle)` | — (mutates `p`). |
| `parse` | `do parse^STDARGS(p,argline,.ns)` | — (populates `ns(dest)` by reference). |
| `help` | `$$help^STDARGS(p)` | Formatted help text. |
| `free` | `do free^STDARGS(p)` | — (drops parser state). |

The handle keys into `^STDLIB($job,"stdargs",p,...)`. State is
per-process and per-handle. `free()` is idempotent; the handle must
not be reused after.

## Actions

| Action | Behaviour | Default in `ns` |
|---|---|---|
| `store_true` | `ns(dest)=1` if flag seen | `ns(dest)=0` |
| `store` | `ns(dest)=<next token>` | (none) |
| `count` | `ns(dest)+=1` per occurrence; `-vvv` expands | `ns(dest)=0` |
| `append` | `ns(dest,k)=<next token>` (k is auto-incrementing 1..N) | (none) |

`store_true` and `count` flags are pre-populated with `0` so absent
flags are observable. `store` and `append` flags do not appear in
`ns` if the flag was never given.

`addflag` with an action outside this set sets `$ECODE` to
`,U-STDARGS-UNKNOWN-ACTION,`.

## Examples

```m
; basic flag + positional
new p,ns
set p=$$new^STDARGS("rsync","copy a tree")
do addflag^STDARGS(p,"--verbose","-v","count","verbose")
do addflag^STDARGS(p,"--exclude","-e","append","exclude")
do addpos^STDARGS(p,"src","src")
do addpos^STDARGS(p,"dst","dst")
do parse^STDARGS(p,"-vv --exclude .git --exclude node_modules /a /b",.ns)
write ns("verbose"),!         ; 2
write ns("exclude",1),!       ; .git
write ns("exclude",2),!       ; node_modules
write ns("src"),!             ; /a
write ns("dst"),!             ; /b
do free^STDARGS(p)

; sub-commands
new p,sub,ns
set p=$$new^STDARGS("m","tooling")
set sub=$$new^STDARGS("m test","run tests")
do addflag^STDARGS(sub,"--filter","-f","store","filter")
do addsub^STDARGS(p,"test",sub)
do parse^STDARGS(p,"test --filter STDB64",.ns)
write ns("__sub__"),!         ; test
write ns("filter"),!          ; STDB64
do free^STDARGS(p)
do free^STDARGS(sub)

; help text
write $$help^STDARGS(p)
```

## The `--` terminator

A bare `--` token ends flag parsing. Subsequent tokens are positional
even if they start with `-`:

```m
do parse^STDARGS(p,"-- --verbose",.ns)
write ns("path"),!            ; --verbose  (positional, not a flag)
```

## Sub-commands

When any sub-command is registered with `addsub`, the first non-flag
token of `argline` MUST name one — anything else sets `$ECODE` to
`,U-STDARGS-UNKNOWN-SUBCOMMAND,`. The chosen sub-command name is
recorded as `ns("__sub__")`. The remainder of the argline is
re-parsed against the sub-parser's flags / positionals into the same
`ns`, so a top-level `parse()` populates everything in one call.

## Grouped short flags

Short-flag tokens of length > 2 (`-vvv`) are expanded char by char.
Every char must be the short form of a `count`-action flag; otherwise
`,U-STDARGS-UNKNOWN-FLAG,` fires. This rules out the ambiguity
between grouped flags and a `store`-style short with an attached
value.

## Error codes

| `$ECODE` | When |
|---|---|
| `,U-STDARGS-UNKNOWN-ACTION,` | `addflag` with a non-recognised action |
| `,U-STDARGS-UNKNOWN-FLAG,` | `parse` sees a flag that was never registered |
| `,U-STDARGS-UNKNOWN-SUBCOMMAND,` | `parse` sees a first token that names no registered sub |
| `,U-STDARGS-MISSING-VALUE,` | `store`/`append` flag has no following token |
| `,U-STDARGS-MISSING-POSITIONAL,` | A registered positional was never filled |

## Tokenisation

`parse()` splits `argline` on runs of ASCII space and tab — quoting
is the shell's job (and `$ZCMDLINE` arrives post-shell). If you need
a value with embedded spaces, pass an already-tokenised list of
tokens joined with `_$char(31)_` and tokenise yourself; first-class
quoted-arg support is out of scope for v0.0.7.

## Edge cases

- **Empty `argline`.** `parse()` runs `initDefaults` (so `store_true`
  and `count` flags appear in `ns` as 0) and `checkPositionals` (so
  any registered positional fires `MISSING-POSITIONAL`).
- **Extra positionals.** Tokens past the last registered positional
  are silently ignored at v0.0.7 — a future revision may add `nargs+`
  / `nargs*` semantics.
- **Mutually-exclusive groups.** Not modelled at v0.0.7. Callers
  enforce by inspecting `ns` after parse.
- **`-` as a value.** A bare `-` is treated as a positional (length
  ≤ 1 with leading `-` falls through the flag check).

## See also

- [`STDFMT`](stdfmt.md) for printf-style help-text formatting once a
  caller wants more than the default usage block.
