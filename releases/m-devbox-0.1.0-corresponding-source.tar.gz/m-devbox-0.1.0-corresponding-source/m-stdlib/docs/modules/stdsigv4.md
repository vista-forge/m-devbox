---
module: STDSIGV4
tag: v0.14.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.14.0
synopsis: 'AWS Signature Version 4 request signer'
labels: ['amzDate', 'authHeader', 'canonRequest', 'emptyHash', 'encPath', 'encQuery', 'sign', 'signingKey']
errors: ['U-STDCRYPTO-CALLOUT-MISSING']
conformance: []
see_also: ['STDCRYPTO', 'STDHEX', 'STDS3']
---

# `STDSIGV4` — AWS Signature Version 4 request signer

Service-generic **AWS Signature Version 4 (SigV4)** signer for m-stdlib. Given
the parts of an HTTP request — method, canonical URI, query string, headers, and
the SHA-256 of the body — `STDSIGV4` produces the `Authorization` header an AWS
REST service requires. S3 is the first consumer (`STDS3` builds on it), but the
module is **not** S3-specific: the same four-step process signs any AWS SigV4
REST service, given the right `service`/`region` in the signing context.

There is **no new crypto here**. Every step maps onto an existing
`$$…^STDCRYPTO` (HMAC-SHA-256 / SHA-256) or `$$encode^STDURL` / `$$encode^STDHEX`
call. The module is the *protocol* — the canonical-request layout, the
string-to-sign, the HMAC signing-key chain, and the credential-scope assembly —
laid over those primitives.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `amzDate` | `$$amzDate^STDSIGV4()` | Current UTC timestamp in SigV4 basic-ISO form YYYYMMDDgHHMMSSZ. |
| `authHeader` | `$$authHeader^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)` | Build the full Authorization header value. |
| `canonRequest` | `$$canonRequest^STDSIGV4(method, uri, query, headers, payloadHash, signed)` | Build the SigV4 canonical request (and the signed-headers list, by ref). |
| `emptyHash` | `$$emptyHash^STDSIGV4()` | The SHA-256 of the empty string (the unsigned-body hash constant). |
| `encPath` | `$$encPath^STDSIGV4(key)` | URI-encode an object key (RFC 3986), preserving the "/" separator. |
| `encQuery` | `$$encQuery^STDSIGV4(params)` | Build the canonical query string: keys sorted, both sides URI-encoded. |
| `sign` | `$$sign^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)` | Compute the 64-char hex SigV4 signature. |
| `signingKey` | `$$signingKey^STDSIGV4(secret, datestamp, region, service)` | SigV4 raw 32-byte signing key (HMAC chain). |

### `$$amzDate^STDSIGV4()`

Current UTC timestamp in SigV4 basic-ISO form YYYYMMDDgHHMMSSZ.

**Returns** _string_ — 16-char basic-ISO UTC (e.g. 20260619T123456Z)

**Example**

```m
write $length($$amzDate^STDSIGV4())  ; 16
```

### `$$authHeader^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)`

Build the full Authorization header value.

**Parameters**

- `ctx` _(array)_ — ctx("accessKey"/"secretKey"/"region"/"service"), by reference
- `method` _(string)_ — HTTP method
- `uri` _(string)_ — canonical URI
- `query` _(string)_ — canonical query string
- `headers` _(array)_ — headers(name)=value, by reference
- `payloadHash` _(string)_ — hex SHA-256 of the body
- `amzdate` _(string)_ — x-amz-date YYYYMMDDgHHMMSSZ
- `datestamp` _(string)_ — YYYYMMDD

**Returns** _string_ — "AWS4-HMAC-SHA256 Credential=…, SignedHeaders=…, Signature=…"

**Example**

```m
new ctx,h set ctx("accessKey")="AKIAIOSFODNN7EXAMPLE",ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",ctx("region")="us-east-1",ctx("service")="s3",h("host")="examplebucket.s3.amazonaws.com",h("range")="bytes=0-9",h("x-amz-content-sha256")=$$emptyHash^STDSIGV4(),h("x-amz-date")="20130524T000000Z" do contains^STDASSERT(.pass,.fail,$$authHeader^STDSIGV4(.ctx,"GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),"20130524T000000Z","20130524"),"Signature=f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","header embeds the AWS S3 GET-Object signature")
```

### `$$canonRequest^STDSIGV4(method, uri, query, headers, payloadHash, signed)`

Build the SigV4 canonical request (and the signed-headers list, by ref).

**Parameters**

- `method` _(string)_ — HTTP method (GET/PUT/…)
- `uri` _(string)_ — canonical URI (already encPath'd, leading "/")
- `query` _(string)_ — canonical query string ("" if none)
- `headers` _(array)_ — headers(name)=value, by reference
- `payloadHash` _(string)_ — hex SHA-256 of the body (or UNSIGNED-PAYLOAD)
- `signed` _(string)_ — OUT — ";"-joined lowercased signed-header names

**Returns** _string_ — the canonical-request string (LF-joined)

**Example**

```m
new h,signed,cr set h("host")="examplebucket.s3.amazonaws.com",h("x-amz-date")="20130524T000000Z" set cr=$$canonRequest^STDSIGV4("GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),.signed) do eq^STDASSERT(.pass,.fail,signed,"host;x-amz-date","signed-header list returned by reference")
```

### `$$emptyHash^STDSIGV4()`

The SHA-256 of the empty string (the unsigned-body hash constant).

**Returns** _string_ — 64-char lowercase hex (e3b0c442…b855)

**Example**

```m
write $$emptyHash^STDSIGV4()  ; "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
```

### `$$encPath^STDSIGV4(key)`

URI-encode an object key (RFC 3986), preserving the "/" separator.

**Parameters**

- `key` _(string)_ — object key (one M character per byte)

**Returns** _string_ — percent-encoded path, "/" left literal

**Example**

```m
write $$encPath^STDSIGV4("a/my key.txt")  ; "a/my%20key.txt"
```

### `$$encQuery^STDSIGV4(params)`

Build the canonical query string: keys sorted, both sides URI-encoded.

**Parameters**

- `params` _(array)_ — params(name)=value, by reference

**Returns** _string_ — "k1=v1&k2=v2&…" sorted by encoded key

**Example**

```m
new q set q("b")=2,q("a")=1 do eq^STDASSERT(.pass,.fail,$$encQuery^STDSIGV4(.q),"a=1&b=2","keys sorted into canonical order")
```

### `$$sign^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)`

Compute the 64-char hex SigV4 signature.

**Parameters**

- `ctx` _(array)_ — ctx("secretKey"/"region"/"service"), by reference
- `method` _(string)_ — HTTP method
- `uri` _(string)_ — canonical URI
- `query` _(string)_ — canonical query string
- `headers` _(array)_ — headers(name)=value, by reference
- `payloadHash` _(string)_ — hex SHA-256 of the body
- `amzdate` _(string)_ — x-amz-date YYYYMMDDgHHMMSSZ
- `datestamp` _(string)_ — YYYYMMDD (the amzdate's date part)

**Returns** _string_ — 64-char lowercase hex signature

**Raises**

- `U-STDCRYPTO-CALLOUT-MISSING` — std_crypto not loaded

**Example**

```m
new ctx,h set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",ctx("region")="us-east-1",ctx("service")="s3",h("host")="examplebucket.s3.amazonaws.com",h("range")="bytes=0-9",h("x-amz-content-sha256")=$$emptyHash^STDSIGV4(),h("x-amz-date")="20130524T000000Z" do eq^STDASSERT(.pass,.fail,$$sign^STDSIGV4(.ctx,"GET","/test.txt","",.h,$$emptyHash^STDSIGV4(),"20130524T000000Z","20130524"),"f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41","AWS S3 GET-Object documented signature")
```

### `$$signingKey^STDSIGV4(secret, datestamp, region, service)`

SigV4 raw 32-byte signing key (HMAC chain).

**Parameters**

- `secret` _(string)_ — the AWS secret access key
- `datestamp` _(string)_ — YYYYMMDD (UTC)
- `region` _(string)_ — AWS region, e.g. us-east-1
- `service` _(string)_ — AWS service, e.g. s3

**Returns** _byte-string_ — raw 32-byte signing key

**Raises**

- `U-STDCRYPTO-CALLOUT-MISSING` — std_crypto not loaded

**Example**

```m
do eq^STDASSERT(.pass,.fail,$$encode^STDHEX($$signingKey^STDSIGV4("wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY","20150830","us-east-1","iam")),"2c94c0cf5378ada6887f09bb697df8fc0affdb34ba1cdd5bda32b664bd55b73c","AWS IAM known-answer signing key")
```

<!-- END GENERATED API REFERENCE -->

## Status

`@tier optional` — depends on **STDCRYPTO** (libcrypto HMAC/SHA-256), so it
requires that call-out to be loaded. Shipped in **v0.14.0** as the engine-neutral
half of the RPC+HL7→S3 traffic-tap stack (AWS S3 egress for the VistA traffic
tap; see [`changelog.md`](../changelog.md) v0.14.0).

**Dual-engine GREEN** — bare YottaDB (`m-test-engine`) and bare IRIS
(`m-test-iris`), `--chset m`. Anchored by AWS's **published known-answer
vectors**: the S3 GET-Object signature and canonical-request hash match
byte-for-byte (`STDSIGV4TST` 16/16, `STDSIGV4DOCTST` 2/2).

### The SigV4 flow

The four steps, and the public label that performs each:

1. **Canonical request** — `$$canonRequest` joins method, URI, query, the sorted
   canonical-headers block, the `;`-joined signed-header list, and the payload
   hash with LF (`$char(10)`).
2. **String-to-sign** — `$$sign` prefixes `AWS4-HMAC-SHA256`, the `amzdate`, the
   credential scope (`datestamp/region/service/aws4_request`), and the SHA-256 of
   the canonical request.
3. **Signing key** — `$$signingKey` derives a raw 32-byte key by chaining four
   HMAC-SHA-256 rounds (`AWS4`+secret → datestamp → region → service →
   `aws4_request`).
4. **Signature** — `$$sign` HMACs the string-to-sign with the signing key and
   emits 64-char lowercase hex. `$$authHeader` wraps that into the full
   `Authorization` value.

### The `ctx` signing context

`$$sign` and `$$authHeader` take a `ctx` array, by reference, holding the AWS
credentials and target:

```
ctx("accessKey")   ; AWS access key id     (authHeader only — goes in Credential=)
ctx("secretKey")   ; AWS secret access key (feeds $$signingKey)
ctx("region")      ; AWS region, e.g. "us-east-1"
ctx("service")     ; AWS service, e.g. "s3"
```

`$$sign` reads `secretKey`/`region`/`service`; `$$authHeader` additionally reads
`accessKey` for the `Credential=` field.

## Public API

### `$$authHeader^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)`

Build the full `Authorization` header value — the one call most callers need.

- **`ctx`** *(array, by ref)* — `ctx("accessKey"/"secretKey"/"region"/"service")`
- **`method`** *(string)* — HTTP method
- **`uri`** *(string)* — canonical URI (already `encPath`'d, leading `/`)
- **`query`** *(string)* — canonical query string (`""` if none)
- **`headers`** *(array, by ref)* — `headers(name)=value`
- **`payloadHash`** *(string)* — hex SHA-256 of the body
- **`amzdate`** *(string)* — `x-amz-date`, `YYYYMMDDgHHMMSSZ`
- **`datestamp`** *(string)* — `YYYYMMDD`
- **Returns** *(string)* — `"AWS4-HMAC-SHA256 Credential=…, SignedHeaders=…, Signature=…"`

```m
new ctx,hdrs,date,amz,auth
set ctx("accessKey")="AKIDEXAMPLE"
set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
set ctx("region")="us-east-1",ctx("service")="s3"
set amz="20260619T123456Z",date="20260619"
set hdrs("host")="examplebucket.s3.amazonaws.com"
set hdrs("x-amz-date")=amz
set hdrs("x-amz-content-sha256")=$$emptyHash^STDSIGV4()
set auth=$$authHeader^STDSIGV4(.ctx,"GET","/photo.jpg","",.hdrs,$$emptyHash^STDSIGV4(),amz,date)
write auth,!  ; AWS4-HMAC-SHA256 Credential=AKIDEXAMPLE/20260619/us-east-1/s3/aws4_request, SignedHeaders=host;x-amz-content-sha256;x-amz-date, Signature=<64-hex>
```

### `$$sign^STDSIGV4(ctx, method, uri, query, headers, payloadHash, amzdate, datestamp)`

Compute just the 64-char hex SigV4 signature (the `Signature=` value).

- **`ctx`** *(array, by ref)* — `ctx("secretKey"/"region"/"service")`
- **`method` / `uri` / `query` / `headers` / `payloadHash` / `amzdate` / `datestamp`** — as for `$$authHeader`
- **Returns** *(string)* — 64-char lowercase hex signature
- **Raises** — `U-STDCRYPTO-CALLOUT-MISSING` if `std_crypto` is not loaded

```m
new ctx,hdrs
set ctx("secretKey")="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
set ctx("region")="us-east-1",ctx("service")="s3"
set hdrs("host")="examplebucket.s3.amazonaws.com",hdrs("x-amz-date")="20260619T123456Z"
write $$sign^STDSIGV4(.ctx,"GET","/photo.jpg","",.hdrs,$$emptyHash^STDSIGV4(),"20260619T123456Z","20260619"),!
```

### `$$canonRequest^STDSIGV4(method, uri, query, headers, payloadHash, signed)`

Build the SigV4 canonical-request string and return the signed-header list by
reference.

- **`method`** *(string)* — HTTP method (`GET`/`PUT`/…)
- **`uri`** *(string)* — canonical URI (already `encPath`'d, leading `/`)
- **`query`** *(string)* — canonical query string (`""` if none)
- **`headers`** *(array, by ref)* — `headers(name)=value`
- **`payloadHash`** *(string)* — hex SHA-256 of the body (or `UNSIGNED-PAYLOAD`)
- **`signed`** *(string, OUT)* — `;`-joined lowercased signed-header names
- **Returns** *(string)* — the LF-joined canonical-request string

Internally, header names are lowercased (`$$toLowerASCII^STDSTR`) and values
trimmed (`$$trim^STDSTR`), then sorted by `$order` so the canonical-headers block
and the `signed` list are both in canonical order.

```m
new hdrs,signed,cr
set hdrs("Host")="example.s3.amazonaws.com",hdrs("X-Amz-Date")="20260619T123456Z"
set cr=$$canonRequest^STDSIGV4("GET","/k","",.hdrs,$$emptyHash^STDSIGV4(),.signed)
write signed,!  ; host;x-amz-date
```

### `$$signingKey^STDSIGV4(secret, datestamp, region, service)`

Derive the raw 32-byte SigV4 signing key (the HMAC chain).

- **`secret`** *(string)* — the AWS secret access key
- **`datestamp`** *(string)* — `YYYYMMDD` (UTC)
- **`region`** *(string)* — AWS region, e.g. `us-east-1`
- **`service`** *(string)* — AWS service, e.g. `s3`
- **Returns** *(byte-string)* — raw 32-byte signing key
- **Raises** — `U-STDCRYPTO-CALLOUT-MISSING` if `std_crypto` is not loaded

Each round keys the next on **raw bytes** via `$$hmacSha256Bytes^STDCRYPTO`
(`AWS4`+secret → datestamp → region → service → `aws4_request`) — the classic
SigV4 bug if any round were to hex-encode first. The result feeds `$$sign`.

```m
write $length($$signingKey^STDSIGV4("secret","20260619","us-east-1","s3")),!  ; 32
```

### `$$encPath^STDSIGV4(key)`

URI-encode an object key (RFC 3986), **preserving the `/` separator** so a path
stays a path.

- **`key`** *(string)* — object key (one M character per byte)
- **Returns** *(string)* — percent-encoded path, `/` left literal

```m
write $$encPath^STDSIGV4("a/my key.txt"),!  ; a/my%20key.txt
```

### `$$encQuery^STDSIGV4(params)`

Build the canonical query string: keys sorted, both name and value URI-encoded.

- **`params`** *(array, by ref)* — `params(name)=value`
- **Returns** *(string)* — `"k1=v1&k2=v2&…"` sorted by encoded key

```m
new q
set q("b")=2,q("a")=1
write $$encQuery^STDSIGV4(.q),!  ; a=1&b=2
```

### `$$amzDate^STDSIGV4()`

Current UTC timestamp in SigV4 basic-ISO form `YYYYMMDDgHHMMSSZ`.

- **Returns** *(string)* — 16-char basic-ISO UTC (e.g. `20260619T123456Z`)

Derived from `$$now^STDDATE` (extended ISO with separators); the `-`, `:` and
`.sss` fraction are stripped to the SigV4 basic form. The first 8 characters are
the `datestamp` that `$$sign`/`$$signingKey`/`$$authHeader` also need.

```m
new amz,date
set amz=$$amzDate^STDSIGV4()      ; 20260619T123456Z
set date=$extract(amz,1,8)        ; 20260619
```

### `$$emptyHash^STDSIGV4()`

The SHA-256 of the empty string — the payload-hash constant for a bodyless
request (`GET`, `HEAD`, `DELETE`, …).

- **Returns** *(string)* — 64-char lowercase hex (`e3b0c442…b855`)

```m
write $$emptyHash^STDSIGV4()  ; e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

## Notes & gotchas

- **Byte mode is mandatory.** Steps 1–3 of the signing-key chain pass raw 32-byte
  HMAC outputs as the *key* to the next HMAC (`…Bytes` crypto variants); only
  step 4 emits hex. Under `ydb_chset=UTF-8` those raw-byte keys would re-encode
  and silently produce a **wrong signature** that AWS rejects. Run the engine in
  byte (M) mode — the m-stdlib default (`ydb_chset=M`).
- **Caller computes the dates once.** `amzdate` and `datestamp` are passed in (not
  read from the clock inside `$$sign`) so the canonical headers, the
  `x-amz-date` header, and the credential scope all use the *same* instant. Use
  `$$amzDate` once and slice `datestamp` from `$extract(amz,1,8)`.
- **`payloadHash` must match the body you send.** For a bodyless request use
  `$$emptyHash`; for a body, pass `$$sha256^STDCRYPTO(body)`. The same value must
  also go in the `x-amz-content-sha256` header you sign. AWS recomputes and
  compares.
- **URI must already be `encPath`'d** with a leading `/`. `$$canonRequest`/`$$sign`
  do not re-encode the URI — run the object key through `$$encPath` first.
- **Host is signed but not necessarily sent by you.** Include `host` in `headers`
  so it joins the signed-header list; the HTTP client (`STDHTTP` / `STDS3`)
  supplies the actual `Host:` from the URL. (IRIS `%Net.HttpRequest` errors if
  `Host` is set by hand — see the v0.14.0 discoveries.)
- **STDCRYPTO required.** `$$sign` / `$$signingKey` raise
  `U-STDCRYPTO-CALLOUT-MISSING` when the libcrypto call-out is not loaded. The
  pure-string helpers (`$$canonRequest`, `$$encPath`, `$$encQuery`, `$$amzDate`,
  `$$emptyHash`) work without it.

## See also

- [`STDCRYPTO`](stdcrypto.md) — HMAC-SHA-256 / SHA-256 primitives every signing
  step rests on (`$$hmacSha256Bytes`, `$$hmacSha256`, `$$sha256`).
- [`STDURL`](stdurl.md) — RFC 3986 percent-encoding behind `$$encPath`/`$$encQuery`.
- [`STDDATE`](stddate.md) — `$$now^STDDATE`, the clock behind `$$amzDate`.
- `STDS3` — the S3 REST client; the first `STDSIGV4` consumer.
