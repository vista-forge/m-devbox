---
module: STDSTR
tag: v0.3.0
phase: P4 wave
stable: stable
since: v0.3.0
synopsis: 'String helpers (pad / trim / split / replaceAll / case / repeat)'
labels: ['endsWith', 'pad', 'padLeft', 'padRight', 'repeat', 'replaceAll', 'split', 'startsWith', 'toLowerASCII', 'toUpperASCII', 'trim', 'trimLeft', 'trimRight']
errors: []
conformance: []
see_also: []
---

# `STDSTR` — String helpers

A small set of string-manipulation primitives that show up
repeatedly across other modules: pad, trim, replace, split,
prefix / suffix predicates, ASCII case conversion, repeat.
Pure-M throughout — no `$Z*` extensions, no STDREGEX dep — so
runs unchanged on YDB and IRIS.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `endsWith` | `$$endsWith^STDSTR(s, suffix)` | Return 1 iff s ends with suffix; else 0. Empty suffix → 1. |
| `pad` | `$$pad^STDSTR(s, n, c)` | Alias for padLeft — common numeric-formatting shorthand. |
| `padLeft` | `$$padLeft^STDSTR(s, n, c)` | Left-pad s to width n with c (default " "). Returns s unchanged |
| `padRight` | `$$padRight^STDSTR(s, n, c)` | Right-pad s to width n with c (default " "). Returns s unchanged |
| `repeat` | `$$repeat^STDSTR(s, n)` | Concatenate s with itself n times. Returns "" for n ≤ 0 or s="". |
| `replaceAll` | `$$replaceAll^STDSTR(s, find, repl)` | Replace every non-overlapping left-to-right occurrence. |
| `split` | `$$split^STDSTR(s, sep, out)` | Split s on sep; populate out(1..N); return N. |
| `startsWith` | `$$startsWith^STDSTR(s, prefix)` | Return 1 iff s begins with prefix; else 0. Empty prefix → 1. |
| `toLowerASCII` | `$$toLowerASCII^STDSTR(s)` | A-Z → a-z; preserves all other characters. |
| `toUpperASCII` | `$$toUpperASCII^STDSTR(s)` | a-z → A-Z; preserves all other characters. |
| `trim` | `$$trim^STDSTR(s)` | Strip leading and trailing whitespace (space / tab / LF / CR). |
| `trimLeft` | `$$trimLeft^STDSTR(s)` | Strip leading whitespace only. |
| `trimRight` | `$$trimRight^STDSTR(s)` | Strip trailing whitespace only. |

### `$$endsWith^STDSTR(s, suffix)`

Return 1 iff s ends with suffix; else 0. Empty suffix → 1.

**Parameters**

- `s` _(string)_ — the string to test
- `suffix` _(string)_ — the suffix to look for

**Returns** _bool_ — 1 iff s ends with suffix; empty suffix returns 1

**Example**

```m
write $$endsWith^STDSTR("hello world","world")  ; 1
```

### `$$pad^STDSTR(s, n, c)`

Alias for padLeft — common numeric-formatting shorthand.

**Parameters**

- `s` _(string)_ — the string to pad
- `n` _(int)_ — target width (no-op if $LENGTH(s) >= n)
- `c` _(string)_ — fill character (default " "; first char only used)

**Returns** _string_ — s left-padded with c to width n

**Example**

```m
write $$pad^STDSTR("5",3,"0")  ; "005"
```

### `$$padLeft^STDSTR(s, n, c)`

Left-pad s to width n with c (default " "). Returns s unchanged

**Parameters**

- `s` _(string)_ — the string to pad
- `n` _(int)_ — target width
- `c` _(string)_ — fill character (default " "; first char only used)

**Returns** _string_ — s left-padded; s unchanged if $LENGTH(s) >= n

**Example**

```m
write $$padLeft^STDSTR("ab",6,"-")  ; "----ab"
```

### `$$padRight^STDSTR(s, n, c)`

Right-pad s to width n with c (default " "). Returns s unchanged

**Parameters**

- `s` _(string)_ — the string to pad
- `n` _(int)_ — target width
- `c` _(string)_ — fill character (default " "; first char only used)

**Returns** _string_ — s right-padded; s unchanged if $LENGTH(s) >= n

**Example**

```m
write $$padRight^STDSTR("ab",6,"-")  ; "ab----"
```

### `$$repeat^STDSTR(s, n)`

Concatenate s with itself n times. Returns "" for n ≤ 0 or s="".

**Parameters**

- `s` _(string)_ — the string to repeat
- `n` _(int)_ — repetition count (n <= 0 yields "")

**Returns** _string_ — s concatenated with itself n times

**Example**

```m
write $$repeat^STDSTR("ab",3)  ; "ababab"
```

### `$$replaceAll^STDSTR(s, find, repl)`

Replace every non-overlapping left-to-right occurrence.

**Parameters**

- `s` _(string)_ — the string to scan
- `find` _(string)_ — the substring to match (multi-char allowed)
- `repl` _(string)_ — the replacement

**Returns** _string_ — s with every non-overlapping match replaced

**Example**

```m
write $$replaceAll^STDSTR("a-b-c","-","+")  ; "a+b+c"
```

### `$$split^STDSTR(s, sep, out)`

Split s on sep; populate out(1..N); return N.

**Parameters**

- `s` _(string)_ — the string to split
- `sep` _(string)_ — the separator (multi-char allowed)
- `out` _(array)_ — by-ref local; killed then populated as out(1..N)

**Returns** _int_ — number of pieces (0 if s="" or sep="")

**Example**

```m
new out do eq^STDASSERT(.pass,.fail,$$split^STDSTR("a,b,c",",",.out),3,"split returns piece count")
new out,n set n=$$split^STDSTR("a,b,c",",",.out) do eq^STDASSERT(.pass,.fail,out(2),"b","split populates out(1..N)")
```

### `$$startsWith^STDSTR(s, prefix)`

Return 1 iff s begins with prefix; else 0. Empty prefix → 1.

**Parameters**

- `s` _(string)_ — the string to test
- `prefix` _(string)_ — the prefix to look for

**Returns** _bool_ — 1 iff s begins with prefix; empty prefix returns 1

**Example**

```m
write $$startsWith^STDSTR("hello world","hello")  ; 1
```

### `$$toLowerASCII^STDSTR(s)`

A-Z → a-z; preserves all other characters.

**Parameters**

- `s` _(string)_ — the string to lowercase

**Returns** _string_ — s with A-Z mapped to a-z (other chars unchanged)

**Example**

```m
write $$toLowerASCII^STDSTR("Hello-World")  ; "hello-world"
```

### `$$toUpperASCII^STDSTR(s)`

a-z → A-Z; preserves all other characters.

**Parameters**

- `s` _(string)_ — the string to uppercase

**Returns** _string_ — s with a-z mapped to A-Z (other chars unchanged)

**Example**

```m
write $$toUpperASCII^STDSTR("Hello-World")  ; "HELLO-WORLD"
```

### `$$trim^STDSTR(s)`

Strip leading and trailing whitespace (space / tab / LF / CR).

**Parameters**

- `s` _(string)_ — the string to trim

**Returns** _string_ — s with outer whitespace stripped

**Example**

```m
write $$trim^STDSTR("  hello  ")  ; "hello"
```

### `$$trimLeft^STDSTR(s)`

Strip leading whitespace only.

**Parameters**

- `s` _(string)_ — the string to trim

**Returns** _string_ — s with leading whitespace stripped

**Example**

```m
write $$trimLeft^STDSTR("  x  ")  ; "x  "
```

### `$$trimRight^STDSTR(s)`

Strip trailing whitespace only.

**Parameters**

- `s` _(string)_ — the string to trim

**Returns** _string_ — s with trailing whitespace stripped

**Example**

```m
write $$trimRight^STDSTR("  x  ")  ; "  x"
```

<!-- END GENERATED API REFERENCE -->

## Public API

| Extrinsic | Signature | Returns |
|---|---|---|
| `pad` | `$$pad^STDSTR(s, n, c?)` | Alias for `padLeft` (numeric-formatting default). |
| `padLeft` | `$$padLeft^STDSTR(s, n, c?)` | s left-padded with c (default `" "`) to width n. |
| `padRight` | `$$padRight^STDSTR(s, n, c?)` | s right-padded to width n. |
| `trim` | `$$trim^STDSTR(s)` | s with leading and trailing whitespace stripped. |
| `trimLeft` | `$$trimLeft^STDSTR(s)` | s with leading whitespace stripped. |
| `trimRight` | `$$trimRight^STDSTR(s)` | s with trailing whitespace stripped. |
| `replaceAll` | `$$replaceAll^STDSTR(s, find, repl)` | s with every non-overlapping `find` replaced by `repl`. |
| `split` | `$$split^STDSTR(s, sep, .out)` | Splits s on sep; populates `out(1..N)`; returns N. |
| `startsWith` | `$$startsWith^STDSTR(s, prefix)` | `1` iff s begins with prefix. |
| `endsWith` | `$$endsWith^STDSTR(s, suffix)` | `1` iff s ends with suffix. |
| `toLowerASCII` | `$$toLowerASCII^STDSTR(s)` | A-Z → a-z; non-alpha preserved. |
| `toUpperASCII` | `$$toUpperASCII^STDSTR(s)` | a-z → A-Z; non-alpha preserved. |
| `repeat` | `$$repeat^STDSTR(s, n)` | s concatenated with itself n times. |

## Examples

```m
; padding (numeric formatting)
WRITE $$pad^STDSTR("5",3,"0"),!         ; "005"
WRITE $$padRight^STDSTR("ab",6,"-"),!   ; "ab----"
WRITE $$padLeft^STDSTR("x",4),!         ; "   x"  (default char is space)

; whitespace
WRITE $$trim^STDSTR("  hello  "),!      ; "hello"
WRITE $$trim^STDSTR($CHAR(9)_"hi"_$CHAR(10,13,32)),!  ; "hi"

; substitution
WRITE $$replaceAll^STDSTR("a-b-c","-","+"),!     ; "a+b+c"
WRITE $$replaceAll^STDSTR("foofoofoo","foo","bar"),!  ; "barbarbar"

; tokenisation
DO  SET n=$$split^STDSTR("a,b,c",",",.out)
WRITE n,!                                ; 3
WRITE out(1),"|",out(2),"|",out(3),!    ; a|b|c

; predicates
WRITE $$startsWith^STDSTR("hello world","hello"),!  ; 1
WRITE $$endsWith^STDSTR("hello world","world"),!    ; 1

; case-folding (ASCII only)
WRITE $$toLowerASCII^STDSTR("Hello-World"),!  ; "hello-world"
WRITE $$toUpperASCII^STDSTR("Hello-World"),!  ; "HELLO-WORLD"

; rep
WRITE $$repeat^STDSTR("-",10),!              ; "----------"
```

## Whitespace definition

`trim` / `trimLeft` / `trimRight` strip the four ASCII whitespace
characters: space (`$C(32)`), tab (`$C(9)`), LF (`$C(10)`), CR
(`$C(13)`). Internal whitespace is **always preserved**:

| Input | `trim` |
|---|---|
| `"  hello  "` | `"hello"` |
| `"  a  b  "` | `"a  b"` |
| `" \t\n\r hi \r\n\t "` | `"hi"` |
| `"     "` | `""` |
| `""` | `""` |

Unicode whitespace classes (NBSP, ideographic space, Mongolian
vowel separator, etc.) are **not** stripped. This keeps `trim`
byte-faithful and idempotent under any `$ZCHSET` mode — Unicode-
aware whitespace handling waits on a future `STDUNICODE` module.

## `replaceAll` semantics

- Empty `find` returns `s` unchanged (no infinite loop).
- Scan is **non-overlapping greedy left-to-right**:
  `replaceAll("aaaa", "aa", "b")` is `"bb"`, not `"ba"`.
- Replacement is **non-recursive**: bytes inserted by `repl` are
  not rescanned. `replaceAll("aa", "a", "aa")` is `"aaaa"`, not
  an infinite expansion.
- Implementation is `$piece`-based — split `s` on `find`, rejoin
  with `repl`. O(N) in input length.

## `split` semantics

- Empty input returns 0 with `out` cleared.
- Empty separator returns 0 (avoids infinite loop; matches
  Python's `str.split` with no separator argument behaving
  differently — STDSTR's split deliberately requires an explicit
  separator).
- Multi-char `sep` matches the literal sequence (`"a::b::c"` with
  `sep="::"` yields three pieces).
- Trailing separator yields a trailing empty element: `"a,b,"`
  with `sep=","` yields `["a", "b", ""]`.
- Implementation: `$piece`-walk.

## ASCII case conversion

`toLowerASCII` / `toUpperASCII` are byte-wise `$translate`
operations on the 26 letters `A-Z` ↔ `a-z`. They preserve
**every other byte** including digits, punctuation, whitespace,
and high-bit-set bytes. They are **not** locale-aware:
`toLowerASCII("Ä")` returns `"Ä"` (the byte sequence is preserved
verbatim). Use these for case-insensitive comparisons of
machine-generated identifiers (env var names, hex strings,
HTTP method tokens) where only the ASCII letter range matters.

## Engine portability

Pure-M, no `$Z*` extensions. Runs unchanged on YDB and IRIS. The
test suite (63 assertions across 37 labels) is the conformance
gate.

## See also

- [`STDFMT`](stdfmt.md) — printf-style formatter; has its own
  width / fill / alignment handling and does not use STDSTR.pad.
- [`STDARGS`](stdargs.md) — has its own quote-aware tokeniser
  (an upgrade over `split`); STDSTR.split is for one-pass simple
  separators.
- [`STDOS`](stdos.md) — `splitArgs` is whitespace-only and has
  the same shape as STDSTR.split with `sep=" "` plus run-collapse;
  the two will likely merge under a single tokeniser when STDOS
  picks up quote-aware splitting (T15).

## History

ASCII-only by design — pad / padLeft / padRight, trim / trimLeft /
trimRight, replaceAll, split, startsWith / endsWith, toLowerASCII /
toUpperASCII, repeat. Pure-M (`$translate` / `$piece` / `$find` /
`$extract`); no `$Z*` extensions, no STDREGEX dep.

**Optional add-on (T17, deferred):** Unicode whitespace + locale-aware
case folding. Deferred behind a future `STDUNICODE`. Activates when a
concrete consumer hits the ASCII-only limit.
