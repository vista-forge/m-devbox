---
module: STDNET
tag: v0.8.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.8.0
synopsis: 'portable raw-TCP socket primitives (engine-native sockets)'
labels: ['accept', 'available', 'boundport', 'close', 'connect', 'listen', 'read', 'write']
errors: []
conformance: []
see_also: []
---

# `STDNET` — portable raw-TCP socket primitives

`STDNET` is the portable socket seam (**S4** of the MSL⟷VSL coordination plan):
a thin, handle-based, **raw-byte** TCP API that any pure-M service can use on a
bare engine, and that the VistA `VSLIO` adapter binds to VistA's device handler
(`^%ZIS` / `CALL^%ZISTCP`) above the m/v waterline. It drives each engine's
**native socket device** — no C call-outs — with the (large) engine divergence
isolated behind `$ZVERSION["IRIS"` arms.

`@tier optional` — engine-sensitive (dual-engine: YottaDB + IRIS).

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `accept` | `$$accept^STDNET(id, timeout)` | Accept a pending connection on a listener handle. |
| `available` | `$$available^STDNET()` | 1 iff STDNET raw sockets are wired on this engine. |
| `boundport` | `$$boundport^STDNET(id)` | The actual bound port of a listener handle. |
| `close` | `$$close^STDNET(id)` | Close a handle (listener or connection) and free its state. |
| `connect` | `$$connect^STDNET(host, port, timeout)` | Open a client TCP connection to host:port. |
| `listen` | `$$listen^STDNET(port)` | Open a listening TCP socket on `port` (0 => OS-assigned). |
| `read` | `$$read^STDNET(id, maxlen, timeout, buf)` | Raw-read up to maxlen bytes from a handle. |
| `write` | `$$write^STDNET(id, buf)` | Raw-write `buf` to a connected handle. |

### `$$accept^STDNET(id, timeout)`

Accept a pending connection on a listener handle.

**Parameters**

- `id` _(numeric)_ — a listener handle from $$listen
- `timeout` _(numeric)_ — seconds to wait for a connection

**Returns** _numeric_ — a connected handle (>0), or 0 on timeout/failure

**Example**

```m
new srv,cli,conn set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5) do true^STDASSERT(.pass,.fail,conn>0,"accepted a connection") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
```

### `$$available^STDNET()`

1 iff STDNET raw sockets are wired on this engine.

**Returns** _bool_ — 1 on YottaDB and IRIS

**Example**

```m
write $$available^STDNET()  ; 1
```

### `$$boundport^STDNET(id)`

The actual bound port of a listener handle.

**Parameters**

- `id` _(numeric)_ — a listener handle from $$listen

**Returns** _numeric_ — the bound TCP port (meaningful after $$listen)

**Example**

```m
new srv set srv=$$listen^STDNET(0) do true^STDASSERT(.pass,.fail,$$boundport^STDNET(srv)>0,"bound to a port") set srv=$$close^STDNET(srv)
```

### `$$close^STDNET(id)`

Close a handle (listener or connection) and free its state.

**Parameters**

- `id` _(numeric)_ — a handle from $$listen/$$accept/$$connect

**Returns** _bool_ — 1 (idempotent)

**Example**

```m
write $$close^STDNET(0)  ; 1
```

### `$$connect^STDNET(host, port, timeout)`

Open a client TCP connection to host:port.

**Parameters**

- `host` _(string)_ — host/IP to connect to
- `port` _(numeric)_ — TCP port
- `timeout` _(numeric)_ — seconds to wait for the connect

**Returns** _numeric_ — a connected handle (>0), or 0 on failure

**Example**

```m
new srv,cli set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5) do true^STDASSERT(.pass,.fail,cli>0,"client connected") set cli=$$close^STDNET(cli),srv=$$close^STDNET(srv)
```

### `$$listen^STDNET(port)`

Open a listening TCP socket on `port` (0 => OS-assigned).

**Parameters**

- `port` _(numeric)_ — TCP port to bind; 0 lets the OS choose

**Returns** _numeric_ — a listener handle (>0), or 0 on failure

**Example**

```m
new srv set srv=$$listen^STDNET(0) do true^STDASSERT(.pass,.fail,srv>0,"opened a listener") set srv=$$close^STDNET(srv)
```

### `$$read^STDNET(id, maxlen, timeout, buf)`

Raw-read up to maxlen bytes from a handle.

**Parameters**

- `id` _(numeric)_ — a connected handle
- `maxlen` _(numeric)_ — maximum bytes to read
- `timeout` _(numeric)_ — seconds to wait for data
- `buf` _(string)_ — by-ref; receives the bytes read

**Returns** _numeric_ — bytes read (0 on timeout/EOF)

**Example**

```m
new srv,cli,conn,buf,n set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5),n=$$write^STDNET(cli,"ping"),n=$$read^STDNET(conn,99,5,.buf) do eq^STDASSERT(.pass,.fail,buf,"ping","server read the client's bytes") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
```

### `$$write^STDNET(id, buf)`

Raw-write `buf` to a connected handle.

**Parameters**

- `id` _(numeric)_ — a connected handle
- `buf` _(string)_ — bytes to write (raw, no delimiter)

**Returns** _bool_ — 1 on success; 0 on failure

**Example**

```m
new srv,cli,conn,buf,n set srv=$$listen^STDNET(0),cli=$$connect^STDNET("127.0.0.1",$$boundport^STDNET(srv),5),conn=$$accept^STDNET(srv,5),n=$$write^STDNET(cli,"hello"),n=$$read^STDNET(conn,99,5,.buf) do eq^STDASSERT(.pass,.fail,buf,"hello","the written bytes arrived") set cli=$$close^STDNET(cli),conn=$$close^STDNET(conn),srv=$$close^STDNET(srv)
```

<!-- END GENERATED API REFERENCE -->

## Public API

All transfers are raw bytes: no record delimiter, no packet framing. Handles are
small integers; per-handle state (device name, accepted-socket name, bound port)
lives in the process-private `^STDLIB($job,"stdnet",id,*)`.

| Call | Purpose |
|---|---|
| `$$available^STDNET()` | `1` iff raw sockets are wired on this engine |
| `$$listen^STDNET(port)` | open a listening socket (`0` ⇒ OS-assigned port) → handle, or `0` |
| `$$boundport^STDNET(id)` | the actual bound port of a listener handle |
| `$$accept^STDNET(id,timeout)` | accept a pending connection → connection handle, or `0` |
| `$$connect^STDNET(host,port,timeout)` | client connect → handle, or `0` |
| `$$read^STDNET(id,maxlen,timeout,.buf)` | raw-read up to `maxlen` bytes → count, `buf` by-ref |
| `$$write^STDNET(id,buf)` | raw-write `buf` → `1`/`0` |
| `$$close^STDNET(id)` | close a handle (idempotent) → `1` |

### Loopback echo (the shape `STDNETTST` proves)

```m
set srv=$$listen^STDNET(0)                     ; OS-assigned port
set port=$$boundport^STDNET(srv)
set cli=$$connect^STDNET("127.0.0.1",port,5)
set conn=$$accept^STDNET(srv,5)                ; the server-side connection
if $$write^STDNET(cli,"ping")
set n=$$read^STDNET(conn,99,5,.buf)            ; buf="ping"
if $$write^STDNET(conn,buf)                    ; echo back
set n=$$read^STDNET(cli,99,5,.buf)             ; buf="ping"
set n=$$close^STDNET(cli),n=$$close^STDNET(conn),n=$$close^STDNET(srv)
```

## Engine support & portability

- **YottaDB** — implemented. YottaDB's `SOCKET` device is a *collection of
  sockets per device*, so a single process can `listen` + `connect` + `accept`
  (the loopback the suite uses). `accept` is `WRITE /WAIT`, which **auto-accepts**
  the connection — the new socket handle is `$PIECE($KEY,"|",2)` (there is no
  separate `/ACCEPT`; that raises `LOCALSOCKREQ`). Each verb saves/restores `$IO`
  so it never disturbs the caller's current device.
- **IRIS** — implemented. IRIS has no collection-of-sockets device, so each
  handle is its own `|TCP|n` device. The listener is opened in **accept mode**
  (`OPEN dev:(:port:"AM"):2`) — its **first `READ` returns `""`** the moment a
  client is accepted, and the listener device then **becomes the connection**
  (one connection per listener; no separate `JOB`'d connector is needed for the
  single-process loopback). The bound port (incl. an OS-assigned port 0) is read
  with `##class(%SYSTEM.TCPDevice).LocalPort()`, kept behind an `xecute` so
  YottaDB never compiles the `##class` syntax. Writes must **flush** with
  `WRITE *-3` (default wait mode buffers otherwise). **Reads are byte-at-a-time**
  (`READ *c:t`, accumulated up to `maxlen`): a fixed-length `READ x#n:t` on a
  `|TCP|` device is **CR-terminated** — it stops at the first CR and strips the
  CRLF, which would corrupt binary/HTTP (`\r\n`) data; `READ *c` never interprets
  a terminator, so the read is byte-exact (fixed v0.12.1, found by v-web M6.3).
  The first byte waits up to the timeout; follow-on bytes drain with a zero
  timeout, returning the currently-available raw bytes. A read on a socket whose
  **peer has already closed** raises an IRIS `<DSCON>`-class disconnect that
  (unlike YottaDB, which drains + EOFs) would **kill the job** — so the IRIS drain
  loop runs under an ObjectScript `try { … } catch { }` (the same disconnect-trap
  idiom `invoke^STDHTTPD` uses; flag-`$ETRAP` does not catch IRIS disconnects),
  yielding the already-buffered bytes then a clean `0`/EOF return (fixed v0.12.2,
  found by v-web M6.3's read-back). Live-verified on `m-test-iris`: `STDNETTST`
  runs the full loopback **22/22** (incl. the CRLF byte-exact and peer-closed
  drain-then-EOF regressions), same as YottaDB.

## Seam contract

The side-effecting verbs (`listen`/`accept`/`connect`/`read`/`write`/`close`)
carry `; doc: @seam STDNET` → the `seams.STDNET` block of `dist/stdlib-manifest.json`
(+ `dist/seam-snapshot.json`). `VSLIO` (v-stdlib, M2) pins this contract and
implements the same signatures over `^%ZIS`/`CALL^%ZISTCP` + named TLS.
