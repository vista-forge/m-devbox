---
module: STDHTTPMSG
tag: v0.10.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.10.0
synopsis: 'pure-M HTTP/1.1 parse+serialize codec (the §5 seam)'
labels: ['hdr', 'parseReq', 'parseRsp', 'serializeReq', 'serializeRsp']
errors: []
conformance: []
see_also: ['STDHTTPD']
---

# `STDHTTPMSG` — pure-M HTTP/1.1 parse+serialize codec (the §5 seam)

A byte-level HTTP/1.1 message codec, identical on YottaDB and IRIS. It is the
**portability seam** the VistA-native HTTPS stack (the VWEB capstone) sits on:
the engine-neutral half of the inbound/outbound web stack. The bytes that feed
it come from the socket layer (STDNET + the per-engine VWEBIO adapter, above
the waterline); the codec itself knows nothing of sockets, TLS, VistA, XPAR, or
`$ZF`. That is exactly why it lives here in m-stdlib and not in the VWEB
package — and why it is **distinct from the libcurl-backed [`STDHTTP`](stdhttp.md)
outbound client**.

It is **symmetric** (P4): the same `REQ`/`RSP` contract serves inbound (parse a
request, serialize a response) and outbound (serialize a request, parse a
response). The codec is **buffer-at-once** — the caller (STDHTTPD's worker loop
or the outbound client) owns the socket read and hands a complete in-memory
buffer down. A streaming pull/feed interface is a documented future extension
(spec §15) and is deliberately not built here.

Built on the existing STD\* leaves — percent-decode [`STDURL`](stdurl.md),
string ops [`STDSTR`](stdstr.md), the `Date` header [`STDDATE`](stddate.md)
(`$$httpdate`), the JSON body [`STDJSON`](stdjson.md). Nothing here is
re-implemented from those.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `hdr` | `$$hdr^STDHTTPMSG(MSG, name)` | Case-insensitive header lookup over MSG("hdr",…). |
| `parseReq` | `$$parseReq^STDHTTPMSG(buf, REQ, opts)` | Parse an HTTP/1.1 request buffer into the REQ contract. |
| `parseRsp` | `$$parseRsp^STDHTTPMSG(buf, RSP, opts)` | Parse an HTTP/1.1 response buffer into the RSP contract. |
| `serializeReq` | `$$serializeReq^STDHTTPMSG(REQ)` | Serialize the REQ contract into HTTP/1.1 request bytes. |
| `serializeRsp` | `$$serializeRsp^STDHTTPMSG(RSP)` | Serialize the RSP contract into HTTP/1.1 response bytes. |

### `$$hdr^STDHTTPMSG(MSG, name)`

Case-insensitive header lookup over MSG("hdr",…).

**Parameters**

- `MSG` _(array)_ — by-ref REQ or RSP carrying an "hdr" subtree
- `name` _(string)_ — header name (any casing)

**Returns** _string_ — the header value, or "" if absent

**Example**

```m
set msg("hdr","Content-Type")="text/html" do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.msg,"content-type"),"text/html","hdr case-insensitive")
set msg("hdr","Host")="h" do eq^STDASSERT(.pass,.fail,$$hdr^STDHTTPMSG(.msg,"x-missing"),"","hdr absent returns empty")
```

### `$$parseReq^STDHTTPMSG(buf, REQ, opts)`

Parse an HTTP/1.1 request buffer into the REQ contract.

**Parameters**

- `buf` _(string)_ — complete request bytes (request line + headers + body)
- `REQ` _(array)_ — by-ref; killed then populated per spec §5.1
- `opts` _(array)_ — by-ref size caps (maxline/maxhdrcount/maxhdrbytes/maxbody); optional

**Returns** _numeric_ — HTTP status: 200 ok; 400/413/414/431 on a bad request

**Example**

```m
set crlf=$char(13,10) set buf="GET /a?x=1 HTTP/1.1"_crlf_"Host: h"_crlf_crlf do eq^STDASSERT(.pass,.fail,$$parseReq^STDHTTPMSG(buf,.req),200,"parseReq ok")
set crlf=$char(13,10) set buf="POST /p HTTP/1.1"_crlf_"Host: h"_crlf_crlf set st=$$parseReq^STDHTTPMSG(buf,.req) do eq^STDASSERT(.pass,.fail,req("method"),"POST","parseReq fills method")
```

### `$$parseRsp^STDHTTPMSG(buf, RSP, opts)`

Parse an HTTP/1.1 response buffer into the RSP contract.

**Parameters**

- `buf` _(string)_ — complete response bytes (status line + headers + body)
- `RSP` _(array)_ — by-ref; killed then populated per spec §5.2
- `opts` _(array)_ — by-ref size caps (maxbody); optional

**Returns** _numeric_ — HTTP status: 200 ok; 400/413 on a bad response

**Example**

```m
set crlf=$char(13,10) set buf="HTTP/1.1 404 Not Found"_crlf_"Content-Length: 0"_crlf_crlf do eq^STDASSERT(.pass,.fail,$$parseRsp^STDHTTPMSG(buf,.rsp),200,"parseRsp ok")
set crlf=$char(13,10) set buf="HTTP/1.1 201 Created"_crlf_"Content-Length: 0"_crlf_crlf set st=$$parseRsp^STDHTTPMSG(buf,.rsp) do eq^STDASSERT(.pass,.fail,rsp("status"),201,"parseRsp fills status")
```

### `$$serializeReq^STDHTTPMSG(REQ)`

Serialize the REQ contract into HTTP/1.1 request bytes.

**Parameters**

- `REQ` _(array)_ — by-ref request per spec §5.1 (method/rawpath/rawquery/hdr/body)

**Returns** _string_ — full request bytes (request line + headers + CRLF + body)

**Example**

```m
set req("method")="GET",req("rawpath")="/a" do contains^STDASSERT(.pass,.fail,$$serializeReq^STDHTTPMSG(.req),"GET /a HTTP/1.1","serializeReq request line")
```

### `$$serializeRsp^STDHTTPMSG(RSP)`

Serialize the RSP contract into HTTP/1.1 response bytes.

**Parameters**

- `RSP` _(array)_ — by-ref response per spec §5.2 (status/hdr/body/json)

**Returns** _string_ — full response bytes (status line + headers + CRLF + body)

**Example**

```m
set rsp("status")=200,rsp("reason")="OK" do contains^STDASSERT(.pass,.fail,$$serializeRsp^STDHTTPMSG(.rsp),"HTTP/1.1 200 OK","serializeRsp status line")
```

<!-- END GENERATED API REFERENCE -->

## Status

**Shipped in `v0.10.0` (VSL/MSL M6.1) — the fourth `@seam`.** Pure-M and
**dual-engine GREEN** (bare YottaDB m-test-engine + bare IRIS m-test-iris,
byte-exact, no `$ZVERSION` arm, no callout). 66/66 tests; coverage 97.3%. Every
layer above the socket (STDHTTPD, VWEBR, the D5 conformance suite) binds to the
`REQ`/`RSP` contract byte-for-byte; the `vweb` consumer pins
`v0.10.0:dist/seam-snapshot.json` `seams.STDHTTPMSG`.

**Errors as traffic.** A malformed message is normal traffic, not an exception:
`$$parseReq`/`$$parseRsp` return an HTTP status code (200 ok; 400/413/414/431 on
a bad message) and fill the array. A loud `$ECODE` is reserved for a genuine
internal fault — guarded by a flag-based `$ETRAP` (never `zgoto`) that maps it to
a `500` return (or `""` from the serializers).

## Public API

### `$$parseReq^STDHTTPMSG(buf, REQ, opts)` → status

Parse a complete HTTP/1.1 request buffer into the `REQ` contract.

- `buf` *(string)* — complete request bytes (request line + headers + body).
- `REQ` *(array, by-ref)* — killed, then populated per the request shape below.
- `opts` *(array, by-ref, optional)* — injected size caps
  `maxline` / `maxhdrcount` / `maxhdrbytes` / `maxbody`.
- **returns** *(numeric)* — `200` ok; `400` (malformed / bad request-line / bad
  Content-Length), `413` (body over `maxbody`), `414` (request line over
  `maxline`), `431` (too many / too-large headers).

The request line must be exactly `METHOD SP target SP HTTP/<ver>` with `ver` of
`1.0` or `1.1`. The method is upper-cased; the target is split at `?` into
`rawpath` (kept raw) + percent-decoded `path`, and any query string is parsed
into `REQ("query",...)`. A `Transfer-Encoding: chunked` body is de-chunked;
otherwise the body is taken per `Content-Length`.

```m
new buf,REQ,st
set buf="POST /api/things?x=1 HTTP/1.1"_$char(13,10)
set buf=buf_"Host: example.org"_$char(13,10)
set buf=buf_"Content-Type: application/json"_$char(13,10)
set buf=buf_"Content-Length: 7"_$char(13,10,13,10)_"{""a"":1}"
set st=$$parseReq^STDHTTPMSG(buf,.REQ)
write st,!                                  ; 200
write REQ("method")," ",REQ("path"),!       ; POST /api/things
write REQ("query","x"),!                    ; 1
write $$hdr^STDHTTPMSG(.REQ,"content-type"),!  ; application/json
write REQ("body"),!                         ; {"a":1}
```

**Parsed request shape** (`REQ`):

```
REQ("method")           ; upper-cased verb ("GET", "POST", ...)
REQ("ver")              ; "1.0" or "1.1"
REQ("rawpath")          ; request-target path, raw (not decoded)
REQ("rawquery")         ; raw query string after "?" ("" if none)
REQ("path")             ; percent-decoded path
REQ("query",name)       ; decoded query value, last-wins for the scalar
REQ("query",name,1..N)  ; every occurrence, in arrival order
REQ("hdr",lowerName)    ; header value; name LOWER-cased; dup names join ", "
REQ("body")             ; body bytes (de-chunked if chunked)
REQ("body","len")       ; body length in bytes
REQ("keepalive")        ; 1/0 from version + Connection header
```

### `$$parseRsp^STDHTTPMSG(buf, RSP, opts)` → status

Parse a complete HTTP/1.1 response buffer into the `RSP` contract.

- `buf` *(string)* — complete response bytes (status line + headers + body).
- `RSP` *(array, by-ref)* — killed, then populated per the response shape below.
- `opts` *(array, by-ref, optional)* — size caps (`maxbody` honored here).
- **returns** *(numeric)* — `200` ok; `400` (malformed) or `413` (body over
  `maxbody`).

Response **header names keep their on-the-wire casing** (unlike requests); use
`$$hdr` for case-insensitive lookup. With no `Content-Length` and no chunking,
the whole remaining buffer becomes the body.

```m
new buf,RSP,st
set buf="HTTP/1.1 404 Not Found"_$char(13,10)
set buf=buf_"Content-Type: text/plain"_$char(13,10)
set buf=buf_"Content-Length: 9"_$char(13,10,13,10)_"not found"
set st=$$parseRsp^STDHTTPMSG(buf,.RSP)
write st,!                                  ; 200  (parse succeeded)
write RSP("status")," ",RSP("reason"),!     ; 404 Not Found
write $$hdr^STDHTTPMSG(.RSP,"CONTENT-TYPE"),!  ; text/plain
write RSP("body"),!                         ; not found
```

**Parsed response shape** (`RSP`):

```
RSP("ver")              ; version after "HTTP/" ("1.1")
RSP("status")           ; 3-digit numeric status code
RSP("reason")           ; reason phrase
RSP("hdr",name)         ; header value; name AS-SENT (wire casing); dup join ", "
RSP("body")             ; body bytes (de-chunked if chunked)
RSP("body","len")       ; body length in bytes
RSP("keepalive")        ; 1/0 from version + Connection header
```

### `$$serializeReq^STDHTTPMSG(REQ)` → bytes

Serialize the `REQ` contract into HTTP/1.1 request bytes (request line + headers
+ blank CRLF + body).

- `REQ` *(array, by-ref)* — `method` (default `GET`), `ver` (default `1.1`),
  `rawpath` (default `/`), optional `rawquery`, `hdr`, `body`.
- **returns** *(string)* — full request bytes (`""` on internal fault).

The request-target is `REQ("rawpath")` (plus `"?"_REQ("rawquery")` when set)
verbatim — the caller owns query encoding. `Content-Length` is added (lower-case)
only when a body is present.

```m
new REQ
set REQ("method")="GET",REQ("rawpath")="/health"
set REQ("hdr","host")="example.org"
write $$serializeReq^STDHTTPMSG(.REQ)
; GET /health HTTP/1.1
; host: example.org
; (blank line)
```

### `$$serializeRsp^STDHTTPMSG(RSP)` → bytes

Serialize the `RSP` contract into HTTP/1.1 response bytes (status line + headers
+ blank CRLF + body).

- `RSP` *(array, by-ref)* — `status` (default `200`), `ver` (default `1.1`),
  `reason` (auto-filled from `status` when blank), `hdr`, `body`, and an optional
  `json` subtree.
- **returns** *(string)* — full response bytes (`""` on internal fault).

When `RSP("json")` is present, the body is `$$encode^STDJSON` of that subtree and
`Content-Type: application/json` is injected if the caller hasn't set one.
`Date` (`$$httpdate^STDDATE`), `Server` (`m-stdlib`), and `Connection`
(`keep-alive`/`close` from `RSP("keepalive")`, default keep-alive) are injected
only when absent; caller header casing is kept. `Content-Length` is **always**
emitted (no server-side chunking in v0.1).

```m
new RSP
set RSP("status")=200
set RSP("json","ok")=1,RSP("json","name")="vista"
write $$serializeRsp^STDHTTPMSG(.RSP)
; HTTP/1.1 200 OK, with Date/Server/Connection/Content-Type/Content-Length
; and the JSON-encoded body {"ok":1,"name":"vista"}
```

### `$$hdr^STDHTTPMSG(MSG, name)` → value

Case-insensitive header lookup over `MSG("hdr",...)` — the canonical way to read
a header from either a `REQ` (lower-cased keys) or an `RSP` (wire-cased keys).

- `MSG` *(array, by-ref)* — a parsed `REQ` or `RSP` carrying an `"hdr"` subtree.
- `name` *(string)* — header name, any casing.
- **returns** *(string)* — the header value, or `""` if absent.

```m
set ct=$$hdr^STDHTTPMSG(.RSP,"Content-Type")  ; matches "content-type" too
```

## Notes & gotchas

- **Size caps are injected, never XPAR-aware.** Safe defaults: `maxline` 8192,
  `maxhdrcount` 100, `maxhdrbytes` 16384, `maxbody` 1048576. The VWEB layer
  sources real limits from XPAR and passes them down via `opts`.
- **Header casing differs by direction.** Request header keys are lower-cased on
  store; response header keys keep their on-the-wire casing. Always read through
  `$$hdr` so either works.
- **Duplicate headers** with the same name are joined with `", "` (per RFC 7230
  §3.2.2) on both parse paths.
- **Body bytes are opaque.** No transcoding — bodies are M strings of bytes; run
  the engine in byte (M) mode (`ydb_chset=M`) like the rest of m-stdlib.
- **STDJSON by-ref gotcha (serialize).** Pass the JSON payload as a top-level
  local before encoding — `$$serializeRsp` does `merge jnode=RSP("json")` first,
  because handing a *subscripted* node by reference into `$$encode^STDJSON` loses
  the subtree on IRIS.
