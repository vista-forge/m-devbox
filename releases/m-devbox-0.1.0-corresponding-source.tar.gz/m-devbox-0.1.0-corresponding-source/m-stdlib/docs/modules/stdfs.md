---
module: STDFS
tag: v0.3.0
phase: P4 wave
stable: stable
since: v0.3.0
synopsis: 'File-system primitives (text I/O, path manipulation, bytes)'
labels: ['append', 'appendBytes', 'available', 'basename', 'dirname', 'exists', 'join', 'openAppend', 'openRead', 'openWrite', 'readBytes', 'readFile', 'readLines', 'remove', 'size', 'writeBytes', 'writeFile', 'writeLines']
errors: ['U-STDFS-NOT-WIRED', 'U-STDFS-OPEN-FAIL', 'U-STDFS-READ-TRUNCATED', 'U-STDFS-REMOVE-FAIL']
conformance: []
see_also: ['STDENV', 'STDSNAP']
---

# `STDFS` — File-system primitives

Read / write / append / exists / remove / size on regular text
files, plus three pure-string path manipulators (`basename`,
`dirname`, `join`). Centralises the YDB-style `OPEN`/`USE`/`READ`/
`WRITE`/`CLOSE` device dance so consumer modules don't have to
re-derive the deviceparam combinations or work around the
[`M-MOD-024`](../discoveries.md) lint false-positive.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `append` | `do append^STDFS(path, data)` | Append data to path; create the file if missing. |
| `appendBytes` | `do appendBytes^STDFS(path, data)` | Append data to path via O_APPEND — atomic at EOF, byte-faithful. |
| `available` | `$$available^STDFS()` | 1 iff the stdfs callout is loaded and open(2) is reachable. |
| `basename` | `$$basename^STDFS(path)` | Return the last component of path. |
| `dirname` | `$$dirname^STDFS(path)` | Return the parent path (everything but the last component). |
| `exists` | `$$exists^STDFS(path)` | Return 1 iff path exists; else 0. |
| `join` | `$$join^STDFS(left, right)` | POSIX path join: absolute right replaces left. |
| `openAppend` | `$$openAppend^STDFS(path, timeout)` | Open path for append (create if missing); return $TEST. |
| `openRead` | `$$openRead^STDFS(path, timeout)` | Open path read-only on the current engine; return $TEST. |
| `openWrite` | `$$openWrite^STDFS(path, timeout)` | Open path write-new (create/truncate); return $TEST. |
| `readBytes` | `$$readBytes^STDFS(path)` | Return file content as a byte string — no CR/LF normalisation. |
| `readFile` | `$$readFile^STDFS(path)` | Return file content as a string (lines joined by $C(10)). |
| `readLines` | `do readLines^STDFS(path, lines)` | Read path into lines(1..N) (1-indexed; CRLF normalised). |
| `remove` | `do remove^STDFS(path)` | Delete path; idempotent (no-op if already absent). |
| `size` | `$$size^STDFS(path)` | Return size of path in bytes; -1 if missing or unreadable. |
| `writeBytes` | `do writeBytes^STDFS(path, data)` | Write data to path verbatim — no trailing LF, no transcoding. |
| `writeFile` | `do writeFile^STDFS(path, data)` | Write data to path (overwrite if exists). |
| `writeLines` | `do writeLines^STDFS(path, lines)` | Write lines(1..N) to path, separated and terminated by LF. |

### `do append^STDFS(path, data)`

Append data to path; create the file if missing.

**Parameters**

- `path` _(path)_ — filesystem path; created if absent
- `data` _(string)_ — text content

**Raises**

- `U-STDFS-OPEN-FAIL` — could not open for read or write

**Example**

```m
new p set p="/tmp/stdfs_ap_"_$job do writeFile^STDFS(p,"a") do append^STDFS(p,$char(10)_"b") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"a"_$char(10)_"b","append adds a second line") do remove^STDFS(p)
```

### `do appendBytes^STDFS(path, data)`

Append data to path via O_APPEND — atomic at EOF, byte-faithful.

**Parameters**

- `path` _(path)_ — filesystem path; created if absent
- `data` _(byte-string)_ — one M character per byte

**Raises**

- `U-STDFS-NOT-WIRED` — stdfs.so is unavailable
- `U-STDFS-OPEN-FAIL` — open(2) failed

**Example**

```m
do raises^STDASSERT(.pass,.fail,"do appendBytes^STDFS(""/tmp/blob.bin"",""x"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, appendBytes raises NOT-WIRED")
```

### `$$available^STDFS()`

1 iff the stdfs callout is loaded and open(2) is reachable.

**Returns** _bool_ — 1 iff stdfs.so is loaded; 0 otherwise

**Example**

```m
do true^STDASSERT(.pass,.fail,($$available^STDFS()=0)!($$available^STDFS()=1),"available returns a 0/1 flag")
```

### `$$basename^STDFS(path)`

Return the last component of path.

**Parameters**

- `path` _(path)_ — POSIX path

**Returns** _string_ — last path component; "/" for root; "" for empty input

**Example**

```m
write $$basename^STDFS("/etc/hosts")  ; "hosts"
```

### `$$dirname^STDFS(path)`

Return the parent path (everything but the last component).

**Parameters**

- `path` _(path)_ — POSIX path

**Returns** _path_ — parent path; "." for no-slash input; "/" for root

**Example**

```m
write $$dirname^STDFS("/etc/hosts")  ; "/etc"
```

### `$$exists^STDFS(path)`

Return 1 iff path exists; else 0.

**Parameters**

- `path` _(path)_ — filesystem path

**Returns** _bool_ — 1 iff openable; 0 otherwise

**Example**

```m
new p set p="/tmp/stdfs_ex_"_$job do writeFile^STDFS(p,"x") do eq^STDASSERT(.pass,.fail,$$exists^STDFS(p),1,"exists is 1 after write") do remove^STDFS(p)
write $$exists^STDFS("/no/such/stdfs/path")  ; 0
```

### `$$join^STDFS(left, right)`

POSIX path join: absolute right replaces left.

**Parameters**

- `left` _(path)_ — left operand
- `right` _(path)_ — right operand (absolute right wins)

**Returns** _path_ — joined path

**Example**

```m
write $$join^STDFS("/a","b")     ; "/a/b"
```

### `$$openAppend^STDFS(path, timeout)`

Open path for append (create if missing); return $TEST.

**Parameters**

- `path` _(path)_ — filesystem path; created if absent
- `timeout` _(int)_ — OPEN timeout in seconds (default 5)

**Returns** _bool_ — 1 iff the device opened; 0 otherwise

**Example**

```m
new p set p="/tmp/stdfs_oa_"_$job do eq^STDASSERT(.pass,.fail,$$openAppend^STDFS(p,5),1,"opened a file for append") close p do remove^STDFS(p)
```

### `$$openRead^STDFS(path, timeout)`

Open path read-only on the current engine; return $TEST.

**Parameters**

- `path` _(path)_ — filesystem path to open for reading
- `timeout` _(int)_ — OPEN timeout in seconds (default 5; 0 = poll)

**Returns** _bool_ — 1 iff the device opened; 0 on timeout/error

**Example**

```m
write $$openRead^STDFS("/no/such/stdfs/path",0)  ; 0
```

### `$$openWrite^STDFS(path, timeout)`

Open path write-new (create/truncate); return $TEST.

**Parameters**

- `path` _(path)_ — filesystem path; truncated/created
- `timeout` _(int)_ — OPEN timeout in seconds (default 5)

**Returns** _bool_ — 1 iff the device opened; 0 otherwise

**Example**

```m
new p set p="/tmp/stdfs_ow_"_$job do eq^STDASSERT(.pass,.fail,$$openWrite^STDFS(p,5),1,"opened a new file for write") close p do remove^STDFS(p)
```

### `$$readBytes^STDFS(path)`

Return file content as a byte string — no CR/LF normalisation.

**Parameters**

- `path` _(path)_ — filesystem path

**Returns** _byte-string_ — file contents byte-for-byte

**Raises**

- `U-STDFS-NOT-WIRED` — stdfs.so is unavailable
- `U-STDFS-OPEN-FAIL` — open(2) failed
- `U-STDFS-READ-TRUNCATED` — file exceeds the 1 MiB buffer cap (YDB max string length)

**Example**

```m
do raises^STDASSERT(.pass,.fail,"set x=$$readBytes^STDFS(""/tmp/blob.bin"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, readBytes raises NOT-WIRED")
```

### `$$readFile^STDFS(path)`

Return file content as a string (lines joined by $C(10)).

**Parameters**

- `path` _(path)_ — filesystem path

**Returns** _string_ — file content; lines LF-separated, trailing LF dropped

**Raises**

- `U-STDFS-OPEN-FAIL` — path is missing or unreadable

**Example**

```m
new p set p="/tmp/stdfs_rf_"_$job do writeFile^STDFS(p,"alpha") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"alpha","readFile round-trips writeFile") do remove^STDFS(p)
do raises^STDASSERT(.pass,.fail,"set x=$$readFile^STDFS(""/no/such/stdfs/path"")","U-STDFS-OPEN-FAIL","missing path raises OPEN-FAIL")
```

### `do readLines^STDFS(path, lines)`

Read path into lines(1..N) (1-indexed; CRLF normalised).

**Parameters**

- `path` _(path)_ — filesystem path
- `lines` _(array)_ — by-ref local; killed then populated as lines(1..N)

**Raises**

- `U-STDFS-OPEN-FAIL` — path is missing or unreadable

**Example**

```m
new p,lines set p="/tmp/stdfs_rl_"_$job do writeFile^STDFS(p,"a"_$char(10)_"b") do readLines^STDFS(p,.lines) do eq^STDASSERT(.pass,.fail,lines(2),"b","second line lands at lines(2)") do remove^STDFS(p)
do raises^STDASSERT(.pass,.fail,"do readLines^STDFS(""/no/such/stdfs/path"",.a)","U-STDFS-OPEN-FAIL","missing path raises OPEN-FAIL")
```

### `do remove^STDFS(path)`

Delete path; idempotent (no-op if already absent).

**Parameters**

- `path` _(path)_ — filesystem path

**Raises**

- `U-STDFS-REMOVE-FAIL` — open-with-DELETE failed (not the missing-file case)

**Example**

```m
new p set p="/tmp/stdfs_rm_"_$job do writeFile^STDFS(p,"x") do remove^STDFS(p) do eq^STDASSERT(.pass,.fail,$$exists^STDFS(p),0,"remove deletes the file")
```

### `$$size^STDFS(path)`

Return size of path in bytes; -1 if missing or unreadable.

**Parameters**

- `path` _(path)_ — filesystem path

**Returns** _int_ — byte count; -1 if missing or unreadable

**Example**

```m
new p set p="/tmp/stdfs_sz_"_$job do writeFile^STDFS(p,"hi") do eq^STDASSERT(.pass,.fail,$$size^STDFS(p),3,"size counts the trailing LF") do remove^STDFS(p)
write $$size^STDFS("/no/such/stdfs/path")  ; -1
```

### `do writeBytes^STDFS(path, data)`

Write data to path verbatim — no trailing LF, no transcoding.

**Parameters**

- `path` _(path)_ — filesystem path; truncated if exists
- `data` _(byte-string)_ — one M character per byte (0..255)

**Raises**

- `U-STDFS-NOT-WIRED` — stdfs.so is unavailable
- `U-STDFS-OPEN-FAIL` — open(2) failed

**Example**

```m
do raises^STDASSERT(.pass,.fail,"do writeBytes^STDFS(""/tmp/blob.bin"",""x"")","U-STDFS-NOT-WIRED","with no stdfs.so loaded, writeBytes raises NOT-WIRED")
```

### `do writeFile^STDFS(path, data)`

Write data to path (overwrite if exists).

**Parameters**

- `path` _(path)_ — filesystem path; truncated if exists
- `data` _(string)_ — text content (lines may be LF-separated)

**Raises**

- `U-STDFS-OPEN-FAIL` — could not open `path` for write

**Example**

```m
new p set p="/tmp/stdfs_wf_"_$job do writeFile^STDFS(p,"hi") do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"hi","writeFile then readFile") do remove^STDFS(p)
```

### `do writeLines^STDFS(path, lines)`

Write lines(1..N) to path, separated and terminated by LF.

**Parameters**

- `path` _(path)_ — filesystem path; truncated if exists
- `lines` _(array)_ — by-ref local subscripted as lines(1..N)

**Raises**

- `U-STDFS-OPEN-FAIL` — could not open `path` for write

**Example**

```m
new p,lines set p="/tmp/stdfs_wl_"_$job,lines(1)="a",lines(2)="b" do writeLines^STDFS(p,.lines) do eq^STDASSERT(.pass,.fail,$$readFile^STDFS(p),"a"_$char(10)_"b","writeLines emits LF-separated lines") do remove^STDFS(p)
```

<!-- END GENERATED API REFERENCE -->

## Public API

### Text I/O + path manipulation (pure-M, YDB SEQ device)

| Extrinsic | Signature | Returns |
|---|---|---|
| `readFile` | `$$readFile^STDFS(path)` | File content as a string (lines joined by `$C(10)`). |
| `writeFile` | `do writeFile^STDFS(path, data)` | Writes `data` to `path`, overwriting any existing file. |
| `append` | `do append^STDFS(path, data)` | Appends `data` to `path`; creates the file if missing. |
| `readLines` | `do readLines^STDFS(path, .lines)` | Populates `lines(1..N)` from file (one line per index). |
| `writeLines` | `do writeLines^STDFS(path, .lines)` | Writes `lines(1..N)` to `path`, LF-separated. |
| `exists` | `$$exists^STDFS(path)` | `1` iff path exists; else `0`. |
| `remove` | `do remove^STDFS(path)` | Deletes `path`; idempotent (no-op if absent). |
| `size` | `$$size^STDFS(path)` | Size in bytes; `-1` if missing. |
| `basename` | `$$basename^STDFS(path)` | Last path component. |
| `dirname` | `$$dirname^STDFS(path)` | Parent path. |
| `join` | `$$join^STDFS(left, right)` | POSIX path join (absolute right wins). |

### Byte-faithful I/O (`$&stdfs` → libc `read(2)` / `write(2)`)

| Extrinsic | Signature | Returns |
|---|---|---|
| `readBytes` | `$$readBytes^STDFS(path)` | File content as a byte string — no LF stripping, no CRLF normalisation. |
| `writeBytes` | `do writeBytes^STDFS(path, data)` | Writes `data` verbatim — **no trailing LF added**. |
| `appendBytes` | `do appendBytes^STDFS(path, data)` | Atomic append via `O_APPEND`; creates the file if missing. |
| `available` | `$$available^STDFS()` | `1` iff `stdfs.so` is loaded and reachable; else `0`. |

## Examples

```m
; round-trip a string
DO writeFile^STDFS("/tmp/note.txt","hello, world")
SET body=$$readFile^STDFS("/tmp/note.txt")  ; "hello, world"

; build then read an array
SET lines(1)="alpha",lines(2)="beta",lines(3)="gamma"
DO writeLines^STDFS("/tmp/list.txt",.lines)
KILL lines  DO readLines^STDFS("/tmp/list.txt",.lines)

; existence guard
IF '$$exists^STDFS(path) DO writeFile^STDFS(path,"<default>")

; path manipulation
WRITE $$basename^STDFS("/etc/hosts"),!     ; "hosts"
WRITE $$dirname^STDFS("/etc/hosts"),!      ; "/etc"
WRITE $$join^STDFS("/var","log"),!         ; "/var/log"
WRITE $$join^STDFS("/var","/abs"),!        ; "/abs"  (absolute right wins)
```

## Trailing-LF semantics

`writeFile` always ends the on-disk file with `LF`, regardless of
whether `data` does. This matches the POSIX text-file convention
(`echo "x" > file` produces `"x\n"`, two bytes) and the YDB SEQ
device's stream-mode close finalisation. Practical consequences:

- `$$readFile^STDFS(path)` strips the **single** trailing LF when
  reconstructing the string, so a string `"hello"` round-trips
  back to `"hello"` — even though the on-disk file is six bytes.
- `$$size^STDFS(path)` reports the **on-disk byte count**, which
  is `$LENGTH(data) + 1` if `data` did not already end in LF, and
  `$LENGTH(data)` otherwise. Use this for "what does `ls -l`
  show", not for "how many bytes did I pass to writeFile".
- For binary payloads (no implicit LF, exact byte round-trip),
  use `$$readBytes^STDFS` / `do writeBytes^STDFS` — these go
  through the libc `read(2)` / `write(2)` callout instead of the
  YDB SEQ device.

## Byte-faithful I/O (T13 + T14)

`$$readBytes^STDFS(path)` and `do writeBytes^STDFS(path, data)`
preserve every byte exactly. Unlike `readFile` / `writeFile`,
they do not strip CR, do not collapse line endings, and do not
add a trailing LF. The on-disk byte count after `writeBytes` is
exactly `$LENGTH(data)`. This makes them the right tool for:

- gzipped / zstd-compressed payloads
- signed binary blobs (where any added byte invalidates the signature)
- captured HTTP response bodies that need bit-exact replay
- snapshot fixtures that include CR / NUL / high-bit bytes

Backend: `$&stdfs → libc open(2) / read(2) / write(2) / close(2)`,
sourced from `src/callouts/stdfs.c` and described by
`tools/std_fs.xc`. Built by `tools/build-callouts.sh`. When the
`.so` is missing, the byte-faithful entries set
`$ECODE=,U-STDFS-NOT-WIRED,` — the text-I/O entries continue to
work because they use the YDB SEQ device.

The 1 MiB per-call output cap (YDB max string length) is declared in the `.xc`
descriptor. If a `readBytes` call would exceed it, `$ECODE` is
set to `,U-STDFS-READ-TRUNCATED,` (no silent truncation —
truncation would corrupt downstream consumers expecting
byte-faithful round-trip semantics). For larger files a
streaming `open` / `write` / `close` triplet is the natural
follow-on; not yet scheduled.

## Append semantics

`$$append^STDFS(path, data)` is a **text-mode** operation: it reads the
existing file via `readFile` (LF-stripped reconstruction), concatenates
`data`, and writes the result back via `writeFile` (which always emits
exactly one trailing LF on disk). Cost is `O(file size)` per call.

This implementation is deliberate, not a workaround for the missing
callout. The native `O_APPEND` path would leave an interior LF in the
file whenever the previous content already ended with one — readFile
would then round-trip to `"head\n-tail"` instead of the documented
`"head-tail"`. Keeping append() at read-then-rewrite preserves the
contract that `readFile` after `append` equals `readFile(old) + data`.

For byte-faithful append at EOF (no LF normalisation, single `write(2)`
syscall, atomic under concurrent writers), use `do appendBytes^STDFS`
directly. That entry lands data verbatim and is the right tool for
binary log streams, append-only data files, and structured payloads
where each chunk already carries its own framing.

## `exists` and the YDB `$ZSEARCH` cache

`$ZSEARCH` is the obvious primitive for existence checks, but it
caches the directory enumeration per-process — a path created and
then deleted within one M process can still appear "present" via
`$ZSEARCH` until the next OPEN. STDFS bypasses this by **probing
via OPEN with `timeout=0`**: `$$exists^STDFS(path)` delegates to
`$$openRead^STDFS(path,0)` and reports success. `openRead` carries
the engine branch and the trap: on YDB an `$ETRAP` catches the hard
error that fires on a missing file and unwinds via
`ZGOTO $zlevel:openReadRet^STDFS` (the arg-less-`quit`-avoidance
pattern also used by `raises^STDASSERT`); on IRIS it uses the
native OPEN-timeout `$TEST`. The result is an existence check that
reflects the actual filesystem, not the process-local search cache,
and `exists` itself carries no trap — it is a thin wrapper over the
portable `openRead` probe.

## Path manipulation semantics

`basename` and `dirname` follow GNU coreutils conventions:

| Input | `basename` | `dirname` |
|---|---|---|
| `/etc/hosts` | `hosts` | `/etc` |
| `/foo/bar/` | `bar` | `/foo` |
| `plain` | `plain` | `.` |
| `/` | `/` | `/` |
| `""` | `""` | `.` |

`join`:

- Empty operand drops out: `join("","b") = "b"`, `join("/a","") = "/a"`.
- Absolute right wins: `join("/a","/b") = "/b"` (matches Python `os.path.join`).
- Trailing slash on the left is collapsed: `join("/a/","b") = "/a/b"`.

## Edge cases

- **Empty file round-trip.** `writeFile(path,"")` creates a zero-byte
  file; `readFile(path)` returns `""`. Confirmed by
  `tests/STDFSTST.m:tWriteThenReadEmpty`.
- **CRLF normalisation on read.** `readFile` and `readLines` strip
  a trailing CR from each line, so a file produced on Windows
  reads back identically to the same file produced on Linux.
- **`remove()` idempotency.** Removing a missing path is a no-op
  (no `$ECODE` set). This matches `unlink`-with-`ENOENT-suppression`
  semantics — useful inside teardown blocks.
- **`size()` of missing path returns `-1`,** not `0`. A
  zero-byte-existing file returns `0`.

## Error codes

| `$ECODE` | Raised by | Meaning |
|---|---|---|
| `,U-STDFS-OPEN-FAIL,` | `readFile`, `readLines`, `writeFile`, `writeLines`, `append`, `readBytes`, `writeBytes`, `appendBytes` | Path missing or unopenable. Text-I/O surfaces YDB's OPEN failure; byte-I/O surfaces libc `open(2)` failure (full errno text in `stdfs_lasterror`). |
| `,U-STDFS-REMOVE-FAIL,` | `remove` | OPEN-with-DELETE failed for a reason other than "file already absent" (typically a permission or busy-fd issue). |
| `,U-STDFS-NOT-WIRED,` | `readBytes`, `writeBytes`, `appendBytes` | `stdfs.so` not loaded (`ydb_xc_stdfs` unset, descriptor missing, or `dlopen` failed). The text-I/O entries are unaffected. |
| `,U-STDFS-READ-TRUNCATED,` | `readBytes` | File exceeds the 1 MiB per-call buffer cap declared in `tools/std_fs.xc` (YDB max string length — a larger preallocation is rejected at call-table load). No silent truncation. |

## Deployment

The byte-faithful API depends on `stdfs.so`. To deploy:

```bash
tools/build-callouts.sh                     # produces so/<plat>/stdfs.so
export STDLIB_LIB=$(pwd)/so/linux-x86_64    # or whichever platform
export ydb_xc_stdfs=$(pwd)/tools/std_fs.xc
```

Verify with `$$available^STDFS()` from any M shell — `1` means
the descriptor is exported and `open(2)` works on `/dev/null`.

When the `.so` is absent the rest of STDFS still works, and
`append()` automatically falls back to read-then-rewrite — see
the "Append semantics" section.

## Engine portability

YDB on Linux is the supported configuration. The path-manipulation
labels (`basename` / `dirname` / `join`) are pure-M and run
unchanged on IRIS today. The text-I/O labels rely on YDB's
`OPEN`/`USE`/`READ #n`/`CLOSE` semantics and the `$ZEOF` /
`$ZLEVEL` extensions; the byte-I/O labels rely on the
external-call (`$&`) ABI which YDB exposes via `ydb_xc_*`. The IRIS arm of the byte-I/O
path lands once a real consumer drives it; the public M API will
not change.

## See also

- [`STDCSV`](stdcsv.md) — same OPEN/USE/CLOSE pattern, pre-dates
  STDFS by ~6 weeks; once STDFS stabilises, STDCSV's `parseFile`
  / `writeFile` will rebase onto STDFS for the device dance.
- [`STDCSPRNG`](stdcsprng.md) — same byte-faithful OPEN/USE/READ
  pattern for `/dev/urandom`.
- [`STDASSERT`](stdassert.md) — every test in `STDFSTST` is one
  STDASSERT call; the `$ETRAP+ZGOTO` pattern in `openRead()` (which
  `exists()` delegates to) is the same one `raises^STDASSERT` uses.

## History

Original ship was text-mode YDB-only:
read/write/append/exists/remove/size + basename/dirname/join.
`exists()` delegates to `openRead()`, whose `$ETRAP+ZGOTO $zlevel`
OPEN-probe bypasses `$ZSEARCH`'s per-process cache (same pattern as
`raises^STDASSERT`);
`writeFile` always emits trailing LF (POSIX text-file convention);
`append()` is read-then-rewrite to sidestep a YDB SEQ APPEND-mode
position quirk.

T13 + T14 closed 2026-05-08 by the `src/callouts/stdfs.c` libc shim
(`stdfs_writeBytes` / `stdfs_appendBytes` / `stdfs_readBytes` /
`stdfs_available` / `stdfs_lasterror`) + `tools/std_fs.xc`. M side
adds byte-faithful extrinsics: `do writeBytes^STDFS` (no trailing LF),
`do appendBytes^STDFS` (atomic at EOF via `O_APPEND`),
`$$readBytes^STDFS` (preserves every byte; surfaces
`,U-STDFS-READ-TRUNCATED,` on 1 MiB cap overflow), and
`$$available^STDFS()`.

The text-mode `append^STDFS` keeps its read-then-rewrite implementation
by design — rerouting through `O_APPEND` would leave an interior LF
whenever the previous content ended with one, breaking the
`readFile(append(x,y)) == readFile(x) + y` round-trip contract.
Callers that want byte-faithful append at EOF use `appendBytes`
directly; callers that want text-mode "concat + trailing LF" semantics
keep using `append`. STDFSTST 50/50 green on engine.

G-FS-YDB fix (2026-07-22, found by the m-devbox callout build path):
the T13/T14 Bytes API above never actually resolved on YottaDB — the
dispatch used `$ZF(...)` (not YDB syntax; `%YDB-E-COMMA` at XECUTE
compile, silently trapped to `,U-STDFS-NOT-WIRED,`), the `.xc` labels
carried underscores (uncallable: in M `_` is concatenation — the same
class STDHTTP fixed as G-HTTP-YDB on 2026-06-20), and the env guard
read `ydb_xc_std_fs`, a name the engine never consults. Fixed:
underscore-free labels (`available:` / `writeBytes:` / `appendBytes:`
/ `readBytes:` / `lastError:`), `$&stdfs.<label>` dispatch, guard
`ydb_xc_stdfs`. Proven by known-answer on a wired engine through the
driver seam (`$$available^STDFS()` 0→1, byte round-trip green);
regression pinned by `tWiredEnvImpliesAvailable` in STDFSTST.
