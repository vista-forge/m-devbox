---
module: STDS3
tag: v0.14.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.14.0
synopsis: 'AWS S3 REST client (PutObject / GetObject / List / multipart)'
labels: ['abortMultipart', 'buildRequest', 'canonUri', 'completeMultipart', 'createMultipart', 'deleteObject', 'getObject', 'headObject', 'host', 'listObjectsV2', 'parseError', 'parseList', 'putObject', 'uploadPart', 'url']
errors: []
conformance: []
see_also: ['STDHTTP', 'STDSIGV4']
---

# `STDS3` — AWS S3 REST client (PutObject / GetObject / List / multipart)

A thin, portable reimplementation of the S3 REST slice an SDK (boto3) would
otherwise generate: **build the request, sign it with `STDSIGV4`, hand the
bytes to `STDHTTP`.** Every entry point takes an explicit credential context
`ctx` by reference — no ambient config — and returns an integer HTTP status
(`0` on transport failure, mirroring `STDHTTP`). This is the engine-neutral
S3-egress half of the RPC+HL7→S3 VistA traffic-tap stack (the SigV4 half is
[`STDSIGV4`](stdsigv4.md)).

**Addressing.** Virtual-hosted-style
(`<bucket>.s3.<region>.amazonaws.com`) by default; an `opt("endpoint")`
override switches to **path-style** (`<endpoint>/<bucket>/<key>`), which is
what MinIO / LocalStack and any S3-compatible store want — the no-code-change
hook the testbed rides on. The endpoint override reaches request assembly on
**all** ops, not just `putObject`, so round-trips (not just PUT) work against a
local sink.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `abortMultipart` | `$$abortMultipart^STDS3(ctx, bucket, key, uploadId, opt)` | Abort a multipart upload; returns HTTP status (204 on success). |
| `buildRequest` | `do buildRequest^STDS3(ctx, method, bucket, key, query, body, opt, req, resp)` | Assemble a signed STDHTTP request array for an S3 operation. |
| `canonUri` | `$$canonUri^STDS3(ctx, bucket, key, opt)` | The canonical URI for signing (path-style prefixes the bucket). |
| `completeMultipart` | `$$completeMultipart^STDS3(ctx, bucket, key, uploadId, parts, opt)` | Finalize a multipart upload from parts(partNo)=etag. |
| `createMultipart` | `$$createMultipart^STDS3(ctx, bucket, key, opt)` | Initiate a multipart upload; returns the UploadId ("" on error). |
| `deleteObject` | `$$deleteObject^STDS3(ctx, bucket, key, opt)` | DELETE an object; returns HTTP status (204 on success). |
| `getObject` | `$$getObject^STDS3(ctx, bucket, key, opt, resp)` | GET an object; resp("body") holds the bytes on 200. |
| `headObject` | `$$headObject^STDS3(ctx, bucket, key, opt, resp)` | HEAD an object; resp("header",*) holds size/etag/metadata. |
| `host` | `$$host^STDS3(ctx, bucket, opt)` | The Host header value: endpoint override host, else virtual-hosted. |
| `listObjectsV2` | `$$listObjectsV2^STDS3(ctx, bucket, prefix, opt, listing)` | List objects (V2); listing(n,"key"/"size"/"etag") + ("truncated"/"next"). |
| `parseError` | `do parseError^STDS3(xml, resp)` | Parse an S3 error body into resp("error","code"/"message"). |
| `parseList` | `$$parseList^STDS3(xml, listing)` | Parse a ListBucketResult into listing(n,…) + pagination; returns the count. |
| `putObject` | `$$putObject^STDS3(ctx, bucket, key, body, opt, resp)` | PUT an object; returns HTTP status (200 on success). |
| `uploadPart` | `$$uploadPart^STDS3(ctx, bucket, key, uploadId, partNo, body, opt, resp)` | Upload one part; resp("header","etag") carries the part ETag. |
| `url` | `$$url^STDS3(ctx, bucket, key, query, opt)` | The full request URL (virtual-hosted, or path-style under an endpoint override). |

### `$$abortMultipart^STDS3(ctx, bucket, key, uploadId, opt)`

Abort a multipart upload; returns HTTP status (204 on success).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `uploadId` _(string)_ — the UploadId
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint

**Returns** _int_ — HTTP status; 0 on transport failure

### `do buildRequest^STDS3(ctx, method, bucket, key, query, body, opt, req, resp)`

Assemble a signed STDHTTP request array for an S3 operation.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `method` _(string)_ — HTTP method
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `query` _(string)_ — canonical query string ("" if none)
- `body` _(byte-string)_ — request body ("" if none)
- `opt` _(array)_ — options (contentType/sse/endpoint/amzdate/timeoutMs/meta/…), by reference
- `req` _(array)_ — OUT — STDHTTP request array, by reference
- `resp` _(array)_ — OUT — cleared for the response, by reference

### `$$canonUri^STDS3(ctx, bucket, key, opt)`

The canonical URI for signing (path-style prefixes the bucket).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `opt` _(array)_ — options (may carry "endpoint"), by reference

**Returns** _string_ — canonical URI (leading "/")

**Example**

```m
new ctx do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"b","dir/k.txt"),"/dir/k.txt","canonUri: virtual-hosted")
new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$canonUri^STDS3(.ctx,"b","k.txt",.opt),"/b/k.txt","canonUri: path-style")
```

### `$$completeMultipart^STDS3(ctx, bucket, key, uploadId, parts, opt)`

Finalize a multipart upload from parts(partNo)=etag.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `uploadId` _(string)_ — the UploadId
- `parts` _(array)_ — parts(partNo)=etag, by reference
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$createMultipart^STDS3(ctx, bucket, key, opt)`

Initiate a multipart upload; returns the UploadId ("" on error).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `opt` _(array)_ — options (contentType/sse/endpoint/…), by reference

**Returns** _string_ — UploadId; "" on error

### `$$deleteObject^STDS3(ctx, bucket, key, opt)`

DELETE an object; returns HTTP status (204 on success).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$getObject^STDS3(ctx, bucket, key, opt, resp)`

GET an object; resp("body") holds the bytes on 200.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
- `resp` _(array)_ — OUT — resp("body")/("header",*), by reference

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$headObject^STDS3(ctx, bucket, key, opt, resp)`

HEAD an object; resp("header",*) holds size/etag/metadata.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
- `resp` _(array)_ — OUT — resp("header",*), by reference

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$host^STDS3(ctx, bucket, opt)`

The Host header value: endpoint override host, else virtual-hosted.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `opt` _(array)_ — options (may carry "endpoint"), by reference

**Returns** _string_ — host[:port]

**Example**

```m
new ctx set ctx("region")="us-east-1" do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"mybucket"),"mybucket.s3.us-east-1.amazonaws.com","host: virtual-hosted")
new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$host^STDS3(.ctx,"mybucket",.opt),"localhost:9000","host: endpoint override")
```

### `$$listObjectsV2^STDS3(ctx, bucket, prefix, opt, listing)`

List objects (V2); listing(n,"key"/"size"/"etag") + ("truncated"/"next").

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `prefix` _(string)_ — key prefix filter ("" for all)
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
- `listing` _(array)_ — OUT — listing(n,…)/("truncated")/("next"), by reference

**Returns** _int_ — HTTP status; 0 on transport failure

### `do parseError^STDS3(xml, resp)`

Parse an S3 error body into resp("error","code"/"message").

**Parameters**

- `xml` _(string)_ — S3 error XML body
- `resp` _(array)_ — OUT — resp("error",*), by reference

**Example**

```m
new resp do parseError^STDS3("<Error><Code>NoSuchKey</Code><Message>The key does not exist</Message></Error>",.resp) do eq^STDASSERT(.pass,.fail,resp("error","code"),"NoSuchKey","parseError: error code")
```

### `$$parseList^STDS3(xml, listing)`

Parse a ListBucketResult into listing(n,…) + pagination; returns the count.

**Parameters**

- `xml` _(string)_ — ListObjectsV2 XML body
- `listing` _(array)_ — OUT — listing(n,"key"/"size"/"etag")/("truncated")/("next")

**Returns** _int_ — number of Contents entries

**Example**

```m
new listing,n set n=$$parseList^STDS3("<ListBucketResult><Contents><Key>a.txt</Key><Size>5</Size><ETag>e1</ETag></Contents><IsTruncated>false</IsTruncated></ListBucketResult>",.listing) do eq^STDASSERT(.pass,.fail,n_"|"_listing(1,"key"),"1|a.txt","parseList: count + first key")
```

### `$$putObject^STDS3(ctx, bucket, key, body, opt, resp)`

PUT an object; returns HTTP status (200 on success).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `body` _(byte-string)_ — object bytes
- `opt` _(array)_ — options (contentType/sse/endpoint/…), by reference
- `resp` _(array)_ — OUT — resp("header",*)/("error",*), by reference

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$uploadPart^STDS3(ctx, bucket, key, uploadId, partNo, body, opt, resp)`

Upload one part; resp("header","etag") carries the part ETag.

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key
- `uploadId` _(string)_ — the UploadId from createMultipart
- `partNo` _(int)_ — part number (1-based)
- `body` _(byte-string)_ — part bytes
- `opt` _(array)_ — options (endpoint/…), by reference — REQUIRED to reach a non-AWS endpoint
- `resp` _(array)_ — OUT — resp("header","etag"), by reference

**Returns** _int_ — HTTP status; 0 on transport failure

### `$$url^STDS3(ctx, bucket, key, query, opt)`

The full request URL (virtual-hosted, or path-style under an endpoint override).

**Parameters**

- `ctx` _(array)_ — credential context, by reference
- `bucket` _(string)_ — bucket name
- `key` _(string)_ — object key ("" for bucket-level ops)
- `query` _(string)_ — canonical query string ("" if none)
- `opt` _(array)_ — options (may carry "endpoint"), by reference

**Returns** _string_ — the request URL

**Example**

```m
new ctx set ctx("region")="us-east-1" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","k.txt"),"https://b.s3.us-east-1.amazonaws.com/k.txt","url: virtual-hosted")
new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","k.txt","",.opt),"http://localhost:9000/b/k.txt","url: path-style endpoint")
new ctx,opt set opt("endpoint")="http://localhost:9000" do eq^STDASSERT(.pass,.fail,$$url^STDS3(.ctx,"b","","list-type=2",.opt),"http://localhost:9000/b/?list-type=2","url: with query")
```

<!-- END GENERATED API REFERENCE -->

## Status

**Shipped in `v0.14.0`.** `@tier optional` — it sits on top of `STDHTTP`
(network) and `STDSIGV4` (signing; itself on `STDCRYPTO`/`STDHEX`), and parses
S3 XML via `STDXML`. **Dual-engine green:** `STDS3TST` is **18/18** on bare
YottaDB (`m-test-engine`) **and** bare IRIS (`m-test-iris`), `--chset m`. The
request-assembly helpers and the response parsers are pure-M and testable
without a network — that is the bulk of the suite.

The **live round-trip integration suite `STDS3MINIOTST`** (a real signed
PUT/GET against a MinIO/S3 sink) is **not** in core `make test` and **not** in
the default optional set. It runs via a dedicated **`make test-s3`** target,
which needs a live MinIO/S3 (`scripts/s3-testbed.sh up`) **and** engine HTTP
egress (a wired `stdhttp`/libcurl callout on YDB, or working IRIS `%Net`). A
live signed `PUT`→MinIO returns `200` on IRIS; the GET read-back is gated on
engine egress availability per engine.

## Public API

All extrinsics return a numeric HTTP status (`0` = transport failure), except
`$$createMultipart`, which returns the `UploadId` string (`""` on error). The
`ctx` array carries the credentials/region used for signing; `opt` carries
per-request options (most importantly `opt("endpoint")` to reach a non-AWS
store); `resp` (or `listing`) is filled by reference with the result.

### The `ctx` credential context

Built once and passed by reference into every op. It is the same context
`STDSIGV4` consumes:

```
ctx("accessKey")     ; AWS access key id
ctx("secretKey")     ; AWS secret access key (raw, signed via the SigV4 key chain)
ctx("region")        ; e.g. "us-east-1" — also forms the virtual-hosted host
ctx("service")       ; "s3"
ctx("sessionToken")  ; optional — emitted as x-amz-security-token when set
```

### `$$putObject` — PUT an object

`$$putObject^STDS3(ctx, bucket, key, body, opt, resp)`

PUTs `body` (a byte-string) as object `key`. Returns the HTTP status (`200` on
success). On a non-2xx, non-zero status the S3 error XML is parsed into
`resp("error","code")` / `resp("error","message")`.

- **`opt`** — `contentType`, `sse`/`sseKmsKeyId`, `storageClass`, `acl`,
  `meta(name)=value` (→ `x-amz-meta-*`), `endpoint`, `timeoutMs`, `amzdate`.
- **`resp`** (OUT) — `resp("header",*)`, `resp("error",*)` on failure.

```m
new ctx,opt,resp,sc
set ctx("accessKey")="AKIA…",ctx("secretKey")="…"
set ctx("region")="us-east-1",ctx("service")="s3"
set opt("endpoint")="http://minio:9000"   ; path-style → S3-compatible store
set opt("contentType")="application/x-ndjson"
set sc=$$putObject^STDS3(.ctx,"tap-bucket","rpc/2026/06/23/batch-001.ndjson","{""x"":1}"_$char(10),.opt,.resp)
write:sc'=200 "PUT failed: ",sc," ",$get(resp("error","code")),!
```

### `$$getObject` — GET an object

`$$getObject^STDS3(ctx, bucket, key, opt, resp)`

GETs object `key`; on `200`, the object bytes land in `resp("body")` and the
response headers in `resp("header",*)`. Non-2xx bodies are parsed into
`resp("error",*)`.

```m
new ctx,opt,resp,sc
; … populate ctx as above …
set opt("endpoint")="http://minio:9000"
set sc=$$getObject^STDS3(.ctx,"tap-bucket","rpc/2026/06/23/batch-001.ndjson",.opt,.resp)
if sc=200 write "got ",$length(resp("body"))," bytes",!
```

### `$$headObject` — HEAD an object

`$$headObject^STDS3(ctx, bucket, key, opt, resp)`

HEAD request — no body. `resp("header",*)` carries size/etag/metadata; returns
the HTTP status (`200` if the object exists, `404` if not). Unlike the other
ops it does **not** parse an error body (a HEAD has none).

### `$$deleteObject` — DELETE an object

`$$deleteObject^STDS3(ctx, bucket, key, opt)`

DELETEs object `key`. Returns the HTTP status (`204` on success). Takes no
`resp` — there is nothing useful to return on success.

### `$$listObjectsV2` — list a bucket (V2)

`$$listObjectsV2^STDS3(ctx, bucket, prefix, opt, listing)`

Issues a `GET ?list-type=2[&prefix=…]` and parses the `ListBucketResult` into
`listing` by reference. Pass `prefix=""` to list everything. Returns the HTTP
status.

`listing` is filled as:

```
listing(n,"key")     ; object key       (n = 1, 2, …, document order)
listing(n,"size")    ; size in bytes
listing(n,"etag")    ; entity tag
listing("truncated") ; IsTruncated ("true"/"false")
listing("next")      ; NextContinuationToken (for the next page)
```

```m
new ctx,opt,listing,sc,i
; … populate ctx …
set opt("endpoint")="http://minio:9000"
set sc=$$listObjectsV2^STDS3(.ctx,"tap-bucket","rpc/2026/06/23/",.opt,.listing)
for i=1:1 quit:'$data(listing(i))  write listing(i,"key")," (",listing(i,"size")," b)",!
```

### Multipart upload

For large objects, S3's multipart flow is: initiate → upload N parts (each ≥ 5
MiB except the last) → complete (or abort). The four ops mirror that lifecycle.

#### `$$createMultipart` — initiate

`$$createMultipart^STDS3(ctx, bucket, key, opt)`

POSTs `?uploads=` and returns the **`UploadId`** string parsed from the
response XML (`""` on any non-200 or parse failure). Honours the same
`contentType`/`sse`/`endpoint` options as `putObject`.

#### `$$uploadPart` — upload one part

`$$uploadPart^STDS3(ctx, bucket, key, uploadId, partNo, body, opt, resp)`

PUTs one part (`?partNumber=<partNo>&uploadId=<uploadId>`). `partNo` is
1-based. The part's ETag comes back in `resp("header","etag")` — collect it,
keyed by part number, for the complete step. Returns the HTTP status.

#### `$$completeMultipart` — finalize

`$$completeMultipart^STDS3(ctx, bucket, key, uploadId, parts, opt)`

Builds the `<CompleteMultipartUpload>` XML body from `parts(partNo)=etag`
(walked in `$order` numeric order), POSTs it with
`contentType="application/xml"`, and returns the HTTP status.

```m
new ctx,opt,resp,uploadId,parts,sc
; … populate ctx; set opt("endpoint") …
set uploadId=$$createMultipart^STDS3(.ctx,"tap-bucket","big.ndjson",.opt)
quit:uploadId=""
set sc=$$uploadPart^STDS3(.ctx,"tap-bucket","big.ndjson",uploadId,1,chunk1,.opt,.resp)
set parts(1)=$get(resp("header","etag"))
set sc=$$uploadPart^STDS3(.ctx,"tap-bucket","big.ndjson",uploadId,2,chunk2,.opt,.resp)
set parts(2)=$get(resp("header","etag"))
set sc=$$completeMultipart^STDS3(.ctx,"tap-bucket","big.ndjson",uploadId,.parts,.opt)
```

#### `$$abortMultipart` — abort

`$$abortMultipart^STDS3(ctx, bucket, key, uploadId, opt)`

DELETEs `?uploadId=<uploadId>` to discard an in-flight upload and free its
parts. Returns the HTTP status (`204` on success).

## Internal helpers

Request assembly and response parsing are split into separately testable
labels (all reachable without a network, which is how the bulk of `STDS3TST`
exercises them):

- **`do buildRequest^STDS3(ctx,method,bucket,key,query,body,opt,.req,.resp)`** —
  the heart of the module. Computes the canonical URI, the `x-amz-date`
  (`opt("amzdate")` pins it for deterministic tests; production uses
  `$$amzDate^STDSIGV4`), the payload hash (`$$emptyHash^STDSIGV4` for an empty
  body, else `$$sha256^STDCRYPTO`), assembles the `x-amz-*` / `content-type` /
  metadata / `x-amz-security-token` headers, calls `$$authHeader^STDSIGV4` for
  the `Authorization`, and emits the `STDHTTP` `req` array. **`Host` is signed
  but stripped from the sent headers** — both libcurl (YDB) and
  `%Net.HttpRequest` (IRIS) derive `Host` from the URL, and IRIS errors if it
  is set by hand.
- **`$$host` / `$$url` / `$$canonUri`** — the addressing trio: endpoint host vs
  virtual-hosted, the full request URL, and the canonical URI for signing
  (path-style prefixes the bucket). Each branches on `opt("endpoint")`.
- **`do parseError^STDS3(xml,.resp)`** — parses an S3 error body into
  `resp("error","code")` / `resp("error","message")` via `STDXML` xpath.
- **`$$parseList^STDS3(xml,.listing)`** — parses a `ListBucketResult` into the
  `listing` array (above) and returns the `Contents` count. Note: it is an
  argumented-`quit` extrinsic, so `listObjectsV2` invokes it with `$$`, never
  `do` (a `do`-context argumented quit raises `%YDB-E-NOTEXTRINSIC`).

## Notes & gotchas

- **`0` means transport failure, not a bucket/key error.** A `0` return is the
  `STDHTTP` soft-fail (callout missing, connection refused, …). A `403`/`404`
  is a real S3 response and (for the object ops that take `resp`) populates
  `resp("error",*)`. Branch on both.
- **`opt("endpoint")` is required to reach any non-AWS store.** Without it the
  request is addressed to `<bucket>.s3.<region>.amazonaws.com`. With it, every
  op switches to path-style and targets your endpoint — the one knob that
  redirects the whole client at MinIO/LocalStack.
- **Bodies are byte-strings.** Run the engine in byte mode (`ydb_chset=M`, the
  m-stdlib default); the payload SHA-256 and signing assume one M character ==
  one byte. UTF-8 content must already be encoded to bytes by the caller.
- **`opt("amzdate")` is a test seam.** Leave it unset in production so SigV4
  uses the live clock; pin it only to make a signature reproducible.
- **HEAD/DELETE carry no error body.** `$$headObject` and `$$deleteObject`
  don't call `parseError` — inspect the status code directly.
- **Multipart ETags must round-trip exactly.** Store each part's
  `resp("header","etag")` verbatim (quotes included) under its part number;
  `$$completeMultipart` emits them as-is into the XML.

## See also

- [`STDSIGV4`](stdsigv4.md) — the AWS Signature V4 signer this module signs
  every request with (`$$authHeader`, `$$encPath`/`$$encQuery`, `$$amzDate`,
  `$$emptyHash`).
- [`STDHTTP`](stdhttp.md) — the HTTP/1.1 client that carries every request;
  `STDS3` builds its `req`/`resp` arrays and reads back the status the same way.
- `STDXML` — parses the S3 error and `ListBucketResult` XML bodies.
- `STDCRYPTO` / `STDHEX` — the SHA-256 payload hash and hex encoding under SigV4.
