---
module: STDASSERT
tag: v0.0.1
phase: Phase 1
stable: stable
since: v0.0.1
synopsis: 'assertion library (v0.0.1)'
labels: ['contains', 'eq', 'false', 'len', 'ne', 'near', 'raises', 'report', 'start', 'true']
errors: []
conformance: []
see_also: ['STDSNAP']
---

# `STDASSERT` — assertion library

The cornerstone of every test suite in m-stdlib (and the recommended
assertion vocabulary for any M project that wants a richer API than
m-tools `^TESTRUN`).

Output mirrors `^TESTRUN`'s line protocol byte-for-byte so m-cli's
`m test` runner accepts STDASSERT-driven suites unchanged. See [§7.6
of the implementation plan](../archive/m-stdlib-implementation-plan.md#7-phase-0--bootstrap-done-2026-04-30)
for the bootstrap rationale.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `contains` | `do contains^STDASSERT(p, f, haystack, needle, desc)` | Assert haystack contains needle (M's "[" operator). |
| `eq` | `do eq^STDASSERT(p, f, actual, expected, desc)` | Assert actual=expected (string equality). |
| `false` | `do false^STDASSERT(p, f, cond, desc)` | Assert cond is falsy (zero numeric prefix or empty). |
| `len` | `do len^STDASSERT(p, f, actual, n, desc)` | Assert actual=n (length comparison helper). |
| `ne` | `do ne^STDASSERT(p, f, actual, expected, desc)` | Assert actual'=expected (string inequality). |
| `near` | `do near^STDASSERT(p, f, a, b, eps, desc)` | Assert \|a-b\|<=eps (float comparison). |
| `raises` | `do raises^STDASSERT(p, f, code, errno, desc)` | Assert XECUTEing 'code' sets $ECODE containing 'errno'. |
| `report` | `do report^STDASSERT(p, f)` | Print summary; halt with error if any failures. |
| `start` | `do start^STDASSERT(p, f)` | Initialise pass/fail counters (call by-reference). |
| `true` | `do true^STDASSERT(p, f, cond, desc)` | Assert cond is truthy (non-zero numeric prefix). |

### `do contains^STDASSERT(p, f, haystack, needle, desc)`

Assert haystack contains needle (M's "[" operator).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `haystack` _(string)_ — string to search
- `needle` _(string)_ — substring to find (empty always matches)
- `desc` _(string)_ — description

**Example**

```m
set output="STATUS: OK" do contains^STDASSERT(.pass,.fail,output,"OK","status line")
```

### `do eq^STDASSERT(p, f, actual, expected, desc)`

Assert actual=expected (string equality).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `actual` _(string)_ — observed value
- `expected` _(string)_ — expected value
- `desc` _(string)_ — human-readable assertion description

**Example**

```m
set result="hello" do eq^STDASSERT(.pass,.fail,result,"hello","greet test")
```

### `do false^STDASSERT(p, f, cond, desc)`

Assert cond is falsy (zero numeric prefix or empty).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `cond` _(string)_ — condition (M falsiness)
- `desc` _(string)_ — description

**Example**

```m
new x do false^STDASSERT(.pass,.fail,$data(x),"$data of an unset var is 0")
```

### `do len^STDASSERT(p, f, actual, n, desc)`

Assert actual=n (length comparison helper).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `actual` _(int)_ — observed length
- `n` _(int)_ — expected length
- `desc` _(string)_ — description

**Example**

```m
set s="abcde" do len^STDASSERT(.pass,.fail,$length(s),5,"5-char string")
```

### `do ne^STDASSERT(p, f, actual, expected, desc)`

Assert actual'=expected (string inequality).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `actual` _(string)_ — observed value
- `expected` _(string)_ — value `actual` must NOT equal
- `desc` _(string)_ — human-readable description

**Example**

```m
set oldId="A",newId="B" do ne^STDASSERT(.pass,.fail,oldId,newId,"id rotated")
```

### `do near^STDASSERT(p, f, a, b, eps, desc)`

Assert |a-b|<=eps (float comparison).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `a` _(num)_ — first value
- `b` _(num)_ — second value
- `eps` _(num)_ — tolerance (max allowed |a-b|)
- `desc` _(string)_ — description

**Example**

```m
set sum=3.145 do near^STDASSERT(.pass,.fail,sum,3.14,0.01,"approx pi")
```

### `do raises^STDASSERT(p, f, code, errno, desc)`

Assert XECUTEing 'code' sets $ECODE containing 'errno'.

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `code` _(string)_ — M code XECUTEd inside the assertion frame
- `errno` _(string)_ — substring expected to appear in $ECODE
- `desc` _(string)_ — description

**Example**

```m
do raises^STDASSERT(.pass,.fail,"set x=1/0",",M9,","divzero")
```

### `do report^STDASSERT(p, f)`

Print summary; halt with error if any failures.

**Parameters**

- `p` _(int)_ — pass count
- `f` _(int)_ — fail count

**Example**

```m
do report^STDASSERT(pass,fail)
```

### `do start^STDASSERT(p, f)`

Initialise pass/fail counters (call by-reference).

**Parameters**

- `p` _(int)_ — pass counter (by-ref; set to 0)
- `f` _(int)_ — fail counter (by-ref; set to 0)

**Example**

```m
do start^STDASSERT(.pass,.fail)
```

### `do true^STDASSERT(p, f, cond, desc)`

Assert cond is truthy (non-zero numeric prefix).

**Parameters**

- `p` _(int)_ — pass counter (by-ref)
- `f` _(int)_ — fail counter (by-ref)
- `cond` _(string)_ — condition (M truthiness)
- `desc` _(string)_ — description

**Example**

```m
new arr set arr(1)="" do true^STDASSERT(.pass,.fail,$data(arr),"arr defined")
```

<!-- END GENERATED API REFERENCE -->

## Suite shape

```m
STDASSERTTST    ;
        NEW pass,fail
        DO start^STDASSERT(.pass,.fail)
        ;
        DO tMyCase(.pass,.fail)
        DO tAnotherCase(.pass,.fail)
        ;
        DO report^STDASSERT(pass,fail)
        QUIT
        ;
tMyCase(pass,fail)      ;@TEST "what this verifies"
        DO eq^STDASSERT(.pass,.fail,$$myFn^MYROUTINE("input"),"expected","got expected output")
        QUIT
```

The `t<UpperCase>(pass,fail)` label convention is the m-cli `m test`
discovery contract — keep it. The `;@TEST "..."` comment provides a
human-readable description picked up by LSP and TAP output.

## Public API

| Label | Signature | Asserts |
|---|---|---|
| `start` | `start(p,f)` | Initialise counters: sets `p=0,f=0`. |
| `report` | `report(p,f)` | Print summary; `HALT` with non-zero exit if `f>0`. |
| `eq` | `eq(p,f,actual,expected,desc)` | `actual=expected` (string). |
| `ne` | `ne(p,f,actual,expected,desc)` | `actual'=expected`. |
| `true` | `true(p,f,cond,desc)` | `cond` is truthy (numeric prefix non-zero). |
| `false` | `false(p,f,cond,desc)` | `cond` is falsy (numeric prefix zero or empty). |
| `near` | `near(p,f,a,b,eps,desc)` | `\|a-b\|<=eps` (use for floats). |
| `raises` | `raises(p,f,code,errno,desc)` | XECUTEing `code` sets `$ECODE` containing `errno`. |
| `contains` | `contains(p,f,haystack,needle,desc)` | `haystack[needle` (M's substring operator). |
| `len` | `len(p,f,actual,n,desc)` | `actual=n` — caller computes the length. |
| `silent` | `silent(on)` | **Internal.** Toggles output suppression for self-tests. |

All assertion labels accept counters by reference (`.pass,.fail`),
update them, and print one PASS/FAIL line per call. They never halt
or throw — `report` is the single point of process exit.

## Examples

```m
; equality
DO eq^STDASSERT(.pass,.fail,$LENGTH(s),5,"5-char string")

; inequality
DO ne^STDASSERT(.pass,.fail,oldId,newId,"id rotated")

; truthiness (succeeds for any non-zero numeric prefix)
DO true^STDASSERT(.pass,.fail,$DATA(arr),"arr defined")

; float comparison with tolerance
DO near^STDASSERT(.pass,.fail,sum,3.14,0.01,"approx pi")

; expected error
DO raises^STDASSERT(.pass,.fail,"NEW x SET x=1/0",",M9,","DIVZERO ecode")

; substring containment
DO contains^STDASSERT(.pass,.fail,output,"OK","status line present")

; length comparison
DO len^STDASSERT(.pass,.fail,$LENGTH(arr),3,"3-element array")
```

## Output protocol (parser contract)

Every assertion emits exactly one of:

```
  PASS  <desc>
```

or:

```
  FAIL  <desc>
         expected: <expected>
         actual:   <actual>
```

Two leading spaces before `PASS`/`FAIL`; nine leading spaces before
`expected:`/`actual:`. `report` emits:

```
Results: <total> assertions  <p> passed  <f> failed
All assertions passed.
```

(or `<n> assertion(s) FAILED.` followed by a **non-zero process exit** — YDB
`ZHALT 3`, IRIS `$system.Process.Terminate($job,3)` — so the engine exit code
agrees with the FAILED text and can't read green on a truncated stream;
`nohalt` orchestration mode returns instead of exiting). The count is assertions —
it was labeled "tests" before the 2026-07-10 rename; m-cli parses both wordings.

m-cli's `m test` runner parses this protocol verbatim
([m-cli/src/m_cli/test/runner.py:69-78](../../../m-cli/src/m_cli/test/runner.py#L69-L78)).
**Don't change the format.** If you add new assertion helpers, route
their output through `recordPass` / `recordFail` so the protocol stays
single-sourced.

## Edge cases

- **`raises` and `$ECODE`.** `$ECODE` is a special variable and cannot
  be `NEW`ed. The implementation explicitly clears it before and after
  the `XECUTE`. The XECUTE-of-arg pattern is the documented purpose;
  m-cli's M-MOD-036 (taint→XECUTE) is suppressed at that line.
- **`raises` is dual-engine.** On YottaDB it unwinds the trapped error
  with `$ETRAP`+`ZGOTO $ZLEVEL`. IRIS has no `ZGOTO`/`$ZLEVEL` (the YDB
  path faults `<SYNTAX>` there), so a `$ZVERSION["IRIS"` branch routes to
  `irisRaises`, which runs the code in an ObjectScript `try { … } catch`
  and captures `$ECODE` — engine-identical to the YDB capture (`,M9,` for
  a `<DIVIDE>`, the full `,U-…,` user code for a `set $ECODE` raise), so
  the substring match against `errno` is the same on both engines. Note:
  IRIS `try{}` fully suppresses a deeper `$ETRAP`, so try/catch is the only
  viable IRIS unwind. (Resolved 2026-06-12; see discoveries.md.)
- **`true`/`false` semantics.** M evaluates strings as numbers when
  used in conditional contexts: `"abc"` is `0` (false), `"7abc"` is
  `7` (true). `true()` and `false()` use this M-native semantic.
- **`contains` with empty needle.** `"abc"["" ` is true in M — empty
  needle always matches. `contains` mirrors this.
- **Self-test of failure paths.** Tests that need to verify the FAIL
  branch (e.g. "does `eq` increment `fail` when actual!=expected?")
  use `silent(1)` to suppress the deliberate FAIL line, then verify
  the counters with another `eq` call. `silent(0)` resumes output.
- **Counter scope.** All assertion helpers update `p`/`f` by reference.
  Pass them with the leading dot: `do eq^STDASSERT(.pass,.fail,...)`.
  Forgetting the dot silently disconnects the counters from the
  outer report.

## Error codes

`STDASSERT` itself doesn't set `$ECODE`. Failing assertions only
increment `f`; control returns to the caller. `report` `HALT`s the
process with a non-zero status when `f>0`, which is what propagates
exit failure to `m test` / CI.

## Lint suppressions

Test suites that delegate `(pass,fail)` to STDASSERT helpers should
file-disable `M-MOD-020` at the top:

```m
STDFOOTST       ; ...
        ; m-lint: disable-file=M-MOD-020
        ; (m-cli's by-ref analyzer can't see writes through STDASSERT helpers.)
        NEW pass,fail
        ...
```

This is the canonical idiom — see
[`tests/STDASSERTTST.m`](../../tests/STDASSERTTST.m).

## See also

- [`STDUUID`](stduuid.md) — first consumer of STDASSERT.
- Implementation plan §8.1 — the API spec.
- m-tools/`^TESTRUN` — the legacy assertion library STDASSERT replaces.
  STDASSERT is a drop-in with a richer vocabulary; whole-suite
  execution under `m test` works without m-cli changes.
