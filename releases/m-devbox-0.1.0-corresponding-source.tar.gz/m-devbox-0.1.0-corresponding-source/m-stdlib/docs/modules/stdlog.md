---
module: STDLOG
tag: v0.0.4
phase: Phase 1
stable: stable
since: v0.0.4
synopsis: 'structured key=value logger (v0.0.4)'
labels: ['DEBUG', 'ERROR', 'FATAL', 'FORMAT', 'INFO', 'LEVEL', 'SINK', 'WARN']
errors: ['U-STDLOG-INVALID-FORMAT', 'U-STDLOG-INVALID-LEVEL', 'U-STDLOG-INVALID-SINK']
conformance: []
see_also: ['STDDATE', 'STDJSON']
---

# `STDLOG` — structured key=value logger

A small, dependency-free structured logger. Emits one line per record in
the form

```
<ISO-8601 UTC ts> level=<NAME> event=<event> k=v k=v ...
```

Pure-M; timestamp source is `$$now^STDDATE()` (track L4b folded into
the v0.0.4 commit since L5 STDDATE landed first).

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `DEBUG` | `do DEBUG^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)` | Emit a DEBUG line. |
| `ERROR` | `do ERROR^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)` | Emit an ERROR line. |
| `FATAL` | `do FATAL^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)` | Emit a FATAL line. |
| `FORMAT` | `do FORMAT^STDLOG(name)` | Select line-rendering format. "kv" (default) or "json". |
| `INFO` | `do INFO^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)` | Emit an INFO line (default level). |
| `LEVEL` | `do LEVEL^STDLOG(threshold)` | Set the runtime threshold. Levels at or above pass. |
| `SINK` | `do SINK^STDLOG(target)` | Configure where log lines go. |
| `WARN` | `do WARN^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)` | Emit a WARN line. |

### `do DEBUG^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)`

Emit a DEBUG line.

**Parameters**

- `event` _(string)_ — short event name (one token, no spaces ideally)
- `k1` _(string)_ — key 1 (optional)
- `v1` _(string)_ — value 1 (optional)
- `k2` _(string)_ — key 2 (optional)
- `v2` _(string)_ — value 2 (optional)
- `k3` _(string)_ — key 3 (optional)
- `v3` _(string)_ — value 3 (optional)
- `k4` _(string)_ — key 4 (optional)
- `v4` _(string)_ — value 4 (optional)
- `k5` _(string)_ — key 5 (optional)
- `v5` _(string)_ — value 5 (optional)

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do LEVEL^STDLOG("DEBUG") do DEBUG^STDLOG("cache_miss","key","u:42") do contains^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","buf",1),"level=DEBUG event=cache_miss key=u:42","DEBUG")
```

### `do ERROR^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)`

Emit an ERROR line.

**Parameters**

- `event` _(string)_ — short event name
- `k1` _(string)_ — key 1 (optional)
- `v1` _(string)_ — value 1 (optional)
- `k2` _(string)_ — key 2 (optional)
- `v2` _(string)_ — value 2 (optional)
- `k3` _(string)_ — key 3 (optional)
- `v3` _(string)_ — value 3 (optional)
- `k4` _(string)_ — key 4 (optional)
- `v4` _(string)_ — value 4 (optional)
- `k5` _(string)_ — key 5 (optional)
- `v5` _(string)_ — value 5 (optional)

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do ERROR^STDLOG("db_failed","sqlcode","-803") do contains^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","buf",1),"level=ERROR event=db_failed sqlcode=-803","ERROR")
```

### `do FATAL^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)`

Emit a FATAL line.

**Parameters**

- `event` _(string)_ — short event name
- `k1` _(string)_ — key 1 (optional)
- `v1` _(string)_ — value 1 (optional)
- `k2` _(string)_ — key 2 (optional)
- `v2` _(string)_ — value 2 (optional)
- `k3` _(string)_ — key 3 (optional)
- `v3` _(string)_ — value 3 (optional)
- `k4` _(string)_ — key 4 (optional)
- `v4` _(string)_ — value 4 (optional)
- `k5` _(string)_ — key 5 (optional)
- `v5` _(string)_ — value 5 (optional)

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do FATAL^STDLOG("crash","reason","oom") do contains^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","buf",1),"level=FATAL event=crash reason=oom","FATAL")
```

### `do FORMAT^STDLOG(name)`

Select line-rendering format. "kv" (default) or "json".

**Parameters**

- `name` _(string)_ — "kv" (default) or "json"

**Raises**

- `U-STDLOG-INVALID-FORMAT` — `name` is not "kv" or "json"

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do FORMAT^STDLOG("json") do eq^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","format"),"json","FORMAT selects json")
do raises^STDASSERT(.pass,.fail,"do FORMAT^STDLOG(""xml"")",",U-STDLOG-INVALID-FORMAT,","unknown format rejected")
```

### `do INFO^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)`

Emit an INFO line (default level).

**Parameters**

- `event` _(string)_ — short event name
- `k1` _(string)_ — key 1 (optional)
- `v1` _(string)_ — value 1 (optional)
- `k2` _(string)_ — key 2 (optional)
- `v2` _(string)_ — value 2 (optional)
- `k3` _(string)_ — key 3 (optional)
- `v3` _(string)_ — value 3 (optional)
- `k4` _(string)_ — key 4 (optional)
- `v4` _(string)_ — value 4 (optional)
- `k5` _(string)_ — key 5 (optional)
- `v5` _(string)_ — value 5 (optional)

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do INFO^STDLOG("login","user","alice","ip","1.2.3.4") do contains^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","buf",1),"level=INFO event=login user=alice ip=1.2.3.4","INFO")
```

### `do LEVEL^STDLOG(threshold)`

Set the runtime threshold. Levels at or above pass.

**Parameters**

- `threshold` _(string)_ — one of "DEBUG", "INFO", "WARN", "ERROR", "FATAL"

**Raises**

- `U-STDLOG-INVALID-LEVEL` — `threshold` is not one of the five names

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do LEVEL^STDLOG("WARN") do INFO^STDLOG("suppressed") do eq^STDASSERT(.pass,.fail,$data(^STDLIB(j,"stdlog","buf")),0,"LEVEL WARN suppresses INFO")
do raises^STDASSERT(.pass,.fail,"do LEVEL^STDLOG(""TRACE"")",",U-STDLOG-INVALID-LEVEL,","unknown level rejected")
```

### `do SINK^STDLOG(target)`

Configure where log lines go.

**Parameters**

- `target` _(string)_ — one of "stderr", "stdout", "global", or "global:^GREF"

**Raises**

- `U-STDLOG-INVALID-SINK` — `target` is not one of the documented forms

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") kill ^MYLOG do SINK^STDLOG("global:^MYLOG") do INFO^STDLOG("hi") do contains^STDASSERT(.pass,.fail,^MYLOG(1),"event=hi","SINK global:^GREF writes ^MYLOG(N)")
do raises^STDASSERT(.pass,.fail,"do SINK^STDLOG(""file"")",",U-STDLOG-INVALID-SINK,","unknown sink rejected")
```

### `do WARN^STDLOG(event, k1, v1, k2, v2, k3, v3, k4, v4, k5, v5)`

Emit a WARN line.

**Parameters**

- `event` _(string)_ — short event name
- `k1` _(string)_ — key 1 (optional)
- `v1` _(string)_ — value 1 (optional)
- `k2` _(string)_ — key 2 (optional)
- `v2` _(string)_ — value 2 (optional)
- `k3` _(string)_ — key 3 (optional)
- `v3` _(string)_ — value 3 (optional)
- `k4` _(string)_ — key 4 (optional)
- `v4` _(string)_ — value 4 (optional)
- `k5` _(string)_ — key 5 (optional)
- `v5` _(string)_ — value 5 (optional)

**Example**

```m
new j set j=$job kill ^STDLIB(j,"stdlog") do SINK^STDLOG("global") do WARN^STDLOG("retry","attempt","3") do contains^STDASSERT(.pass,.fail,^STDLIB(j,"stdlog","buf",1),"level=WARN event=retry attempt=3","WARN")
```

<!-- END GENERATED API REFERENCE -->

## Public API

| Entry | Signature | Purpose |
|---|---|---|
| `DEBUG` | `do DEBUG^STDLOG(event,k1,v1,...,k5,v5)` | Emit at level DEBUG (priority 10). Up to 5 kv pairs. |
| `INFO` | `do INFO^STDLOG(event,...)` | Emit at level INFO (priority 20). Default threshold. |
| `WARN` | `do WARN^STDLOG(event,...)` | Emit at level WARN (priority 30). |
| `ERROR` | `do ERROR^STDLOG(event,...)` | Emit at level ERROR (priority 40). |
| `FATAL` | `do FATAL^STDLOG(event,...)` | Emit at level FATAL (priority 50). |
| `LEVEL` | `do LEVEL^STDLOG(threshold)` | Set threshold. Accepts any level name above. |
| `SINK` | `do SINK^STDLOG(target)` | Set sink: `stderr` / `stdout` / `global` / `global:^GREF`. |

All five level entry points accept a leading `event` string and up to
5 key/value formal pairs (`k1,v1,...,k5,v5`). Caller-supplied pairs
appear in the rendered line in the order they were passed; missing
trailing pairs are simply omitted.

## Examples

```m
; defaults — INFO threshold, stderr sink
do INFO^STDLOG("login","user","alice","ip","10.0.0.1")
; → 2026-05-05T17:42:31.123Z level=INFO event=login user=alice ip=10.0.0.1

; quiet down — only WARN and above
do LEVEL^STDLOG("WARN")
do INFO^STDLOG("ignored")          ; suppressed
do WARN^STDLOG("retry","attempt","3")
; → 2026-05-05T17:42:31.456Z level=WARN event=retry attempt=3

; capture into a global for tests / log inspection
do SINK^STDLOG("global")
do INFO^STDLOG("captured")
; ^STDLIB($job,"stdlog","buf",1) holds the rendered line

; redirect to a caller-named global
do SINK^STDLOG("global:^MYAPPLOG")
do INFO^STDLOG("hello")
; ^MYAPPLOG(1) holds the rendered line
```

## Levels

| Name | Priority |
|---|---|
| `DEBUG` | 10 |
| `INFO` | 20 (default threshold) |
| `WARN` | 30 |
| `ERROR` | 40 |
| `FATAL` | 50 |

A line is emitted when its level priority is **at or above** the
configured threshold. The default threshold is `INFO`, so `DEBUG`
calls are silent unless the caller explicitly opts in via
`do LEVEL^STDLOG("DEBUG")`.

## Sinks

| Target | Behaviour |
|---|---|
| `stderr` | Open `/dev/stderr` and write the line. Default when no `SINK` call has been made. |
| `stdout` | Write to the current device (typically standard output). |
| `global` | Write to `^STDLIB($job,"stdlog","buf",N)` where `N` is allocated via `$INCREMENT`. |
| `global:^FOO` | Write to `^FOO(N)` where `N` is allocated via `$INCREMENT` on a per-target counter under `^STDLIB($job,"stdlog","cnt","g","^FOO")`. |

Sink configuration is per-process and persists in
`^STDLIB($job,"stdlog","sink")`. The `global` sinks are convenient for
testing and for buffered analysis pipelines: each emit gets a unique
sequential subscript, and concurrent emitters never collide because
`$INCREMENT` is atomic.

## Value escaping

Values are emitted **raw** when they contain none of: space, `=`, `"`,
`\`. Otherwise the value is wrapped in double quotes, with embedded
`\` doubled to `\\` and embedded `"` escaped to `\"`. The empty
string renders as `""`.

```m
do INFO^STDLOG("e","msg","hello world")  ; msg="hello world"
do INFO^STDLOG("e","kv","a=b")           ; kv="a=b"
do INFO^STDLOG("e","q","a""b")           ; q="a\"b"
do INFO^STDLOG("e","p","a\b c")          ; p="a\\b c"
do INFO^STDLOG("e","empty","")           ; empty=""
```

Keys are emitted verbatim — callers should keep keys to
identifier-safe characters (alphanumerics + `_`).

## Edge cases

- **No kv pairs.** Calling `do INFO^STDLOG("startup")` is legal; the
  line ends after `event=startup`.
- **Missing trailing values.** Passing `k1` without `v1` (e.g. an odd
  number of kv arguments) treats the missing value as the empty string
  and emits `k1=""`.
- **Threshold reset.** Killing `^STDLIB($job,"stdlog","level")`
  restores the default `INFO` threshold; the same applies to the sink
  config.
- **Test isolation.** Tests that exercise STDLOG should reset state
  between cases: `kill ^STDLIB($job,"stdlog")` then `do
  SINK^STDLOG("global")` and `do LEVEL^STDLOG("DEBUG")`.

## Errors

| `$ECODE` | Trigger |
|---|---|
| `,U-STDLOG-INVALID-LEVEL,` | `LEVEL` called with anything other than the five named priorities. |
| `,U-STDLOG-INVALID-SINK,` | `SINK` called with a target that is not `stderr`, `stdout`, `global`, or `global:^...` (the post-colon part must start with `^`). |

## Timestamp source

`$$now^STDDATE()` — millisecond-precision ISO-8601 UTC ending in `Z`.
v0.0.4 was originally planned to ship an inline helper (replaced at
v0.0.5 by track L4b), but since L5 STDDATE merged first, L4b is
folded into the v0.0.4 commit and STDLOG ships using STDDATE from
day one.

## See also

- `STDDATE` (v0.0.5) — provides the timestamp via `$$now`.
- `STDJSON` (v0.2.0) — adds a JSON-line output mode in Phase 2.
- `STDFIX` (v0.1.1) — log records can be safely emitted from inside
  TSTART/TROLLBACK isolation blocks; STDLOG performs no transactional
  state of its own.

## History

The original `v0.0.4` release was the kv logger only. The L4
`FORMAT(kv|json)` add-on landed at `v0.2.0` (depends on STDJSON, which
itself only became available at `v0.2.0`). Total effort spans both
landings.

The seven JSON-emission tests (`tFormatJsonEmitsValidJson` …
`tFormatKvAfterJsonReverts`) were withheld at the kv-only v0.0.4
release because the first call after a clean kv-path test crashed the
YDB harness. Diagnosis (corrected after one wrong turn) traced to the
documented YDB syntax limit `.x(SUBS)` (`%YDB-E-COMMAORRPAREXP` at
compile time on subscripted-by-reference args). STDJSON's recursive
descent was refactored to the **merge-then-pass** idiom in commit
`c3a0880`; the four parked STDLOG-JSON probe-the-tree tests followed
in commit `fb48f39` once `raises^STDASSERT` itself was hardened (ZGOTO
unwind for arg-less-quit-in-extrinsic in `9ee9724`).
