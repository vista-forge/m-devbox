---
module: STDJWT
tag: v0.13.0
phase: Phase 5 — web stack + AWS S3 egress
stable: stable
since: v0.13.0
synopsis: 'JSON Web Token (RFC 7519 / 9068) validation'
labels: ['claim', 'decode', 'lastError', 'sign', 'verify']
errors: []
conformance: []
see_also: ['STDB64', 'STDCRYPTO', 'STDJSON']
---

# `STDJWT` — JSON Web Token (RFC 7519 / 9068) validation

Resource-server-side JWT handling for m-stdlib: parse a compact JWS, verify
its HMAC-SHA-256 signature, and validate the registered claims (RFC 7519 §4.1
`exp`/`nbf`/`iss`/`aud`) the way an OAuth 2.0 resource server must (RFC 9068).

This is deliberately **not** an authorization server — there is no production
token issuance here. `$$sign` exists only to build dev/test fixtures. STDJWT is
the **engine-neutral half of the VSL/MSL SMART-on-FHIR auth stack (M6.5)**: it
answers "is this bearer token valid?" in layer `m`; the VistA identity binding
(a validated subject → NEW PERSON `#200` / DUZ) lives above the waterline in
v-stdlib and never appears here.

**Algorithm:** **HS256** (HMAC-SHA-256) is wired. RS256/ES256 via a JWKS key
set are the staged follow-on, dispatched on the header `alg`; until then a
non-HS256 token is **rejected, never silently accepted**.

A compact JWS is three base64url segments joined by `.`:
`header.payload.signature`. The signing input is `header.payload`; the
signature is `urlencode(HMAC-SHA-256(key, signing-input))`. Header and claims
trees use the **STDJSON typed-node convention** (`"o"` / `"a"` / `"s:VALUE"` /
`"n:VALUE"`); read a scalar with `$$valueOf^STDJSON`.

<!-- BEGIN GENERATED API REFERENCE — managed by tools/gen-bodies.py (`make docs-bodies`); edits between these markers are overwritten. -->
## API reference

_Generated from `dist/stdlib-manifest.json` — the canonical, always-current signature / parameter / return / error surface. Hand-written usage narrative and gotchas, when present, appear on the page outside this generated block._

| Label | Signature | Summary |
|---|---|---|
| `claim` | `$$claim^STDJWT(token, name)` | One-shot UNVERIFIED read of a single claim's scalar value. |
| `decode` | `$$decode^STDJWT(token, hdr, claims)` | Parse header + claims trees; NO signature/claim check. |
| `lastError` | `$$lastError^STDJWT()` | The reason the most recent $$verify/$$decode failed ("" when none). |
| `sign` | `$$sign^STDJWT(claims, key, opts)` | DEV/TEST ONLY — build an HS256 compact JWS from a claims tree. |
| `verify` | `$$verify^STDJWT(token, key, claims, opts)` | Verify signature + registered claims; 1 iff valid. |

### `$$claim^STDJWT(token, name)`

One-shot UNVERIFIED read of a single claim's scalar value.

**Parameters**

- `token` _(string)_ — compact JWS
- `name` _(string)_ — claim name (e.g. "sub", "iss", "scope")

**Returns** _string_ — the claim's scalar value, or "" if absent/unparseable

**Example**

```m
new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$$claim^STDJWT($$sign^STDJWT(.c,"k"),"sub"),"u1","read the sub claim")
```

### `$$decode^STDJWT(token, hdr, claims)`

Parse header + claims trees; NO signature/claim check.

**Parameters**

- `token` _(string)_ — compact JWS
- `hdr` _(array)_ — by-ref; the decoded JOSE header tree
- `claims` _(array)_ — by-ref; the decoded claims (payload) tree

**Returns** _bool_ — 1 if both segments base64url-decode and parse as JSON; else 0

**Example**

```m
new c,h,cl set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$$decode^STDJWT($$sign^STDJWT(.c,"k"),.h,.cl),1,"decode parses a signed token")
```

### `$$lastError^STDJWT()`

The reason the most recent $$verify/$$decode failed ("" when none).

**Returns** _string_ — the last failure message, or ""

**Example**

```m
set v=$$verify^STDJWT("a.b","k") do eq^STDASSERT(.pass,.fail,$$lastError^STDJWT(),"malformed token: expected 3 base64url segments","lastError reports the prior failure")
```

### `$$sign^STDJWT(claims, key, opts)`

DEV/TEST ONLY — build an HS256 compact JWS from a claims tree.

**Parameters**

- `claims` _(array)_ — by-ref claims tree (STDJSON typed nodes)
- `key` _(string)_ — HMAC shared secret
- `opts` _(array)_ — by-ref; reserved (header overrides) — optional

**Returns** _string_ — a signed HS256 token

**Example**

```m
new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do eq^STDASSERT(.pass,.fail,$length($$sign^STDJWT(.c,"k"),"."),3,"sign emits a 3-part compact JWS")
```

### `$$verify^STDJWT(token, key, claims, opts)`

Verify signature + registered claims; 1 iff valid.

**Parameters**

- `token` _(string)_ — compact JWS (header.payload.signature, base64url)
- `key` _(string)_ — HMAC shared secret (HS256) OR the caller's SPKI public key (DER/PEM) for an asymmetric alg
- `claims` _(array)_ — by-ref; populated with the claims tree (STDJSON typed nodes)
- `opts` _(array)_ — by-ref; now/leeway/iss/aud + the alg allowlist algs/alg (all optional)

**Returns** _bool_ — 1 if signature + exp/nbf/iss/aud all pass; 0 otherwise ($$lastError set)

**Example**

```m
new c set v=$$parse^STDJSON("{""sub"":""u1""}",.c) do true^STDASSERT(.pass,.fail,$$verify^STDJWT($$sign^STDJWT(.c,"secret"),"secret"),"verify a self-signed token")
do false^STDASSERT(.pass,.fail,$$verify^STDJWT("not.a.jwt","k"),"a malformed token verifies as 0")
```

<!-- END GENERATED API REFERENCE -->

## Status

**Shipped in `v0.13.0`.** Dual-engine **GREEN** — STDJWTTST 28/28 on bare
YottaDB (m-test-engine, `--chset m`) and bare IRIS (m-test-iris).

`@tier optional`. STDJWT depends on **STDCRYPTO** for the HMAC, which is a
compiled `$&stdcrypto` (libcrypto) call-out. It therefore runs under
`make test-optional`, not the dependency-free `make test` core. Before relying
on `$$verify`/`$$sign` on an engine that may lack the crypto call-out, preflight
with `$$available^STDCRYPTO()` — a 0 there means the HMAC primitive is not
loaded and signature computation will not work. STDJWT also consumes **STDB64**
(base64url), **STDJSON** (header/claims parse + encode) and **STDDATE**
(`$$epoch` clock).

## Public API

### `verify`

```m
set ok=$$verify^STDJWT(token,key,.claims,.opts)
```

Verify the signature **and** the registered claims; returns `1` iff the token
is valid, `0` otherwise (with `$$lastError` set to the reason).

- **`token`** *(string)* — compact JWS (`header.payload.signature`, base64url).
- **`key`** *(string)* — the HMAC shared secret (HS256).
- **`claims`** *(array, by-ref)* — populated with the decoded claims tree
  (STDJSON typed nodes). Killed and rebuilt on each call.
- **`opts`** *(array, by-ref, all optional)*:
  - `opts("now")` — epoch override for the clock (default `$$epoch^STDDATE()`).
  - `opts("leeway")` — clock-skew tolerance in seconds (default `0`).
  - `opts("iss")` — required issuer; the `iss` claim must equal it.
  - `opts("aud")` — required audience (see audience matching below).
  - `opts("alg")` — expected algorithm (default HS256). A token whose header
    `alg` is not `HS256` is rejected outright.
- **Returns** *(bool)* — `1` if the structure, signature, and `exp`/`nbf`/`iss`/
  `aud` checks all pass; `0` otherwise.

Validation order: 3-segment structure → `$$decode` (base64url + JSON parse) →
header `alg` must be HS256 → signature recompute + **constant-time** compare →
`exp` (expired iff `now '< exp+leeway`) → `nbf` (not-yet-valid iff
`now < nbf-leeway`) → `iss` (when `opts("iss")` set) → `aud` (when `opts("aud")`
set). The first failure short-circuits and stashes the reason.

**Does not raise** — every failure path returns `0` and sets `$$lastError`.

```m
new claims,opts
set opts("iss")="https://idp.example.va.gov"
set opts("aud")="vista-fhir"
set opts("leeway")=30
if '$$verify^STDJWT(tok,secret,.claims,.opts) do  quit
. write "rejected: ",$$lastError^STDJWT(),!
write "subject: ",$$valueOf^STDJSON(claims("sub")),!
```

### `decode`

```m
set ok=$$decode^STDJWT(token,.hdr,.claims)
```

Parse the header and claims trees with **no** signature or claim check;
returns `1` if both segments base64url-decode and parse as JSON, else `0`.

- **`token`** *(string)* — compact JWS.
- **`hdr`** *(array, by-ref)* — the decoded JOSE header tree (killed first).
- **`claims`** *(array, by-ref)* — the decoded claims (payload) tree (killed
  first).
- **Returns** *(bool)* — `1` iff well-formed; sets `$$lastError` and returns `0`
  on a non-3-segment token or a non-JSON header/claims.

**Inspect-only.** A `1` here means *well-formed*, not *trusted* — never make an
authorization decision on `$$decode` output; use `$$verify`. Does not raise.

```m
new H,C
if $$decode^STDJWT(tok,.H,.C) write "alg=",$$valueOf^STDJSON(H("alg")),!
```

### `claim`

```m
write $$claim^STDJWT(token,name)
```

One-shot **unverified** read of a single claim's scalar value (a convenience
wrapper over `$$decode`).

- **`token`** *(string)* — compact JWS.
- **`name`** *(string)* — claim name (e.g. `"sub"`, `"iss"`, `"scope"`).
- **Returns** *(string)* — the claim's scalar value, or `""` if the token is
  unparseable or the claim is absent.

Convenience for logging/diagnostics. **Unverified** — do not authorize on it.

```m
write "incoming sub: ",$$claim^STDJWT(tok,"sub"),!
```

### `sign`

```m
set tok=$$sign^STDJWT(.claims,key,.opts)
```

**DEV/TEST ONLY** — build an HS256 compact JWS from a claims tree. The header
is fixed to `{"alg":"HS256","typ":"JWT"}`; the signing input is
`urlencode(header).urlencode($$encode^STDJSON(.claims))`.

- **`claims`** *(array, by-ref)* — claims tree in STDJSON typed-node form.
- **`key`** *(string)* — the HMAC shared secret.
- **`opts`** *(array, by-ref, optional)* — reserved for header overrides.
- **Returns** *(string)* — a signed HS256 token.

For test fixtures and local dev tokens only — **not** a production issuer.
Real tokens come from the IdP/STS; this never manages signing keys.

```m
new claims
set claims="o"
set claims("sub")="s:1234567890"
set claims("iss")="s:test-idp"
set tok=$$sign^STDJWT(.claims,"secret")
write $$verify^STDJWT(tok,"secret",.out),!   ; 1
```

### `lastError`

```m
set msg=$$lastError^STDJWT()
```

The reason the most recent `$$verify`/`$$decode` failed; `""` when the last
call succeeded (success clears the stash). Messages include `"malformed token:
expected 3 base64url segments"`, `"unsupported alg '…'"`, `"signature
mismatch"`, `"token expired"`, `"token not yet valid (nbf in the future)"`,
`"issuer mismatch"`, and `"audience mismatch"`.

- **Returns** *(string)* — the last failure message, or `""`.

## Claim validation

- **`exp`** (expiration) — token is expired iff `now '< (exp + leeway)`.
- **`nbf`** (not-before) — token is not-yet-valid iff `now < (nbf - leeway)`.
- **`iss`** (issuer) — checked only when `opts("iss")` is set; the `iss` claim
  must equal it exactly.
- **`aud`** (audience) — checked only when `opts("aud")` is set. Per RFC 7519
  §4.1.3 the `aud` claim may be a single string **or** an array; the requested
  audience matches if it equals the scalar value or is a member of the array.
- Claims are read through `$$valueOf^STDJSON`, so absent `exp`/`nbf` simply skip
  their check (an unbounded-lifetime token is not rejected by STDJWT alone —
  enforce presence at the caller if your policy requires it).

## Notes & gotchas

- **No `$ECODE` / `$ETRAP` surface.** Every public label degrades to a boolean
  (`0` / `""`) plus `$$lastError`; STDJWT does not raise. The manifest lists no
  `U-STDJWT*` error codes (`errors: []`) — failure reasons are conveyed by
  `$$lastError`, not by raised codes.
- **Constant-time signature compare.** The signature equality check (`cteq`,
  private to STDJWT) never early-exits on the first differing byte, to avoid a
  timing oracle. It will be promoted to a public `$$ctEquals^STDCRYPTO` when a
  second consumer needs it.
- **HS256 only, by design.** A header `alg` other than `HS256` (including
  `"none"`) is rejected — STDJWT never trusts an unsigned or unsupported-alg
  token. RS256/ES256 via JWKS is the staged follow-on behind the same `alg`
  dispatch.
- **Byte mode.** Like the rest of m-stdlib, run the engine in byte mode
  (`ydb_chset=M`): the base64url and HMAC paths are byte-oriented.
- **Optional-tier prerequisite.** `$$verify` and `$$sign` need the STDCRYPTO
  HMAC call-out. Probe with `$$available^STDCRYPTO()` before use on an engine
  that may not have it loaded; `$$decode` and `$$claim` (parse-only) do not
  depend on the crypto call-out.

## See also

- [`STDCRYPTO`](stdcrypto.md) — `$$hmacSha256Bytes` (the HS256 primitive) and
  `$$available` preflight.
- [`STDB64`](stdb64.md) — `$$urlencode` / `$$urldecode` for base64url segments.
- [`STDJSON`](stdjson.md) — header/claims typed-node trees; `$$valueOf`,
  `$$parse`, `$$encode`.
- [`STDDATE`](stddate.md) — `$$epoch` UTC Unix-second clock for `exp`/`nbf`.

## History

Shipped in `v0.13.0` (promoted from `future-modules-plan` A5/item 3 the moment
TDD-red was staked). The engine-neutral half of the VSL/MSL auth stack (M6.5):
token validation lives here in `m`; the VistA identity binding lives above the
waterline in v-stdlib. The private constant-time compare descends from
`future-modules` A3 `$$ctEquals`. Dual-engine GREEN at ship: STDJWTTST 28/28 on
bare YottaDB and bare IRIS.
