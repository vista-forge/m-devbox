---
title: M Test-Driven Development Guide
audience: M developers building or maintaining test suites on top of m-stdlib's primitives.
companion: users-guide.md (general m-stdlib usage). comprehensive-testing.md (run everything). modules/index.md (per-module reference).
created: 2026-05-08
last_modified: 2026-06-24
revisions: 6
doc_type: [GUIDE]
---

# M Test-Driven Development Guide

The TDD loop on M:

```
edit src/*.m  →  m fmt  →  m lint  →  m test (via the driver stack)  →
m coverage (aggregate line, gated ≥85%)  →  make examples-run  →  CI
```

This guide is what to type and how the pieces fit: the runtime substrate, the
`m` runner, the suite anatomy, the in-suite testing patterns, and the gates.

## Contents

- [1. The substrate](#1-the-substrate)
- [2. Anatomy of a test suite](#2-anatomy-of-a-test-suite)
- [3. The runner](#3-the-runner)
  - [3.1 `m test`](#31-m-test)
  - [3.2 `m coverage`](#32-m-coverage)
- [4. The TDD inner loop](#4-the-tdd-inner-loop)
- [5. Worked example — TDD a module](#5-worked-example--tdd-a-module)
- [6. In-suite testing patterns](#6-in-suite-testing-patterns)
  - [6.1 Transactional isolation](#61-transactional-isolation)
  - [6.2 Mocking call sites](#62-mocking-call-sites)
  - [6.3 Fixture data](#63-fixture-data)
  - [6.4 Snapshot testing](#64-snapshot-testing)
  - [6.5 Config via `.env`](#65-config-via-env)
  - [6.6 Profiling](#66-profiling)
- [7. The release-readiness gate](#7-the-release-readiness-gate)
- [8. Living examples — the second surface](#8-living-examples--the-second-surface)
- [9. CI](#9-ci)
- [10. Troubleshooting](#10-troubleshooting)
- [11. History & further reading](#11-history--further-reading)

## 1. The substrate

Three pieces collaborate. None owns the whole stack:

| Piece | Responsibility | Entry point |
|---|---|---|
| **`m-stdlib`** | The M-side runtime — assertions (`STDASSERT`), and the test-discovery contract (`*TST.m` suites, `t<UpperCase>(pass,fail)` labels). The fixture / mock / seed / snapshot / profile / `.env` helper modules (`STDFIX` / `STDMOCK` / `STDSEED` / `STDSNAP` / `STDPROF` / `STDENV`) are ordinary library calls you make **inside** suite code. | `do start^STDASSERT(.pass,.fail)` / `do eq^STDASSERT(...)` — see §2. |
| **the Go `m`** | One static binary (built from `m-cli`) — `m fmt`, `m lint`, `m test`, `m coverage`. A lean suite-runner: it stages routines, runs `*TST.m` through the engine, parses the `^STDASSERT` output, and reports pass/fail + coverage. | `m test --docker m-test-engine --chset m --routines src tests/` — see §3. |
| **the engine** | Reached **only** through the driver stack (`m-driver-sdk → m-ydb / m-iris`) via `m … --docker <container>` — never a raw `docker exec` or a host install. Default = the byte-mode `m-test-engine` YottaDB container; IRIS portability = `m-test-iris`; live VistA = `vehu` / `foia`. | `docker run -d --name m-test-engine m-test-engine:0.3.0-local` (one-time). |

Build the `m` binary once and point the Makefile at it:

```bash
git clone https://github.com/vista-forge/m-cli ~/vista-forge/m-cli
( cd ~/vista-forge/m-cli && go build -o dist/m . )
export M=$HOME/vista-forge/m-cli/dist/m       # make test M=$M
```

## 2. Anatomy of a test suite

A suite is a routine `tests/<NAME>TST.m`. Its entry line `new`s the counters,
calls `start^STDASSERT`, runs each `t<Label>(pass,fail)` sub-routine, then
`report^STDASSERT`. Each test label carries a `;@TEST "<description>"` marker and
asserts via the `^STDASSERT` verbs.

```m
STDFOOTST       ; Test suite for STDFOO.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        do tBarReturnsLength(.pass,.fail)
        do tBarRejectsEmpty(.pass,.fail)
        do report^STDASSERT(pass,fail)
        quit
        ;
tBarReturnsLength(pass,fail) ;@TEST "$$bar^STDFOO returns input length"
        do eq^STDASSERT(.pass,.fail,$$bar^STDFOO("hello"),5,"length of hello")
        quit
        ;
tBarRejectsEmpty(pass,fail) ;@TEST "$$bar^STDFOO raises on empty input"
        do raises^STDASSERT(.pass,.fail,"$$bar^STDFOO("""")",",U-STDFOO-EMPTY,","empty rejected")
        quit
```

The `^STDASSERT` verbs (all `do <verb>^STDASSERT(.pass,.fail,…)`):

| Verb | Asserts |
|---|---|
| `eq` / `ne` | `actual` equals / does not equal `expected` (string equality). |
| `true` / `false` | the expression is truthy / falsy. |
| `near` | `|a − b| ≤ eps` (float comparison). |
| `contains` | `haystack` contains `needle` (`[` operator). |
| `len` | a value has length `n`. |
| `raises` | `xecute`-ing the snippet sets `$ECODE` containing `,CODE,`. |

> **A `0/0` result is a failure, not a pass.** It means the suite aborted before
> `report^STDASSERT` ran — almost always a routine that raised `$ECODE` at load or
> in a TDD-red stub. TDD-red stubs must return a **safe default**
> (`quit 0` / `quit ""` / leave by-ref arrays untouched), never set `$ECODE`.

## 3. The runner

### 3.1 `m test`

`m test [<paths>…]` stages routines and runs the `*TST.m` suites through the
engine. Paths are positional (suites or directories; default `.`). The flag set
(`m test --help` is authoritative):

| Flag | Purpose |
|---|---|
| `-o` / `--output text\|json\|auto` | Output format (default `auto` — styled text on a TTY, else JSON). |
| `--engine ydb\|iris` | Target engine; else `$M_ENGINE` / heuristic (refuses, exit 4, if unresolved). |
| `--docker NAME` | Run inside this running container via the driver stack (`m-test-engine`, `m-test-iris`, `vehu`, `foia-t12`). |
| `--routines DIR,…` | Source dirs to stage on the routine path (e.g. `src` for the code under test, `../m-stdlib/src` for `^STDASSERT`). Repeatable. |
| `--namespace NAME` | IRIS namespace (default `USER`; live VistA = `VISTA`). |
| `--chset m\|utf-8` | Engine charset — `m` (byte mode) for the byte suites (`STDCSPRNG` / `STDB64` / `STDHEX`) on YDB; inherent on IRIS. |
| `--resident` | Run `;; tier: integration` suites via the resident harness (`RUN^STDHARN`) and reconcile with the file-side pure-logic suites. |
| `-v` / `--verbose` | Verbose diagnostics to stderr. |

```bash
m test --docker m-test-engine --chset m --routines src tests/                 # all suites
m test --docker m-test-engine --chset m --routines src tests/STDFOOTST.m      # one suite
```

To run a subset, pass the specific suite path(s). Day to day, use the Makefile —
`make test M=$M` wraps the engine flags for you (`M_ENGINE_FLAGS` defaults to
`--engine ydb --docker m-test-engine --chset m`).

### 3.2 `m coverage`

`m coverage` measures line coverage. Positional args split into the measured
routines (`src/*.m`) and the suites (`*TST.m`).

| Flag | Purpose |
|---|---|
| `-o` / `--output text\|json\|auto` | Output format. |
| `--engine` / `--docker` / `--routines` / `--namespace` / `--chset` | The same engine transport as `m test`. |
| `--min-percent N` | Fail (exit 3) if **aggregate line coverage** is below N percent. |
| `--lcov PATH` | Write an LCOV tracefile (for `genhtml` / Codecov / Coveralls). |

The gate is **aggregate** line coverage across the measured set (`make coverage`
passes `--min-percent=85`; m-stdlib runs at ~93%), not per-module. The LCOV
tracefile drives the per-line HTML / Codecov view.

## 4. The TDD inner loop

1. **Write the test first.** Add the `t<Label>` to the suite stating the public
   contract (`$$bar^STDFOO` returns / raises …).
2. **Confirm red.** `make test M=$M` — the assertion fails (or the label doesn't
   exist yet). A *deliberate* red, with a concrete message.
3. **Implement** the smallest code in `src/` that makes it green. A TDD-red stub
   returns a safe default until implemented (never `$ECODE`).
4. **Confirm green.** `make test M=$M`.
5. **Gate.** `make check M=$M` (fmt + lint + test); `make coverage M=$M` (≥85%).

## 5. Worked example — TDD a module

Scaffold by **modeling on this repo** (there is no `m new` and no external
template — keep it self-contained): copy an existing module's shape into the new
one. For a new module *inside* m-stdlib, add `src/STDFOO.m` +
`tests/STDFOOTST.m` beside their peers; for a brand-new engine-neutral `m-*`
repo, copy the `.m-cli.toml` / `Makefile` / `repo.meta.json` / `docs/` layout
from m-stdlib (or the in-org `go-cli-template` for a Go tool).

```bash
# inside m-stdlib: create the two files beside their peers
cp src/STDSTR.m src/STDFOO.m           # then rewrite the body
cp tests/STDSTRTST.m tests/STDFOOTST.m # then rewrite the suite
```

Stake the contract in `tests/STDFOOTST.m` (the suite in §2), then confirm red:

```bash
make test M=$M
```

Implement `src/STDFOO.m`:

```m
STDFOO  ; Length helper.
        quit
bar(s)
        if s="" set $ecode=",U-STDFOO-EMPTY," quit ""
        quit $length(s)
```

Confirm green and gate:

```bash
make test M=$M       # 1 suite(s), 2/2 assertions passed
make check M=$M      # fmt + lint + test
make coverage M=$M   # aggregate line coverage ≥ 85%
```

## 6. In-suite testing patterns

The `m` runner is deliberately lean — it runs suites and reports results. Setup,
teardown, isolation, mocking, fixtures, and snapshots are things the **suite**
does, by calling the helper modules directly. The patterns below are how.

### 6.1 Transactional isolation

To prove a mutation and leave nothing behind, bracket the test body in a
transaction — directly, or via `STDFIX` for a structured wrapper:

```m
tStoreWritesGlobal(pass,fail) ;@TEST "store^MYAPP writes to ^USER"
        tstart
        do store^MYAPP(42,"alice")
        do eq^STDASSERT(.pass,.fail,$get(^USER(42)),"alice","stored")
        trollback                                     ; mutation rolled back
        quit
```

`do invoke^STDFIX("<label>","<code>")` opens the `tstart`, runs the code, and
`trollback`s on the way out (pass, fail, or `$ECODE`-raised) — use it when you
want the wrapper rather than inline `tstart`/`trollback`.

### 6.2 Mocking call sites

`STDMOCK` is opt-in **at the call site**: production code dispatches through
`do invoke^STDMOCK("TARGET",.args)` (or `$$resolve^STDMOCK("TARGET")`) instead of
a bare `do TARGET`. A test then swaps the implementation and clears the registry
itself:

```m
tSendEmailUsesSmtp(pass,fail) ;@TEST "sendEmail dispatches to smtp^DELIVERY"
        do clear^STDMOCK
        do register^STDMOCK("smtp^DELIVERY","stub^MYTEST")
        do sendEmail^MYAPP("a@b","hello")
        do eq^STDASSERT(.pass,.fail,$$called^STDMOCK("smtp^DELIVERY"),1,"called once")
        do eq^STDASSERT(.pass,.fail,$$args^STDMOCK("smtp^DELIVERY",1,1),"a@b","first arg")
        do clear^STDMOCK                              ; don't leak to the next test
        quit
```

Mock state (call count, recorded args) is `$JOB`-scoped — call `clear^STDMOCK` in
your suite between tests so registrations don't leak.

### 6.3 Fixture data

Load a `STDSEED` manifest in the suite's setup (inside a transaction so it rolls
back):

```m
tLookupFindsSeeded(pass,fail) ;@TEST "seeded patient is findable"
        tstart
        do load^STDSEED("fixtures/test-patients.tsv")
        do true^STDASSERT(.pass,.fail,$$exists^DIC(2,"Smith,John"),"seeded record found")
        trollback
        quit
```

`STDSEED` reads TSV (`FILE<tab>.01=…<tab>.02=…`) or, via `loadJson`, an
STDJSON-encoded array of records with the same field shape. See
[`../modules/stdseed.md`](../modules/stdseed.md) for the manifest format.

### 6.4 Snapshot testing

For data-shape regressions (parsed trees, record exports, RPC responses):

```m
tParsedConfigShape(pass,fail) ;@TEST "config tree matches snapshot"
        new tree
        do parseFile^STDTOML("/cfg/dev.toml",.tree)
        do asserts^STDSNAP(.pass,.fail,"snapshots/dev-config.snap",.tree,"dev config")
        quit
```

The first run has no baseline, so `asserts^STDSNAP` saves one and passes;
subsequent runs compare against it. To regenerate after an intentional change,
delete the baseline file (or use the `STDSNAP` update sentinel — see
[`../modules/stdsnap.md`](../modules/stdsnap.md)) and re-run.

### 6.5 Config via `.env`

```m
tDbHostFromEnv(pass,fail) ;@TEST "DB_HOST falls back to localhost"
        new env,host
        do parseFile^STDENV(".env.test",.env)
        set host=$get(env("DB_HOST")) if host="" set host="localhost"
        do eq^STDASSERT(.pass,.fail,host,"localhost","fallback works")
        quit
```

`parseFile^STDENV` handles double-quoted (`\n \t \r \" \\`) and single-quoted
(POSIX-literal) values, `#` comments, and leading-letter-or-`_` keys.

### 6.6 Profiling

Instrument a hot path inline with `STDPROF` (microsecond resolution via
`$ZHOROLOG`):

```m
tParseStaysFast(pass,fail) ;@TEST "parse p95 under 50ms"
        new prof,i
        for i=1:1:1000 do
        . do start^STDPROF(.prof,"parse")
        . do parse^STDXML(testInput,.tree)
        . do stop^STDPROF(.prof,"parse")
        do true^STDASSERT(.pass,.fail,$$percentile^STDPROF(.prof,"parse",95)<50000,"p95 < 50ms")
        quit
```

The runner reports per-suite totals; `-o json` carries the structured result.

## 7. The release-readiness gate

Applied before any `vN.N.N` tag (and what CI runs):

| Gate | Command | Pass threshold |
|---|---|---|
| Format | `make fmt-check` | clean (no diffs) |
| Lint | `make lint` | 0 error-severity findings (style/warning advisory) |
| Tests | `make test` | 100 % assertions pass (a `0/0` silent abort is a failure) |
| Coverage | `make coverage` | aggregate line coverage ≥ 85 % (currently ~93 %) |
| Examples — drift | `make examples-check` | generated `examples/programs/*EX.m` + `index.md` match source |
| Examples — coverage | `make examples-coverage` | 100 % of public labels exampled; every `@raises` accounted |
| Examples — run | `make examples-run` | green on **both** bare engines (m-test-engine YDB + m-test-iris IRIS) |

```bash
make check M=$M     # fmt-check + lint + test (fast dev loop)
make ci    M=$M     # check + coverage + JSON result/coverage artifacts (CI-shaped)
```

## 8. Living examples — the second surface

Alongside the hand-written `tests/*TST.m` suites (which prove *correctness*), each
module ships a generated, self-verifying **example program**
(`examples/programs/<MOD>EX.m`, built from its `@example` tags) that proves every
public label is documented with a runnable example. `make examples-run` executes
them on **both** bare engines (gating); `make examples-run-live` executes them on
live `vehu` / `foia` nightly with a byte-identical residue check and writes
`examples/REPORT.md`. A per-module `@exrun` / `@exsafe` header tag declares which
engine tier runs each program and its live side-effect class. See the
[users-guide](users-guide.md) and [comprehensive-testing.md](comprehensive-testing.md).

## 9. CI

`make ci` runs the gates and writes the machine-readable artifacts:

```bash
make ci M=$M
# → test-results.json  (m test -o json)
# → coverage.lcov      (m coverage --lcov)
# → coverage.json      (m coverage -o json)
```

CI (`.github/workflows/ci.yml`) builds `m`, runs the engine-free drift gates +
`fmt` / `lint`, then the engine-bound `test` / `coverage` / `examples-run-ydb` on
the `m-test-engine` container. A fail-soft `iris-portability-check` job runs
`make examples-run-iris` on a fresh IRIS image — it surfaces IRIS regressions but
does not gate merges.

## 10. Troubleshooting

**`m test` can't reach an engine.** The `m-test-engine` container isn't running.
Bring it up: `docker run -d --name m-test-engine m-test-engine:0.3.0-local`.
The Makefile's `M_ENGINE_FLAGS` already targets it via the driver stack.

**A suite reports `0/0`.** A silent abort — treated as a failure. Usual cause: a
routine raised `$ECODE` at load or a TDD-red stub set `$ECODE` instead of
returning a safe default, so `report^STDASSERT` never ran. Fix the stub.

**A byte suite (`STDCSPRNG` / `STDB64` / `STDHEX`) fails on YDB.** The engine is in
UTF-8 mode. Pass `--chset m` (the Makefile does — don't strip it).

**`%YDB-E-QUITARGREQD` from a test using `$ETRAP`.** An `$etrap` firing inside an
extrinsic must `quit` *with an argument* — end the body with `quit -1` (or another
sentinel), or move the trap into a procedure-level frame.

**Coverage reports 0 % but tests pass.** The measured-routines / suites split
mislocated the source — pass them explicitly:
`m coverage --docker m-test-engine --chset m --routines src/ tests/ --min-percent=85`.

**State leaks between tests.** The runner does not auto-roll-back — a test that
mutates a global, a file (`STDFS`), an env var (`STDOS`), or the mock registry
must clean up itself: bracket mutations in `tstart`/`trollback` (§6.1) and call
`clear^STDMOCK` between tests (§6.2).

## 11. History & further reading

- [`comprehensive-testing.md`](comprehensive-testing.md) — run everything (both libraries, both engines, all gates).
- [`users-guide.md`](users-guide.md) — the deep reference + per-module surface.
- [`module-tracker.md`](../module-tracker.md) — shipped / in-flight / proposed modules.
- [`changelog.md`](../changelog.md) — release history.
- [`m-stdlib-implementation-plan.md`](../archive/m-stdlib-implementation-plan.md) — the per-module specs (§8) and the §9 acceptance gate this guide implements.
- [`discoveries.md`](../discoveries.md) — toolchain findings register.
