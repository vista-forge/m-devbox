---
title: Verification surfaces — tests/, examples/, and demos
status: live
created: 2026-06-28
last_modified: 2026-06-28
revisions: 0
doc_type: [GUIDE]
---

# Verification surfaces — `tests/`, `examples/`, and demos

m-stdlib verifies every `STD*` module through **three distinct surfaces**. They
look similar (all are `.m`, most assert via `^STDASSERT`) but they answer
different questions, have different authors, and must not be collapsed into one
another. This guide says **what each surface is for and where new code belongs**.
For *how to run* them, see [`comprehensive-testing.md`](comprehensive-testing.md);
for the TDD inner loop, see [`m-tdd-guide.md`](m-tdd-guide.md).

## The three surfaces at a glance

| Surface | Location | Author | Produced by | Answers |
|---|---|---|---|---|
| **Unit tests** | `tests/STD*TST.m` | hand-written | a developer, TDD-first | "What could go wrong?" — edge cases, error contracts, conformance vectors |
| **Living examples** | `examples/programs/STD*EX.m` | **generated** | `make examples` from `@example` tags | "How do I call this?" — happy-path API usage, *and* a doc-drift gate |
| **Demos** | `examples/std*-demo.m` | hand-written | a developer, by hand | "Show me a realistic end-to-end workflow" — onboarding narrative |

These are **complementary, not redundant.** The happy-path scenarios in `*EX.m`
are usually a subset of what the matching `*TST.m` already asserts, but they
exist for a different reason (see below). Do not delete one because the other
"covers it."

## 1. `tests/STD*TST.m` — the correctness specification

The wide net. One hand-written suite per module, written **before** the
implementation (TDD hard rule), asserting through `^STDASSERT`.

- **Scope:** edge cases, boundary values, error/`$ECODE` contracts, conformance
  corpora (RFC vectors, JSONTestSuite `y_`/`n_`/`i_` cases), round-trips,
  internal-state isolation, setup/teardown via fixtures.
- **Audience:** the maintainer. This is the source of truth — when an example and
  a test disagree, the **test wins** and the example is a docs bug.
- **Gate:** `make test` (core) / `make test-optional` (call-out modules) +
  `make coverage` (aggregate ≥ 85%).
- **Add code here when:** you are specifying or defending behavior — any new
  function, bug fix, or edge case starts as a failing `*TST.m`.

## 2. `examples/programs/STD*EX.m` — living, self-verifying examples

The narrow, typical-use slice — **and a drift gate on the docs.**

- **Generated, never hand-edited.** `tools/gen-examples.py` (`make examples`)
  extracts each module's `@example` tags from `src/STD*.m` and emits one
  self-asserting program per module, plus [`examples/index.md`](../../examples/index.md).
  Every file carries a `DO NOT EDIT BY HAND` header; CI's drift gate rejects
  manual edits.
- **Purpose:** prove that the usage examples shown in the documentation actually
  run and produce the stated results. If a published example rots, this suite
  goes red. That guarantee — not coverage — is the point.
- **Scope:** happy-path API usage, one example per public label, ~1–4 cases per
  module. Coverage of public labels is tracked in `examples/index.md`.
- **Run:** executed by `make examples-run` (bare, both engines) and
  `make examples-run-live` (nightly `vehu`/`foia` cadence).
- **Add code here when:** never directly. To change an example, edit the
  `@example` tag in `src/STD*.m` and run `make examples`.

## 3. `examples/std*-demo.m` — hand-written demos

The onboarding narrative. A small number of modules ship a runnable, hand-written
demo (currently `stdargs`, `stdcsv`, `stdjson`, `stdlog`).

- **Scope:** a realistic, composed workflow — e.g. `stdargs-demo.m` builds a
  small CLI with subcommands. Reads top-to-bottom as a tutorial.
- **Purpose:** teach the idiomatic pattern; show how the pieces fit. Not a gate,
  not exhaustive.
- **Add one when:** a module is common enough that a 5-minute "here's the whole
  shape" walkthrough helps a newcomer. Optional, by hand.

## Decision rule

```
Specifying / defending behavior, edge case, error path?  → tests/STD*TST.m
Documenting how to call a function (happy path)?          → @example tag in src/  (regenerates *EX.m)
Teaching an end-to-end workflow for a popular module?     → examples/std*-demo.m
```

## Why three and not one

Folding examples into tests would lose the **doc-drift guarantee** (the examples
exist precisely because they are the published docs, executed). Folding demos
into examples would lose the **narrative** (generated per-label snippets can't
tell a composed story). Folding tests into examples would lose **coverage** (the
happy path is a fraction of the contract). The minor scenario overlap between
`*EX.m` and `*TST.m` is the accepted, intentional cost of keeping each surface
honest about its own job.

## See also

- [`comprehensive-testing.md`](comprehensive-testing.md) — how to run everything
  (suites + examples + gates) across both engines and tiers.
- [`m-tdd-guide.md`](m-tdd-guide.md) — the TDD inner loop and `m test` runner.
- [`m-doc-grammar.md`](m-doc-grammar.md) — the `; doc:` / `@example` tag grammar
  that drives the generated examples.
- v-stdlib carries the identical three-surface model for its `VSL*` modules; see
  `v-stdlib/docs/guides/verification-surfaces.md`.
