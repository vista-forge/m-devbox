---
title: M-doc tag grammar (canonical — m-stdlib + v-stdlib)
status: live
audience: m-stdlib / v-stdlib maintainers writing or editing `; doc:` blocks,
  and toolchain authors implementing a consumer of stdlib metadata
created: 2026-05-08
last_modified: 2026-06-24
revisions: 4
doc_type: [SPEC]
---

# M-doc tag grammar

This document specifies the **structured-tag grammar** that extends the
`; doc:` comment convention shared by m-stdlib and v-stdlib. Tags are
optional — every prose-only `; doc:` block is valid. The grammar adds a
small, JSDoc-shaped tag vocabulary so a single source artefact (the routine
file) drives the manifest, the per-module markdown, the frontmatter, and the
AI skill.

The grammar is **engine-neutral and canonical for BOTH stdlibs** — m-stdlib
(`STD*`) and v-stdlib (`VSL*`). The two repos run byte-identical generators;
v-stdlib's copy of this spec is a pointer here. It is implemented by
**`tools/gen-manifest.py`** and consumed by four generators: the manifest
(`gen-manifest.py`), the per-module API bodies (`gen-bodies.py`), the
frontmatter (`write-module-frontmatter.py`), and the AI skill (`gen-skill.py`).
The §5 tag table is generated from the registry — the shared core
`tools/mdoc/tags.py` plus this repo's extras in `tools/mdoc_config.py` — by
`tools/gen-grammar.py` and drift-gated by `make grammar-check`.

**Eighteen tags** are recognised: nine JSDoc-shaped label tags (§5.1–5.9) plus
nine org-specific extensions — `@seam` (§5.10), the module-level `@tier`
(§5.11), the Living-Examples `@fixture` (§5.12) / `@illustrative` (§5.13) /
`@raisesnodemo` (§5.14) / the module-level `@exrun` (§5.15) / `@exsafe` (§5.16),
and the m-stdlib-only frontmatter owners `@tag` (§5.17) / `@phase` (§5.18).

## Contents

- [1. Purpose and design constraints](#1-purpose-and-design-constraints)
- [2. Relationship to the existing `; doc:` convention](#2-relationship-to-the-existing--doc-convention)
- [3. Lexical structure](#3-lexical-structure)
- [4. The synopsis line](#4-the-synopsis-line)
- [5. Tag reference](#5-tag-reference)
- [6. Worked example — `parse^STDJSON`](#6-worked-example--parsestdjson)
- [7. Parsing contract for downstream tools](#7-parsing-contract-for-downstream-tools)
- [8. Edge cases and lint rules](#8-edge-cases-and-lint-rules)
- [9. What does NOT change](#9-what-does-not-change)
- [History & further reading](#history--further-reading)

---

## 1. Purpose and design constraints

The grammar makes the public surface **machine-extractable** without
sacrificing the prose-readability the `; doc:` convention already gives. Three
constraints govern every design choice:

1. **Optional, additive.** A label with no tags is valid; lint warns at most.
   Modules adopt tags one at a time without breaking the others.
2. **Tiny vocabulary.** Sixteen tags total. Nine are JSDoc-shaped label tags
   that map 1-to-1 onto JSDoc / rustdoc / Python type-hint concepts, so AI
   assistants and human readers from those ecosystems pick the grammar up by
   reflex; seven are org-specific extensions (`@seam`, `@tier`, `@fixture`,
   `@illustrative`, `@raisesnodemo`, `@exrun`, `@exsafe`) for the MSL⟷VSL seam
   contract, the optional-module tier, and the Living-Examples sample-data /
   coverage / error-demonstration escape hatches and the executable-runner
   engine-scope + live-safety classes.
3. **Trivially parsable.** The grammar is a flat per-line lexicon — a `; doc:`
   prefix, an optional `@tag` first token, a free-form tail. ~30 lines of M (or
   one tree-sitter-m query) handle it.

The grammar deliberately does **not** specify markup inside tag bodies (no
Markdown subset, no inline links). Tag bodies are plain text.

## 2. Relationship to the existing `; doc:` convention

A prose-only `; doc:` block carries the long description:

```m
parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
        ; doc: Kills `root` first. On failure, $$lastError() holds the
        ; doc: "line:col: msg" diagnostic and the partial tree is killed.
```

The full-grammar form adds a tag block:

```m
parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
        ; doc: @param text   string  RFC-8259 JSON document
        ; doc: @param root   array   caller-owned destination (killed first)
        ; doc: @returns      bool    1 on success, 0 on failure
        ; doc: @raises       U-STDJSON-PARSE  malformed input
        ; doc: @example      do parse^STDJSON("[1,2,3]",.t) write $$type^STDJSON(.t)  ; "array"
        ; doc: @since        v0.2.0
        ; doc: @stable       stable
        ; doc: @see          valid^STDJSON, lastError^STDJSON
        ; doc: Kills `root` first. On failure, $$lastError() holds the
        ; doc: "line:col: msg" diagnostic and the partial tree is killed.
```

The header comment on the label line (`; Parse \`text\` into \`root\`.
Returns 1/0.`) is the **synopsis** (§ 4). The prose `; doc:` lines remain as
the long description. Only the tag block is new.

## 3. Lexical structure

A **doc block** is a contiguous run of lines, each matching:

```
<INDENT> ; doc: <BODY>
```

where `<INDENT>` is the routine's standard 8-space (or tab-aligned)
indent and `<BODY>` is the rest of the line after the `; doc:`
prefix and one separating space.

A doc block belongs to the **immediately preceding label line**. The
label line itself is the line beginning at column 1 (or column
non-whitespace) with the form `<name>` or `<name>(<formal-list>)`,
optionally followed by an inline comment.

Within a doc block, each line is one of:

- **A tagged line.** First non-whitespace token in `<BODY>` matches
  `@<word>`. The token is the **tag name**; the rest of `<BODY>`
  (after the tag and one separating space) is the **tag body**.
- **A continuation line.** No `@<word>` first token. The line's
  `<BODY>` is appended (with a newline) to the most recent tag
  body, or to the **free-form description** if no tag has yet
  appeared in the block.

Empty `; doc:` lines (just the prefix, no body) terminate the
current tag's continuation but do not end the doc block. Use them
sparingly — they're permitted but unidiomatic. Prefer one tag per
line and a single description paragraph.

## 4. The synopsis line

The **synopsis** is the first non-tag, non-empty unit of prose for
the label. It is one sentence that summarises the label. By
convention — and matching godoc — the synopsis goes on the **label
line itself**, as the inline comment after the formal-list:

```m
parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
```

The manifest generator extracts everything after the first `;` on
the label line (trimmed) as `synopsis`. It is consumed by:

- `m doc --short` (godoc-style one-liner).
- The hover-popup first line in the VS Code extension.
- The first column in `m search` results.

**Style.** One sentence, present-tense, ends with a period.
Backticks for code identifiers. ≤ 80 characters where possible.

If the label line has no inline comment, the **first non-tag
sentence in the doc block** is the synopsis (godoc fallback). Every
public label should carry a synopsis on its label line; the fallback
is a courtesy, not the preferred form.

## 5. Tag reference

Sixteen tags: nine JSDoc-shaped **label** tags (§5.1–5.9), plus seven
org-specific extensions — `@seam` (§5.10), the module-level `@tier` (§5.11),
the Living-Examples `@fixture` (§5.12) / `@illustrative` (§5.13) /
`@raisesnodemo` (§5.14), and the module-level `@exrun` (§5.15) / `@exsafe`
(§5.16).
Each entry below specifies syntax, multiplicity, level, and semantics.

<!-- BEGIN GENERATED TAG TABLE — managed by tools/gen-grammar.py (`make grammar`); edits between these markers are overwritten. -->

| Tag | Level | Multiplicity | Body | Manifest field | Synopsis |
|---|---|---|---|---|---|
| `@param` | label | 0..N | `NAME [TYPE] BODY` | `params` | Parameter declaration. |
| `@returns` | label | 0..1 | `[TYPE] BODY` | `returns` | Return-value declaration. |
| `@raises` | label | 0..N | `CODE [BODY]` | `raises` | Error-code declaration. |
| `@example` | label | 0..N | `BODY` | `examples` | A runnable usage example (consecutive @example lines join). |
| `@since` | label | 0..1 (1 for public) | `VERSION` | `since` | The first version this label appeared in. |
| `@stable` | label | 0..1 (1 for public) | `experimental\|stable\|deprecated` | `stable` | API-stability tier. |
| `@see` | label | 0..1 | `SYMBOL[, SYMBOL]*` | `see_also` | Cross-references to related symbols. |
| `@deprecated` | label | 0..1 | `VERSION BODY` | `deprecated` | Deprecation version + replacement (requires @stable deprecated). |
| `@internal` | label | 0..1 | `(no body)` | `(excludes the label)` | Marks a documented label as NOT part of the public surface. |
| `@seam` | label | 0..1 | `NAME [vN]` | `seams` | Marks a side-effecting seam entry point (a versioned contract). |
| `@tier` | module | 0..1 | `core\|optional` | `tier` | Classifies the whole module (routine-header tag). |
| `@exrun` | module | 0..1 | `dual\|bare\|bare-ydb\|ydb\|live` | `example_run` | Living-examples execution scope (E4) — which engine tier/arms run the module's examples/programs/<MOD>EX.m. dual (default) = both bare engines (m-test-engine YDB + m-test-iris IRIS), gating, plus the live tier; bare = both bare engines only, NOT live (a module that exercises its own shared global, e.g. the tap family writing ^VSLTAP); bare-ydb = the YDB bare engine only (IRIS-bare-incompatible and not live); ydb = YDB only (bare m-test-engine + live vehu — its IRIS-bare backend is absent, e.g. a $ZF call-out/$ZCMDLINE demo); live = live VistA only (vehu/foia), skipped on the bare engines (needs Kernel/FileMan). Absent → dual. Routine-header tag. |
| `@exsafe` | module | 0..1 | `read-only\|transactional\|illustrative-skip` | `example_safety` | Living-examples live-VistA side-effect class (E4 §8 safety model) — read-only (default; reads known data), transactional (mutates inside TSTART/TROLLBACK or self-restores the prior value), illustrative-skip (cannot be made safe on a shared live system; not run live). The live runner's pre/post residue check enforces a byte-identical engine regardless of the declared class. Routine-header tag. |
| `@fixture` | label | 0..N | `PATH [BODY]` | `fixtures` | Declares an example's sample-data fixture dependency (Living Examples). |
| `@illustrative` | label | 0..1 | `REASON` | `illustrative` | Marks a label whose example is illustrative-only — exempt from the executable-example coverage requirement; the reason is required. |
| `@raisesnodemo` | label | 0..N | `CODE REASON` | `raises_nodemo` | Marks a documented @raises CODE as not demonstrable by an executable error-example — an infrastructure/environment failure that cannot be triggered on a healthy engine (e.g. a missing call-out library, or a live-only side-effecting failure). Exempts that code from the @raises-demonstration coverage requirement; the reason is required. |
| `@tag` | module | 0..1 | `VERSION` | `tag` | The release version this module first shipped in — the owner of the per-module `tag`/`since` frontmatter fields (routine-header tag). Replaces the old hand-written docs/modules/index.md table as the input. |
| `@phase` | module | 0..1 | `BODY` | `phase` | The delivery phase/wave this module shipped in — the owner of the per-module `phase` frontmatter field (routine-header tag). The body is free text (may contain spaces), e.g. 'Phase 5 — web stack + AWS S3 egress'. |

<!-- END GENERATED TAG TABLE -->

### 5.1 `@param NAME [TYPE] BODY`

Parameter declaration.

- **Multiplicity.** Zero or more. At most one `@param` per
  `NAME`. Order should match the formal-list left-to-right.
- **Required when.** Label has a non-empty formal-list. Each name
  in the formal-list MUST appear as exactly one `@param`.
- **`NAME`.** Bare identifier. MUST match a name in the
  formal-list (`M-DOC-001` lint).
- **`TYPE`.** Free-form type label, single token. Recommended
  vocabulary: `string`, `int`, `num`, `bool`, `array`, `node`,
  `path`, `iso8601`, `horolog`, `byte-string`, `mref` (M
  reference), `cb` (callback). The grammar does not type-check —
  the label is for human / AI readers.
- **`BODY`.** One-line description. Continuation lines append.

### 5.2 `@returns [TYPE] BODY`

Return-value declaration.

- **Multiplicity.** Zero or one.
- **Required when.** Any code path in the label body does
  `quit <expression>` (returns a value). Forbidden when every
  `quit` is value-less.
- **`TYPE`.** Same vocabulary as `@param`. Use `void` if the type
  is intentionally polymorphic (rare).
- **`BODY`.** Description of the value's meaning, including the
  failure indicator if the function uses an in-band failure
  signal (e.g. `1 on success, 0 on failure`).

### 5.3 `@raises CODE [BODY]`

Error-code declaration.

- **Multiplicity.** Zero or more. One per distinct `CODE`.
- **Required when.** The label (or any helper it transitively
  calls and does not catch) sets `$ECODE` to a `,U-STDxxx-NAME,`
  value. (Not required for engine-set `$ECODE`s the label propagates
  blindly — those are not part of the documented surface.)
- **`CODE`.** The error code without the surrounding commas:
  `U-STDJSON-PARSE` not `,U-STDJSON-PARSE,`. The manifest emits
  it without commas; consumers add them when comparing against
  `$ECODE`.
- **`BODY`.** Optional one-line description of when the code is
  raised. Continuation lines append.

### 5.4 `@example BODY`

A runnable usage example.

- **Multiplicity.** Zero or more. Recommended: ≥ 1 for every
  `@stable stable` label.
- **`BODY`.** A line of M code that exercises the label.
  Continuation lines append (with newline) — multi-line examples
  are supported. The example MUST run cleanly under `m test`
  context (no global side-effects beyond `^STDLIB($job,...)`
  scratch space, no opens against arbitrary paths).
- **Two recognised shapes.** Either form is legal:

  1. **Self-asserting.** `do eq^STDASSERT(.p,.f, $$x^MOD(...),
     "expected", "doc example")` — uses STDASSERT plumbing the
     way an ordinary test does.
  2. **Annotated I/O.** A `write` statement followed by an inline
     `; "expected"` comment. The doctest generator compares
     captured output against the comment.

  The self-asserting form is preferred because it composes with
  existing test plumbing without special-case parsing.

### 5.5 `@since VERSION`

The first version this label appeared in.

- **Multiplicity.** Exactly one for every public label.
- **`VERSION`.** A SemVer string with leading `v` (`v0.2.0`).
  Must match a tag in `CHANGELOG.md`.
- **Source of truth.** Cross-checked against the `## [vX.Y.Z]`
  heading that introduced the label in `CHANGELOG.md`.

### 5.6 `@stable LEVEL`

API-stability tier.

- **Multiplicity.** Exactly one for every public label.
- **`LEVEL`.** One of:
  - `experimental` — may change without a major version bump.
    No SemVer guarantee.
  - `stable` — guarded by SemVer. Removal or breaking signature
    change requires a major bump.
  - `deprecated` — slated for removal. Use the replacement named
    in `@see`. The label MUST still work as documented until
    its removal version.
- **Default.** Absent `@stable` is treated as `experimental` by
  consumers, with a warning from the lint rule. Public labels
  SHOULD be tagged explicitly.

The tier is informational — there is no CI gate enforcing SemVer
against the tier. Annotating now lets a future gate switch on
without backfill.

### 5.7 `@see SYMBOL[, SYMBOL]*`

Cross-references to related symbols.

- **Multiplicity.** Zero or one. Multiple references are
  comma-separated.
- **`SYMBOL`.** M call-site form: `label^MODULE`,
  `$$label^MODULE`, `^MODULE` (whole-routine ref), or a free-text
  external reference (e.g. `RFC 8259 §6`).
- **Use.** Renders as a "See also" line in `m doc`, hover, and
  the per-module markdown.

### 5.8 `@deprecated VERSION BODY`

Required iff `@stable deprecated`. Identifies the version the
deprecation took effect and gives the replacement plan.

- **Multiplicity.** Zero or one. Forbidden unless `@stable
  deprecated` is also set.
- **`VERSION`.** Version (`vX.Y.Z`) where the deprecation began.
- **`BODY`.** One sentence explaining the replacement; usually
  paired with `@see` pointing at it.

### 5.9 `@internal`

Marks a labeled-and-documented routine point as not part of the
public surface.

- **Multiplicity.** Zero or one. Boolean — body is ignored.
- **Use.** A label that has a `; doc:` block (because the prose
  is useful to maintainers) but should not appear in the
  manifest, in `m doc`, in hover, or in the AI skill. Examples in
  current src/: `parseFail^STDJSON`, `parseFileEof^STDJSON`,
  `encodeFail^STDJSON` — labels reached only via ZGOTO traps
  whose `; doc:` blocks explain the unwind contract.
- **Caution.** Labels with NO `; doc:` block are already invisible
  to the manifest generator. `@internal` is only needed when a
  label has documentation but is not for external use.

### 5.10 `@seam NAME [vN]`

Marks a label as a side-effecting **seam** entry point — part of a
versioned cross-repo contract (the MSL⟷VSL coordination seam model;
coordination plan § 5.2). An org-specific extension, not a JSDoc concept.

- **Multiplicity.** Zero or one per label. **Level.** Label-level.
- **`NAME`.** The seam-contract identifier the label belongs to — a bare
  identifier (`[A-Za-z][A-Za-z0-9]*`), conventionally the module/contract
  name (e.g. `STDENV`, `STDFS`).
- **`vN`.** Optional contract version (`v2`); default `1`. It bumps only
  when the seam's signature changes incompatibly.
- **Manifest.** Each `@seam` label gets a `seam: {name, contract_version}`
  field; all of them aggregate into the manifest's top-level **`seams`**
  block (entry points grouped by contract + version). The `seam-snapshot`
  drift gate (`make check-seams`, the "bump-forcer") red-gates an
  incompatible change that did not bump the version.

Example: `; doc: @seam STDENV v2`.

### 5.11 `@tier core|optional`  (module-level)

Classifies the **whole module**, not a label. Unlike every other tag, it
lives in the **routine-header `; doc:` block** (the prose block before the
first label), not in a label's doc block. An org-specific extension.

- **Multiplicity.** Zero or one per module (in the header).
- **Level.** Module-level (header block → `module.tier`).
- **`core`** — the default when the tag is absent: pure-M (or
  already-wired), part of the dependency-free core and the default
  `make test`.
- **`optional`** — the module needs a compiled `$&` / `$ZF` call-out
  library to function, so it is excluded from the core suite and the
  default `make test` (e.g. `STDCRYPTO`, `STDCOMPRESS`, `STDHTTP`).
- **Manifest.** Sets the module entry's `"tier"` field
  (`"core"` | `"optional"`).

Example (in the routine header): `; doc: @tier optional`.

### 5.12 `@fixture PATH [BODY]`

Declares an example's **sample-data fixture** dependency — a real input (and
optional expected-output golden) the example reads, for the Living Executable
Examples system (docs `proposals/living-executable-examples.md`). An
org-specific extension.

- **Multiplicity.** Zero or more per label. **Level.** Label-level.
- **`PATH`.** A repo-relative path under `examples/data/<module>/…` (or a reused
  conformance corpus under `tests/conformance/…`).
- **`BODY`.** Optional one-line description of what the fixture is.
- **Manifest.** Collected into the label's `fixtures` array. The coverage gate
  forbids a `@fixture` whose file is missing, and (eventually) an `examples/data`
  file no example references.

Example: `; doc: @fixture examples/data/stdcsv/people.csv  RFC-4180 input rows`.

### 5.13 `@illustrative REASON`

Marks a label whose example **cannot be executed automatically** (it needs a live
external sink, a multi-step live setup, etc.) and is therefore **exempt from the
executable-example coverage requirement**. The escape hatch that keeps
"comprehensive" honest rather than faked. An org-specific extension.

- **Multiplicity.** Zero or one per label. **Level.** Label-level.
- **`REASON`.** Required — a one-line explanation of why the label's example is
  illustrative-only. The coverage report lists every exemption.
- **Manifest.** Sets the label's `illustrative` reason string. A label is
  "covered" by the comprehensiveness gate iff it has an executable `@example`
  **or** an `@illustrative` reason.

Example: `; doc: @illustrative needs a configured live S3 sink to run`.

### 5.14 `@raisesnodemo CODE REASON`

Marks a documented `@raises CODE` as **not demonstrable by an executable
error-example** — an infrastructure/environment failure that cannot be triggered
on a healthy engine (a missing call-out library, a live-only side-effecting
queue failure, etc.). The raise-level analogue of `@illustrative`: it keeps the
`@raises`-demonstration accounting **honest** — every documented code is either
demonstrated or explicitly exempted with a reason, never a silent gap. An
org-specific extension.

- **Multiplicity.** Zero or more per label (one per exempted code). **Level.**
  Label-level.
- **`CODE`.** Required — must match a `@raises` code declared on the same label.
- **`REASON`.** Required — a one-line explanation of why the code cannot be
  triggered. The coverage report lists every exemption.
- **Manifest.** Collected into the label's `raises_nodemo` array. A `@raises`
  code is "accounted" by the comprehensiveness gate iff it is demonstrated by a
  `raises^STDASSERT` example **or** carries a `@raisesnodemo` exemption.

Example: `; doc: @raisesnodemo U-STDCRYPTO-CALLOUT-MISSING  cannot fire when the callout is loaded`.

### 5.15 `@exrun dual|bare|bare-ydb|ydb|live`  (module-level)

Classifies, for the **Living Executable Examples runner** (E4 of the
`proposals/living-executable-examples.md` roadmap), **which engine tier/arms run
the module's `examples/programs/<MODULE>EX.m`**. Like `@tier`, it lives in the
**routine-header `; doc:` block**, not a label's doc block. An org-specific
extension.

- **Multiplicity.** Zero or one per module (in the header). **Level.**
  Module-level (header block → `module.example_run`).
- **`dual`** — the default when the tag is absent: the program runs on **both
  bare engines** (the `m-test-engine` YDB container *and* the `m-test-iris` IRIS
  container) as the gating bare tier, **and** on the live tier.
- **`bare`** — both bare engines only; **not** the live tier. A module whose
  examples exercise its own shared global (e.g. the tap family writing
  `^VSLTAP`), which is fine on a dedicated bare engine but would pollute a shared
  live VistA.
- **`bare-ydb`** — the YDB bare engine only (IRIS-bare-incompatible *and* not
  live; e.g. `VSLRPCWRAP`, whose transactional tap-capture examples diverge in
  the IRIS example harness — IRIS capability is proven separately by its `*TST`
  suite).
- **`ydb`** — YDB only: runs on the bare `m-test-engine` **and** live `vehu`, but
  **not** the IRIS bare engine — a YDB-only call-out backend or runtime demo the
  IRIS test engine cannot execute (e.g. `STDCOMPRESS`/`STDCSPRNG` whose `$&`/`$ZF`
  backends are absent on `m-test-iris`, or `STDHARN`'s `$ZCMDLINE`/`^%MONLBL`
  shell-entry demos). The IRIS bare arm records it as skipped.
- **`live`** — live VistA only: the example needs Kernel/FileMan/KIDS/… and
  reports `0/0` on a bare engine, so it is **skipped on both bare engines** and
  run only on the live tier (`vehu` + `foia`). The VistA-binding `VSL*` modules.
- **Manifest.** Sets the module entry's `"example_run"` field.

Example (in the routine header): `; doc: @exrun bare`.

### 5.16 `@exsafe read-only|transactional|illustrative-skip`  (module-level)

Declares the module's example program's **live-VistA side-effect class** for the
E4 safety model (proposal §8) — the contract that a shared live VistA comes back
**byte-identical** after a run. Module-level header tag, like `@tier`/`@exrun`.
An org-specific extension.

- **Multiplicity.** Zero or one per module (in the header). **Level.**
  Module-level (header block → `module.example_safety`).
- **`read-only`** — the default: the examples only read known data; safe to run
  freely on a shared live engine.
- **`transactional`** — the examples mutate, but inside `TSTART`/`TROLLBACK` or
  by self-restoring the prior value, so no net state change survives.
- **`illustrative-skip`** — the examples cannot be made safe/automatic on a
  shared live system; not run on the live tier (only bare / read-only arms),
  listed in the run report.
- **Manifest.** Sets the module entry's `"example_safety"` field. Independent of
  the declared class, the live runner's **pre/post residue check** empirically
  re-asserts byte-identical engine state and reds the report if state leaked.

Example (in the routine header): `; doc: @exsafe transactional`.

### 5.17 `@tag VERSION`  (module-level)

Records the **release the module first shipped in** — the single owner of the
module's `tag` / `since` frontmatter fields. Like `@tier`/`@exrun`/`@exsafe` it
lives in the **routine-header `; doc:` block**, not a label's doc block. An
org-specific extension.

- **Multiplicity.** Zero or one per module (in the header). **Level.**
  Module-level (header block → `module.tag`).
- **`VERSION`.** A single token, the `vX.Y.Z` tag of the module's first release.
- **Manifest.** Sets the module entry's `"tag"` field; `write-module-frontmatter.py`
  derives the per-module `tag`/`since` frontmatter **and** the
  `docs/modules/index.md` module-catalogue table from it. This replaced the old
  hand-written index table as the input (stdlib-doc-accuracy F8 / RC-5): a module
  can no longer be silently omitted from the catalogue.

Example (in the routine header): `; doc: @tag v0.2.0`.

### 5.18 `@phase BODY`  (module-level)

Records the **delivery phase/wave** the module shipped in — the single owner of
the module's `phase` frontmatter field. Module-level header tag, like `@tag`. An
org-specific extension.

- **Multiplicity.** Zero or one per module (in the header). **Level.**
  Module-level (header block → `module.phase`).
- **`BODY`.** Free text (may contain spaces), e.g. `Phase 5 — web stack + AWS S3
  egress`.
- **Manifest.** Sets the module entry's `"phase"` field, surfaced in the
  per-module frontmatter and the `docs/modules/index.md` catalogue's **Phase**
  column.

Example (in the routine header): `; doc: @phase Phase 2`.

### Tags outside this grammar (registry tags)

`; doc:` blocks (especially in v-stdlib) may also carry **registry tags** —
`@icr`, `@call`, `@status`, `@custodian`, `@source` — e.g.
`; doc: @icr 2263 @call $$GET^XPAR @status Supported @custodian XU @source …`.
These are **not part of the doc-manifest grammar** and are *ignored* by
`gen-manifest.py` (treated as unknown tags, dropped). They are consumed by
separate registry generators — `tools/gen-icr.py` (the DBIA/ICR registry,
`make check-icr`) and `tools/check_citations.py` (doc-citation provenance vs
the gold corpus, `make check-citations`) — each with its own contract. Listed
here only so a reader who sees them in source knows where they belong.

## 6. Worked example — `parse^STDJSON`

The full-grammar form of the `parse` label in `src/STDJSON.m`:

```m
parse(text,root)        ; Parse `text` into `root`. Returns 1/0.
        ; doc: @param text   string  RFC-8259 JSON document text
        ; doc: @param root   array   caller-owned destination subtree;
        ; doc:   killed before population so callers may pass a partially
        ; doc:   populated array safely
        ; doc: @returns      bool    1 on success, 0 on failure (caller
        ; doc:   inspects $$lastError^STDJSON for the diagnostic)
        ; doc: @raises       U-STDJSON-PARSE  set on malformed input;
        ; doc:   the partial tree is killed before this raises
        ; doc: @example      new t,p,f
        ; doc: @example      do start^STDASSERT(.p,.f)
        ; doc: @example      do eq^STDASSERT(.p,.f,$$parse^STDJSON("[1,2,3]",.t),1,"valid array parses")
        ; doc: @example      do eq^STDASSERT(.p,.f,$$type^STDJSON(.t),"array","root is array")
        ; doc: @since        v0.2.0
        ; doc: @stable       stable
        ; doc: @see          $$valid^STDJSON, $$lastError^STDJSON, $$encode^STDJSON
        ; doc: Kills `root` first. On failure, $$lastError() holds the
        ; doc: "line:col: msg" diagnostic and the partial tree is killed.
        ; doc: Internal recursion can fire $ETRAP at arbitrary extrinsic
        ; doc: depth; ZGOTO N:label unwinds the M-stack to parse()'s own
        ; doc: level before the GOTO so parseFail's `quit 0` always
        ; doc: executes in extrinsic context (avoids M17 NOTEXTRINSIC).
```

Reading the example:

- The synopsis is `Parse \`text\` into \`root\`. Returns 1/0.` — the
  inline comment on the label line.
- The tag block records `@param` for each formal-list entry (`text`
  and `root`), `@returns`, `@raises`, four `@example` lines forming
  one self-asserting STDASSERT snippet, `@since`, `@stable`, and a
  `@see` pointing at related labels.
- The prose paragraph (the ZGOTO unwind explanation) is the
  **free-form description** at the end of the doc block. Tags can
  precede or follow the prose; ordering is a style choice
  (recommended: tags first, prose second, since tags are scanned by
  tools and prose is read by humans).

The manifest entry derived from the above:

```json
"parse": {
  "form": "extrinsic",
  "signature": "$$parse^STDJSON(text, .root)",
  "synopsis": "Parse `text` into `root`. Returns 1/0.",
  "params": [
    {"name": "text", "type": "string", "doc": "RFC-8259 JSON document text"},
    {"name": "root", "type": "array",  "doc": "caller-owned destination subtree; killed before population so callers may pass a partially populated array safely"}
  ],
  "returns": {"type": "bool", "doc": "1 on success, 0 on failure (caller inspects $$lastError^STDJSON for the diagnostic)"},
  "raises": [{"code": "U-STDJSON-PARSE", "doc": "set on malformed input; the partial tree is killed before this raises"}],
  "examples": [
    "new t,p,f\ndo start^STDASSERT(.p,.f)\ndo eq^STDASSERT(.p,.f,$$parse^STDJSON(\"[1,2,3]\",.t),1,\"valid array parses\")\ndo eq^STDASSERT(.p,.f,$$type^STDJSON(.t),\"array\",\"root is array\")"
  ],
  "since": "v0.2.0",
  "stable": "stable",
  "see_also": ["$$valid^STDJSON", "$$lastError^STDJSON", "$$encode^STDJSON"],
  "description": "Kills `root` first. On failure, $$lastError() holds the \"line:col: msg\" diagnostic and the partial tree is killed. Internal recursion can fire $ETRAP at arbitrary extrinsic depth; ZGOTO N:label unwinds the M-stack to parse()'s own level before the GOTO so parseFail's `quit 0` always executes in extrinsic context (avoids M17 NOTEXTRINSIC).",
  "source": {"file": "src/STDJSON.m", "line": 39}
}
```

The four `@example` lines collapse into one multi-line example
because they are consecutive `@example` tags forming one
self-contained snippet. Two distinct examples would be expressed
as two `@example` blocks separated by another tag (or by an empty
`; doc:` line).

## 7. Parsing contract for downstream tools

The consumers in the m-stdlib and m-cli toolchain agree on the parsing rules
below.

### 7.1 `tools/gen-manifest.py` (the manifest generator)

A **Python hand-rolled parser**. Each stdlib carries a byte-identical sibling
copy; the only difference is the source glob and the output name: **m-stdlib
reads `src/STD*.m` → `dist/stdlib-manifest.json`**, **v-stdlib reads
`src/VSL*.m` → `dist/vsl-manifest.json`**.

- Reads the module's `.m` files. For each routine: emit a module entry
  (with `tier` from a header `@tier` tag, default `core`).
- For each label that has a non-empty `; doc:` block: emit a label
  entry, **unless** the block contains `@internal`.
- The label's `synopsis` is the inline comment on the label line
  (preferred) or the first prose sentence in the doc block
  (fallback).
- Tags are extracted into the schema fields shown in § 6.
- `@example` lines that are consecutive collapse into one example
  body (newline-joined). A non-`@example` tag (or an empty
  `; doc:` line) terminates the current example.
- The label's `signature` is reconstructed from the formal-list:
  `$$<name>^<MODULE>(<params>)` for extrinsics, `do
  <name>^<MODULE>(<params>)` for procedures. The form is
  determined by static analysis of the label body (`quit
  <expression>` anywhere → extrinsic).
- `source.file` is the routine path; `source.line` is the
  label-line number (1-indexed).
- **Extension tags:** `@seam NAME [vN]` labels aggregate into the
  manifest's top-level **`seams`** block (§5.10); a header `@tier` sets
  the module **`tier`** (§5.11). Unknown `@tags` are dropped silently.

### 7.2 `M-DOC-001` lint rule

Severity: **warn**. Promote to error once source is clean across a release
cycle.

The rule fires on a public label (one that has any `; doc:` content
and is not `@internal`) when ANY of the following hold:

- A name in the formal-list has no `@param`.
- A `@param` has a name not in the formal-list.
- The label body contains `quit <expression>` and there is no
  `@returns`.
- The label body contains a `set $ecode=",U-STDxxx-...,"` line and
  the corresponding `@raises U-STDxxx-...` is missing.
- `@stable` is missing.
- `@since` is missing.
- `@stable deprecated` is set without an accompanying
  `@deprecated` tag.

The rule does NOT fire on:

- Internal labels (no `; doc:` block, or `@internal` set).
- Routines whose entire file is opted out via
  `; m-lint: disable-file=M-DOC-001` (escape hatch for legacy
  routines).

### 7.3 `m doc`, VS Code, and the AI skill

These consumers read the **manifest**, not the source. They never
re-parse `; doc:` blocks. Any new tag added to this grammar is
reflected in the manifest schema first, then the consumers pick it
up automatically.

## 8. Edge cases and lint rules

| Situation | Behaviour |
|---|---|
| Tag name unknown (e.g. `@todo`) | Manifest generator: ignore (drop with no warning). Lint rule: warn `M-DOC-002` — keeps the grammar closed. |
| `@param` for a name not in the formal-list | `M-DOC-001` warn. Manifest: drop the entry. |
| Two `@param` with the same name | `M-DOC-001` warn (treat as ambiguous). Manifest: keep the first; drop the rest. |
| `@returns` on a label whose every `quit` is value-less | `M-DOC-001` warn. Manifest: keep (consumers may render it as `void` advice). |
| `@raises` for a code the label can't raise | `M-DOC-001` warn (over-claim). Manifest: keep the entry. |
| Missing `@example` on a `@stable stable` label | `M-DOC-001` warn (best-practice nudge). |
| `@stable experimental` with `@example` | Allowed. Examples for experimental labels are still useful. |
| `@deprecated` without `@stable deprecated` | `M-DOC-001` warn. Manifest: still emits both. |
| `@internal` plus other tags | The other tags are dropped from the manifest (the label is excluded entirely). Tags remain in the source for maintainer reading. |
| Doc block before any label (i.e. routine-level prose) | Belongs to the **routine**, not a label. Manifest emits as `module.description`. |

## 9. What does NOT change

The grammar is purely additive to comment content. The following remain
exactly as they are in the codebase:

- The **routine-header block** at the top of every `STDxxx.m`
  file (the `Public API` summary, storage convention,
  error-codes list). It is read by humans glancing at the source
  and by the manifest generator as the module-level description.
- The **`; doc:` prefix** (lower-case, single space after the
  colon, indented to the routine's standard column).
- The **inline-synopsis convention** on the label line.
- The **`,U-<LIB>xxx-NAME,` error namespace** (`U-STD…` in m-stdlib,
  `U-VSL…` in v-stdlib).
- The **`STD*` / `VSL*` routine-prefix families** (the grammar is
  engine-neutral and shared by both stdlibs).
- The **TDD discipline**, the per-module acceptance gate, and
  every existing lint rule.

The grammar does not require a single `set`, `quit`, or label rename
anywhere in the codebase.

## History & further reading

- [Discoverability & tooling plan, § 3.1](../archive/discoverability-and-tooling-plan.md#31-formalise-an-m-doc-grammar-extends-does-not-replace--doc) — the design rationale this guide implements.
- [Discoverability tracker](../archive/discoverability-tracker.md#wa1--specify-m-doc-tag-grammar) — Wave A–D work items behind the grammar, the source-tag backfill, the `M-DOC-001` lint rule, and the manifest generator.
- [Grammar spec-from-code gate plan](../archive/grammar-spec-from-code-gate-plan.md) — the design of the `tools/gen-grammar.py` drift gate that generates §5's tag table from the tag registry (then `tools/mdoc_tags.py`; since the stdlib-doc-accuracy Phase 7 de-fork, the shared `tools/mdoc/tags.py` + `tools/mdoc_config.py` extras).
- [`docs/guides/comprehensive-testing.md`](comprehensive-testing.md) — the Living Executable Examples runner (E1–E5) that `@fixture` / `@illustrative` / `@raisesnodemo` / `@exrun` / `@exsafe` feed.
- [Routine-name length policy ADR](../module-tracker.md) — relaxed the historical `STD*` ≤8-character routine-prefix cap to 31 characters; the grammar governs `VSL*` alongside `STD*`.
- [STDJSON source — `parse` label](../../src/STDJSON.m) — the source of the §6 worked example.
- [JSDoc reference](https://jsdoc.app/) — the closest existing-ecosystem analogue; tag names match where they overlap.
- [godoc commentary reference](https://go.dev/doc/comment) — the synopsis-line convention (§ 4) follows godoc.
- [rustdoc book](https://doc.rust-lang.org/rustdoc/) — the per-tag stability tier (`@stable`) borrows the `#[stable]` / `#[unstable]` distinction.
