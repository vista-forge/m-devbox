---
title: Comprehensive testing & quality — m-stdlib + v-stdlib on YDB + IRIS
status: live
created: 2026-06-24
last_modified: 2026-06-25
revisions: 4
doc_type: [GUIDE]
---

# Comprehensive testing & quality — m-stdlib + v-stdlib on both engines

The one-stop guide to running **everything**: the full test suites, the living
**executable examples**, and the quality / maintenance drift-gates — for both
libraries (`m-stdlib` `STD*` and its VistA-specific sibling `v-stdlib` `VSL*`)
across **both M engines** (YottaDB and InterSystems IRIS), at both the **bare**
and **live-VistA** tiers.

For a fast lap see [`quick-start.md`](quick-start.md); for the TDD inner loop see
[`m-tdd-guide.md`](m-tdd-guide.md); for the deep reference see
[`users-guide.md`](users-guide.md).

---

## Contents

- **[Run the nightly job on demand (one command)](#run-the-nightly-job-on-demand-one-command)**
- [0. Ground rules (read first)](#0-ground-rules-read-first)
- [1. The whole thing, in order](#1-the-whole-thing-in-order)
- [2. Executable examples — the comprehensiveness story](#2-executable-examples--the-comprehensiveness-story)
- [3. Test suites — what each target covers](#3-test-suites--what-each-target-covers)
- [4. Quality & maintenance gates](#4-quality--maintenance-gates)
- [5. The live-VistA tier (nightly cadence)](#5-the-live-vista-tier-nightly-cadence)
- [6. CI mapping](#6-ci-mapping)
- [7. Troubleshooting](#7-troubleshooting)
- [8. See also](#8-see-also)

### Run the nightly job on demand (one command)

The nightly live-VistA cadence (§5) has a canonical driver script —
**`~/scripts/bin/examples-live-cron.sh`**. Run it to do the whole thing on
demand: both libraries (`m-stdlib` + `v-stdlib`) on both live engines
(`vehu` + `foia`) through the driver stack, plus the §8 residue check:

```bash
~/scripts/bin/examples-live-cron.sh
```

This is the **same** body system cron runs nightly (`30 6 * * *`), and the
`examples-live.yml` GitHub workflow defers to it because the live engines are
local (a self-hosted runner would be needed otherwise). On top of the bare
`make examples-run-live` it also:

- sets `$M` internally (`$HOME/vista-forge/m-cli/dist/m`) — no `export`
  needed, so it's genuinely one command;
- `git pull --ff-only`s each repo, then **commits + pushes** the refreshed
  `examples/REPORT.md`;
- is **fail-soft** — a red run reds REPORT.md but the script still exits 0 (the
  bare tier in CI is the hard gate);
- logs to `~/data/living-examples/cron.log`;
- pushes headlessly via a PAT in `~/.config/examples-live.env` (`GH_TOKEN=…`,
  `chmod 600`) since cron has no keyring — without it, it commits locally and
  logs the push failure.

**No side effects (no pull/commit/push)?** Run the two `make` targets directly
instead — set `$M` inline so it works copy-pasted without exporting first
(build the `m` binary once per §0):

```bash
M=$HOME/vista-forge/m-cli/dist/m; \
( cd ~/vista-forge/m-stdlib && make examples-run-live M=$M ) && \
( cd ~/vista-forge/v-stdlib && make examples-run-live M=$M )
```

> Forgetting the `M=…` (or an unset `$M`) is the usual cause of
> `run-examples.py: error: argument --m: expected one argument` — an empty `$M`
> passes a bare `--m` to the script.

This is exactly what the scheduled nightly job runs (see [§5](#5-the-live-vista-tier-nightly-cadence)
and the `nightly` entry in [§6 CI mapping](#6-ci-mapping)); it's fail-soft and
needs `vehu`/`foia` reachable.

---

## 0. Ground rules (read first)

**Engine access is through the driver stack ONLY.** Every command below reaches
a live engine via the `m` toolchain (`m test --docker …`, `m coverage …`,
`m vista exec …`) which routes through `m-driver-sdk → m-ydb / m-iris`. **Never**
hand-roll `docker exec <engine> … mumps`, `iris session`, or `mumps -direct` —
that is a red gate, blocked by the `engine-stack-guard.sh` PreToolUse hook and by
CI. (See the org `CLAUDE.md` § "Engine access through the driver stack" and the
[[engine-access-through-driver-stack]] memory.)

**The two tiers and the four engines:**

| Tier | YDB engine | IRIS engine | VistA present? | What runs here |
|---|---|---|---|---|
| **bare** | `m-test-engine` (Docker) | `m-test-iris` (Docker) | no | `STD*` core; `VSL*` engine-neutral tier (tap / S3 / auth) |
| **live** | `vehu` (YDB-VistA) | `foia*` (IRIS-VistA) | yes | the VistA-binding `VSL*` modules + the §8 residue check |

**Byte mode.** m-stdlib is byte-oriented; the YDB arm always runs `ydb_chset=M`
(the Makefiles pass `--chset m`). Don't drop it on the YDB engine.

**The `M` binary.** Every target takes `M=<path to the m binary>`. Build it once
from m-cli:

```bash
git clone https://github.com/vista-forge/m-cli ~/vista-forge/m-cli
( cd ~/vista-forge/m-cli && go build -o dist/m . )
export M=$HOME/vista-forge/m-cli/dist/m     # used below as $M
```

`m-stdlib`'s Makefile defaults `M=m` (on `$PATH`); `v-stdlib`'s defaults to
`$HOME/vista-forge/m-cli/dist/m`. Pass `M=$M` explicitly to be unambiguous.

**Bring the bare engines up** (once per machine; live `vehu`/`foia` are managed
separately):

```bash
docker run -d --name m-test-engine m-test-engine:0.3.0-local
docker run -d --name m-test-iris   m-test-iris-gold:local                  # IRIS CE, port 52774
```

---

## 1. The whole thing, in order

Run this from each repo root. It is the maximal sequence — engine-free gates
first (fail fast, no container needed), then the engine-bound suites on both
engines, then the executable examples on both engines, then coverage. The live
tier is the nightly cadence (§5), kept separate because it needs `vehu`/`foia`.

> **One command for the whole bare sweep (both repos, both engines).** This entire
> §1 sequence is mechanized as **`m-stdlib/scripts/comprehensive-test.sh`** — it
> runs every step below for `m-stdlib` *and* `v-stdlib` on both bare engines, then
> prints a PASS/FAIL summary and exits non-zero if anything failed (it does *not*
> stop at the first failure). Run `scripts/comprehensive-test.sh` (sets `$M`
> internally; `--skip-optional` to drop the callout-prereq steps — this covers
> BOTH engines' optional runs: the sweep runs `make test-optional` (YDB) and
> `make test-optional-iris` (IRIS, explicit suite list with a printed tracked
> skip for STDCOMPRESSTST — m-test-iris embedded Python is non-functional).
> There is NO S3 step: the prior `test-s3-matrix` gate was removed from
> v-stdlib with the old tap subsystem, and the sweep prints that absence
> explicitly instead of skipping it silently (sweep-truth 2026-07-16).
> The hand sequence below is the reference it mechanizes.

### m-stdlib

```bash
cd ~/vista-forge/m-stdlib

# (a) engine-free: fmt + lint + every drift gate (no container needed)
make check-manifest skill-check docs-check frontmatter-check grammar-check \
     check-seams check-icr check-citations check-namespaces check-kids \
     check-docs-prose examples-check M=$M
make fmt-check lint M=$M

# (b) engine-bound suites — BOTH bare engines
make test M=$M M_ENGINE_FLAGS='--engine ydb  --docker m-test-engine --chset m'
make test M=$M M_ENGINE_FLAGS='--engine iris --docker m-test-iris'
make test-optional M=$M                      # callout tier: STDCRYPTO/STDCOMPRESS/STDHTTP (needs .so libs)

# (c) executable examples — BOTH bare engines, asserts every suite green
make examples-run M=$M                        # = examples-run-ydb + examples-run-iris

# (d) aggregate coverage (≥85% gate)
make coverage M=$M
```

### v-stdlib

```bash
cd ~/vista-forge/v-stdlib

# (a) the full engine-free gate aggregate (fmt + lint + arch + all drift gates)
make check-fast M=$M                           # fmt-check lint arch gates  (no engine)

# (b) engine-bound: the bare-green suite set on BOTH bare engines
make test-bare M=$M ENGINE=ydb  DOCKER=m-test-engine CHSET=m
make test-bare M=$M ENGINE=iris DOCKER=m-test-iris

# (c) executable examples — BOTH bare engines (stages $(MSTDLIB)/src automatically)
make examples-run M=$M

# (d) coverage — BARE tier: measures the bare-runnable VSL* routines only
#     (excludes the @exrun-live VistA-binding ones), gated ≥80%; stages STD* from m-stdlib
make coverage M=$M ENGINE=ydb  DOCKER=m-test-engine CHSET=m
make coverage M=$M ENGINE=iris DOCKER=m-test-iris

# (e) S3 integration: NO live gate exists today — the prior test-s3-matrix
#     target + MinIO testbed were removed from v-stdlib with the old tap
#     subsystem (the greenfield v-rpc-tap brings its own validation when it
#     lands). Absence is stated here so nobody hunts for a missing target.
```

> **`make check` vs `make check-fast` (v-stdlib).** `check = fmt-check lint arch
> gates test` — the `test` at the end is engine-bound, so `make check` needs an
> engine (`ENGINE=`/`DOCKER=`). `check-fast` stops after the engine-free gates —
> use it as the fast pre-commit lap, then run the engine suites explicitly on each
> engine as above.

---

## 2. Executable examples — the comprehensiveness story

The "examples" are not prose — they are generated, self-verifying M programs
(`examples/programs/<MOD>EX.m`), one per public label, emitted from the
`@example` / `@illustrative` / `@raises` / `@fixture` doc-tags. They are the
**living, executed** proof that every documented surface actually runs. Same
target names in both repos:

| Target | What it does | Gating? |
|---|---|---|
| `make examples` | (re)generate `programs/<MOD>EX.m` + `examples/index.md` | — |
| `make examples-check` | drift gate: generated examples match source tags | **red gate** (CI) |
| `make examples-coverage` | comprehensiveness report: `(executable @example∨@illustrative)/total`, every `@raises` has an error-example, every `@fixture` present | advisory (exit 0) until E3 backfill hits 100%, then `--strict` |
| `make examples-run` | **execute** the programs through the driver stack on **both bare engines**, assert every suite green (`total>0, failed==0`; a `0/0` silent abort is a failure) | **gating** — dev loop + local PR gate |
| `make examples-run-ydb` | bare **YDB** arm only | CI hard gate |
| `make examples-run-iris` | bare **IRIS** arm only | CI fail-soft job |
| `make examples-run-live` | **live** tier (`vehu` + `foia`), runs the §8 residue check, writes `examples/REPORT.md` | nightly cadence (fail-soft) |

What runs on which tier:

- **m-stdlib** `STD*` examples are engine-neutral → run on both bare engines and
  again live.
- **v-stdlib** `VSL*` splits at the waterline: the engine-neutral modules (tap /
  S3 / auth) run on the bare engines; the **VistA-binding** modules
  (`VSLCFG` / `VSLBLD` / `VSLFS` / `VSLIO` / `VSLLOG` / `VSLTASK` / `VSLENV`) are
  tagged `@exrun live` and only execute on the **live** tier — they are *skipped*
  on bare. So a clean bare run does **not** mean those modules ran; only
  `examples-run-live` exercises them.

The last live run is committed at [`../../examples/REPORT.md`](../../examples/REPORT.md)
(m-stdlib) and `v-stdlib/examples/REPORT.md` — the snapshot showing them passing
on real `vehu`/`foia` with the byte-identical residue check.

---

## 3. Test suites — what each target covers

### m-stdlib

| Target | Scope |
|---|---|
| `make test` | dependency-free **core** suites via `$(M_ENGINE_FLAGS)` (default YDB byte mode) |
| `make test-optional` | callout tier — `STDCRYPTO` / `STDCOMPRESS` / `STDHTTP` (needs the compiled `.so` libs) |
| `make test-s3` | `STDS3` round-trip against a live S3-equivalent (MinIO) — needs engine HTTP egress |
| `make coverage` | aggregate line coverage, gated **≥85%** (`--lcov coverage.lcov`); optional modules excluded from the measured set |
| `make check` | `fmt-check + lint + test` (fast dev loop) |
| `make ci` | `check + coverage + ci-json` (CI-shaped) |

### v-stdlib

| Target | Scope |
|---|---|
| `make test` | full `VSL*` suite (stages `$(MSTDLIB)/src` so `^STDASSERT` resolves) |
| `make test-bare` | the **bare-engine-green** set (`$(BARE_TESTS)` — tap + S3 + auth); green on a plain engine with **no VistA**. This is what `make ci` runs per engine |
| ~~`make test-s3`~~ / ~~`make test-s3-matrix`~~ | **REMOVED** from v-stdlib with the old tap subsystem (kept in git history) — no live S3 gate exists today; the greenfield v-rpc-tap effort brings its own validation |
| `make coverage` | **bare-tier** line coverage, gated **≥80%** (stages `$(MSTDLIB)/src`). Measures `$(BARE_SRC)` — every `src/*.m` minus the `@exrun live` VistA-binding routines (`VSLBLD`/`VSLCFG`/`VSLENV`/`VSLFS`/`VSLIO`/`VSLLOG`/`VSLTASK`), which report 0 on a bare engine — running only `$(BARE_TESTS)`. Documented bare exception (the analogue of m-stdlib excluding optional callout modules); the excluded routines + VSLTAPRUN's `$text`/XPAR-guarded branches are covered on the live tier. **Not** run by `make ci` |

> **S3 harness (historical).** The v-stdlib `test-s3`/`test-s3-matrix` harness and
> its MinIO testbed were removed with the old tap subsystem. m-stdlib's own
> `STDS3MINIOTST` integration tier (`make test-s3`, m-stdlib) still exists and
> needs the m-stdlib s3-testbed MinIO up first:
> `( cd ~/vista-forge/m-stdlib && scripts/s3-testbed.sh up )`.

---

## 4. Quality & maintenance gates

These are the engine-free, registry-driven `source-tag → generate → registry →
red-gate` checks. The discipline: any interface that can drift is a **generated,
drift-gated artifact** — never a convention. After editing source, regenerate and
commit; the `*-check` target re-gates that the committed artifact still matches.

| Concern | Regenerate | Drift gate | Notes |
|---|---|---|---|
| fmt | `make fmt` | `make fmt-check` | the `m-fmt-hook` PostToolUse hook also fixes drift silently |
| lint | — | `make lint` | house gate = zero **error**-severity findings (`scripts/m-lint-gate.sh`) |
| waterline arch (v-stdlib) | — | `make arch` (`m arch check .`) | G1–G5: one-way `v→m`, no VistA symbols below the line, transport monopoly, seam pin |
| manifest | `make manifest` | `make manifest-check` / `check-manifest` | `dist/stdlib-manifest.json` + `errors.json`; asserts `repo.meta.json` committed |
| skill | `make skill` | `make skill-check` | `dist/skill/{SKILL.md,patterns.md,…}` |
| module docs bodies | `make docs-bodies` | `make docs-bodies-check` | the delimited `## API reference` block on each `docs/modules/*.md` |
| frontmatter | `make frontmatter` | `make frontmatter-check` | YAML frontmatter on `docs/modules/*.md` |
| doc grammar | `make grammar` | `make grammar-check` | the `; doc:` tag grammar |
| docs prose layout | — | `make docs-check` / `check-docs-prose` | `docs/` holds prose only |
| seams | `make seams` | `make check-seams` | `@seam` → `dist/seam-snapshot.json` + git-HEAD bump-forcer |
| ICR / DBIA | `make icr` | `make check-icr` | `@icr` → registry + Supported-API / no-direct-global gate (numeric ICR is notional — never required; see [[notional-dbia-not-a-blocker]]) |
| citations | `make citations` | `make check-citations` | cited `doc_key`s vs the vdocs gold corpus — **SKIPS green** if `~/data/vdocs` absent |
| namespaces | `make namespaces` | `make check-namespaces` | declared (`repo.meta.json`) vs discovered `STD*`/`VSL*` prefixes |
| KIDS build | `make kids` | `make check-kids` | deterministic, byte-identical `.KID` vs committed; SKIPS green if `v-pkg` absent |
| MSL pin (v-stdlib) | `make pin` | `make check-msl-pin` | v-stdlib's upward pin to the m-stdlib seam contract |
| engine access (v-stdlib) | — | `make check-engine-access` | committed-artifact backstop to the engine-stack-guard hook — no hand-rolled engine access |

**Aggregate shortcuts.** v-stdlib bundles the engine-free set as `make gates`
(all the drift gates above) and `make check-fast` (`fmt-check lint arch gates`).
m-stdlib runs its drift gates individually or via `make check` / `make ci`.

---

## 5. The live-VistA tier (nightly cadence)

The live tier runs the executable examples — including the VistA-binding `VSL*`
modules — against real VistA on both engines (`vehu` for YDB-VistA, `foia*` for
IRIS-VistA), then runs the **§8 residue check** (asserts the examples left no
trace — byte-identical globals before/after) and writes the run snapshot to
`examples/REPORT.md`.

```bash
# m-stdlib — STD* live on vehu + foia
cd ~/vista-forge/m-stdlib && make examples-run-live M=$M

# v-stdlib — STD* + the @exrun-live VSL* modules on vehu + foia (IRIS namespace VISTA)
cd ~/vista-forge/v-stdlib && make examples-run-live M=$M
```

This is **fail-soft** (a red surfaces without breaking the gate) because it
depends on the live hosts being reachable. It is *not* part of `make check` /
`make ci`. The scheduled nightly job is already wired:
**`~/scripts/bin/examples-live-cron.sh`** (system cron, `30 6 * * *`) runs both
repos' `make examples-run-live` and commits/pushes the refreshed REPORTs — run
it on demand for the same effect (see the [on-demand one-command](#run-the-nightly-job-on-demand-one-command)
section at the top). The committed `examples/REPORT.md` is a run snapshot,
**not** a drift-gated artifact, so a regenerated REPORT is expected to differ.

---

## 6. CI mapping

What the local laps correspond to in `.github/workflows/` (the reusable org
`m-ci.yml` runs the repo's Makefile targets):

- **engine-free job** — `fmt-check`, `lint`, `arch` (v-stdlib), and every drift
  gate from §4; runs on a plain `ubuntu-latest`, no container.
- **YDB engine job (hard gate)** — `make test` / `test-bare` + `examples-run-ydb`
  + `coverage` over `--docker m-test-engine`.
- **IRIS portability job (fail-soft)** — `examples-run-iris` + the IRIS test arm;
  `continue-on-error`, so a red surfaces softly.
- **nightly** — `make examples-run-live` (the §5 live cadence).
- **meta-gate** — the scheduled org-registry backstop ([[meta-gate]]).

A green local `make check-fast` (both repos) + `make examples-run` (both engines,
both repos) + per-engine `coverage` reproduces everything CI gates on a push,
except the live tier and the corpus-dependent `check-citations` (which SKIP green
when their hosts/`~/data/vdocs` are absent).

---

## 7. Troubleshooting

- **`0/0` from an examples or test suite** — a silent abort, treated as a
  **failure**, not a pass. Usual cause: a TDD-red stub that raised `$ECODE`
  instead of returning a safe default, which aborts the suite before
  `report^STDASSERT` fires. Fix the stub (return `0`/`""`/untouched by-ref).
- **STDCSPRNG / binary suite fails on YDB** — the engine is in UTF-8 mode. Pass
  `--chset m` (the Makefiles do; don't strip it from `M_ENGINE_FLAGS` /
  `CHSET=m`).
- **`check-citations` red** — it needs the vdocs gold corpus at `~/data/vdocs`;
  absent → it SKIPS green by design. A *red* means a cited `doc_key` is wrong.
- **A `VSL*` VistA module "didn't run"** — bare runs skip the `@exrun live`
  modules by design; only `examples-run-live` executes them.
- **An engine command is DENIED by the hook** — you (or a Makefile) hand-rolled
  `docker exec`/`iris session`/`mumps -direct`. Route through `m test --docker` /
  `m vista exec` instead. A rare read-only inspection needs an explicit
  `stack-exempt: <reason>` marker.

---

## 8. See also

- [`quick-start.md`](quick-start.md) — 5-minute lap.
- [`m-tdd-guide.md`](m-tdd-guide.md) — the TDD inner loop + release gates.
- [`users-guide.md`](users-guide.md) — deep reference, acceptance gate.
- [`verification-surfaces.md`](verification-surfaces.md) — what `tests/`, `examples/`, and demos each verify, and where new code belongs.
- [`../archive/`](../archive/) — point-in-time corpus / realcode validation writeups (archived from the former `docs/testing/`).
- The Living Executable Examples proposal (E1–E5) — design of the examples
  generator + runner.
- Org `CLAUDE.md` § "m/v waterline" and § "Engine access through the driver
  stack" — the rules these gates enforce.
