---
title: m-stdlib — user's guide
status: live
audience: M developers (VistA, FIS-GT.M heritage projects, IRIS sites) who want a runtime-library substrate so they don't have to re-invent assertions, JSON, regex, datetime, logging, CSV, URL parsing, file I/O, HTTP, crypto digests, and the rest at every site.
companion: modules/index.md (canonical inventory); module-tracker.md (live work board); m-stdlib-implementation-plan.md (per-module specs); m-tdd-guide.md (operational TDD guide for projects building tests on top of m-stdlib's TDD primitives).
created: 2026-05-05
last_modified: 2026-06-24
revisions: 19
doc_type: [GUIDE]
---

# m-stdlib — user's guide

The deep reference for `m-stdlib`: what the library is, the acceptance gate every
module clears, the module inventory, and a five-minute orientation per module.
For a fast lap see [`quick-start.md`](quick-start.md); for the TDD inner loop see
[`m-tdd-guide.md`](m-tdd-guide.md); for the full test + examples + quality matrix
across both engines see [`comprehensive-testing.md`](comprehensive-testing.md).

## Contents

- [1. What this library is](#1-what-this-library-is)
  - [Design principles](#design-principles)
  - [Non-goals](#non-goals)
- [2. The acceptance gate](#2-the-acceptance-gate)
- [3. Module inventory](#3-module-inventory)
- [4. Module reference](#4-module-reference)
  - [4.1 STDASSERT](#41-stdassert--assertions-detail) — assertions
  - [4.2 STDUUID](#42-stduuid--uuids-detail) — UUIDs
  - [4.3 STDB64](#43-stdb64--base64-detail) — Base64
  - [4.4 STDHEX](#44-stdhex--hex-detail) — hex
  - [4.5 STDFMT](#45-stdfmt--printf-detail) — printf-style
  - [4.6 STDLOG](#46-stdlog--structured-logging-detail) — structured logging
  - [4.7 STDDATE](#47-stddate--datetime-detail) — datetime
  - [4.8 STDCSV](#48-stdcsv--rfc-4180-detail) — RFC 4180 CSV
  - [4.9 STDARGS](#49-stdargs--argparse-detail) — argparse
  - [4.10 STDFIX](#410-stdfix--fixtures-detail) — fixtures
  - [4.11 STDMOCK](#411-stdmock--call-interception-detail) — call interception
  - [4.12 STDSEED](#412-stdseed--fixture-data-detail) — fixture data
  - [4.13 STDJSON](#413-stdjson--json-detail) — JSON
  - [4.14 STDREGEX](#414-stdregex--regex-detail) — regex
  - [4.15 STDCOLL](#415-stdcoll--collections-detail) — collections
  - [4.16 STDURL](#416-stdurl--uri-detail) — URI
  - [4.17 STDCSPRNG](#417-stdcsprng--cryptographic-random-detail) — cryptographic random
  - [4.18 STDFS](#418-stdfs--file-system-detail) — file-system
  - [4.19 STDOS](#419-stdos--process--env--cmdline-detail) — process / env / cmdline
  - [4.20 STDSEMVER](#420-stdsemver--semver-200-detail) — SemVer 2.0.0
  - [4.21 STDSTR](#421-stdstr--string-helpers-detail) — string helpers
  - [4.22 STDTOML](#422-stdtoml--toml-10-subset-detail) — TOML 1.0 subset
  - [4.23 STDCACHE](#423-stdcache--lru--ttl-detail) — LRU + TTL cache
  - [4.24 STDPROF](#424-stdprof--wall-clock-profiler-detail) — wall-clock profiler
  - [4.25 STDSNAP](#425-stdsnap--snapshot-testing-detail) — snapshot testing
  - [4.26 STDENV](#426-stdenv--env-loader-detail) — `.env` loader
  - [4.27 STDXML](#427-stdxml--xml-10-detail) — XML 1.0
  - [4.28 STDMATH](#428-stdmath--numeric-helpers-detail) — numeric helpers
  - [4.29 STDXFRM](#429-stdxfrm--higher-order-array-transforms-detail) — map / filter / reduce
  - [4.30 STDCRYPTO](#430-stdcrypto--sha--hmac-detail) — SHA + HMAC
  - [4.31 STDCOMPRESS](#431-stdcompress--gzip--deflate--zstd-detail) — gzip / deflate / zstd
  - [4.32 STDHTTP](#432-stdhttp--http11-client-detail) — HTTP/1.1 client
  - [4.33 STDHARN](#433-stdharn--resident-testcoverage-harness-detail) — resident test/coverage harness
  - [4.34 STDHTTPMSG](#434-stdhttpmsg--http11-message-codec-detail) — HTTP/1.1 message codec
  - [4.35 STDHTTPD](#435-stdhttpd--portable-http-server-framework-detail) — HTTP server framework
  - [4.36 STDKV](#436-stdkv--keyed-record-store-seam-detail) — keyed record store
  - [4.37 STDNET](#437-stdnet--raw-tcp-socket-primitives-detail) — raw-TCP sockets
  - [4.38 STDJWT](#438-stdjwt--jwt-bearer-token-validation-detail) — JWT validation
  - [4.39 STDSIGV4](#439-stdsigv4--aws-sigv4-request-signer-detail) — AWS SigV4 signer
  - [4.40 STDS3](#440-stds3--aws-s3-rest-client-detail) — AWS S3 client
- [5. Living, executable examples](#5-living-executable-examples)
- [6. Cross-references](#6-cross-references)
- [History & further reading](#history--further-reading)

## 1. What this library is

`m-stdlib` is a runtime library that fills the highest-impact gaps in
MUMPS / M's standard library — assertions, UUIDs, base64, JSON, regex,
collections, datetime, logging, CSV, URL parsing, argparse, XML, file
I/O, HTTP, SHA / HMAC, gzip / zstd, and more. It publishes one canonical,
versioned, conformance-tested answer per concern, behaving the same on
every supported engine, so consumers call a single `$$call^STDxxx`
instead of re-inventing the primitive at each site.

The routine family is `STD*` (the prefix is reserved family-wide); routine
names are upper-case, per the M routine-name convention. m-stdlib is a
sibling to `m-cli` (the toolchain), `m-standard` (the modern-M style
guide), and `tree-sitter-m` (the parser).

### Design principles

- **Pure-M for the entire ergonomics surface; `$ZF`-bound only where
  correctness or performance require it.** Most of the library is 100 %
  pure M. The optional tier (`STDCRYPTO`, `STDCOMPRESS`, `STDHTTP`, plus
  the byte-faithful arms of `STDFS` and `STDCSPRNG`) binds to libcrypto /
  libz / libzstd / libcurl through YottaDB's `$&pkg.fn` external-call ABI
  via a shared deployment harness (`scripts/seed-callouts.sh`).
- **Dual-engine: YottaDB and InterSystems IRIS.** The pure-M surface runs
  identically on both engines; where a public behaviour is structurally
  engine-specific the module documents it explicitly. Engine access for
  development, tests, and CI is **through the driver stack only** (see §2).
- **Byte-oriented.** The library assumes one M character == one byte;
  the YDB engine runs in byte mode (`ydb_chset=M`). Binary modules
  (`STDCSPRNG`, `STDB64`, `STDHEX`, `STDJSON`'s UTF-8 decode) are
  byte-exact via `$ZCHAR` / `$ZASCII`.
- **Conformance-backed.** Each module ships a vendored conformance corpus
  tied to the relevant RFC or NIST publication (RFC-4648 base64/hex,
  RFC-4180 CSV, RFC 8259 JSON, RFC 3986 URLs, RFC 4122/9562 UUIDs,
  FIPS 180-4 SHA, RFC 4231 HMAC, the W3C XML Test Suite, …) and runs all
  of it on every commit.
- **m-stdlib has priority over m-cli.** When both projects need a utility
  it lands here first; m-cli imports it.

### Non-goals

- **Not a framework.** No global registries, no init hook, no
  dependency injection. Each module is a flat routine; you `do`-call
  or `$$`-call public labels.
- **Not a compatibility shim.** Does not paper over differences
  between YDB and IRIS — `STDREGEX` runs a Thompson-NFA on every
  engine, but the public API is what's portable, not the
  implementation.
- **Not a security boundary.** Nothing in m-stdlib enforces
  authentication, authorisation, or input sanitisation across trust
  domains. Treat it as a library, not a gateway.
- **Not a TDD framework, though seven of its modules** —
  `STDASSERT`, `STDFIX`, `STDMOCK`, `STDSEED`, `STDPROF`, `STDSNAP`,
  `STDENV` — are the operational primitives behind the m-cli runner's
  TDD support. If you're building a test suite *on top of* m-stdlib
  rather than just consuming utility code, see
  [`m-tdd-guide.md`](m-tdd-guide.md) for the integrated workflow.

## 2. The acceptance gate

Every module clears the same gate. The fast inner loop:

```bash
make check        # fmt-check + lint + test — under a minute on the dev box
```

The release-readiness loop (also what CI runs):

```bash
make ci           # check + JUnit XML + LCOV coverage at min-percent 85
```

The full acceptance gate, applied before any `vN.N.N` tag:

| Gate | Tool | Command | Pass threshold |
|---|---|---|---|
| Format | `m fmt --check` | `make fmt-check` | clean (no diffs) |
| Lint | `m lint` (error-severity) | `make lint` | 0 errors (style/warning advisory) |
| Tests | `m test` | `make test` | 100 % assertions pass (a `0/0` silent abort is a failure) |
| Coverage | `m coverage --min-percent=85` | `make coverage` | aggregate line coverage ≥ 85 % (currently ~93 %) |
| Examples — drift | `make examples-check` | `make examples-check` | generated `examples/programs/*EX.m` + `index.md` match source |
| Examples — coverage | `make examples-coverage` | `make examples-coverage` | 100 % of public labels exampled; every `@raises` demonstrated |
| Examples — run (bare) | `make examples-run` | `make examples-run` | green on **both** bare engines (`m-test-engine` YDB + `m-test-iris` IRIS) |
| Examples — run (live) | `make examples-run-live` | `make examples-run-live` | fail-soft nightly cadence on `vehu` + `foia` + residue check (§5) |

The toolchain is the Go **`m`** — one static binary, built from
[`m-cli`](https://github.com/vista-forge/m-cli), covering fmt / lint /
test / coverage. The `M` Makefile variable points at it (defaults to `m`
on `$PATH`); the engine transport is `$(M_ENGINE_FLAGS)` (default
`--engine ydb --docker m-test-engine --chset m`).

**Engine access is through the driver stack only.** Every `make` target
reaches a live engine via `m test --docker <container>` / `m coverage` /
`m vista exec`, which route through `m-driver-sdk → m-ydb / m-iris` — never
a raw `docker exec`, `iris session`, `mumps -direct`, or a host YDB
install. The default transport is the byte-mode `m-test-engine` YottaDB
container; IRIS portability runs against `m-test-iris`; the live tier runs
against `vehu` (YDB-VistA) and `foia` (IRIS-VistA). The library is
verified **dual-engine**.

`make test` runs the dependency-free **core** — **33 suites,
2513/2513 assertions green** — plus the callout-backed tier
(`make test-optional`: `STDCOMPRESS` / `STDCRYPTO` / `STDHTTP` /
`STDNET` / `STDJWT` / `STDSIGV4` / `STDS3`, which need their `.so` or
IRIS-native backend) and the live S3 round-trip (`make test-s3`).
Aggregate line coverage is gated **≥ 85 %** (currently ~93 %), with 0
lint errors and a clean format.

For the full test + examples + quality matrix across both libraries and
both engines, see [`comprehensive-testing.md`](comprehensive-testing.md);
for projects building tests on top of m-stdlib's TDD primitives, see
[`m-tdd-guide.md`](m-tdd-guide.md).

## 3. Module inventory

40 `STD*` modules, 344 public labels. Backend column: **pure-M** = no host
callouts; **`$&pkg.fn`** = YDB external-call ABI to a libc / OpenSSL /
libz / libzstd / libcurl shared object. m-cli column: **✅ C\<n\>** =
m-cli companion integration shipped (see
[`module-tracker.md`](../module-tracker.md) for the full
companion-track names); **n/a** = no m-cli companion needed; **🟡** /
**🔮** = planned companion integration.

| # | Module | Backend | m-cli | Headline |
|---|---|---|---|---|
| 1 | [`STDASSERT`](../modules/stdassert.md) | pure-M | ✅ C1+C2 | Assertion library — `eq` / `ne` / `true` / `false` / `near` / `raises` / `contains` / `len` + counter `start` / `report`. Wire-protocol-compatible with the m-cli runner. |
| 2 | [`STDUUID`](../modules/stduuid.md) | pure-M | n/a | RFC-4122 v4 + RFC-9562 v7 UUIDs. v7 timestamp-prefix sorts in generation order. |
| 3 | [`STDB64`](../modules/stdb64.md) | pure-M | n/a | RFC-4648 Base64 — standard alphabet `+ /`, URL-safe variant `- _`, `valid` predicate. |
| 4 | [`STDHEX`](../modules/stdhex.md) | pure-M | n/a | RFC-4648 §8 hex — lowercase default, uppercase variant, case-insensitive decode. |
| 5 | [`STDFMT`](../modules/stdfmt.md) | pure-M | n/a | Printf-style formatter — subset of Python `str.format` (fill / align / width / precision / type `s d f x X o b`). |
| 6 | [`STDLOG`](../modules/stdlog.md) | pure-M | n/a | Structured logger — five levels, four sinks, `kv` or `json` line format. |
| 7 | [`STDDATE`](../modules/stddate.md) | pure-M | n/a | ISO-8601 datetime + duration arithmetic (`now`, `fromh`, `toh`, `strftime`, `strptime`, `add`, `diff`). |
| 8 | [`STDCSV`](../modules/stdcsv.md) | pure-M | n/a | RFC-4180 CSV parser/writer — every §2 clause, optional file I/O. |
| 9 | [`STDARGS`](../modules/stdargs.md) | pure-M | n/a | argparse — long/short/grouped flags, positionals, sub-commands, `--` terminator. |
| 10 | [`STDFIX`](../modules/stdfix.md) | pure-M | ✅ C3 | Fixture lifecycle — `with` / `invoke` / `register` / `cleanup`. Powers `m test`'s default per-test isolation. |
| 11 | [`STDMOCK`](../modules/stdmock.md) | pure-M | ✅ C4 | Test-time call interception — `register` / `invoke` / `$$resolve` / `$$called` / `$$args`. |
| 12 | [`STDSEED`](../modules/stdseed.md) | pure-M | ✅ C5 | TSV / JSON manifest loader for FileMan record fixtures + pluggable filer hook. |
| 13 | [`STDJSON`](../modules/stdjson.md) | pure-M | n/a | RFC 8259 JSON parser + serialiser — one M tree node per JSON value. |
| 14 | [`STDREGEX`](../modules/stdregex.md) | pure-M | n/a | Thompson-NFA regex engine (literals, classes, groups, alternation, greedy quantifiers, capture, replace, split). |
| 15 | [`STDCOLL`](../modules/stdcoll.md) | pure-M | n/a | Collections — Set / Map / Stack / Queue / Deque / Heap / OrderedDict over caller-owned arrays. |
| 16 | [`STDURL`](../modules/stdurl.md) | pure-M | 🔮 C9 | RFC 3986 URI parse / build / encode / decode / valid / normalize / resolve. |
| 17 | [`STDCSPRNG`](../modules/stdcsprng.md) | pure-M (+ optional `$&` → `getrandom(2)` perf path) | n/a | Cryptographic random — bytes / hex / base64 / token / int / uuid4 backed by `/dev/urandom`. |
| 18 | [`STDFS`](../modules/stdfs.md) | pure-M (text I/O) + `$&` → libc `open/read/write/close` (byte-faithful arms) | n/a | File-system primitives — text-mode read/write/append + byte-faithful readBytes/writeBytes/appendBytes + exists/remove/size + basename/dirname/join. |
| 19 | [`STDOS`](../modules/stdos.md) | pure-M | n/a | Process / env / cmdline helpers — env / pid / cmdline / argv / cwd / user / hostname / exit. |
| 20 | [`STDSEMVER`](../modules/stdsemver.md) | pure-M | 🔮 C10 | SemVer 2.0.0 — valid / parse / compare / matches with caret, tilde, comparator AND-combination. |
| 21 | [`STDSTR`](../modules/stdstr.md) | pure-M | n/a | String helpers — pad / trim / replaceAll / split / startsWith / endsWith / case / repeat. |
| 22 | [`STDTOML`](../modules/stdtoml.md) | pure-M | 🔮 C11 | TOML 1.0 subset — top-level pairs + `[section]` tables; string / int / float / bool scalars; `#` comments. |
| 23 | [`STDCACHE`](../modules/stdcache.md) | pure-M | n/a | LRU + TTL cache over caller-owned array — new / put / get / has / remove / clear. |
| 24 | [`STDPROF`](../modules/stdprof.md) | pure-M | ✅ C6 | Wall-clock profiler — start / stop / count / total / mean / min / max / percentile / tags. |
| 25 | [`STDSNAP`](../modules/stdsnap.md) | pure-M | ✅ C7 | Snapshot testing — serialize / save / matches / asserts; canonical line-per-leaf dump via `$QUERY`. |
| 26 | [`STDENV`](../modules/stdenv.md) | pure-M | ✅ C8 | `.env` loader + typed accessors — parse / parseFile / valid / has / get / getInt / getBool / getFloat. |
| 27 | [`STDXML`](../modules/stdxml.md) | pure-M | n/a | XML 1.0 parser — elements, attributes, CDATA, comments / PI / xml-decl, numeric char refs, namespaces, full XPath subset (paths / predicates / descendant axis / wildcards / attribute axis / functions / comparison predicates / DOCTYPE + `<!ENTITY>`). |
| 28 | [`STDMATH`](../modules/stdmath.md) | pure-M | n/a | Numeric helpers — clamp / min / max / sum / count / mean over caller-owned arrays. |
| 29 | [`STDXFRM`](../modules/stdxfrm.md) | pure-M | n/a | Higher-order array transforms — map / filter / reduce via XECUTE-evaluated lambdas (`value` / `key` / `acc` locals). |
| 30 | [`STDCRYPTO`](../modules/stdcrypto.md) | `$&stdcrypto.fn` → libcrypto | 🟡 C12 | SHA-256/384/512 + HMAC-SHA-256/384/512 backed by OpenSSL EVP_Digest + HMAC. Conformance: FIPS 180-4 + RFC 4231 vectors. |
| 31 | [`STDCOMPRESS`](../modules/stdcompress.md) | `$&stdcompress.fn` → libz + libzstd | 🟡 C13 | gzip / gunzip / deflate / inflate / zstdCompress / zstdDecompress + magic-byte autodetect; 1 MiB output cap with `,U-…-FAIL,` on overflow. |
| 32 | [`STDHTTP`](../modules/stdhttp.md) | `$&stdhttp.fn` → libcurl (callout) + pure-M (wire-format helpers) | 🟡 C14 | HTTP/1.1 client — `$$get` / `$$post` / `$$request` driving libcurl, plus pure-M `parseStatusLine` / `parseHeader` / `parseResponse` / `buildRequest` / `formatHeaders` for offline wire-format work. |
| 33 | [`STDHARN`](../modules/stdharn.md) | pure-M | n/a | Resident test/coverage harness — runs `*TST` suites in the live namespace and emits a deterministic `##M-HARNESS` result frame the Go `m` client splits back through its unchanged `mtest`/`mcov` consumers (`RUN` / `run` / `cov`). |
| 34 | [`STDHTTPMSG`](../modules/stdhttpmsg.md) | pure-M | n/a | Byte-level HTTP/1.1 message codec — symmetric `parseReq` / `parseRsp` / `serializeReq` / `serializeRsp` + case-insensitive `hdr`; parse failures return a status code, identical on YDB + IRIS. |
| 35 | [`STDHTTPD`](../modules/stdhttpd.md) | pure-M | n/a | Portable HTTP server framework — `route` / `match` route engine, `use` middleware chain, `dispatch` / `serve` worker loop; transport, route table and log hook are all caller-injected (no sockets/TLS/VistA). |
| 36 | [`STDKV`](../modules/stdkv.md) | pure-M | n/a | Minimal keyed record-store seam (MSL/VSL S1) — `set` / `get` / `exists` / `kill` over (collection, key, field); reference back end is a process-private global, VSLFS swaps in FileMan. |
| 37 | [`STDNET`](../modules/stdnet.md) | pure-M over the engine's native socket device (no C call-out) | n/a | Portable raw-TCP socket primitives (MSL/VSL S4) — `available` / `listen` / `boundport` / `accept` / `connect` / `read` / `write` / `close`; YDB + IRIS, raw bytes, no framing. |
| 38 | [`STDJWT`](../modules/stdjwt.md) | pure-M + `$&stdcrypto.fn` → libcrypto (HMAC, via STDCRYPTO) | n/a | Resource-server JWT validator (RFC 7519 / 9068, HS256) — `verify` / `decode` / `claim` / `sign` (dev-test only) / `lastError`; non-HS256 tokens rejected, not silently accepted. |
| 39 | [`STDSIGV4`](../modules/stdsigv4.md) | pure-M + `$&stdcrypto.fn` → libcrypto (HMAC/SHA, via STDCRYPTO) | n/a | Service-generic AWS SigV4 request signer — `authHeader` / `sign` / `signingKey` / `canonRequest` / `encPath` / `encQuery` / `amzDate` / `emptyHash`; the protocol layered over STDCRYPTO, no new crypto. |
| 40 | [`STDS3`](../modules/stds3.md) | pure-M (builds on STDSIGV4 + STDHTTP → libcurl) | n/a | AWS S3 REST client — `putObject` / `getObject` / `headObject` / `listObjectsV2` / `deleteObject` + full multipart; explicit `ctx` credential, virtual-hosted or path-style (`opt("endpoint")`) for MinIO/LocalStack. |

Every module also ships a generated, executed **living example** (§5):
all 344 public labels carry a runnable, self-verifying example, re-run on
both bare engines every PR and on live `vehu` / `foia` on a nightly
cadence. See [`modules/index.md`](../modules/index.md) for the per-module
gate breakdown and
[`module-tracker.md`](../module-tracker.md) for live status,
in-flight extensions, and proposed future modules.

## 4. Module reference

Each subsection here is a five-minute orientation. Authoritative
detail (full label list, error codes, edge cases, API examples) lives
in the per-module document linked at the top.

### 4.1 `STDASSERT` — assertions ([detail](../modules/stdassert.md))

The cornerstone every other suite uses. Eleven public labels
(`start`, `report`, `eq`, `ne`, `true`, `false`, `near`, `raises`,
`contains`, `len`, `silent`). Each assertion takes counters by
reference (`.pass,.fail`) and emits the line protocol the m-cli
runner consumes without adapter code.

```m
do start^STDASSERT(.pass,.fail)
do eq^STDASSERT(.pass,.fail,$$encode^STDB64("foo"),"Zm9v","RFC-4648 example")
do report^STDASSERT(pass,fail)
```

`raises` captures `$ECODE` from a candidate label running under
`$ETRAP`, supporting both extrinsic chains and procedure-style calls
via a `ZGOTO`-based unwind.

### 4.2 `STDUUID` — UUIDs ([detail](../modules/stduuid.md))

Both v4 (random) and v7 (timestamp-prefix monotonic) per RFC 4122 +
RFC 9562. The v7 implementation matters: it sorts in generation
order under M's natural collation, so `^index($$v7^STDUUID(),...)`
gives you a chronologically-ordered index for free.

API: `$$v4^STDUUID()`, `$$v7^STDUUID()`, `$$valid^STDUUID(s)`,
`$$version^STDUUID(s)`, `$$variant^STDUUID(s)`, plus `parse` /
`format` helpers. Conformance corpus at
`tests/conformance/uuid/rfc4122-vectors.tsv` covers Nil, Max, every
version 1–8, all four variants, mixed/upper case, plus eight
malformed-input rejections.

For security tokens (session IDs, password resets, JWT salts), prefer
`$$uuid4^STDCSPRNG()` — same RFC-4122 v4 surface but kernel-CSPRNG-
backed.

### 4.3 `STDB64` — Base64 ([detail](../modules/stdb64.md))

Standard and URL-safe variants. The URL-safe variant (`- _`, no `=`
padding) is the JWT convention, so STDB64 doubles as the encoding
half of a future JWT helper.

```m
write $$encode^STDB64("foobar"),!         ; Zm9vYmFy
write $$urlencode^STDB64("foo?bar=baz")   ; URL-safe, no padding
```

Five extrinsics: `encode`, `decode`, `urlencode`, `urldecode`,
`valid`. RFC-4648 §10 vectors at `tests/conformance/b64/`.

### 4.4 `STDHEX` — Hex ([detail](../modules/stdhex.md))

RFC-4648 §8. Four extrinsics: `encode` (lowercase), `encodeu`
(uppercase), `decode` (case-insensitive), `valid` (even length +
hex digits).

### 4.5 `STDFMT` — printf ([detail](../modules/stdfmt.md))

Subset of Python `str.format`. Two extrinsics:

- `$$f^STDFMT(template,a1,…,a9)` — up to 9 positional args.
- `$$fn^STDFMT(template,.args)` — named via local array.

Format spec: `{[name][:[fill][align][width][.precision][type]]}`,
where type ∈ `{s d f x X o b}`. `{{` / `}}` escape literal braces.

```m
write $$f^STDFMT("Hello, {0:>10}!","world"),!     ; "Hello,      world!"
write $$f^STDFMT("{0:.3f}",3.14159),!              ; "3.142"
```

### 4.6 `STDLOG` — structured logging ([detail](../modules/stdlog.md))

Five level entry points (`DEBUG` / `INFO` / `WARN` / `ERROR` /
`FATAL`), each accepting an `event` and up to five `key=value` pairs.

```m
do INFO^STDLOG("user.login","userid",duz,"ip",$io,"ua",ua)
; → 2026-05-05T19:10:00.123Z level=INFO event=user.login userid=42 ip=... ua=...
```

Configuration at `^STDLIB($job,"stdlog",...)`: `LEVEL` (per-process
threshold), `SINK` (`stderr` / `stdout` / `global` / `global:^GREF`),
and `FORMAT` (`kv` default, or `json` for one-line JSON-encoded
records via `$$encode^STDJSON`). Output values are emitted raw when
clean, otherwise wrapped in `"…"` with `\\` and `\"` escaping.

### 4.7 `STDDATE` — datetime ([detail](../modules/stddate.md))

Seven extrinsics covering wall-clock and arithmetic:

| Label | Purpose |
|---|---|
| `now` | Current UTC, ms precision, trailing `Z`. |
| `fromh` / `toh` | Convert `$HOROLOG` ↔ ISO 8601 (accepts 2/3/4-piece). |
| `strftime` / `strptime` | `%Y %m %d %H %M %S %j %z %%` directives. |
| `add` | `[-]P[nY][nM][nW][nD][T[nH][nM][nS]]` duration; Feb-29 day-clamp on `+P1Y`. |
| `diff` | `h2 − h1 → PnDTnHnMnS`, sign-prefixed. |

Civil-to-day conversion uses Howard Hinnant's `days_from_civil` over
proleptic Gregorian (verified 1840–2400 incl. all leap-year edge
cases).

### 4.8 `STDCSV` — RFC 4180 ([detail](../modules/stdcsv.md))

Four entry points: `$$parse^STDCSV(text,.rows)`,
`$$write^STDCSV(.rows)`, `parseFile^STDCSV(path,callback)`,
`writeFile^STDCSV(path,.rows)`. Covers every RFC-4180 §2 clause
(CRLF / LF / lone-CR record separators, optional trailing
terminator, optional `"…"` field wrapping, embedded `,` / CRLF /
`""` escape) and strips a leading UTF-8 BOM on input. Conformance
corpus at `tests/conformance/csv/`.

### 4.9 `STDARGS` — argparse ([detail](../modules/stdargs.md))

Long flags, short flags, grouped count flags (`-vvv`), positionals,
sub-commands, `--` end-of-flags terminator. Four actions:
`store_true` / `store` / `count` / `append`.

```m
new p,ns
set p=$$new^STDARGS()
do flag^STDARGS(p,"verbose","v","count")
do flag^STDARGS(p,"output","o","store")
do parse^STDARGS(p,$ZCMDLINE,.ns)
write ns("verbose"),!,ns("output"),!
```

Args source = `$ZCMDLINE` on YDB, explicit string elsewhere. Per-handle
state under `^STDLIB($job,"stdargs",p,...)`.

### 4.10 `STDFIX` — fixtures ([detail](../modules/stdfix.md))

Five public labels enabling per-test isolation:

| Label | Purpose |
|---|---|
| `with(tag,code)` | One-shot transactional scope: opens `tstart`, runs `code`, `trollback`s on exit. |
| `invoke(tag,code)` | Like `with`, but pre-runs setup hooks registered via `register`. |
| `$$active(tag)` | Predicate — is a fixture currently held? |
| `register(tag,setupCode,teardownCode)` | Declarative fixture. |
| `cleanup` | Idempotent rollback of any leaked transactions. |

Why one-shot wrappers and not standalone `setup` / `teardown`? Because
YDB's `TPQUIT` enforces per-routine-frame balance of `tstart` /
`trollback` — a separately-scoped setup/teardown pair is structurally
impossible. Call `with` / `invoke` inside the test to bracket a mutation
in a transaction that rolls back on the way out.

### 4.11 `STDMOCK` — call interception ([detail](../modules/stdmock.md))

Three procedures (`register` / `unregister` / `clear`), three
extrinsics (`$$resolve` / `$$called` / `$$args`), and one
indirection-driven procedure (`invoke`).

```m
do register^STDMOCK("get^DGFUNC","stub^MYTEST")
; production code calls do invoke^STDMOCK("get^DGFUNC",.args)
; — dispatched to stub^MYTEST instead
do clear^STDMOCK
```

Call `clear^STDMOCK` between tests so registrations don't leak.
Single-level resolution — no chained replacement. Per-call args
recorded under `^STDLIB($job,"stdmock",...)` so tests can assert what
the production code passed.

### 4.12 `STDSEED` — fixture data ([detail](../modules/stdseed.md))

TSV and JSON manifest loader for FileMan record fixtures.

```
# fixtures/test-patients.tsv
PATIENT	.01=Smith,John	.02=M	.03=2 7 80
PATIENT	.01=Doe,Jane	.02=F	.03=12 1 75
```

```m
; in your suite setup, inside a transaction:
do load^STDSEED("fixtures/test-patients.tsv")
```

`loadJson` accepts an STDJSON-encoded array of records (same field
shape) for callers who already produce JSON fixtures. Pluggable filer
hook — the default `fileViaDie^STDSEED` invokes `FILE^DIE` and
surfaces `^TMP("DIERR",$J)` as `U-STDSEED-FILER-DIE-ERROR`. Tests
inject a stub filer to run without FileMan.

### 4.13 `STDJSON` — JSON ([detail](../modules/stdjson.md))

RFC 8259 parser + serialiser. Storage convention: one M tree node per
JSON value, with the type discriminator in the leaf:

| Sigil | Type |
|---|---|
| `o` | object — children at `node(key)` |
| `a` | array — children at `node(i)` |
| `s:VALUE` | string |
| `n:VALUE` | number (canonical numeric string) |
| `t` / `f` | true / false |
| `z` | null |

```m
new root,ok
set ok=$$parse^STDJSON("{""user"":""rmr"",""active"":true}",.root)
write $$type^STDJSON(.root("user")),!         ; string
write $$valueOf^STDJSON(.root("user")),!      ; rmr
write $$encode^STDJSON(.root),!                ; round-trips
```

Curated A3 corpus (23 `y_`, 15 `n_`, 8 `i_` files) at
`tests/conformance/json/` — every vector mapped to an RFC 8259 clause
in the corpus README. Recursion through subscripted-by-reference locals
uses the merge-then-pass idiom (YDB's `.x(SUBS)` syntax limit), which
is fully internalised — callers see ordinary-looking
`$$encode^STDJSON(.tree)` calls.

**Engine portability.** Runs on YottaDB and IRIS with one behavioural
difference: an **empty object key** (`{"": …}`, RFC 8259 §4) is supported
on YottaDB but rejected with a clean `U-STDJSON-PARSE` error on IRIS,
because IRIS prohibits null subscripts in local arrays (the tree stores
members at `node(key)` and `node("")` is not representable). String
values are byte-exact UTF-8 on both engines. Full rationale in the module
doc's [Engine portability](../modules/stdjson.md#engine-portability-yottadb--iris)
section.

### 4.14 `STDREGEX` — regex ([detail](../modules/stdregex.md))

Thompson-NFA engine. Compiled patterns are positive-integer handles;
pattern state lives at `^STDLIB($job,"stdregex",h,...)`;
`$$free^STDREGEX(h)` releases it.

```m
new h,n,out
set h=$$compile^STDREGEX("(\\w+)@(\\w+\\.\\w+)")
write $$search^STDREGEX(h,"contact rmr@example.com"),!     ; 1
do groups^STDREGEX(h,"contact rmr@example.com",.out)
write out(1),!                                              ; rmr
write out(2),!                                              ; example.com
do free^STDREGEX(h)
```

Supported subset: literals, `.`, `^` / `$`, greedy `*` / `+` / `?` /
`{n}` / `{n,}` / `{n,m}`, `[abc]` / `[^abc]` / `[a-z]`, predefined
classes `\d` `\w` `\s`, alternation `|`, capturing `(…)` and
non-capturing `(?:…)`, `\1..\9` backref expansion in `replace`. Out
of scope: back-refs in pattern, lookaround, named groups, Unicode
property classes, inline modifiers, possessive/lazy quantifiers —
`compile` rejects with `U-STDREGEX-UNSUPPORTED`.

### 4.15 `STDCOLL` — collections ([detail](../modules/stdcoll.md))

Seven by-reference collection types over caller-owned local arrays:

| Type | Headline labels |
|---|---|
| `Set` | `add` / `has` / `remove` / `size` / `clear` / iterate via `$ORDER` |
| `Map` | `put` / `get` / `has` / `remove` / `size` / `clear` |
| `Stack` | `push` / `pop` / `peek` / `size` |
| `Queue` | `enq` / `deq` / `peek` / `size` |
| `Deque` | `pushFront` / `pushBack` / `popFront` / `popBack` / `peekFront` / `peekBack` |
| `Heap` | min-heap with `O(log n)` push / pop, `O(1)` peek; optional payload |
| `OrderedDict` | insertion-ordered; walks via monotonic sequence + reverse map |

Empty-key and empty-pop semantics are silent no-ops / blank returns
rather than `$ECODE`-raising — callers gate on `*Size` to distinguish
empty from a stored `""`.

### 4.16 `STDURL` — URI ([detail](../modules/stdurl.md))

RFC 3986. One procedure (`parse`) writes all seven components of a
URI to the caller's array (`scheme` / `userinfo` / `host` / `port` /
`path` / `query` / `fragment`); six extrinsics handle build, encode,
decode, validity, normalization, and reference resolution.

```m
new u
do parse^STDURL("https://user@example.com:8080/p?q=1#f",.u)
write u("scheme"),!,u("host"),!,u("port"),!  ; https / example.com / 8080
write $$normalize^STDURL("HTTP://Example.COM/a/./b/../c"),!
;   → http://example.com/a/c
write $$resolve^STDURL("/foo","http://a/b/c"),!
;   → http://a/foo (RFC 3986 §5.3 transform-references in strict mode)
```

`decode` is intentionally lenient (Python `urllib.parse.unquote`
semantics — malformed `%` sequences pass through as literal text);
`valid` is the strict gate.

### 4.17 `STDCSPRNG` — cryptographic random ([detail](../modules/stdcsprng.md))

Kernel CSPRNG via `/dev/urandom` (the same source `getrandom(2)` reads
without `GRND_RANDOM`). Use this — not `STDUUID.v4` or `$RANDOM` — for
session tokens, password reset tokens, JWT signing salts, nonces.

```m
write $$bytes^STDCSPRNG(16),!         ; 16 raw bytes (binary-unsafe in print)
write $$hex^STDCSPRNG(16),!           ; 32-char lowercase hex
write $$base64^STDCSPRNG(16),!        ; URL-safe base64 (no padding)
write $$token^STDCSPRNG(24),!         ; URL-safe token, 24 bytes of entropy
write $$int^STDCSPRNG(0,99),!         ; unbiased rejection-sampled int 0–99
write $$uuid4^STDCSPRNG(),!           ; RFC-4122 v4 backed by /dev/urandom
```

`int` rejection-samples on the smallest power of 256 covering the
range, so the distribution is unbiased (no modulo-bias artefact).
`uuid4` round-trips through `$$valid^STDUUID` / `$$version^STDUUID`
identically to `$$v4^STDUUID()` — switch over wherever the UUID is a
security boundary.

### 4.18 `STDFS` — file-system ([detail](../modules/stdfs.md))

Centralises the YDB SEQ-device `OPEN`/`USE`/`READ`/`WRITE`/`CLOSE`
dance so consumers don't re-derive deviceparams or trigger the
M-MOD-024 OPEN/CLOSE-deviceparam lint false-positive. Text-mode I/O
plus existence + metadata + pure-string path manipulation.

```m
do writeFile^STDFS("/tmp/note.txt","hello world")
write $$readFile^STDFS("/tmp/note.txt"),!     ; "hello world"
do append^STDFS("/tmp/note.txt"," — line 2")
do readLines^STDFS("/tmp/note.txt",.lines)
write $$exists^STDFS("/tmp/note.txt"),!       ; 1
write $$size^STDFS("/tmp/note.txt"),!         ; byte count
do remove^STDFS("/tmp/note.txt")
write $$basename^STDFS("/a/b/c.tsv"),!        ; "c.tsv"
write $$dirname^STDFS("/a/b/c.tsv"),!         ; "/a/b"
write $$join^STDFS("/a","b","c"),!            ; "/a/b/c"
```

`exists` uses an `OPEN`-with-`timeout=0` probe inside an
`$ETRAP+ZGOTO $zlevel` so it bypasses `$ZSEARCH`'s per-process cache —
a path created and removed inside one M process round-trips correctly.
`writeFile` always emits a trailing LF (POSIX convention); `readFile`
strips it on the way back.

### 4.19 `STDOS` — process / env / cmdline ([detail](../modules/stdos.md))

Fills the gaps `$ZCMDLINE` / `$ZJOB` / `$ZTRNLNM` leave behind. Useful
glue for STDARGS-driven scripts that want to inspect env, exit with a
non-zero rc, or report `$JOB` / `$cwd` / hostname.

```m
write $$env^STDOS("HOME"),!           ; ~/  ($ZTRNLNM-equivalent)
write $$pid^STDOS(),!                  ; current $JOB
write $$cmdline^STDOS(),!              ; raw $ZCMDLINE
do argv^STDOS(.args)                   ; whitespace-tokenised
write $$cwd^STDOS(),!
write $$hostname^STDOS(),!
do exit^STDOS(2)                       ; ZHALT 2
```

`splitArgs` is whitespace-only — quote-aware tokenisation tracked on
the dispatch board.

### 4.20 `STDSEMVER` — SemVer 2.0.0 ([detail](../modules/stdsemver.md))

Parse / compare / range-match per SemVer 2.0.0. Pure-M (no STDREGEX
runtime dep). Architecturally load-bearing for any future M package
manager — dependency resolution can't exist without this.

```m
write $$valid^STDSEMVER("1.2.3-rc.1+build.5"),!     ; 1
write $$compare^STDSEMVER("1.2.3","1.2.4"),!        ; -1
write $$matches^STDSEMVER("1.2.3","^1.2.0"),!       ; 1 (caret)
write $$matches^STDSEMVER("1.3.0","~1.2"),!         ; 0 (tilde, minor pinned)
write $$matches^STDSEMVER("2.0.0",">=1.0 <2"),!     ; 0 (AND-combined comparators)
do parse^STDSEMVER("1.2.3-rc.1+x",.v)
write v("major"),".",v("minor"),".",v("patch"),! v("prerelease"),!,v("build"),!
```

Range syntax: comparators (`>`, `<`, `>=`, `<=`, `=`), caret (`^`),
tilde (`~`), space-separated AND. Extended range constructs (`||`
OR, hyphen ranges, wildcards, prerelease-aware comparators, npm
`^0.x.y` zero-major narrowing) are tracked in
[`module-tracker.md`](../module-tracker.md).

### 4.21 `STDSTR` — string helpers ([detail](../modules/stdstr.md))

The pad / trim / split / starts-with / ends-with / case-fold / repeat
basics that show up across every consumer. Pure `$translate` /
`$piece` / `$find` / `$extract` — no `$Z*`, no STDREGEX dep. ASCII-
only.

```m
write $$pad^STDSTR("x",5,"."),!                ; "x...."
write $$padLeft^STDSTR("42",5,"0"),!            ; "00042"
write $$trim^STDSTR("  hi  "),!                 ; "hi"
write $$replaceAll^STDSTR("a,b,c",",",";"),!    ; "a;b;c"
do split^STDSTR("a,b,c",",",.parts)             ; parts(1)="a",parts(2)="b",...
write $$startsWith^STDSTR("hello","he"),!       ; 1
write $$toLowerASCII^STDSTR("ABC"),!            ; "abc"
write $$repeat^STDSTR("-",10),!                  ; "----------"
```

### 4.22 `STDTOML` — TOML 1.0 subset ([detail](../modules/stdtoml.md))

Top-level pairs + `[section]` tables + four scalars (string, signed
decimal int, signed decimal float, bool surfaced as 1/0) + `#`
comments. Tree shape: `root("v",path)` + `root("t",path)` where
`path` is a dotted key.

```m
new toml,cfg
set toml="[server]"_$char(10)_"host=""127.0.0.1"""_$char(10)_"port=8080"
do parse^STDTOML(toml,.cfg)
write cfg("v","server.host"),!     ; "127.0.0.1"
write cfg("v","server.port"),!     ; 8080
write cfg("t","server.port"),!     ; "int"
```

Out of scope: arrays, inline tables, dotted keys,
`[[array-of-tables]]`, multi-line / literal strings, integer
underscores + hex/oct/bin, special floats, exponent notation,
datetime values — see [`module-tracker.md`](../module-tracker.md) for
the queued extensions.

### 4.23 `STDCACHE` — LRU + TTL ([detail](../modules/stdcache.md))

Caller-owned cache tree (no globals). LRU via two-way `seq ↔ key`
maps; TTL is **lazy on access** (no background sweeper). Memoisation,
RPC-result caching, rate-limit windows.

```m
new cache,v
do new^STDCACHE(.cache,100,300)        ; capacity=100, ttl=300s
do put^STDCACHE(.cache,"user:42",.userTree)
if $$has^STDCACHE(.cache,"user:42") write $$get^STDCACHE(.cache,"user:42"),!
write $$size^STDCACHE(.cache),!,$$capacity^STDCACHE(.cache),!
do remove^STDCACHE(.cache,"user:42")
do clear^STDCACHE(.cache)
```

Multiple caches per process are independent (different `.cache`
locals). Time source is `$HOROLOG` collapsed to seconds.

### 4.24 `STDPROF` — wall-clock profiler ([detail](../modules/stdprof.md))

Caller-owned profiler tree. `$ZHOROLOG`-backed (microsecond
resolution; ANSI `$HOROLOG` is too coarse). Aggregates: count, total,
mean, min, max, percentile.

```m
new prof,i
do start^STDPROF(.prof,"db.query")
do queryDb()                              ; whatever you're profiling
do stop^STDPROF(.prof,"db.query")
write $$count^STDPROF(.prof,"db.query"),!
write $$mean^STDPROF(.prof,"db.query"),!
write $$percentile^STDPROF(.prof,"db.query",95),!
```

STDPROF is the tool for finer-grained intra-suite timings (per-test,
per-section) — instrument the hot path with `start` / `stop` and assert
on `$$percentile`.

### 4.25 `STDSNAP` — snapshot testing ([detail](../modules/stdsnap.md))

Canonical line-per-leaf serialisation via a `$QUERY` walk; save +
match + assert against an on-disk baseline. Force-multiplier for
data-shape tests (parsed JSON trees, FileMan record exports,
RPC responses).

```m
new tree
set tree("a")=1
set tree("b","c")=2
do save^STDSNAP("snapshots/cfg.snap",.tree)
write $$matches^STDSNAP("snapshots/cfg.snap",.tree),!     ; 1
do asserts^STDSNAP(.pass,.fail,"snapshots/cfg.snap",.tree,"config matches")
```

Update mode: when `^STDLIB($job,"stdsnap","update")=1` is set,
`asserts` rewrites the baseline file instead of comparing — set the
sentinel in your suite (or delete the baseline file) to regenerate
snapshots after an intentional output change.

### 4.26 `STDENV` — `.env` loader ([detail](../modules/stdenv.md))

Parses `.env` files with the standard subset: bare values
(whitespace-trimmed), double-quoted with `\n \t \r \" \\` escapes,
single-quoted POSIX-literal (no escape processing), `#` whole-line
comments, leading-letter-or-`_` keys. Typed accessors with default-
on-miss-or-mistype.

```m
new env
do parseFile^STDENV("/cfg/dev.env",.env)
write $$get^STDENV(.env,"DB_HOST","localhost"),!
write $$getInt^STDENV(.env,"PORT",5432),!
write $$getBool^STDENV(.env,"DEBUG",0),!         ; 1 for {true,yes,on,1}
```

`getBool` matches `{true, yes, on, 1}` / `{false, no, off, 0}` case-
insensitive. In a suite, call `parseFile^STDENV(path,.env)` in setup and
read keys from the `env` array.

### 4.27 `STDXML` — XML 1.0 ([detail](../modules/stdxml.md))

XML 1.0 parser with namespace support and a useful XPath subset.
Public surface covers what a VistA HL7v3 / CDA / FHIR consumer
needs out of the box. Tree shape mirrors STDJSON's caller-owned-tree
convention — `node("name")` (local name) / `node("prefix")` /
`node("ns")` / `node("attr",key)` / `node("attrNs",key)` /
`node("text")` / `node("childCount")` / `node("child",N)`.

```m
new doc,sub
do parse^STDXML("<note id=""1""><body>hi</body></note>",.doc)
write $$rootName^STDXML(.doc),!                   ; "note"
write $$attr^STDXML(.doc,"id"),!                   ; "1"
do childByName^STDXML(.doc,"body",.sub)
write $$text^STDXML(.sub),!                        ; "hi"
```

What's covered:

- **Elements / attributes / text** — well-formed XML 1.0.
- **Comments / processing instructions / `<?xml ... ?>` declaration**
  — consumed and discarded (preamble, intra-document, postamble).
- **CDATA sections** — `<![CDATA[ ... ]]>` content stored verbatim
  (no entity decoding).
- **Entity references** — the five standard entities (`&amp;` `&lt;`
  `&gt;` `&quot;` `&apos;`) plus numeric character references
  (`&#NNN;` decimal, `&#xHH;` hex), with full UTF-8 encoding for
  any code point up to U+10FFFF.
- **Namespaces** — element prefix and attribute prefix both resolved
  against the inherited + local `xmlns` map; `xml:` prefix bound
  built-in. Accessors: `$$ns^STDXML(.node)`,
  `$$attrNs^STDXML(.node, attrName)`. Undeclared prefix is a parse
  error.
- **XPath subset** — `$$xpath` / `$$xpathOne` / `$$xpathText` accept
  bare `name`, chained `a/b/c`, absolute `/foo`, descendant `//x`,
  and the position predicate `[N]`. Results are subtree merges so
  callers walk them like any other parsed-tree node.

`childByName` does the internal `merge` to sidestep the YDB `.x(SUBS)`
syntax limit — recursive descent through a parsed XML tree just works
without callers needing merge-then-pass plumbing themselves. The
parser fails closed on unsupported input (`$$lastError^STDXML()`
identifies the offending construct). Out of scope: DTDs / `<!DOCTYPE>` /
custom entity declarations, XPath wildcards / attribute axis (`@attr`),
and XPath functions / comparison predicates (`[@attr='v']`,
`position()`, `count()`, …) — all tracked in
[`module-tracker.md`](../module-tracker.md).

### 4.28 `STDMATH` — numeric helpers ([detail](../modules/stdmath.md))

Scalar `clamp` plus reductions over caller-owned arrays
(`min` / `max` / `sum` / `count` / `mean`). Pure-M (no `$Z*`,
no STDREGEX dep). Works with any subscript shape — `$ORDER`-walks
depth-1 entries.

```m
write $$clamp^STDMATH(99,0,10),!         ; 10 (rolls down to hi)
write $$clamp^STDMATH(-3,0,10),!         ; 0  (rolls up to lo)

new arr  set arr(1)=3,arr(2)=1,arr(3)=4,arr(4)=1,arr(5)=5
write $$min^STDMATH(.arr),!              ; 1
write $$mean^STDMATH(.arr),!             ; 2.8
```

`mean` returns `""` for an empty array (no division by zero); `sum`
and `count` return `0`. The reductions read scalar leaves only —
nested subtrees are ignored, not recursed.

### 4.29 `STDXFRM` — higher-order array transforms ([detail](../modules/stdxfrm.md))

Three procedures (`map` / `filter`) and one extrinsic (`reduce`) that
modernise the standard `$ORDER`-loop idiom. The transformation is
supplied as an M expression string and evaluated via `XECUTE
"set <target>="_expr` per element — the lambda sees `value` and `key`
(and `acc`, for `reduce`) as plain locals.

```m
new a,out
set a(1)=1,a(2)=2,a(3)=3
do map^STDXFRM(.a,"value*2",.out)
; out(1)=2, out(2)=4, out(3)=6

set a(1)=2,a(2)=4,a(3)=5,a(4)=8
do filter^STDXFRM(.a,"value#2=0",.out)
; out(1)=2, out(2)=4, out(4)=8 (5 dropped)

write $$reduce^STDXFRM(.a,"acc+value",0),!     ; 19
```

Why `XECUTE` and not `@expr` indirection? YDB's `@expr` is
name-indirection (single expratom only) and rejects binary expressions
like `value*2` with `INDEXTRACHARS`. The XECUTE-based dispatch
accepts any valid M expression in scope.

### 4.30 `STDCRYPTO` — SHA + HMAC ([detail](../modules/stdcrypto.md))

OpenSSL-backed digest + MAC primitives. Twelve hex-output and
raw-byte extrinsics covering SHA-256 / SHA-384 / SHA-512 + HMAC-SHA
of each, plus an `$$available^STDCRYPTO()` probe that never raises.
Conformance: FIPS 180-4 §B for SHA, RFC 4231 §4 for HMAC.

```m
write $$sha256^STDCRYPTO("abc"),!
;   ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad

write $$hmacSha256^STDCRYPTO("Jefe","what do ya want for nothing?"),!
;   5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843

if '$$available^STDCRYPTO() set $ec=",U-MYAPP-NO-CRYPTO,"

set digestRaw=$$sha256Bytes^STDCRYPTO(payload)     ; 32 raw bytes
```

Backend: `$&stdcrypto.<fn>` → libcrypto via the YDB external-call
ABI. Deployment is the responsibility of `scripts/seed-callouts.sh`,
which compiles `src/callouts/std_crypto.c` inside the `m-test-engine`
container, stages the resulting `.so` + `tools/std_crypto.xc`, and
idempotently exports `STDLIB_LIB` + `ydb_xc_stdcrypto` into
`/etc/profile.d/ydb_env.sh`. `make seed` invokes it automatically
whenever `src/callouts/*.c` is present.

### 4.31 `STDCOMPRESS` — gzip / deflate / zstd ([detail](../modules/stdcompress.md))

Compression backed by libz (gzip, raw deflate) and libzstd (zstd
frames). Six round-trip extrinsics + an availability probe that
returns the comma-separated list of any *missing* backends:

```m
new buf,roundtrip
if '$$gzip^STDCOMPRESS("hello, world",.buf) write $ec,! quit
write $length(buf),!                            ; ~30 bytes (RFC 1952 framed)

if '$$gunzip^STDCOMPRESS(buf,.roundtrip) write $ec,! quit
write roundtrip,!                               ; "hello, world"

write $$available^STDCOMPRESS(),!               ; "" when both libs load,
                                                ; "libzstd" if zstd is missing
```

Output-by-reference (`.out`) rather than return value because
compressed payloads can run to megabytes and YDB extrinsic returns
hit per-string limits sooner than the 1 MiB cap STDCOMPRESS
documents. The function return is the success boolean; on failure
`$ECODE` carries the specific tag (`,U-STDCOMPRESS-LIBZ-FAIL,` /
`,U-STDCOMPRESS-LIBZSTD-FAIL,` / `,U-STDCOMPRESS-NOT-WIRED,`).

Same `$&stdcompress.<fn>` → libz/libzstd deployment story as STDCRYPTO.

### 4.32 `STDHTTP` — HTTP/1.1 client ([detail](../modules/stdhttp.md))

HTTP/1.1 + HTTPS client. Two layers:

1. **Pure-M wire-format helpers** — `parseStatusLine` / `parseHeader`
   / `parseResponse` / `buildRequest` / `formatHeaders`. Testable
   without a network or a compiled callout; useful for offline
   protocol work and proxy/test-double construction.
2. **libcurl callout** — `$$get` / `$$post` / `$$request` /
   `$$available` drive `src/callouts/http.c::http_perform` via the
   shared `$&pkg.fn` deployment harness.

```m
; Pure-M offline parse — no network needed
new resp
do parseResponse^STDHTTP("HTTP/1.1 200 OK"_$c(13,10)_"Content-Type: text/plain"_$c(13,10,13,10)_"hi",.resp)
write resp("status"),! resp("header","content-type"),!,resp("body"),!
;   200 / text/plain / hi

; Network call — soft-fails to NOT-WIRED if the .so isn't deployed
new resp
do get^STDHTTP("https://example.com/hello.txt",.resp)
if $get(resp("error"))="STDHTTP-NOT-WIRED" set $ec=",U-MYAPP-NO-HTTP,"
write resp("status"),! resp("body"),!
```

`$$available^STDHTTP()` is the cheap pre-flight probe; the network
extrinsics short-circuit on `$$env^STDOS("ydb_xc_stdhttp")=""` so a
missing descriptor doesn't pay the XECUTE compile cost. The pure-M
`req` / `resp` array contract is engine-neutral, shared by the
libcurl-backed transport.

### 4.33 `STDHARN` — resident test/coverage harness ([detail](../modules/stdharn.md))

The server-side half of *run-and-verify*: STDHARN runs `*TST` suites **in the
live namespace**, next to the real FileMan DD and data, and emits a
deterministic result **frame** the Go `m` client splits back through its
unchanged `mtest`/`mcov` consumers. The contract is the output frame, not the
transport — `##M-HARNESS … / ##SUITE … / ##END … / ##END-HARNESS` delimiter
lines wrap verbatim `^STDASSERT` payloads, so `mtest.ParseOutput` consumes them
with no adapter. Three entry points: `RUN^STDHARN` (read `$ZCMDLINE`, emit to
the device), `run^STDHARN` (run space-separated suites in scope), and
`cov^STDHARN` (same, wrapped in the IRIS line monitor for `##LCOV`).

Suite execution + framing are pure-M and run identically on YottaDB and IRIS;
only the `^%MONLBL` coverage probe and watch hooks are IRIS-bound. Because many
suites run in **one process**, `report^STDASSERT` must not halt — `RUN` flips
STDASSERT into no-halt mode (it stashes counts and returns); each suite is
crash-isolated, so a mid-suite error becomes a non-zero `##END exit` and the run
continues.

### 4.34 `STDHTTPMSG` — HTTP/1.1 message codec ([detail](../modules/stdhttpmsg.md))

A byte-level HTTP/1.1 message codec, identical on YottaDB and IRIS — the
portability seam the VistA-native HTTPS stack sits on, and distinct from the
libcurl-backed `STDHTTP` outbound client. It is **symmetric**: the same `REQ`/
`RSP` contract serves inbound (parse a request, serialize a response) and
outbound (serialize a request, parse a response). Five public functions:
`$$parseReq` / `$$parseRsp` (buffer → status, filling `REQ`/`RSP`),
`$$serializeReq` / `$$serializeRsp`, and `$$hdr` (case-insensitive header
lookup over `MSG("hdr",…)`).

Parse failures are **normal traffic**: `parseReq`/`parseRsp` return an HTTP
status (200 ok; 400/413/414/431 on a bad message), reserving a loud `$ECODE`
(via a flag-based `$ETRAP`, never `zgoto`) for a genuine internal fault → 500.
v0.1 is buffer-at-once — the caller owns the socket read. Size caps are
config-injected (`opts`) with safe defaults (maxline 8192, maxhdrcount 100,
maxhdrbytes 16384, maxbody 1048576), never XPAR-aware.

### 4.35 `STDHTTPD` — portable HTTP server framework ([detail](../modules/stdhttpd.md))

The engine-agnostic half of the VistA-native HTTPS stack: the route-match
engine, the middleware chain, and the per-connection worker request/response
loop — pure-M and identical on YottaDB and IRIS, sitting on the `STDHTTPMSG`
codec. Five public extrinsics plus two built-in middlewares:
`$$route(.SRV,method,pattern,handler,.opts)` registers a route,
`$$match(.SRV,method,path,.route,.params)` matches one (→ 200/404/405),
`$$use(.SRV,mwref,.opts)` registers middleware, `$$dispatch(.SRV,.REQ,.RSP,.opts)`
runs one parsed request through middleware → handler, and
`$$serve(.SRV,.TR,conn,.opts)` runs the full connection loop; `requestId` and
`noop` are the shipped middlewares.

Everything engine-sensitive is **injected**, never built in: the transport
(`$$serve` reaches the wire only through the caller's `TR` read/write entry-refs,
signatures matching STDNET), the handler/middleware `TAG^ROUTINE` refs (invoked
by indirection with a fixed by-ref signature), the caller-owned `SRV` route
table (literal + `:named` + trailing `*` patterns; first-registered wins), and
the log hook. A handler fault → 500 with a **sanitized** body; the detail goes
only to the injected `logref`. (Caught with a flag-based `$ETRAP`, never `zgoto`.)

### 4.36 `STDKV` — keyed record-store seam ([detail](../modules/stdkv.md))

The portable storage seam (**S1** of the MSL⟷VSL coordination plan): a tiny
record store addressing a value by **(collection, key, field)**. Four verbs,
all called with `$$`: `$$set^STDKV(coll,key,field,value)` →1,
`$$get^STDKV(coll,key,field,default)`, `$$exists^STDKV(coll,key)`, and
`$$kill^STDKV(coll,key)` (idempotent record removal). It is deliberately
minimal — a record store, **not** a filesystem (that stays in STDFS); any
parsing/formatting belongs in the caller.

On a bare engine STDKV is its own reference back end — records live
process-private in `^STDLIB($job,"kv",coll,key,field)`, so there is no cross-run
bleed. Above the waterline, v-stdlib's `VSLFS` binds the **identical four-verb
signature** to FileMan's DBS API (`GETS^DIQ` / `UPDATE^DIE` / …), mapping
collection→file, key→IENS, field→field number — so callers are unchanged across
back ends and the seam is real and testable with no VistA present.

### 4.37 `STDNET` — raw-TCP socket primitives ([detail](../modules/stdnet.md))

The portable socket seam (**S4** of the MSL⟷VSL plan): a thin, handle-based,
**raw-byte** TCP API any pure-M service can use on a bare engine, and that
VistA's `VSLIO` binds to the device handler (`^%ZIS` / `CALL^%ZISTCP`) above the
waterline. No C call-outs — it drives each engine's *native* socket device, with
the large YDB/IRIS divergence behind `$ZVERSION["IRIS"` arms. Eight extrinsics:
`$$available`, `$$listen(port)`, `$$boundport(id)`, `$$accept(id,timeout)`,
`$$connect(host,port,timeout)`, `$$read(id,maxlen,timeout,.buf)`,
`$$write(id,buf)`, `$$close(id)` — all `^STDNET`, all raw bytes with no record
delimiter or packet framing.

Handles are small integers; per-handle state lives in
`^STDLIB($job,"stdnet",id,*)`. The engines differ sharply: YottaDB's SOCKET
device holds many sockets per device (one process can listen + connect + accept
directly), while IRIS uses `|TCP|` accept-mode devices (the listener's first
read returns `""` on accept and *becomes* the connection — one connection per
listener; writes flush with `WRITE *-3`). Both run the single-process loopback
the suite exercises. Optional tier.

### 4.38 `STDJWT` — JWT bearer-token validation ([detail](../modules/stdjwt.md))

Resource-server-side token handling: parse a compact JWS, verify its signature,
and validate the registered claims (RFC 7519 §4.1 `exp`/`nbf`/`iss`/`aud`) the
way an OAuth 2.0 resource server must (RFC 9068). It is deliberately **not** an
authorization server — `$$sign` exists for dev/test fixtures only. Five public
extrinsics: `$$verify(token,key,.claims,.opts)` (signature + claims → 1/0,
claims by-ref), `$$decode(token,.hdr,.claims)` (parse only, no verify),
`$$claim(token,name)` (one-shot *unverified* single-claim read),
`$$sign(.claims,key,.opts)` (dev/test only), and `$$lastError()` (the last
failure reason, `""` when none).

HS256 (HMAC-SHA-256) is wired; RS256/ES256 via JWKS are the staged follow-on,
dispatched on the header `alg` — until then a non-HS256 token is **rejected,
never silently accepted**. Layer `m` (engine-neutral): it consumes STDB64,
STDCRYPTO (HMAC — an *optional* callout, so STDJWT is `@tier optional` too),
STDJSON and STDDATE; the VistA identity binding (subject → NEW PERSON `#200` /
DUZ) lives above the waterline in v-stdlib. Claims/header trees use the STDJSON
typed-node convention — read a scalar with `$$valueOf^STDJSON`. `opts` for
`$$verify`: `now` / `leeway` / `iss` / `aud` / `alg`.

### 4.39 `STDSIGV4` — AWS SigV4 request signer ([detail](../modules/stdsigv4.md))

Service-generic **AWS Signature Version 4** signer (S3 is the first consumer,
but the same module signs any AWS SigV4 REST service given the right
`service`/`region` in the `ctx`). It implements the four-step process —
canonical request, string-to-sign, the HMAC signing-key chain, and the final
signature — over m-stdlib's existing crypto primitives, with **no new crypto**:
every step maps onto a `$$…^STDCRYPTO` or `$$encode^STDHEX` call. Key
extrinsics: `$$authHeader(...)` (the full `Authorization` header value),
`$$sign(...)` (64-char hex signature), `$$signingKey(secret,date,region,service)`
(raw 32-byte key), `$$canonRequest(...)`, plus the helpers `$$encPath` /
`$$encQuery` / `$$amzDate` / `$$emptyHash` — all `^STDSIGV4`. Optional tier.

**Byte-mode correctness matters here:** the signing-key chain passes raw 32-byte
HMAC outputs as the key to the next HMAC (steps 1–3 use the `…Bytes` crypto
variants; only step 4 emits hex). Under `ydb_chset=UTF-8` those raw-byte keys
re-encode and silently produce a *wrong* signature — run the engine in byte (M)
mode, the m-stdlib default. Missing the crypto callout raises
`U-STDCRYPTO-CALLOUT-MISSING`.

### 4.40 `STDS3` — AWS S3 REST client ([detail](../modules/stds3.md))

A thin, portable reimplementation of the S3 REST slice an SDK (boto3) would
otherwise generate: **build the request, sign it with `STDSIGV4`, hand the bytes
to `STDHTTP`.** Every entry point takes an explicit credential context `ctx`
(accessKey / secretKey / region / service, plus optional sessionToken) by
reference — no ambient config — and returns an integer HTTP status (`0` on
transport failure, mirroring STDHTTP). The op set: `$$putObject` / `$$getObject`
/ `$$headObject` / `$$deleteObject` / `$$listObjectsV2`, plus full multipart
(`$$createMultipart` → uploadId, `$$uploadPart`, `$$completeMultipart`,
`$$abortMultipart`) — all `^STDS3`. Optional tier.

**Addressing:** virtual-hosted-style
(`<bucket>.s3.<region>.amazonaws.com`) by default; an `opt("endpoint")` override
switches to path-style (`<endpoint>/<bucket>/<key>`) — exactly what MinIO /
LocalStack and any S3-compatible store want, and the no-code-change hook the
testbed rides on. The endpoint override reaches `buildRequest` on **all** ops
(so round-trips work, not just PUT). This is the engine-neutral S3-egress half
of the RPC+HL7→S3 VistA traffic-tap stack.

## 5. Living, executable examples

Beyond the hand-written `tests/*TST.m` suites — which prove *correctness* — every
module ships a generated, self-verifying **example program** that proves the
public surface is completely and truthfully documented, and re-runs it on real
engines.

- **Source → generated.** Example programs are generated from each public
  label's `; doc: @example` tags. `make examples` emits one
  `examples/programs/<MODULE>EX.m` per module plus the front-door
  [`examples/index.md`](../../examples/index.md); both are **drift-gated**
  (`make examples-check`). Coverage is gated at 100 % of public labels
  (`make examples-coverage`) — every label has an executable example or an
  explicit `@illustrative` exemption, and every documented `@raises` is
  demonstrated (`@raisesnodemo` exempts the few not triggerable on a healthy
  engine): **344/344 labels, 111/111 `@raises` accounted**.
- **Executed, two tiers**, through the driver stack only:
  - **Bare (gating):** `make examples-run` runs the example programs on **both**
    bare engines — `m-test-engine` (YDB) and `m-test-iris` (IRIS) — every PR.
  - **Live (cadence):** `make examples-run-live` runs them on the live VistA
    engines (`vehu` + `foia`) nightly, fail-soft, with a pre/post **residue
    check** (an owned-global fingerprint via `$QUERY`) proving the shared engine
    came back byte-identical. Each run regenerates
    [`examples/REPORT.md`](../../examples/REPORT.md) — the snapshot of the
    examples passing on real engines.
- **Per-module engine scope** is declared in source by two routine-header tags:
  `@exrun` (`dual` | `bare` | `bare-ydb` | `ydb` | `live` — which engine tier
  runs the module's examples) and `@exsafe` (`read-only` | `transactional` |
  `illustrative-skip` — the live side-effect class the residue check enforces).
  A few modules are YDB-only at the example tier (`STDCSPRNG` / `STDCOMPRESS` /
  `STDHARN` — their IRIS-bare backends are absent), tagged `@exrun ydb`.

Eighteen doc-comment tags drive the manifest, skill, docs, and examples; the
tag registry is the shared [`tools/mdoc/tags.py`](../../tools/mdoc/tags.py)
plus this repo's extras in [`tools/mdoc_config.py`](../../tools/mdoc_config.py).

## 6. Cross-references

- [m-tdd-guide.md](m-tdd-guide.md) — operational TDD guide for projects building tests on top of m-stdlib's seven m-cli-integrated TDD primitives (STDASSERT / STDFIX / STDMOCK / STDSEED / STDPROF / STDSNAP / STDENV).
- [comprehensive-testing.md](comprehensive-testing.md) — the full test + examples + quality matrix across both libraries and both engines.
- [modules/index.md](../modules/index.md) — canonical module inventory; one row per shipped module with conformance corpus + cross-module dependency map.
- [module-tracker.md](../module-tracker.md) — single-source-of-truth tracker for shipped, in-flight, and proposed modules; live ToDo board.
- [discoveries.md](../discoveries.md) — open toolchain bugs with severity, status, and resolution path.

## History & further reading

- [module-tracker.md](../module-tracker.md) — per-module status, closed-ticket archaeology, and proposed future modules.
- [changelog.md](../changelog.md) — release history (one entry per tag).
- [plans/completed/](../archive/) — the completed planning specs behind the library, including [`m-stdlib-implementation-plan.md`](../archive/m-stdlib-implementation-plan.md) (per-module specs + acceptance gate) and [`tdd-orchestration-plan.md`](../archive/tdd-orchestration-plan.md) (the cross-project TDD-orchestration plan, now realised). The living-examples generator replaced an earlier generated-doctest path (`tests/*DOCTST.m`), now retired.
