---
title: m-stdlib — 5-minute quick start
status: live
created: 2026-06-24
last_modified: 2026-06-24
revisions: 2
doc_type: [GUIDE]
---

# m-stdlib — 5-minute quick start

The fastest path from zero to calling `STD*` code. For the deep reference see
[`users-guide.md`](users-guide.md); for the TDD workflow see
[`m-tdd-guide.md`](m-tdd-guide.md); for the full per-symbol surface load the AI
skill ([`../../dist/skill/SKILL.md`](../../dist/skill/SKILL.md)) or browse
[`../modules/index.md`](../modules/index.md).

## 1. Get the toolchain + an engine (2 min)

m-stdlib is pure-M source — there's nothing to compile. You need the Go **`m`**
toolchain (one static binary, built from
[m-cli](https://github.com/vista-forge/m-cli)) and a YottaDB engine.

```bash
# Build the `m` toolchain (one binary; no venv)
git clone https://github.com/vista-forge/m-cli ~/vista-forge/m-cli
( cd ~/vista-forge/m-cli && go build -o dist/m . )

# Start the test engine (byte mode is the default in the Makefile)
docker run -d --name m-test-engine m-test-engine:0.3.0-local
```

> **Run the engine in byte (M) mode** (`ydb_chset=M`). m-stdlib is byte-oriented;
> the `make` targets already pass `--chset m`. m-stdlib is verified **dual-engine**
> — IRIS portability runs against a second container (`m-test-iris`,
> `intersystemsdc/iris-community`), reached the same way (`--docker m-test-iris`).

## 2. Run the suite (30 sec)

```bash
cd ~/vista-forge/m-stdlib
make test M=~/vista-forge/m-cli/dist/m     # core suites, dependency-free
```

`make check` adds fmt + lint + the engine-free drift gates;
`make test-optional` runs the callout-backed tier (STDCRYPTO / STDCOMPRESS /
STDHTTP — needs the compiled `.so` libs); **`make examples-run`** executes the
generated living-example programs (one per module, from the `@example` tags) on
**both** bare engines (m-test-engine YDB + m-test-iris IRIS).

## 3. Call something (1 min)

Stage `src/` on the routine path, then call a public label. A taste — parse JSON
and emit a structured log line:

```m
; parse-then-walk: each node carries a one-char sigil (o/a/s:/n:/t/f/z)
new tree
if '$$parse^STDJSON("{""hello"":""world""}",.tree) write "bad json",! quit
write $$valueOf^STDJSON(.tree("hello")),!          ; "world"

; structured key=value logging
do LEVEL^STDLOG("INFO")
do INFO^STDLOG("login","user","alice","ip","1.2.3.4")
```

For copy-paste idioms across the high-frequency modules (STDASSERT, STDFIX,
STDLOG, STDJSON, STDURL, STDCSV, STDDATE, STDCSPRNG, …) see the pattern library
in the skill ([`../../dist/skill/patterns.md`](../../dist/skill/patterns.md)),
and runnable demos under [`../../examples/`](../../examples/).

## 4. Write your first test (1 min)

Tests use `m test` + `^STDASSERT` (not OSEHRA `%ut`). The minimal suite the
runner discovers:

```m
MYMODTST  ; Test suite for MYMOD.
        new pass,fail
        do start^STDASSERT(.pass,.fail)
        do tRoundTrips(.pass,.fail)
        do report^STDASSERT(pass,fail)
        quit
        ;
tRoundTrips(pass,fail)  ;@TEST "parse round-trips"
        new tree
        do eq^STDASSERT(.pass,.fail,$$parse^STDJSON("[1,2,3]",.tree),1,"parse ok")
        quit
```

```bash
make test M=… TESTS=tests/MYMODTST.m
```

## 5. Where next

- **The deep reference:** [`users-guide.md`](users-guide.md) (the 30-minute read).
- **Run everything (both engines, both libraries):** [`comprehensive-testing.md`](comprehensive-testing.md)
  — the full suites + executable examples + quality/maintenance gates for m-stdlib
  *and* v-stdlib on YDB *and* IRIS.
- **Living, executable examples:** [`../../examples/index.md`](../../examples/index.md)
  — a runnable, self-verifying example for every public label (generated from the
  `@example` tags). The last live run, [`../../examples/REPORT.md`](../../examples/REPORT.md),
  shows them passing on real engines (`vehu` + `foia`) with a byte-identical
  residue check.
- **Per-module API:** [`../modules/index.md`](../modules/index.md) (every module,
  generated from source).
- **The VistA-specific sibling:** [v-stdlib](https://github.com/vista-forge/v-stdlib)
  (`VSL*`, layer `v`) binds Kernel / FileMan / XPAR / Broker to this base.
