---
created: 2026-04-30
last_modified: 2026-07-18
revisions: 44
doc_type: [CHANGELOG]
---

# Changelog

All notable changes to m-stdlib are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); the project
adheres to [Semantic Versioning](https://semver.org/). Pre-1.0 minor
versions may include breaking changes.

**Reading model.** Each entry below is a thin index — a one-paragraph
headline plus bullet pointers into the canonical sources (tracker
tickets, per-module History sections, discoveries register). The
deep implementation narrative lives in those sources, not duplicated
here. See [`README.md`](README.md) § Bucket 4 for the rationale.

## [Unreleased]

Work landed on `main` since the v0.13.0 tag, staged as planned versions.
The manifest's `stdlib_version` stays anchored to the last SHIPPED tag —
a version-bearing heading marked pending/unreleased is a hard
`gen-manifest` error (stdlib-doc-accuracy W1).

### v0.15.0 (planned) — STDCRYPTO asymmetric signature verify — RS\*/PS\*/ES\* + EdDSA, the JWT/JWS foundation

**`STDCRYPTO` gains public-key signature *verification*** — one verb,
`$$verifySig^STDCRYPTO(alg,pubKey,msg,sig)` → `1|0`, plus `$$verifyRs*/Ps*/Es*` +
`$$verifyEdDSA` sugar and a symbol-specific `$$verifyAvailable` probe. This is the
engine-neutral critical-path leaf the asymmetric-JWT auth stack (STDJWT asym leg →
VSLJWT → `XUS JWT LOGON` → VWEB) sits on; STDJWT's non-HS256 rejection can now be lifted.

- **Scope:** all JWS families — RS256/384/512 (PKCS1-v1_5), PS256/384/512 (RSASSA-PSS),
  ES256/384/512 (ECDSA P-256/384/521), and EdDSA (Ed25519). **Dual-engine GREEN 53/53**
  on YDB (m-test-engine, `crypto_verify` libcrypto callout) and IRIS (foia-t12 +
  m-test-iris, native `$SYSTEM.Encryption` `RSASHAVerify`/`RSASSAPSSVerify`/`ECSHAVerify`).
  **EdDSA is YDB-only** — IRIS exposes no CFRG method, so `$$verifySig("EdDSA",…)` raises
  `BADALG` there (a visible, fail-closed, tracked skip — never a silent gap).
- **ES\* signature form** is the JWT `R‖S` fixed-width concatenation (RFC 7518 §3.4;
  P-521 halves are 66 bytes, not 64), converted to a DER `SEQUENCE{r,s}` before verify
  (in C on YDB, in M `$$rsToDer` for the IRIS `ECSHAVerify` arm). PSS params (padding,
  MGF1, saltlen=hlen) set explicitly. Validated against RFC 7515 §A.3, RFC 8037 §A.1,
  scripted OpenSSL PS/ES vectors, and Wycheproof-class negatives (r=0/s=0, truncated,
  odd-length, wrong-curve, bit-flip).
- **Verify-only, key-agnostic, JWT-agnostic** (SPKI DER or PEM in; no signing, no
  private keys). Security contract: STDCRYPTO does NOT defend against algorithm
  confusion by design — the caller (STDJWT) owns alg policy (`src/STDCRYPTO.m`
  security-contract note; finding N-1).
- Disjoint C error channel (`-10/-11/-12`) + `-99` `$ETRAP` sentinel via a
  dedicated `dispatchV` (rc=0 = invalid, not success — N-3); Phase-0 findings in
  [`docs/design/stdcrypto-asymmetric-verify-design.md`](design/stdcrypto-asymmetric-verify-design.md).
- Pointers: tracker **T32** ([`module-tracker.md`](module-tracker.md)); proposal
  [`stdcrypto-asymmetric-verify-v2.md`](proposals/stdcrypto-asymmetric-verify-v2.md);
  `test-optional`/`coverage-optional` now gate in CI (`seed-engine-callouts` bridges
  the pinned-image symbol gap; discoveries 2026-07-09).

### v0.14.0 (planned) — STDSIGV4 + STDS3 — AWS S3 egress for the VistA traffic tap

**AWS S3 egress lands as `STDSIGV4` + `STDS3`, the engine-neutral half of the
RPC+HL7→S3 traffic-tap stack** ([`rpc-traffic-s3-streaming-implementation-plan.md`
Phase 1](https://github.com/vista-forge/docs/blob/main/proposals/implemented/rpc-traffic-s3-streaming-implementation-plan.md)).
A pure-M reimplementation of the thin S3 REST + SigV4 slice an SDK (boto3) would
generate, so a VistA M process can sign and ship objects to S3 with no SDK and no
new crypto — every signing step maps onto an existing `STDCRYPTO`/`STDHEX` call.

- **`STDSIGV4`** (`@tier optional`, depends on STDCRYPTO): the service-generic AWS
  Signature Version 4 signer — `$$signingKey` (the raw 32-byte HMAC key chain),
  `$$sign`/`$$authHeader`, `$$canonRequest`, `$$encPath`/`$$encQuery`, `$$amzDate`,
  `$$emptyHash`. The signing-key chain keys each HMAC on **raw bytes** (the `…Bytes`
  crypto variants); only the final signature is hex — the classic SigV4 bug, made
  exact by m-stdlib's mandatory byte mode (`ydb_chset=M`). Anchored by AWS's
  **published known-answer vectors**: the S3 GET-Object signature and
  canonical-request hash match byte-for-byte (the G-SIGV4 gate, the plan's
  highest-value test).
- **`STDS3`** (`@tier optional`, depends on STDHTTP): the S3 REST client —
  `$$putObject`/`$$getObject`/`$$headObject`/`$$listObjectsV2`/`$$deleteObject` plus
  the multipart trio; a **path-style `endpoint` override** points the same code at
  MinIO/LocalStack with no change (the local-S3-equivalent testbed). The request
  assembly (`$$buildRequest`/`$$host`/`$$url`/`$$canonUri`) and the response
  parsers (`$$parseError`/`$$parseList`, via STDXML) are testable without a network.
  Host is **signed but never sent** (the HTTP client adds it from the URL; IRIS
  `%Net.HttpRequest` errors if Host is set by hand — see discoveries 2026-06-19).
- **MinIO testbed:** `scripts/s3-testbed.sh {up|down|status}` stands up a local
  S3-compatible sink reachable by name from both engine containers; the round-trip
  suite `STDS3MINIOTST` runs via a dedicated `make test-s3` target (not core /
  not default-optional — it needs an external MinIO **and** engine HTTP egress).
- **Verification:** `STDSIGV4TST` **16/16** + `STDSIGV4DOCTST` **2/2** +
  `STDS3TST` **18/18** dual-engine GREEN (bare YDB m-test-engine + bare IRIS
  m-test-iris, `--chset m`); core `make check` + `make coverage` (93.2% aggregate)
  unaffected. **Live signed PUT→MinIO returns 200 on IRIS** (real egress proven
  end-to-end). The round-trip read-back is **blocked on engine HTTP egress** —
  YDB (`m-test-engine`) lacks the `stdhttp`/libcurl callout; IRIS `%Net` fails
  `Send()` for signed bodyless requests — both logged as P1 discoveries
  (2026-06-19). Registered in `OPTIONAL_MODULES`/`OPTIONAL_SUITES` + the new
  `INTEGRATION_SUITES`.

## [v0.13.0] — 2026-06-18 (STDJWT bearer-token validation + STDDATE epoch)

**JWT/JOSE bearer-token validation lands as `STDJWT` (HS256), the engine-neutral
half of the VSL/MSL auth stack (M6.5).** A new resource-server-side token module
— parse a compact JWS, verify the HMAC-SHA-256 signature, and validate the RFC
7519 §4.1 registered claims (`exp`/`nbf`/`iss`/`aud`) the way an OAuth 2.0
resource server must (RFC 9068). This is the deliberate waterline split for VistA
HTTPS auth: **token validation is engine-neutral and lives here in `m`**; the
VistA identity binding (a validated subject → NEW PERSON #200 / DUZ) lives above
the waterline in v-stdlib. Promoted from `future-modules-plan` A5/item 3 the
moment TDD-red was staked.

- **`STDJWT`** (`@tier optional`, depends on STDCRYPTO HMAC): `$$verify`
  (signature + claims; clock injected via `opts("now")`, `opts("leeway")` for
  skew, `opts("iss")`/`opts("aud")` enforced), `$$decode` (inspect-only, no
  trust), `$$claim` (one-shot unverified read), `$$sign` (DEV/TEST fixtures
  only — **not** a production issuer), `$$lastError`. A non-HS256 `alg` is
  **rejected, never silently accepted** — RS256/ES256 via JWKS are the staged
  follow-on behind the same `alg` dispatch (gated on the STDCRYPTO public-key
  signature ticket). `@seam STDJWT`.
- **Constant-time compare** (`future-modules` A3 `$$ctEquals`) ships **private to
  STDJWT** (`cteq`) for the signature comparison; promote it to a public
  `$$ctEquals^STDCRYPTO` when a second consumer needs it.
- **`$$epoch^STDDATE`** — current time as UTC Unix epoch seconds, the JWT
  `exp`/`nbf` clock. Engine-split identically to `$$now` (YDB subtracts the
  `$ZHOROLOG` tz piece; IRIS reads `$ZTIMESTAMP`).
- **Dual-engine GREEN:** STDJWTTST **28/28** + STDDATETST **72/72** on bare YDB
  (m-test-engine, `--chset m`) and bare IRIS (m-test-iris). STDJWT runs under
  `make test-optional` (HMAC callout), registered in `OPTIONAL_MODULES`/
  `OPTIONAL_SUITES`.

## [v0.12.2] — 2026-06-17 (STDNET IRIS peer-closed read drains + EOFs)

**`$$read^STDNET` on IRIS no longer kills the job when the peer has closed.**
Bugfix for the *second* IRIS socket gap, found by v-web M6.3's repin session
once the v0.12.1 CRLF fix let the IRIS serve tests run: a `$$read^STDNET`
against a socket whose **peer has already closed** raised an IRIS `<DSCON>`-class
disconnect that **killed the whole job** (aborting the test suite to 0/0) —
*not* a flag-`$ETRAP`-catchable M error — instead of returning the buffered
bytes and then EOF. This breaks the normal HTTP-client pattern (after a server
sends its response and does `Connection: close`, the client's read of that
response hits a peer-closed socket). YDB already drains + EOFs correctly and is
**unchanged**.

- **Fix (IRIS arm only):** `readIris` now runs its byte-at-a-time drain loop
  under an ObjectScript `try { … } catch { }` (the same disconnect-trap idiom
  `invoke^STDHTTPD` uses for IRIS faults — flag-`$ETRAP`/`$zstatus` does **not**
  catch IRIS disconnects). A peer close now yields the already-buffered bytes
  and then a clean `0`/EOF return. The loop body is byte-identical to v0.12.1
  (`read *c:t`, CRLF-safe, byte-exact); only the disconnect trap is added, and
  the whole loop is `xecute`-hidden so the YDB compiler never sees the
  ObjectScript braces.
- **No contract change** — same six `@seam STDNET` verbs, identical signatures;
  `make check-seams` clean (5 seams, no `contract_version` bump). Behavior fix.
- **New regression test** `tPeerClosedDrainsThenEof` in `STDNETTST`: the peer
  writes a few bytes then `$$close`s; the read side must return those bytes,
  then `0` (EOF), **without aborting**. Red-first: the suite **aborted to 0/0 on
  IRIS** and passed on YDB before the fix; now **GREEN 22/22 on BOTH** engines
  (`m-test-engine` YDB byte-mode + `m-test-iris`).
- **Unblocks v-web M6.3's IRIS read-back** — after this lands and MSL is
  re-tagged + repinned, v-web can drop the `'$zversion["IRIS"` arm of its static
  `readbackSafe()` gate and `tServeHealthOverSocket` goes green on IRIS, making
  the M6.3 serve vertical fully dual-engine. Tag/release **MSL v0.12.2** is a
  user action. Module-tracker row 34;
  [`docs/modules/stdnet.md`](../modules/stdnet.md).

## [v0.12.1] — 2026-06-17 (STDNET IRIS raw-read CRLF fix)

**`$$read^STDNET` on IRIS is now byte-exact — CR/LF no longer stripped.**
Bugfix for a latent defect in the v0.12.0 IRIS socket leg, found by v-web M6.3:
`readIris` read with `read x#maxlen:timeout` on the `|TCP|` device, which is a
**CR-terminated read** — it stopped at the first CR (char 13) and stripped the
CRLF, so binary/HTTP data carrying `\r\n` was corrupted (`$$serve^STDHTTPD`
never saw the `\r\n\r\n` request terminator and returned 400 over an IRIS
socket). The IRIS arm now reads **one byte at a time** with `read *c:t` (a
single-character read that never interprets a terminator) and accumulates up to
`maxlen` — the first read waits up to `timeout`, follow-on bytes drain with a
zero timeout, so it returns exactly the available raw bytes. The YDB path
(`read x#n:t`, already raw) is unchanged.

- **No contract change** — same six `@seam STDNET` verbs, identical signatures;
  `make check-seams` clean (5 seams, no `contract_version` bump). This is a
  behavior fix, not an API change.
- **New regression test** `tCrlfByteExact` in `STDNETTST` writes a CRLF-bearing
  payload (`GET /x\r\nH: y\r\n\r\n` plus a lone CR and a lone LF) and asserts
  byte-exact round-trip (length + `$ascii` per position). Red-first: FAILED on
  IRIS (13/16) and passed on YDB before the fix; now **GREEN 16/16 on BOTH**
  engines (`m-test-engine` YDB byte-mode + `m-test-iris`).
- **Unblocks v-web M6.3's IRIS serve vertical** — v-web's `$$rawByteSafe()`
  probe auto-heals its soft-skipped IRIS serve tests once this lands and MSL is
  re-tagged + repinned. Tag/release **MSL v0.12.1** is a user action.
  Module-tracker row 34; [`docs/modules/stdnet.md`](../modules/stdnet.md).

## [v0.12.0] — 2026-06-17 (VSL/MSL M2.T1 — STDNET IRIS leg)

**The STDNET IRIS socket leg lands — `STDNET` is now dual-engine (M2.T1).**
Closes the owed M2 tail: `STDNET`'s IRIS raw-socket backend, so
`$$available^STDNET()` is now **1 on both engines** and the **loopback echo
suite is GREEN 9/9 on YottaDB *and* IRIS** (it previously soft-skipped on IRIS
with `$$available`=0). The IRIS arm uses a `|TCP|` accept-mode device — first
`READ ""` accepts and the listener handle *becomes* the connection; `WRITE *-3`
flushes; the `$ZUTIL`/`LocalPort()` query is `xecute`-hidden so the YDB
compiler never sees the IRIS-only intrinsic — behind the established
`$ZVERSION["IRIS"` fork (no change to the YDB path). The `@seam STDNET`
signatures are unchanged (same six verbs), so the bump-forcer stays green
(seam-snapshot still 5 seams); only the manifest synopsis (`$$available`
returns 1 on both) is regenerated. `m arch check` layer **m** / **G2** clean.

- **Loopback echo GREEN 9/9 on BOTH engines** (YDB `m-test-engine` + IRIS
  `m-test-iris`), verified on the merged `master` 2026-06-17. Full suite no
  regression. `STDNET` stays `@tier optional` (engine-sensitive; excluded from
  the core `make test`/aggregate-coverage set).
- This **unblocks M6.3** (the `vweb` listener — the IRIS leg of the inbound
  socket adapter could not run while IRIS sockets were unwired). Implemented on
  branch `m2t1-stdnet-iris` (2026-06-16); landed onto `master` 2026-06-17.
- Tag/release **MSL v0.12.0** is a user action (so `vweb`/M6.3 pins a STDNET
  with IRIS sockets). Module-tracker row 34 (M2.T1 ☑) +
  [`docs/modules/stdnet.md`](../modules/stdnet.md).

## [v0.11.0] — 2026-06-17 (VSL/MSL M6.2)

**The portable HTTP server framework — `STDHTTPD` (VSL/MSL M6.2, the §4/§6
engine-agnostic half of the VWEB capstone).** Adds the **fifth `@seam`** and a
new module: `STDHTTPD`, a pure-M, dual-engine HTTP **server framework** that
sits on the M6.1 `STDHTTPMSG` codec and below the VistA `vweb` listener
(M6.3+). Three parts: a **router** (`$$route` registers method+pattern+handler
into a caller-owned `SRV` array; `$$match` extracts `:named` segments → 404 on
no match / 405 + `Allow` on a method mismatch; literal + `:named` + trailing
`*`, trailing-slash-insensitive, first-registered-wins); a **middleware chain**
(`$$use` registers ordered `TAG^ROUTINE` refs run before the handler, any may
short-circuit via `CTX("stop")`); and the **worker request/response loop**
(`$$serve` reads a complete request over an **injected transport**, frames it
honoring Content-Length / chunked, `$$parseReq^STDHTTPMSG` → middleware →
`$$match` → handler → `$$serializeRsp^STDHTTPMSG` → write, looping keep-alive
until close / idle / max-requests). `$$dispatch` runs one request; an uncaught
handler/middleware fault → **500** with a sanitized body, detail only to an
**injected log hook**. No sockets, no TLS, no VistA, no FileMan, no XPAR, no
`$ZF` — the transport, route data, limits, and log hook are all injected, so
the engine-sensitive socket handoff stays in `VWEBL` (M6.3).

- **dual-engine GREEN 39/39** (YottaDB m-test-engine + IRIS m-test-iris); cov
  93.3% (STDHTTPD), aggregate 93.24%; full suite 48/2557/0 — no regression.
- `@seam STDHTTPD` — **seam-snapshot now 5 seams**, bump-forcer green (new seam,
  contract_version 1); 4 drift gates + check-kids green (not in the MSL base).
- Three engine gotchas captured ([`docs/memory/m6.2-stdhttpd.md`](../memory/m6.2-stdhttpd.md)):
  YDB rejects `do/$$ @ref(args)` (→ full-argument indirection); IRIS fault-trap
  needs `try/catch`+`$zerror` not flag-`$ETRAP`/`$zstatus` (fork on
  `$zversion["IRIS"`); `quit <val>` from a DO-frame aborts (→ `$quit`-aware).
- Tag/release **MSL v0.11.0** is a user action (so M6.3's `vweb` can pin
  `seams.STDHTTPD`). See module-tracker row 37.

## [v0.10.0] — 2026-06-17 (VSL/MSL M6.1)

**The HTTP/1.1 codec seam — `STDHTTPMSG` (VSL/MSL M6.1, the §5 portability
seam of the VWEB capstone).** Adds the **fourth `@seam`** and a new module:
`STDHTTPMSG`, a pure-M, dual-engine HTTP/1.1 parse+serialize codec — five
extrinsics `$$parseReq` / `$$parseRsp` / `$$serializeReq` / `$$serializeRsp`
/ `$$hdr` implementing the `REQ`/`RSP` data contract that every layer above
the socket (STDHTTPD, VWEBR, the D5 conformance suite) binds to byte-for-byte.
It is **buffer-at-once** (the listener owns the socket read loop; a streaming
pull/feed parser is a deferred §15 extension), takes **injected size caps**
(never XPAR-aware), and treats a malformed message as **normal traffic** —
returning an HTTP status code (400/413/414/431), not `$ECODE`; a loud `$ECODE`
(flag-based `$ETRAP`, never zgoto) is reserved for a genuine internal fault.
No sockets, no TLS, no VistA, no `$ZF` — it is the byte-level codec, distinct
from the libcurl-backed `STDHTTP` outbound client. Also adds
**`$$httpdate^STDDATE`** (the RFC 7231 IMF-fixdate the `Date` header needs;
`STDDATE.strftime` lacked weekday/month names), so the MSL KIDS base
(`dist/kids/MSL.kids`, which carries `STDDATE`) is regenerated.

- **dual-engine GREEN 66/66** (YottaDB m-test-engine + IRIS m-test-iris),
  byte-exact, no `$ZVERSION` arm; coverage 97.3% (STDHTTPMSG), aggregate 93.2%.
- Tracker: [`module-tracker.md`](module-tracker.md) row 36 (STDHTTPMSG) + the
  STDDATE row (`$$httpdate`). Memory: `../memory/m6.1-stdhttpmsg.md`.
- Gotcha captured: passing a **subscripted node** (`.RSP("json")`) by reference
  into `$$encode^STDJSON` loses the subtree on IRIS (the `irisEncode` xecute
  chain) — copy to a top-level local (`merge jnode=RSP("json")`) first.
- The git **tag/release ceremony stays a user action**; the `vweb` consumer
  (M6.3+) pins `v0.10.0:dist/seam-snapshot.json` `seams.STDHTTPMSG`.

## [v0.9.0] — 2026-06-16

**The portable storage seam — `STDKV` (VSL/MSL M3 Lane A).** This release adds
the **third `@seam`** and a new minimal module: `STDKV`, a keyed record store
addressing a value by `(collection, key, field)` with four extrinsic verbs —
`$$set` / `$$get` / `$$exists` / `$$kill`. It resolves design Q3 — the storage
seam is its own module, **not** a `STDFS` sub-API (a record store is distinct
from filesystem path/byte I/O), so `STDFS` stays filesystem-only. On a bare
engine `STDKV` is its own reference back end (a process-private
`^STDLIB($job,"kv",…)` global); `v-stdlib`'s `VSLFS` adapter (M3, the S1 seam)
binds the same four-verb signature to VistA's FileMan DBS above the m/v
waterline (`coll`→file, `key`→IENS, `field`→field number). All four verbs carry
`; doc: @seam STDKV`, so the `seams.STDKV` block (`contract_version: 1`, 4 entry
points) now appears in [`dist/stdlib-manifest.json`](../../dist/stdlib-manifest.json)
and its [`dist/seam-snapshot.json`](../../dist/seam-snapshot.json) projection;
the bump-forcer is green (a newly-introduced seam needs no `contract_version`
bump). `v-stdlib` re-pins this git ref (`msl_ref` v0.8.0→v0.9.0).

- **Dual-engine GREEN 12/12** — `STDKVTST` passes on both YottaDB
  (`m-test-engine`) and IRIS (`foia-t12`), including byte-fidelity (control and
  high bytes round-trip exact). No `$ZVERSION` arm — pure global I/O is portable
  as-is. CORE suite: full `make test` is 46 suites / 2448 assertions, no
  regression.
- Module-tracker row 35 + [`docs/modules/stdkv.md`](../modules/stdkv.md).

## [v0.8.0] — 2026-06-16

**The portable socket seam — `STDNET` (VSL/MSL M2 Lane A).** This release adds
the **second `@seam`** and the most engine-sensitive module in the library (R1):
`STDNET`, a thin handle-based **raw-byte TCP** API over each engine's *native
socket device* — no C call-outs — which `v-stdlib`'s `VSLIO` adapter (M2, the S4
seam) binds to VistA's device handler (`^%ZIS` / `CALL^%ZISTCP`) above the m/v
waterline. The six side-effecting verbs (`listen`/`accept`/`connect`/`read`/
`write`/`close`) carry `; doc: @seam STDNET`, so the `seams.STDNET` block
(`contract_version: 1`, 6 entry points) now appears in
[`dist/stdlib-manifest.json`](../../dist/stdlib-manifest.json) and its
[`dist/seam-snapshot.json`](../../dist/seam-snapshot.json) projection; the
bump-forcer is green (a newly-introduced seam needs no `contract_version` bump).
`v-stdlib` re-pins this git ref (`msl_ref` v0.7.0→v0.8.0) to consume the
signature.

- **YottaDB loopback echo GREEN 9/9** on `m-test-engine` — a single process
  opens a listener, connects a client, accepts, and round-trips a byte string
  end to end (the GT.M/YDB `SOCKET` device is a collection of sockets, so one
  process can `listen` + `connect` + `accept`; `WRITE /WAIT` auto-accepts).
- **`@tier optional`** — engine-sensitive + partial-engine, excluded from core
  `make test`/aggregate coverage. **IRIS deferred**: `$$available^STDNET()=0`,
  the suite soft-skips green (the `STDHTTP` soft-fail posture); the `|TCP|`-device
  + `JOB`'d-connector loopback is the owed follow-up, live-verified on
  `m-test-iris`. `m arch check` layer **m** / **G2** clean (no VistA symbols).
  See [`docs/memory/m2-stdnet-socket-seam.md`](../memory/m2-stdnet-socket-seam.md)
  and [`docs/modules/stdnet.md`](../modules/stdnet.md).
- Tag: `v0.8.0`. Compare: `v0.7.0..v0.8.0`.

## [v0.7.0] — 2026-06-15

**The first real seam contract — `STDENV` config-read (VSL T1.1).** This
release carries the **first non-empty `@seam`**: the config-READ primitive
`$$get^STDENV(env,key,default)` is tagged `; doc: @seam STDENV`, so the
`seams.STDENV` block (`contract_version: 1`) now appears in
[`dist/stdlib-manifest.json`](../../dist/stdlib-manifest.json) and its
[`dist/seam-snapshot.json`](../../dist/seam-snapshot.json) projection — the
first time the T0b.3 drift-gate machinery runs against live data instead of
the frozen-empty `v0.6.0` baseline. This is the MSL side of the **M1
walking-skeleton vertical** (`STDENV → VSLCFG → VPNG`); `v-stdlib`'s `VSLCFG`
adapter (T1.2) binds this seam to VistA's XPAR. Per [§6 of the coordination
plan](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md),
the **library SemVer** (this tag) and the **seam-contract version** (the
per-seam integer inside the manifest) remain separate axes; `v-stdlib`
re-pins this git ref to consume the real signature.

- **First real `@seam` (VSL T1.1).** The seam is deliberately minimal —
  only the config-read entry point the `VSLCFG` adapter actually binds
  (`$$get^STDENV`); the typed accessors and `has` are excluded. STDENV
  behaviour is unchanged (a doc-comment-only change); the bump-forcer is
  green because a newly-introduced seam needs no `contract_version` bump.
  See [`docs/memory/t1.1-stdenv-seam.md`](../memory/t1.1-stdenv-seam.md).
- Tag: `v0.7.0`. Compare: `v0.6.0..v0.7.0`.

## [v0.6.0] — 2026-06-15

**Dual-engine portability + the VSL/MSL substrate (Phase A/B) + the four
drift gates — and the frozen seam-contract baseline (VSL T0b.4).** This
release tags the MSL state that the VistA Standard Library (`v-stdlib`)
pins against: the `STD*` base is dual-engine (YottaDB + IRIS), the CI
substrate is standardized, and the registry-driven seam contract is wired
and **frozen as the v0.6.0 baseline** — empty today (no `@seam` tags yet;
the first real seam, `STDENV`, arrives in a later release), so the
`seams` block in [`dist/stdlib-manifest.json`](../../dist/stdlib-manifest.json)
and [`dist/seam-snapshot.json`](../../dist/seam-snapshot.json) are `{}` at
this tag. Per [§6 of the coordination plan](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-coordination-implementation-plan.md),
the **library SemVer** (this tag) and the **seam-contract version** (the
per-seam integer inside the manifest) are deliberately separate axes;
`v-stdlib` pins this git ref.

- **Seam contract FROZEN as the v0.6.0 baseline (VSL T0b.4).** The four
  registry-driven drift gates (`@seam`→seams + bump-forcer, `@icr`/DBIA,
  citation provenance, namespace registry) are green-on-empty and
  red-on-violation; the contract is now a stable, pinnable artifact.
  Built in T0b.3 (`tools/seam_contract.py` et al.); see
  [`docs/memory/t0b3-drift-gates.md`](../memory/t0b3-drift-gates.md).
- **Dual-engine IRIS portability (VSL T0b.2).** The `STD*` base installs
  via KIDS and tests in place on both engines (17/17 suites, 1483
  assertions, YDB `vehu` + IRIS `foia`). Closed IRIS-portability fixes
  (all YDB-byte-identical): `raises^STDASSERT` (try/catch), STDJSON,
  STDXML, STDCSV, STDDATE, STDOS, STDFS. See
  [`docs/memory/t0b2-msl-kids-base.md`](../memory/t0b2-msl-kids-base.md)
  and the discoveries register.
- **STDSEED engine-neutral (waterline G2).** The default FileMan filer
  re-homing keeps STDSEED below-waterline-clean; see
  [`docs/memory/stdseed-g2-engine-neutral.md`](../memory/stdseed-g2-engine-neutral.md).
- **Byte-mode (`--chset m`)** baked into the toolchain path.
- **CI standardized onto the Go `m`** (reusable `m-ci.yml`) + a root
  `repo.meta.json` (`layer: m`) under the org `m arch check` waterline
  gate. See [`docs/memory/ci-go-m-toolchain.md`](../memory/ci-go-m-toolchain.md)
  and [`docs/memory/meta-at-root.md`](../memory/meta-at-root.md).
- Tag: `v0.6.0`. Compare: `v0.5.0..v0.6.0`.

## [v0.5.0] — 2026-05-08

**Discoverability & tooling — Wave A.** First wave of the
[discoverability and tooling plan](../plans/historical/discoverability-and-tooling-plan.md):
structured-tag grammar, machine-readable manifest, CI manifest-drift
gate. Doc + tooling only — no `src/STD*.m` runtime behaviour change.

- **Closed Wave A tasks:** WA1 (M-doc tag grammar), WA4 (manifest generator), WA5 (CI manifest-drift gate), WA6 (frontmatter on all 32 module docs), WA7 (`dist/errors.json`), WA8 (this release tag) — see [`discoverability-tracker.md` § Wave A](archive/discoverability-tracker.md#wave-a--m-stdlib-grammar--manifest).
- **New machine-readable surface:** [`dist/stdlib-manifest.json`](../../dist/stdlib-manifest.json) (every public module + label with signature, source line, tag-derived fields), `dist/errors.json` (inverted `U-STD*` → producing-module index), YAML frontmatter on every `docs/modules/std*.md`.
- **Cross-cutting follow-ons (deferred):** WA2 (src/ tag backfill), WA3 (`M-DOC-001` lint rule in m-cli) — both unblock Wave B (m-cli `m doc` family) once landed.
- Tag: `v0.5.0`. Compare: `v0.4.0..v0.5.0`.

## [v0.4.0] — 2026-05-08

**Phase 3 close + STDXML full envelope + STDFS byte-faithful I/O +
deployment automation.** All three Phase 3 callout modules engine-
green; STDXML reaches ~100% of its 12-16d envelope; STDFS gains
libc-backed byte-faithful arms. Aggregate gate at this tag:
**32 suites, 2483/2483 assertions green on engine, 0E lint, fmt
clean.**

- **Phase 3 modules engine-green** — [STDCRYPTO](../modules/stdcrypto.md) H1 (23/23, T28 closed), [STDCOMPRESS](../modules/stdcompress.md) H2 (59/59, T28 + T30 closed), [STDHTTP](../modules/stdhttp.md) H3 (68/68, T29 closed). Per-module deployment narratives in each module's § History.
- **STDXML reaches feature-complete v1** — [T26 (DTDs / DOCTYPE / `<!ENTITY>`)](module-tracker.md#t23-t27--stdxml-deferred-features) + T27a (XPath wildcards + attribute axis) + T27b (XPath functions + comparison predicates). [`stdxml.md` § History](../modules/stdxml.md) walks all eight T-ticket landings.
- **STDFS byte-faithful I/O** — T13 + T14 closed; new `writeBytes` / `appendBytes` / `readBytes` / `available` extrinsics over libc. [`stdfs.md` § History](../modules/stdfs.md).
- **STDCSPRNG getrandom(2) callout** — T12 closed; pure-M `/dev/urandom` fallback unchanged. [`stdcsprng.md` § History](../modules/stdcsprng.md).
- **Two more P4 promotions** — STDMATH (L26) and STDXFRM (L27) — see [`stdxfrm.md` § History](../modules/stdxfrm.md) for the `@expr` → XECUTE migration that landed this release.
- **Deployment harness** — `scripts/seed-callouts.sh` (T28 + T29 close): build inside container, stage `.so` + `.xc`, idempotently inject `STDLIB_LIB` + `ydb_xc_<pkg>` into `/etc/profile.d/ydb_env.sh`. Used by all four callout modules.
- **Discoveries that shaped this release:** [`discoveries.md` 2026-05-07](discoveries.md) `$ZF` mangling (`m fmt` rewrites `$ZF` → `$zfind`); `$&pkg.fn` ABI prepends `int argc` on every C entry; YDB r2.02 caps M-strings at 1 MiB.
- Tag: `v0.4.0`. Compare: `v0.3.0..v0.4.0`.

## [v0.3.0] — 2026-05-07

**Phase-2 close + P4 module wave + bug-fix sweep.** Eleven new pure-M
modules promoted out of the proposal pipeline (see
[`future-modules-plan.md` § Promoted out](proposals/future-modules-plan.md));
three m-cli companion tracks bind the new modules into `m test`. New
lint rule `M-MOD-037` catches the YDB `.x(SUBS)` syntax limit at lint
time. Aggregate stable-suite gate: **16 suites, 1230+ assertions, 0E
lint, fmt clean.**

- **P4 promotions (L15–L25)** — STDCSPRNG, STDFS, STDOS, STDSEMVER, STDSTR, STDTOML, STDCACHE, STDPROF, STDSNAP, STDENV, STDXML v0+T23+T24+T25+T25b. Per-module narratives in each module's § History (e.g. [`stdfs.md`](../modules/stdfs.md), [`stdcsprng.md`](../modules/stdcsprng.md), [`stdxml.md`](../modules/stdxml.md)).
- **m-cli companion tracks** — C6 (`m test --timings` consuming STDPROF), C7 (`--update-snapshots` consuming STDSNAP), C8 (`--env PATH` consuming STDENV). Short-code reference in [`module-tracker.md` § m-cli integration short codes](module-tracker.md#m-cli-integration-short-codes).
- **STDXML closes T23 + T24 + T25 + T25b** during this cycle; T26/T27 close in v0.4.0. See [`stdxml.md` § History](../modules/stdxml.md).
- **New lint rule** — `M-MOD-037` (in m-cli) flags `.x(SUBS)` calls at lint time, anchored to [`discoveries.md` 2026-05-06](discoveries.md) `.x(SUBS)` syntax.
- Tag: `v0.3.0`. Compare: `v0.2.0..v0.3.0`.

## [v0.2.0] — 2026-05-07

**Phase 2 release.** Four pure-M heavy-lift modules complete the
Phase-2 set: STDJSON, STDREGEX, STDCOLL, STDURL. Two add-ons land on
the same tag boundary: STDLOG `FORMAT(kv|json)` and STDSEED
`loadJson`. Phase 1b TDD primitives (STDFIX, STDMOCK, STDSEED) rolled
into this release as their `v0.1.x` minor tags were never cut.
Aggregate gate: 800+ assertions across 16 suites, 0 lint errors,
per-module label coverage ≥ 95%.

- **Phase 2 core** — STDJSON (L11), STDREGEX (L12), STDCOLL (L13), STDURL (L14). Per-module reference in [`docs/modules/`](../modules/).
- **Add-ons** — STDLOG `FORMAT(kv|json)` (L4 add-on) and STDSEED `loadJson` (L10 add-on); both unblocked by STDJSON in this release.
- **Phase 1b folded in** — STDFIX (L8), STDMOCK (L9), STDSEED (L10).
- **Auxiliary tracks A3/A4/A5/A6** — JSON conformance corpus, RFC-4122/9562 UUID vectors, IRIS portability CI job, `tools/build-callouts.sh` Phase 3 prereq.
- **Discoveries that shaped this release:**
  - [`discoveries.md` 2026-05-05 P1](discoveries.md) STDASSERT.raises ZGOTO unwind — fixed `$ETRAP` arg-less `quit` cascade in extrinsic chains; unblocks T2 (STDFMT/STDDATE/STDCSV raises tests) and partial T3 (STDLOG-JSON).
  - [`discoveries.md` 2026-05-06 docs](discoveries.md) `.x(SUBS)` syntax limit — STDJSON encode/parse refactored to merge-then-pass; T6 closed.
  - [`discoveries.md` 2026-05-05 P2](discoveries.md) `$ETRAP`+TROLLBACK propagation — STDFIX restructured to one-shot `with`/`invoke`.
  - See [`stdregex.md` § History](../modules/stdregex.md) for the `raise()`-helper pattern (commit `3abf7e8`) back-ported to STDFMT/STDARGS in `8c0b419`.
- **Closed tickets:** T1, T2, T3, T6, T7, T9, T10. Cross-references in [`module-tracker.md` § Closed tickets](module-tracker.md#closed-tickets--archaeology).
- Tag: `v0.2.0`. Compare: `v0.1.0..v0.2.0`.

## [v0.1.0] — 2026-05-05

**Phase 1 release.** Seven new pure-M modules ship across tags
`v0.0.2`–`v0.0.7`, completing the Phase-1 set planned in §8 of the
implementation plan. With `v0.0.1` (`STDASSERT` + `STDUUID`),
m-stdlib at `v0.1.0` provides nine modules: assertions, UUIDs,
base64 + hex, printf-style formatting, structured logging, ISO-8601
datetime, RFC-4180 CSV, argparse.

- **Phase 1 modules (L1–L7, L4b folded)** — [STDB64](../modules/stdb64.md) (L1), [STDHEX](../modules/stdhex.md) (L2), [STDFMT](../modules/stdfmt.md) (L3), [STDLOG](../modules/stdlog.md) (L4 + L4b folded — STDDATE landed first so the inline-ts interim was never cut; see [`stdlog.md` § History](../modules/stdlog.md)), [STDDATE](../modules/stddate.md) (L5), [STDCSV](../modules/stdcsv.md) (L6), [STDARGS](../modules/stdargs.md) (L7).
- **Conformance corpora** — `tests/conformance/b64/` (RFC-4648 §10), `tests/conformance/csv/` (RFC-4180 §2 + excel-quirks + UTF-8 BOM); `{json,uuid}/` reserved for Phase 2.
- **Per-module gate (§9):** 527/527 assertions across 9 suites, 0E lint, ≥95% label coverage per module (most at 100%), fmt clean. STDLOG inline-timestamp helper removed in favour of `$$now^STDDATE()`.
- **Deferred:** error-path `raises` tests for STDFMT and STDDATE — blocked on the STDASSERT.raises P1 documented in [`discoveries.md` 2026-05-05](discoveries.md). Closed in v0.2.0.
- Tag: `v0.1.0`. Compare: `v0.0.1..v0.1.0`.

### Per-tag history

| Tag | Date | Commit | Modules added |
|---|---|---|---|
| `v0.0.2` | 2026-05-05 | `83e11b2` | STDB64 (RFC-4648 std + URL-safe), STDHEX (RFC-4648 §8) |
| `v0.0.3` | 2026-05-05 | `8e6b689` | STDFMT (printf-style; subset of Python `str.format`) |
| `v0.0.4` | 2026-05-05 | `abfa9a2` | STDLOG (kv logger; L4b folded — uses `$$now^STDDATE()`) |
| `v0.0.5` | 2026-05-05 | `1ec3b00` | STDDATE (ISO-8601 datetime + duration arithmetic) |
| `v0.0.6` | 2026-05-05 | `0f7de40` | STDCSV (RFC-4180 parser/writer + file I/O) |
| `v0.0.7` | 2026-05-05 | `c98d5a1` | STDARGS (argparse: long/short/grouped/positional/`--`) |

## [v0.0.1] — 2026-04-30

**Bootstrap release.** STDASSERT + STDUUID — the assertion library
that anchors every subsequent test suite, plus the first
non-`STDASSERT` module to validate the per-module §9 acceptance gate
end-to-end.

- **[`STDASSERT`](../modules/stdassert.md)** — assertion library; output protocol mirrors `^TESTRUN` byte-for-byte so m-cli's `m test` runner accepts STDASSERT-driven suites unchanged. Internal `pass`/`fail` helpers renamed to `recordPass`/`recordFail` to dissolve the M-MOD-020 label/formal name-shadow warning ([`discoveries.md` 2026-04-30 P3](discoveries.md)).
- **[`STDUUID`](../modules/stduuid.md)** — RFC-4122 v4 + RFC-9562 v7 UUIDs.
- **`tools/init-db.sh` bumped to `KEY_SIZE=1019` + `BLOCK_SIZE=4096`** so YDB's `view "TRACE"` can capture deep `FOR_LOOP/*CHILDREN` subscripts without `%YDB-E-GVSUBOFLOW` ([`discoveries.md` 2026-04-30 P2](discoveries.md)).
- **Per-module gate (§9):** 166/166 assertions across 2 suites, 22/22 labels (100%), 0E lint, fmt clean. IRIS portability fail-soft (CI re-add deferred to v0.0.4).
- Tag: `v0.0.1`.

## [Phase 0] — 2026-04-30 (commit `347a938`)

**Project skeleton.** Devcontainer, CI, Makefile, license, README,
STDASSERT bootstrap probe (single-test sanity check that the m-cli
`m test` runner accepts STDASSERT-style assertions under the existing
`^TESTRUN` output-protocol parser).

---

## See also

- [`README.md`](README.md) — the four-bucket doc model this changelog follows.
- [`module-tracker.md`](module-tracker.md) — canonical per-module tracker (Summary table + closed-ticket archaeology).
- [`discoveries.md`](discoveries.md) — discoveries register (in-project pivots + external toolchain findings).
- [`../modules/`](../modules/) — per-module reference; each module has a § History section with deep implementation narrative.
- [`../plans/completed/m-stdlib-implementation-plan.md`](../plans/completed/m-stdlib-implementation-plan.md) — per-module specs and §9 acceptance gate.
- [`proposals/future-modules-plan.md`](proposals/future-modules-plan.md) — proposal pipeline.
