---
created: 2026-05-11
last_modified: 2026-05-11
revisions: 0
doc_type: [REFERENCE]
---

# m-stdlib — Documentation Index

> First-pass index generated 2026-05-11. Labels follow the shared vocabulary below; the same vocabulary is used across all vista-forge repos.

## Vocabulary

Each doc is labeled `[TYPE · type? · connection · connection?]`.

**Types** — `HISTORY` · `ARCHITECTURE` · `DESIGN` · `ADR` · `SPEC` · `REFERENCE` · `GUIDE` · `TUTORIAL` · `ROADMAP` · `PLAN` · `RESEARCH` · `SURVEY` · `GAP-ANALYSIS` · `STATUS` · `EXPLAINER` · `NOTES` · `WORKED-EXAMPLE` · `SETUP` · `INTEGRATION` · `PROPOSAL` · `BUILD-LOG` · `CHANGELOG` · `POSTMORTEM`

**Repo connections** — `history` · `function` · `design` · `architecture` · `planning` · `implementation`

## `guides/` — User and contributor how-to docs

- **`guides/comprehensive-testing.md`** — `[GUIDE · function]` One-stop guide to running everything — full suites, living executable examples, and the quality/maintenance drift-gates — for m-stdlib + v-stdlib across both engines (YDB + IRIS), at the bare and live tiers.
- **`guides/m-doc-grammar.md`** — `[SPEC · function]` Normative grammar for the structured `; doc:` tags that drive the manifest, per-module markdown, and downstream tooling.
- **`guides/m-tdd-guide.md`** — `[GUIDE · function]` Operational TDD guide covering the m-stdlib primitives, the `m test` runner, and the inner-loop / release-gate commands.
- **`guides/quick-start.md`** — `[GUIDE · function]` 5-minute quick start — the fastest path from zero to calling `STD*` code.
- **`guides/verification-surfaces.md`** — `[GUIDE · function]` What `tests/`, `examples/programs/*EX.m`, and the hand-written demos each verify, and where new code belongs — the three-surface model (canonical, shared with v-stdlib).
- **`guides/users-guide.md`** — `[GUIDE · function]` Deep user reference for m-stdlib — purpose, non-goals, acceptance gate, and per-module usage notes.

## `modules/` — Per-module reference docs

- **`modules/index.md`** — `[REFERENCE · architecture · function]` Canonical released-module catalogue, organised by phase, with cross-module runtime dependencies and conformance corpora.
- **`modules/stdargs.md`** — `[REFERENCE · function]` Reference for the STDARGS module — argparse with long/short/grouped flags, positionals, sub-commands, and `--` terminator.
- **`modules/stdassert.md`** — `[REFERENCE · function]` Reference for the STDASSERT module — assertion library with nine extrinsics and `^TESTRUN`-compatible output protocol.
- **`modules/stdb64.md`** — `[REFERENCE · function]` Reference for the STDB64 module — RFC-4648 Base64 with standard and URL-safe alphabets.
- **`modules/stdcache.md`** — `[REFERENCE · function]` Reference for the STDCACHE module — LRU + TTL cache over a caller-owned array.
- **`modules/stdcoll.md`** — `[REFERENCE · function]` Reference for the STDCOLL module — Set / Map / Stack / Queue / Deque / Heap / OrderedDict collections.
- **`modules/stdcompress.md`** — `[REFERENCE · function]` Reference for the STDCOMPRESS module — gzip / deflate / zstd compress and decompress via libz + libzstd callouts.
- **`modules/stdcrypto.md`** — `[REFERENCE · function]` Reference for the STDCRYPTO module — SHA-256/384/512 and HMAC-SHA-256/384/512 via libcrypto callouts.
- **`modules/stdcsprng.md`** — `[REFERENCE · function]` Reference for the STDCSPRNG module — crypto random bytes / hex / base64 / token / int / uuid4 over the kernel CSPRNG.
- **`modules/stdcsv.md`** — `[REFERENCE · function]` Reference for the STDCSV module — RFC-4180 CSV parser and writer with optional file I/O.
- **`modules/stddate.md`** — `[REFERENCE · function]` Reference for the STDDATE module — ISO-8601 datetime and duration arithmetic over the proleptic Gregorian calendar.
- **`modules/stdenv.md`** — `[REFERENCE · function]` Reference for the STDENV module — `.env` loader plus typed accessors (`getInt` / `getBool` / `getFloat`).
- **`modules/stdfix.md`** — `[REFERENCE · function]` Reference for the STDFIX module — fixture lifecycle with `with` / `invoke` one-shot transactional scopes.
- **`modules/stdfmt.md`** — `[REFERENCE · function]` Reference for the STDFMT module — printf-style formatter, subset of Python `str.format` syntax.
- **`modules/stdfs.md`** — `[REFERENCE · function]` Reference for the STDFS module — file-system primitives plus byte-faithful I/O via libc callouts.
- **`modules/stdhex.md`** — `[REFERENCE · function]` Reference for the STDHEX module — RFC-4648 §8 hex encoding with lowercase default and case-insensitive decode.
- **`modules/stdhttp.md`** — `[REFERENCE · function]` Reference for the STDHTTP module — HTTP/1.1 client with pure-M wire-format helpers and libcurl-backed verbs.
- **`modules/stdjson.md`** — `[REFERENCE · function]` Reference for the STDJSON module — RFC 8259 JSON parser and serialiser with one M-tree node per JSON value.
- **`modules/stdlog.md`** — `[REFERENCE · function]` Reference for the STDLOG module — structured `key=value` logger with five levels and four sinks.
- **`modules/stdmath.md`** — `[REFERENCE · function]` Reference for the STDMATH module — numeric helpers (clamp / min / max / sum / count / mean) over caller-owned arrays.
- **`modules/stdmock.md`** — `[REFERENCE · function]` Reference for the STDMOCK module — test-time call interception with `register` / `invoke` / `resolve` / `called` / `args`.
- **`modules/stdos.md`** — `[REFERENCE · function]` Reference for the STDOS module — process / env / cmdline helpers (env / pid / cmdline / argv / cwd / user / hostname).
- **`modules/stdprof.md`** — `[REFERENCE · function]` Reference for the STDPROF module — wall-clock profiler with `$ZHOROLOG`-microsecond resolution.
- **`modules/stdregex.md`** — `[REFERENCE · function]` Reference for the STDREGEX module — Thompson-NFA regex engine with literals, classes, groups, alternation, and greedy quantifiers.
- **`modules/stdseed.md`** — `[REFERENCE · function]` Reference for the STDSEED module — declarative TSV / JSON manifest loader for FileMan record fixtures.
- **`modules/stdsemver.md`** — `[REFERENCE · function]` Reference for the STDSEMVER module — SemVer 2.0.0 validate / parse / compare / match with range syntax.
- **`modules/stdsnap.md`** — `[REFERENCE · function]` Reference for the STDSNAP module — snapshot testing with canonical line-per-leaf dump via `$QUERY` walk.
- **`modules/stdstr.md`** — `[REFERENCE · function]` Reference for the STDSTR module — ASCII string helpers (pad / trim / replaceAll / split / startsWith / endsWith).
- **`modules/stdtoml.md`** — `[REFERENCE · function]` Reference for the STDTOML module — TOML 1.0 subset with top-level pairs, `[section]` tables, and scalar values.
- **`modules/stdurl.md`** — `[REFERENCE · function]` Reference for the STDURL module — RFC 3986 URI parse / build / encode / decode / valid / normalize / resolve.
- **`modules/stduuid.md`** — `[REFERENCE · function]` Reference for the STDUUID module — RFC-4122 v4 and RFC-9562 v7 UUID generation.
- **`modules/stdxfrm.md`** — `[REFERENCE · function]` Reference for the STDXFRM module — higher-order array transforms (map / filter / reduce) via XECUTE-evaluated lambdas.
- **`modules/stdxml.md`** — `[REFERENCE · function]` Reference for the STDXML module — XML 1.0 parser plus XPath 1.0 subset with namespaces, predicates, and functions.

## Top-level live trackers (`docs/` root)

> Layout normalized 2026-06-28 to the org-standard set — the bespoke
> `plans/` · `tracking/` · `prompts/` folders were folded into `design/`
> (forward notes) and `archive/` (retired docs). Live status sits at `docs/`
> root; see the docs-organization remediation plan in the central `docs` repo.

- **`module-tracker.md`** — `[STATUS · implementation]` Master per-module tracker — Summary table, closed-tickets archaeology (T1–T30), and Must-know section. The canonical "what's done / in flight / proposed" view.
- **`discoveries.md`** — `[NOTES · history · implementation]` Discoveries register — every issue not anticipated in a locked plan but addressed during implementation, internal and external.
- **`changelog.md`** — `[CHANGELOG · history]` Keep-a-Changelog release history; one entry per tag with thin pointers into the tracker and per-module History sections.
- **`TODO.md`** — `[STATUS · implementation]` Resume-here pointer — thin index over the tracker with current release status and live work board.

## `proposals/` — Live, in-progress proposals (decision-seeking)

- **`proposals/future-modules-plan.md`** — `[PROPOSAL · planning]` Parking lot for module candidates that haven't crossed TDD-red yet (the L2 `STD*` modules the seams consume) — the proposal pipeline; promote rows out into the module-tracker as they land.
- **`proposals/run-examples-hang-timeout.md`** — `[PROPOSAL · accepted]` Give `tools/run-examples.py`'s `m test` subprocess a per-batch timeout so a hung example suite (e.g. a blocking callout on an unseeded engine, per EIP-1f) fails fast + attributed instead of burning the 25-min CI step budget. Tool-side half; engine-side half is m-cli's `engine-callout-deployment.md`.
- **`vista-library-promotion-plan.md`** — `[PLAN · forward]` Registry-driven plan to surface VistA's de-facto standard library (`v lib`). `v`-family, cross-repo → **moved to the central `docs` repo** (`proposals/vista-library-promotion-plan.md`, 2026-07-11); awaits graduation to the `v-cli` repo with the rest of the `v` platform.

## `design/` — This repo's own stable design notes & analyses

- **`design/m-stdlib-s3-design.md`** — `[DESIGN]` S3 connector design (outbound VistA→S3 log egress) — realized as the shipped STDSIGV4 + STDS3 (v0.14.0); open items are engine HTTP egress.
- **`design/vista-de-facto-library-analysis.md`** — `[ANALYSIS]` Empirical census of code reuse/redundancy in VistA — the foundational analysis behind the de-facto-library promotion plan.

## `memory/` — Auto-memory (durable lessons only)

Per-repo auto-memory — durable engine/tooling gotchas and invariants, per the
Increment Protocol keep-test. Index: [`memory/MEMORY.md`](memory/MEMORY.md).

## `archive/` — Retired docs from this repo (`git mv`'d, never deleted)

Completed-effort plans and trackers (`m-stdlib-implementation-plan.md`,
`tdd-orchestration-plan.md`, `discoverability-tracker.md`, `parallel-tracks.md`,
the executed kickoff prompts, the dated `dual-engine-validation-2026-06-14.md`
report, …) and superseded background (`m-libraries-remediation.md`,
`discoverability-and-tooling-plan.md`, the `v-cli-platform-redirect.md` stub),
and dated corpus-validation reports (`realcode-validation.md`,
`modern-m-corpus-test-results.md`, `vista-corpus-lint-results.md` — point-in-time
RESEARCH snapshots, archived 2026-06-28 with the former `docs/testing/` folder).
History only — git and this folder hold it; the live tree shows in-flight work.
