# vista-de-facto-library-analysis

**An empirical census of code reuse, redundancy, and reinvention in the VistA
codebase — and where `m-stdlib` fits.**

Author: m-stdlib maintainers · Date: 2026-06-07
Corpus: FOIA VistA M source as shipped in the VEHU instance
(`vista-meta/vista/vista-m-host`) · Grounding: vdocs GOLD corpus + the actual
routine source.

---

## Table of contents

1. [Executive summary](#1-executive-summary)
2. [Why this matters for m-stdlib](#2-why-this-matters-for-m-stdlib)
3. [Methodology & data provenance](#3-methodology--data-provenance)
4. [The de-facto VistA standard library (namespace rollup)](#4-the-de-facto-vista-standard-library-namespace-rollup)
5. [Top 200 most-reused functions (the table)](#5-top-200-most-reused-functions-the-table)
6. [Redundancy & copy-paste analysis](#6-redundancy--copy-paste-analysis)
7. [Reinvention analysis](#7-reinvention-analysis)
8. [Functional taxonomy of the de-facto library](#8-functional-taxonomy-of-the-de-facto-library)
9. [m-stdlib vs the de-facto VistA library](#9-m-stdlib-vs-the-de-facto-vista-library)
10. [Where m-stdlib fits — assessment & verdict](#10-where-m-stdlib-fits--assessment--verdict)
11. [Appendix A — objective metrics](#appendix-a--objective-metrics)
12. [Appendix B — reproduction commands](#appendix-b--reproduction-commands)

---

## 1. Executive summary

This report measures, against the **actual VistA source code** (39,330 `.m`
routines, **4,138,428 lines**), how much functionality VistA developers
**reuse from a common library** versus how much they **reinvent or
copy/paste**. The empirical signal is the *entry reference* — every
`tag^routine` call site in the corpus. We extracted **529,055** such call
sites and ranked them by raw frequency and by **breadth** (how many distinct
routines and how many distinct packages call each one).

Headline numbers:

| Metric | Value |
|---|---|
| Routines analyzed | **39,330** |
| Lines of M analyzed | **4,138,428** |
| Total `tag^routine` call sites extracted | **529,055** |
| Distinct `tag^routine` targets | **94,736** |
| Cross-package reuse (calls to a function used by ≥2 packages) | **268,042 (50.7%)** |
| Intra-package "plumbing" reuse (function used by exactly 1 package) | **261,013 (49.3%)** |
| Calls absorbed by the **top 10** functions | **85,948 (16.2% of all calls)** |
| Calls absorbed by the **top 200** functions | **219,159 (41.4% of all calls)** |

**The de-facto VistA standard library is real, small, and dominated by two
packages.** Of the top-200 most-called functions, the **single most-reused
function in all of VistA is `$$GET1^DIQ`** (read one FileMan field) at
**27,095 call sites across 4,984 routines in 106 packages**. The top providers:

| Provider family | Calls in top-200 | What it is |
|---|---:|---|
| **VA FileMan** (`DI*`, `DD*`, `%DT*`) | **97,461** | The database engine — read/write/lookup/index |
| **Kernel `XLF*`** (`XLFSTR`, `XLFDT`) | **30,150** | The string + date/time function library |
| **Kernel `XPD*`** (`XPDUTL`) | **27,916** | KIDS install/packaging |
| **List Manager** (`VALM*`) | **11,016** | The terminal list/UI framework |
| **Kernel other** (`%Z*`, `XU*`, `XQ*`, `XPAR`) | **9,555** | Devices, OS, TaskMan, parameters |
| Registration (`VA*`) | 5,292 | Patient demographics / site |
| HL7 (`HL*`) | 2,510 | Messaging |
| Application-specific long tail | 26,883 | Per-package, not library |

**Two facts frame the whole report:**

1. **VistA *does* have a de-facto standard library and developers *do* use
   it heavily** — FileMan for data, `XLFSTR`/`XLFDT` for strings/dates,
   `XPDUTL` for install, `VALM*` for UI. These ~6 namespaces account for the
   overwhelming majority of cross-package reuse.
2. **Where reuse breaks down, it breaks down the same way every time:**
   developers reinvent the *general-purpose primitives that have no
   one-true-home* — JSON serialization, case conversion, splitting, error
   logging — because historically VistA had no clean, modern, dependency-free
   library for them. **That is precisely the gap m-stdlib targets.**

The verdict for m-stdlib (§10): m-stdlib is **not** committing VistA's sin.
The functions VistA reuses most (FileMan data access, KIDS, List Manager,
demographics) are **platform/domain services m-stdlib correctly does not
touch**. The functions VistA *reinvents* most (JSON, string ops, encoding,
structured logging) are **exactly m-stdlib's charter** — and several
(base64/hex, CSPRNG, TOML, semver, UUID) fill **genuine gaps where VistA has
essentially nothing**.

---

## 2. Why this matters for m-stdlib

m-stdlib's reason to exist is "fill the highest-impact gaps in M's standard
library without reinventing what already works." To honor that, we must know
*what already works and is already used* in the largest M codebase on earth.
This report is the objective check: it tells us which de-facto VistA functions
m-stdlib must **defer to** (and never duplicate), and which categories VistA
**reinvents per-package** (and therefore m-stdlib should **centralize**).

---

## 3. Methodology & data provenance

**Corpus.** `~/projects/vista-meta/vista/vista-m-host/Packages/**/Routines/*.m`
— the FOIA VistA M distribution, the same routine set the VEHU education
instance runs. 39,330 `.m` files, 4,138,428 lines, across 100+ package
directories.

**Primary metric — the entry reference.** In M, code reuse is expressed as
`tag^routine` (call a labeled entry point in another routine) and `$$tag^routine`
(extrinsic function). We extracted every token matching
`[%A-Za-z][A-Za-z0-9]*\^%?[A-Za-z][A-Za-z0-9]{0,7}` — i.e. an alphanumeric
*tag*, a caret, and an alphanumeric *routine*. Requiring alphanumerics on
**both** sides of the caret excludes bare global references (`^DPT(`,
`^%ZOSF`), which begin with the caret. This yields **529,055** call sites and
**94,736** distinct targets.

**Three ranking signals per function:**

- **Calls** — raw occurrence count (how *often* it's invoked). This is
  "frequency" in the literal sense the request asked for.
- **Caller routines** — distinct `.m` files that reference it (how *widely*).
- **Packages** — distinct package directories that reference it. **This is the
  de-facto-library signal:** a function called by 90+ packages is a shared
  library; one called by 1 package (even thousands of times) is internal
  plumbing.

**Why breadth matters.** Raw frequency alone is misleading. `EN2^NURCCPU2`
has 1,608 call sites — but **all in 1 package** (Nursing): it is internal glue,
not a library. `$$NOW^%DTC` has fewer raw uses than some, yet is called by
**114 packages**: it is unambiguously de-facto-standard. The report ranks the
top-200 table by frequency (as requested) but reports breadth in every row so
plumbing is distinguishable from library.

**Grounding.** Library identities are confirmed against the **vdocs GOLD
corpus** and the actual routine headers:

- `$$GET1^DIQ` is the documented FileMan DBS field-read API — *VA FileMan 22.2
  Developer's Guide* §Example 3/5 (`documents/gold/consolidated/DI/di_dg/body.md`);
  the Pharmacy Reengineering API manual even documents downstream calls as
  "the VA FileMan DBS call `$$GET1^DIQ`"
  (`documents/gold/consolidated/PSA/psa_api/body.md`).
- `XLFSTR` / `XLFDT` are the Kernel string and date/time function libraries —
  routine headers: `XLFSTR ;ISC-SF/STAFF - String Functions ;;8.0;KERNEL` and
  `XLFDT ;ISC-SF/STAFF - Date/Time Functions ;;8.0;KERNEL`, both carrying *"Per
  VHA Directive 2004-038, this routine should not be modified"* — the literal
  marker of a frozen, canonical library.
- `XPAR` is Toolkit Parameter Tools — `XPAR ; SLC/KCM - Parameters File Calls
  ;;7.3;TOOLKIT` and *XT\*7.3\*26 Parameter Tools Supplement*
  (`documents/gold/consolidated/XT/xt_pdd/body.md`).

**Known caveats (stated for honesty):**

1. **String-literal false positives.** Six "functions" tied at 342 calls —
   `JAN^FEB`, `MAR^APR`, `MAY^JUN`, `JUL^AUG`, `SEP^OCT`, `NOV^DEC` — are not
   calls. They are fragments of the caret-delimited month literal
   `"JAN^FEB^MAR^APR^MAY^JUN^JUL^AUG^SEP^OCT^NOV^DEC"`, which appears **342
   times verbatim** across the corpus (itself a copy-paste finding — see §6).
   They are **excluded** from the ranked table; the table therefore lists the
   top **194** true entry references.
2. **`$J` is not reinvention.** `$JUSTIFY` is a native MUMPS intrinsic; using
   it for right-justification is idiomatic, not a failure to use a library.
   §7 treats it accordingly.
3. **FileMan editor internals.** Tags like `F^DIE17`, `OUT^DIE17`, `Z^DIE2`,
   `QQ^DIEQ` are FileMan's own scrolling-editor engine cross-referencing
   itself. They have high counts but narrow breadth (≤26 packages) because they
   are mostly invoked from FileMan-generated compiled INPUT templates. They are
   shown but flagged "(internal)".

---

## 4. The de-facto VistA standard library (namespace rollup)

Summing **all 529,055** call sites by provider namespace (not just the top
200) gives the objective shape of VistA's de-facto library. "Max pkgs" is the
breadth of the single most-broadly-used function in that family.

| Rank | Namespace family | Total calls | Max breadth (pkgs) | Role |
|---:|---|---:|---:|---|
| 1 | **`DI*` / `DD*` — VA FileMan** | 93,459 | 108 | Database engine: read, write, lookup, index, DD |
| 2 | **`XLF*` — Kernel string/date lib** | 31,957 | 107 | General-purpose string & date/time functions |
| 3 | **`XPD*` — KIDS install** | 29,873 | 97 | Packaging / install / patch messaging |
| 4 | **`XU*` / `%Z*` — Kernel core/OS/TaskMan** | 14,225 | 90 | Sign-on, devices, OS services, background jobs |
| 5 | **`VALM*` — List Manager** | 12,482 | 49 | Terminal list/UI framework |
| 6 | **`VA*` — PIMS demographics/site** | 10,431 | 77 | Patient demographics, institution lookup |
| 7 | **`%DT` / `%DTC` — date utils** | 9,036 | 114 | Classic date input/compute (FileMan-era) |
| 8 | **`HL*` — HL7** | 6,381 | 38 | Health-messaging functions |
| 9 | **`XPAR` — Kernel parameters** | 3,680 | 51 | System/config parameter store |
| — | `NUR*` (Nursing-internal) | 10,220 | **3** | *Not a library* — intra-package glue (illustrates the contrast) |
| — | Application long tail | 307,311 | varies | Per-package code; the "everything else" |

**Reading this table:** items 1–9 are the de-facto VistA standard library —
broad breadth, cross-package. The `NUR*` row is included deliberately as a
counter-example: 10,220 calls but a breadth of 3 — high *volume*, near-zero
*reach*. Volume without breadth is plumbing, not library.

**The promotion recommendation (what should be "the vista-library"):** if VistA
were to bless an explicit standard library so developers stop reinventing,
the objective evidence says it is exactly these namespaces, in this order:
**`DIQ`/`DIC`/`DIE`/`DIK` (FileMan DBS), `XLFDT`, `XLFSTR`, `XPDUTL`, `%ZIS`,
`%ZTLOAD`, `XPAR`, `VADPT`/`VASITE`, `VALM*`.** These are *already* the library
— this report simply makes the implicit explicit, with numbers.

---

## 5. Top 200 most-reused functions (the table)

Ranked by raw call frequency. **Calls** = total call sites; **Caller
routines** = distinct `.m` files; **Pkgs** = distinct packages (the
de-facto-library breadth signal). Rows with **Pkgs = 1** are intra-package
plumbing despite high counts — kept in the ranking for completeness but they
are *not* library functions. (194 rows; the six month-literal false positives
are excluded per §3.)

| # | Function (`tag^routine`) | Calls | Caller routines | Pkgs | Owning package | Category |
|---:|---|---:|---:|---:|---|---|
| 1 | `GET1^DIQ` | 27,095 | 4,984 | 106 | VA FileMan | DB: field/record read |
| 2 | `MES^XPDUTL` | 13,992 | 2,482 | 92 | Kernel | KIDS install/packaging |
| 3 | `BMES^XPDUTL` | 11,748 | 2,603 | 97 | Kernel | KIDS install/packaging |
| 4 | `FMTE^XLFDT` | 8,841 | 3,366 | 107 | Kernel | Date/time library |
| 5 | `F^DIE17` | 5,817 | 763 | 26 | VA FileMan | DB: editor engine (internal) |
| 6 | `NOW^XLFDT` | 5,507 | 2,862 | 94 | Kernel | Date/time library |
| 7 | `NOW^%DTC` | 3,995 | 2,975 | 114 | VA FileMan | Date computation |
| 8 | `OUT^DIE17` | 3,978 | 583 | 22 | VA FileMan | DB: editor engine (internal) |
| 9 | `UPDATE^DIE` | 3,741 | 1,834 | 95 | VA FileMan | DB: filer (write) |
| 10 | `FILE^DIE` | 3,660 | 1,734 | 95 | VA FileMan | DB: filer (write) |
| 11 | `EN^DDIOL` | 3,296 | 798 | 65 | VA FileMan | I/O: output to device/list |
| 12 | `SETSTR^VALM1` | 3,151 | 405 | 39 | List Manager | TUI: list framework |
| 13 | `FMADD^XLFDT` | 2,999 | 1,653 | 87 | Kernel | Date/time library |
| 14 | `FIREREC^DIE17` | 2,936 | 259 | 18 | VA FileMan | DB: editor engine (internal) |
| 15 | `FILE^DICN` | 2,935 | 1,892 | 108 | VA FileMan | DB: add/lookup |
| 16 | `UP^XLFSTR` | 2,881 | 1,306 | 97 | Kernel | String library |
| 17 | `GETS^DIQ` | 2,860 | 1,461 | 86 | VA FileMan | DB: field/record read |
| 18 | `FIND1^DIC` | 2,423 | 1,350 | 89 | VA FileMan | DB: lookup |
| 19 | `DD^%DT` | 2,355 | 1,314 | 91 | VA FileMan | Date input/validate |
| 20 | `HOME^%ZIS` | 2,285 | 1,938 | 90 | Kernel | Device handling |
| 21 | `FULL^VALM1` | 1,885 | 892 | 46 | List Manager | TUI: list framework |
| 22 | `GET^XPAR` | 1,780 | 641 | 51 | Toolkit | Parameter (config) tools |
| 23 | `YN^DICN` | 1,740 | 1,065 | 79 | VA FileMan | DB: add/lookup |
| 24 | `EZBLD^DIALOG` | 1,698 | 443 | 25 | VA FileMan | I/O: message/dialog build |
| 25 | `E^DIE0` | 1,697 | 860 | 26 | VA FileMan | DB: editor engine (internal) |
| 26 | `N^DIE17` | 1,695 | 859 | 26 | VA FileMan | DB: editor engine (internal) |
| 27 | `CJ^XLFSTR` | 1,675 | 367 | 43 | Kernel | String library |
| 28 | `C^%DTC` | 1,638 | 1,079 | 90 | VA FileMan | Date computation |
| 29 | `EN2^NURCCPU2` | 1,608 | 404 | 1 | Nursing | App-internal (intra-pkg) |
| 30 | `EN1^NURCCPU3` | 1,608 | 404 | 1 | Nursing | App-internal (intra-pkg) |
| 31 | `SITE^VASITE` | 1,595 | 1,033 | 75 | Registration | Site/institution lookup |
| 32 | `EN4^NURCCPU1` | 1,569 | 553 | 1 | Nursing | App-internal (intra-pkg) |
| 33 | `EN^DIQ1` | 1,533 | 907 | 75 | VA FileMan | DB: field read |
| 34 | `DT^XLFDT` | 1,323 | 744 | 72 | Kernel | Date/time library |
| 35 | `EXTERNAL^DILFD` | 1,287 | 603 | 63 | VA FileMan | DB: DD utility |
| 36 | `DEM^VADPT` | 1,254 | 994 | 77 | Registration | Patient demographics API |
| 37 | `EN2^NURCCPU1` | 1,175 | 362 | 1 | Nursing | App-internal (intra-pkg) |
| 38 | `EN5^NURCCPU0` | 1,175 | 358 | 1 | Nursing | App-internal (intra-pkg) |
| 39 | `ERRLOG^SDESJSON` | 1,173 | 159 | 1 | Scheduling | App: JSON/scheduling (reinvented JSON) |
| 40 | `LABEL^DIALOGZ` | 1,127 | 174 | 11 | VA FileMan | I/O: dialog (internal) |
| 41 | `FIND^DIC` | 1,123 | 522 | 76 | VA FileMan | DB: lookup |
| 42 | `PAUSE^VALM1` | 1,121 | 435 | 34 | List Manager | TUI: list framework |
| 43 | `D^OCXO` | 1,104 | 75 | 1 | Order Check | App-internal |
| 44 | `IX1^DIK` | 1,103 | 497 | 64 | VA FileMan | DB: index/xref |
| 45 | `SETFLD^VALM1` | 1,102 | 167 | 28 | List Manager | TUI: list framework |
| 46 | `D^PATIENT` | 1,031 | 88 | 1 | (various) | App/other |
| 47 | `SET^VALM10` | 1,031 | 243 | 30 | List Manager | TUI: list framework |
| 48 | `CKP^GMTSUP` | 1,007 | 105 | 6 | Health Summary | Health summary support |
| 49 | `GET1^DID` | 994 | 425 | 57 | VA FileMan | DB: data-dictionary read |
| 50 | `LJ^XLFSTR` | 991 | 249 | 41 | Kernel | String library |
| 51 | `REPEAT^XLFSTR` | 983 | 462 | 53 | Kernel | String library |
| 52 | `FMDIFF^XLFDT` | 935 | 578 | 70 | Kernel | Date/time library |
| 53 | `EN^VALM` | 895 | 676 | 49 | List Manager | TUI: list framework |
| 54 | `S^%ZTLOAD` | 895 | 652 | 54 | Kernel | TaskMan (background jobs) |
| 55 | `SURG^OTHER` | 895 | 108 | 1 | (various) | App/other |
| 56 | `QQ^DIEQ` | 859 | 859 | 26 | VA FileMan | DB: editor engine (internal) |
| 57 | `Z^DIE2` | 858 | 858 | 26 | VA FileMan | DB: editor engine (internal) |
| 58 | `Z^DIE17` | 858 | 858 | 26 | VA FileMan | DB: editor engine (internal) |
| 59 | `M^DIE17` | 858 | 858 | 26 | VA FileMan | DB: editor engine (internal) |
| 60 | `RW^DIR2` | 846 | 844 | 26 | VA FileMan | DB: reader (internal) |
| 61 | `SIGN^PRSDUTIL` | 846 | 44 | 1 | Time & Attendance | App-internal |
| 62 | `PATCH^XPDUTL` | 785 | 498 | 65 | Kernel | KIDS install/packaging |
| 63 | `D^DIQ` | 780 | 410 | 27 | VA FileMan | DB: field/record read |
| 64 | `EN1^DIP` | 774 | 486 | 75 | VA FileMan | DB: print/report |
| 65 | `EN^XPAR` | 768 | 292 | 38 | Toolkit | Parameter (config) tools |
| 66 | `SET^HLOAPI` | 756 | 30 | 8 | HL7 | HL7 (HLO) API |
| 67 | `D^DATA` | 734 | 90 | 1 | (various) | App/other |
| 68 | `ADDVAL^RORTSK11` | 732 | 48 | 1 | Clinical Case Reg | App-internal |
| 69 | `BLD^DIALOG` | 728 | 234 | 13 | VA FileMan | I/O: message/dialog build |
| 70 | `VERSION^XPDUTL` | 715 | 377 | 67 | Kernel | KIDS install/packaging |
| 71 | `RJ^XLFSTR` | 710 | 222 | 36 | Kernel | String library |
| 72 | `MED^OTHER` | 710 | 108 | 1 | (various) | App/other |
| 73 | `DT^DICRW` | 636 | 537 | 59 | VA FileMan | DB: lookup setup |
| 74 | `HLDATE^HLFNC` | 614 | 199 | 33 | HL7 | HL7 functions |
| 75 | `ADGRU^DGRUDD01` | 612 | 115 | 8 | (various) | App/other |
| 76 | `DD^PRSDUTIL` | 609 | 43 | 1 | Time & Attendance | App-internal |
| 77 | `D^FREE` | 607 | 100 | 1 | (various) | App/other |
| 78 | `CNTRL^VALM10` | 595 | 207 | 32 | List Manager | TUI: list framework |
| 79 | `LIST^DIC` | 588 | 288 | 59 | VA FileMan | DB: lookup |
| 80 | `%XY^%RCR` | 578 | 326 | 54 | Kernel | Array copy util |
| 81 | `HTE^XLFDT` | 574 | 383 | 53 | Kernel | Date/time library |
| 82 | `DIAGNOSIS^S06` | 570 | 7 | 1 | (various) | App/other |
| 83 | `ERRLOG^SDES2JSO` | 548 | 64 | 1 | Scheduling | App: JSON/scheduling (reinvented JSON) |
| 84 | `DAT1^IBOUTL` | 520 | 194 | 5 | Integrated Billing | App-internal |
| 85 | `MSG^DIALOG` | 515 | 291 | 40 | VA FileMan | I/O: message/dialog build |
| 86 | `FMTHL7^XLFDT` | 513 | 227 | 44 | Kernel | Date/time library |
| 87 | `AVAFC^VAFCDD01` | 512 | 90 | 9 | Registration | MPI/demographics (internal) |
| 88 | `CPT^ICPTCOD` | 509 | 297 | 33 | CPT/HCPCS | CPT code lookup |
| 89 | `PARAM^RORTSK01` | 507 | 56 | 1 | Clinical Case Reg | App-internal |
| 90 | `CLEAN^DILF` | 506 | 272 | 49 | VA FileMan | DB: utility (IENS/clean) |
| 91 | `REPLACE^XLFSTR` | 502 | 86 | 21 | Kernel | String library |
| 92 | `Y^DIQ` | 499 | 280 | 41 | VA FileMan | DB: field/record read |
| 93 | `D^T` | 486 | 63 | 2 | (various) | App/other |
| 94 | `SET^IBCNSP` | 485 | 19 | 1 | Integrated Billing | App-internal |
| 95 | `KSP^XUPARAM` | 479 | 321 | 48 | Kernel | System parameter read |
| 96 | `IX^DIC` | 478 | 364 | 52 | VA FileMan | DB: lookup |
| 97 | `ENALL^DIK` | 470 | 295 | 61 | VA FileMan | DB: index/xref |
| 98 | `PROD^XUPROD` | 469 | 331 | 55 | Kernel | Production flag |
| 99 | `TRIM^XLFSTR` | 469 | 223 | 39 | Kernel | String library |
| 100 | `KVAR^VADPT` | 459 | 354 | 40 | Registration | Patient demographics API |
| 101 | `D^QUERY` | 456 | 58 | 1 | (various) | App/other |
| 102 | `NEWCP^XPDUTL` | 456 | 197 | 25 | Kernel | KIDS install/packaging |
| 103 | `CARE^TL` | 456 | 16 | 1 | (various) | App/other |
| 104 | `CLEAN^VALM10` | 446 | 329 | 30 | List Manager | TUI: list framework |
| 105 | `HTFM^XLFDT` | 444 | 266 | 52 | Kernel | Date/time library |
| 106 | `WP^DIE` | 440 | 287 | 55 | VA FileMan | DB: filer (write) |
| 107 | `FIELD^DID` | 419 | 249 | 50 | VA FileMan | DB: data-dictionary read |
| 108 | `DISP^XQORM1` | 406 | 367 | 43 | Kernel | Protocol/menu (internal) |
| 109 | `EN^VALM2` | 397 | 233 | 25 | (various) | App/other |
| 110 | `CLEAR^VALM1` | 393 | 281 | 34 | List Manager | TUI: list framework |
| 111 | `S^LR7OS` | 393 | 17 | 1 | Lab | App-internal |
| 112 | `IENS^DILF` | 379 | 169 | 25 | VA FileMan | DB: utility (IENS/clean) |
| 113 | `D^Enter` | 374 | 52 | 1 | (various) | App/other |
| 114 | `XML^EDPX` | 371 | 50 | 1 | (various) | App/other |
| 115 | `D^HL7` | 369 | 85 | 1 | (various) | App/other |
| 116 | `SURG^MAJOR` | 368 | 90 | 1 | (various) | App/other |
| 117 | `READ^TIUU` | 368 | 111 | 3 | TIU | App: text integration |
| 118 | `EXPAND^IBTRE` | 366 | 127 | 2 | Integrated Billing | App-internal |
| 119 | `OREF^DILF` | 366 | 123 | 23 | VA FileMan | DB: utility (IENS/clean) |
| 120 | `ROOT^DILFD` | 365 | 215 | 42 | VA FileMan | DB: DD utility |
| 121 | `CREF^DILF` | 359 | 124 | 25 | VA FileMan | DB: utility (IENS/clean) |
| 122 | `D^DATABASE` | 357 | 39 | 1 | (various) | App/other |
| 123 | `BUILDJSON^SDES2JSO` | 356 | 98 | 1 | Scheduling | App: JSON/scheduling (reinvented JSON) |
| 124 | `IXALL^DIK` | 352 | 217 | 49 | VA FileMan | DB: index/xref |
| 125 | `KILL^XUSCLEAN` | 351 | 326 | 21 | Kernel | Cleanup util |
| 126 | `INP^VADPT` | 343 | 277 | 40 | Registration | Patient demographics API |
| 127 | `GETLST^XPAR` | 335 | 197 | 36 | Toolkit | Parameter (config) tools |
| 128 | `IN5^VADPT` | 334 | 215 | 49 | Registration | Patient demographics API |
| 129 | `UNIQFERR^DIE17` | 333 | 333 | 19 | VA FileMan | DB: editor engine (internal) |
| 130 | `EN^XUTMDEVQ` | 333 | 267 | 32 | Kernel | TaskMan device queue |
| 131 | `NOSCR^DIED` | 331 | 331 | 19 | VA FileMan | DB: editor (internal) |
| 132 | `AST^DIED` | 331 | 331 | 19 | VA FileMan | DB: editor (internal) |
| 133 | `EN^DIU2` | 330 | 205 | 67 | VA FileMan | DB: delete DD |
| 134 | `EN^DIQ` | 329 | 216 | 54 | VA FileMan | DB: field/record read |
| 135 | `LOOK^IVMPREC9` | 326 | 12 | 2 | (various) | App/other |
| 136 | `ROOT^OCXS` | 325 | 19 | 1 | Order Check | App-internal |
| 137 | `GETICN^MPIF001` | 323 | 200 | 39 | MPI | Master Patient Index API |
| 138 | `DBS^RORERR` | 319 | 117 | 1 | Clinical Case Reg | App-internal |
| 139 | `AUDIT^DIET` | 319 | 110 | 10 | VA FileMan | DB: audit (internal) |
| 140 | `FMTISO^SDAMUTDT` | 318 | 93 | 1 | (various) | App/other |
| 141 | `D^GENERIC` | 317 | 66 | 1 | (various) | App/other |
| 142 | `EN2^NURCCPU3` | 311 | 240 | 1 | Nursing | App-internal (intra-pkg) |
| 143 | `EN1^NURCCPU2` | 310 | 278 | 1 | Nursing | App-internal (intra-pkg) |
| 144 | `EN3^NURCCPU0` | 310 | 241 | 1 | Nursing | App-internal (intra-pkg) |
| 145 | `EN3^NURCCPU1` | 310 | 238 | 1 | Nursing | App-internal (intra-pkg) |
| 146 | `LOW^XLFSTR` | 310 | 191 | 50 | Kernel | String library |
| 147 | `D^LRU` | 306 | 163 | 2 | Lab | App-internal |
| 148 | `WAIT^DICD` | 303 | 261 | 44 | VA FileMan | DB: lookup (internal) |
| 149 | `D^ORDER` | 301 | 88 | 1 | (various) | App/other |
| 150 | `MED^ACUTE` | 297 | 54 | 1 | (various) | App/other |
| 151 | `SURG^CARDIAC` | 297 | 18 | 1 | (various) | App/other |
| 152 | `ICDDATA^ICDXCODE` | 297 | 143 | 17 | ICD | ICD code data |
| 153 | `ELIG^VADPT` | 294 | 222 | 49 | Registration | Patient demographics API |
| 154 | `EVENT^IVMPLOG` | 292 | 94 | 8 | (various) | App/other |
| 155 | `INIT^HLFNC2` | 291 | 196 | 38 | HL7 | HL7 functions |
| 156 | `STA^XUAF4` | 290 | 178 | 32 | Kernel | Institution file API |
| 157 | `S^ORU4` | 288 | 8 | 2 | (various) | App/other |
| 158 | `IX^DIK` | 287 | 184 | 48 | VA FileMan | DB: index/xref |
| 159 | `FO^IBCNEUT1` | 286 | 37 | 1 | Integrated Billing | App-internal |
| 160 | `ADD^VADPT` | 283 | 208 | 50 | Registration | Patient demographics API |
| 161 | `COMMA^%DTC` | 283 | 101 | 17 | VA FileMan | Date computation |
| 162 | `DTP^FH` | 275 | 119 | 2 | Dietetics | App-internal |
| 163 | `FT^IBCEF` | 271 | 112 | 1 | Integrated Billing | App-internal |
| 164 | `EOS^RAUTL5` | 270 | 58 | 1 | (various) | App/other |
| 165 | `LOG^MHVUL2` | 270 | 48 | 1 | (various) | App/other |
| 166 | `D^GCC` | 258 | 26 | 1 | (various) | App/other |
| 167 | `OUT^DIALOGU` | 258 | 253 | 23 | VA FileMan | I/O: dialog util |
| 168 | `FMDATE^HLFNC` | 258 | 127 | 25 | HL7 | HL7 functions |
| 169 | `HL7TFM^XLFDT` | 257 | 146 | 44 | Kernel | Date/time library |
| 170 | `SENDMSG^XMXAPI` | 256 | 209 | 40 | MailMan | Email/message send |
| 171 | `MED^MAJOR` | 252 | 90 | 1 | (various) | App/other |
| 172 | `DISPLAY^PRCPUX2` | 251 | 85 | 1 | IFCAP/Fiscal | App-internal |
| 173 | `MSG^PRCFQ` | 250 | 82 | 1 | IFCAP/Fiscal | App-internal |
| 174 | `YN^LRU` | 248 | 136 | 2 | Lab | App-internal |
| 175 | `LOG^BPSOSL` | 244 | 34 | 3 | (various) | App/other |
| 176 | `SETUP^XQALERT` | 244 | 144 | 35 | Kernel | Alerts |
| 177 | `SURG^SKIN` | 243 | 36 | 1 | (various) | App/other |
| 178 | `CSTP^DIO2` | 243 | 243 | 23 | VA FileMan | DB: output (internal) |
| 179 | `NS^XUAF4` | 241 | 177 | 33 | Kernel | Institution file API |
| 180 | `V^LRU` | 239 | 211 | 3 | Lab | App-internal |
| 181 | `EOF^OCXS` | 237 | 91 | 1 | Order Check | App-internal |
| 182 | `FMTH^XLFDT` | 236 | 144 | 41 | Kernel | Date/time library |
| 183 | `GET^DDSVAL` | 231 | 47 | 10 | (various) | App/other |
| 184 | `OPEN^%ZISH` | 230 | 109 | 32 | Kernel | Host file I/O |
| 185 | `P^PRCPUREP` | 228 | 82 | 1 | IFCAP/Fiscal | App-internal |
| 186 | `ERROR^RORERR` | 228 | 82 | 1 | Clinical Case Reg | App-internal |
| 187 | `CLOSE^%ZISH` | 225 | 109 | 32 | Kernel | Host file I/O |
| 188 | `ENDR^%ZISS` | 224 | 193 | 40 | Kernel | Screen handling |
| 189 | `DT^DILF` | 224 | 111 | 36 | VA FileMan | DB: utility (IENS/clean) |
| 190 | `ENDTC^PSGMI` | 223 | 107 | 3 | (various) | App/other |
| 191 | `GENERATE^HLMA` | 222 | 146 | 36 | HL7 | HL7 message build |
| 192 | `VER^XPDUTL` | 220 | 95 | 10 | Kernel | KIDS install/packaging |
| 193 | `CHKTF^%ut` | 220 | 17 | 4 | M-Unit | Test framework |
| 194 | `KVA^VADPT` | 218 | 149 | 30 | Registration | Patient demographics API |

**Within this top-200 list:** 125 functions are genuine cross-package library
(≥10 packages) carrying **184,226 calls**; 69 are intra-package plumbing
(<10 packages) carrying 34,933 calls. The library/plumbing split is visible at
a glance by reading the **Pkgs** column.

---

## 6. Redundancy & copy-paste analysis

The request asked specifically for the *amount* of redundant/repetitive/
copy-paste code. Three objective probes:

### 6.1 Exact-duplicate routine bodies

Hashing every routine body (md5 of all lines after the first) finds **72
groups of byte-identical routines covering 166 routines** — i.e. ~0.42% of the
corpus is a literal whole-file copy of another routine. **This is low** —
VistA's redundancy is *not* primarily at whole-file granularity. The exact
dupes that do exist are mostly FileMan-generated compiled templates and a
handful of namespaced clones.

### 6.2 Line-level copy-paste (the real redundancy)

The redundancy lives at the **line/idiom** level. The single most-repeated
non-trivial code line in all of VistA appears **2,644 times**:

```
S X=DG(DQ),DIC=DIE
```

and an entire **cluster of ~15 lines from FileMan's scrolling editor engine
(`DIE17`/`DIEQ`/`DIE0`/`DIR2`) each recurs 820–860 times.** These are
**machine-generated** — FileMan emits the same boilerplate into every compiled
INPUT template — so they are "copy-paste" in effect but generated by design,
not hand-duplicated. They explain why the `DIE17` internal tags rank so high in
§5 with narrow breadth.

### 6.3 The month literal — hand copy-paste in the wild

The caret-delimited constant
`"JAN^FEB^MAR^APR^MAY^JUN^JUL^AUG^SEP^OCT^NOV^DEC"` appears **342 times
verbatim** across hundreds of routines — a textbook hand-copied constant that,
in a modern codebase, would live once in a library (`$$month^…`). It is the
cleanest single illustration of "developers paste the same data because there
is no shared home for it."

**Redundancy verdict:** whole-file duplication is rare (166 routines, 0.42%);
the dominant redundancy is (a) generated FileMan template boilerplate and
(b) hand-pasted small idioms/constants. The latter is the category a modern
stdlib eliminates.

---

## 7. Reinvention analysis

"Reinvented instead of using a built-in that already exists." Measured cases,
each with objective numbers:

### 7.1 Case conversion — `$TR` instead of `$$UP^XLFSTR`

`$$UP^XLFSTR` is *literally* `Q $TR(X,"abc…xyz","ABC…XYZ")` (confirmed in the
source). Yet:

| Approach | Count |
|---|---:|
| Routines using the library `$$UP^XLFSTR` | 1,306 |
| Routines with a hand-written lowercase-alphabet literal in `$TR` | **404** |
| Occurrences of the explicit `$TR(x,"a…z","A…Z")` uppercase idiom | 529 |

≈**24% of all uppercasing in VistA is reinvented** verbatim rather than
calling the one-line library function that does exactly the same thing.

### 7.2 The library function nobody uses — `$$SPLIT^XLFSTR`

`SPLIT^XLFSTR` exists in Kernel (split a string by delimiter into a var list)
and has **0 callers** in the entire corpus. Developers instead hand-roll
`$PIECE` loops everywhere. A library function that is undiscoverable is
functionally equivalent to one that doesn't exist — a key lesson for m-stdlib's
discoverability tooling.

### 7.3 JSON — reinvented per package (the headline reinvention)

VistA's Kernel ships a canonical JSON encoder/decoder: `XLFJSON` /
`XLFJSOND` / `XLFJSONE`. Despite that, **the corpus contains 26 distinct
`*JSON*` routines and 24 distinct JSON entry-point targets, totaling 2,643
JSON-build call sites** — each package rolling its own:

| Namespace | JSON routines | Package |
|---|---|---|
| `XLFJSON*` | `XLFJSON`, `XLFJSOND`, `XLFJSONE` | Kernel (the *official* one) |
| `SDESJSON`, `SDES2JSON`, `SDESBUILDJSON`, `SDEC…JSON` | 8+ | Scheduling (VSE) |
| `VPRJSON*` | `VPRJSON`, `VPRJSOND`, `VPRJSONE` | Virtual Patient Record |
| `HMPJSON*` | `HMPJSON`, `HMPJSOND`, `HMPJSONE` | Health Management Platform |
| `YTWJSON*`, `YSBJSON` | 5+ | Other |

Two Scheduling JSON entries alone (`ERRLOG^SDESJSON` 1,173 calls;
`ERRLOG^SDES2JSO` + `BUILDJSON^SDES2JSO` 904 calls) make the top-200. **This is
the canonical reinvention pattern**: a general-purpose primitive (JSON) with no
*authoritative, modern, easy-to-call* home, so every team builds its own.

### 7.4 Encoding — a genuine gap, not reinvention

Only **6 routines** in the entire corpus mention base64/encoding primitives.
VistA effectively has **no** base64/hex library. So m-stdlib's `STDB64`/`STDHEX`
fill a real void rather than competing with anything.

### 7.5 Honest non-finding — `$J`

`$J(` appears 25,977 times vs 222 routines using `$$RJ^XLFSTR`. This is **not**
reinvention: `$JUSTIFY` is a native MUMPS intrinsic and the idiomatic way to
right-justify. We flag it only to pre-empt a false "look how much they reinvent
right-justify" reading. `$$CJ`/`$$LJ`/`$$RJ^XLFSTR` add value only for
centering and padding semantics `$J` lacks.

---

## 8. Functional taxonomy of the de-facto library

Grouping the de-facto library by *what it does* (the axis along which we can
compare to m-stdlib):

| Functional area | VistA de-facto provider(s) | Representative top-200 entries |
|---|---|---|
| **Database (read/write/lookup/index/DD)** | FileMan `DIQ/DIC/DICN/DIE/DIK/DIP/DID/DILF/DILFD` | `GET1^DIQ`, `FILE^DICN`, `UPDATE^DIE`, `FIND1^DIC`, `IX1^DIK` |
| **Date / time** | `XLFDT`, `%DT`, `%DTC` | `FMTE^XLFDT`, `NOW^XLFDT`, `FMADD^XLFDT`, `NOW^%DTC`, `DD^%DT` |
| **String** | `XLFSTR` | `UP^XLFSTR`, `CJ^XLFSTR`, `LJ/RJ^XLFSTR`, `REPEAT/TRIM/REPLACE^XLFSTR` |
| **Config / parameters** | `XPAR`, `XUPARAM` | `GET^XPAR`, `GETLST^XPAR`, `KSP^XUPARAM` |
| **Install / packaging** | `XPDUTL` (KIDS) | `MES/BMES^XPDUTL`, `PATCH^XPDUTL`, `VERSION^XPDUTL` |
| **Device / host I/O** | `%ZIS`, `%ZISH`, `%ZISS` | `HOME^%ZIS`, `OPEN/CLOSE^%ZISH`, `ENDR^%ZISS` |
| **Background jobs** | `%ZTLOAD`, `XUTMDEVQ` | `S^%ZTLOAD`, `EN^XUTMDEVQ` |
| **Terminal UI** | List Manager `VALM*` | `SETSTR^VALM1`, `FULL^VALM1`, `EN^VALM` |
| **Output / messaging** | `DDIOL`, `DIALOG`, `XMXAPI` | `EN^DDIOL`, `EZBLD^DIALOG`, `SENDMSG^XMXAPI` |
| **Alerts** | `XQALERT` | `SETUP^XQALERT` |
| **OS / system services** | `%ZOSV`, `XUPROD`, `XUAF4` | `PROD^XUPROD`, `STA^XUAF4` |
| **Serialization (JSON/XML)** | *fragmented* — `XLFJSON` + per-pkg clones | `ERRLOG^SDESJSON`, `BUILDJSON^SDES2JSO` |
| **Encoding (base64/hex)** | *absent* | — |
| **Domain: demographics / coding / HL7** | `VADPT`, `VASITE`, `MPIF001`, `ICPTCOD`, `ICDXCODE`, `HL*` | `DEM^VADPT`, `SITE^VASITE`, `CPT^ICPTCOD`, `HLDATE^HLFNC` |

---

## 9. m-stdlib vs the de-facto VistA library

The crucial cross-check: for each m-stdlib module, does an equivalent
de-facto VistA library already exist (→ m-stdlib must defer / interoperate, not
duplicate), or is the area fragmented/absent (→ m-stdlib legitimately fills the
gap)?

| m-stdlib module | VistA de-facto equivalent | Status | Verdict |
|---|---|---|---|
| `STDDATE` | `XLFDT`, `%DT`, `%DTC` (very heavily used) | **Overlap, different epoch** — STDDATE is ISO-8601/UTC; VistA is FM-date | Complementary. **Should offer FM↔ISO bridges**, not replace XLFDT. |
| `STDSTR` / `STDFMT` | `XLFSTR` (heavily used) | **Direct overlap** | Don't duplicate semantics; align names; STDSTR is the modern/portable home where XLFSTR is YDB+IRIS-awkward. |
| `STDJSON` | `XLFJSON` **+ 20+ per-package clones** | **Fragmented in VistA** | **Centralize.** This is exactly the reinvention §7.3 documents. Strong fit. |
| `STDXML` | scattered (`XML^EDPX` etc., no library) | Absent/fragmented | Fills gap. |
| `STDB64` / `STDHEX` | **essentially none** (6 routines) | **Absent** | Pure gap-fill. |
| `STDCRYPTO` / `STDCSPRNG` | none (Kernel has hashing bits, no clean lib) | Absent | Gap-fill (optional tier). |
| `STDLOG` | per-package error/log routines (`RORERR`, `*LOG*`) | Fragmented | Centralize. |
| `STDCSV` | none (hand-rolled `$P` everywhere) | Absent | Gap-fill. |
| `STDURL` / `STDHTTP` | none (modern need) | Absent | Gap-fill. |
| `STDUUID` | none | Absent | Gap-fill. |
| `STDTOML` / `STDENV` / `STDSEMVER` | `XPAR` (DB-backed params) is different | Absent (file/config-as-text) | Complementary to XPAR. |
| `STDMATH` | none (intrinsics only) | Absent | Gap-fill. |
| `STDCOLL` / `STDCACHE` | none (raw globals/locals) | Absent | Gap-fill. |
| `STDREGEX` | none (YDB has `?` pattern; no PCRE) | Absent | Gap-fill. |
| `STDASSERT` / `STDMOCK` / `STDHARN` / `STDPROF` / `STDSNAP` | M-Unit `%ut` (test only; `CHKTF^%ut` is in top-200) | Different philosophy | Complementary modern test stack. |
| `STDFS` / `STDOS` | `%ZISH` (host files), `%ZOSV` (OS) — used | **Overlap** | Interop/wrap; don't reinvent `%ZISH` device semantics. |
| `STDARGS` | none | Absent | Gap-fill (CLI). |
| `STDFIX` / `STDXFRM` / `STDSEED` / `STDCOMPRESS` | none | Absent | Gap-fill. |

**m-stdlib has no module that competes with FileMan, KIDS, List Manager, MPI,
demographics, HL7, or TaskMan** — i.e. it does **not** duplicate the functions
VistA reuses most. The overlaps are confined to **string, date, file/OS** — and
in those, m-stdlib's role is the *modern, YDB+IRIS-portable, dependency-free*
counterpart with bridges to the VistA originals, not a replacement.

---

## 10. Where m-stdlib fits — assessment & verdict

**Does m-stdlib commit "the same sin as all developers — reinventing function
libraries"?** Measured against the VEHU code: **No — with two caveats to honor.**

1. **m-stdlib targets the reinvention zone, not the well-served zone.** The
   areas VistA reuses heavily and well (FileMan data access = 93k calls; KIDS =
   30k; List Manager = 12k; demographics = 10k) are platform/domain services
   m-stdlib deliberately does not provide. The areas VistA *fragments and
   reinvents* (JSON = 24 clones; structured logging; CSV; case-conversion as a
   one-liner that 404 routines re-paste) map **one-to-one onto m-stdlib's
   charter**. m-stdlib is the missing "one true home" for exactly the
   primitives that have no home in VistA.

2. **The genuine gaps validate the gap-filling mission.** base64/hex (6
   routines), regex (none), UUID (none), CSV (none), HTTP/URL (none), math
   helpers (none), collections/cache (none), CSPRNG (none) — for these,
   m-stdlib competes with *nothing*. It is additive, not duplicative.

3. **Caveat — string & date are overlap zones; treat them as bridges, not
   replacements.** `XLFSTR`/`XLFDT`/`%DT` are top-tier de-facto functions
   (30k+ calls, 100+ package breadth). m-stdlib `STDSTR`/`STDFMT`/`STDDATE`
   must (a) not silently diverge in semantics from the canonical Kernel
   functions, and (b) ship explicit **FM-date ↔ ISO-8601** and
   **XLFSTR-parity** bridges so a VistA developer adopting m-stdlib is never
   forced to choose. The risk of "reinventing" is real *only here*, and the
   mitigation is interop, which m-stdlib already leans toward.

4. **Discoverability is the real lesson.** `$$SPLIT^XLFSTR` exists and has
   **zero callers**; `$$UP^XLFSTR` is reinvented by 404 routines. VistA's
   problem was never the absence of a library — it was that the library was
   undiscoverable and unblessed. m-stdlib's manifest / skill / doctest
   generation (the `dist/skill/` + `make manifest` machinery) is the direct
   countermeasure: **a library is only "de-facto" if developers can find it.**
   This report is itself an argument for keeping that discoverability tooling
   first-class.

**Bottom line.** m-stdlib sits in the **complement** of VistA's de-facto
library: it provides the modern, portable, discoverable primitives VistA
developers have been reinventing per-package for 30 years (JSON, logging, CSV,
encoding, regex, UUID, math, collections), while staying out of the
data/install/UI/domain territory FileMan and Kernel already own. Its one zone
of overlap — strings and dates — should remain explicitly bridge-shaped. On
the evidence of 4.1M lines of VEHU code, **m-stdlib is the cure for VistA's
reinvention pattern, not another instance of it.**

---

## Appendix A — objective metrics

| Metric | Value |
|---|---:|
| Routines (`.m`) | 39,330 |
| Total lines | 4,138,428 |
| Entry-reference call sites extracted | 529,055 |
| Distinct `tag^routine` targets | 94,736 |
| Cross-package call share | 50.7% (268,042) |
| Intra-package call share | 49.3% (261,013) |
| Top-10 functions' share of all calls | 16.2% |
| Top-200 functions' share of all calls | 41.4% |
| Exact-duplicate routine groups / routines | 72 / 166 (0.42%) |
| Most-repeated single code line | `S X=DG(DQ),DIC=DIE` (2,644×) |
| Month-literal copy-paste occurrences | 342 |
| Uppercasing reinvented via `$TR` (routines) | 404 (≈24% of uppercasing) |
| `$$SPLIT^XLFSTR` callers | 0 |
| Distinct `*JSON*` routines / JSON build call sites | 26 / 2,643 |
| base64/encoding routines in corpus | 6 |
| **#1 most-reused function** | `$$GET1^DIQ` — 27,095 calls, 4,984 routines, 106 packages |

## Appendix B — reproduction commands

Run from `~/projects/vista-meta/vista/vista-m-host/Packages`:

```bash
# Extract every TAG^ROUTINE entry reference (alnum on both sides of caret).
grep -rohE '[%A-Za-z][A-Za-z0-9]*\^%?[A-Za-z][A-Za-z0-9]{0,7}' --include='*.m' . \
  | sort | uniq -c | sort -rn          # frequency ranking

# Breadth (distinct callers + packages) per entry reference:
grep -roHE '[%A-Za-z][A-Za-z0-9]*\^%?[A-Za-z][A-Za-z0-9]{0,7}' --include='*.m' . \
  | awk -F: '{ ... split(path,p,"/"); pkg=p[1]; ... }'   # see report tooling

# Exact-duplicate routine bodies:
find . -name '*.m' | while read f; do tail -n+2 "$f" | md5sum; done \
  | awk '{print $1}' | sort | uniq -d | wc -l

# Reinvention probes:
grep -rliE 'abcdefghijklmnopqrstuvwxyz' --include='*.m' .   # manual case-conv
grep -rlE 'UP\^XLFSTR' --include='*.m' .                    # library case-conv
find . -name '*.m' | grep -iE 'JSON' | sed 's#.*/##' | sort -u   # JSON clones
```

Grounding queries (from `~/projects/vdocs`):

```bash
.venv/bin/vdocs ask "GET1^DIQ FileMan retrieve field data" --k 3 --json
.venv/bin/vdocs ask "XPAR parameter tools GET^XPAR" --k 3 --json
```

> **Sources.** VistA M source: `vista-meta/vista/vista-m-host/Packages`
> (FOIA / VEHU routine set). Documentation grounding: vdocs GOLD corpus —
> *VA FileMan 22.2 Developer's Guide* (`documents/gold/consolidated/DI/di_dg/body.md`),
> *FM 22.2 Advanced User Manual* (`…/DI/di_um/body.md`),
> *XT\*7.3\*26 Parameter Tools Supplement* (`…/XT/xt_pdd/body.md`).
> Library identities confirmed against routine headers in the source
> (`XLFSTR`, `XLFDT`, `XPAR`).
