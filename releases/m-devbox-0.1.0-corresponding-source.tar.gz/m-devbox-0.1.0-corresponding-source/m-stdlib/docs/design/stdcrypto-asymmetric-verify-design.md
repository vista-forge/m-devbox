---
title: STDCRYPTO asymmetric-verify — Phase-0 design findings (G-IRIS + G-ERR)
status: draft
version: v0.1
tracker: docs/module-tracker.md
created: 2026-07-09
doc_type: [DESIGN, DRAFT]
proposal: docs/proposals/stdcrypto-asymmetric-verify-v2.md
---

# STDCRYPTO asymmetric-verify — Phase-0 design findings

The build proposal
[`stdcrypto-asymmetric-verify-v2.md`](../proposals/stdcrypto-asymmetric-verify-v2.md)
gates all production code on three Phase-0 blockers. This note records the two
that produce a durable design decision: **G-IRIS** (the load-bearing IRIS-surface
probe, OQ-1) and **G-ERR** (the disjoint error channel). G-CI is a CI-wiring task
with no design content (see `.github/workflows/ci.yml`).

---

## G-IRIS — the `$SYSTEM.Encryption` verify surface (measured on foia-t12)

**Method:** read-only probe via the `m-iris` driver stack
(`m vista exec --engine iris --transport docker`) against the running **foia-t12**
container — IRIS **2026.1 (Build 234U)**. Vectors were generated with host OpenSSL
3.0.13, passed in as base64, and decoded in-engine with
`$system.Encryption.Base64Decode` so the engine saw byte-exact key/sig material.

### RSA (Phase 1 — CONFIRMED, this is what T-IRIS-RS builds on)

```
$SYSTEM.Encryption.RSASHAVerify(SHASize, Data, Signature, PublicKey) → 1 valid | 0 invalid
```

- **Arg order:** `(SHASize, Data, Signature, PublicKey)` — SHA size **first**, key
  **last**. (Note this differs from the digest/HMAC arms' `(bits, data, key)` order.)
- **SHASize:** the digest **bit width** — `256` / `384` / `512`. All three verified
  a matching RS256/RS384/RS512 signature → `1`.
- **Key form: PEM only.** A `-----BEGIN PUBLIC KEY-----` SPKI PEM string verifies.
  **A raw SPKI DER blob returns `0` (invalid), NOT an error** — a silent false
  negative. ⇒ **The IRIS arm MUST convert a DER key to PEM before calling
  `RSASHAVerify`** (base64-wrap at 64 cols + add the PUBLIC KEY armor). YDB's
  `d2i_PUBKEY`/`PEM_read_bio_PUBKEY` accept both, so this DER→PEM shim is an
  IRIS-only concern needed to keep the public `$$verifySig` contract ("SPKI DER or
  PEM") truly engine-neutral.
- **Negative behaviour:** a bit-flipped signature → `0` (correct, non-exceptional).

### ES* / PS* / EdDSA (Phase 2 — CONFIRMED + implemented 2026-07-09)

Enumerated `^oddCOM("%SYSTEM.Encryption","m",…)` — the sign/verify surface present
on foia-t12:

| Method | Family | Phase-2 relevance |
|---|---|---|
| `RSASHAVerify` | RS* (PKCS1-v1_5) | Phase 1 (above) |
| `RSASSAPSSVerify` | **PS\* (RSA-PSS)** | **PS\* is dual-engine capable** |
| `ECSHAVerify` | **ECDSA** | **ES\* is dual-engine capable** |
| `RSASHA3Verify`, `RSASHA1Verify` | SHA-3 / SHA-1 RSA | out of JWS scope |
| `X509VerifyCertChain` | cert-chain | not needed (verify-only, no chain) |
| *(no `Ed*`/`Ed25519`/CFRG method found)* | **EdDSA** | **EdDSA likely YDB-only on IRIS** |

**This materially lowers R-IRIS.** The proposal's headline worry ("IRIS has no
documented generic ECDSA/EdDSA verify → ES256 not engine-neutral") is **half
resolved**: ES\* (`ECSHAVerify`) and PS\* (`RSASSAPSSVerify`) both exist natively.
The residual gap is **EdDSA only** — no CFRG/Ed25519 method is exposed, so EdDSA is
the one alg that may be tracked YDB-only-for-now at Phase 2 (never a silent gap).

`ECSHAVerify` arg shape, probed the same way:

```
$SYSTEM.Encryption.ECSHAVerify(SHASize, Data, Signature, PublicKey) → 1|0
```

- Same `(SHASize, Data, Signature, PublicKey)` order as RSASHAVerify.
- **Signature is DER-encoded `SEQUENCE{r,s}`**, not the JWT `R‖S` concatenation.
  ⇒ the Phase-2 IRIS ES\* arm converts `R‖S`→DER first (same conversion the YDB C
  path does), then calls `ECSHAVerify`. Key is PEM (same DER→PEM shim as RSA).

**Phase-2 outcome (measured + implemented 2026-07-09):**

- **`RSASSAPSSVerify` arg shape CONFIRMED** — probed read-only on foia with a
  host-OpenSSL PS256 vector: `$SYSTEM.Encryption.RSASSAPSSVerify(SHASize, Data,
  Signature, PublicKey) → 1|0`, **the same order as RSASHAVerify/ECSHAVerify**.
  IRIS's PSS defaults already match the RFC (saltlen = hlen, MGF1 = same digest),
  so the same host-OpenSSL vector verifies on both engines with no param plumbing
  on the IRIS side.
- **`ECSHAVerify` R‖S→DER done M-side** (`$$rsToDer^STDCRYPTO`) — component width
  `$L(sig)\2`, minimal-DER integers, leading `$c(0)` on a high-bit byte; a
  malformed R‖S (odd/empty) → invalid (0), never an error. Verified with the
  RFC 7515 §A.3 ES256 vector through the driver stack.
- **EdDSA is YDB-only — DECIDED, not "may be".** No CFRG/Ed25519 method exists on
  foia, so `$$verifySig("EdDSA",…)` **raises `U-STDCRYPTO-BADALG` on IRIS** — a
  visible, fail-closed *tracked skip* (asserted in-suite via `edDsaSkip`), never a
  silent 0. `BADALG` is reused (semantically "unsupported alg on this engine"); no
  new error code was added. On IRIS an EdDSA token therefore fails closed → reject,
  which is the correct engine-neutral behavior for the downstream STDJWT layer.
- **One implementation trap** (see `docs/discoveries.md` 2026-07-09 / memory
  `iris-native-backends`):
  the RS-family `RSAGetLastError`→BADKEY disambiguation is **RSA-specific** — reusing
  it for ES*/PS* turned a normal invalid into an uncaught raise that aborted the
  suite; it is gated to `fam="RS"`.

**Test-corpus caveat (logged per proposal §12 "log any curation/cap"):** the
adversarial negatives are a **curated, hand-built Wycheproof-*class* subset**
(all-zero r=0/s=0, truncated/half-width, odd-length, wrong-curve, bit-flipped
sig/key), **not an import of the official Google Wycheproof JSON corpus** — a
future increment could wire the full vector sets. Two deliberate scope facts:
(a) **high-s ECDSA malleability is NOT rejected** — OpenSSL's verifier accepts both
`(r,s)` and `(r,n−s)` and RFC 7518 does not mandate low-s, so this is correct-by-spec,
stated so it is not silently assumed; (b) the **non-canonical-DER** class (extra
leading zero, etc.) is *structurally sidestepped* — the public input is the JWT
`R‖S`, converted to canonical DER in-house (`BN_bin2bn`+`i2d_ECDSA_SIG` / `$$rsToDer`),
so a caller cannot present non-canonical DER to the verifier at all.

**G-IRIS exit:** RSA arg/key form confirmed; ES\*/PS\* present (dual-engine, arg
shapes confirmed + implemented), EdDSA absent (YDB-only, decided). §9b's Phase-1 shape is **native
`RSASHAVerify`, no helper class needed.**

---

## G-ERR — the disjoint C error channel + `dispatchV`

### The two hazards this closes (proposal N-3)

1. **`rc=0` inversion.** The existing `dispatch3`/`dispatch4` treat `rc=0` as
   *success* (`STDCRYPTO.m:336,352`). For verify, `rc=0` means **invalid
   signature** — a valid, non-exceptional answer. So verify **must not reuse**
   `dispatch3`/`dispatch4`; it needs its own `dispatchV` that reads `rc` directly as
   the verdict.
2. **The latent `rc=-1` collision.** `dispatch3`/`dispatch4` use `$ETRAP` to set
   `rc=-1` on callout-missing (`STDCRYPTO.m:331,347`), while the C layer also returns
   `-1..-5`. If verify's C fn ever returned `-1`, callout-missing and a C error would
   be indistinguishable.

### The channel (disjoint ranges)

| Source | Code | Meaning | M mapping |
|---|---|---|---|
| C fn | `1` | valid signature | `$$verifySig` → 1 |
| C fn | `0` | invalid signature | `$$verifySig` → 0 (no `$ECODE`) |
| C fn | `-5` | wrong arity (`argc!=4`) | `U-STDCRYPTO-VERIFY-FAIL` |
| C fn | `-10` | BADKEY (SPKI parse failed) | `U-STDCRYPTO-BADKEY` |
| C fn | `-11` | BADALG (unknown alg) | `U-STDCRYPTO-BADALG` |
| C fn | `-12` | VERIFY-FAIL (internal EVP error) | `U-STDCRYPTO-VERIFY-FAIL` |
| M `$ETRAP` | `-99` | callout symbol missing | `U-STDCRYPTO-CALLOUT-MISSING` |

`-10/-11/-12` are **disjoint from the existing digest/HMAC `-1..-5`** (which
`crypto_verify` does not emit except `-5` for arity). The `$ETRAP` sentinel is
**`-99`**, distinct from every C code, so **callout-missing can never be confused
with a C error** — closing N-3.

### `dispatchV` (private, mirrors dispatch4 but rc-as-verdict)

```
dispatchV(sym,alg,key,msg,sig)  ; → 1 valid | 0 invalid; $ECODE set on malformed input
  if $zversion["IRIS" quit $$irisVerify(sym,alg,key,msg,sig)
  new $etrap,rc,cmd
  set $etrap="set $ecode="""" set rc=-99 quit"     ; -99 ≡ callout MISSING
  set rc=-99
  set cmd="set rc=$&stdcrypto."_sym_"(alg,key,msg,sig)"
  xecute cmd
  if rc=1 quit 1                                    ; valid
  if rc=0 quit 0                                    ; invalid — the other non-error return
  if rc=-99 set $ecode=",U-STDCRYPTO-CALLOUT-MISSING," quit 0
  if rc=-10 set $ecode=",U-STDCRYPTO-BADKEY,"          quit 0
  if rc=-11 set $ecode=",U-STDCRYPTO-BADALG,"          quit 0
  set $ecode=",U-STDCRYPTO-VERIFY-FAIL,"               quit 0   ; -5, -12, any other <0
```

Only `rc=1` and `rc=0` are non-error returns; every negative maps to a distinct
`$ECODE`. The four error codes — `CALLOUT-MISSING`, `BADKEY`, `BADALG`,
`VERIFY-FAIL` — are asserted **distinct** by a regression test (the G-ERR RED test).

### `$$verifyAvailable` — symbol-specific probe (N-8)

`$$available` probes only `sha256`, so a stale `.so` (present but pre-`crypto_verify`)
would report available yet every verify raises CALLOUT-MISSING. `$$verifyAvailable`
calls `$$verifySig` with a **known-good self-signed RS256 KAT** and expects `1`,
distinguishing a healthy verify-capable `.so` from a stale one.

**G-ERR exit:** design fixed (this note); the distinct-code test is written RED
before the C/M implementation lands.
