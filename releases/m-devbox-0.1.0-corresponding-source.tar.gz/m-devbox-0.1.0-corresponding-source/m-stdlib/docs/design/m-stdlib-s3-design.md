---
title: m-stdlib S3 Connector — Design Specification
status: draft
version: v0.1
tracker: docs/module-tracker.md
created: 2026-06-07
doc_type: [DESIGN, DRAFT]
---

# m-stdlib S3 Design — AWS S3 Connector for VistA Log Egress — **DRAFT v0.1**

**Working names:** `STDS3` (portable S3 client) + `STDSIGV4` (portable AWS
Signature V4 signer) in **m-stdlib** (`STD*`); `VSLS3` (the VistA-coupled S3 log
sink) in the **v-stdlib** (`VSL*`). Final `VSL*` routine namespace is
DBA-assigned.
**Status:** Draft for review — architecture, contracts, and the boto3→M mapping
only. Nothing here has crossed TDD-red.
**Target platforms:** YottaDB **and** IRIS for Health — one pure-M codebase, byte
mode (`ydb_chset=M`).
**Hard constraint:** No AWS SDK, no JVM, no external signing helper, no
ObjectScript. AWS Signature Version 4 is computed in pure M from the existing
`STDCRYPTO` HMAC/SHA primitives. Anything VistA-specific (socket, TLS, config,
credentials, scheduling) is isolated in `VSL*`.

> **One-line summary:** A portable, pure-M Amazon S3 REST client (`STDS3`) that
> signs requests with an in-M AWS SigV4 implementation (`STDSIGV4`) over the
> existing `STDCRYPTO`/`STDHEX`/`STDHTTP` primitives — paired with a thin
> VistA-coupled sink (`VSLS3`) that streams `STDLOG` records out of a running
> VistA system into an S3 bucket as newline-delimited JSON, so logs never have to
> land in a MUMPS global. This is the **outbound, write-direction** worked
> example named in the [Standard Library architecture §6.2](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#62-example-application-2--vista-log-streaming-to-aws-s3).

---

## Table of Contents

1. [Goals & Non-Goals](#1-goals--non-goals)
2. [Why VistA Needs This — the Logging Gap (VDL-grounded)](#2-why-vista-needs-this--the-logging-gap-vdl-grounded)
3. [Architectural Placement — the Sharp Line](#3-architectural-placement--the-sharp-line)
   - [3.1 End-to-End Architecture — ASCII](#31-end-to-end-architecture--ascii)
   - [3.2 End-to-End Architecture — Mermaid](#32-end-to-end-architecture--mermaid)
   - [3.3 Layer / Component Reference Table](#33-layer--component-reference-table)
4. [Module Map](#4-module-map)
5. [AWS S3 over REST — the SDK Surface We Reimplement](#5-aws-s3-over-rest--the-sdk-surface-we-reimplement)
6. [AWS Signature Version 4 — the Signing Process in Pure M](#6-aws-signature-version-4--the-signing-process-in-pure-m)
7. [Reference Python (boto3) Code → MUMPS Equivalent](#7-reference-python-boto3-code--mumps-equivalent)
   - [7.1 High-level `put_object`](#71-high-level-put_object)
   - [7.2 The SigV4 signing routine](#72-the-sigv4-signing-routine)
   - [7.3 Signed `PutObject` end-to-end](#73-signed-putobject-end-to-end)
   - [7.4 Multipart upload (large log batches)](#74-multipart-upload-large-log-batches)
   - [7.5 `GetObject` / `ListObjectsV2` / `DeleteObject`](#75-getobject--listobjectsv2--deleteobject)
8. [`STDS3` Public API Contract](#8-stds3-public-api-contract)
9. [`STDSIGV4` Public API Contract](#9-stdsigv4-public-api-contract)
10. [Configuration & Credentials Model](#10-configuration--credentials-model)
11. [Interfacing with the v-stdlib — `VSLS3` Log Sink](#11-interfacing-with-the-v-stdlib--vsls3-log-sink)
12. [Security Considerations](#12-security-considerations)
13. [Testing Strategy](#13-testing-strategy)
14. [Open Decisions](#14-open-decisions)
15. [Roadmap](#15-roadmap)
16. [References — AWS S3 SDK & SigV4 Documentation](#16-references--aws-s3-sdk--sigv4-documentation)
17. [References — Example Python (boto3) Code](#17-references--example-python-boto3-code)
18. [References — VistA gold-docs (VDL corpus)](#18-references--vista-gold-docs-vdl-corpus)

> Each numbered section is written to be extractable as a standalone module
> document later; cross-references use section numbers, not page positions.

---

## 1. Goals & Non-Goals

### Goals
- **Pure-M S3 client.** `PUT`, `GET`, `HEAD`, `LIST`, `DELETE`, and multipart
  upload against an Amazon S3 bucket, with **zero** non-M dependency beyond the
  TLS socket the engine already provides.
- **In-M SigV4.** AWS Signature Version 4 (`AWS4-HMAC-SHA256`) computed entirely
  from `STDCRYPTO`'s HMAC-SHA-256 / SHA-256 primitives — no AWS SDK, no shell-out
  to `aws` CLI, no helper service.
- **Portable.** One `STD*` codebase runs identically on YottaDB and IRIS; the only
  engine-specific code (socket open + TLS) lives behind `VSLIO`/`STDNET`.
- **The log-egress worked example.** Stream `STDLOG` records out of VistA to S3 as
  NDJSON, proving the Standard Library architecture's outbound seam end-to-end — *no log
  ever written into a MUMPS global*.
- **Provider-swappable.** The same `STDLOG` calls ship to a different object store
  (GCS/Azure) by swapping the `VSL*` sink, not the application code.

### Non-Goals (v0.1)
- Not a full AWS SDK. Only the S3 operations the log-egress and object-IO use
  cases need; no STS, no IAM, no DynamoDB, no SNS/SQS.
- No SigV4**A** (multi-region `AWS4-ECDSA-P256-SHA256`) — single-region SigV4 only.
- No browser-style POST policy uploads or pre-signed-URL query auth in v0.1
  (Authorization-header auth only; pre-signed URLs noted for a later phase).
- No S3 Select, no event notifications, no bucket administration (create/delete
  bucket, policies, lifecycle) — those are console/IaC concerns, not a log shipper's.
- No credential vending logic — credentials are operator-provisioned config
  (§10); the connector consumes them, it does not mint them.

---

## 2. Why VistA Needs This — the Logging Gap (VDL-grounded)

This is the load-bearing justification, and it is the same one the Standard Library
architecture draws in
[§6.2](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#62-example-application-2--vista-log-streaming-to-aws-s3):

**VistA has no mainstream, always-on logging facility, and the reason is
structural.** The only place a pure-M routine can durably write is a **global**,
and a global lives in the *same database that holds patient data*. A verbose log
global (`^XTMP`, a package-specific log file, a debug global) grows without bound,
inflates **journaling** and **backups**, competes for the same disk and the same
`^%ZIS`/FileMan I/O path as the live clinical workload, and can threaten the
production system. So sites keep logging sparse, ad-hoc, or switched off.

Yet modern operations need the opposite: comprehensive, durable, **externalized**
logs for SIEM/security monitoring, HIPAA audit trails, debugging, and
observability. The fix is to **stop writing logs into the M database** and stream
them to cheap, immutable, lifecycle-managed object storage.

**What the VDL corpus does and does not give us here** (full status in the Standard Library
architecture [§12](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#12-documentation-gaps--status-after-the-v02-corpus-fetch)):

- The **outbound socket path is documented** — Kernel's Device Handler exposes
  `CALL^%ZISTCP` (ICR #2118, *Supported*, IPv6-compliant: `IPADDRESS`/`SOCKET`/
  `TIMEOUT` → `IO`/`POP`) and `CLOSE^%ZISTCP`. This is the exact, DBIA-registered
  primitive `VSLIO` binds to open the TLS socket to S3 (`XU/krn_8_0_dg_device_handler_ug`, §18).
- **TLS is documented** — patch `XU*8*787` introduces the Kernel TLS routines and
  the `DEFAULT TLS SERVER CONFIG` Kernel System Parameter (→ a named IRIS
  `Security.SSLConfigs` entry); a *client*-role TLS config naming the AWS CA bundle
  is the symmetric outbound case (`XU/krn_8_0_tm`, §18).
- **Background scheduling is documented** — a persistent TaskMan task
  (`$$PSET^%ZTLOAD`, ICR #10063) drives the periodic flush, self-healing on
  restart, and `^%ZTLOAD` can queue **without an I/O device** (`ZTIO=""`) — exactly
  the shape for a job that owns its own outbound socket (`XU/krn_8_0_dg_taskman_ug`, §18).
- **Config is documented** — XPAR Parameter Tools (`$$GET^XPAR`, #8989.5/.51) hold
  bucket/region/credential-reference parameters (`XT/ktk7_3p26sp`, §18).
- **What's absent:** the VDL carries **no** AWS-integration, object-storage, or
  cloud-egress guidance for VistA at all — a corpus-wide search returns zero docs.
  This connector is **greenfield** relative to the VDL: there is no prior VistA
  pattern to conform to, only the Kernel primitives above to build on.

> **Conclusion:** every VistA primitive the S3 log shipper needs (outbound socket,
> TLS, background task, hierarchical config) is documented and DBIA-registered in
> the gold corpus. The *AWS* half — SigV4 signing, the S3 REST contract — has no
> VistA precedent and is what this spec contributes, as portable `STD*` code.

---

## 3. Architectural Placement — the Sharp Line

This connector obeys the Standard Library architecture's
[sharp-line principle](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#12-the-principle)
verbatim: **engine-agnostic capability is `STD*`; VistA-specific binding is
`VSL*`; nothing VistA leaks up into `STD*`, nothing portable is reimplemented in
`VSL*`.**

The S3 connector splits cleanly because **everything about talking to S3 is
portable** and **everything about being inside VistA is not**:

| Concern | Portable? | Home |
|---|---|---|
| SigV4 canonical request, string-to-sign, signing-key derivation, signature | ✅ pure math over HMAC/SHA | `STDSIGV4` (`STD*`) |
| S3 REST request construction (method, host, path, `x-amz-*` headers) | ✅ string building | `STDS3` (`STD*`) |
| NDJSON batch serialization | ✅ | `STDJSON` (`STD*`) |
| Payload SHA-256, hex encoding | ✅ | `STDCRYPTO` / `STDHEX` (`STD*`) |
| HTTP/1.1 framing of the request/response | ✅ | `STDHTTP` / `STDHTTPMSG` (`STD*`) |
| Opening the **TLS socket** to `s3.<region>.amazonaws.com` | ❌ engine-specific | `VSLIO` → `CALL^%ZISTCP` |
| **Where credentials live** (XPAR vs `.env`) | ❌ VistA-native | `VSLCFG` → `$$GET^XPAR` |
| **What drives the flush** (TaskMan vs cron) | ❌ VistA-native | `VSLTASK` → `^%ZTLOAD` |
| **What feeds the logs** (`STDLOG` sink binding) | ❌ side-effecting seam | `VSLS3` |
| Packaging (KIDS build, env-check, namespace) | ❌ VistA-native | `VSLBLD` |

**The payoff of the split:** `STDS3` + `STDSIGV4` are usable by *any* pure-M
program — a YottaDB batch job, an m-cli command, a non-VistA service — with no
VistA present. The same routines, unchanged, become a VistA log shipper when
`VSLS3` binds them to `STDLOG` + XPAR + TaskMan + `^%ZIS`. That is exactly the
reuse the Standard Library architecture is built to produce.

### 3.1 End-to-End Architecture — ASCII

The full path a log record travels from a VistA package to an immutable S3
object. **Every component carries a stable ID (`[P1]`, `[S1]`, `[V1]`, …) used
identically in the [Mermaid diagram (§3.2)](#32-end-to-end-architecture--mermaid)
and the [component table (§3.3)](#33-layer--component-reference-table).** Bands are
the architecture layers; the single bold line is the network / trust boundary —
the only thing that ever leaves the M system is one SigV4-signed `PUT` crossing it.

```
 ╔═══════════════════════════════════════════════════════════════════════════╗
 ║  VistA host — single trust domain (the live clinical system)              ║
 ╠═══════════════════════════════════════════════════════════════════════════╣
 ║  PRODUCERS   [P1] VistA application code — ANY package                    ║
 ║                   do info^STDLOG(level,msg,…)   ← has no knowledge of S3   ║
 ║                          │ log record (flat M array)                      ║
 ║                          ▼                                                 ║
 ║  ┌─ Layer 2 · m-stdlib  STD*  (portable · YDB+IRIS · zero VistA) ────────┐ ║
 ║  │ [S1] STDLOG          logging API + sink seam ──▶ bound to [V1] VSLS3   │ ║
 ║  │ [S2] STDJSON         log records → NDJSON batch                        │ ║
 ║  │ [S3] STDSIGV4        AWS SigV4: canonical-req → string-to-sign → sig   │ ║
 ║  │ [S4] STDCRYPTO+STDHEX HMAC-SHA256 signing chain · SHA-256 · hex        │ ║
 ║  │ [S5] STDS3           PUT / multipart request builder (calls S3 + S4)   │ ║
 ║  │ [S6] STDHTTP(MSG)    HTTP/1.1 framing of the signed request            │ ║
 ║  └──────────────────────────┬─────────────────────────────────────────────┘ ║
 ║       portable bytes — nothing above knows it is running inside VistA      ║
 ║                             ▼                                              ║
 ║  ┌─ Layer 3 · v-stdlib  VSL*  (VistA-coupled · KIDS-installed) ──────┐ ║
 ║  │ [V1] VSLS3   log sink: batch · spool · compose key · ship  (drives S5) │ ║
 ║  │ [V2] VSLIO   open the client TLS socket to the S3 endpoint             │ ║
 ║  │ [V3] VSLCFG  bucket / region / endpoint / credential reference         │ ║
 ║  │ [V4] VSLTASK background periodic flusher (drives V1)                   │ ║
 ║  │ [V5] VSLBLD  KIDS build + env-check  (install-time · off the data path)│ ║
 ║  └────┬───────────────┬───────────────┬──────────────────┬─────────────────┘ ║
 ║       ▼               ▼               ▼                  ▼                  ║
 ║  ┌─ Layer 4 · VistA internals ─────────────────────────────────────────┐  ║
 ║  │ [K1] XPAR          [K2] TaskMan         [K3] Device Handler          │  ║
 ║  │  #8989.5/.51        ^%ZTLOAD             ^%ZIS / CALL^%ZISTCP + named │  ║
 ║  │  S3 config params   flush job ($$PSET)   client TLS config (ICR #2118)│  ║
 ║  └──────────────────────────────────────────────────────┬───────────────┘  ║
 ║  ┌─ Layer 1 · M engine: YottaDB | IRIS for Health (byte mode) ── [E1] ─┐  ║
 ║  └───────────────────────────────────────────────────────│─────────────┘  ║
 ║                                                           │                ║
 ║  [X1] ✗ legacy ^XTMP / log global — what we DO NOT do: it grows inside     ║
 ║        the live clinical DB (journaling/backup/disk pressure) — the        ║
 ║        structural reason VistA barely logs today.                          ║
 ╚═══════════════════════════════════════════════════════════╪═══════════════╝
                                                              │ HTTPS PUT
        ═══════ network / trust boundary ═════════════════════╪═ SigV4-signed ═
                                                              ▼
 ┌─ ☁ AWS Cloud — external service · separate trust domain · off the M DB ───┐
 │ [A1] S3 bucket   NDJSON log objects                                        │
 │        key: vista/<station>/<yyyy>/<mm>/<dd>/<seq>.ndjson                   │
 │          ├──▶ [A2] lifecycle policy · Object Lock (immutable HIPAA audit)  │
 │          └──▶ [A3] Athena SELECT · SIEM ingestion · observability          │
 └────────────────────────────────────────────────────────────────────────────┘
```

**Read it as a flow:** `[P1]` a package logs → `[S1]` `STDLOG` hands the record to
its bound sink `[V1]` `VSLS3`, which buffers it (never writing through) → on a
`[V4]` `VSLTASK` tick (config from `[K1]`/`[V3]`), the batch is serialized `[S2]`,
hashed + signed `[S3]`/`[S4]`, built into a `PUT` `[S5]` and framed `[S6]` → `[V2]`
`VSLIO` opens the TLS socket via `[K3]` `CALL^%ZISTCP` → the signed request crosses
the **trust boundary** to `[A1]` the S3 bucket → downstream `[A2]`/`[A3]` lifecycle,
immutability, and query happen entirely off the live database. `[X1]` is the legacy
in-database sink this whole path exists to replace.

### 3.2 End-to-End Architecture — Mermaid

The same architecture as a rendered graph; node IDs match §3.1 and §3.3 exactly.

```mermaid
flowchart TB
    subgraph PROD["VistA log producers — any package"]
        P1["[P1] VistA application code<br/>do info^STDLOG(level,msg,…)<br/><i>no knowledge of S3</i>"]
    end

    X1["[X1] ✗ legacy sink: ^XTMP / log global<br/>grows in the live clinical DB<br/>— why VistA barely logs today"]

    subgraph L2["Layer 2 — m-stdlib · STD* (portable · YDB+IRIS · no VistA)"]
        direction TB
        S1["[S1] STDLOG<br/>logging API + sink seam"]
        S2["[S2] STDJSON<br/>records → NDJSON batch"]
        S3["[S3] STDSIGV4<br/>AWS SigV4 signer"]
        S4["[S4] STDCRYPTO + STDHEX<br/>HMAC-SHA256 chain · SHA-256 · hex"]
        S5["[S5] STDS3<br/>PUT / multipart request builder"]
        S6["[S6] STDHTTP / STDHTTPMSG<br/>HTTP/1.1 framing"]
    end

    subgraph L3["Layer 3 — v-stdlib · VSL* (VistA-coupled · KIDS)"]
        direction TB
        V1["[V1] VSLS3<br/>log sink: batch · spool · key · ship"]
        V2["[V2] VSLIO<br/>client TLS socket open"]
        V3["[V3] VSLCFG<br/>bucket / region / creds"]
        V4["[V4] VSLTASK<br/>background flusher"]
        V5["[V5] VSLBLD<br/>KIDS build + env-check"]
    end

    subgraph L4["Layer 4 — VistA internals"]
        direction LR
        K1["[K1] XPAR<br/>#8989.5/.51 · S3 config"]
        K2["[K2] TaskMan<br/>^%ZTLOAD · $$PSET flush job"]
        K3["[K3] Device Handler<br/>^%ZIS / CALL^%ZISTCP + TLS<br/>(ICR #2118)"]
    end

    E1["[E1] Layer 1 — M engine: YottaDB | IRIS for Health (byte mode)"]

    subgraph CLOUD["☁ AWS Cloud — external service · separate trust domain · off the M database"]
        A1["[A1] S3 bucket<br/>NDJSON log objects<br/>vista/&lt;station&gt;/&lt;yyyy&gt;/&lt;mm&gt;/&lt;dd&gt;/&lt;seq&gt;.ndjson"]
        A2["[A2] lifecycle policy · Object Lock<br/>immutable HIPAA audit"]
        A3["[A3] Athena SELECT · SIEM ingest · observability"]
    end

    P1 -->|"do log^STDLOG()"| S1
    X1 -. "what we DON'T do" .-> S1
    S1 -. "sink bound to (replaces global)" .-> V1
    V4 -. "drives periodic flush" .-> V1
    V1 --> S2 --> S5
    S5 --> S3 --> S4
    S5 --> S6 --> V2
    V1 --> V3
    V3 --> K1
    V4 --> K2
    V2 --> K3

    L2 --> E1
    L3 --> E1
    L4 --> E1

    V2 ==>|"HTTPS PUT · SigV4-signed — crosses the network / trust boundary"| A1
    A1 --> A2
    A1 --> A3

    classDef portable fill:#e6f2ff,stroke:#3399ff;
    classDef vista fill:#fff0e6,stroke:#ff8c1a;
    classDef internals fill:#eaffea,stroke:#33cc33;
    classDef ext fill:#f3e6ff,stroke:#9933ff,stroke-dasharray: 5 3;
    classDef producer fill:#f7f7f7,stroke:#888888;
    classDef bad fill:#ffe6e6,stroke:#cc0000,stroke-dasharray: 3 3;
    class S1,S2,S3,S4,S5,S6 portable;
    class V1,V2,V3,V4,V5 vista;
    class K1,K2,K3 internals;
    class A1,A2,A3 ext;
    class P1 producer;
    class X1 bad;

    style PROD fill:#fcfcfc,stroke:#bbbbbb;
    style L2 fill:#f3f9ff,stroke:#3399ff,stroke-width:2px;
    style L3 fill:#fff8f2,stroke:#ff8c1a,stroke-width:2px;
    style L4 fill:#f3fff3,stroke:#33cc33,stroke-width:2px;
    style CLOUD fill:#faf3ff,stroke:#9933ff,stroke-width:3px,stroke-dasharray:8 5;
```

### 3.3 Layer / Component Reference Table

Every node in the [ASCII (§3.1)](#31-end-to-end-architecture--ascii) and
[Mermaid (§3.2)](#32-end-to-end-architecture--mermaid) diagrams, by ID. The
**Engine-specific?** column is the whole point of the architecture: only the five
`VSL*` rows and the three Layer-4 rows are VistA-coupled; everything in Layer 2 is
portable `STD*` that runs anywhere.

| ID | Layer | Component | Role — what it does in the log-to-S3 path | Engine-specific? |
|---|---|---|---|---|
| **[P1]** | Producers | VistA application code (any package) | Emits a log line via the ordinary `STDLOG` API; has **no knowledge** of batching, signing, or S3. Decouples every caller from the egress mechanism. | VistA caller, but uses only the portable API |
| **[S1]** | L2 · `STD*` | `STDLOG` | The logging API **and the pluggable sink seam**. Under VistA its sink is bound to `[V1]`; the call site never changes. | ❌ portable (the *binding* is VistA, §11.1) |
| **[S2]** | L2 · `STD*` | `STDJSON` | Serializes a batch of log records to **NDJSON** (one JSON object per line). | ❌ portable |
| **[S3]** | L2 · `STD*` | `STDSIGV4` | Computes the **AWS Signature V4**: canonical request → string-to-sign → signing-key chain → signature → `Authorization` header (§6, §9). | ❌ portable |
| **[S4]** | L2 · `STD*` | `STDCRYPTO` + `STDHEX` | Supplies the crypto primitives SigV4 needs: raw-byte HMAC-SHA-256 chain, SHA-256 payload hash, hex encoding. Byte-mode-exact. | ❌ portable |
| **[S5]** | L2 · `STD*` | `STDS3` | Builds the S3 REST request (host, URI, `x-amz-*` headers), calls `[S3]` to sign, returns status. `putObject` / multipart (§5, §8). | ❌ portable |
| **[S6]** | L2 · `STD*` | `STDHTTP` / `STDHTTPMSG` | Frames the signed request as HTTP/1.1 bytes and parses the response. | ❌ portable |
| **[V1]** | L3 · `VSL*` | `VSLS3` | The **`STDLOG` sink adapter**: buffers records, spools, composes the object key, drives `[S5]` on flush. The only S3-specific `VSL*` module; provider-swappable (§11.6). | ✅ VistA-coupled |
| **[V2]** | L3 · `VSL*` | `VSLIO` | Opens the **client TLS socket** to the S3 endpoint — the single engine-specific hop on the data path (§11.3). | ✅ VistA-coupled (over `[K3]`) |
| **[V3]** | L3 · `VSL*` | `VSLCFG` | Resolves bucket / region / endpoint / credential reference from XPAR (§10). | ✅ VistA-coupled (over `[K1]`) |
| **[V4]** | L3 · `VSL*` | `VSLTASK` | The **background flusher** — wakes on interval or batch-size and drives `[V1]` (§11.2). Logging is never synchronous on the network. | ✅ VistA-coupled (over `[K2]`) |
| **[V5]** | L3 · `VSL*` | `VSLBLD` | KIDS build manifest + environment-check routine (engine/TLS/Kernel-patch). **Install-time only — off the runtime data path.** | ✅ VistA-coupled |
| **[K1]** | L4 internals | XPAR (#8989.5/.51) | VistA's native hierarchical config store; holds the `VSLS3 *` parameters. Cited: `XT/ktk7_3p26sp` (§18). | ✅ VistA |
| **[K2]** | L4 internals | TaskMan (`^%ZTLOAD`) | Schedules the persistent, self-healing flush task (`$$PSET^%ZTLOAD`, ICR #10063; queue-without-device). Cited: `XU/krn_8_0_dg_taskman_ug` (§18). | ✅ VistA |
| **[K3]** | L4 internals | Device Handler (`^%ZIS`) | Opens the outbound TLS socket via `CALL^%ZISTCP` (ICR #2118) against a named client TLS config. Cited: `XU/krn_8_0_dg_device_handler_ug`, `XU/krn_8_0_tm` (§18). | ✅ VistA |
| **[E1]** | L1 engine | YottaDB \| IRIS for Health | The M engine in **byte mode** (`ydb_chset=M`) — what makes the SigV4 raw-byte HMAC chain exact (§6). | ✅ engine |
| **[A1]** | AWS Cloud | S3 bucket | Receives the signed `PUT`; stores log batches as immutable NDJSON objects under a date-partitioned key. | ⬛ external |
| **[A2]** | AWS Cloud | Lifecycle / Object Lock | Auto-expire/archive + tamper-evident immutability for HIPAA audit — *free*, no M code (§11.5). | ⬛ external |
| **[A3]** | AWS Cloud | Athena / SIEM / observability | Ad-hoc `SELECT` over NDJSON, SIEM ingestion, dashboards — all off the live database (§11.5). | ⬛ external |
| **[X1]** | (anti-pattern) | `^XTMP` / log global | The legacy in-database sink this architecture **replaces** — grows in the clinical DB, the structural reason VistA avoids logging (§2). | ✅ VistA (rejected) |

---

## 4. Module Map

**New in m-stdlib (`STD*` — portable, YDB + IRIS, no VistA dependency):**

| Module | Role | Depends on | Status |
|---|---|---|---|
| `STDSIGV4` | AWS Signature Version 4 signer: canonical request, string-to-sign, signing-key chain, `Authorization` header. Service-generic (works for any AWS SigV4 service, S3 is the first consumer). | `STDCRYPTO` (HMAC/SHA), `STDHEX`, `STDURL` (percent-encoding), `STDDATE` | **propose** |
| `STDS3` | S3 REST client: `putObject`, `getObject`, `headObject`, `listObjectsV2`, `deleteObject`, `deleteObjects`, and the three multipart calls. Builds the request, calls `STDSIGV4` to sign, hands bytes to the HTTP layer. | `STDSIGV4`, `STDHTTP`/`STDHTTPMSG`, `STDJSON`, `STDXML` (ListObjects/multipart parse), `STDURL` | **propose** |

**New in v-stdlib (`VSL*` — VistA-coupled, KIDS-distributed):**

| Module | Role | VistA back end |
|---|---|---|
| `VSLS3` | The `STDLOG` **sink adapter**: batch → spool → serialize (NDJSON) → sign (`STDS3`) → ship. Named in Standard Library architecture §6.2. | binds `STDLOG`'s sink seam |
| `VSLIO` | Opens the client TLS socket to the S3 endpoint. | `CALL^%ZISTCP` (ICR #2118) + named client TLS config |
| `VSLCFG` | Bucket / region / endpoint / credential-reference accessor. | `$$GET^XPAR` (#8989.5/.51) |
| `VSLTASK` | Background periodic-flush driver. | `$$PSET^%ZTLOAD` (ICR #10063) persistent task |

> `VSLIO`, `VSLCFG`, `VSLTASK` are the **same shared `VSL*` adapters** the Standard
> Library architecture already defines for the whole VSL library — the S3 connector reuses
> them, it does not introduce its own socket/config/task machinery. Only `VSLS3`
> (the sink) is S3-specific, and even it is provider-swappable (`VSLGCS`/`VSLAZ`
> drop in behind the same `STDLOG` seam).

---

## 5. AWS S3 over REST — the SDK Surface We Reimplement

The official AWS SDKs (boto3, AWS SDK for Java, etc.) are convenience wrappers
over the **Amazon S3 REST API**. Because the REST API is a stable, documented
HTTP contract, a pure-M client reimplements the *thin slice* the SDK would
otherwise generate. The operations this connector needs:

| S3 operation | HTTP | Request-target (virtual-hosted-style) | Body | Success |
|---|---|---|---|---|
| **PutObject** | `PUT` | `https://<bucket>.s3.<region>.amazonaws.com/<key>` | object bytes | `200 OK` + `ETag` |
| **GetObject** | `GET` | `…/<key>` | — | `200 OK` + object bytes |
| **HeadObject** | `HEAD` | `…/<key>` | — | `200 OK` + metadata headers |
| **ListObjectsV2** | `GET` | `…/?list-type=2&prefix=<p>` | — | `200 OK` + XML listing |
| **DeleteObject** | `DELETE` | `…/<key>` | — | `204 No Content` |
| **CreateMultipartUpload** | `POST` | `…/<key>?uploads` | — | `200 OK` + `<UploadId>` (XML) |
| **UploadPart** | `PUT` | `…/<key>?partNumber=N&uploadId=<id>` | part bytes | `200 OK` + `ETag` |
| **CompleteMultipartUpload** | `POST` | `…/<key>?uploadId=<id>` | XML part list | `200 OK` + XML |

**Endpoint addressing.** Virtual-hosted-style
(`<bucket>.s3.<region>.amazonaws.com`) is the default and is what SigV4's `Host`
canonical header signs; path-style
(`s3.<region>.amazonaws.com/<bucket>/<key>`) is supported as a config fallback
(§10, D-S3-2). The bucket name is part of the **`Host` header**, not the
canonical URI, in virtual-hosted-style — this matters for the signature.

**The three mandatory signed pieces** every request carries (from the AWS S3
Authorization-header doc, §16):

1. `Host` — the endpoint host (signs the bucket in virtual-hosted-style).
2. `x-amz-date` — request timestamp, **`YYYYMMDDgHHMMSSZ`** basic-ISO form (note:
   `STDDATE`'s `$$now` returns *extended* ISO with separators; `STDSIGV4` strips
   them — see §6).
3. `x-amz-content-sha256` — either the **hex SHA-256 of the payload** (signed
   payload, recommended) or the literal `UNSIGNED-PAYLOAD`.

The `Authorization` header then carries
`AWS4-HMAC-SHA256 Credential=…, SignedHeaders=…, Signature=…`.

---

## 6. AWS Signature Version 4 — the Signing Process in Pure M

SigV4 is four steps. Each maps directly onto an existing `STDCRYPTO`/`STDHEX`
primitive — which is *why* a pure-M signer is feasible with no new crypto code.

**Step 1 — Canonical Request.** A newline-joined string:

```
<HTTPMethod>\n
<CanonicalURI>\n               ; URI-encoded path, "/" not encoded
<CanonicalQueryString>\n       ; sorted, URI-encoded key=value&…
<CanonicalHeaders>\n           ; lowercased "name:trimmed-value\n", sorted by name
<SignedHeaders>\n              ; lowercased ";"-joined header names
<HashedPayload>                ; hex SHA-256 of body, or UNSIGNED-PAYLOAD
```

Then hash it: `CR_HASH = SHA256_hex(CanonicalRequest)`.
→ M: `$$sha256^STDCRYPTO(cr)` (already returns 64-char lowercase hex).

**Step 2 — String to Sign.**

```
AWS4-HMAC-SHA256\n
<x-amz-date YYYYMMDD'T'HHMMSS'Z'>\n
<yyyymmdd>/<region>/<service>/aws4_request\n   ; the Credential Scope
<CR_HASH>
```

**Step 3 — Signing Key** (an HMAC chain; each step keys the next):

```
kDate    = HMAC_SHA256("AWS4"+secretKey, yyyymmdd)
kRegion  = HMAC_SHA256(kDate,   region)
kService = HMAC_SHA256(kRegion, service)        ; "s3"
kSigning = HMAC_SHA256(kService, "aws4_request")
```

→ M: each line is `$$hmacSha256Bytes^STDCRYPTO(key,data)` (raw-byte output so the
next HMAC keys on raw bytes, **not** hex — this is the single most common SigV4
bug, and byte mode `ydb_chset=M` makes it exact).

**Step 4 — Signature** (hex, this time):

```
signature = HEX( HMAC_SHA256(kSigning, StringToSign) )
```

→ M: `$$hmacSha256^STDCRYPTO(kSigning,sts)` (the hex variant).

**Authorization header:**

```
AWS4-HMAC-SHA256 Credential=<accessKey>/<scope>, SignedHeaders=<signed>, Signature=<signature>
```

> **Byte-mode correctness.** The signing-key chain passes **raw 32-byte HMAC
> outputs** as keys. Under `ydb_chset=UTF-8`, bytes > 127 would re-encode and the
> chain would silently produce a wrong (but well-formed) signature → `403
> SignatureDoesNotMatch`. m-stdlib's mandated **byte mode** (`ydb_chset=M`,
> `$ZCHAR`/`$ZASCII`-exact) is exactly what makes the raw-byte chain reliable.
> `STDSIGV4`'s test vectors are the AWS-published SigV4 examples, asserted
> byte-exact.

---

## 7. Reference Python (boto3) Code → MUMPS Equivalent

The official AWS SDK for Python (**boto3**) is the reference implementation. Two
layers matter: the **high-level client** (what an application calls) and the
**low-level SigV4 signer** (what boto3/botocore does internally, and what AWS
documents as a standalone Python example — §17). `STDS3` mirrors the first;
`STDSIGV4` mirrors the second.

### 7.1 High-level `put_object`

**Python (boto3) — AWS S3 `put_object` reference:**

```python
import boto3

s3 = boto3.client("s3", region_name="us-east-1")
resp = s3.put_object(
    Bucket="my-vista-logs",
    Key="vista/2026/06/07/site508-batch-0001.ndjson",
    Body=ndjson_bytes,
    ContentType="application/x-ndjson",
    ServerSideEncryption="AES256",
)
etag = resp["ETag"]
```

**MUMPS equivalent (`STDS3`) — same call shape, explicit creds:**

```M
 ; build a credential context once (access key / secret / region / service)
 new ctx
 set ctx("accessKey")=ak,ctx("secretKey")=sk,ctx("region")="us-east-1",ctx("service")="s3"
 ;
 new opt,resp
 set opt("contentType")="application/x-ndjson"
 set opt("sse")="AES256"                          ; → x-amz-server-side-encryption
 set status=$$putObject^STDS3(.ctx,"my-vista-logs","vista/2026/06/07/site508-batch-0001.ndjson",ndjson,.opt,.resp)
 if status'=200 set $ec=",U-STDS3-PUT-"_status_","
 set etag=resp("header","etag")
```

`boto3` reads credentials/region from the environment or `~/.aws/config`; the
portable `STDS3` takes them as an explicit `ctx` array (no ambient state — that is
`VSLCFG`'s job under VistA, §10).

### 7.2 The SigV4 signing routine

This is the heart of the connector. AWS publishes a standalone Python example of
the *complete* SigV4 signing process (§17); `STDSIGV4` is its line-for-line M
translation. The shared helper from the AWS example:

**Python (AWS SigV4 example):**

```python
import hmac, hashlib

def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

def signing_key(secret, datestamp, region, service):
    kDate    = sign(("AWS4" + secret).encode("utf-8"), datestamp)
    kRegion  = sign(kDate, region)
    kService = sign(kRegion, service)
    kSigning = sign(kService, "aws4_request")
    return kSigning

# canonical request → string to sign → signature
canonical_request = "\n".join([method, canonical_uri, canonical_qs,
                               canonical_headers, signed_headers, payload_hash])
string_to_sign = "\n".join([
    "AWS4-HMAC-SHA256", amzdate,
    f"{datestamp}/{region}/{service}/aws4_request",
    hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
])
signature = hmac.new(signing_key(secret, datestamp, region, service),
                     string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()
```

**MUMPS equivalent (`STDSIGV4`):**

```M
signingKey(secret,datestamp,region,service) ; raw 32-byte SigV4 signing key
 new kDate,kRegion,kService
 set kDate=$$hmacSha256Bytes^STDCRYPTO("AWS4"_secret,datestamp)
 set kRegion=$$hmacSha256Bytes^STDCRYPTO(kDate,region)
 set kService=$$hmacSha256Bytes^STDCRYPTO(kRegion,service)
 quit $$hmacSha256Bytes^STDCRYPTO(kService,"aws4_request")
 ;
sign(ctx,method,uri,query,headers,payloadHash,amzdate,datestamp) ; → signature hex + Authorization
 new cr,sts,key,sig,canHdr,signed
 ; build canonical headers (lowercased, sorted, "name:value" lines) + signed list
 do canonHeaders(.headers,.canHdr,.signed)
 set cr=method_$c(10)_uri_$c(10)_query_$c(10)_canHdr_$c(10)_signed_$c(10)_payloadHash
 set sts="AWS4-HMAC-SHA256"_$c(10)_amzdate_$c(10)
 set sts=sts_datestamp_"/"_ctx("region")_"/"_ctx("service")_"/aws4_request"_$c(10)
 set sts=sts_$$sha256^STDCRYPTO(cr)                  ; hex hash of canonical request
 set key=$$signingKey(ctx("secretKey"),datestamp,ctx("region"),ctx("service"))
 set sig=$$hmacSha256^STDCRYPTO(key,sts)             ; hex signature
 quit sig
```

The `$c(10)` is LF; `canonHeaders` lowercases names, trims values, sorts, and
emits both the `name:value\n…` block and the `;`-joined signed-headers list. Note
the deliberate asymmetry that trips every first SigV4 implementation: **Steps 1–3
key on raw bytes (`…Bytes`), Step 4 emits hex (`hmacSha256`).**

### 7.3 Signed `PutObject` end-to-end

**Python (boto3 low-level, the request botocore assembles):**

```python
amzdate   = now.strftime("%Y%m%dT%H%M%SZ")
datestamp = now.strftime("%Y%m%d")
payload_hash = hashlib.sha256(body).hexdigest()
headers = {
    "host": f"{bucket}.s3.{region}.amazonaws.com",
    "x-amz-date": amzdate,
    "x-amz-content-sha256": payload_hash,
    "content-type": "application/x-ndjson",
}
# … sign(...) as in 7.2 → Authorization header …
requests.put(url, data=body, headers=headers)
```

**MUMPS equivalent (`STDS3` `putObject`, the assembled flow):**

```M
putObject(ctx,bucket,key,body,opt,resp) ; PUT an object; returns HTTP status
 new host,uri,amzdate,datestamp,phash,h,auth,req
 set host=bucket_".s3."_ctx("region")_".amazonaws.com"
 set uri="/"_$$encPath^STDSIGV4(key)                 ; URI-encode key, keep "/"
 set amzdate=$$amzDate^STDSIGV4()                     ; YYYYMMDDTHHMMSSZ (UTC)
 set datestamp=$e(amzdate,1,8)
 set phash=$$sha256^STDCRYPTO(body)                   ; signed-payload hash
 ; headers that get signed
 set h("host")=host,h("x-amz-date")=amzdate,h("x-amz-content-sha256")=phash
 if $g(opt("contentType"))'="" set h("content-type")=opt("contentType")
 if $g(opt("sse"))'="" set h("x-amz-server-side-encryption")=opt("sse")
 set auth=$$authHeader^STDSIGV4(.ctx,"PUT",uri,"",.h,phash,amzdate,datestamp)
 ; assemble + send via the portable HTTP layer (socket open is VSLIO under VistA)
 set req("method")="PUT",req("url")="https://"_host_uri,req("body")=body
 merge req("header")=h set req("header","Authorization")=auth
 quit $$request^STDHTTP(.req,.resp)
```

Every line above is portable. Under VistA, the single non-portable step —
`$$request^STDHTTP` opening the TLS socket — is swapped for the `VSLIO` socket
adapter (`CALL^%ZISTCP` + client TLS config); nothing else changes.

### 7.4 Multipart upload (large log batches)

For batches over the single-`PUT` threshold (S3 caps a single `PUT` at 5 GiB;
the connector's config threshold is far lower, ~8 MiB, D-S3-3), boto3's
`upload_fileobj` / the `create_multipart_upload` → `upload_part` →
`complete_multipart_upload` trio applies.

**Python (boto3 low-level multipart):**

```python
mpu = s3.create_multipart_upload(Bucket=b, Key=k)
parts = []
for i, chunk in enumerate(chunks, start=1):
    r = s3.upload_part(Bucket=b, Key=k, PartNumber=i,
                       UploadId=mpu["UploadId"], Body=chunk)
    parts.append({"PartNumber": i, "ETag": r["ETag"]})
s3.complete_multipart_upload(
    Bucket=b, Key=k, UploadId=mpu["UploadId"],
    MultipartUpload={"Parts": parts})
```

**MUMPS equivalent (`STDS3`):**

```M
 new uid,parts,i,etag
 set uid=$$createMultipart^STDS3(.ctx,b,k)            ; parses <UploadId> from XML
 for i=1:1:nChunks do
 . set status=$$uploadPart^STDS3(.ctx,b,k,uid,i,chunk(i),.pr)
 . set parts(i)=pr("header","etag")                  ; PartNumber → ETag
 set status=$$completeMultipart^STDS3(.ctx,b,k,uid,.parts)  ; builds the XML part list
```

`createMultipart` and `completeMultipart` parse/emit the small S3 XML payloads
with `STDXML` (the only place S3 still speaks XML rather than JSON). Each
`uploadPart` is an independently-signed `PUT` — the SigV4 path of §7.3 reused.

### 7.5 `GetObject` / `ListObjectsV2` / `DeleteObject`

**Python (boto3):**

```python
obj   = s3.get_object(Bucket=b, Key=k)["Body"].read()
listing = s3.list_objects_v2(Bucket=b, Prefix="vista/2026/06/")
s3.delete_object(Bucket=b, Key=k)
```

**MUMPS equivalent (`STDS3`):**

```M
 set status=$$getObject^STDS3(.ctx,b,k,.resp)          ; resp("body")=object bytes
 set status=$$listObjectsV2^STDS3(.ctx,b,"vista/2026/06/",.listing) ; listing(n,"key")=…
 set status=$$deleteObject^STDS3(.ctx,b,k)             ; 204 on success
```

`getObject`/`deleteObject` sign an empty body (the well-known empty-string SHA-256
constant, which `STDSIGV4` caches); `listObjectsV2` signs the canonical query
string (`list-type=2&prefix=…`, URI-encoded and sorted) and parses the result
XML into a `listing(n,…)` array with `STDXML`, following the `IsTruncated` /
`NextContinuationToken` pagination loop.

---

## 8. `STDS3` Public API Contract

All entry points take a credential context `ctx` (by reference) and return an
**integer HTTP status** (or `0` on transport failure, mirroring `STDHTTP`'s
convention); response detail comes back in a by-reference `resp`/`listing` array.

| Entry point | Signature | Returns |
|---|---|---|
| `putObject` | `(ctx,bucket,key,body,opt,resp)` | status; `resp("header",*)`, `resp("header","etag")` |
| `getObject` | `(ctx,bucket,key,resp)` | status; `resp("body")`, `resp("header",*)` |
| `headObject` | `(ctx,bucket,key,resp)` | status; `resp("header",*)` (size/etag/metadata) |
| `listObjectsV2` | `(ctx,bucket,prefix,listing)` | status; `listing(n,"key"/"size"/"etag")`, `listing("truncated")`, `listing("next")` |
| `deleteObject` | `(ctx,bucket,key)` | status (204 expected) |
| `deleteObjects` | `(ctx,bucket,keys,resp)` | status; batch delete (XML body) |
| `createMultipart` | `(ctx,bucket,key[,opt])` | uploadId string (`""`/`$ec` on error) |
| `uploadPart` | `(ctx,bucket,key,uploadId,partNo,body,resp)` | status; `resp("header","etag")` |
| `completeMultipart` | `(ctx,bucket,key,uploadId,parts)` | status |
| `abortMultipart` | `(ctx,bucket,key,uploadId)` | status (204 expected) |

`opt` subscripts (all optional): `contentType`, `sse`
(`x-amz-server-side-encryption`), `sseKmsKeyId`, `storageClass`
(`x-amz-storage-class`), `acl`, `meta(<name>)` (→ `x-amz-meta-<name>`),
`endpoint` (override host for path-style / S3-compatible stores), `timeoutMs`.

**Error convention:** non-2xx responses set `$ec=",U-STDS3-<op>-<status>,"` only at
the `VSLS3`/caller boundary; the core entry points *return* the status so callers
can implement retry/backoff without an `$ETRAP`. S3 error XML (`<Code>`/`<Message>`)
is parsed into `resp("error","code")` / `resp("error","message")`.

---

## 9. `STDSIGV4` Public API Contract

Service-generic (S3 is the first consumer; the same module signs any AWS SigV4
REST service).

| Entry point | Signature | Returns |
|---|---|---|
| `authHeader` | `(ctx,method,uri,query,headers,payloadHash,amzdate,datestamp)` | the full `Authorization` header value |
| `sign` | `(ctx,method,uri,query,headers,payloadHash,amzdate,datestamp)` | 64-char hex signature |
| `signingKey` | `(secret,datestamp,region,service)` | raw 32-byte signing key |
| `canonRequest` | `(method,uri,query,headers,payloadHash,.signed)` | canonical-request string (+ signed-headers list by ref) |
| `amzDate` | `()` | current UTC `YYYYMMDDgHHMMSSZ` (basic ISO; derived from `$$now^STDDATE`, separators stripped) |
| `encPath` | `(key)` | URI-encode an object key, preserving `/` (RFC-3986, `STDURL`-based) |
| `encQuery` | `(.params)` | sorted, URI-encoded canonical query string |
| `emptyHash` | `()` | the cached empty-payload SHA-256 (`e3b0c442…b855`) |

`ctx` subscripts: `accessKey`, `secretKey`, `region`, `service`, and optionally
`sessionToken` (→ adds `x-amz-security-token` to the signed headers, for temporary
STS credentials).

---

## 10. Configuration & Credentials Model

Portable `STDS3`/`STDSIGV4` are **stateless about config** — they take an explicit
`ctx`. Under VistA, `VSLCFG` builds that `ctx` from **XPAR parameters**
(`$$GET^XPAR`, #8989.5/.51, with the standard `USR > LOC > SRV > DIV > SYS > PKG`
precedence — `XT/ktk7_3p26sp`, §18):

| XPAR parameter (illustrative) | Scope | Purpose |
|---|---|---|
| `VSLS3 BUCKET` | SYS | Target log bucket |
| `VSLS3 REGION` | SYS | AWS region (e.g. `us-gov-west-1` for GovCloud) |
| `VSLS3 ENDPOINT` | SYS | Host override (path-style / S3-compatible / FIPS endpoint) |
| `VSLS3 TLS CLIENT CONFIG` | SYS | Named client TLS config (CA bundle) for `VSLIO` |
| `VSLS3 KEY PREFIX` | SYS/DIV | Object-key prefix (e.g. `vista/<station>/`) |
| `VSLS3 SSE` | SYS | Server-side encryption mode (`AES256` / `aws:kms`) |
| `VSLS3 FLUSH SECONDS` | SYS | Background flush interval (`VSLTASK`) |
| `VSLS3 BATCH MAX BYTES` | SYS | Single-PUT vs multipart threshold |

**Credentials — never in XPAR plaintext.** Options, in precedence order
(D-S3-1):

1. **IAM role / instance profile** (preferred where the VistA host runs on EC2 or
   has an SSM/IMDS path) — the credential is fetched at flush time, short-lived,
   never persisted. `ctx("sessionToken")` carries the STS token.
2. **A named credential reference** that `VSLCFG` resolves out of an
   operator-managed secret store (file with restricted perms, or the engine's
   secured config), **never** the access key in a global or an XPAR value.
3. The access key/secret in an OS-protected config file readable only by the
   VistA service account — the floor, not the recommendation.

This mirrors the Standard Library architecture's TLS rule: **no credential material in M
source, in a global, or in the KIDS build** — only a *reference* to operator-
provisioned material, resolved at runtime.

---

## 11. Interfacing with the v-stdlib — `VSLS3` Log Sink

This section is the connector's primary recommendation set: **how `STDS3` plugs
into VSL to ship VistA logs.** It realizes the data flow drawn in the
Standard Library architecture
[§6.2 Mermaid diagram](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#62-example-application-2--vista-log-streaming-to-aws-s3).

### 11.1 The binding — `STDLOG`'s sink seam → `VSLS3`

`STDLOG` is a **side-effecting seam** (Standard Library architecture §2.3 / §4.2): the
logging *API* is portable, the *sink* is pluggable. Recommendation:

- VistA application code calls the ordinary, unchanged `STDLOG` API
  (`do info^STDLOG(...)`, `do error^STDLOG(...)`). It has **no knowledge of S3**.
- `VSLS3` registers as `STDLOG`'s sink at install time. Each log record is
  appended to an in-process (or short-lived spool) **batch buffer**, not written
  through to S3 synchronously — logging must never block the clinical path on a
  network round-trip.
- A record is a flat M array; `VSLS3` serializes the batch to **NDJSON** with
  `STDJSON` (one JSON object per line: timestamp, level, message, `DUZ`, routine,
  job number, station).

### 11.2 The flush — `VSLTASK` drives egress

- A **persistent TaskMan task** (`$$PSET^%ZTLOAD`, ICR #10063 — Standard Library
  architecture §3.5) wakes every `VSLS3 FLUSH SECONDS`, or when the batch crosses
  `VSLS3 BATCH MAX BYTES`, whichever first.
- It composes the object key (`<prefix>/<yyyy>/<mm>/<dd>/<station>-<seq>.ndjson`),
  calls `$$putObject^STDS3` (or the multipart trio for large batches, §7.4), and
  on `200 OK` clears the flushed batch.
- The task queues **without an I/O device** (`ZTIO=""`) and owns its own outbound
  socket — exactly the TaskMan shape the corpus documents for this (§2).

### 11.3 The socket — `VSLIO` is the only engine-specific hop

- `STDS3` hands the assembled, signed request to the HTTP layer; under VistA the
  socket open is `VSLIO` → **`CALL^%ZISTCP`** (ICR #2118: `IPADDRESS`/`SOCKET`/
  `TIMEOUT` → `IO`/`POP`) against the **`VSLS3 TLS CLIENT CONFIG`** named config
  (Standard Library architecture §3.6). No certificate material in M; the config names the
  AWS CA bundle out-of-band.

### 11.4 Durability & back-pressure recommendations

The risk a log shipper must not create is **threatening the clinical system it
observes** — the very failure mode that keeps VistA from logging today (§2). So:

1. **Bounded spool, drop-oldest.** The batch buffer has a hard byte cap. If S3 is
   unreachable and the spool fills, **drop oldest records and increment a dropped
   counter** — never grow unbounded into the database. (Optionally spool to a
   capped HFS file via `STDFS`, *not* a global, for crash durability — D-S3-4.)
2. **Asynchronous only.** No `STDLOG` call ever waits on the network. Flush is
   always the background task's job.
3. **Idempotent keys + retry with backoff.** Each batch's object key includes a
   monotonic sequence; a retried `PUT` overwrites identically (S3 `PUT` is
   idempotent for a given key+body), so a flush that times out and retries cannot
   duplicate or corrupt. `STDS3` returns the status; `VSLTASK` owns the
   retry/backoff policy.
4. **Self-healing task.** `$$PSET^%ZTLOAD` persistence restarts the flusher if it
   dies, so a transient crash doesn't silently stop egress.
5. **Fail-open for logging.** If S3 egress is broken, the clinical system keeps
   running and logs keep batching/dropping with a counter — logging degrades, the
   EHR does not.

### 11.5 What the bucket side buys (the "why bother" payoff)

Once logs are NDJSON objects in S3, the VistA operator gets — with **zero** extra
M code — what the M database never could: **lifecycle policies** (auto-expire/
archive to Glacier), **immutability** (Object Lock for tamper-evident HIPAA audit
trails), **Athena/`SELECT`** ad-hoc query over the NDJSON, and **SIEM ingestion**
(the bucket is a standard SIEM source). The Standard Library architecture's §6.2 framing
holds: the M system's *only* outward act is one signed `PUT` across the trust
boundary; everything analytical happens off the live database.

### 11.6 Provider-swap recommendation

Keep `VSLS3` a *thin* sink: batching, spooling, key composition, and the
`STDS3` call. Put **nothing** S3-specific in `STDLOG` or in the application. Then
a future `VSLGCS` (Google Cloud Storage) or `VSLAZ` (Azure Blob) sink — each with
its own portable `STDGCS`/`STDAZBLOB` client and its own signer — drops in behind
the identical `STDLOG` seam, and the same VistA log calls ship to a different
cloud unchanged. This is the Standard Library architecture's reuse thesis, demonstrated.

---

## 12. Security Considerations

- **Credentials.** §10: prefer IAM-role/STS short-lived creds; never an access
  key in a global, XPAR plaintext, M source, or the KIDS build. The signing key
  derives the secret in-memory per flush and is never persisted.
- **Least privilege.** The IAM principal the shipper uses should hold *only*
  `s3:PutObject` (+ `s3:AbortMultipartUpload`) on the one log-bucket prefix —
  no `GetObject`/`DeleteObject`/`ListBucket` on the log path. `getObject`/`delete`
  in `STDS3` exist for *other* object-IO consumers, not the log shipper.
- **TLS verification is mandatory.** `VSLIO`'s client TLS config must verify the
  S3 endpoint against a pinned CA bundle — an unverified socket would let a
  man-in-the-middle harvest signed requests. (The signature protects integrity,
  not confidentiality of the log payload.)
- **PHI in logs.** Logs streamed off-box may contain PHI. Recommend: bucket-side
  SSE (`AES256`/`aws:kms`), Object Lock for audit immutability, a Government/
  BAA-covered account (GovCloud region where required), and an application
  discipline that log *messages* avoid raw PHI where feasible. This is a policy
  surface the connector enables but cannot enforce — call it out in the `VSLS3`
  DIBRG.
- **GovCloud / FIPS.** `VSLS3 REGION` + `VSLS3 ENDPOINT` support
  `us-gov-west-1`/`us-gov-east-1` and FIPS endpoints
  (`s3-fips.<region>.amazonaws.com`) — likely mandatory for a VA deployment.
- **Clock skew.** SigV4 rejects requests whose `x-amz-date` skews > 15 min from
  S3's clock (`403 RequestTimeTooSkewed`). The VistA host's time must be NTP-synced;
  `VSLTASK` should surface skew-class 403s as an alert, not a silent retry loop.

---

## 13. Testing Strategy

**Portable layer (`STDS3` / `STDSIGV4`) — m-stdlib gates, no VistA, no network:**

- **SigV4 known-answer vectors.** Assert `STDSIGV4` byte-exact against the
  **AWS-published SigV4 test suite** and the worked example in the AWS S3
  Authorization-header doc (§16) — canonical request, string-to-sign, signing
  key, and final signature each checked. This is the single highest-value test:
  it catches the raw-byte-vs-hex chain bug (§6) deterministically with no S3.
- **Request-assembly snapshots.** `STDS3` builds for `putObject`/`listObjectsV2`/
  multipart are asserted against frozen expected byte strings (`STDSNAP`).
- **Round-trip against a local S3-compatible server** (MinIO/LocalStack) via
  `STDS3`'s `endpoint` override — exercises the real HTTP path with no AWS
  account, in CI. (Optional `make test-optional`-style suite, since it needs a
  container.)
- **85%-per-module coverage**, fmt/lint, manifest/skill/doctest drift gates — same
  as every `STD*` module.

**VistA layer (`VSLS3`) — v-stdlib gates, live `VistaEngine`:**

- `VSLS3` `*TST.m` runs inside a real FOIA VistA (YDB **and** IRIS) per the Standard Library
  architecture's **no-mocks** rule (§8): real XPAR params, real `^%ZIS`/`CALL^%ZISTCP`
  socket, real `$$PSET^%ZTLOAD` task. The S3 endpoint is a CI MinIO/LocalStack so
  the test never touches production AWS.
- **Back-pressure tests:** spool-full drop-oldest, S3-unreachable degradation,
  retry/backoff, sequence-key idempotency — assert the clinical-safety properties
  of §11.4 explicitly.
- KIDS install → flush → verify object in bucket → back-out → verify-clean.

---

## 14. Open Decisions

| # | Decision | Default leaning |
|---|---|---|
| **D-S3-1** | Credential source (§10) | IAM-role/STS preferred; named secret-store ref next; plaintext key the floor only |
| **D-S3-2** | Addressing style | Virtual-hosted-style default; path-style via `endpoint` config for S3-compatible stores |
| **D-S3-3** | Single-PUT vs multipart threshold (§7.4) | ~8 MiB; config-driven (`VSLS3 BATCH MAX BYTES`) |
| **D-S3-4** | Crash-durable spool: in-memory only vs capped HFS file (§11.4) | Capped HFS file via `STDFS` (never a global); in-memory acceptable for v0.1 |
| **D-S3-5** | Signed vs unsigned payload (`x-amz-content-sha256`) | Signed payload (hash the batch) — added integrity, batches are bounded so double-read is cheap |
| **D-S3-6** | Is the signer `STDSIGV4` (S3-only) or a broader `STDAWS` (any AWS service)? | `STDSIGV4` service-generic from day 1, but ship only S3 as a consumer |
| **D-S3-7** | Pre-signed URLs (query-param auth) in scope? | Defer to a later phase; Authorization-header auth only for v0.1 |
| **D-S3-8** | Compression before egress (`STDCOMPRESS` gzip the NDJSON) | Optional `Content-Encoding: gzip` via the existing optional `STDCOMPRESS` callout; off by default |

---

## 15. Roadmap

| Phase | Deliverable |
|---|---|
| **v0.1 (this doc)** | Design + contracts + boto3→M mapping agreed |
| **v0.2** | `STDSIGV4` TDD-red→green against the AWS SigV4 known-answer vectors (no network) |
| **v0.3** | `STDS3` `putObject`/`getObject`/`listObjectsV2`/`deleteObject` green against a CI MinIO/LocalStack |
| **v0.4** | Multipart upload; error-XML parsing; pagination loop |
| **v0.5** | `VSLS3` sink + `VSLCFG`/`VSLIO`/`VSLTASK` wiring; `VistaEngine` end-to-end on YDB + IRIS |
| **v1.0** | KIDS `VSLS3` build with env-check + DIBRG; back-pressure/clinical-safety suite green; GovCloud/FIPS endpoint verified |
| **Later** | Pre-signed URLs; `STDAWS` generalization; `VSLGCS`/`VSLAZ` provider parity |

---

## 16. References — AWS S3 SDK & SigV4 Documentation

Official AWS developer documentation grounding this design. Fetched/verified
2026-06-07.

**Amazon S3 REST API Reference:**
- **S3 API Reference — Welcome / operation index** — https://docs.aws.amazon.com/AmazonS3/latest/API/Welcome.html
- **PutObject** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_PutObject.html *(method/URI, `x-amz-*` headers, SSE/storage-class, `ETag` response — §5, §7.3)*
- **GetObject** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_GetObject.html
- **HeadObject** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_HeadObject.html
- **ListObjectsV2** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListObjectsV2.html *(`list-type=2`, `prefix`, `IsTruncated`/`NextContinuationToken` — §7.5)*
- **DeleteObject** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_DeleteObject.html
- **DeleteObjects (batch)** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_DeleteObjects.html
- **CreateMultipartUpload** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_CreateMultipartUpload.html
- **UploadPart** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_UploadPart.html
- **CompleteMultipartUpload** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_CompleteMultipartUpload.html
- **AbortMultipartUpload** — https://docs.aws.amazon.com/AmazonS3/latest/API/API_AbortMultipartUpload.html
- **Common Request Headers** — https://docs.aws.amazon.com/AmazonS3/latest/API/RESTCommonRequestHeaders.html
- **Error Responses (S3 error XML `<Code>`/`<Message>`)** — https://docs.aws.amazon.com/AmazonS3/latest/API/ErrorResponses.html

**AWS Signature Version 4 (the signing process — §6):**
- **Authenticating Requests: Using the Authorization Header (AWS Signature Version 4)** — https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-auth-using-authorization-header.html *(the `AWS4-HMAC-SHA256` / `Credential` / `SignedHeaders` / `Signature` header anatomy, `x-amz-content-sha256` values incl. `UNSIGNED-PAYLOAD` — verified, §5)*
- **Signature Calculations for the Authorization Header: Transferring Payload in a Single Chunk** — https://docs.aws.amazon.com/AmazonS3/latest/API/sig-v4-header-based-auth.html *(the canonical-request → string-to-sign → signature steps — §6)*
- **Signature Calculations: Transferring Payload in Multiple Chunks (Chunked Upload)** — https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-streaming.html
- **AWS Signature Version 4 for API requests (IAM User Guide)** — https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv-create-signed-request.html
- **Signing AWS API requests — overview (AWS General Reference)** — https://docs.aws.amazon.com/general/latest/gr/signing-aws-api-requests.html
- **Elements of an AWS API request signature** — https://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html
- **Create a string to sign / Calculate the signature / Add the signature to the request** — https://docs.aws.amazon.com/general/latest/gr/sigv4-create-string-to-sign.html · https://docs.aws.amazon.com/general/latest/gr/sigv4-calculate-signature.html · https://docs.aws.amazon.com/general/latest/gr/sigv4-add-signature-to-request.html

**AWS SDK for Python (boto3) — the high-level reference (§7):**
- **boto3 S3 client reference** — https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html
- **`S3.Client.put_object`** — https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/client/put_object.html
- **`S3.Client.get_object`** — https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/client/get_object.html
- **`S3.Client.list_objects_v2`** — https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/client/list_objects_v2.html
- **`S3.Client.create_multipart_upload` / `upload_part` / `complete_multipart_upload`** — https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3/client/create_multipart_upload.html
- **boto3 S3 uploading-files guide** — https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-uploading-files.html
- **boto3 credentials resolution order** — https://boto3.amazonaws.com/v1/documentation/api/latest/guide/credentials.html

## 17. References — Example Python (boto3) Code

The Python the M code is translated from (§7):
- **AWS-published complete SigV4 signing example (Python)** — https://docs.aws.amazon.com/general/latest/gr/sigv4-signed-request-examples.html *(the `sign()` / `getSignatureKey()` helpers and the canonical-request→string-to-sign→signature flow `STDSIGV4` mirrors line-for-line — §7.2)*
- **boto3 S3 examples (put/get/list/delete, multipart)** — https://boto3.amazonaws.com/v1/documentation/api/latest/guide/s3-example-creating-buckets.html and the per-method reference pages in §16 *(the high-level calls `STDS3` mirrors — §7.1, §7.3–7.5)*
- **botocore SigV4 signer (`botocore.auth.SigV4Auth`)** — https://github.com/boto/botocore/blob/develop/botocore/auth.py *(the production SigV4 implementation; the canonical reference for header ordering and edge cases when validating `STDSIGV4`)*

## 18. References — VistA gold-docs (VDL corpus)

VistA integration points are grounded in the same gold-docs the Standard Library
architecture cites (`is_latest=1`, verified present in `~/data/vdocs`); see that
document's [§13](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md#13-references-vista-gold-docs)
for the full set. The ones load-bearing for the S3 log shipper:

- **`XU/krn_8_0_dg_device_handler_ug`** — Kernel 8.0 Developer's Guide: Device
  Handler — https://www.va.gov/vdl/documents/Infrastructure/Kernel/krn_8_0_dg_device_handler_ug.docx *(`CALL^%ZISTCP` ICR #2118 / `CLOSE^%ZISTCP` — the outbound TLS socket to S3, §2/§11.3)*
- **`XU/krn_8_0_dg_taskman_ug`** — Kernel 8.0 Developer's Guide: TaskMan — https://www.va.gov/vdl/documents/Infrastructure/Kernel/krn_8_0_dg_taskman_ug.docx *(`$$PSET^%ZTLOAD` ICR #10063 persistent self-healing flush task; `^%ZTLOAD` queue-without-device — §2/§11.2)*
- **`XU/krn_8_0_tm`** — Kernel 8.0 Technical Manual — https://www.va.gov/vdl/documents/Infrastructure/Kernel/krn_8_0_tm.docx *(`XU*8*787` TLS enablement; `DEFAULT TLS SERVER CONFIG` → named IRIS `Security.SSLConfigs`; client-role TLS for the S3 endpoint, §2)*
- **`XT/ktk7_3p26sp`** — XT*7.3*26 Parameter Tools Supplement — https://www.va.gov/vdl/documents/Infrastructure/Kernel_Toolkit/ktk7_3p26sp.docx *(`$$GET^XPAR`, #8989.5/.51, entity precedence — the `VSLS3` config model, §10)*
- **`DI/fm22_2dg`** — FileMan 22.2 Developer's Guide — https://www.va.gov/vdl/documents/Infrastructure/Fileman/fm22_2dg.docx *(FileMan DBS — for the capped-spool/audit-counter records if a FileMan sink is chosen over HFS, D-S3-4)*

**m-stdlib / VSL cross-references:**
- [`msl-vsl-architecture.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/msl-vsl-architecture.md) — the parent architecture; **§6.2** is the log-streaming worked example this spec details, **§2.3/§4.2** the seam model, **§3.5/§3.6** the TaskMan/Device-Handler grounding.
- [`https-stack-spec.md`](https://github.com/vista-forge/docs/blob/main/vsl-msl/https-stack-spec.md) — sibling `VWEB` stack; the inbound counterpart to this outbound connector, sharing `VSLIO`/`STDHTTPMSG`.
- [`future-modules-plan.md`](../proposals/future-modules-plan.md) — where `STDS3`/`STDSIGV4` register as proposed modules.
- m-stdlib primitives consumed: `STDCRYPTO` (HMAC-SHA-256/SHA-256), `STDHEX`,
  `STDJSON`, `STDXML`, `STDURL`, `STDDATE`, `STDHTTP`/`STDHTTPMSG`,
  `STDCOMPRESS` (optional gzip).

---

*End DRAFT v0.1. Sections are modular by design — each can be promoted to a
standalone spec as detail accretes. Naming set to `STDS3` / `STDSIGV4` (portable,
m-stdlib) + `VSLS3` (VistA-coupled, v-stdlib); final `VSL*` namespace
DBA-assigned. Next step: `STDSIGV4` TDD-red against the AWS SigV4 known-answer
vectors (v0.2) — no network, no VistA, deterministic.*
