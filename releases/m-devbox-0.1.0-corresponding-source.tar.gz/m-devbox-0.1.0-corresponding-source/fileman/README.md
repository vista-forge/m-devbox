# fileman

Reproducible, **driver-stack-native** install of **standalone VA FileMan** onto a
**bare YottaDB engine** — no Kernel, no VistA. It is the **L1a "seed"** of a
from-scratch VistA build (Kernel = L1b, KIDS-installed packages = L2), and stands
alone as a useful artifact: a FileMan DBMS over YottaDB, usable outside VistA.

Feasibility is **proven** — standalone FileMan 22.2 installs from scratch on bare
YDB through the driver seam and a file round-trips (`$$GET1^DIQ`, `UPDATE^DIE`). See
the design note and the originating proposal in the org `docs` repo
(`proposals/fileman-on-ydb/`).

---

## The two rules this repo lives by

1. **Engine access is ONLY through the driver stack** (`m-ydb` / the `m-driver-sdk`
   seam), never raw `docker exec` / `docker run` / `mumps -direct`. Every engine
   step is `m-ydb lifecycle|exec …`, run-lock-bracketed. (Raw docker on an engine is
   both org-forbidden and, on this box, harness-blocked.)
2. **This is the pre-KIDS seed, NOT a bespoke package installer.** It installs
   FileMan *only*, so that KIDS can later exist. It never installs a KIDS build and
   never patches a national routine — the instant Kernel/KIDS exist (L1b+), the org
   `never-use-bespoke-installer` rule applies in full and `v pkg install` is the
   only path. This repo stays strictly below that waterline.

---

## What it does (the recipe, proven)

FileMan 22.2 is **self-installing** on a bare engine and needs no Kernel. On YottaDB
the install is:

| Phase | Step | Note |
|---|---|---|
| **P1** | `m-ydb exec load` the MSC FileMan `.m` | 852 routines; exclude the 10 foreign-OS `DINV*/DINZ*` |
| **P2** | Seed 5 `%`-routines + a `%ZOSV` stub | via FileMan's own `19,"ZS"` `$TEXT`-copy — **not** `DINZMGR` (which can't run on YDB) |
| **P3** | Drive `D ^DINIT` via `m-ydb exec script` | 4-line answer `YES / <site> / <num> / GT.M(UNIX)`; prepend an `$ETRAP` |
| **P4** | Verify | `$$GET1^DIQ(1,"1,",.01)="FILE"`, `%DT` parses a date, a write round-trips |

Two transports (`VF_TRANSPORT`): **docker** (default — provision a scratch
container, install into it, tear it down on failure) and **local** (the
m-devbox lane — the same P1–P4 as a `RUN` step inside `docker build`, engine
ambient; a failed step destroys **nothing**, the builder discards the layer;
`make test-build-image` is the end-to-end proof). Failure semantics are gated
offline by `scripts/tests/failure-semantics.test.sh` in `make check`.

> **Why not `DINZMGR` / `^%ZOSF`?** `DINZMGR` is a fossilized 22.0 dialog with no
> GT.M(Unix) option and a ZLOAD/ZSAVE rename engine YottaDB lacks. FileMan 22.2 runs
> off `^DD("OS")` (#.7 IEN 19 = `GT.M(UNIX)`), so a from-scratch install ends with
> `^%ZOSF` empty and works fine. See `docs/design/fileman-on-ydb-build.md`.

## Quickstart

```sh
make help          # list targets
make sources       # fetch + verify the PINNED FileMan source into ./src  (sync-time, network)
make build         # provision a fresh YDB, install FileMan, verify        (offline, driver-native)
make verify        # re-run the P4 acceptance checks on a running instance
make check         # offline docs gate (link + layout)
make down          # tear down the instance
```

> **Source is pinned, not vendored.** `make sources` fetches ONLY the FileMan subtree
> of `WorldVistA/VistA-VEHU-M` at a pinned commit (`scripts/seed/source.pin`) and
> verifies it byte-for-byte against `scripts/seed/sources.sha256` — the one network
> step (sync-time); `make build` is offline. See `docs/design/fileman-on-ydb-build.md`.

## Documentation

- [`docs/design/fileman-on-ydb-build.md`](docs/design/fileman-on-ydb-build.md) — the
  build design + the corrected recipe.
- `scripts/` — the driver-native phase scripts and the two seed routines
  (`scripts/seed/`).
- Origin + full rationale: the `docs` repo `proposals/fileman-on-ydb/`.
