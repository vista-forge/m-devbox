# fileman — repo rules (adds to the org `~/vista-forge/CLAUDE.md`)

A build/provisioning repo (like `vista-iris`): it installs **standalone VA FileMan
onto a bare YottaDB engine** through the driver seam. Not m/v-layered code — no
`repo.meta.json` layer tag; it carries no `VSL*`/`STD*` library surface.

## Binding rules for this repo

1. **Driver seam only.** Reach any engine exclusively via `m-ydb lifecycle|exec …`
   (the `m-driver-sdk` seam), always inside `m runlock hold --engine ydb … -- …`.
   NEVER `docker exec`/`docker compose`/`mumps -direct` (org-forbidden +
   harness-blocked). Two transports (`VF_TRANSPORT`, PR-10 port 2026-07-22):
   - **docker** (default): provision a **fresh dedicated** container; **never**
     touch `vehu`, `foia-t12`, or the shared `m-test-engine`. Destroy on exit
     — teardown covers only what this run provisioned.
   - **local** (the m-devbox §5.2(a) lane): the engine is AMBIENT — a
     docker-build `RUN` step installing into the image being built. **NEVER
     `lifecycle destroy` under local** (it deletes the engine's `.gld`/`.dat`);
     a failed `RUN` layer is discarded by the builder. Gated by
     `scripts/tests/failure-semantics.test.sh` (in `make check`, red-proofed).
2. **Below the KIDS waterline — not a bespoke installer.** Install FileMan *only*.
   Never install a KIDS build, never patch a national routine. See the org
   `never-use-bespoke-installer` directive — it binds the moment Kernel/KIDS exist
   (L1b+); this repo stays strictly beneath it.
3. **`exec script` needs an `$ETRAP` preamble** — YDB fault text does not reach the
   `exec script`/`exec eval` stdout channel otherwise, and failures go silent.
   Every phase script opens with `S $ETRAP="W !,""ETRAP:"",$ZSTATUS,! S $ECODE="""" ZGOTO 0"`.
4. ~~**`exec load` cannot stage `%`-routine filenames**~~ **Limitation LIFTED
   2026-07-22** (m-ydb `6d89a0c`, PR-21: the source layer now accepts the on-disk
   `%`-routine form `_X.m`). The proven Spike-3 recipe still seeds the
   `%`-routines in-engine via FileMan's own `19,"ZS"` `$TEXT`-copy technique
   (`scripts/seed/`) — keep it (green, byte-proven); direct `exec load` of
   `_X.m` is now *possible*, not *required*.
5. **Source is pinned + checksum-verified, never vendored raw.** FileMan source is
   pinned to an immutable `WorldVistA/VistA-VEHU-M` commit in `scripts/seed/source.pin`;
   `make sources` sparse-fetches ONLY the FileMan subpath at sync-time and verifies it
   byte-for-byte against `scripts/seed/sources.sha256` (`make build` depends on
   `verify-sources`). Do not commit the routine tree (`/src/` is gitignored). To move
   the pin, bump both `source.pin` and regenerate `sources.sha256` in one commit.

## Gates
`make check` (offline docs link+layout) before commit. Trunk-based per the org
Increment Protocol.
