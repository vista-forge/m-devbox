# scripts/

Driver-native install of standalone FileMan onto a bare YottaDB engine.

- **`build.sh`** — the orchestrator. Holds one run-lock bracket and runs the phases
  (`build` = P0→P4; or a single phase: `up|load|seed|dinit|verify|down`). Every
  engine op is an `m-ydb` verb; no raw docker/mumps. Config via env / the Makefile:
  `CONTAINER`, `IMAGE`, `FM_SRC`, `SITE_NAME`, `SITE_NUM`.
- **`fetch-source.sh`** — fetches the pinned FileMan source (`seed/source.pin`) into
  `../src` at sync-time and verifies it byte-for-byte against `seed/sources.sha256`.
  `make sources` / `make verify-sources` wrap it; `--path` prints the resolved
  `FM_SRC`.
- **`seed/`** — the two seed routines, the load set, and the source pin +
  checksum manifest. See `seed/README.md`.

Run via the Makefile (`make build` / `make verify` / `make down`), which passes the
config through. Do not call the driver against `vehu`/`foia-t12`/`m-test-engine` —
always a fresh dedicated `CONTAINER`.
