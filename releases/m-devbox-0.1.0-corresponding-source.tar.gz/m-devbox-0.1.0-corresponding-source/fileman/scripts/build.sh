#!/usr/bin/env bash
# vista-fileman build orchestrator — install standalone VA FileMan onto a fresh
# bare YottaDB engine, DRIVER-NATIVE (m-ydb seam only). Commands proven in Spike 3
# (see ../../docs/proposals/fileman-on-ydb/ in the org `docs` repo).
#
# P1 load FileMan .m -> P2 seed 5 %-routines + %ZOSV stub (NOT DINZMGR) ->
# P3 drive DINIT via `exec script` (4-line answer + $ETRAP) -> P4 verify.
# No raw docker/mumps anywhere. See ../CLAUDE.md.
#
# Transports (VF_TRANSPORT, default docker):
#   docker — the original flow: provision a fresh scratch container from
#            $IMAGE, install into it, tear it down on failure (we created it).
#   local  — the m-devbox §5.2(a) flow: the engine is AMBIENT (a docker-build
#            RUN step inside the image being built; ydb_* env baked as ENV).
#            No provision, no destroy — EVER. A failed RUN layer is discarded
#            by the builder; `lifecycle destroy` under local would os.Remove
#            the engine's .gld/.dat (PR-10 ruling, 2026-07-22: a failed build
#            step destroys nothing it did not create this run). Gated by
#            scripts/tests/failure-semantics.test.sh.
set -euo pipefail

TRANSPORT="${VF_TRANSPORT:-docker}"
CONTAINER="${CONTAINER:-vista-fileman}"
IMAGE="${IMAGE:-m-test-engine:0.3.0-local}"
FM_SRC="${FM_SRC:-$HOME/projects/vista-meta/vista/vista-m-host/Packages/VA FileMan/Routines}"
SITE_NAME="${SITE_NAME:-FILEMAN}"
SITE_NUM="${SITE_NUM:-999}"
HERE="$(cd "$(dirname "$0")" && pwd)"

case "$TRANSPORT" in
  docker) DT="--transport docker --container $CONTAINER"; LOCKARGS=(--docker "$CONTAINER") ;;
  local)  DT="--transport local";                          LOCKARGS=(--transport local) ;;
  *) echo "unknown VF_TRANSPORT=$TRANSPORT (docker|local)" >&2; exit 2 ;;
esac

# Hold ONE run-lock bracket around the whole run (the Spike-3 pattern), then
# re-enter with all engine verbs unbracketed inside it.
if [ -z "${VF_LOCKED:-}" ]; then
  exec m runlock hold --engine ydb "${LOCKARGS[@]}" -- env VF_LOCKED=1 "$0" "$@"
fi

# Failure semantics (PR-10 ruling): tear down ONLY what this run provisioned.
# docker: we created the scratch container -> destroy it (VF_KEEP=1 to keep a
# failed instance up for debugging). local: we created NOTHING -> destroy
# NOTHING; under local `lifecycle destroy` deletes the .gld/.dat.
on_err() {
  echo "!! build failed" >&2
  if [ "$TRANSPORT" = docker ]; then
    echo "!! tearing down scratch container $CONTAINER (VF_KEEP=1 to keep)" >&2
    [ -n "${VF_KEEP:-}" ] || m-ydb lifecycle destroy $DT >/dev/null 2>&1 || true
  else
    echo "!! local transport: nothing is destroyed — a failed docker-build RUN layer is discarded by the builder" >&2
  fi
}
trap on_err ERR

# DUZ/programmer context for FileMan API calls (Spike-3 verify setup).
DUZ='set DUZ=1,DUZ(0)="@",U="^"'
# $ETRAP preamble — MANDATORY on exec script: YDB fault text does not otherwise
# reach the exec stdout channel, so failures go silent (Spike-3 finding).
ETRAP='S $ETRAP="W !,""ETRAP:"",$ZSTATUS,! S $ECODE="""" ZGOTO 0"'

ev()  { m-ydb exec eval $DT -o json "$1"; }
scr() { local b64; b64="$(printf '%s\n' "$ETRAP" "$@" | base64 -w0)"
        m-ydb exec script $DT -o json --script-b64 "$b64"; }

phase_up() {
  if [ "$TRANSPORT" = docker ]; then
    echo ">> P0 provision fresh $CONTAINER from $IMAGE"
    m-ydb lifecycle destroy $DT >/dev/null 2>&1 || true
    m-ydb lifecycle provision $DT --image "$IMAGE"
    m-ydb lifecycle wait $DT --timeout 60
  else
    # The ambient engine is the image's own: DB files + ydb_* ENV baked at
    # image build. No `lifecycle up` — the trimmed devbox image ships no gde,
    # and provisioning is the image's job, not this step's. Just PROVE the
    # engine is usable before installing into it (fail-loud, not assumed).
    echo ">> P0 ambient engine (local transport) — probe"
    local probe
    probe="$(ev 'write "ENGINE-OK ",$zyrelease')"
    printf '%s\n' "$probe"
    case "$probe" in
      *ENGINE-OK*) : ;;
      *) echo "P0: ambient engine probe failed" >&2; return 1 ;;
    esac
  fi
}

phase_load() {
  echo ">> P1 load FileMan routines (exclude foreign-OS DINV*/DINZ*)"
  local list="$HERE/seed/loadlist.txt" files=() b=() r f
  if [ -f "$list" ]; then
    # loadlist entries are bare filenames relative to FM_SRC
    while IFS= read -r r; do
      [ -n "$r" ] || continue
      r="${r##*/}"
      [ -f "$FM_SRC/$r" ] || { echo "P1: missing source $FM_SRC/$r" >&2; return 1; }
      files+=("$FM_SRC/$r")
    done < "$list"
  else
    while IFS= read -r f; do files+=("$f"); done < \
      <(find "$FM_SRC" -name '*.m' ! -name 'DINV*' ! -name 'DINZ*')
  fi
  echo "   loading ${#files[@]} routines in batches of 200"
  for f in "${files[@]}"; do b+=("$f")
    if [ "${#b[@]}" -ge 200 ]; then m-ydb exec load $DT "${b[@]}"; b=(); fi
  done
  if [ "${#b[@]}" -gt 0 ]; then m-ydb exec load $DT "${b[@]}"; fi
}

phase_seed() {
  echo ">> P2 seed 5 %-routines + %ZOSV stub (19,\"ZS\" copy — NOT DINZMGR)"
  m-ydb exec load $DT "$HERE/seed/FMPOCREN.m" "$HERE/seed/ZOSVSTUB.m"
  ev 'do ^FMPOCREN'   # DIDT->%DT, DIDTC->%DTC, DIRCR->%RCR, DIIS->%ZIS, DIISS->%ZISS
  ev 'do copy^FMPOCREN("ZOSVSTUB","%ZOSV",$piece($piece($piece($zroutines,")"),"(",2)," ")) write "ZOSV=",$text(+1^%ZOSV)'
}

phase_dinit() {
  # Input stream per the Spike-3 green transcript (poc-artifacts/
  # dinit-green-transcript.txt). Observed fresh-engine dialog: Initialize? YES /
  # SITE NAME / SITE NUMBER / TYPE OF MUMPS SYSTEM. The 'NO' line is absorbed by
  # the OS-type prompt (rejected '??', FileMan re-asks, GT.M(UNIX) then lands) —
  # kept because it is the exact proven input stream. A trailing marker write
  # proves the dialog ran to completion (fail-loud, checked below).
  echo ">> P3 drive D ^DINIT (YES / $SITE_NAME / $SITE_NUM / NO / GT.M(UNIX))"
  local out
  out="$(scr 'D ^DINIT' 'YES' "$SITE_NAME" "$SITE_NUM" 'NO' 'GT.M(UNIX)' \
             'W !,"MARKER-DONE OSNODE=",$G(^DD("OS"))," ZOSF=",$D(^%ZOSF)," DIC1=",$G(^DIC(1,0)),!')"
  printf '%s\n' "$out"
  case "$out" in
    *MARKER-DONE*) : ;;
    *) echo "P3: DINIT dialog did not reach the done marker" >&2; return 1 ;;
  esac
}

# Run an eval, print its output, and fail loud unless the expected marker shows.
expect() { # expect <marker> <m-code>
  local out
  out="$(ev "$2")"
  printf '%s\n' "$out"
  case "$out" in
    *"$1"*) : ;;
    *) echo "P4: expected [$1] in output above" >&2; return 1 ;;
  esac
}

phase_verify() {
  echo ">> P4 verify"
  expect 'GET1=FILE' "$DUZ write \"GET1=\",\$\$GET1^DIQ(1,\"1,\",.01)"
  expect 'DT=3260101' "$DUZ set X=\"JAN 1,2026\" do ^%DT write \"DT=\",Y"
  expect 'DDOS=19' 'new n,c set n="",c=0 xecute "for  set n=$order(^%ZOSF(n)) quit:n=""""  set c=c+1" write "ZOSFNODES=",c,"|DDOS=",$get(^DD("OS"))'
  expect 'ERR=none' "$DUZ kill FDA,FMIEN,FMERR set FDA(1.2,\"+1,\",.01)=\"VFM EDITOR\" do UPDATE^DIE(\"\",\"FDA\",\"FMIEN\",\"FMERR\") write \"IEN=\",\$get(FMIEN(1)),\"|ERR=\",\$get(FMERR(\"DIERR\",1,\"TEXT\",1),\"none\")"
}

phase_down() {
  if [ "$TRANSPORT" = local ] && [ -z "${VF_FORCE_LOCAL_DESTROY:-}" ]; then
    echo "down: REFUSED under the local transport — 'lifecycle destroy' deletes the engine's .gld/.dat." >&2
    echo "      Set VF_FORCE_LOCAL_DESTROY=1 if you really mean to delete the ambient database." >&2
    return 4
  fi
  m-ydb lifecycle destroy $DT
}

case "${1:-build}" in
  build)  phase_up; phase_load; phase_seed; phase_dinit; phase_verify ;;
  up)     phase_up ;;
  load)   phase_load ;;
  seed)   phase_seed ;;
  dinit)  phase_dinit ;;
  verify) phase_verify ;;
  down)   phase_down ;;
  *) echo "usage: ${0##*/} {build|up|load|seed|dinit|verify|down}" >&2; exit 2 ;;
esac
