# scripts/seed/

The two **original** routines FileMan-on-YDB needs beyond the FileMan source itself,
plus the pinned load set. Apache-2.0 (this repo's own code).

| File | Role |
|---|---|
| `FMPOCREN.m` | Seeds the 5 `%`-routines (`DIDT→%DT` … `DIISS→%ZISS`) by writing each routine's `$TEXT` image into the first `$ZROUTINES` source dir then `ZLINK` — FileMan's own `19,"ZS"` technique, the YDB replacement for `DINZMGR`'s broken ZLOAD/ZSAVE rename. Its `copy(src,dst,dir)` entry also seeds `%ZOSV` from `ZOSVSTUB`. |
| `ZOSVSTUB.m` | A minimal pure-M GT.M `%ZOSV` (`LGR`/`EC`/`GETENV` + job-info stubs). Standalone FileMan 22.2 ships no GT.M `%ZOSV`, yet `BLD^DIALOG` calls `$$LGR^%ZOSV` and crashes `DINIT` without it. No Kernel needed. |
| `loadlist.txt` | The proven 851-routine load set (foreign-OS `DINV*/DINZ*` excluded). |
| `source.pin` | The immutable FileMan-source pin: `WorldVistA/VistA-VEHU-M` repo + commit + subpath. `../fetch-source.sh` reads it. |
| `sources.sha256` | sha256 of each of the 851 proven routines. `make sources`/`verify-sources` checks the fetched `../src` against it — byte-identity to the proven build or fail-loud. Regenerate together with `source.pin` when moving the pin. |

> **Provisional names.** `FMPOCREN` / `ZOSVSTUB` are carried verbatim from the
> proof-of-concept (they are proven-working). Rename to the repo convention when the
> phases are hardened — update the labels, the `ZLINK`/`copy^…` references, and
> `scripts/build.sh` together.
