FMPOCREN ; fmpoc spike 3 - copy DI* manager routines to %-names (DINZMGR MOVE analog for YDB)
 ; Mirrors FileMan 22.2's own GT.M technique (file .7 node 19,"ZS"):
 ; write the source into the first $ZROUTINES source dir, then ZLINK.
 new dir,i,pair,src,dst
 set dir=$piece($piece($piece($zroutines,")"),"(",2)," ")
 for i=1:1:5 do
 . set pair=$piece("DIDT:%DT^DIDTC:%DTC^DIRCR:%RCR^DIIS:%ZIS^DIISS:%ZISS","^",i)
 . set src=$piece(pair,":"),dst=$piece(pair,":",2)
 . do copy(src,dst,dir)
 . write "RENAMED ",src," -> ",dst,!
 quit
copy(src,dst,dir) ; write $TEXT image of src as dst's source file, then link
 new f,n,line
 set f=dir_"/"_$translate(dst,"%","_")_".m"
 open f:(newversion) use f
 for n=1:1 set line=$text(@("+"_n_"^"_src)) quit:line=""  write line,!
 close f
 zlink $translate(dst,"%","_")
 quit
