ZOSVSTUB ; fmpoc spike 3 - minimal hand-seeded %ZOSV for GT.M/YottaDB standalone FileMan
 ; Standalone FileMan 22.2 ships NO GT.M %ZOSV (DINVGUX has only DEL);
 ; DIALOG p7 et al. call these. Pure-M stubs, no Kernel globals.
 quit
LGR() ; last global reference
 quit $reference
LGRX ; set naked ref (caller Xecutes)
 quit
EC() ; error code, DSM-$ZE-ish shape (from ZOSVGUX)
 new %ze
 if $zstatus="" quit ""
 set %ze=$piece($zstatus,",",2)_","_$translate($piece($zstatus,",",4,999),",","'")_","_$piece($zstatus,",")_",-"_$piece($zstatus,",",3)
 quit %ze
GETENV ; Y=UCI^VOL^NODE^BOX:NODE
 new %host set %host=$piece($system,",",2)
 set Y="FMPOC^FMPOC^"_%host_"^FMPOC:"_%host
 quit
UCICHECK(X) quit 1
UCI set Y="FMPOC" quit
BADUCI quit
ACTJ() quit 1
AVJ() quit 99
MAXJ() quit 100
PROGMODE() quit 1
PRGMODEX quit
PRIINQ() quit 10
PRIORITY(X) quit
JOBPAR set Y="" quit
DOLRO quit
RO quit
PASSALL quit
NOPASS quit
TRMON quit
TRMOFF quit
