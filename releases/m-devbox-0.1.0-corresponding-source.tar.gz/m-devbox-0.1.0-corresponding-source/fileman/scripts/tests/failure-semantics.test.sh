#!/usr/bin/env bash
# PR-10 regression gate (offline): build.sh failure semantics.
#
# RULING (m-devbox PR-10, 2026-07-22): a failed build step destroys nothing it
# did not create this run —
#   docker transport: the script provisioned the scratch container, so on_err
#     tears IT down (VF_KEEP=1 opt-out). That stays.
#   local transport: the script provisioned NOTHING (it runs inside a
#     docker-build RUN layer; the builder discards a failed layer), so on_err
#     must never call `lifecycle destroy` — under local that os.Remove()s the
#     engine's .gld/.dat, i.e. a failed build step would DELETE THE DATABASE
#     (roster S-5, build.sh:29).
#
# Mechanism: stub m/m-ydb on PATH record every driver invocation; the DINIT
# phase is forced to fail; the test asserts the failure propagates AND that
# `lifecycle destroy` was (docker) / was NOT (local) invoked.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BUILD="$HERE/../build.sh"

run_arm() { # run_arm <transport> → log file path in $LOG
  local transport="$1"
  local tmp; tmp="$(mktemp -d)"
  LOG="$tmp/driver.log"
  : >"$LOG"
  # Stub m-ydb: log argv; every verb succeeds EXCEPT `exec script`, which
  # returns output without the MARKER so phase_dinit fails loud.
  cat >"$tmp/m-ydb" <<STUB
#!/usr/bin/env bash
echo "m-ydb \$*" >>"$LOG"
case "\$1 \$2" in
  "exec script") echo '{"ok":true,"exit":0,"data":{"stdout":"NO-MARKER"}}' ;;
  "exec eval")   echo '{"ok":true,"exit":0,"data":{"stdout":"stub"}}' ;;
  *)             echo '{"ok":true,"exit":0,"data":{}}' ;;
esac
STUB
  # Stub m: `m runlock hold … -- CMD…` just execs CMD (bracket elided).
  cat >"$tmp/m" <<'STUB'
#!/usr/bin/env bash
while [ $# -gt 0 ] && [ "$1" != "--" ]; do shift; done
shift
exec "$@"
STUB
  chmod +x "$tmp/m-ydb" "$tmp/m"
  local src="$tmp/fmsrc"; mkdir -p "$src"; touch "$src/DI.m"
  set +e
  PATH="$tmp:$PATH" VF_TRANSPORT="$transport" CONTAINER=stub-eng FM_SRC="$src" \
    bash "$BUILD" build >"$tmp/out.log" 2>&1
  RC=$?
  set -e
}

fail() { echo "FAIL: $*" >&2; exit 1; }

# --- local arm: failure must propagate and destroy NOTHING -------------------
run_arm local
[ "$RC" -ne 0 ] || fail "local: a failed DINIT phase must fail the build (rc=0)"
if grep -q "lifecycle destroy" "$LOG"; then
  fail "local: on_err invoked 'lifecycle destroy' — under the local transport that DELETES the .gld/.dat"
fi
if grep -q -- "--transport docker" "$LOG"; then
  fail "local: driver invoked with the docker transport"
fi
echo "ok: local failure destroys nothing (rc=$RC, no 'lifecycle destroy' in driver log)"

# --- docker arm: provision-owner teardown stays -------------------------------
run_arm docker
[ "$RC" -ne 0 ] || fail "docker: a failed DINIT phase must fail the build (rc=0)"
grep -q "lifecycle destroy" "$LOG" || \
  fail "docker: on_err must still tear down the scratch container it provisioned"
echo "ok: docker failure tears down its own scratch container"

echo "failure-semantics: PASS"
