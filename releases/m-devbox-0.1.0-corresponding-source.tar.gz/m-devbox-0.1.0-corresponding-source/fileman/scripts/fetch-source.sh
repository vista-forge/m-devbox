#!/usr/bin/env bash
# Fetch the pinned FileMan source into ./src (sync-time, network) and verify it
# byte-for-byte against seed/sources.sha256. Airgap model: this is the ONE network
# step (operator-run at sync-time); `make build` is offline and consumes ./src.
#
#   scripts/fetch-source.sh          # fetch + verify into ./src
#   scripts/fetch-source.sh --path   # print the resolved FM_SRC dir (no fetch)
#   scripts/fetch-source.sh --verify # verify an already-fetched ./src (no network)
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
PIN="$HERE/seed/source.pin"
SUMS="$HERE/seed/sources.sha256"
SRC_ROOT="$ROOT/src"

kv() { grep -E "^$1=" "$PIN" | head -1 | cut -d= -f2-; }
REPO="$(kv repo)"; COMMIT="$(kv commit)"; SUBPATH="$(kv subpath)"
DEST="$SRC_ROOT/$SUBPATH"

case "${1:-fetch}" in
  --path) echo "$DEST"; exit 0 ;;
esac

verify() {
  [ -d "$DEST" ] || { echo "fetch-source: no $DEST — run 'make sources' first" >&2; return 1; }
  ( cd "$DEST" && sha256sum -c "$SUMS" --quiet ) \
    || { echo "fetch-source: CHECKSUM MISMATCH — fetched source is not the proven byte-set" >&2; return 1; }
  echo "fetch-source: verified $(grep -c . "$SUMS") routines against seed/sources.sha256"
}

[ "${1:-}" = "--verify" ] && { verify; exit $?; }

echo "fetch-source: $REPO @ ${COMMIT:0:12}  ($SUBPATH)"
rm -rf "$SRC_ROOT"; mkdir -p "$SRC_ROOT"; cd "$SRC_ROOT"
git init -q
git remote add origin "$REPO"
git config core.sparseCheckout true
mkdir -p .git/info   # a global init.templatedir may omit info/ from git init
printf '%s/*\n' "$SUBPATH" > .git/info/sparse-checkout
# Sparse + blobless + single-commit: pulls only the FileMan blobs at the pin.
git fetch --depth 1 --filter=blob:none origin "$COMMIT"
git checkout -q FETCH_HEAD
rm -rf .git   # a plain source tree; provenance lives in seed/source.pin
verify
