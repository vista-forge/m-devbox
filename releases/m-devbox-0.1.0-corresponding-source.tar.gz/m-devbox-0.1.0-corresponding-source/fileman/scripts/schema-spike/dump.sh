#!/usr/bin/env bash
# Dump a routine's text from the engine via $TEXT loop, through the seam.
set -euo pipefail
CONTAINER="${CONTAINER:-vista-fileman}"
DT="--transport docker --container $CONTAINER"
R="$1"
CODE="new i,l,x s x=\"$R\" for i=1:1 s l=\$text(+i^@x) q:l=\"\"  w l,\$char(10)"
m runlock hold --engine ydb --docker "$CONTAINER" -- \
  m-ydb exec eval $DT -o json "$CODE" 2>/dev/null | python3 -c 'import json,sys
d,_=json.JSONDecoder().raw_decode(sys.stdin.read().strip())
sys.stdout.write(d.get("data",{}).get("stdout",""))'
