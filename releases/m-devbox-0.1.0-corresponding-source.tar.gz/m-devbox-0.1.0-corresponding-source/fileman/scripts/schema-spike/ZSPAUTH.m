ZSPAUTH ;p0b spike ;author the fixture DD nodes (fields 1-3 + xref + new-style index) onto the DICATT-created WIDGET file 999100 ;2026-07-19
 Q
FIELDS ; add STATUS(set), ACQUIRED(date), CATEGORY(pointer) via direct DD SET
 N F S F=999100
 ; clean any half-created field 1..3
 K ^DD(F,1),^DD(F,2),^DD(F,3)
 K ^DD(F,"B","STATUS"),^DD(F,"B","ACQUIRED"),^DD(F,"B","CATEGORY"),^DD(F,"B","halt")
 ; --- field 1 STATUS, set of codes, node 0;2 ---
 S ^DD(F,1,0)="STATUS^S^A:ACTIVE;I:INACTIVE;R:RETIRED;^0;2^Q"
 S ^DD(F,"B","STATUS",1)=""
 S ^DD(F,"GL",0,2,1)=""
 ; --- field 2 ACQUIRED, date (imprecise ok), node 0;3 ---
 S ^DD(F,2,0)="ACQUIRED^D^^0;3^S %DT=""E"" D ^%DT S X=Y K:Y<1 X"
 S ^DD(F,"B","ACQUIRED",2)=""
 S ^DD(F,"GL",0,3,2)=""
 ; --- field 3 CATEGORY, pointer to 999101, node 0;4 ---
 S ^DD(F,3,0)="CATEGORY^P999101'^DIZ(999101,^0;4^Q"
 S ^DD(F,"B","CATEGORY",3)=""
 S ^DD(F,"GL",0,4,3)=""
 ; header field count -> 4 fields (.01,1,2,3), top .01..3
 S ^DD(F,0)="ZSPIKE WIDGET^999100^3^4"
 W "FIELDS set",!
 Q
XREF ; regular whole-file x-ref C on STATUS (field 1); reindex via IXALL^DIK
 N F,DIK,DA S F=999100
 ; regular MUMPS x-ref #2 on field 1 (STATUS): ^DIZ(F,"C",status,ien)
 S ^DD(F,1,1,0)="^.1"
 S ^DD(F,1,1,1,0)=F_"^C"
 S ^DD(F,1,1,1,1)="S ^DIZ("_F_",""C"",X,DA)="""""
 S ^DD(F,1,1,1,2)="K ^DIZ("_F_",""C"",X,DA)"
 S ^DD(F,1,1,1,3)="STATUS regular x-ref"
 ; force-build all cross-references from the DD (authoritative reindexer)
 S DIK="^DIZ("_F_"," D IXALL^DIK
 W "XREF set + reindexed",!
 Q
CAT ; seed 2 CATEGORY entries so the pointer has targets
 N FDA,IEN,ERR
 S FDA(999101,"+1,",.01)="HARDWARE" D UPDATE^DIE("","FDA","IEN","ERR")
 K FDA,IEN,ERR S FDA(999101,"+1,",.01)="SOFTWARE" D UPDATE^DIE("","FDA","IEN","ERR")
 W "CAT seeded ",$O(^DIZ(999101,""),-1)," entries",!
 Q
RT ; round-trip a WIDGET record through the DBS API -> proves the DD is FileMan-valid
 N FDA,IEN,ERR,OUT,cat
 S cat=$O(^DIZ(999101,"B","HARDWARE",0))
 S FDA(999100,"+1,",.01)="WIDGET-A"
 S FDA(999100,"+1,",1)="A"
 S FDA(999100,"+1,",2)=3260101
 S FDA(999100,"+1,",3)="`"_cat
 D UPDATE^DIE("","FDA","IEN","ERR")
 I $D(ERR("DIERR")) W "RT FILE ERR: ",$G(ERR("DIERR",1,"TEXT",1)),! Q
 N ien S ien=+IEN(1)
 D GETS^DIQ(999100,ien_",",".01;1;2;3","IE","OUT","ERR")
 W "RT ien=",ien," .01=",$G(OUT(999100,ien_",",.01,"E"))
 W "|STATUS=",$G(OUT(999100,ien_",",1,"E"))
 W "|ACQ=",$G(OUT(999100,ien_",",2,"E"))
 W "|CAT=",$G(OUT(999100,ien_",",3,"E"))
 W "|Cxref=",$D(^DIZ(999100,"C","A",ien))
 W "|AACQidx=",$D(^DIZ(999100,"AACQ"))
 W !
 Q
EDIT ; the edit round-trip: add a 4th field WEIGHT (numeric) to WIDGET
 N F S F=999100
 S ^DD(F,4,0)="WEIGHT^NJ6,0^^1;2^K:+X'=X!(X>999999)!(X<0)!(X?.E1""."".E) X"
 S ^DD(F,"B","WEIGHT",4)=""
 S ^DD(F,"GL",1,2,4)=""
 S ^DD(F,0)="ZSPIKE WIDGET^999100^4^5"
 W "EDIT: WEIGHT field added",!
 Q
ALL D FIELDS,CAT,RT Q
