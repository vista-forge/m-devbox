# scripts/schema-spike — the freight D6 schema-mechanism spike harness

Reusable substrate for the **fileman-stdlib Phase 0b** spike that settled freight
decision **D6** (how a FileMan schema becomes a pinned, re-appliable artifact).
Verdict + evidence live in the `docs` repo:
`docs/proposals/fileman-stdlib/phase0-artifacts/phase0b-README.md`
(**B — DIFROM wins**; A scripted-dialog and C direct-emit fail the bar).

Test-only. NOT FileMan, NOT FSL. Drives a scratch `vista-fileman` YottaDB engine
**through the m-ydb driver seam only** (org rule: no raw `docker exec`/`mumps`).
Provision the engine with `make build` first; tear down with `make down`.

- **`fmdlg.sh`** — run a scripted FileMan dialog or an M eval through the seam,
  one run-lock bracket per call, `$ETRAP` + programmer-context (`DUZ=1,DUZ(0)="@"`)
  prologue auto-added. `fmdlg.sh script <<'EOF' … EOF` (stdin = dialog answer
  lines) / `fmdlg.sh eval '<m-code>'`.
- **`dump.sh <ROUTINE>`** — dump a routine's source via `$TEXT` through the seam
  (used to capture the DIFROM-generated `<ns>INIT` set). **Caveat C-1:** strip
  trailing whitespace-only lines from the dump before committing/loading, or the
  DIFROM DD-loader faults `%YDB-E-VAREXPECTED` on a space-only line.
- **`ZSPAUTH.m`** — authors the spike fixture DD (a `ZSPIKE WIDGET` file #999100:
  free-text `.01` + input transform, `STATUS` set, `ACQUIRED` date, `CATEGORY`
  pointer → #999101) onto DICATT-created files, seeds pointer targets, and
  round-trips a record. `EDIT^ZSPAUTH` adds a `WEIGHT` field for the edit-arm.

The DIFROM workflow the spike proved: author the fixture (via `fmdlg.sh` +
`ZSPAUTH.m`) → `D ^DIFROM` (namespace `ZSP`, file 999100) → `dump.sh` each
`ZSPINIT*`/`ZSPIN00*` → strip trailing blanks → the routine set is the pinned
schema artifact → `D ^ZSPINIT` applies it (apply / re-apply-idempotent /
edit-round-trip all verified). P2 `fmschema` builds on this: apply must add a
post-apply `^DD(F,"IX",fld)` reconstruct + `IXALL^DIK` reindex + live-lookup
verify (caveat C-2).
