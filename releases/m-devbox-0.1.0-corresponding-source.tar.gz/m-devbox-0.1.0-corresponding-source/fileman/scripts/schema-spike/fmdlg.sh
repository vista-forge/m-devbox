#!/usr/bin/env bash
# P0b spike helper — run a scripted dialog (or eval) against the scratch
# vista-fileman engine THROUGH THE DRIVER SEAM ONLY, one runlock bracket per call.
#   fmdlg.sh script <<'EOF'   (lines = dialog input; $ETRAP preamble added)
#   fmdlg.sh eval '<m-code>'
set -euo pipefail
CONTAINER="${CONTAINER:-vista-fileman}"
DT="--transport docker --container $CONTAINER"
ETRAP='S $ETRAP="W !,""ETRAP:"",$ZSTATUS,! S $ECODE="""" ZGOTO 0"'
DUZ='set DUZ=1,DUZ(0)="@",U="^"'

sout() { python3 -c 'import json,sys
s=sys.stdin.read().strip()
if not s: print("<EMPTY ENGINE OUTPUT>"); sys.exit(0)
try: d,_=json.JSONDecoder().raw_decode(s)   # FIRST json doc = the exec result
except Exception: print("<NON-JSON: "+s[:400]+">"); sys.exit(0)
if not d.get("ok",True):
    print("<engineError: "+json.dumps(d.get("error") or d.get("engineError"))+">")
print(d.get("data",{}).get("stdout",""),end="")'; }

case "${1:?script|eval}" in
  script)
    b64="$( { printf '%s\n' "$ETRAP" "$DUZ"; cat; } | base64 -w0)"
    m runlock hold --engine ydb --docker "$CONTAINER" -- \
      m-ydb exec script $DT -o json --script-b64 "$b64" 2>/dev/null | sout ;;
  eval)
    m runlock hold --engine ydb --docker "$CONTAINER" -- \
      m-ydb exec eval $DT -o json "$DUZ $2" 2>/dev/null | sout ;;
  *) echo "usage: fmdlg.sh {script|eval}" >&2; exit 2 ;;
esac
