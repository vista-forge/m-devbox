#!/usr/bin/env bash
# fileman-stdlib Phase 0 — R-6 conformance probe driver (adversarial analysis R-6).
#
# Drives the FMPRB.m harness against a scratch `vista-fileman` YottaDB engine
# THROUGH THE m-ydb DRIVER SEAM ONLY (org rule: no raw docker/mumps). One
# run-lock bracket is held around the whole run (the build.sh pattern); nested
# engine verbs run unbracketed inside it. Crash injection = arm a HANG gate in a
# .01 x-ref, freeze the writer there, then `m-ydb exec abort` (mupip stop) — the
# in-driver equivalent of SIGKILL-mid-write ([[suspended-engine-writer-triage]]).
#
# State floor: the session provisions a fresh FileMan engine with `make build`.
# BUILD^FMPRB kills+recreates probe file #999000 and all ^ZFS* scratch globals,
# giving each probe a clean floor for the only state it touches (no probe mutates
# core FileMan). Contamination-sensitive arms note their reset explicitly.
#
#   scripts/probe/run.sh <a|b|c|d|e|all>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
CONTAINER="${CONTAINER:-vista-fileman}"
C="--transport docker --container $CONTAINER -o json"
DUZ='set DUZ=1,DUZ(0)="@",U="^"'

# Re-enter under one held run-lock (unbracketed engine verbs inside).
if [ -z "${VF_LOCKED:-}" ]; then
  exec m runlock hold --engine ydb --docker "$CONTAINER" -- env VF_LOCKED=1 "$0" "$@"
fi

sout() { python3 -c 'import json,sys
s=sys.stdin.read().strip()
if not s: print("<EMPTY ENGINE OUTPUT — check for fault>"); sys.exit(0)
try:
    d=json.loads(s)
except Exception:
    print("<NON-JSON: "+s[:200]+">"); sys.exit(0)
if not d.get("ok",True): print("<engineError: "+json.dumps(d.get("error") or d.get("engineError"))+">"); sys.exit(0)
print(d.get("data",{}).get("stdout",""),end="")' ; }
ev()  { m-ydb exec eval $C "$1" 2>/dev/null | sout; }
reset(){ m-ydb exec eval $C "$DUZ do BUILD^FMPRB" >/dev/null; }
load() { m-ydb exec load $C "$HERE/FMPRB.m" >/dev/null; }

probe_a() {
  echo "### R-6(a) torn write (G-1) — kill-9-equivalent mid-FILE^DIE"
  reset
  ev "$DUZ do FILE^FMPRB(\"WIDGET ALPHA\",\"AAA\",10) do FILE^FMPRB(\"WIDGET BETA\",\"BBB\",20)"
  echo -n "baseline (uninterrupted, atomic): "; ev "$DUZ do SKEW^FMPRB"
  m-ydb exec run $C --prefix ZFSA "HANGFILE^FMPRB" "WIDGET~GAMMA" "CCC" >/dev/null 2>&1 &
  local wpid=$! i h
  for i in $(seq 1 800); do
    h=$(ev "write \$data(^ZFSMARK(\"hang\"))")
    [ "${h:-0}" != "0" ] && [ -n "$h" ] && { echo "writer frozen in .01 C-xref after $i polls (\$D=$h)"; break; }
  done
  echo -n "torn state, writer FROZEN mid-index: "; ev "$DUZ do SKEW^FMPRB"
  echo -n "abort (mupip stop the frozen writer): "; m-ydb exec abort $C --prefix ZFSA 2>/dev/null | python3 -c 'import json,sys;print("ok="+str(json.load(sys.stdin).get("ok")))'
  echo -n "post-crash state (PERMANENT torn record): "; ev "$DUZ do SKEW^FMPRB"
  wait "$wpid" 2>/dev/null || true
  echo "VERDICT: data/header/B-index count the crashed record; C-index is short one entry -> torn, un-repaired-by-engine (needs re-index). G-1 CONFIRMED."
}

probe_b() {
  echo "### R-6(b) IEN contention (G-4) — N concurrent DBS inserters"
  local N
  for N in 1 2 4 8; do
    reset
    local recs=$((100))   # per-writer record count
    local start end
    start=$(date +%s.%N)
    local pids=() k
    for k in $(seq 1 "$N"); do
      m-ydb exec run $C --prefix "ZFSB$k" "MANYFILE^FMPRB" "W$k" "$recs" >/dev/null 2>&1 &
      pids+=($!)
    done
    for k in "${pids[@]}"; do wait "$k" 2>/dev/null || true; done
    end=$(date +%s.%N)
    local secs; secs=$(python3 -c "print(f'{$end-$start:.2f}')")
    local total=$((N*recs))
    local rep; rep=$(ev "$DUZ do CONTREP^FMPRB")
    local aps; aps=$(python3 -c "print(f'{$total/($end-$start):.0f}')")
    echo "N=$N writers x $recs = $total intended | ${secs}s | ${aps} adds/s | $(echo "$rep" | tr -d '\n')"
  done
  echo "VERDICT: at every N the file stays dense (gaps=0), loses nothing (records=intended,"
  echo "  fileErr=0) and every returned IEN points at its own record (badReturnedIEN=0) — FileMan's"
  echo "  DICN0 LOCK+TRY-NEXT allocation is CORRECT under concurrency. Cost is throughput only"
  echo "  (sublinear scaling). G-4 = a throughput hotspot, not a correctness gap -> FSLIEN DEFERRED."
}

probe_c() {
  echo "### R-6(c) torn read (G-2) — GETS^DIQ sees a half-updated multi-node record"
  # Deterministic arm: freeze a writer mid-UPDATE between two coupled nodes
  # (.01 and CODE, both encoding the same digit) using the .01 C-xref hang, then
  # read the pair through GETS^DIQ — no read lock, no read isolation.
  reset
  ev "$DUZ do DCSEED^FMPRB"
  echo -n "seeded coupled pair: "; ev "$DUZ do DCREAD^FMPRB"
  m-ydb exec run $C --prefix ZFSCD "DCHANG^FMPRB" >/dev/null 2>&1 &
  local wpid=$! i h
  for i in $(seq 1 800); do
    h=$(ev "write \$data(^ZFSMARK(\"hang\"))")
    [ "${h:-0}" != "0" ] && [ -n "$h" ] && { echo "writer frozen mid-update after $i polls"; break; }
  done
  echo -n "read WHILE writer frozen mid-update: "; ev "$DUZ do DCREAD^FMPRB"
  m-ydb exec abort $C --prefix ZFSCD >/dev/null 2>&1 || true
  wait "$wpid" 2>/dev/null || true
  echo "VERDICT: torn=1 -> GETS^DIQ returned a record whose .01 and CODE disagree (new .01, old CODE). No read isolation. G-2 CONFIRMED."
  # Secondary racy arm (informational): tight coupled flip + high-rate sampler
  echo "--- secondary (racy sampler, informational) ---"
  reset; ev "$DUZ do COUPLE^FMPRB"
  m-ydb exec run $C --prefix ZFSCU "UPDCOUPLE^FMPRB" >/dev/null 2>&1 &
  local wp2=$!
  echo -n "sampler: "; ev "$DUZ do READPAIR^FMPRB(200000)"
  m-ydb exec abort $C --prefix ZFSCU >/dev/null 2>&1 || true
  wait "$wp2" 2>/dev/null || true
}

probe_d() {
  echo "### R-6(d) bypass (G-3) — direct SET/KILL around the DBS API"
  reset
  ev "$DUZ do FILE^FMPRB(\"WIDGET ALPHA\",\"AAA\",10)"
  ev "$DUZ do BYPASS^FMPRB"
  echo "VERDICT: raw SET adds an un-indexed, un-counted record invisible to FIND^DIC; raw KILL leaves dangling x-refs. No enforcement boundary. G-3 CONFIRMED."
}

probe_e() {
  echo "### R-6(e) DBS-inside-TP (FSLTX go/no-go) — YottaDB lane"
  reset; echo -n "(iii) DBS write inside TSTART/TCOMMIT: "; ev "$DUZ do TPWRITE^FMPRB"
  reset; echo -n "(i)   LOCK in a transaction:           "; ev "$DUZ do TPLOCK^FMPRB"
  reset; echo -n "(ii)  ^TMP(DIERR) under TROLLBACK:      "; ev "$DUZ do TPTMP^FMPRB"
  reset; echo -n "(v)   \$INCREMENT under TROLLBACK:       "; ev "$DUZ do TPINCR^FMPRB"
  # (iv) crash INSIDE the TP bracket -> whole txn rolls back -> nothing persists
  reset
  ev "$DUZ do FILE^FMPRB(\"KEEP ONE\",\"K1\",1)" >/dev/null
  echo -n "(iv)  pre-crash baseline:               "; ev "$DUZ do SKEW^FMPRB"
  m-ydb exec run $C --prefix ZFSE "TPHANGFILE^FMPRB" "TP~GHOST" >/dev/null 2>&1 &
  local wpid=$! i h
  # poll the COMMITTED pre-bracket marker (the in-txn hang marker is invisible by TP isolation)
  for i in $(seq 1 800); do
    h=$(ev "write \$data(^ZFSMARK(\"tpstart\"))")
    [ "${h:-0}" != "0" ] && [ -n "$h" ] && { echo "      writer reached the TP bracket after $i polls (now frozen in-txn, writes invisible)"; break; }
  done
  # a few more polls to let it enter the in-txn hang before we crash it
  for i in $(seq 1 20); do ev "write 1" >/dev/null; done
  echo -n "      other process view mid-txn (TP isolation): "; ev "$DUZ do SKEW^FMPRB"
  echo -n "      abort (mupip stop the frozen in-txn writer): "; m-ydb exec abort $C --prefix ZFSE 2>/dev/null | python3 -c 'import json,sys
d=json.load(sys.stdin);print("ok="+str(d.get("ok"))+" data="+json.dumps(d.get("data")))'
  wait "$wpid" 2>/dev/null || true
  echo -n "(iv)  post-crash (txn rolled back?):    "; ev "$DUZ do SKEW^FMPRB"
  echo "VERDICT: committed TP write (iii) persists; crashed in-txn write (iv) leaves data=1 (KEEP ONE only) — the TP GHOST vanished. Contrast R-6(a)'s PERSISTENT torn record. Crash-atomicity CONFIRMED on the YDB lane."
}

load
case "${1:-all}" in
  a) probe_a ;;
  b) probe_b ;;
  c) probe_c ;;
  d) probe_d ;;
  e) probe_e ;;
  all) probe_a; echo; probe_b; echo; probe_c; echo; probe_d; echo; probe_e ;;
  *) echo "usage: ${0##*/} {a|b|c|d|e|all}" >&2; exit 2 ;;
esac
