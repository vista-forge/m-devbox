#!/usr/bin/env bash
# fileman-stdlib Phase 0 — driver-seam benchmark (R-6 companion "bench" row).
#
# Measures the m-ydb docker-transport exec seam against a scratch vista-fileman
# engine THROUGH THE DRIVER ONLY: round-trip latency (each exec = a fresh
# in-container process spawn), throughput, and request-payload behavior vs the
# measured ~18 KB YDB command-line ceiling ([[stack-architecture-review-p10]]).
#
#   scripts/probe/bench.sh [N]     # N round-trips for the latency sample (default 60)
set -euo pipefail
CONTAINER="${CONTAINER:-vista-fileman}"
C="--transport docker --container $CONTAINER -o json"
N="${1:-60}"

if [ -z "${VF_LOCKED:-}" ]; then
  exec m runlock hold --engine ydb --docker "$CONTAINER" -- env VF_LOCKED=1 "$0" "$@"
fi

echo "### driver-seam benchmark (m-ydb docker transport, container $CONTAINER)"

# --- latency / throughput: N sequential fresh-process round-trips ---
echo "## round-trip latency ($N sequential exec eval, each a fresh process spawn)"
: > /tmp/zfsbench.ms
for i in $(seq 1 "$N"); do
  t0=$(date +%s.%N)
  m-ydb exec eval $C 'write 1+1' >/dev/null 2>&1
  t1=$(date +%s.%N)
  python3 -c "print(f'{($t1-$t0)*1000:.1f}')" >> /tmp/zfsbench.ms
done
python3 - <<'PY'
import statistics as st
xs=sorted(float(l) for l in open('/tmp/zfsbench.ms') if l.strip())
n=len(xs)
def pct(p):
    import math
    k=max(0,min(n-1,int(round((p/100)*(n-1)))))
    return xs[k]
tot=sum(xs)/1000.0
print(f"n={n} | p50={pct(50):.1f}ms | p95={pct(95):.1f}ms | min={xs[0]:.1f}ms | max={xs[-1]:.1f}ms | mean={st.mean(xs):.1f}ms")
print(f"throughput (sequential, fresh process/call) = {n/tot:.0f} round-trips/s")
PY

# --- request-payload ceiling: grow the REQUEST command line until it faults ---
echo "## request-payload behavior vs the ~18 KB YDB command-line ceiling"
for kb in 1 4 8 16 24 32 40 48; do
  n=$((kb*1024))
  big=$(python3 -c "print('A'*$n)")
  out=$(m-ydb exec eval $C "set X=\"$big\" write \"len=\",\$length(X)" 2>/dev/null || true)
  reqlen=$((n+40))
  status=$(printf '%s' "$out" | python3 -c "import json,sys
try:
  d=json.loads(sys.stdin.read())
  if d.get('ok'): print('ok, engine saw len='+ (d.get('data',{}).get('stdout','').strip()))
  else: print('FAULT: '+str((d.get('error') or d.get('engineError') or {}).get('message','?')))
except Exception:
  print('empty/kill (no JSON returned)')" 2>/dev/null || echo "parse-fail")
  echo "  request ~${kb}KB literal (cmd ~${reqlen}B): $status"
done
echo "NOTE: the request literal rides the in-container M command line (%XCMD/INDRMAXLEN=32766);"
echo "      a bulk FSLDB create/FSLQ forward must page under this ceiling. FSLQ paginates by design."
