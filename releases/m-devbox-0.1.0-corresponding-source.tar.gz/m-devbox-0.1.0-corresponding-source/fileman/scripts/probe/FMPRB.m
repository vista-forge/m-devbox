FMPRB ;phase0/fileman-stdlib ;R-6 FileMan conformance probe harness (NOT FSL) ;2026-07-19
 ;;0.1;fileman-stdlib probes;;
 ; Test-only probe harness for the R-6 conformance probes (adversarial analysis
 ; recommendation R-6). Builds a scratch FileMan probe file #999000 (.01 with a
 ; B x-ref and an instrumentable C x-ref carrying a HANG gate, a CODE field, a
 ; QTY field, and an ITEMS multiple) and drives FileMan's documented DBS API
 ; (UPDATE^DIE / GETS^DIQ / FIND^DIC) to red-proof the ACID gaps. NEVER edits
 ; FileMan. A frozen writer is crashed via `m-ydb exec abort` (mupip stop at the
 ; HANG) — the in-driver equivalent of SIGKILL-mid-write. Drive LABEL^FMPRB
 ; through the m-ydb seam only.
 Q
 ;
BUILD ; emit the probe-file DD (fixture) — idempotent, resets probe state
 N F S F=999000
 K ^DIC(F),^DIZ(F),^DD(F),^DD(F_.03),^ZFSHANG,^ZFSMARK,^ZFSRES,^ZFSLK,^ZFSINC,^ZFSTMP,^ZFSCTR,^ZFSW
 S ^DIC(F,0)="ZFS PROBE^"_F
 S ^DIC(F,0,"GL")="^DIZ("_F_","
 S ^DIC("B","ZFS PROBE",F)=""
 S ^DIZ(F,0)="ZFS PROBE^"_F_"^0^0"
 S ^DD(F,0)="ZFS PROBE^L^3^3"
 ; --- .01 NAME, node 0;1, regular B x-ref ---
 S ^DD(F,.01,0)="NAME^RF^^0;1^K:$L(X)>30!($L(X)<1) X"
 S ^DD(F,.01,1,0)="^.1"
 S ^DD(F,.01,1,1,0)=F_"^B"
 S ^DD(F,.01,1,1,1)="S ^DIZ("_F_",""B"",$E(X,1,30),DA)="""""
 S ^DD(F,.01,1,1,2)="K ^DIZ("_F_",""B"",$E(X,1,30),DA)"
 ; second .01 x-ref C WITH HANG HOOK (fires after B on the same field)
 S ^DD(F,.01,1,2,0)=F_"^C"
 S ^DD(F,.01,1,2,1)="D S1^FMPRB"
 S ^DD(F,.01,1,2,2)="D K1^FMPRB"
 S ^DD(F,"B","NAME",.01)="",^DD(F,"IX",.01)="",^DD(F,"RQ",.01)=""
 S ^DD(F,"GL",0,1,.01)=""
 ; --- field 1 CODE, node 1;1 (plain, unindexed) ---
 S ^DD(F,1,0)="CODE^F^^1;1^K:$L(X)>10 X"
 S ^DD(F,"B","CODE",1)="",^DD(F,"GL",1,1,1)=""
 ; --- field 2 QTY, node 2;1 (plain, unindexed) ---
 S ^DD(F,2,0)="QTY^NJ6,0^^2;1^K:+X'=X!(X>999999)!(X<0)!(X?.E1""."".E) X"
 S ^DD(F,"B","QTY",2)="",^DD(F,"GL",2,1,2)=""
 ; --- field 3 ITEMS, a MULTIPLE (subfile 999000.03) ---
 S ^DD(F,3,0)="ITEMS^999000.03^^3;0"
 S ^DD(F,"B","ITEMS",3)="",^DD(F,"GL",3,0,3)=""
 S ^DD(F,3,3)="This is a multiple."
 S ^DD(F,3,21,0)="^^0^0^0"
 S ^DD(F_.03,0)="ITEMS SUB-FIELD^^.01^1"
 S ^DD(F_.03,0,"UP")=F
 S ^DD(F_.03,.01,0)="ITEM^MF^^0;1^K:$L(X)>20!($L(X)<1) X"
 S ^DD(F_.03,.01,1,0)="^.1"
 S ^DD(F_.03,.01,1,1,0)=F_.03_"^B"
 S ^DD(F_.03,.01,1,1,1)="S ^DIZ("_F_",DA(1),3,""B"",$E(X,1,30),DA)="""""
 S ^DD(F_.03,.01,1,1,2)="K ^DIZ("_F_",DA(1),3,""B"",$E(X,1,30),DA)"
 S ^DD(F_.03,"B","ITEM",.01)="",^DD(F_.03,"GL",0,1,.01)=""
 W "BUILT file ",F,!
 Q
 ;
S1 ; .01 C x-ref SET logic (X=value, DA=ien) — freeze gate here
 I $G(^ZFSHANG) S ^ZFSMARK("hang",DA,X)=$H H 999999
 S ^DIZ(999000,"C",$E(X,1,30),DA)=""
 Q
K1 K ^DIZ(999000,"C",$E(X,1,30),DA) Q
 ;
FILE(NAME,CODE,QTY) ; file a new #999000 record via UPDATE^DIE (compat path)
 N FDA,IEN,ERR
 S FDA(999000,"+1,",.01)=NAME
 S:$G(CODE)'="" FDA(999000,"+1,",1)=CODE
 S:$G(QTY)'="" FDA(999000,"+1,",2)=QTY
 D UPDATE^DIE("","FDA","IEN","ERR")
 S ^ZFSRES("lastien")=$G(IEN(1))
 W "IEN=",$G(IEN(1)),"|ERR=",$G(ERR("DIERR",1,"TEXT",1),"none"),!
 Q
 ;
HANGFILE ; (R-6a) arm the C-xref hang then file — writer freezes mid-index
 N NAME,CODE S NAME=$P($ZCMDLINE," ",1),CODE=$P($ZCMDLINE," ",2)
 S:NAME="" NAME="WIDGET GAMMA" S:CODE="" CODE="CCC"
 S ^ZFSHANG=1
 D FILE^FMPRB(NAME,CODE,30)
 Q
 ;
SKEW ; report atomicity skew: #data-records vs #B-xref vs #C-xref vs header
 N nd,i S nd=0,i=0 F  S i=$O(^DIZ(999000,i)) Q:+i'=i!(i="")  S nd=nd+1
 W "SKEW data=",nd,"|Bxref=",$$tot("B"),"|Cxref=",$$tot("C"),"|header=",$P($G(^DIZ(999000,0)),U,4),!
 Q
tot(x) N n,i,j S n=0,i="" F  S i=$O(^DIZ(999000,x,i)) Q:i=""  S j="" F  S j=$O(^DIZ(999000,x,i,j)) Q:j=""  S n=n+1
 Q n
 ;
MANYFILE ; (R-6b) file N records tagged <TAG>-<i>; args: TAG N  (via $ZCMDLINE)
 ; Records into ^ZFSW: intended-adds and how many returned IEN(1)s DID NOT
 ; point at this writer's own record (the returned-IEN-trust question).
 N tag,n,i,ien,nm,ok,bad,mis S tag=$P($ZCMDLINE," ",1),n=+$P($ZCMDLINE," ",2)
 N FDA,IEN,ERR S ok=0,bad=0,mis=0 F i=1:1:n D
 . S nm=tag_"-"_i K FDA,IEN,ERR
 . S FDA(999000,"+1,",.01)=nm,FDA(999000,"+1,",1)=$E(tag)
 . D UPDATE^DIE("","FDA","IEN","ERR") S ien=+$G(IEN(1))
 . I ien'>0 S bad=bad+1 Q
 . S ok=ok+1
 . ; does the returned IEN actually hold OUR record?
 . I $P($G(^DIZ(999000,ien,0)),U,1)'=nm S mis=mis+1
 S ^ZFSW(tag)=ok_"/"_bad_"/"_mis
 Q
CONTREP ; (R-6b) report: filed records vs intended, IEN density, returned-IEN mismatches
 N nd,i,mx,mn S nd=0,i=0,mx=0,mn=999999999
 F  S i=$O(^DIZ(999000,i)) Q:+i'=i!(i="")  S nd=nd+1 S:i>mx mx=i S:i<mn mn=i
 N t,ok,bad,mis S ok=0,bad=0,mis=0,t="" F  S t=$O(^ZFSW(t)) Q:t=""  D
 . S ok=ok+$P(^ZFSW(t),"/",1),bad=bad+$P(^ZFSW(t),"/",2),mis=mis+$P(^ZFSW(t),"/",3)
 W "CONTREP records=",nd,"|ienDense=",mn,"-",mx,"|gaps=",(mx-mn+1-nd),"|fileErr=",bad,"|badReturnedIEN=",mis,!
 Q
 ;
COUPLE ; (R-6c) seed record 1 with coupled fields CODE=QTY baseline (V1)
 N FDA,IEN,ERR K ^DIZ(999000) S ^DIZ(999000,0)="ZFS PROBE^999000^0^0"
 S FDA(999000,"+1,",.01)="COUPLED",FDA(999000,"+1,",1)="V1",FDA(999000,"+1,",2)=1
 D UPDATE^DIE("","FDA","IEN","ERR") W "seeded ien=",$G(IEN(1)),!
 Q
UPDCOUPLE ; (R-6c) flip record 1's CODE and QTY between coupled states in a loop
 N FDA,ERR,i,c F i=1:1:100000 S c=i#2+1 K FDA,ERR S FDA(999000,"1,",1)="V"_c,FDA(999000,"1,",2)=c D FILE^DIE("","FDA","ERR")
 Q
READPAIR(N) ; (R-6c) read CODE+QTY via GETS^DIQ in a loop; catch a torn pair
 N i,OUT,ERR,c,q,torn S torn=0 F i=1:1:N D  Q:torn
 . K OUT,ERR D GETS^DIQ(999000,"1,","1;2","","OUT","ERR")
 . S c=$G(OUT(999000,"1,",1)),q=$G(OUT(999000,"1,",2))
 . I c'="",q'="",$E(c,2)'=q S torn=1,^ZFSRES("torn")="CODE="_c_"/QTY="_q_" @iter "_i
 W "READPAIR torn=",torn,"|",$G(^ZFSRES("torn"),"none"),"|iters=",i,!
 Q
 ;
DCSEED ; (R-6c deterministic) seed record 1 with coupled .01/CODE both encoding "1"
 N FDA,IEN,ERR K ^DIZ(999000) S ^DIZ(999000,0)="ZFS PROBE^999000^0^0"
 S FDA(999000,"+1,",.01)="ROW-1",FDA(999000,"+1,",1)="V1"
 D UPDATE^DIE("","FDA","IEN","ERR") W "seeded ien=",$G(IEN(1)),!
 Q
DCHANG ; (R-6c) arm hang, update rec1 .01 AND CODE to "2"; freeze in .01 C-xref
 N FDA,ERR S ^ZFSHANG=1
 S FDA(999000,"1,",.01)="ROW-2",FDA(999000,"1,",1)="V2"
 D FILE^DIE("","FDA","ERR")
 Q
DCREAD ; (R-6c) read rec1 .01+CODE via GETS^DIQ; report whether the pair is torn
 N OUT,ERR,a,c D GETS^DIQ(999000,"1,",".01;1","","OUT","ERR")
 S a=$G(OUT(999000,"1,",.01)),c=$G(OUT(999000,"1,",1))
 W "DCREAD .01=",a,"|CODE=",c,"|torn=",($E(a,$L(a))'=$E(c,2)),!
 Q
 ;
BYPASS ; (R-6d) direct SET/KILL bypassing the DBS API — no xref/header/audit
 N FDA,IEN,ERR,f S f=999000
 ; state before
 W "before: ",$$sk(),!
 ; raw insert a record at IEN 777 straight into the data global
 S ^DIZ(f,777,0)="GHOST RECORD^ZZZ^99"
 W "after-raw-SET: ",$$sk(),!
 ; can the DBS layer find the ghost by name?  ($$FIND1^DIC over the B x-ref)
 N gi,gerr S gi=$$FIND1^DIC(999000,"","X","GHOST RECORD","B","","gerr")
 W "FIND1 ghost by name -> ien=",+gi," (0 = not found by the DBS layer)",!
 ; raw KILL a real record's data node -> dangling B/C xref
 S ^DIZ(f,1,0)="REAL ONE^RR^1",^DIZ(f,"B","REAL ONE",1)="",^DIZ(f,"C","RR",1)=""
 K ^DIZ(f,1,0)
 W "after-raw-KILL data node (xrefs remain): Bxref=",$$tot("B"),"|dataNode1=",$D(^DIZ(f,1,0)),!
 Q
sk() Q "data="_$$cd()_"|Bxref="_$$tot("B")_"|header="_$P($G(^DIZ(999000,0)),U,4)
cd() N n,i S n=0,i=0 F  S i=$O(^DIZ(999000,i)) Q:+i'=i!(i="")  S n=n+1
 Q n
 ;
TPWRITE ; (R-6e-iii) can a DBS write run inside TSTART/TCOMMIT? does it commit?
 N FDA,IEN,ERR,tl0
 TSTART (IEN,ERR,FDA):SERIAL
 S FDA(999000,"+1,",.01)="TP RECORD",FDA(999000,"+1,",1)="TPX"
 D UPDATE^DIE("","FDA","IEN","ERR")
 S tl0=$TLEVEL
 TCOMMIT
 W "TPWRITE ien=",$G(IEN(1)),"|err=",$G(ERR("DIERR",1,"TEXT",1),"none"),"|tlevel-in-bracket=",tl0,"|after-commit=",$TLEVEL,"|persisted=",$D(^DIZ(999000,+$G(IEN(1)),0)),!
 Q
TPLOCK ; (R-6e-i) LOCK acquisition + release-on-commit inside a transaction
 N r,tl S r=""
 TSTART ():SERIAL
 L +^ZFSLK(1):3 S r="acq="_$T_";tlevel="_$TLEVEL
 TCOMMIT
 ; after TCOMMIT: is the incremental lock still held? (re-lock at 0 timeout)
 L +^ZFSLK(1):0 S r=r_";held-after-commit="_$T L -^ZFSLK(1),-^ZFSLK(1)
 W "TPLOCK ",r,!
 Q
TPTMP ; (R-6e-ii) does ^TMP(DIERR)-style state roll back on TROLLBACK / survive to caller?
 N s K ^ZFSTMP
 TSTART ():SERIAL
 S ^ZFSTMP($J,"DIERR",1,"TEXT",1)="boom"
 S s="in-bracket=$D:"_$D(^ZFSTMP($J,"DIERR"))
 TROLLBACK
 S s=s_";after-rollback=$D:"_$D(^ZFSTMP($J,"DIERR"))
 W "TPTMP ",s,!
 Q
TPINCR ; (R-6e-v) $INCREMENT inside TP: atomic + rolls back on TROLLBACK?
 N a,b K ^ZFSINC S ^ZFSINC=0
 TSTART ():SERIAL
 S a=$INCREMENT(^ZFSINC)
 TROLLBACK
 S b=$G(^ZFSINC)
 W "TPINCR value-in-tp=",a,"|after-rollback=",b,!
 Q
TPHANGFILE ; (R-6e-iv) file a record INSIDE a TP bracket with hang armed; the
 ; writer freezes in the .01 C-xref BEFORE TCOMMIT. mupip-stop -> whole txn
 ; rolls back -> nothing persists (contrast R-6a's persistent torn record).
 N FDA,IEN,ERR,NAME S NAME=$P($ZCMDLINE," ",1) S:NAME="" NAME="TP GHOST"
 S ^ZFSHANG=1
 S ^ZFSMARK("tpstart")=$H   ; committed BEFORE the bracket so the poller sees the writer reached it
 TSTART (IEN,ERR,FDA,NAME):SERIAL
 S FDA(999000,"+1,",.01)=NAME,FDA(999000,"+1,",1)="TPC"
 D UPDATE^DIE("","FDA","IEN","ERR")  ; freezes in the .01 C-xref, INSIDE the uncommitted txn
 TCOMMIT
 Q
