# vista-fileman docs

- [`design/fileman-on-ydb-build.md`](design/fileman-on-ydb-build.md) — the build
  design: the proven from-scratch install recipe for standalone FileMan on bare
  YottaDB, why `DINZMGR`/`^%ZOSF` are not used, and the driver-native phase model.
- `guides/` — how-to (added as needed).
- `memory/` — per-repo auto-memory.

The originating proposal, adversarial detail, and the proof-of-concept artifacts
live in the org `docs` repo under `proposals/fileman-on-ydb/`.
