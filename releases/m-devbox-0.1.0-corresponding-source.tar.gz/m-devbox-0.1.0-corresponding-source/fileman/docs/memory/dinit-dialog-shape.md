# DINIT dialog shape on a fresh engine (first assembled green run, 2026-07-19)

The fresh-engine `D ^DINIT` dialog asks exactly **four** questions:
`Initialize VA FileMan now? NO//` → YES · `SITE NAME:` · `SITE NUMBER:` ·
`TYPE OF MUMPS SYSTEM YOU ARE USING:` → `GT.M(UNIX)`.

The Spike-3 green transcript feeds a fifth line (`NO`) between site number and
OS type. That line is **absorbed by the OS-type prompt**: FileMan rejects it
(`?? ` + bell), re-asks, and the following `GT.M(UNIX)` lands. Benign — the
spike went green the same way. `build.sh` keeps the exact proven input stream
and instead **asserts the trailing `MARKER-DONE` write** (OSNODE/DIC1) so a
dialog misalignment fails loud rather than half-initializing.

Related durable gotcha (fixed in code, recorded here because it will recur in
any future load-set regeneration): `seed/loadlist.txt` must hold **bare
filenames relative to `FM_SRC`** — the PoC artifact version held absolute
scratchpad paths plus a spike-only `ZFMPOC.m` that exists in no source tree.
`phase_load` now fail-louds on any listed file missing from `FM_SRC`.
