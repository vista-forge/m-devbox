# Memory index — vista-fileman

- [DINIT dialog on a fresh engine has 4 prompts](dinit-dialog-shape.md) — the
  transcript's `NO` line is absorbed by the OS-type prompt (benign `??` re-ask);
  keep the proven input stream, assert the `MARKER-DONE` write.
