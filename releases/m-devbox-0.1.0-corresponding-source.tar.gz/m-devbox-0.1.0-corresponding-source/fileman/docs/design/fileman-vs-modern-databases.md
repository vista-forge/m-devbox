# FileMan vs. modern databases — a comparative analysis

A database-to-database comparison of **VA FileMan** (VistA's DBMS, as of 22.2)
against relational (**PostgreSQL**) and document (**MongoDB**) systems — data
model, types, indexing, query, transactions, and scale. **Scope is the database
only**; forms, reporting, and the app-development surface are deliberately
excluded.

> **Why this lives in `vista-fileman`.** It's the design context for how this
> repo positions FileMan *as a database* on YottaDB. It pairs with the
> **adversarial follow-up** in the org `docs` repo
> (`docs/design/fileman-vs-modern-db-adversarial-analysis.md`), which measured the
> claims below against the routines — most importantly that FileMan 22.2 uses
> **zero** M transaction processing (0/861 routines; filing is bare `SET`/`KILL`
> under advisory `LOCK`s). Read that doc for the measured verdict; this one is the
> capability map.

**Grounding:** FileMan facts are from the VA FileMan 22.2 documentation (vdocs gold
corpus, hash `3ce0872e…`) and were verified against a running instance during the
FileMan-on-YDB work. MongoDB/PostgreSQL claims are stated at the level of database
capability, not version-specific behavior.

---

## Contents

- [0. The category error to clear first](#0-the-category-error-to-clear-first)
- [1. Data model](#1-data-model)
- [2. Data types](#2-data-types)
- [3. Schema & introspection](#3-schema--introspection--where-fileman-was-40-years-early)
- [4. Indexing](#4-indexing)
- [5. Query & aggregation](#5-query--aggregation--the-widest-gap)
- [6. Relationships & integrity](#6-relationships--referential-integrity)
- [7. Transactions & concurrency](#7-transactions-consistency--concurrency)
- [8. Scale, HA & replication](#8-scale-ha--replication)
- [9. Constraints, validation, triggers](#9-constraints-validation--triggers)
- [10. Verdict & MongoDB head-to-head](#10-verdict--where-it-leads-where-it-lags)
- [References](#references)

---

## 0. The category error to clear first

FileMan isn't one layer — it's a **schema-enforcing DBMS on top of a NoSQL storage
engine**, and a fair comparison has to hold that straight:

- **Substrate:** MUMPS *globals* — persistent, ordered, sparse, **multidimensional
  key–value B-trees** (`^DPT(ien,node)="piece^piece^piece"`). This layer *is* a
  NoSQL store — arguably the original hierarchical / wide-column key–value engine
  (1966), predating everything it's now compared to.
- **DBMS layer:** FileMan adds the **data dictionary** (schema), typing,
  validation, cross-references, referential pointers, and a data-server API
  (`^DIC`, `^DIE`, `^DIQ`, `FIND^DIC`, `UPDATE^DIE`) on top.

So FileMan sits *orthogonal* to the relational-versus-document axis: a
**hierarchical–relational hybrid with a mandatory, self-describing schema, over a
schemaless key–value engine.**

> **The layer vs. the stack.** Several "modern" capabilities FileMan lacks are
> supplied by the *engine* underneath it — YottaDB, or IRIS. A VistA-on-IRIS
> deployment inherits IRIS's SQL, ACID, and mirroring even though *FileMan proper*
> provides none of them. This analysis compares **FileMan-the-layer**, flagging
> where the engine fills a gap — that distinction is the crux of any honest debate.

## 1. Data model

| Concept | FileMan | Relational · PostgreSQL | Document · MongoDB |
|---|---|---|---|
| Container | **File** (`#.1`/`#.11` DD) | Table | Collection |
| Record | Entry, keyed by **IEN** | Row (primary key) | Document (`_id`) |
| Attribute | **Field** — typed, DD-defined | Column — typed, DDL | Field — typed per-doc |
| Nested / repeating | **Multiple / subfile** — a file within a field | child table, or `JSONB`/array | **Embedded doc / array** |
| Reference | **POINTER / VARIABLE-POINTER** | Foreign key | Manual ref / DBRef |
| Surrogate key | **IEN** — per-file sequential integer | serial / UUID | ObjectId — 12-byte, distributed |
| Schema | **Mandatory, self-describing, runtime-editable** | Mandatory, DDL-migrated | Optional (schemaless + optional validation) |

The structural punchline: **FileMan and MongoDB make the same embed-or-reference
choice.** A FileMan file with multiples is a document with embedded arrays; a
FileMan pointer is a Mongo reference. The philosophical split is schema — Mongo is
"no schema, validate if you feel like it"; FileMan is "mandatory schema, but it is
*data* you can edit at runtime." Neither is the rigid-DDL relational model.

> **The model's Achilles' heel.** Unlike an ObjectId (globally unique, generable
> offline, merge-safe) or a UUID, an **IEN** is a per-file sequential integer. It
> *collides across instances* — which is exactly why KIDS has to remap IENs at
> install time and why cross-site merges are hard. Mongo's `_id` was designed for
> the distributed world FileMan's IEN was not.

## 2. Data types

FileMan carries **17 field data types** — more than its reputation admits. It gained
`BOOLEAN`, `TIME`, `YEAR`, `UNIVERSAL TIME`, `RATIO`, and free-text pointer/date
variants in 22.2.

| FileMan (17) | Nearest SQL | Nearest BSON | Note |
|---|---|---|---|
| DATE/TIME · TIME · YEAR · UNIVERSAL TIME | date / time / timestamptz | date | FileMan's own 7-digit date format; UNIVERSAL TIME adds TZ |
| NUMERIC | numeric / decimal / float | double / decimal128 / int | **One loose type** — no int/decimal/float split; precision via input transform |
| BOOLEAN | boolean | bool | Added 22.2 (was SET OF CODES 0/1) |
| SET OF CODES | enum | — (string) | Enum; stored as internal code |
| FREE TEXT | varchar | string | Length-bounded string |
| WORD-PROCESSING | text | string / array | Multi-line; stored as a subfile of lines |
| COMPUTED | generated column | — | **Virtual / derived, not stored** — arbitrary M expression |
| POINTER · VARIABLE-POINTER | FK · *(no analog)* | ref · *(no analog)* | **VARIABLE-POINTER = polymorphic FK** — rare anywhere else |
| MUMPS | *(no analog)* | *(no analog)* | Stores executable M code as a value |
| RATIO · FT POINTER · FT DATE · LABEL REFERENCE | — | — | Niche 22.2 additions |

**Real type gaps (even counting the engine):** no native **binary / BLOB**; no
first-class **JSON / document type** (globals hold caret-delimited strings — JSON is
an *I/O* format on `FIND^DIC`, not a stored, queryable type, so there is no `->` /
`@>` operator); no **geospatial**; no **vector / embedding** type; no native
**array-of-scalars** (a multiple is heavier than a Postgres array or a BSON array);
no **decimal-vs-float** separation; no distributed **UUID**.

**Type strengths that beat both:** `COMPUTED` (virtual columns, decades before
generated columns); `VARIABLE-POINTER` (polymorphic references — SQL and Mongo both
make you hand-roll this); `SET OF CODES` (proper enums); and the `MUMPS` type
(code-as-data).

## 3. Schema & introspection — where FileMan was 40 years early

The data dictionary **is itself FileMan files** (`#.1` FILE, `#.11` INDEX, the `^DD`
global). The schema is therefore:

- **Self-describing** — the catalog is queryable with the *same API as the data*.
- **Runtime-editable** — add a field or a cross-reference on a live system; no
  `ALTER TABLE` downtime, no migration tool.
- **Introspectable as first-class data** — like Postgres's `information_schema`, but
  *writable* and load-bearing.

This is genuinely ahead of its time — the "schema registry" / multi-model idea,
shipped in 1979. MongoDB's schemaless flexibility gets you runtime change but
*discards* the enforced, introspectable contract; Postgres keeps the contract but
makes evolution a migration event. FileMan uniquely gives you **both an enforced
schema and painless runtime evolution.**

## 4. Indexing

| Capability | FileMan | MongoDB | PostgreSQL |
|---|---|---|---|
| Basic | Regular x-ref (`"B"` index) | single-field | B-tree |
| Composite | **Compound** new-style index | compound | multicolumn |
| Expression / functional | **MUMPS x-ref** — arbitrary M code | via aggregation only | expression index |
| Uniqueness | **KEY** file | unique | unique |
| Partial | screened x-ref ≈ partial | partial | partial |
| Full-text | ✗ roll your own | text index | GIN + `tsvector` |
| Geospatial | ✗ | 2dsphere | PostGIS / GiST |
| TTL / expiry | ✗ | TTL | via job |
| Vector | ✗ | Atlas vector | pgvector |
| Auto-selection | **✗ — caller names the index** | query planner | cost-based planner |

FileMan's index model is **powerful but manual and imperative.** The `MUMPS`
cross-reference is effectively a *functional index where you write the function* —
more programmable than anything Mongo offers — but there is **no query planner**:
the caller of `FIND^DIC` names the index to use. Mongo and Postgres *choose*
indexes; FileMan makes the developer choose. And it simply has no geospatial, text,
TTL, or vector index *types*.

## 5. Query & aggregation — the widest gap

- **FileMan:** the DBS API (`FIND^DIC`, `LIST^DIC`, `$$GET1^DIQ`) for keyed /
  indexed lookups (JSON-capable output); **extended pointers** for *relational
  navigation* — walking a pointer chain is an implicit join; plus interactive
  Search / Sort / Print with totals and subtotals.
- **MongoDB:** rich query operators plus the **aggregation pipeline** (`$match` /
  `$group` / `$lookup` / `$facet` / `$unwind`…) — a full data-transformation engine.
- **PostgreSQL:** relational algebra plus a **cost-based optimizer** — arbitrary
  joins, `GROUP BY`, window functions, CTEs, set operations.

This is where FileMan lags most as a *database*. It has **no declarative query
language of its own with an optimizer**, **no arbitrary joins** (only pointer-chain
traversal), and **only rudimentary aggregation** (report totals, not `GROUP BY` /
windows / pipelines). Ad-hoc analytical querying — the thing SQL and the Mongo
pipeline exist for — is FileMan's weakest dimension.

> **The stack caveat.** SQL *is* available — but bolted on *beside* FileMan by the
> engine. IRIS SQL projects FileMan globals as relational tables; YottaDB's **Octo**
> gives SQL over the same globals. So "VistA can't do SQL" is false at the stack
> level; "FileMan-the-layer has no optimizer-driven query language" is true.

## 6. Relationships & referential integrity

FileMan does references (pointers, including **polymorphic** variable-pointers) *and*
embedding (multiples) — like Mongo, unlike pure-relational. Integrity is enforced by
an **input transform validating the pointer** and by **delete-protection** — you
cannot delete an entry that is pointed to.

But it is **softer than SQL foreign keys**: no declarative `ON DELETE CASCADE /
RESTRICT / SET NULL`, no deferrable constraints. It sits closer to Mongo's
application-enforced references than to Postgres's declarative FK graph — except
FileMan at least centralizes the rule in the data dictionary rather than in
application code.

## 7. Transactions, consistency & concurrency

| Property | FileMan layer | Engine · YottaDB / IRIS | MongoDB | PostgreSQL |
|---|---|---|---|---|
| ACID | not exposed as multi-record txns by default | yes — `TSTART/TCOMMIT`, journaling | multi-doc (≥4.0, replica sets) | full ACID |
| Isolation | advisory `LOCK`, cooperative | engine-defined | snapshot (WiredTiger MVCC) | MVCC (snapshot / serializable) |
| Reader / writer | locks can block | — | readers don't block writers | MVCC |

The honest read: **strong ACID exists in the M stack, but at the *engine* level, not
uniformly wrapped by the FileMan API.** MUMPS gives you real transactions and
journaling on a single node; concurrency control at the FileMan layer is `LOCK`-based
— **advisory, incremental, cooperative** — not MVCC. Readers and writers can contend
in ways Mongo's and Postgres's MVCC avoids. Those systems present *uniform,
developer-visible* transaction and isolation semantics; FileMan makes you reach down
to `TSTART` / `LOCK` yourself.

> **Measured (adversarial follow-up):** FileMan 22.2 doesn't just *fail to wrap*
> engine transactions — it uses **none**. 0/861 routines contain `$TLEVEL`/`TSTART`;
> filing is bare `SET`/`KILL` under advisory `LOCK`s. See
> `docs/design/fileman-vs-modern-db-adversarial-analysis.md` in the `docs` repo.

## 8. Scale, HA & replication

**Entirely engine-level; FileMan has no concept of it.** No partitioning, no
sharding, no "distribute this file" in FileMan itself. High availability comes from
**YottaDB replication** (multi-site source / replica), or **IRIS mirroring + ECP**
(distributed cache), or **IRIS sharding**.

Contrast MongoDB, where **native replica sets and sharding** are core database
features, and PostgreSQL (streaming replication plus Citus / partitioning). VistA
historically scales *vertically* — M globals scale beautifully on one large box —
and leans on the engine for HA; horizontal scale-out was never FileMan's design
center.

## 9. Constraints, validation & triggers

FileMan's real strength: **imperative validation embedded in the data dictionary** —
per-field **INPUT transforms** (arbitrary M validation), **SCREEN** logic, required
fields, **KEY** uniqueness, and **trigger cross-references** that fire M code on set
or kill (triggers, conceptually before SQL triggers were common).

This is *more* expressive than Mongo's JSON-Schema validation and rivals SQL triggers
— but it is **code, not declarative constraints**: powerful and auditable in one
place, yet heavier and MUMPS-bound.

## 10. Verdict — where it leads, where it lags

**Where FileMan leads — even vs. 2020s systems:**

- **Schema-as-data + runtime evolution** — enforced *and* migration-free; still rare.
- **Multi-model before "multi-model"** — embedding (multiples), references
  (pointers), and a KV substrate in one engine.
- **Polymorphic references**, **virtual/computed fields**, and **programmable
  functional indexes** as first-class DD features.
- **Sparse hierarchical storage** — space-efficient; keyed and range access with no
  planner overhead.
- **Proven at scale** — decades, nationwide, life-critical.

**Where FileMan lags — as a database, engine-independent:**

- **No optimizer-driven query language or arbitrary joins** — the biggest gap;
  analytics is bolted on, not native.
- **Thin aggregation** — no `GROUP BY` / window / pipeline.
- **Type gaps** — no native binary, JSON-type, geospatial, vector, distributed UUID;
  one loose NUMERIC.
- **Coarse concurrency** — advisory locks, no MVCC at the FileMan layer (and, as
  measured, no engine transactions used at all).
- **No native scale-out** — sharding, replication all delegated to the engine.
- **Manual index management** and a MUMPS-based, code-heavy developer surface.

**Head-to-head with MongoDB, specifically.** They are closer than folklore suggests —
the *same* embed-or-reference data model, both flexible-schema-ish, both
hierarchical. Mongo decisively wins on **query and aggregation expressiveness, native
sharding and replica-set scale-out, index-type breadth (geo / text / TTL / vector), a
distributed-native `_id`, and JSON-native storage.** FileMan wins on **an
enforced-yet-runtime-editable self-describing schema, polymorphic references, computed
fields, programmable functional indexes, and sparse storage efficiency.**

The deepest divergence is **identity and distribution**: Mongo was born for
horizontal, offline-generable, merge-safe identity; FileMan's sequential `IEN` ties
it to vertical, single-authority deployment — which is the real reason it feels "old"
next to a NoSQL system, more than any feature checkbox.

> **Framing.** FileMan is a schema-first, multi-model DBMS that solved runtime schema
> evolution and hierarchical-plus-relational storage decades early — but it
> externalized query optimization, horizontal scale, and distributed identity to its
> engine and its era, which is exactly where modern relational and document databases
> now compete.

---

## References

**Primary — VA FileMan 22.2 (documented facts).** vdocs gold corpus, content hash
`3ce0872e…`:

- Advanced User Manual — "Field Data Types" (Table 6, the 17 types), "SET OF CODES,
  POINTER, and VARIABLE-POINTER Data Types", "Multiple-Valued Field (Multiples)",
  "Relational Query Example" (`DI/fm22_2um2/…`).
- Developer's Guide — "FIND^DIC Parameters", the LIST^DIC / JSON output surface
  (`DI/fm22_2dg/…`).
- Key and Index Tutorial — cross-reference taxonomy: traditional (regular / MUMPS /
  trigger / whole-file) and new-style (regular / MUMPS / compound), plus KEY files
  (`DI/fm22_tutorial`).
- Technical & Developer Manuals — "VA FileMan can be used as a standalone database";
  the self-describing DD (`#.1`, `#.11`, `^DD`) (`DI/fm22_2tm/…`,
  `DI/fm22_2dg/standalone-va-fileman`).
- Public source of the FileMan manuals + Timson's history: `hardhats.org/fileman/`,
  `hardhats.org/history/hardhats.html`.

**Comparative — modern databases.** MongoDB Manual (`mongodb.com/docs`) — data
modeling, BSON types, aggregation pipeline, index types, sharding & replica sets,
multi-document transactions. PostgreSQL Documentation (`postgresql.org/docs`) — data
types (incl. `JSONB`, arrays, ranges), MVCC & isolation, index methods, the
cost-based planner, streaming replication.

**Engine substrate — MUMPS & the M databases.** YottaDB (`docs.yottadb.com`) —
multidimensional global storage, `TSTART/TCOMMIT`, `LOCK`, replication; and **Octo**
(SQL over M globals). InterSystems IRIS (`docs.intersystems.com`) — multi-model
(globals / objects / SQL), ACID, mirroring, ECP, sharding — the engine capabilities a
VistA-on-IRIS stack inherits above FileMan.

**Adversarial follow-up (measured against the routines):** the org `docs` repo,
`docs/design/fileman-vs-modern-db-adversarial-analysis.md`.

**Styled version:** a formatted HTML rendering of this analysis sits beside it at
[`fileman-vs-modern-databases.html`](fileman-vs-modern-databases.html).
