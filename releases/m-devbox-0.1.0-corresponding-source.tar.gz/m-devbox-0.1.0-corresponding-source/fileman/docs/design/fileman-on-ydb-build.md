# vista-fileman — build design

How this repo installs **standalone VA FileMan 22.2 onto a bare YottaDB engine**,
from scratch, driver-native. The recipe below is **proven** (org `docs` repo,
`proposals/fileman-on-ydb/` §7.7); this note is the repo-local design of record.

## Principle

FileMan is the true baseline of VistA — it predates Kernel and is **self-installing
on a bare M engine**. So the smallest real from-scratch VistA seed is FileMan alone.
Everything above it (Kernel = L1b, KIDS packages = L2) stacks on this.

## The phase model

All engine access is through the `m-ydb` driver, inside one run-lock bracket
(`scripts/build.sh`). No raw docker/mumps.

| Phase | What | How |
|---|---|---|
| **P0** | Fresh bare YDB | `m-ydb lifecycle provision` a dedicated container (destroy any stale first), `wait` healthy |
| **P1** | Load FileMan routines | `m-ydb exec load` the MSC-lineage `.m`; **exclude the 10 foreign-OS `DINV*/DINZ*` variants** (they fail YDB compile) |
| **P2** | Seed the OS glue | Seed 5 `%`-routines (`DIDT→%DT`, `DIDTC→%DTC`, `DIRCR→%RCR`, `DIIS→%ZIS`, `DIISS→%ZISS`) + a minimal `%ZOSV`, via FileMan's own `19,"ZS"` `$TEXT`-copy technique (`seed/FMPOCREN.m`, `seed/ZOSVSTUB.m`) |
| **P3** | Initialize | Drive `D ^DINIT` via `m-ydb exec script` with the 4-line answer `YES / <site> / <num> / GT.M(UNIX)` |
| **P4** | Verify | `$$GET1^DIQ(1,"1,",.01)="FILE"`; `%DT` parses a date; a write round-trips via `UPDATE^DIE` |

## Two things that are NOT what the hardhats recipe implies

1. **No `DINZMGR`.** It is a fossilized 22.0 dialog: its OS menu has no GT.M(Unix)
   option, and its rename engine runs `X "ZL @X ZS @Y"` — ZLOAD/ZSAVE, which
   YottaDB lacks. P2 replaces it with the `19,"ZS"` copy technique FileMan itself
   uses.
2. **`^%ZOSF` is not the porting surface.** FileMan 22.2 runs off `^DD("OS")` (file
   #.7, IEN 19 = `GT.M(UNIX)`); `OS^DII` falls back `^%ZOSF` → `^DD("OS")`. A
   from-scratch install ends with `^%ZOSF` **empty** and works. The full 54-node
   `^%ZOSF` only matters once Kernel (L1b) or screen-oriented consumers arrive.

## Two driver findings this build works around (file upstream in `m-ydb`)

- `exec load` rejects `%`-routine **filenames** (`_DT.m` → "invalid routine name").
  → seed `%`-routines in-engine via the `19,"ZS"` copy, not by filename.
- YDB fault text does **not** reach the `exec script`/`eval` stdout channel. → every
  driven script opens with an `$ETRAP` that writes `$ZSTATUS`, else failures are
  silent.

## Source — pinned, verified, not vendored

The FileMan source is the **MSC FileMan Apache-2.0 lineage** ("Based on Medsphere …")
as it ships in **`WorldVistA/VistA-VEHU-M`** — the VEHU distribution the org's `vehu`
gold-master derives from (which is why the PoC's routines matched it exactly). It is
**pinned to an immutable commit** in [`scripts/seed/source.pin`](../../scripts/seed/source.pin):

```
repo=https://github.com/WorldVistA/VistA-VEHU-M.git
commit=62622e63fc7dffad27fc79f107fd7689c2ac4eff
subpath=Packages/VA FileMan/Routines
```

`make sources` (the ONE network step, run at sync-time per the airgap model) does a
**sparse, blobless, single-commit** fetch of *only* the FileMan subpath into `./src`
(gitignored), then verifies **every routine byte-for-byte** against
[`scripts/seed/sources.sha256`](../../scripts/seed/sources.sha256) (851 hashes of the
proven set; aggregate `b187b857…`). Any drift from the proven bytes **fails loud** —
so the build is reproducible regardless of upstream mutation, and nothing is vendored.
`make build` is offline and consumes `./src` (it depends on `verify-sources`).

## Open items (tracked in the proposal)

- Idempotency of the P4 verify (each run adds a `#1.2` row — look-up-or-create).
- Optional: bake the finished instance into an image (Strategy-A, like `vista-iris`).
- IRIS parity via the `m-iris` driver (the seam is engine-neutral).
- One live `make sources && make build` on a network-and-engine host to confirm the
  pinned fetch reproduces green (the checksum manifest already guarantees byte-
  identity to the proven source).
