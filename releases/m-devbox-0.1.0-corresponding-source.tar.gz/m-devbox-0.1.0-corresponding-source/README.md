# m-devbox 0.1.0 — corresponding source

This bundle is the **corresponding source** for the published container image:

    image      docker.io/rafaelrichards/m-devbox:0.1.0
    image id   sha256:8151b092c1922110e33402003bd7bffd49eba95c3d6284ad475ccfc2af5fb3d2
    digest     sha256:b83d089167c6ac819309ce6470ac18f20138ae76dad30ffd3dab5cd47f2ace80
    assembled  2026-07-27

It exists because the image contains AGPL-3.0-or-later software — YottaDB and
vista-forge's own code — and its recipients are entitled to the source. See
`COMMITS.txt` for the exact commit of every repository included.

## Rebuilding — the pins and this bundle agree, verifiably

As of this release the `go.mod` pins and these directories name the SAME
code: the image binaries are built with `GOWORK=off` against the pinned
module versions, every dependency repo in this bundle is archived at the exact
commit its tag/pin names, and the image's acceptance gate G27 reads the module
list Go embeds in the shipped binaries and refuses any mismatch. You may
rebuild from the pins or from these directories; they are the same source.

## What is here

| Directory | What it is | Licence |
|---|---|---|
| `m-devbox/` | the image recipe: Dockerfile, staging, gates, examples | AGPL-3.0-or-later + commercial |
| `m-cli/` | the `m` toolchain | AGPL-3.0-or-later + commercial |
| `m-ydb/` | the YottaDB driver | AGPL-3.0-or-later + commercial |
| `clikit/`, `m-driver-sdk/`, `m-parse/` | linked into the binaries above | see each repo |
| `m-stdlib/` | MSL routines + native callout sources | AGPL-3.0-or-later + commercial |
| `f-stdlib/` | FSL routines | AGPL-3.0-or-later + commercial |
| `m-vscode/` | the baked VS Code extension | AGPL-3.0-or-later + commercial |
| `fileman/` | our FileMan build scripts and the pinned-source manifest | AGPL-3.0-or-later + commercial |

## What is NOT here, and where to get it

These are third-party components the image assembles but does not fork. Each is
pinned, and every pin is recorded in `m-devbox/Dockerfile`'s header:

- **YottaDB r2.06** — AGPL-3.0-or-later, from YottaDB LLC.
  Source: <https://gitlab.com/YottaDB/DB/YDB>. Installed by that project's own
  `ydbinstall.sh` at a pinned commit, checksum-verified in the build.
- **VA FileMan 22.2** — 774 of its 861 routines are Apache-2.0 (Medsphere MSC
  FileMan 1051 lineage); the rest are US Government work. Fetched from the
  pinned WorldVistA/VistA-VEHU-M commit recorded in
  `fileman/scripts/seed/source.pin`, and byte-verified against
  `fileman/scripts/seed/sources.sha256`. Not modified — see the change
  statement in `m-devbox/NOTICE`.
- **code-server, Code Runner, Error Lens, Rainbow CSV, Debian, git** — pinned
  by version and sha256 in the Dockerfile header; upstream sources at their own
  projects.

The full third-party inventory, with every licence read from the artifact
itself, is `m-devbox/NOTICE` — also baked into the image at
`/opt/licenses/NOTICE`.

## Rebuilding

The build needs these repositories side by side in one directory (the layout
they have here), then:

    cd m-devbox && make build

Network is used only at build time, for the pinned upstreams above.
